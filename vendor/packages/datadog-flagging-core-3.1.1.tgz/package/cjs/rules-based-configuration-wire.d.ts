import './configuration/protobuf-text-encoding';
export { getPrecomputedContext } from './configuration/precomputed-context';
export { configurationFromRulesBinary } from './configuration/rules-wire';
export { configurationFromString, configurationToString } from './configuration/wire';
export type { FlagsConfigurationWire } from './configuration/wire-types';
//# sourceMappingURL=rules-based-configuration-wire.d.ts.map