export declare function encodeUtf8(value: string): Uint8Array<ArrayBuffer>;
//# sourceMappingURL=utf8.d.ts.map