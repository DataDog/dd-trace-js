import type { EvaluationContext, FlagValue, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import { type FlagsConfiguration, type FlagTypeToValue } from '../configuration';
import type { FlagsConfiguration as ProtobufFlagsConfiguration } from '../configuration/generated/ufc_pb';
import { type UniversalFlagConfigurationV1 } from './ufc-v1';
export declare function evaluate<T extends FlagValueType>(flagsConfiguration: FlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger?: Logger, onDependencyEvaluation?: DependencyEvaluationHandler, onDependencyExposures?: DependencyExposureHandler): ResolutionDetails<FlagTypeToValue<T>>;
export type FlagsConfigurationError = {
    errorCode: 'INVALID_CONTEXT' | 'PARSE_ERROR' | 'PROVIDER_NOT_READY';
    errorMessage?: string;
};
/** Return the lifecycle/evaluation error when no configuration capability can serve the context. */
export declare function getFlagsConfigurationError(configuration: FlagsConfiguration | undefined, context: EvaluationContext): FlagsConfigurationError | undefined;
export declare function evaluateRulesBasedConfiguration<T extends FlagValueType>(config: UniversalFlagConfigurationV1 | ProtobufFlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger: Logger, onDependencyEvaluation?: DependencyEvaluationHandler, onDependencyExposures?: DependencyExposureHandler): ResolutionDetails<FlagTypeToValue<T>>;
export type DependencyEvaluation = {
    flagKey: string;
    details: ResolutionDetails<FlagValue>;
};
export type DependencyExposureCandidate = {
    flagKey: string;
    details: ResolutionDetails<FlagValue>;
};
export type DependencyEvaluationHandler = (evaluation: DependencyEvaluation) => void;
export type DependencyExposureHandler = (evaluations: readonly DependencyExposureCandidate[]) => void;
//# sourceMappingURL=evaluation.d.ts.map