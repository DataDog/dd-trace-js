import type { EvaluationContext, EvaluationContextValue } from '@openfeature/core';
export type ConditionValueType = EvaluationContextValue | EvaluationContextValue[];
export declare enum OperatorType {
    MATCHES = "MATCHES",
    NOT_MATCHES = "NOT_MATCHES",
    GTE = "GTE",
    GT = "GT",
    LTE = "LTE",
    LT = "LT",
    ONE_OF = "ONE_OF",
    NOT_ONE_OF = "NOT_ONE_OF",
    IS_NULL = "IS_NULL",
    SEMVER_EQ = "SEMVER_EQ",
    SEMVER_NEQ = "SEMVER_NEQ",
    SEMVER_LT = "SEMVER_LT",
    SEMVER_LTE = "SEMVER_LTE",
    SEMVER_GT = "SEMVER_GT",
    SEMVER_GTE = "SEMVER_GTE"
}
type NumericOperator = OperatorType.GTE | OperatorType.GT | OperatorType.LTE | OperatorType.LT;
type SemVerOperator = OperatorType.SEMVER_EQ | OperatorType.SEMVER_NEQ | OperatorType.SEMVER_GTE | OperatorType.SEMVER_GT | OperatorType.SEMVER_LTE | OperatorType.SEMVER_LT;
type MatchesCondition = {
    operator: OperatorType.MATCHES;
    attribute: string;
    value: string;
};
type NotMatchesCondition = {
    operator: OperatorType.NOT_MATCHES;
    attribute: string;
    value: string;
};
type OneOfCondition = {
    operator: OperatorType.ONE_OF;
    attribute: string;
    value: string[];
};
type NotOneOfCondition = {
    operator: OperatorType.NOT_ONE_OF;
    attribute: string;
    value: string[];
};
export type FlagEvaluation = {
    key: string;
    property?: 'variant_key' | 'reason' | 'error_code';
};
type FlagEvaluationCondition = {
    operator: OperatorType.ONE_OF | OperatorType.NOT_ONE_OF;
    flagEvaluation: FlagEvaluation;
    value: string[];
} | {
    operator: OperatorType.MATCHES | OperatorType.NOT_MATCHES;
    flagEvaluation: FlagEvaluation;
    value: string;
};
export type ResolveFlagEvaluation = (flagEvaluation: FlagEvaluation) => string | undefined;
type NumericCondition = {
    operator: NumericOperator;
    attribute: string;
    value: number;
};
type NullCondition = {
    operator: OperatorType.IS_NULL;
    attribute: string;
    value: boolean;
};
type SemVerCondition = {
    operator: SemVerOperator;
    attribute: string;
    value: string;
};
export type Condition = MatchesCondition | NotMatchesCondition | OneOfCondition | NotOneOfCondition | FlagEvaluationCondition | NumericCondition | NullCondition | SemVerCondition;
export interface Rule {
    conditions: Condition[];
}
export declare function isValidRule(rule: unknown): rule is Rule;
export declare function matchesRule(rule: Rule, subjectAttributes: EvaluationContext, resolveFlagEvaluation?: ResolveFlagEvaluation): boolean;
export {};
//# sourceMappingURL=rules.d.ts.map