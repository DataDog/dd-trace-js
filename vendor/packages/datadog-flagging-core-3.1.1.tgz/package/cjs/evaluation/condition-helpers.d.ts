export declare function compileRegex(pattern: string): RegExp;
export declare function coerceToString(value: unknown): string | undefined;
export declare function coerceToNumber(value: unknown): number | undefined;
//# sourceMappingURL=condition-helpers.d.ts.map