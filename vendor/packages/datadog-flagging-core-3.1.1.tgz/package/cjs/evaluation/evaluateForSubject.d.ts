import type { EvaluationContext, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import type { FlagTypeToValue } from '../configuration';
import { type TimeStamp } from '../time';
import { type ResolveFlagEvaluation, type Rule } from './rules';
import { type Flag } from './ufc-v1';
export declare function evaluateForSubject<T extends FlagValueType>(flag: Flag, type: T, subjectKey: string | null | undefined, subjectAttributes: EvaluationContext, defaultValue: FlagTypeToValue<T>, logger: Logger, evaluationTimestampMs?: TimeStamp, resolveFlagEvaluation?: ResolveFlagEvaluation): ResolutionDetails<FlagTypeToValue<T>>;
export declare function containsMatchingRule(rules: Rule[] | undefined, subjectAttributes: EvaluationContext, logger: Logger, resolveFlagEvaluation?: ResolveFlagEvaluation): boolean;
//# sourceMappingURL=evaluateForSubject.d.ts.map