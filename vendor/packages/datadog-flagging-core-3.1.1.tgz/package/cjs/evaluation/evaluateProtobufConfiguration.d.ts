import type { EvaluationContext, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import type { FlagTypeToValue } from '../configuration';
import type { PreparedRulesResponse } from '../configuration/prepared-rules-response';
import { type TimeStamp } from '../time';
export declare function evaluateProtobufConfiguration<T extends FlagValueType>(configuration: PreparedRulesResponse, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger: Logger, evaluationTimestampMs?: TimeStamp): ResolutionDetails<FlagTypeToValue<T>>;
//# sourceMappingURL=evaluateProtobufConfiguration.d.ts.map