import type { EvaluationContext, FlagValueType, ResolutionDetails } from '@openfeature/core';
import { type FlagsConfiguration, type FlagTypeToValue } from '../configuration';
export declare function evaluatePrecomputedConfiguration<T extends FlagValueType>(flagsConfiguration: FlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext): ResolutionDetails<FlagTypeToValue<T>>;
//# sourceMappingURL=precomputed-evaluation.d.ts.map