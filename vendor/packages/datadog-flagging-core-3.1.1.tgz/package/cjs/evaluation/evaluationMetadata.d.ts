import type { PrecomputedFlagMetadata } from '../configuration';
import type { TimeStamp } from '../time';
export declare function createEvaluationMetadata(evaluationTimestampMs: TimeStamp, observeFullEvaluationData: unknown): PrecomputedFlagMetadata;
export declare function createEvaluationTimestampMetadata(evaluationTimestampMs: TimeStamp): PrecomputedFlagMetadata;
//# sourceMappingURL=evaluationMetadata.d.ts.map