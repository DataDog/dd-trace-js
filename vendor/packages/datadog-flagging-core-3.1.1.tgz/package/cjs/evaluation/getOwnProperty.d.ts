export declare function getOwnProperty<T>(record: Record<string, T>, key: string): T | undefined;
//# sourceMappingURL=getOwnProperty.d.ts.map