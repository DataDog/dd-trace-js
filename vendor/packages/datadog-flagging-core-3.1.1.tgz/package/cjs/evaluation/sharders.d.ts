export declare abstract class Sharder {
    abstract getShard(input: string, totalShards: number): number;
}
export declare class MD5Sharder extends Sharder {
    getShard(input: string, totalShards: number): number;
}
export declare class DeterministicSharder extends Sharder {
    private lookup;
    constructor(lookup: Record<string, number>);
    getShard(input: string, _totalShards: number): number;
}
//# sourceMappingURL=sharders.d.ts.map