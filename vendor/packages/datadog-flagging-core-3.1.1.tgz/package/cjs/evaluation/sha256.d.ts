export declare function sha256(input: Uint8Array): Uint8Array;
export declare function sha256Hex(input: Uint8Array): string;
//# sourceMappingURL=sha256.d.ts.map