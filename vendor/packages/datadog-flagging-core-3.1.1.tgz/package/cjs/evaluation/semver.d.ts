/**
 * The language-neutral SemVer representation used by the FFE evaluator.
 * Build metadata is validated while parsing but is intentionally not retained,
 * because it does not affect SemVer precedence.
 */
export interface ParsedSemver {
    parts: string[];
    prerelease: string;
}
export interface ParsedVersion {
    components: string[];
    prerelease: string[];
}
/** Parse the version syntax represented by the UFC protobuf Version message. */
export declare function parseVersion(value: unknown): ParsedVersion | null;
/** Validate a pre-parsed version received from protobuf. */
export declare function isParsedVersion(value: ParsedVersion): boolean;
/** Compare versions, treating missing main components as zero. */
export declare function compareVersions(left: ParsedVersion, right: ParsedVersion): number;
/**
 * Parse the SemVer subset.
 *
 * Core identifiers are limited to uint64; numeric prerelease identifiers may
 * be arbitrarily large. One- and two-part core versions are accepted and
 * normalized with missing parts treated as zero; any number of additional
 * core parts is accepted as further numeric identifiers.
 */
export declare function parseSemver(version: unknown): ParsedSemver | null;
/** Compare SemVer precedence. Build metadata is intentionally ignored. */
export declare function compareSemver(left: ParsedSemver, right: ParsedSemver): number;
//# sourceMappingURL=semver.d.ts.map