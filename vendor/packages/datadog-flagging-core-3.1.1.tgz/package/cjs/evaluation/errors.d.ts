export declare class TargetingKeyMissingError extends Error {
    constructor();
}
export declare class FlagConfigurationError extends Error {
    constructor(message: string);
}
export declare class InvalidContextError extends Error {
    constructor();
}
//# sourceMappingURL=errors.d.ts.map