import type { FlagValue } from '@openfeature/core';
import type { FlagsConfiguration as ProtobufFlagsConfiguration } from './generated/ufc_pb';
export type CachedJsonValue = {
    valid: true;
    value: FlagValue;
} | {
    valid: false;
};
export type PreparedRulesResponse = ProtobufFlagsConfiguration & {
    evaluationRegexCache: Map<number, RegExp | null>;
    evaluationJsonCache: Map<number, CachedJsonValue>;
};
export declare function prepareRulesResponse(response: ProtobufFlagsConfiguration): PreparedRulesResponse;
//# sourceMappingURL=prepared-rules-response.d.ts.map