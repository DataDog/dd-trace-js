import type { EvaluationContextValue } from '@openfeature/core';
import type { TimeStamp } from '../time';
import type { FlagEvaluationEvent } from './flagEvaluationEvent.types';
interface FlagEvaluationAggregationData {
    flagKey: string;
    variantKey?: string;
    allocationKey?: string;
    targetingRuleKey?: string;
    targetingKey?: string;
    targetingContext?: Record<string, EvaluationContextValue>;
    count: number;
    firstEvaluation: TimeStamp;
    lastEvaluation: TimeStamp;
    runtimeDefaultUsed: boolean;
    error?: string;
}
export declare function createFlagEvaluationEvent(data: FlagEvaluationAggregationData, timestamp: TimeStamp): FlagEvaluationEvent;
export {};
//# sourceMappingURL=flagEvaluationEvent.d.ts.map