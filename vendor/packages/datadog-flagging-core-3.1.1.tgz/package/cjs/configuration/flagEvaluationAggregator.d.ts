import type { EvaluationContext, EvaluationDetails, FlagValue } from '@openfeature/core';
import type { FlagEvaluationEvent } from './flagEvaluationEvent.types';
export declare class FlagEvaluationAggregator {
    private aggregatedData;
    private intervalId?;
    private readonly flushInterval;
    private readonly onFlush;
    constructor(flushInterval: number, onFlush: (events: FlagEvaluationEvent[]) => void);
    start(): void;
    stop(): void;
    addEvaluation<T extends FlagValue>(context: EvaluationContext, details: EvaluationDetails<T>, error?: string): void;
    flush(): void;
    private createAggregationKeyString;
}
//# sourceMappingURL=flagEvaluationAggregator.d.ts.map