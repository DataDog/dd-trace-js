import type { EvaluationContext, FlagValueType, JsonValue, ResolutionReason } from '@openfeature/core';
import type { TimeStamp } from '../time';
import type { PreparedRulesResponse } from './prepared-rules-response';
/**
 * Internal flags configuration for DatadogProvider.
 */
export type FlagsConfiguration = {
    /** The configuration wire could not be parsed, so no capability was decoded. @internal */
    configurationError?: string;
    /** @internal */
    precomputed?: PrecomputedConfiguration;
    /** The precomputed capability could not be decoded; a valid rules capability remains usable. @internal */
    precomputedError?: string;
    /** @internal */
    rules?: RulesConfiguration;
    /** The rules capability could not be decoded; a valid precomputed capability remains usable. @internal */
    rulesError?: string;
};
/** @internal */
export type PrecomputedConfiguration = {
    response: PrecomputedConfigurationResponse;
    context?: EvaluationContext;
    fetchedAt?: TimeStamp;
    etag?: string;
    /** Parsing errors for malformed flags, retained by flag key. */
    flagErrors?: Record<string, string>;
};
/** @internal */
export type RulesConfiguration = {
    response: PreparedRulesResponse;
    fetchedAt?: TimeStamp;
    etag?: string;
};
/** @internal */
export type FlagTypeToValue<T extends FlagValueType> = {
    boolean: boolean;
    string: string;
    number: number;
    object: JsonValue;
}[T];
/** @internal */
export type PrecomputedConfigurationResponse = {
    data: {
        attributes: {
            /** When configuration was generated. */
            createdAt: string;
            flags: Record<string, PrecomputedFlag>;
        };
    };
};
/** @internal */
export type PrecomputedFlag<T extends FlagValueType = FlagValueType> = {
    allocationKey: string;
    variationKey: string;
    variationType: T;
    variationValue: FlagTypeToValue<T>;
    reason: ResolutionReason;
    doLog: boolean;
    serialId?: number | null;
};
/** @internal */
export type PrecomputedFlagMetadata = {
    allocationKey?: string;
    variationType?: FlagValueType;
    doLog?: boolean;
    __dd_allocation_key?: string;
    __dd_do_log?: boolean;
    __dd_split_serial_id?: number;
    __dd_eval_timestamp_ms?: TimeStamp;
    __dd_observe_full_evaluation_data?: boolean;
};
/**
 * Check if a stored configuration matches the requested evaluation context.
 * - If the config has no context, it's context-agnostic and matches any request
 * - If the config has a context, it must match the requested context exactly
 */
export declare function configMatchesContext(config: FlagsConfiguration | undefined, requestedContext: EvaluationContext): boolean;
//# sourceMappingURL=configuration.d.ts.map