import type { EvaluationContext } from '@openfeature/core';
import type { TimeStamp } from '../time';
export interface ExposureEvent {
    allocation: {
        key: string;
    };
    flag: {
        key: string;
    };
    variant: {
        key: string;
    };
    serial_id?: number;
    subject: {
        id: string;
        attributes: EvaluationContext;
    };
    service?: string;
    rum?: {
        application?: {
            id?: string;
        };
        view?: {
            url?: string;
        };
    };
}
export interface ExposureEventWithTimestamp extends ExposureEvent {
    /** Unix timestamp in milliseconds */
    timestamp: TimeStamp;
}
//# sourceMappingURL=exposureEvent.types.d.ts.map