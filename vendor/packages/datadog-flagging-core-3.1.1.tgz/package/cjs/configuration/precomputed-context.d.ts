import type { EvaluationContext } from '@openfeature/core';
import type { FlagsConfiguration } from './configuration';
/**
 * Return a detached copy of the context from a precomputed configuration.
 *
 * This function returns `undefined` when the configuration has no
 * context-specific precomputed branch. It does not modify the configuration,
 * OpenFeature, or provider state.
 */
export declare function getPrecomputedContext(configuration: FlagsConfiguration): EvaluationContext | undefined;
//# sourceMappingURL=precomputed-context.d.ts.map