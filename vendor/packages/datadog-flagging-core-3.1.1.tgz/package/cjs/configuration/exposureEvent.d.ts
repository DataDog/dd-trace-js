import type { EvaluationContext, EvaluationDetails, FlagValue } from '@openfeature/core';
import type { ExposureEvent } from './exposureEvent.types';
export declare function createExposureEvent<T extends FlagValue>(context: EvaluationContext, details: EvaluationDetails<T>): ExposureEvent | undefined;
//# sourceMappingURL=exposureEvent.d.ts.map