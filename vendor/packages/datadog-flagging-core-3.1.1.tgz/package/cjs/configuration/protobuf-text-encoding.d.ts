export declare function decodeUtf8(bytes: Uint8Array): string;
//# sourceMappingURL=protobuf-text-encoding.d.ts.map