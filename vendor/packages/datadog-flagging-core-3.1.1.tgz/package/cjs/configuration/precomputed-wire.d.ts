import type { FlagsConfiguration } from './configuration';
import { type ConfigurationWireContents, type FlagsConfigurationWire } from './wire-types';
/**
 * Parse the precomputed entry from an opaque flags configuration wire value.
 */
export declare function configurationFromPrecomputedString(wire: FlagsConfigurationWire): FlagsConfiguration;
/**
 * Serialize only the precomputed capability of a flags configuration.
 */
export declare function configurationToPrecomputedString(configuration: FlagsConfiguration): FlagsConfigurationWire;
export declare function precomputedConfigurationFromWire(serialized: ConfigurationWireContents): FlagsConfiguration;
export declare function precomputedConfigurationToWire(configuration: FlagsConfiguration): ConfigurationWireContents;
//# sourceMappingURL=precomputed-wire.d.ts.map