import type { EvaluationContext } from '@openfeature/core';
import type { TimeStamp } from '../time';
export type FlagsConfigurationWire = string;
export declare const INVALID_CONFIGURATION_WIRE_ERROR = "Invalid flags configuration wire format";
export type ConfigurationWireContents = {
    version: 1;
    precomputed?: {
        context?: EvaluationContext;
        response: string;
        fetchedAt?: TimeStamp;
        etag?: string;
    };
    rules?: {
        response: string;
        fetchedAt?: TimeStamp;
        etag?: string;
    };
};
export declare function parseConfigurationWire(wire: FlagsConfigurationWire): ConfigurationWireContents | undefined;
export declare function decodeSafely<T>(decode: () => T): T | undefined;
//# sourceMappingURL=wire-types.d.ts.map