import type { FlagsConfiguration } from './configuration';
import { type FlagsConfigurationWire } from './wire-types';
export type { FlagsConfigurationWire } from './wire-types';
/**
 * Parse an opaque flags configuration wire value.
 */
export declare function configurationFromString(wire: FlagsConfigurationWire): FlagsConfiguration;
/**
 * Serialize a flags configuration to a string that can be deserialized with
 * `configurationFromString`.
 */
export declare function configurationToString(configuration: FlagsConfiguration): FlagsConfigurationWire;
//# sourceMappingURL=wire.d.ts.map