import type { GenEnum, GenFile, GenMessage } from "@bufbuild/protobuf/codegenv2";
import type { Empty, Timestamp } from "@bufbuild/protobuf/wkt";
import type { Message } from "@bufbuild/protobuf";
/**
 * Describes the file ufc.proto.
 */
export declare const file_ufc: GenFile;
/**
 * FlagsConfiguration is a compiled rules-based flag configuration.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.FlagsConfiguration
 */
export type FlagsConfiguration = Message<"datadog.ffe.flagging.ufc.v1.FlagsConfiguration"> & {
    /**
     * @generated from field: google.protobuf.Timestamp created_at = 1;
     */
    createdAt?: Timestamp | undefined;
    /**
     * @generated from field: string environment_name = 2;
     */
    environmentName: string;
    /**
     * @generated from field: map<string, datadog.ffe.flagging.ufc.v1.Flag> flags = 3;
     */
    flags: {
        [key: string]: Flag;
    };
    /**
     * Interned data referenced by zero-based indexes in conditions. An index must
     * refer to an element in its corresponding list.
     *
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.AttributeReference attributes = 4;
     */
    attributes: AttributeReference[];
    /**
     * @generated from field: repeated string strings = 5;
     */
    strings: string[];
    /**
     * @generated from field: repeated string regexes = 6;
     */
    regexes: string[];
    /**
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.Version versions = 7;
     */
    versions: Version[];
    /**
     * Interned JSON variation values, each a serialized JSON document. Indexed
     * by Variation.json_string_index.
     *
     * JSON values are stored as strings because for some SDKs, our
     * users want to override the JSON parser or get the variant as a
     * string they can parse on their own.
     *
     * @generated from field: repeated string json_strings = 8;
     */
    jsonStrings: string[];
    /**
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.Condition conditions = 9;
     */
    conditions: Condition[];
    /**
     * Opt-in flag for emitting full flag-evaluation data from SDKs to
     * Datadog. May contain PII; defaults to false for privacy.
     *
     * @generated from field: bool observe_full_evaluation_data = 10;
     */
    observeFullEvaluationData: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.FlagsConfiguration.
 * Use `create(FlagsConfigurationSchema)` to create a new message.
 */
export declare const FlagsConfigurationSchema: GenMessage<FlagsConfiguration>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.Version
 */
export type Version = Message<"datadog.ffe.flagging.ufc.v1.Version"> & {
    /**
     * Main version components (usually "major.minor.patch" but can have more/less
     * parts). Missing components should be treated as "0" for comparison
     * purposes.
     *
     * @generated from field: repeated string components = 1;
     */
    components: string[];
    /**
     * @generated from field: repeated string prerelease = 2;
     */
    prerelease: string[];
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Version.
 * Use `create(VersionSchema)` to create a new message.
 */
export declare const VersionSchema: GenMessage<Version>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.Flag
 */
export type Flag = Message<"datadog.ffe.flagging.ufc.v1.Flag"> & {
    /**
     * The minimum feature level an SDK must support to evaluate this flag.
     * SDKs that don't support this level must not evaluate the flag and should
     * report an informative flag-scoped error rather than treat it as absent.
     *
     * @generated from field: uint32 minimum_feature_level = 1;
     */
    minimumFeatureLevel: number;
    /**
     * @generated from field: datadog.ffe.flagging.ufc.v1.VariationType variation_type = 2;
     */
    variationType: VariationType;
    /**
     * Split.variation_index indexes this array.
     *
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.Variation variations = 3;
     */
    variations: Variation[];
    /**
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.Allocation allocations = 4;
     */
    allocations: Allocation[];
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Flag.
 * Use `create(FlagSchema)` to create a new message.
 */
export declare const FlagSchema: GenMessage<Flag>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.Variation
 */
export type Variation = Message<"datadog.ffe.flagging.ufc.v1.Variation"> & {
    /**
     * Variation key. Index into FlagsConfiguration.strings
     *
     * @generated from field: uint32 key_string_index = 1;
     */
    keyStringIndex: number;
    /**
     * The populated field must agree with Flag.variation_type.
     *
     * @generated from oneof datadog.ffe.flagging.ufc.v1.Variation.value
     */
    value: {
        /**
         * Index into FlagsConfiguration.strings
         *
         * @generated from field: uint32 string_value_index = 2;
         */
        value: number;
        case: "stringValueIndex";
    } | {
        /**
         * @generated from field: int64 integer_value = 3;
         */
        value: bigint;
        case: "integerValue";
    } | {
        /**
         * @generated from field: double numeric_value = 4;
         */
        value: number;
        case: "numericValue";
    } | {
        /**
         * @generated from field: bool boolean_value = 5;
         */
        value: boolean;
        case: "booleanValue";
    } | {
        /**
         * JSON variations may be any valid JSON value, including scalar values.
         * Index into FlagsConfiguration.json_strings.
         *
         * @generated from field: uint32 json_string_index = 6;
         */
        value: number;
        case: "jsonStringIndex";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Variation.
 * Use `create(VariationSchema)` to create a new message.
 */
export declare const VariationSchema: GenMessage<Variation>;
/**
 * An allocation first selects subjects matching its targeting expression. It
 * then computes each partition key once and chooses the split whose ranges
 * contain that key tuple.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.Allocation
 */
export type Allocation = Message<"datadog.ffe.flagging.ufc.v1.Allocation"> & {
    /**
     * @generated from field: string key = 1;
     */
    key: string;
    /**
     * Zero-based index into FlagsConfiguration.conditions. Unset means
     * this allocation matches every subject.
     *
     * @generated from field: optional uint32 targeting_condition_index = 2;
     */
    targetingConditionIndex?: number | undefined;
    /**
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.PartitionKey partition_key = 3;
     */
    partitionKey: PartitionKey[];
    /**
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.Split splits = 4;
     */
    splits: Split[];
    /**
     * Whether an evaluation resolved by this allocation should emit an
     * exposure event (e.g. for experiments).
     *
     * @generated from field: bool log_exposure_event = 5;
     */
    logExposureEvent: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Allocation.
 * Use `create(AllocationSchema)` to create a new message.
 */
export declare const AllocationSchema: GenMessage<Allocation>;
/**
 * AttributeReference identifies either the targeting key or a value reached by
 * traversing an attribute path. Object keys are indexed into
 * FlagsConfiguration.strings. Array indexes address elements positionally.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.AttributeReference
 */
export type AttributeReference = Message<"datadog.ffe.flagging.ufc.v1.AttributeReference"> & {
    /**
     * @generated from oneof datadog.ffe.flagging.ufc.v1.AttributeReference.kind
     */
    kind: {
        /**
         * @generated from field: google.protobuf.Empty targeting_key = 1;
         */
        value: Empty;
        case: "targetingKey";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.AttributePath attribute_path = 2;
         */
        value: AttributePath;
        case: "attributePath";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.AttributeReference.
 * Use `create(AttributeReferenceSchema)` to create a new message.
 */
export declare const AttributeReferenceSchema: GenMessage<AttributeReference>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.AttributePath
 */
export type AttributePath = Message<"datadog.ffe.flagging.ufc.v1.AttributePath"> & {
    /**
     * Contains at least one segment and starts with a string.
     *
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.AttributePathSegment segments = 1;
     */
    segments: AttributePathSegment[];
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.AttributePath.
 * Use `create(AttributePathSchema)` to create a new message.
 */
export declare const AttributePathSchema: GenMessage<AttributePath>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.AttributePathSegment
 */
export type AttributePathSegment = Message<"datadog.ffe.flagging.ufc.v1.AttributePathSegment"> & {
    /**
     * @generated from oneof datadog.ffe.flagging.ufc.v1.AttributePathSegment.kind
     */
    kind: {
        /**
         * Index into FlagsConfiguration.strings.
         *
         * @generated from field: uint32 object_key_string_index = 1;
         */
        value: number;
        case: "objectKeyStringIndex";
    } | {
        /**
         * @generated from field: uint32 array_index = 2;
         */
        value: number;
        case: "arrayIndex";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.AttributePathSegment.
 * Use `create(AttributePathSegmentSchema)` to create a new message.
 */
export declare const AttributePathSegmentSchema: GenMessage<AttributePathSegment>;
/**
 * Leaf conditions are grouped by the attribute value type they operate on,
 * so implementations can fetch and convert the attribute once per group
 * before dispatching on the specific comparator.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.Condition
 */
export type Condition = Message<"datadog.ffe.flagging.ufc.v1.Condition"> & {
    /**
     * @generated from oneof datadog.ffe.flagging.ufc.v1.Condition.kind
     */
    kind: {
        /**
         * Logical AND. True when every referenced condition is
         * true. Empty ALL is true.
         *
         * @generated from field: datadog.ffe.flagging.ufc.v1.ConditionOperands all = 1;
         */
        value: ConditionOperands;
        case: "all";
    } | {
        /**
         * Logical OR. True when any referenced condition is true. Empty
         * ANY is false.
         *
         * @generated from field: datadog.ffe.flagging.ufc.v1.ConditionOperands any = 2;
         */
        value: ConditionOperands;
        case: "any";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.NumericCondition numeric = 3;
         */
        value: NumericCondition;
        case: "numeric";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.RegexCondition regex = 4;
         */
        value: RegexCondition;
        case: "regex";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.StringMembershipCondition string_membership = 5;
         */
        value: StringMembershipCondition;
        case: "stringMembership";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.Sha256MembershipCondition sha256_membership = 6;
         */
        value: Sha256MembershipCondition;
        case: "sha256Membership";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.AttributePresenceCondition attribute_presence = 7;
         */
        value: AttributePresenceCondition;
        case: "attributePresence";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.VersionCondition version = 8;
         */
        value: VersionCondition;
        case: "version";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.StringComparisonCondition string_comparison = 9;
         */
        value: StringComparisonCondition;
        case: "stringComparison";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.Sha256StringComparisonCondition sha256_string_comparison = 10;
         */
        value: Sha256StringComparisonCondition;
        case: "sha256StringComparison";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Condition.
 * Use `create(ConditionSchema)` to create a new message.
 */
export declare const ConditionSchema: GenMessage<Condition>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.ConditionOperands
 */
export type ConditionOperands = Message<"datadog.ffe.flagging.ufc.v1.ConditionOperands"> & {
    /**
     * Zero-based indexes into FlagsConfiguration.conditions.
     *
     * @generated from field: repeated uint32 condition_indexes = 1;
     */
    conditionIndexes: number[];
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.ConditionOperands.
 * Use `create(ConditionOperandsSchema)` to create a new message.
 */
export declare const ConditionOperandsSchema: GenMessage<ConditionOperands>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.NumericCondition
 */
export type NumericCondition = Message<"datadog.ffe.flagging.ufc.v1.NumericCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * @generated from field: datadog.ffe.flagging.ufc.v1.NumericComparator comparator = 2;
     */
    comparator: NumericComparator;
    /**
     * @generated from field: double comparand = 3;
     */
    comparand: number;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.NumericCondition.
 * Use `create(NumericConditionSchema)` to create a new message.
 */
export declare const NumericConditionSchema: GenMessage<NumericCondition>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.RegexCondition
 */
export type RegexCondition = Message<"datadog.ffe.flagging.ufc.v1.RegexCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * Index into FlagsConfiguration.regexes.
     *
     * @generated from field: uint32 regex_index = 2;
     */
    regexIndex: number;
    /**
     * True negates the regex match.
     *
     * @generated from field: bool negate = 3;
     */
    negate: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.RegexCondition.
 * Use `create(RegexConditionSchema)` to create a new message.
 */
export declare const RegexConditionSchema: GenMessage<RegexCondition>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.StringMembershipCondition
 */
export type StringMembershipCondition = Message<"datadog.ffe.flagging.ufc.v1.StringMembershipCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * Indices into FlagsConfiguration.strings. Sorted by referenced value.
     *
     * @generated from field: repeated uint32 string_indexes = 2;
     */
    stringIndexes: number[];
    /**
     * True negates membership.
     *
     * @generated from field: bool negate = 3;
     */
    negate: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.StringMembershipCondition.
 * Use `create(StringMembershipConditionSchema)` to create a new message.
 */
export declare const StringMembershipConditionSchema: GenMessage<StringMembershipCondition>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.StringComparisonCondition
 */
export type StringComparisonCondition = Message<"datadog.ffe.flagging.ufc.v1.StringComparisonCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * @generated from field: datadog.ffe.flagging.ufc.v1.StringComparator comparator = 2;
     */
    comparator: StringComparator;
    /**
     * Index into FlagsConfiguration.strings.
     *
     * @generated from field: uint32 string_index = 3;
     */
    stringIndex: number;
    /**
     * True negates the comparator.
     *
     * @generated from field: bool negate = 4;
     */
    negate: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.StringComparisonCondition.
 * Use `create(StringComparisonConditionSchema)` to create a new message.
 */
export declare const StringComparisonConditionSchema: GenMessage<StringComparisonCondition>;
/**
 * Compares a prefix or suffix without exposing its plaintext value. For
 * non-string attributes, SDKs must first apply the same conversion used by
 * StringMembershipCondition. SDKs must then encode the resulting string as
 * UTF-8 exactly as provided, without Unicode normalization or case folding.
 * length is measured in UTF-8 bytes. The byte
 * boundary at length (starts-with) or len(attribute)-length (ends-with) must be
 * a Unicode code point boundary; otherwise the condition is false. This avoids
 * hashing malformed partial code points, especially when extracting a suffix.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.Sha256StringComparisonCondition
 */
export type Sha256StringComparisonCondition = Message<"datadog.ffe.flagging.ufc.v1.Sha256StringComparisonCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * @generated from field: bytes salt = 2;
     */
    salt: Uint8Array;
    /**
     * @generated from field: datadog.ffe.flagging.ufc.v1.Sha256StringComparator comparator = 3;
     */
    comparator: Sha256StringComparator;
    /**
     * Number of UTF-8 bytes to extract from the start or end. If the attribute
     * has fewer bytes, or extraction would split a code point, the condition is
     * false.
     *
     * @generated from field: uint32 length = 4;
     */
    length: number;
    /**
     * Expected SHA-256(salt || extracted UTF-8 bytes), as raw digest bytes.
     *
     * @generated from field: bytes sha256 = 5;
     */
    sha256: Uint8Array;
    /**
     * True negates the comparator.
     *
     * @generated from field: bool negate = 6;
     */
    negate: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Sha256StringComparisonCondition.
 * Use `create(Sha256StringComparisonConditionSchema)` to create a new message.
 */
export declare const Sha256StringComparisonConditionSchema: GenMessage<Sha256StringComparisonCondition>;
/**
 * True when SHA-256(salt || attribute_value) matches one of sha256 values.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.Sha256MembershipCondition
 */
export type Sha256MembershipCondition = Message<"datadog.ffe.flagging.ufc.v1.Sha256MembershipCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * @generated from field: bytes salt = 2;
     */
    salt: Uint8Array;
    /**
     * Sorted lexicographically as raw bytes.
     *
     * @generated from field: repeated bytes sha256 = 3;
     */
    sha256: Uint8Array[];
    /**
     * True negates membership.
     *
     * @generated from field: bool negate = 4;
     */
    negate: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Sha256MembershipCondition.
 * Use `create(Sha256MembershipConditionSchema)` to create a new message.
 */
export declare const Sha256MembershipConditionSchema: GenMessage<Sha256MembershipCondition>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.AttributePresenceCondition
 */
export type AttributePresenceCondition = Message<"datadog.ffe.flagging.ufc.v1.AttributePresenceCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * True checks that the attribute is null/absent (is_null); false checks
     * that it is present/not-null (is_not_null).
     *
     * @generated from field: bool expect_null = 2;
     */
    expectNull: boolean;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.AttributePresenceCondition.
 * Use `create(AttributePresenceConditionSchema)` to create a new message.
 */
export declare const AttributePresenceConditionSchema: GenMessage<AttributePresenceCondition>;
/**
 * @generated from message datadog.ffe.flagging.ufc.v1.VersionCondition
 */
export type VersionCondition = Message<"datadog.ffe.flagging.ufc.v1.VersionCondition"> & {
    /**
     * @generated from field: uint32 attribute_index = 1;
     */
    attributeIndex: number;
    /**
     * @generated from field: datadog.ffe.flagging.ufc.v1.VersionComparator comparator = 2;
     */
    comparator: VersionComparator;
    /**
     * Index into FlagsConfiguration.versions.
     *
     * @generated from field: uint32 version_index = 3;
     */
    versionIndex: number;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.VersionCondition.
 * Use `create(VersionConditionSchema)` to create a new message.
 */
export declare const VersionConditionSchema: GenMessage<VersionCondition>;
/**
 * PartitionKey computes one coordinate of the composite key used to select a
 * split. Partition keys are evaluated in declaration order.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.PartitionKey
 */
export type PartitionKey = Message<"datadog.ffe.flagging.ufc.v1.PartitionKey"> & {
    /**
     * @generated from oneof datadog.ffe.flagging.ufc.v1.PartitionKey.kind
     */
    kind: {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.TimePartitionKey time = 1;
         */
        value: TimePartitionKey;
        case: "time";
    } | {
        /**
         * @generated from field: datadog.ffe.flagging.ufc.v1.Md5ShardPartitionKey shard_md5 = 2;
         */
        value: Md5ShardPartitionKey;
        case: "shardMd5";
    } | {
        case: undefined;
        value?: undefined;
    };
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.PartitionKey.
 * Use `create(PartitionKeySchema)` to create a new message.
 */
export declare const PartitionKeySchema: GenMessage<PartitionKey>;
/**
 * Time is the current Unix timestamp in milliseconds.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.TimePartitionKey
 */
export type TimePartitionKey = Message<"datadog.ffe.flagging.ufc.v1.TimePartitionKey"> & {};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.TimePartitionKey.
 * Use `create(TimePartitionKeySchema)` to create a new message.
 */
export declare const TimePartitionKeySchema: GenMessage<TimePartitionKey>;
/**
 * Partition value is computed as follows:
 * uint32_be(md5(salt || attribute_value)[0:4]) % total_shards
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.Md5ShardPartitionKey
 */
export type Md5ShardPartitionKey = Message<"datadog.ffe.flagging.ufc.v1.Md5ShardPartitionKey"> & {
    /**
     * Includes any separator between the salt and the hashed value; callers
     * must concatenate salt and attribute_value directly, with no implicit
     * separator of their own.
     *
     * @generated from field: string salt = 1;
     */
    salt: string;
    /**
     * Index into FlagsConfiguration.attributes.
     *
     * @generated from field: uint32 attribute_index = 2;
     */
    attributeIndex: number;
    /**
     * @generated from field: uint64 total_shards = 3;
     */
    totalShards: bigint;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Md5ShardPartitionKey.
 * Use `create(Md5ShardPartitionKeySchema)` to create a new message.
 */
export declare const Md5ShardPartitionKeySchema: GenMessage<Md5ShardPartitionKey>;
/**
 * Split.ranges is a Cartesian-product range over Allocation.partition_key.
 * ranges[i] applies to partition_key[i], and must have the same cardinality.
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.Split
 */
export type Split = Message<"datadog.ffe.flagging.ufc.v1.Split"> & {
    /**
     * Has the same number of elements as the partition key.
     *
     * @generated from field: repeated datadog.ffe.flagging.ufc.v1.PartitionRange ranges = 1;
     */
    ranges: PartitionRange[];
    /**
     * @generated from field: uint32 variation_index = 2;
     */
    variationIndex: number;
    /**
     * @generated from field: optional int32 serial_id = 3;
     */
    serialId?: number | undefined;
    /**
     * @generated from field: datadog.ffe.flagging.ufc.v1.Reason reason = 4;
     */
    reason: Reason;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.Split.
 * Use `create(SplitSchema)` to create a new message.
 */
export declare const SplitSchema: GenMessage<Split>;
/**
 * A half-open range: from <= partition coordinate < to. Time coordinates are
 * Unix milliseconds; shard coordinates are in [0, total_shards).
 *
 * @generated from message datadog.ffe.flagging.ufc.v1.PartitionRange
 */
export type PartitionRange = Message<"datadog.ffe.flagging.ufc.v1.PartitionRange"> & {
    /**
     * @generated from field: optional uint64 from = 1;
     */
    from?: bigint | undefined;
    /**
     * @generated from field: optional uint64 to = 2;
     */
    to?: bigint | undefined;
};
/**
 * Describes the message datadog.ffe.flagging.ufc.v1.PartitionRange.
 * Use `create(PartitionRangeSchema)` to create a new message.
 */
export declare const PartitionRangeSchema: GenMessage<PartitionRange>;
/**
 * @generated from enum datadog.ffe.flagging.ufc.v1.VariationType
 */
export declare enum VariationType {
    /**
     * @generated from enum value: VARIATION_TYPE_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: VARIATION_TYPE_STRING = 1;
     */
    STRING = 1,
    /**
     * @generated from enum value: VARIATION_TYPE_INTEGER = 2;
     */
    INTEGER = 2,
    /**
     * @generated from enum value: VARIATION_TYPE_NUMERIC = 3;
     */
    NUMERIC = 3,
    /**
     * @generated from enum value: VARIATION_TYPE_BOOLEAN = 4;
     */
    BOOLEAN = 4,
    /**
     * @generated from enum value: VARIATION_TYPE_JSON = 5;
     */
    JSON = 5
}
/**
 * Describes the enum datadog.ffe.flagging.ufc.v1.VariationType.
 */
export declare const VariationTypeSchema: GenEnum<VariationType>;
/**
 * @generated from enum datadog.ffe.flagging.ufc.v1.NumericComparator
 */
export declare enum NumericComparator {
    /**
     * @generated from enum value: NUMERIC_COMPARATOR_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: NUMERIC_COMPARATOR_LESS_THAN = 1;
     */
    LESS_THAN = 1,
    /**
     * @generated from enum value: NUMERIC_COMPARATOR_LESS_THAN_OR_EQUAL = 2;
     */
    LESS_THAN_OR_EQUAL = 2,
    /**
     * @generated from enum value: NUMERIC_COMPARATOR_GREATER_THAN = 3;
     */
    GREATER_THAN = 3,
    /**
     * @generated from enum value: NUMERIC_COMPARATOR_GREATER_THAN_OR_EQUAL = 4;
     */
    GREATER_THAN_OR_EQUAL = 4
}
/**
 * Describes the enum datadog.ffe.flagging.ufc.v1.NumericComparator.
 */
export declare const NumericComparatorSchema: GenEnum<NumericComparator>;
/**
 * @generated from enum datadog.ffe.flagging.ufc.v1.StringComparator
 */
export declare enum StringComparator {
    /**
     * @generated from enum value: STRING_COMPARATOR_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: STRING_COMPARATOR_STARTS_WITH = 1;
     */
    STARTS_WITH = 1,
    /**
     * @generated from enum value: STRING_COMPARATOR_ENDS_WITH = 2;
     */
    ENDS_WITH = 2,
    /**
     * @generated from enum value: STRING_COMPARATOR_CONTAINS = 3;
     */
    CONTAINS = 3
}
/**
 * Describes the enum datadog.ffe.flagging.ufc.v1.StringComparator.
 */
export declare const StringComparatorSchema: GenEnum<StringComparator>;
/**
 * @generated from enum datadog.ffe.flagging.ufc.v1.Sha256StringComparator
 */
export declare enum Sha256StringComparator {
    /**
     * @generated from enum value: SHA256_STRING_COMPARATOR_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: SHA256_STRING_COMPARATOR_STARTS_WITH = 1;
     */
    STARTS_WITH = 1,
    /**
     * @generated from enum value: SHA256_STRING_COMPARATOR_ENDS_WITH = 2;
     */
    ENDS_WITH = 2
}
/**
 * Describes the enum datadog.ffe.flagging.ufc.v1.Sha256StringComparator.
 */
export declare const Sha256StringComparatorSchema: GenEnum<Sha256StringComparator>;
/**
 * @generated from enum datadog.ffe.flagging.ufc.v1.VersionComparator
 */
export declare enum VersionComparator {
    /**
     * @generated from enum value: VERSION_COMPARATOR_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: VERSION_COMPARATOR_EQUAL = 1;
     */
    EQUAL = 1,
    /**
     * @generated from enum value: VERSION_COMPARATOR_NOT_EQUAL = 2;
     */
    NOT_EQUAL = 2,
    /**
     * @generated from enum value: VERSION_COMPARATOR_LESS_THAN = 3;
     */
    LESS_THAN = 3,
    /**
     * @generated from enum value: VERSION_COMPARATOR_LESS_THAN_OR_EQUAL = 4;
     */
    LESS_THAN_OR_EQUAL = 4,
    /**
     * @generated from enum value: VERSION_COMPARATOR_GREATER_THAN = 5;
     */
    GREATER_THAN = 5,
    /**
     * @generated from enum value: VERSION_COMPARATOR_GREATER_THAN_OR_EQUAL = 6;
     */
    GREATER_THAN_OR_EQUAL = 6
}
/**
 * Describes the enum datadog.ffe.flagging.ufc.v1.VersionComparator.
 */
export declare const VersionComparatorSchema: GenEnum<VersionComparator>;
/**
 * @generated from enum datadog.ffe.flagging.ufc.v1.Reason
 */
export declare enum Reason {
    /**
     * @generated from enum value: REASON_UNSPECIFIED = 0;
     */
    UNSPECIFIED = 0,
    /**
     * @generated from enum value: REASON_TARGETING_MATCH = 1;
     */
    TARGETING_MATCH = 1,
    /**
     * @generated from enum value: REASON_SPLIT = 2;
     */
    SPLIT = 2,
    /**
     * @generated from enum value: REASON_STATIC = 3;
     */
    STATIC = 3,
    /**
     * @generated from enum value: REASON_DEFAULT = 4;
     */
    DEFAULT = 4
}
/**
 * Describes the enum datadog.ffe.flagging.ufc.v1.Reason.
 */
export declare const ReasonSchema: GenEnum<Reason>;
//# sourceMappingURL=ufc_pb.d.ts.map