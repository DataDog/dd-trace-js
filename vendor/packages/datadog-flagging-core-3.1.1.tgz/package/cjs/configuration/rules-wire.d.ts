import type { FlagsConfiguration } from './configuration';
import { type ConfigurationWireContents, type FlagsConfigurationWire } from './wire-types';
/**
 * Parse the rules entry from an opaque flags configuration wire value.
 */
export declare function configurationFromRulesString(wire: FlagsConfigurationWire): FlagsConfiguration;
/**
 * Decode a binary flags configuration response.
 */
export declare function configurationFromRulesBinary(response: Uint8Array): FlagsConfiguration;
export declare function rulesConfigurationFromWire(serialized: ConfigurationWireContents): FlagsConfiguration;
//# sourceMappingURL=rules-wire.d.ts.map