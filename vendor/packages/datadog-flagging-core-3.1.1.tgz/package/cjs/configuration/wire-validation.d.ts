import type { EvaluationContext } from '@openfeature/core';
import type { PrecomputedConfigurationResponse } from './configuration';
type WireEntry = {
    response: string;
    fetchedAt?: number;
    etag?: string;
};
export type PrecomputedWireEntry = WireEntry & {
    context?: EvaluationContext;
};
export declare function isWireEntry(value: unknown): value is WireEntry;
export declare function isPrecomputedWireEntry(value: unknown): value is PrecomputedWireEntry;
/** @internal */
export declare function parsePrecomputedConfigurationResponse(value: unknown): {
    response: PrecomputedConfigurationResponse;
    flagErrors?: Record<string, string>;
} | {
    error: string;
};
export {};
//# sourceMappingURL=wire-validation.d.ts.map