import './protobuf-text-encoding';
import { type FlagsConfiguration } from './generated/ufc_pb';
import { type PreparedRulesResponse } from './prepared-rules-response';
export declare function decodeFlagsConfiguration(response: Uint8Array): PreparedRulesResponse;
export declare function encodeFlagsConfiguration(configuration: FlagsConfiguration): Uint8Array;
//# sourceMappingURL=ufc-protobuf.d.ts.map