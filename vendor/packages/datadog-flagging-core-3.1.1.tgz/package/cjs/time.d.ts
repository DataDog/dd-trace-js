/** Unix epoch timestamp in milliseconds. */
export type TimeStamp = number & {
    t: 'Epoch time';
};
export declare function timeStampNow(): TimeStamp;
//# sourceMappingURL=time.d.ts.map