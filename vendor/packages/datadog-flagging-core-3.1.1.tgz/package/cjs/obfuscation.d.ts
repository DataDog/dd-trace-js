export declare function getMD5Hash(input: string, salt?: string): string;
/**
 * Builds a storage key suffix from an API key.
 * @param apiKey - The API key to build the suffix from
 * @returns A string suffix for storage keys
 * @public
 */
export declare function buildStorageKeySuffix(apiKey: string): string;
//# sourceMappingURL=obfuscation.d.ts.map