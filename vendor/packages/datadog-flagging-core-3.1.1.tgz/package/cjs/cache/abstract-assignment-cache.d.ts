import type { ExposureEvent } from '../configuration';
export type AssignmentCacheKey = Pick<ExposureEvent, 'flag' | 'subject'>;
export type AssignmentCacheEntry = ExposureEvent;
/** Converts an {@link AssignmentCacheKey} to a string. */
export declare function assignmentCacheKeyToString(exposureEvent: AssignmentCacheKey | ExposureEvent): string;
/** Converts an {@link AssignmentCacheValue} to a string. */
export declare function assignmentCacheValueToString(cacheValue: AssignmentCacheEntry): string;
export interface AsyncMap<K, V> {
    get(key: K): Promise<V | undefined>;
    set(key: K, value: V): Promise<void>;
    has(key: K): Promise<boolean>;
}
export interface AssignmentCache {
    init(): Promise<void>;
    set(key: AssignmentCacheEntry): void;
    has(key: AssignmentCacheEntry): boolean;
    clear(): Promise<void> | void;
}
/**
 * Minimal interface for the backing store used by {@link AbstractAssignmentCache}.
 *
 * Using a narrower constraint instead of `Map<string, string>` avoids emitting
 * `MapIterator` (introduced in TypeScript 5.6) in declaration files, which would
 * break consumers on TypeScript < 5.6.
 */
export interface CacheDelegate {
    get(key: string): string | undefined;
    set(key: string, value: string): this;
    has(key: string): boolean;
    clear(): void;
    entries(): IterableIterator<[string, string]>;
}
export declare abstract class AbstractAssignmentCache<T extends CacheDelegate> implements AssignmentCache {
    protected readonly delegate: T;
    protected constructor(delegate: T);
    init(): Promise<void>;
    /** Returns whether the provided {@link AssignmentCacheEntry} is present in the cache. */
    has(entry: AssignmentCacheEntry): boolean;
    get(key: AssignmentCacheKey): string | undefined;
    /**
     * Stores the provided {@link AssignmentCacheEntry} in the cache. If the key already exists, it
     * will be overwritten.
     */
    set(entry: AssignmentCacheEntry): void;
    /**
     * Returns an array with all {@link AssignmentCacheEntry} entries in the cache as an array of
     * {@link string}s.
     */
    entries(): IterableIterator<[string, string]>;
    /** Clears all entries from the cache. */
    clear(): void;
}
//# sourceMappingURL=abstract-assignment-cache.d.ts.map