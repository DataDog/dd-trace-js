/**
 * LRUCache is a simple implementation of a Least Recently Used (LRU) cache.
 *
 * Old items are evicted when the cache reaches its capacity.
 *
 * The cache is implemented as a Map, which maintains insertion order:
 * ```
 * Iteration happens in insertion order, which corresponds to the order in which each key-value pair
 * was first inserted into the map by the set() method (that is, there wasn't a key with the same
 * value already in the map when set() was called).
 * ```
 * Source: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map
 */
export declare class LRUCache {
    protected readonly capacity: number;
    protected readonly cache: Map<string, string>;
    constructor(capacity: number);
    entries(): IterableIterator<[string, string]>;
    clear(): void;
    delete(key: string): boolean;
    keys(): IterableIterator<string>;
    values(): IterableIterator<string>;
    has(key: string): boolean;
    get(key: string): string | undefined;
    set(key: string, value: string): this;
}
//# sourceMappingURL=lru-cache.d.ts.map