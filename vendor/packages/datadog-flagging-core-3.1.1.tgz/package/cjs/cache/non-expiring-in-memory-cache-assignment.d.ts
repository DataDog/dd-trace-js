import { AbstractAssignmentCache } from './abstract-assignment-cache';
/**
 * A cache that never expires.
 *
 * The primary use case is for client-side SDKs, where the cache is only used
 * for a single user.
 */
export declare class NonExpiringInMemoryAssignmentCache extends AbstractAssignmentCache<Map<string, string>> {
    constructor(store?: Map<string, string>);
}
//# sourceMappingURL=non-expiring-in-memory-cache-assignment.d.ts.map