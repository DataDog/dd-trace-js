import type { Channel } from 'node:diagnostics_channel';
import { type ExposureEvent } from '@datadog/flagging-core';
import type { EvaluationContext, ServerProviderEvents } from '@openfeature/core';
import type { EvaluationDetails, FlagValue, Hook, JsonValue, Logger, Paradigm, Provider, ProviderEventEmitter, ProviderMetadata, ResolutionDetails } from '@openfeature/server-sdk';
import type { UniversalFlagConfigurationV1 } from './configuration/ufc-v1';
export interface DatadogNodeServerProviderOptions {
    /**
     * Log experiment exposures
     */
    exposureChannel: Channel<ExposureEvent>;
    /**
     * Report prerequisite evaluations, including errors propagated through dependency ancestors.
     */
    dependencyEvaluationChannel?: Channel<DependencyEvaluationEvent>;
    /**
     * Timeout in milliseconds for provider initialization.
     * If the configuration is not set within this time, initialization will fail.
     * @default DEFAULT_INITIALIZATION_TIMEOUT_MS (30000ms / 30 seconds)
     */
    initializationTimeoutMs?: number;
}
export type DependencyEvaluationEvent = {
    context: EvaluationContext;
    details: EvaluationDetails<FlagValue>;
};
export declare class DatadogNodeServerProvider implements Provider {
    private readonly options;
    readonly metadata: ProviderMetadata;
    readonly runsOn: Paradigm;
    readonly hooks?: Hook[];
    private initController?;
    readonly events: ProviderEventEmitter<ServerProviderEvents>;
    private readonly exposureCache;
    private configuration?;
    constructor(options: DatadogNodeServerProviderOptions);
    /**
     * Used by dd-source-js
     */
    getConfiguration(): UniversalFlagConfigurationV1 | undefined;
    /**
     * Used by dd-source-js
     */
    setConfiguration(configuration: UniversalFlagConfigurationV1): void;
    /**
     * Used by dd-source-js
     */
    setError(error: unknown): void;
    /**
     * Used by the OpenFeature SDK to set the status based on initialization.
     * Status of 'PROVIDER_READY' is emitted with a resolved promise.
     * Status of 'PROVIDER_ERROR' is emitted with a rejected promise.
     *
     * Since we aren't loading the configuration in this Provider, we will simulate
     * loading functionality via InitializationController.
     * See setConfiguration and setError for more details.
     */
    initialize(): Promise<void>;
    resolveBooleanEvaluation(flagKey: string, defaultValue: boolean, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<boolean>>;
    resolveStringEvaluation(flagKey: string, defaultValue: string, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<string>>;
    resolveNumberEvaluation(flagKey: string, defaultValue: number, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<number>>;
    resolveObjectEvaluation<T extends JsonValue>(flagKey: string, defaultValue: T, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<T>>;
    private handleDependencyEvaluation;
    private handleDependencyExposures;
    private handleExposure;
}
//# sourceMappingURL=provider.d.ts.map