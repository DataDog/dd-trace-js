export { matchesShard } from '@datadog/flagging-core';
//# sourceMappingURL=matchesShard.d.ts.map