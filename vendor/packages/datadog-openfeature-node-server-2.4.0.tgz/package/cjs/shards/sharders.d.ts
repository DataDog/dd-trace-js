export { DeterministicSharder, MD5Sharder, Sharder } from '@datadog/flagging-core';
//# sourceMappingURL=sharders.d.ts.map