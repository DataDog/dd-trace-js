export type { UniversalFlagConfigurationV1 } from './configuration/ufc-v1';
export * from './provider';
//# sourceMappingURL=index.d.ts.map