import type { AnyProviderEvent, EventContext, EventHandler, Logger, ProviderEventEmitter, ServerProviderEvents } from '@openfeature/core';
/**
 * OpenFeature-compatible event emitter that does not require an OpenFeature SDK at runtime.
 */
export declare class NodeProviderEventEmitter implements ProviderEventEmitter<ServerProviderEvents> {
    private readonly eventEmitter;
    private readonly handlers;
    private logger?;
    emit(eventType: ServerProviderEvents, context?: EventContext): void;
    addHandler(eventType: AnyProviderEvent, handler: EventHandler): void;
    removeHandler(eventType: AnyProviderEvent, handler: EventHandler): void;
    removeAllHandlers(eventType?: AnyProviderEvent): void;
    getHandlers(eventType: AnyProviderEvent): EventHandler[];
    setLogger(logger: Logger): this;
    private logHandlerError;
}
//# sourceMappingURL=provider-event-emitter.d.ts.map