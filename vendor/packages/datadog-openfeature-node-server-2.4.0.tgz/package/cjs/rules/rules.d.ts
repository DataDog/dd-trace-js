export type { Condition, ConditionValueType, Rule } from '@datadog/flagging-core';
export { matchesRule, OperatorType } from '@datadog/flagging-core';
//# sourceMappingURL=rules.d.ts.map