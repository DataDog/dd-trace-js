/**
 * Manages deferred initialization with timeout support.
 * Encapsulates the pattern of waiting for external resolution/rejection
 * with automatic timeout handling and cleanup.
 */
export declare class InitializationController {
    private resolve?;
    private reject?;
    private timeoutId?;
    private readonly promise;
    constructor(timeoutMs: number, onTimeout: () => void);
    /**
     * Wait for initialization to complete (or timeout)
     */
    wait(): Promise<void>;
    /**
     * Complete initialization successfully
     */
    complete(): void;
    /**
     * Fail initialization with an error
     */
    fail(error: unknown): void;
    /**
     * Check if initialization is still in progress
     */
    isInitializing(): boolean;
    private cleanup;
}
//# sourceMappingURL=initialization-controller.d.ts.map