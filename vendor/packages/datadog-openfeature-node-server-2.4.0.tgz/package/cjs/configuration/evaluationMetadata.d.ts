export { createEvaluationTimestampMetadata } from '@datadog/flagging-core';
//# sourceMappingURL=evaluationMetadata.d.ts.map