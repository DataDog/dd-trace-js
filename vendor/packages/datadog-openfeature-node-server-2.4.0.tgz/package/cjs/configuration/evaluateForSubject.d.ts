export { containsMatchingRule, evaluateForSubject } from '@datadog/flagging-core';
//# sourceMappingURL=evaluateForSubject.d.ts.map