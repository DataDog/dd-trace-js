export type { Allocation, Flag, Shard, ShardRange, Split, UniversalFlagConfigurationV1, UniversalFlagConfigurationV1Response, VariantConfiguration, VariantType, } from '@datadog/flagging-core';
export { variantTypeToFlagValueType } from '@datadog/flagging-core';
//# sourceMappingURL=ufc-v1.d.ts.map