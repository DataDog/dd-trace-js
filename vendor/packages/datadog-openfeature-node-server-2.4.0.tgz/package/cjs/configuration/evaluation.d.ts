export { evaluateRulesBasedConfiguration as evaluate } from '@datadog/flagging-core';
//# sourceMappingURL=evaluation.d.ts.map