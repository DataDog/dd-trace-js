# Datadog OpenFeature Core Library

## Configuration parsing entry points

The default `@datadog/flagging-core` entry point parses precomputed configuration without
loading the protobuf decoder. To parse both precomputed and rules-based configuration,
opt into the full parser:

```ts
import { configurationFromString, configurationToString } from '@datadog/flagging-core/rules-based'
```

The `/rules-based` entry point is available through both the package's `exports` map and a
physical `rules-based/package.json` for resolvers that do not support package exports:

- Modern resolvers use the existing modular CommonJS/ESM implementations.
- Legacy resolvers use self-contained CommonJS/ESM compatibility bundles generated from the
  same source during `yarn build` / package preparation. These include the required protobuf
  code, so consumers do not have to resolve its `/wire` or `/codegenv2` subpaths.
- Both paths expose the same API and reuse the same TypeScript declarations. The default
  entry point stays modular and does not import the compatibility bundles or protobuf decoder.

The compatibility bundles increase the npm package size, but only applications using the
legacy rules-based entry point include them in their application bundle. They retain dependency
copyright/license notices and source maps, and are left unminified for the application bundler
to optimize.

The packed-package smoke test covers Android and iOS bundles with Metro package exports both
enabled and disabled, including legacy CommonJS and ESM resolution. It executes those bundles
in Node without `BigInt`, `TextEncoder`, or `TextDecoder`; this checks fallback behavior but does
not replace execution tests on an actual Hermes or JavaScriptCore runtime.

## Local Precomputation

The `/rules-based` entry point exports `precomputeConfiguration(configuration, context, options?)` alongside the parsers and serializer. It resolves rules for one context into a precomputed-only configuration without network calls, provider initialization, or tracking. The Node package wraps this helper and adds `clientFingerprint` support for encoding flag-map keys; the core helper continues to return plaintext assignments. See its [local precomputation guide](../node-server/README.md#local-precomputation) for input validation, omission diagnostics, opt-out policy, and SSR safety constraints.

The helper follows the Rust assignment-only precomputation contract: successful assignments are included, no-assignment outcomes and individual errors are omitted, and no application defaults are fabricated. Typed single-flag evaluation and precomputation share the protobuf assignment resolver. The JSON scalar/null cases in the helper's tests mirror `precomputed_object_variation_preserves_scalar_json_values` in the Rust evaluator's `rules_based/precomputed.rs` tests.

Pass `options.flagSelection: { keyPatterns: ['checkout-*'] }` to include only matching assignments. Patterns are
case-sensitive whole-key globs with only `*` special and use the shared selection normalization and limits. Omitted
selections and selections with no nonempty `keyPatterns` include all assignments; a `null` selection is also treated
as absent at runtime. Tags are unsupported because rules contain no tag metadata: any defined `tags` value, including
`[]` or `null`, throws `ConfigurationPrecomputeError` with `invalid_options`, as do malformed selections and selections
over a limit. Source rules remain available for dependencies and can be reused for other selections.

## Preparing activation timestamps

Rules configurations are snapshots. The protobuf decoder prepares randomization activation
timestamps once, and the Node provider prepares JSON configurations in `setConfiguration`.
Invalid activation marks only the affected flag as a parse error, regardless of opt-out mode.
Evaluation compares the prepared seconds and fractional seconds without reparsing the timestamp;
using a JavaScript `Date` here would lose the nanosecond precision needed at the opt-out cutoff.

Direct JSON core consumers can call `prepareUniversalFlagConfiguration(configuration)` when
receiving configuration. Existing low-level evaluation calls still accept raw configurations
and prepare each flag once on first use. Replace changed flags instead of mutating prepared
flags in place. Preparation does not change the serialized configuration.

## Adding a public entry point

`packages/core/package.json` **`exports` is the single source of truth** for public paths.
To add `@datadog/flagging-core/foo`:

1. Create `src/foo.ts` with the intended exports. Keep any required initialization in this
   source entry point, rather than adding it to a bundler-specific list.
2. Add its modern mapping to `exports`:

   ```json
   {
     "./foo": {
       "types": "./cjs/foo.d.ts",
       "import": "./esm/foo.js",
       "require": "./cjs/foo.js",
       "default": "./esm/foo.js"
     }
   }
   ```

3. Run `yarn workspace @datadog/flagging-core build` and commit the generated metadata with
   the source change. Add the feature's behavior tests as usual.

The build generates the physical fallback manifests, publish-file list, legacy declaration
mappings, and compatibility-bundle side-effect entries. It discovers and builds a CJS/ESM
compatibility bundle for every public JavaScript subpath automatically. Do not edit those
fallback manifests or register new paths in the Webpack configuration or smoke fixtures.

Concrete nested subpaths are supported; wildcard exports and mismatched CJS/ESM/type targets
fail with an actionable error. Removing a path from `exports` and rebuilding removes its
owned fallback manifest and derived metadata without deleting unrelated files.

`yarn check:entrypoints` checks generated metadata without changing files. CI runs it before
building, and `prepack` checks it before packing so a stale publish-file list cannot silently
omit a new entry point. The packed-package tests discover every declared path and generate
static imports for the full Metro matrix. The default entry point remains separate and light.

## End-user license agreement

https://www.datadoghq.com/legal/eula
