import type { ErrorCode, EvaluationContext, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import type { FlagTypeToValue, PrecomputedFlag } from '../configuration';
import type { VariationType } from '../configuration/generated/ufc_pb';
import type { PreparedRulesResponse } from '../configuration/prepared-rules-response';
import { type TimeStamp } from '../time';
import { type ExperimentationOptOutPolicy } from './experimentation-opt-out';
import type { DependencyExposureTransaction } from './rules';
export type ResolveProtobufFlagEvaluation = ((flagKey: string) => string | undefined) & DependencyExposureTransaction;
export declare function evaluateProtobufConfiguration<T extends FlagValueType>(configuration: PreparedRulesResponse, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger: Logger, evaluationTimestampMs?: TimeStamp, excludeExperiments?: ExperimentationOptOutPolicy | boolean, resolveFlagEvaluation?: ResolveProtobufFlagEvaluation): ResolutionDetails<FlagTypeToValue<T>>;
type RulesAssignmentResult = {
    kind: 'assignment';
    assignment: PrecomputedFlag;
} | {
    kind: 'unassigned';
} | {
    kind: 'error';
    errorCode: ErrorCode;
    errorMessage?: string;
};
/** Resolve an assignment without substituting an application's code default. */
export declare function resolveProtobufAssignment(configuration: PreparedRulesResponse, flagKey: string, context: EvaluationContext, logger: Logger, evaluationTimestampMs: TimeStamp, excludeExperiments?: ExperimentationOptOutPolicy | boolean, expectedType?: FlagValueType, resolveFlagEvaluation?: ResolveProtobufFlagEvaluation): RulesAssignmentResult;
export declare function protobufVariationTypeToFlagValueType(variationType: VariationType): FlagValueType;
export {};
//# sourceMappingURL=evaluateProtobufConfiguration.d.ts.map