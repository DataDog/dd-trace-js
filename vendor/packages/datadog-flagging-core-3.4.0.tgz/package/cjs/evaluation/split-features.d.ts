import type { FlagMetadata, Logger } from '@openfeature/core';
export declare const FEATURE_DESTINATION_HOOK = "HOOK";
export declare const FEATURE_DESTINATION_EXPOSURE = "EXPOSURE";
export declare const FEATURE_DESTINATION_EVALUATION = "EVALUATION";
/**
 * Flag-metadata prefixes, one per destination. Only `__dd_feature.` is a public
 * contract; the other two carry features to the SDK's own exposure and
 * flag-evaluation paths.
 */
export declare const METADATA_FEATURE_PREFIX = "__dd_feature.";
export declare const METADATA_EXPOSURE_FEATURE_PREFIX = "__dd_exposure_feature.";
export declare const METADATA_EVALUATION_FEATURE_PREFIX = "__dd_evaluation_feature.";
/**
 * Present only when the selected split routes a feature to EVALUATION, so
 * evaluation-count consumers can skip scanning the metadata otherwise.
 */
export declare const HAS_EVALUATION_FEATURES_METADATA_KEY = "__dd_has_evaluation_features";
export type FeatureValue = string | number | boolean;
export interface SplitFeatureMetadata {
    /** Metadata entries, `prefix + key` to the feature value. */
    entries: Record<string, FeatureValue>;
    hasEvaluationFeatures: boolean;
}
/**
 * Turn the selected split's `features` into flag-metadata entries, one per
 * (feature, destination). Parsing is lenient: a missing or malformed `features`
 * field yields no entries and never fails the flag, and a feature with an
 * unsupported value type is skipped. On a repeated key the first valid feature
 * wins for every destination.
 */
export declare function createSplitFeatureMetadata(features: unknown, logger: Logger): SplitFeatureMetadata;
/**
 * Read the features stored in flag metadata under `prefix`, keyed without the
 * prefix. Returns undefined when there are none, so callers can omit the field.
 */
export declare function featuresWithPrefix(metadata: FlagMetadata | undefined, prefix: string): Record<string, FeatureValue> | undefined;
//# sourceMappingURL=split-features.d.ts.map