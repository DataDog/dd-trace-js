import type { EvaluationContext, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import { type FlagsConfiguration, type FlagTypeToValue } from '../configuration';
import { type ExperimentationOptOutOption } from './experimentation-opt-out';
export declare function evaluatePrecomputedConfiguration<T extends FlagValueType>(flagsConfiguration: FlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, experimentationOptOutMode?: ExperimentationOptOutOption, logger?: Logger): ResolutionDetails<FlagTypeToValue<T>>;
//# sourceMappingURL=precomputed-evaluation.d.ts.map