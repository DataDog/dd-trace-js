/** Optional local diagnostics, separate from the application's operational logger. */
export type EvaluationDiagnostics = (message: string, details: unknown) => void;
/** Diagnostic observers must not change evaluation results or exceptions. */
export declare function traceEvaluation(observer: EvaluationDiagnostics | undefined, message: string, details: () => unknown): void;
//# sourceMappingURL=diagnostics.d.ts.map