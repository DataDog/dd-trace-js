import type { EvaluationDetails, FlagMetadata, FlagValue } from '@openfeature/core';
import type { PrecomputedDependencyEvaluation, PrecomputedFlag } from '../configuration';
export type PrecomputedDependencyEvaluationDetails = Omit<EvaluationDetails<FlagValue>, 'value'> & {
    value?: FlagValue;
    /** Successful dependencies only; errors are reached-evaluation telemetry. */
    isPresentInAssignment?: boolean;
};
export declare function bindPrecomputedDependencyEvaluations(metadata: FlagMetadata, dependencies: readonly PrecomputedDependencyEvaluation[] | undefined, flags: Record<string, PrecomputedFlag>, flagErrors?: Record<string, string>): void;
export declare function inheritPrecomputedDependencyEvaluations(from: FlagMetadata, to: FlagMetadata): void;
export declare function getPrecomputedDependencyEvaluations(details: {
    flagMetadata?: FlagMetadata;
}): readonly PrecomputedDependencyEvaluationDetails[];
//# sourceMappingURL=precomputed-dependencies.d.ts.map