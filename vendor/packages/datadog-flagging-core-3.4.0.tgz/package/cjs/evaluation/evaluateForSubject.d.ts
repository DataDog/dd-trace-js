import type { EvaluationContext, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import type { FlagTypeToValue } from '../configuration';
import { type TimeStamp } from '../time';
import { type EvaluationDiagnostics } from './diagnostics';
import { type ExperimentationOptOutPolicy } from './experimentation-opt-out';
import { type ResolveFlagEvaluation, type Rule } from './rules';
import { type Flag } from './ufc-v1';
export declare function evaluateForSubject<T extends FlagValueType>(flag: Flag, type: T, subjectKey: string | null | undefined, subjectAttributes: EvaluationContext, defaultValue: FlagTypeToValue<T>, logger: Logger, evaluationTimestampMs?: TimeStamp, excludeExperiments?: ExperimentationOptOutPolicy | boolean, resolveFlagEvaluation?: ResolveFlagEvaluation, diagnostics?: EvaluationDiagnostics): ResolutionDetails<FlagTypeToValue<T>>;
export declare function containsMatchingRule(rules: Rule[] | undefined, subjectAttributes: EvaluationContext, logger: Logger, resolveFlagEvaluation?: ResolveFlagEvaluation, diagnostics?: EvaluationDiagnostics): boolean;
//# sourceMappingURL=evaluateForSubject.d.ts.map