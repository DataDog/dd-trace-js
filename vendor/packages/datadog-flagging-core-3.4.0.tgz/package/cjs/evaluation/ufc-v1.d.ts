import type { FlagValue, FlagValueType } from '@openfeature/core';
import type { Rule } from './rules';
export type VariantType = 'BOOLEAN' | 'INTEGER' | 'NUMERIC' | 'STRING' | 'JSON';
export interface VariantConfiguration {
    key: string;
    value: FlagValue;
}
export interface ShardRange {
    start: number;
    end: number;
}
export interface Shard {
    salt: string;
    ranges: ShardRange[];
    totalShards: number;
}
export interface Split {
    variationKey: string;
    shards: Shard[];
    extraLogging?: Record<string, string>;
    serialId?: number;
    features?: unknown;
}
export interface Allocation {
    key: string;
    rules?: Rule[];
    startAt?: Date;
    endAt?: Date;
    randomizationActivatedAt?: string;
    splits: Split[];
    /** Required by the UFC JSON schema; the producer always supplies an explicit boolean. */
    doLog: boolean;
}
export interface Flag {
    key: string;
    enabled: boolean;
    variationType: VariantType;
    variations: Record<string, VariantConfiguration>;
    allocations: Allocation[];
}
export interface UniversalFlagConfigurationV1 {
    createdAt: string;
    format: string;
    observeFullEvaluationData?: boolean;
    evaluatorParams?: {
        maxDependencyDepth?: number;
    };
    environment: {
        name: string;
    };
    flags: Record<string, Flag>;
}
export interface UniversalFlagConfigurationV1Response {
    data: {
        type: 'universal-flag-configuration';
        id: string;
        attributes: UniversalFlagConfigurationV1;
    };
}
export declare function variantTypeToFlagValueType(variantType: VariantType): FlagValueType;
//# sourceMappingURL=ufc-v1.d.ts.map