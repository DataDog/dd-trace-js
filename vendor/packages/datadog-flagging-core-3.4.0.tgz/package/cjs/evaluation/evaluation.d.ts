import type { EvaluationContext, FlagValue, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import { type FlagsConfiguration, type FlagTypeToValue } from '../configuration';
import type { FlagsConfiguration as ProtobufFlagsConfiguration } from '../configuration/generated/ufc_pb';
import { type ExperimentationOptOutOption } from './experimentation-opt-out';
import { type UniversalFlagConfigurationV1 } from './ufc-v1';
export declare function evaluate<T extends FlagValueType>(flagsConfiguration: FlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger?: Logger, experimentationOptOutMode?: ExperimentationOptOutOption): ResolutionDetails<FlagTypeToValue<T>>;
export type FlagsConfigurationError = {
    errorCode: 'INVALID_CONTEXT' | 'PARSE_ERROR' | 'PROVIDER_NOT_READY';
    errorMessage?: string;
};
/** Return the lifecycle/evaluation error when no configuration capability can serve the context. */
export declare function getFlagsConfigurationError(configuration: FlagsConfiguration | undefined, context: EvaluationContext, experimentationOptOutMode?: ExperimentationOptOutOption): FlagsConfigurationError | undefined;
export declare function evaluateRulesBasedConfiguration<T extends FlagValueType>(config: UniversalFlagConfigurationV1 | ProtobufFlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger: Logger, experimentationOptOutMode?: ExperimentationOptOutOption): ResolutionDetails<FlagTypeToValue<T>>;
export type EvaluationTrace<T extends FlagValue = FlagValue> = {
    details: ResolutionDetails<T>;
    dependencyEvaluations: readonly DependencyEvaluation[];
    dependencyExposures: readonly DependencyExposureCandidate[];
};
export type EvaluationTraceOptions = {
    collectDependencyEvaluations?: boolean;
    collectDependencyExposures?: boolean;
};
/** @internal Returns the completed dependency trace for provider integrations. */
export declare function evaluateRulesBasedConfigurationWithTrace<T extends FlagValueType>(config: UniversalFlagConfigurationV1 | ProtobufFlagsConfiguration | undefined, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger: Logger, experimentationOptOutMode?: ExperimentationOptOutOption, options?: EvaluationTraceOptions): EvaluationTrace<FlagTypeToValue<T>>;
export type DependencyEvaluation = {
    flagKey: string;
    details: Omit<ResolutionDetails<FlagValue>, 'value'> & {
        value?: FlagValue;
    };
};
export type DependencyExposureCandidate = {
    flagKey: string;
    details: Omit<ResolutionDetails<FlagValue>, 'value'>;
};
//# sourceMappingURL=evaluation.d.ts.map