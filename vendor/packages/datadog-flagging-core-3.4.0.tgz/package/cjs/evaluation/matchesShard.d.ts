import { type EvaluationDiagnostics } from './diagnostics';
import { type Sharder } from './sharders';
import type { Shard } from './ufc-v1';
export declare function matchesShard(shard: Shard, subjectKey: string, customSharder?: Sharder, diagnostics?: EvaluationDiagnostics): boolean;
//# sourceMappingURL=matchesShard.d.ts.map