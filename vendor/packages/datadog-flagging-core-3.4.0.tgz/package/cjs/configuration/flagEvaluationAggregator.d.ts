import type { EvaluationContext, EvaluationContextValue, EvaluationDetails, FlagValue } from '@openfeature/core';
import { type FeatureValue } from '../evaluation/split-features';
import { type TimeStamp } from '../time';
import type { FlagEvaluationEvent } from './flagEvaluationEvent.types';
interface FlagEvaluationAggregationData {
    flagKey: string;
    variantKey?: string;
    allocationKey?: string;
    targetingRuleKey?: string;
    targetingKey?: string;
    targetingContext?: Record<string, EvaluationContextValue>;
    features?: Record<string, FeatureValue>;
    count: number;
    firstEvaluation: TimeStamp;
    lastEvaluation: TimeStamp;
    runtimeDefaultUsed: boolean;
    error?: string;
}
export interface AggregationDiagnostic {
    type: 'add' | 'flush';
    aggregationId: string;
    aggregationSize: number;
    data: Readonly<FlagEvaluationAggregationData>;
    event?: FlagEvaluationEvent;
    trigger?: string;
}
export declare class FlagEvaluationAggregator {
    private readonly observe?;
    private aggregatedData;
    private generation;
    private intervalId?;
    private readonly flushInterval;
    private readonly onFlush;
    constructor(flushInterval: number, onFlush: (events: FlagEvaluationEvent[]) => void, observe?: ((diagnostic: AggregationDiagnostic) => void) | undefined);
    start(): void;
    stop(trigger?: string): void;
    addEvaluation<T extends FlagValue>(context: EvaluationContext, details: EvaluationDetails<T>, error?: string): void;
    private notify;
    flush(trigger?: string): void;
    private createAggregationKeyString;
}
export {};
//# sourceMappingURL=flagEvaluationAggregator.d.ts.map