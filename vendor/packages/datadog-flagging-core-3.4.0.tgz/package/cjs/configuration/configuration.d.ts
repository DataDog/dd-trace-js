import type { EvaluationContext, FlagValueType, JsonValue, ResolutionReason } from '@openfeature/core';
import type { TimeStamp } from '../time';
import type { FlagKeyObfuscation } from './flag-key-obfuscation';
import type { PreparedRulesResponse } from './prepared-rules-response';
/**
 * Internal flags configuration for DatadogProvider.
 */
export type FlagsConfiguration = {
    /** The configuration wire could not be parsed, so no capability was decoded. @internal */
    configurationError?: string;
    /** @internal */
    precomputed?: PrecomputedConfiguration;
    /** The precomputed capability could not be decoded; a valid rules capability remains usable. @internal */
    precomputedError?: string;
    /** @internal */
    rules?: RulesConfiguration;
    /** The rules capability could not be decoded; a valid precomputed capability remains usable. @internal */
    rulesError?: string;
};
/** @internal */
export type PrecomputedConfiguration = {
    response: PrecomputedConfigurationResponse;
    context?: EvaluationContext;
    fetchedAt?: TimeStamp;
    etag?: string;
    /** Parsing errors for malformed flags, retained by flag key. */
    flagErrors?: Record<string, string>;
};
/** @internal */
export type RulesConfiguration = {
    response: PreparedRulesResponse;
    fetchedAt?: TimeStamp;
    etag?: string;
};
/** @internal */
export type FlagTypeToValue<T extends FlagValueType> = {
    boolean: boolean;
    string: string;
    number: number;
    object: JsonValue;
}[T];
/** @internal */
export type PrecomputedConfigurationResponse = {
    data: {
        attributes: {
            /** When configuration was generated. */
            createdAt: string;
            /** Effective server evaluation options, retained in portable and persisted configurations. */
            evaluation_options?: {
                experimentation_opt_out?: boolean;
                experimentation_opt_out_mode?: string;
                dd_experimentation_opt_out_at?: string;
            };
            /** Absent or false for legacy plaintext assignments. */
            obfuscated?: boolean;
            /** Required when obfuscated is true; retained with the map in caches. */
            obfuscation?: FlagKeyObfuscation;
            flags: Record<string, PrecomputedFlag>;
        };
    };
};
/** @internal */
export type PrecomputedFlag<T extends FlagValueType = FlagValueType> = PrecomputedSuccessfulFlag<T> | PrecomputedErrorFlag;
/** @internal */
export type PrecomputedSuccessfulFlag<T extends FlagValueType = FlagValueType> = {
    allocationKey: string;
    variationKey: string;
    variationType: T;
    variationValue: FlagTypeToValue<T>;
    reason: ResolutionReason;
    doLog: boolean;
    serialId?: number | null;
    dependencyEvaluations?: PrecomputedDependencyEvaluation[];
    /** Split features of the selected assignment; parsed leniently at evaluation time. */
    features?: unknown;
};
/** @internal */
export type PrecomputedErrorFlag = {
    reason: 'ERROR';
    errorCode: string;
    dependencyEvaluations?: PrecomputedDependencyEvaluation[];
    allocationKey?: never;
    variationKey?: never;
    variationType?: never;
    variationValue?: never;
    doLog?: never;
    serialId?: never;
};
/** @internal */
export type PrecomputedDependencyEvaluation = {
    flagKey: string;
    /** Whether this dependency belongs to the root flag's selected assignment path. */
    isPresentInAssignment: boolean;
} | {
    flagKey: string;
    /** Root-relative prerequisite failure; error entries never belong to an assignment. */
    reason: 'ERROR';
    errorCode: string;
};
/** @internal */
export type PrecomputedFlagMetadata = {
    allocationKey?: string;
    variationType?: FlagValueType;
    doLog?: boolean;
    __dd_allocation_key?: string;
    __dd_do_log?: boolean;
    __dd_split_serial_id?: number;
    __dd_eval_timestamp_ms?: TimeStamp;
    __dd_observe_full_evaluation_data?: boolean;
    __dd_exposure_cache_hit?: boolean;
    __dd_has_evaluation_features?: boolean;
};
/**
 * Check if a stored configuration matches the requested evaluation context.
 * - If the config has no context, it's context-agnostic and matches any request
 * - If the config has a context, it must match the requested context exactly
 */
export declare function configMatchesContext(config: FlagsConfiguration | undefined, requestedContext: EvaluationContext): boolean;
//# sourceMappingURL=configuration.d.ts.map