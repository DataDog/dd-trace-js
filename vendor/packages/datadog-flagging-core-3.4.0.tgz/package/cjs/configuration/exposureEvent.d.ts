import type { EvaluationContext, EvaluationDetails, FlagValue } from '@openfeature/core';
import type { ExposureEvent } from './exposureEvent.types';
export declare function createExposureEvent<T extends FlagValue>(context: EvaluationContext, details: EvaluationDetails<T>): ExposureEvent | undefined;
export declare function createExposureEvent(context: EvaluationContext, details: Pick<EvaluationDetails<FlagValue>, 'flagKey' | 'variant' | 'flagMetadata'>): ExposureEvent | undefined;
//# sourceMappingURL=exposureEvent.d.ts.map