export interface FlagSelection {
    tags?: readonly string[];
    keyPatterns?: readonly string[];
}
/** @internal */
export interface CanonicalFlagSelection {
    tags: string[];
    keyPatterns: string[];
}
/** @internal */
export type FlagSelectionError = 'malformed_selection' | 'too_many_values' | 'invalid_key_pattern' | 'invalid_tag';
/** @internal */
export interface CanonicalizeFlagSelectionResult {
    selection?: CanonicalFlagSelection;
    error?: FlagSelectionError;
}
/** @internal */
export declare const MAX_FLAG_SELECTION_VALUES = 31;
/** @internal */
export declare const MAX_FLAG_SELECTION_TAG_BYTES = 200;
/** @internal */
export declare const MAX_FLAG_SELECTION_KEY_PATTERN_BYTES = 200;
/**
 * Canonicalizes and validates a flag selection the same way Compute and ffe-service do.
 * Returns no selection when both lists are empty after canonicalization.
 * @internal
 */
export declare function canonicalizeFlagSelection(input: unknown): CanonicalizeFlagSelectionResult;
//# sourceMappingURL=flag-selection.d.ts.map