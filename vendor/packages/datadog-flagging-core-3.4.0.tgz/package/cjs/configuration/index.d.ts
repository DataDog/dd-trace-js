export type { ClientFingerprint } from './client-fingerprint';
export * from './configuration';
export * from './exposure-decision';
export * from './exposureEvent';
export * from './exposureEvent.types';
export { FLAG_KEY_SHA256_CAPABILITY, SUPPORTED_FLAGS_CAPABILITIES } from './flag-key-obfuscation';
export * from './flag-selection';
export * from './flagEvaluationAggregator';
export * from './flagEvaluationEvent';
export * from './flagEvaluationEvent.types';
export * from './precomputed-context';
export { configurationFromPrecomputedString as configurationFromString, configurationToPrecomputedString as configurationToString, } from './precomputed-wire';
export { prepareUniversalFlagConfiguration } from './prepared-activation';
export type { FlagsConfigurationWire } from './wire-types';
export { parsePrecomputedConfigurationResponse } from './wire-validation';
//# sourceMappingURL=index.d.ts.map