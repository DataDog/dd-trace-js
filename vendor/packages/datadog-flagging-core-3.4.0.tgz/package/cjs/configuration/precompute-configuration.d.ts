import type { ErrorCode, EvaluationContext } from '@openfeature/core';
import { type ExperimentationOptOutModeValue } from '../evaluation/experimentation-opt-out';
import type { FlagsConfiguration } from './configuration';
export type ConfigurationPrecomputeErrorCode = 'invalid_configuration' | 'invalid_context' | 'invalid_options';
/** A top-level input error. Individual flag failures are reported separately. */
export declare class ConfigurationPrecomputeError extends Error {
    readonly code: ConfigurationPrecomputeErrorCode;
    constructor(code: ConfigurationPrecomputeErrorCode);
}
export type PrecomputeEvaluationError = {
    flagKey: string;
    errorCode: ErrorCode;
};
export type PrecomputeConfigurationOptions = {
    /** Defaults to disabled. The receiving provider must use the same effective opt-out policy. */
    experimentationOptOutMode?: ExperimentationOptOutModeValue;
    /**
     * Called for each omitted evaluation error, after all flags have been evaluated.
     * Contains no context, values, or raw error messages. Exceptions from this callback propagate.
     */
    onEvaluationError?: (error: PrecomputeEvaluationError) => void;
};
/**
 * Locally resolve rules for one context, without defaults, tracking, or network calls.
 * Returns a context-bound, precomputed-only snapshot. Failed and unassigned flags are omitted.
 * Recompute when the context or rules change; client-directed output requires client-safe source rules.
 */
export declare function precomputeConfiguration(configuration: FlagsConfiguration, context: EvaluationContext, options?: PrecomputeConfigurationOptions): FlagsConfiguration;
//# sourceMappingURL=precompute-configuration.d.ts.map