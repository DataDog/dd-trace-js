import type { EvaluationDetails, FlagMetadata, FlagValue } from '@openfeature/core';
import type { AssignmentCache } from '../cache';
import type { ExposureEvent } from './exposureEvent.types';
/**
 * Prepare the exposure-cache verdict as a provisional, enumerable getter on the
 * metadata, before OpenFeature freezes it for hooks. The verdict becomes final
 * only when the evaluation completes successfully, so concurrent or nested
 * evaluations cannot both record the same exposure.
 */
export declare function prepareExposureDecision(metadata: FlagMetadata, cache: AssignmentCache, event: ExposureEvent): void;
/**
 * Admit once after a successful evaluation, before either destination observes
 * the verdict. Returns true when a shared decision was prepared for the result,
 * so callers know recording has been handled.
 */
export declare function completeExposureDecision(details: Pick<EvaluationDetails<FlagValue>, 'flagMetadata' | 'errorCode' | 'reason'>): boolean;
//# sourceMappingURL=exposure-decision.d.ts.map