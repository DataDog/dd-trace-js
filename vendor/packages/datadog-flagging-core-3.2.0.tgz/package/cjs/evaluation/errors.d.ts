import type { ErrorCode } from '@openfeature/core';
export declare class TargetingKeyMissingError extends Error {
    constructor();
}
export declare class FlagConfigurationError extends Error {
    constructor(message: string);
}
export declare class InvalidContextError extends Error {
    constructor();
}
export declare class DependencyGraphError extends Error {
    readonly flagKey: string;
    readonly errorCode: ErrorCode;
    constructor(flagKey: string, errorCode: ErrorCode, message: string);
}
//# sourceMappingURL=errors.d.ts.map