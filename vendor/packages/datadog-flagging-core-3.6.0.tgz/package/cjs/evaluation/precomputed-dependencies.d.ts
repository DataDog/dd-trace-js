import type { EvaluationDetails, FlagMetadata, FlagValue, Logger } from '@openfeature/core';
import type { PrecomputedDependencyEvaluation, PrecomputedErrorFlag, PrecomputedFlag } from '../configuration';
import type { FlagKeyObfuscation } from '../configuration/flag-key-obfuscation';
export type PrecomputedDependencyEvaluationDetails = Omit<EvaluationDetails<FlagValue>, 'value'> & {
    value?: FlagValue;
    /** Successful dependencies only; errors are reached-evaluation telemetry. */
    isPresentInAssignment?: boolean;
};
export declare function bindPrecomputedDependencyEvaluations(metadata: FlagMetadata, dependencies: readonly PrecomputedDependencyEvaluation[] | undefined, flags: Record<string, PrecomputedFlag>, flagErrors?: Record<string, string>, logger?: Logger, identity?: {
    rootFlagKey: string;
    encoding?: FlagKeyObfuscation;
    allowDependencyErrors?: boolean;
    flagEvaluationErrors?: Record<string, PrecomputedErrorFlag>;
}): string | undefined;
export declare function getPrecomputedDependencyEvaluations(details: {
    flagMetadata?: FlagMetadata;
}): readonly PrecomputedDependencyEvaluationDetails[];
//# sourceMappingURL=precomputed-dependencies.d.ts.map