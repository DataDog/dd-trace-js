export declare function getOwnProperty<T>(record: Record<string, T>, key: string): T | undefined;
export declare function hasOwnKey(record: object, key: string): boolean;
//# sourceMappingURL=getOwnProperty.d.ts.map