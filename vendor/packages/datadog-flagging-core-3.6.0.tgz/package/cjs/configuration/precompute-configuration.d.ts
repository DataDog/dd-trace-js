import type { ErrorCode, EvaluationContext } from '@openfeature/core';
import { type ExperimentationOptOutModeValue } from '../evaluation/experimentation-opt-out';
import type { FlagsConfiguration } from './configuration';
import { type FlagKeyObfuscation } from './flag-key-obfuscation';
import { type FlagSelection } from './flag-selection';
export type ConfigurationPrecomputeErrorCode = 'invalid_configuration' | 'invalid_context' | 'invalid_options';
/** A top-level input error. Individual flag failures are reported separately. */
export declare class ConfigurationPrecomputeError extends Error {
    readonly code: ConfigurationPrecomputeErrorCode;
    constructor(code: ConfigurationPrecomputeErrorCode);
}
export type PrecomputeEvaluationError = {
    flagKey: string;
    errorCode: ErrorCode;
};
export type PrecomputeConfigurationOptions = {
    /**
     * Select initial root flags whose whole key matches any pattern; only `*` is special.
     * Tags are unsupported: any defined tags value, including [] or null, throws invalid_options.
     * Malformed or over-limit selections also throw invalid_options. With tags absent, omitted selections or no
     * nonempty keyPatterns include all assignments; a null selection is treated as absent at runtime.
     * Precomputation also includes transitive configured prerequisite assignments needed by selected roots,
     * even when their keys do not match.
     */
    flagSelection?: Pick<FlagSelection, 'keyPatterns'> & {
        tags?: never;
    };
    /** Defaults to disabled. The receiving provider must use the same effective opt-out policy. */
    experimentationOptOutMode?: ExperimentationOptOutModeValue;
    /** Encode top-level keys and encrypt root-relative prerequisite keys using this descriptor. */
    obfuscation?: FlagKeyObfuscation;
    /**
     * Called for each evaluation error in the selected-root and prerequisite closure, after all flags have been evaluated.
     * Failed dependency graph roots are retained in the wire; ordinary failures are callback-only.
     * Contains no context, values, or raw error messages. Exceptions from this callback propagate.
     */
    onEvaluationError?: (error: PrecomputeEvaluationError) => void;
};
/**
 * Locally resolve rules for one context, without defaults, tracking, or network calls.
 * Returns a context-bound, precomputed-only snapshot. Failures are separated from successful assignments;
 * no-assignment flags remain absent.
 * Recompute when the context or rules change; client-directed output requires client-safe source rules.
 */
export declare function precomputeConfiguration(configuration: FlagsConfiguration, context: EvaluationContext, options?: PrecomputeConfigurationOptions): FlagsConfiguration;
//# sourceMappingURL=precompute-configuration.d.ts.map