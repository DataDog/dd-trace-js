declare const SCHEME = "flag-key-sha256-v1";
export declare const DEPENDENCY_KEY_ENCRYPTION_SCHEME = "dependency-key-hkdf-sha256-aes-256-gcm-v1";
/** Capability required to consume flag-key-sha256-v1 assignment maps. */
export declare const FLAG_KEY_SHA256_CAPABILITY = "assignment-encoding-flag-key-256-v1";
/** Capability required to consume prerequisite traces in precomputed assignments. */
export declare const DEPENDENT_FLAG_VARIANT_KEY_CAPABILITY = "dependent-flag-variant-key-v1";
/** Capabilities supported by the precomputed parser and evaluator. @internal */
export declare const SUPPORTED_FLAGS_CAPABILITIES: readonly ["assignment-encoding-flag-key-256-v1", "dependent-flag-variant-key-v1"];
/** Public metadata stored with the encoded assignment map. @internal */
export type FlagKeyObfuscation = {
    scheme: typeof SCHEME;
    salt: string;
    dependencyKeyEncryption?: {
        scheme: typeof DEPENDENCY_KEY_ENCRYPTION_SCHEME;
    };
};
/** Validate the response's encoding before parsing or looking up assignments. */
export declare function readFlagKeyObfuscation(obfuscated: unknown, obfuscation: unknown): {
    encoding?: FlagKeyObfuscation;
} | {
    error: string;
};
/** Whether an obfuscated packet declares the supported dependency-key envelope. */
export declare function supportsDependencyKeyEncryption(encoding: FlagKeyObfuscation): boolean;
/** Hash only the lookup key. Values and telemetry retain their original meaning. @internal */
export declare function encodePrecomputedFlagKey(key: string, encoding: FlagKeyObfuscation): {
    key: string;
} | {
    error: string;
};
/** Check the exact byte length and alphabet of a hex-encoded wire value. */
export declare function isLowercaseHex(value: unknown, bytes: number): value is string;
export {};
//# sourceMappingURL=flag-key-obfuscation.d.ts.map