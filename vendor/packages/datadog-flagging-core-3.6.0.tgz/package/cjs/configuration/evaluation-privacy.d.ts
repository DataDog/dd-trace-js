import type { EvaluationContext, EvaluationContextValue } from '@openfeature/core';
/** Apply privacy before buffering; discarded context must not participate in aggregation. */
export declare function captureEvaluationContext(context: EvaluationContext, observeFullData: boolean): {
    targetingKey: string | undefined;
    targetingContext: Record<string, EvaluationContextValue> | undefined;
};
/** Stable telemetry vocabulary in both consent modes; never emit exception messages. */
export declare function sanitizeEvaluationError(error: unknown): string | undefined;
//# sourceMappingURL=evaluation-privacy.d.ts.map