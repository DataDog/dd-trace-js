import type { FlagKeyObfuscation } from './flag-key-obfuscation';
/** Encrypt a plaintext prerequisite key for one plaintext root flag key. @internal */
export declare function encryptDependencyFlagKey(dependencyFlagKey: string, rootFlagKey: string, encoding: FlagKeyObfuscation): string;
/** Create an encryptor that reuses one root-relative key for a dependency batch. @internal */
export declare function createDependencyFlagKeyEncryptor(rootFlagKey: string, encoding: FlagKeyObfuscation): (dependencyFlagKey: string) => string;
/** Authenticate and decrypt a prerequisite key using its caller-supplied plaintext root key. @internal */
export declare function decryptDependencyFlagKey(encryptedFlagKey: string, rootFlagKey: string, encoding: FlagKeyObfuscation): {
    key: string;
} | {
    error: string;
};
/** Create a decryptor that reuses one root-relative key for a dependency batch. @internal */
export declare function createDependencyFlagKeyDecryptor(rootFlagKey: string, encoding: FlagKeyObfuscation): (encryptedFlagKey: string) => {
    key: string;
} | {
    error: string;
};
//# sourceMappingURL=dependency-key-encryption.d.ts.map