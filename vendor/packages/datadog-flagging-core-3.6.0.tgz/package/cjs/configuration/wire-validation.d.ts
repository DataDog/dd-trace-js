import type { EvaluationContext } from '@openfeature/core';
import type { PrecomputedConfigurationResponse, PrecomputedErrorFlag } from './configuration';
import { type FlagKeyObfuscation } from './flag-key-obfuscation';
type WireEntry = {
    response: string;
    fetchedAt?: number;
    etag?: string;
};
export type PrecomputedWireEntry = WireEntry & {
    context?: EvaluationContext;
};
export declare function isWireEntry(value: unknown): value is WireEntry;
export declare function isPrecomputedWireEntry(value: unknown): value is PrecomputedWireEntry;
/** @internal */
export declare function parsePrecomputedConfigurationResponse(value: unknown, onInvalidFlag?: (key: string, issue: {
    field: string;
    expected: string;
    actual: unknown;
}) => void): {
    response: PrecomputedConfigurationResponse;
    flagErrors?: Record<string, string>;
} | {
    error: string;
};
export declare function precomputedFlagIssue(value: unknown, encoding?: FlagKeyObfuscation): {
    field: string;
    expected: string;
    actual: unknown;
} | undefined;
export declare function isPrecomputedErrorFlag(value: unknown, encoding?: FlagKeyObfuscation): value is PrecomputedErrorFlag;
export declare function isDependencyEvaluations(value: unknown, encoding?: FlagKeyObfuscation): boolean;
export {};
//# sourceMappingURL=wire-validation.d.ts.map