export declare function encodeUtf8(value: string): Uint8Array<ArrayBuffer>;
export declare function compareBytes(left: Uint8Array, right: Uint8Array): number;
export declare function isWellFormedUnicode(value: string): boolean;
//# sourceMappingURL=utf8.d.ts.map