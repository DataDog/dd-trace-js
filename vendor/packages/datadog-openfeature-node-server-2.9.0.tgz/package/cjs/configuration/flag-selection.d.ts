import { type FlagSelection, type FlagSelectionError } from '@datadog/flagging-core';
export interface ConfigurationSelectionOptions {
    /**
     * Request flags matching any of these tags or key patterns.
     * Best-effort: an invalid or over-limit selection is not sent.
     */
    flagSelection?: FlagSelection;
    /** Reports dropped or server-ignored selections. Defaults to console. */
    logger?: {
        error(message: string): void;
    };
}
type SelectionLogger = NonNullable<ConfigurationSelectionOptions['logger']>;
export declare function reportDroppedFlagSelection(logger: SelectionLogger, reason: FlagSelectionError, limit?: string): void;
export declare function reportIgnoredFlagSelection(logger: SelectionLogger, response: Response): void;
export {};
//# sourceMappingURL=flag-selection.d.ts.map