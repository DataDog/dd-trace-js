import { type FlagsConfiguration } from '@datadog/flagging-core';
import { type ConfigurationSelectionOptions } from './flag-selection';
export { ConfigurationFetchError, type ConfigurationFetchErrorCode } from './configuration-fetch';
interface ConfigurationFetchOptions extends ConfigurationSelectionOptions {
    env: string;
    /** Datadog site. Defaults to datadoghq.com. */
    site?: string;
    /** Request and response-body deadline in milliseconds. Defaults to 5000. */
    timeoutMs?: number;
    signal?: AbortSignal;
    /** Fetch-compatible transport. Must honor the supplied signal and redirect policy. */
    fetch?: typeof globalThis.fetch;
}
export type RulesConfigurationFetchOptions = ConfigurationFetchOptions & ({
    distributionChannel?: 'server';
    apiKey: string;
    clientToken?: never;
} | {
    distributionChannel: 'client';
    clientToken: string;
    apiKey?: never;
});
/**
 * Fetch and parse context-independent rules without initializing a provider or tracer.
 * Only client-distributed configurations are suitable for forwarding to a browser.
 */
export declare function fetchRulesConfiguration(options: RulesConfigurationFetchOptions): Promise<FlagsConfiguration>;
//# sourceMappingURL=fetch-rules-configuration.d.ts.map