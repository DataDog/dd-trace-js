import { timeStampNow } from '@datadog/flagging-core';
export type ConfigurationFetchErrorCode = 'invalid_options' | 'http' | 'invalid_response' | 'decode' | 'transport' | 'cancelled' | 'timeout';
/** A configuration-loading failure, not an OpenFeature evaluation error. */
export declare class ConfigurationFetchError extends Error {
    readonly code: ConfigurationFetchErrorCode;
    readonly status?: number | undefined;
    constructor(code: ConfigurationFetchErrorCode, message: string, status?: number | undefined);
}
export declare function transportError(message: string, error: unknown): ConfigurationFetchError;
export declare function invalidOption(option: string): ConfigurationFetchError;
export interface ConfigurationTransportOptions {
    /** Request and response-body deadline in milliseconds. Defaults to 5000. */
    timeoutMs?: number;
    signal?: AbortSignal;
    /** Fetch-compatible transport. Must honor the supplied signal and redirect policy. */
    fetch?: typeof globalThis.fetch;
}
export declare function validateTransportOptions(timeoutMs: number, signal: AbortSignal | undefined, requestFetch: typeof fetch): void;
/** Keep credentials, deadlines and response cleanup consistent across configuration endpoints. */
export declare function requestConfiguration<T>(url: string, init: RequestInit, options: Required<Pick<ConfigurationTransportOptions, 'fetch' | 'timeoutMs'>> & Pick<ConfigurationTransportOptions, 'signal'>, read: (response: Response, fetchedAt: ReturnType<typeof timeStampNow>, checkAborted: () => void) => Promise<T>): Promise<T>;
//# sourceMappingURL=configuration-fetch.d.ts.map