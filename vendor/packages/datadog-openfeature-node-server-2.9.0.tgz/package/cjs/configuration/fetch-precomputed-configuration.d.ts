import { type ClientFingerprint, type ExperimentationOptOutModeValue, type FlagsConfiguration } from '@datadog/flagging-core';
import type { EvaluationContext } from '@openfeature/core';
import { type ConfigurationTransportOptions } from './configuration-fetch';
import { type ConfigurationSelectionOptions } from './flag-selection';
export interface PrecomputedConfigurationFetchOptions extends ConfigurationTransportOptions, ConfigurationSelectionOptions {
    /** Required for now. Only client-distributed flags are supported by this endpoint. */
    distributionChannel: 'client';
    clientToken: string;
    /** Reserved. API-key authentication is not supported for client distribution. */
    apiKey?: never;
    env: string;
    /** Datadog site. Defaults to datadoghq.com. */
    site?: string;
    applicationId?: string;
    /**
     * A detached snapshot is bound to the returned assignments. Only plain JSON values are accepted:
     * no Date, undefined, non-finite numbers, class instances, or cycles, including nested values.
     * Convert dates to strings before calling and use the same context in the receiving provider.
     */
    context: EvaluationContext;
    /** Opaque target SDK fingerprint. Forward unchanged from its getter; omission requests plaintext. */
    clientFingerprint?: ClientFingerprint;
    /** Defaults to disabled. The receiving provider must use the same effective opt-out policy. */
    experimentationOptOutMode?: ExperimentationOptOutModeValue;
}
/** Fetch assignments for one client context, without initializing a provider or emitting tracking events. */
export declare function fetchPrecomputedConfiguration(options: PrecomputedConfigurationFetchOptions): Promise<FlagsConfiguration>;
//# sourceMappingURL=fetch-precomputed-configuration.d.ts.map