import { type ClientFingerprint, type FlagsConfiguration } from '@datadog/flagging-core';
import { type PrecomputeConfigurationOptions as CorePrecomputeConfigurationOptions } from '@datadog/flagging-core/rules-based';
import type { EvaluationContext } from '@openfeature/core';
export type PrecomputeConfigurationOptions = Omit<CorePrecomputeConfigurationOptions, 'obfuscation'> & {
    /** Opaque target SDK fingerprint. Forward unchanged from its getter; omission preserves plaintext keys. */
    clientFingerprint?: ClientFingerprint;
};
/** Resolve rules locally for one context, then encode keys for the target client without tracking or fetching. */
export declare function precomputeConfiguration(configuration: FlagsConfiguration, context: EvaluationContext, options?: PrecomputeConfigurationOptions): FlagsConfiguration;
//# sourceMappingURL=precompute-configuration.d.ts.map