/** Decode the SDK-owned wire, then retain only response formats implemented here. Identity is not authorization. */
export declare function readPrecomputedCapabilities(input: unknown): readonly string[];
//# sourceMappingURL=client-fingerprint.d.ts.map