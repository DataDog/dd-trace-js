type Milestone = {
    elapsed_ms: number;
};
type Initialization = {
    started_at_ms: number;
    duration_ms: number;
    milestones: {
        configuration_received?: Milestone;
        provider_ready?: Milestone;
    };
};
/** A provider observation. The integration adds SDK and service identity and handles delivery. */
export type SDKDiagnostic = {
    timestamp: number;
} & ({
    event_type: 'sdk_initialization';
    initialization: Initialization & {
        outcome: 'ready';
        final: true;
        milestones: {
            configuration_received: Milestone;
            provider_ready: Milestone;
        };
    };
} | {
    event_type: 'sdk_initialization';
    error_code: 'INIT_FAILED';
    initialization: Initialization & {
        outcome: 'failed';
        final: true;
    };
} | {
    event_type: 'sdk_initialization';
    initialization: Initialization & {
        outcome: 'incomplete';
        final: false;
        reason: 'provider_closed';
    };
} | {
    event_type: 'provider_error';
    error_code: 'CONFIG_FETCH_FAILED';
});
/** Observations describe one provider, not the health of every process in a service. */
export declare class SDKDiagnostics {
    private readonly onDiagnostic;
    private startedAt?;
    private startedMonotonic;
    private configurationElapsed?;
    private finished;
    private closed;
    private startupFetch;
    private fetchFailed;
    private lastErrorAt;
    constructor(onDiagnostic: (diagnostic: SDKDiagnostic) => void | Promise<void>);
    start(hasConfiguration: boolean): void;
    configurationReceived(): void;
    finish(outcome: 'ready' | 'failed' | 'incomplete'): void;
    fetchStarted(): void;
    fetchResult(success: boolean): void;
    close(): void;
    private elapsed;
    private emit;
}
export {};
//# sourceMappingURL=sdk-diagnostics.d.ts.map