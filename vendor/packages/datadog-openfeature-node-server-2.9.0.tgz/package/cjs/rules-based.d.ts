export type { ClientFingerprint, FlagSelection, FlagsConfiguration } from '@datadog/flagging-core';
export { ConfigurationPrecomputeError, type ConfigurationPrecomputeErrorCode, configurationFromRulesBinary, configurationFromString, configurationToString, type FlagsConfigurationWire, type PrecomputeEvaluationError, } from '@datadog/flagging-core/rules-based';
export { fetchPrecomputedConfiguration, type PrecomputedConfigurationFetchOptions, } from './configuration/fetch-precomputed-configuration';
export * from './configuration/fetch-rules-configuration';
export { type PrecomputeConfigurationOptions, precomputeConfiguration } from './configuration/precompute-configuration';
//# sourceMappingURL=rules-based.d.ts.map