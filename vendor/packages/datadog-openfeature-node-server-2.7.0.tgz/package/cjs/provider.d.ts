import type { Channel } from 'node:diagnostics_channel';
import { type DependencyEvaluation, type ExposureEvent } from '@datadog/flagging-core';
import type { EvaluationContext, ServerProviderEvents } from '@openfeature/core';
import type { EvaluationDetails, FlagValue, Hook, JsonValue, Logger, Paradigm, Provider, ProviderEventEmitter, ProviderMetadata, ResolutionDetails } from '@openfeature/server-sdk';
import type { UniversalFlagConfigurationV1 } from './configuration/ufc-v1';
import { type ExperimentationOptOutMode } from './experimentation-opt-out';
export interface DatadogNodeServerProviderOptions {
    /**
     * Log experiment exposures
     */
    exposureChannel: Channel<ExposureEvent>;
    /**
     * Internal sidecar consumed by the integration's root evaluation hook.
     * @internal
     */
    dependencyTelemetrySidecar?: DependencyTelemetrySidecar;
    /**
     * Timeout in milliseconds for provider initialization.
     * If the configuration is not set within this time, initialization will fail.
     * @default DEFAULT_INITIALIZATION_TIMEOUT_MS (30000ms / 30 seconds)
     */
    initializationTimeoutMs?: number;
    /** Experiment exclusion policy. Defaults to Disabled; environment configuration belongs to the caller. */
    experimentationOptOutMode?: ExperimentationOptOutMode;
}
type PreparedDependencyExposure = {
    details: Omit<EvaluationDetails<FlagValue>, 'value'> & {
        value?: FlagValue;
    };
    event: ExposureEvent;
};
type PreparedDependencyTelemetry = {
    dependencyEvaluations: readonly DependencyEvaluation[];
    dependencyExposures: readonly PreparedDependencyExposure[];
};
/**
 * Associates a completed dependency trace with the root result's metadata and evaluation context.
 * Evaluation and exposure hooks consume their respective batches from the same root lifecycle.
 * @internal
 */
export declare class DependencyTelemetrySidecar {
    readonly collectDependencyEvaluations: boolean;
    private readonly batchesByMetadata;
    private readonly batchesByContext;
    private readonly evaluationAliases;
    constructor(collectDependencyEvaluations?: boolean);
    stage(rootMetadata: object, rootContext: object, telemetry: PreparedDependencyTelemetry): void;
    associateDependencyEvaluations(alias: object, metadata: object | undefined): void;
    takeDependencyEvaluations(metadata: object | undefined, alias?: object, context?: object): readonly DependencyEvaluation[];
    takeDependencyExposures(metadata: object | undefined): readonly PreparedDependencyExposure[];
    discardDependencyExposures(metadata: object | undefined): void;
    private deleteBatch;
}
export declare class DatadogNodeServerProvider implements Provider {
    private readonly options;
    readonly metadata: ProviderMetadata;
    readonly runsOn: Paradigm;
    readonly hooks?: Hook[];
    private initController?;
    readonly events: ProviderEventEmitter<ServerProviderEvents>;
    private readonly exposureCache;
    private readonly dependencyTelemetrySidecar;
    private configuration?;
    private readonly experimentationOptOutMode;
    constructor(options: DatadogNodeServerProviderOptions);
    /**
     * Used by dd-source-js
     */
    getConfiguration(): UniversalFlagConfigurationV1 | undefined;
    /**
     * Used by dd-source-js. Pass null or undefined to withdraw the configuration.
     */
    setConfiguration(configuration: UniversalFlagConfigurationV1 | null | undefined): void;
    /**
     * Used by dd-source-js
     */
    setError(error: unknown): void;
    /**
     * Used by the OpenFeature SDK to set the status based on initialization.
     * Status of 'PROVIDER_READY' is emitted with a resolved promise.
     * Status of 'PROVIDER_ERROR' is emitted with a rejected promise.
     *
     * Since we aren't loading the configuration in this Provider, we will simulate
     * loading functionality via InitializationController.
     * See setConfiguration and setError for more details.
     */
    initialize(): Promise<void>;
    resolveBooleanEvaluation(flagKey: string, defaultValue: boolean, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<boolean>>;
    resolveStringEvaluation(flagKey: string, defaultValue: string, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<string>>;
    resolveNumberEvaluation(flagKey: string, defaultValue: number, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<number>>;
    resolveObjectEvaluation<T extends JsonValue>(flagKey: string, defaultValue: T, context: EvaluationContext, _logger: Logger): Promise<ResolutionDetails<T>>;
    private stageDependencyTelemetry;
    /** Prepares a verdict finalized by the provider hook after successful evaluation. */
    private handleExposure;
    private prepareExposure;
}
export {};
//# sourceMappingURL=provider.d.ts.map