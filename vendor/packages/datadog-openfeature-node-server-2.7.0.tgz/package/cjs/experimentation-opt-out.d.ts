export declare enum ExperimentationOptOutMode {
    Disabled = "disabled",
    Immediate = "immediate"
}
export declare function resolveExperimentationOptOutMode(mode?: ExperimentationOptOutMode): ExperimentationOptOutMode;
//# sourceMappingURL=experimentation-opt-out.d.ts.map