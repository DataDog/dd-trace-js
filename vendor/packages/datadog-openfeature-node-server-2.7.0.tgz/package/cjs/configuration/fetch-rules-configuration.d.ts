import { type FlagSelection, type FlagsConfiguration } from '@datadog/flagging-core';
interface ConfigurationFetchOptions {
    env: string;
    /** Datadog site. Defaults to datadoghq.com. */
    site?: string;
    /**
     * Request flags matching any of these tags or key patterns.
     * Best-effort: an invalid or over-limit selection is not sent.
     */
    flagSelection?: FlagSelection;
    /** Reports dropped or server-ignored selections. Defaults to console. */
    logger?: {
        error(message: string): void;
    };
    /** Request and response-body deadline in milliseconds. Defaults to 5000. */
    timeoutMs?: number;
    signal?: AbortSignal;
    /** Fetch-compatible transport. Must honor the supplied signal and redirect policy. */
    fetch?: typeof globalThis.fetch;
}
export type RulesConfigurationFetchOptions = ConfigurationFetchOptions & ({
    distributionChannel?: 'server';
    apiKey: string;
    clientToken?: never;
} | {
    distributionChannel: 'client';
    clientToken: string;
    apiKey?: never;
});
export type ConfigurationFetchErrorCode = 'invalid_options' | 'http' | 'invalid_response' | 'decode' | 'transport' | 'cancelled' | 'timeout';
/** A configuration-loading failure, not an OpenFeature evaluation error. */
export declare class ConfigurationFetchError extends Error {
    readonly code: ConfigurationFetchErrorCode;
    readonly status?: number | undefined;
    constructor(code: ConfigurationFetchErrorCode, message: string, status?: number | undefined);
}
/**
 * Fetch and parse context-independent rules without initializing a provider or tracer.
 * Only client-distributed configurations are suitable for forwarding to a browser.
 */
export declare function fetchRulesConfiguration(options: RulesConfigurationFetchOptions): Promise<FlagsConfiguration>;
export {};
//# sourceMappingURL=fetch-rules-configuration.d.ts.map