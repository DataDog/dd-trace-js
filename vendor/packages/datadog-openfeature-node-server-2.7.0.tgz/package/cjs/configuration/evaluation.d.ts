export { evaluateRulesBasedConfigurationWithTrace as evaluateWithTrace } from '@datadog/flagging-core';
//# sourceMappingURL=evaluation.d.ts.map