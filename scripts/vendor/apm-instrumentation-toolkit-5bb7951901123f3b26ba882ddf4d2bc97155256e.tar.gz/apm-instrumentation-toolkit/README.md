# APM Instrumentation Toolkit

Automates Datadog APM instrumentation using AI agents. Creates new integrations, adds features, runs tests, and reviews code — all from a single CLI.

**Supported tracers:** dd-trace-js (Node.js). Additional tracers via [repository adapters](docs/ANUBIS-APM.md).

## Install

**Install Dogbrew** (if you don't have it yet):
```bash
brew update && brew install dogbrew
```

**Prerequisites:** [Appgate VPN](https://datadoghq.atlassian.net/wiki/spaces/ENG/pages/2928541699), [GitHub CLI](https://cli.github.com/)

Dogbrew installs to `/opt/dogbrew/bin` — make sure it's on your PATH before running `dogbrew install`:
```bash
export PATH="/opt/dogbrew/bin:$PATH"   # add to ~/.zshrc or ~/.bashrc to make permanent
```

> **If you see `permission denied` on `/opt/dogbrew/Caskroom`**, fix ownership with:
> ```bash
> sudo chown -R $(whoami) /opt/dogbrew
> ```

```bash
dogbrew install dd-apm              # latest
dogbrew install dd-apm@v1.2.0       # specific version
```

On first run, `dd-apm` automatically walks you through configuration (repo paths, API key).

**Development install (from source):**
```bash
git clone https://github.com/DataDog/apm-instrumentation-toolkit
cd apm-instrumentation-toolkit
make dev          # creates .venv, installs deps, runs dd-apm setup
```

`bin/dd-apm` automatically uses `.venv` — no need to activate it manually.

> **Note:** If you keep an existing `~/.dd-apm` installation rather than replacing it, the global `dd-apm` command still points to it. Use `./bin/dd-apm` from the repo directory to run your local build instead.
>
> **If you have the repo checked out and its `bin/` on your PATH**, ensure `/opt/dogbrew/bin` appears *before* the repo's `bin/` so the dogbrew-installed binary takes priority:
> ```bash
> export PATH="/opt/dogbrew/bin:$PATH"
> which dd-apm   # should show /opt/dogbrew/bin/dd-apm
> ```

## Quick Start

```bash
# Create a new integration (guided mode with checkpoints)
dd-apm create bullmq

# Fully autonomous
dd-apm create mqtt --mode=agent

# Target a different repository
dd-apm create bullmq -r dd_trace_py

# Pass custom guidance to the agent
dd-apm create bullmq --prompt="focus on producer/consumer patterns"

# Resume an interrupted workflow (just re-run the same command)
dd-apm create bullmq

# Add features to an existing integration
dd-apm feature add kafkajs

# Run tests, lint, review
dd-apm test bullmq
dd-apm lint bullmq --fix
dd-apm review bullmq

# Open a PR when done
dd-apm pr bullmq --babysit
```

## CLI Reference

### Workflow Commands

| Command | Description |
|---------|-------------|
| `analyze <pkg>` | Analyze package and identify instrumentation targets |
| `create <pkg>` | Create new integration (auto-resumes if interrupted) |
| `test <pkg>` | Test diagnosis and fix loop |
| `lint <pkg>` | Lint with optional auto-fix |
| `review <pkg>` | Code review with parallel checks |
| `semantic <pkg>` | Semantic validation (evalya integration tests) |
| `llm-obs <pkg>` | Generate LLM Observability layer (requires tracing plugin) |
| `feature add <pkg> [feature]` | Add features (auto-detects if feature omitted) |
| `feature list` | List available features |
| `pr <pkg>` | Open a pull request |
| `execute <pkg>` | Run a spec-driven workflow (plan → review → implement) on the package |
| `generate-sample-app` | Generate a sample application |

### Utility Commands

| Command | Description |
|---------|-------------|
| `status <pkg>` | Show workflow progress |
| `list` | List all integration workflows |
| `clean <pkg>` | Delete workflow state |
| `checkpoints <pkg>` | List workflow checkpoints |
| `rollback <pkg> <step>` | Roll back to a previous step |
| `diff <pkg>` | View integration changes |
| `open <pkg>` | Open integration in IDE |
| `claude <pkg>` | Start Claude Code review session |
| `update` | Update toolkit to latest version via dogbrew |
| `setup` | Install missing dependencies and configure the toolkit (first run) |
| `doctor` | Check all prerequisites and environment health |
| `doctor --json` | Machine-readable health check output (for CI / agents) |
| `smoke` | End-to-end smoke test: spawn an agent and verify the framework works |
| `config init` | Initialize configuration interactively |
| `config list` | List configured repositories |
| `config add-repo <name> <path>` | Add a repository |
| `config remove-repo <name>` | Remove a repository |

### Shared Options

These options apply to all workflow commands (`analyze`, `create`, `test`, `lint`, `review`, `semantic`, `llm-obs`, `pr`):

| Option | Description |
|--------|-------------|
| `-r, --repository <repo>` | Target repository (default: dd_trace_js) |
| `--mode=guided\|agent` | Execution mode (`create` only, default: guided) |
| `--headless` | Run without user interaction |
| `--fresh` | Clear existing state before running |
| `--from=<step>` | Restart from a specific step. Rewinds workflow state only — files on disk in the target repo are untouched. |
| `--rollback-git` | Pair with `--from`: also reset the target repo's working tree to the git snapshot taken at the start of `<step>`, so the re-run sees a clean slate. Use this when a later step wrote files you don't want to inherit, or when the earlier step is non-idempotent against existing edits. |
| `--skip=<steps>` | Comma-separated steps to skip |
| `--model=<model>` | Model override for agent steps (e.g., `opus`, `sonnet`) |
| `--prompt="..."` | Custom guidance for the agent |
| `--base-branch=<branch>` | Base branch in target repo (default: auto-detect) |

### Command-Specific Options

| Command | Option | Description |
|---------|--------|-------------|
| `test` | `--max-iterations N` | Max fix iterations |
| `lint` | `--paths, -p <paths>` | Paths to lint (default: plugin path) |
| `lint` | `--fix` | Auto-fix lint issues |
| `lint` | `--max-iterations N` | Max fix iterations |
| `llm-obs` | `--max-fix-iterations N` | Max fix iterations |
| `semantic` | `--max-iterations N` | Max fix iterations |
| `pr` | `--babysit` | Watch CI + review comments, auto-fix until green |
| `execute` | `--spec <path>` | Spec markdown file driving the workflow (required) |
| `execute` | `--source <url\|file\|->` | Dynamic context merged with `--spec`. GitHub issue/PR or Actions failed-job URLs are fetched via `gh`; a file path is read; `-` reads stdin. Unrecognized `http(s)` URLs error rather than silently becoming inline text. |
| `generate-sample-app` | `--spec <file-or-text>` | App specification |
| `generate-sample-app` | `--output-dir <path>` | Output directory (default: cwd) |
| `generate-sample-app` | `--language <lang>` | Target language (e.g., node, python) |
| `clean` | `-f, --force` | Skip confirmation |
| `clean` | `--workflow <name>` | Clean specific workflow (default: all) |
| `clean` | `--revert-externals` | Also revert externals.json (llmobs only) |

### Available Features

| Feature | Description |
|---------|-------------|
| `dsm` | Data Streams Monitoring - track message queues and streams |
| `context_propagation` | Distributed trace context across services |
| `dbm` | Database Monitoring - SQL comment injection |
| `peer_service` | Peer service detection for service maps |

### Environment Variables

| Variable | Purpose |
|----------|---------|
| `DD_TRACER_REPO` | Path to dd-trace-js repository (required) |
| `ANTHROPIC_API_KEY` | Claude API key for agent steps |
| `DD_APM_BASE_BRANCH` | Base branch in target repo (default: auto-detect) |
| `DD_APM_DEBUG=1` | Enable debug output |
| `DD_APM_SKIP_DD_AUTH=1` | Bypass dd-auth invocation and use existing `DD_API_KEY`/`DD_APP_KEY` from the environment. Org 2 validation is still enforced. Default `0`. |

## How It Works

1. **Analysis** - AI agent analyzes target library, identifies instrumentation points
2. **Enrichment** - AST parsing extracts exact file locations and signatures
3. **Generation** - Plugin code generated from analysis
4. **Testing** - Integration tests with iterative auto-fix
5. **Review** - Parallel code checks with auto-fix
6. **Features** - Detect and implement DSM, context propagation, etc.

## Documentation

| Document | Description |
|----------|-------------|
| [Quick Start](docs/QUICKSTART.md) | Getting started, troubleshooting |
| [Claude Code Plugin](plugin/README.md) | Plugin install, commands, drive styles |
| [Setup & Doctor](docs/SETUP-DOCTOR.md) | Prerequisite manifest, `setup`/`doctor`/`smoke` commands |
| [Writing Workflows](docs/WRITING-WORKFLOWS.md) | How to create workflows, steps, agents |
| [Contributing](docs/CONTRIBUTING.md) | Code style, architecture, PR checklist |
| [Releasing](docs/RELEASING.md) | How to cut a release |
| [API Reference](https://datadog.github.io/apm-instrumentation-toolkit/) | Auto-generated API docs |

**Workflow docs:** [new-integration](docs/workflows/new-integration.md) | [feature](docs/workflows/feature.md) | [test](docs/workflows/test.md) | [reviewer](docs/workflows/reviewer.md) | [lint](docs/workflows/lint.md) | [llmobs](docs/workflows/llmobs.md) | [semantic](docs/workflows/semantic-tests.md) | [sample-app](docs/workflows/sample-app.md)

**Architecture:** [Anubis Core](docs/ANUBIS-CORE.md) | [Anubis APM](docs/ANUBIS-APM.md) | [Diagram](docs/ARCHITECTURE-DIAGRAM.md)

### Contributing with Claude Code

```bash
claude
/init-anubis
```

The `/init-anubis` command loads project-specific skills that give Claude context about architecture, code patterns, and debugging strategies.

### Drive workflows from Claude Code (plugin)

The toolkit ships a Claude Code plugin that lets you instrument packages without leaving your editor. Instead of switching to a terminal and parsing Rich TUI output, you drive the workflow through chat — Claude surfaces step outputs in plain language, explains trade-offs, and asks for your sign-off before expensive steps.

**Install once:**
```bash
claude plugin marketplace add git@github.com:DataDog/apm-instrumentation-toolkit.git
claude plugin install dd-apm-integration-ai-toolkit@dd-apm-integration-ai-toolkit
```

**Use from any Claude Code session:**
- `/instrument <package>` — start or resume an integration workflow. Works for `create`, `test`, `lint`, `feature`, and others; specify after the package name (e.g. `/instrument kafkajs test`).
- `/toolkit-setup` — first-time setup guide (VPN → auth → install → `config init`).

**Two drive styles — you pick at the start:**
- **Interactive:** Claude runs one step at a time, surfaces the output, and waits for review before proceeding. Best for unfamiliar packages or when you want tight control over targets and code.
- **Autonomous:** the full workflow runs end-to-end in the background. Claude monitors progress and surfaces the final result before suggesting a PR.

In both styles, Claude always pauses after `analyze` (targets determine everything downstream) and at workflow end (reviews generated code before a PR).

See [docs/QUICKSTART.md](docs/QUICKSTART.md) for setup instructions and [plugin/skills/drive-toolkit/SKILL.md](plugin/skills/drive-toolkit/SKILL.md) for the full driving guide.

## Development

```bash
pip install -e ".[dev]"
pytest tests/
ruff check anubis/ anubis_apm/
sphinx-build -E -b html -W docs/sphinx/source docs/sphinx/build
```
