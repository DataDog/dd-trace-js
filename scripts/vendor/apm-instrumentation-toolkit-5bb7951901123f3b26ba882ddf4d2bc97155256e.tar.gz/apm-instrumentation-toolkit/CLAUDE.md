Also see @AGENTS.md

**Load contributor knowledge:**
Run `/skill contributing` to load architecture and code style guidance, or read skills directly:
- `.claude/skills/contributing/SKILL.md` - Architecture, code style, where to add code
- `.claude/skills/debugging/SKILL.md` - Log locations, common issues
- `.claude/skills/anubis-workflow/SKILL.md` - Creating workflows and steps

`.claude/skills/` is the canonical skill tree. `.agents/skills` points there so non-Claude coding agents can load the same repo skills.
