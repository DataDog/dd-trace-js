"""Authoritative prerequisite manifest for the APM Instrumentation Toolkit.

Every external tool, service, or configuration the toolkit depends on is
defined here. dd-apm setup and dd-apm doctor both read from PREREQS.

Adding a new dependency
-----------------------
1. Write a _check_<name>() function returning a CheckResult
2. Add a Prereq entry to PREREQS
3. Run pytest tests/test_setup_prereqs.py to verify

Do not add the dependency anywhere else (README, preflight, config.py).
This file IS the documentation.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import urllib.parse
from dataclasses import dataclass
from typing import Callable, Optional

from anubis.core.tracing.config import (
    TracingPreflightError,
    _check_agent_reachable,
    get_resolved_agent_url,
)
from anubis.core.tracing.dd_auth import has_dd_api_key_in_env, is_dd_auth_available

logger = logging.getLogger(__name__)

try:
    from anubis_apm.storage.auth import _has_sso_profile as _check_sso_profile
except Exception:
    _check_sso_profile = None  # type: ignore[assignment]


@dataclass
class CheckResult:
    """Result of a single prerequisite check."""

    ok: bool
    message: str
    fixable: bool = False
    fix_cmd: Optional[list[str]] = None
    fix_note: Optional[str] = None


class Prereq:
    """A single external dependency, tool, or configuration requirement."""

    def __init__(
        self,
        name: str,
        description: str,
        required: bool,
        feature: Optional[str],
        check_fn: Callable[[], CheckResult],
    ) -> None:
        self.name = name
        self.description = description
        self.required = required
        self.feature = feature
        self._check_fn = check_fn

    def check(self) -> CheckResult:
        try:
            return self._check_fn()
        except Exception as e:
            return CheckResult(ok=False, message=f"check error: {e}")


# ---------------------------------------------------------------------------
# Check functions — one per prerequisite
# ---------------------------------------------------------------------------


def _check_anthropic_key() -> CheckResult:
    if os.environ.get("ANTHROPIC_API_KEY", "").strip():
        return CheckResult(ok=True, message="set")
    return CheckResult(
        ok=False,
        message="not set",
        fixable=False,
        fix_note="export ANTHROPIC_API_KEY=<key>  (get from https://console.anthropic.com/settings/keys)",
    )


def _check_dd_api_key() -> CheckResult:
    if has_dd_api_key_in_env():
        return CheckResult(ok=True, message="set")
    # When the env var isn't set, dd-auth provides the key at workflow startup
    # (run_preflight injects fresh Org 2 credentials). Report that rather than a
    # misleading "not set" — the dd-auth-session check below verifies it works.
    if is_dd_auth_available():
        return CheckResult(ok=True, message="provided by dd-auth at runtime")
    return CheckResult(
        ok=False,
        message="not set",
        fixable=False,
        fix_note="install dd-auth (brew install datadog/tap/dd-auth) — it provides credentials at startup",
    )


def _check_dd_app_key() -> CheckResult:
    if os.environ.get("DD_APP_KEY", "").strip():
        return CheckResult(ok=True, message="set")
    if is_dd_auth_available():
        return CheckResult(ok=True, message="provided by dd-auth at runtime")
    return CheckResult(
        ok=False,
        message="not set",
        fixable=False,
        fix_note=(
            "install dd-auth (brew install datadog/tap/dd-auth) "
            "or add DD_APP_KEY to ~/.dd-apm/.anubis/config.yaml — required for LLMObs experiment submission"
        ),
    )


def _check_runtime_app_key() -> CheckResult:
    """Verify the runtime DD_APP_KEY is an App Key, not a Personal Access Token.

    A PAT (ddpat_*) lacks the LLMObs intake write scope — APM traces accept
    but LLMObs payloads silently drop. This happens when a user ran
    ``eval "$(dd-auth --output)"`` without ``--force-app-key`` and the PAT
    persisted in their shell before the toolkit could override it.
    """
    app_key = os.environ.get("DD_APP_KEY", "").strip()
    if not app_key:
        return CheckResult(ok=True, message="(skipped — DD_APP_KEY not set)")
    if app_key.startswith("ddpat_"):
        return CheckResult(
            ok=False,
            message="DD_APP_KEY is a PAT (ddpat_*) — LLMObs traces will silently drop",
            fixable=False,
            fix_note=(
                'A previous `eval "$(dd-auth --output)"` (without --force-app-key) '
                "put a PAT in your shell. "
                "Unset DD_API_KEY DD_APP_KEY DD_SITE, restart your terminal, then re-run dd-apm."
            ),
        )
    return CheckResult(ok=True, message="App Key (not PAT)")


def _check_dd_auth() -> CheckResult:
    if shutil.which("dd-auth"):
        return CheckResult(ok=True, message="installed")
    return CheckResult(
        ok=False,
        message="not installed",
        fixable=True,
        fix_cmd=["brew", "install", "datadog/tap/dd-auth"],
    )


def _check_dd_auth_session() -> CheckResult:
    if not shutil.which("dd-auth"):
        return CheckResult(
            ok=False,
            message="dd-auth not installed — install it first",
            fixable=False,
            fix_note="brew install datadog/tap/dd-auth",
        )
    try:
        from anubis.core.tracing.dd_auth import get_org2_credentials  # noqa: PLC0415

        get_org2_credentials()
        return CheckResult(ok=True, message="authenticated (Org 2)")
    except Exception as exc:
        return CheckResult(
            ok=False,
            message=f"Org 2 auth failed: {exc}",
            fixable=False,
            fix_note="dd-auth --domain datad0g.com  (re-authenticate to Org 2)",
        )


def _check_docker() -> CheckResult:
    # Any docker-compatible runtime works (Colima, OrbStack, Rancher Desktop,
    # Docker Desktop, podman) — we only rely on the `docker` CLI talking to *some*
    # daemon via the active context. Don't steer users toward Docker Desktop
    # specifically, since many orgs are moving off it for licensing reasons.
    if os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "").lower() in ("1", "true"):
        return CheckResult(ok=True, message="(skipped — agentless mode)")

    # In non-agentless mode the toolkit's local agents must be running. Surface
    # where the bundled compose file lives in EVERY failure path below, so users
    # always know how to start the containers regardless of which check tripped.
    from anubis.core.config import ConfigLoader  # noqa: PLC0415

    compose_path = ConfigLoader().toolkit_root / "docker-compose.yml"
    compose_hint = f"Start the toolkit agents: docker compose -f {compose_path} up -d"

    if not shutil.which("docker"):
        return CheckResult(
            ok=False,
            message="not installed",
            fixable=False,
            fix_note=(
                "Install a container runtime (Colima, OrbStack, Rancher Desktop, or "
                f"Docker Desktop), then start the toolkit agents. {compose_hint}"
            ),
        )
    try:
        result = subprocess.run(["docker", "info"], capture_output=True, timeout=10)
        daemon_ok = result.returncode == 0
    except subprocess.TimeoutExpired:
        return CheckResult(
            ok=False,
            message="daemon check timed out",
            fixable=False,
            fix_note=f"Start your container runtime (e.g. `colima start`, `orb start`). {compose_hint}",
        )
    if not daemon_ok:
        return CheckResult(
            ok=False,
            message="installed but daemon not reachable",
            fixable=False,
            fix_note=f"Start your container runtime (e.g. `colima start`, `orb start`). {compose_hint}",
        )

    # Daemon is up — the toolkit's Org 2 agent (port 18127) must also be running.
    if not _check_agent_reachable("http://localhost:18127/info"):
        return CheckResult(
            ok=False,
            message="daemon running, but toolkit agents are not (port 18127 unreachable)",
            fixable=False,
            fix_note=compose_hint,
        )
    return CheckResult(ok=True, message="running (daemon + toolkit agents)")


def _check_gh() -> CheckResult:
    if not shutil.which("gh"):
        return CheckResult(
            ok=False,
            message="not installed",
            fixable=True,
            fix_cmd=["brew", "install", "gh"],
        )
    try:
        result = subprocess.run(
            ["gh", "api", "user", "--silent"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            return CheckResult(ok=True, message="installed and authenticated")
        return CheckResult(
            ok=False,
            message="installed but not authenticated",
            fixable=False,
            fix_note="gh auth login  (or: export GH_TOKEN=$(ddtool auth github token))",
        )
    except subprocess.TimeoutExpired:
        return CheckResult(
            ok=False,
            message="installed but auth check timed out",
            fixable=False,
            fix_note="gh auth login",
        )


def _check_node() -> CheckResult:
    if not shutil.which("node"):
        return CheckResult(
            ok=False,
            message="not installed (18+ required)",
            fixable=True,
            fix_cmd=["brew", "install", "node@18"],
        )
    try:
        result = subprocess.run(["node", "--version"], capture_output=True, text=True, timeout=5)
        version = result.stdout.strip().lstrip("v")
        major = int(version.split(".")[0])
        if major >= 18:
            return CheckResult(ok=True, message=f"v{version}")
        return CheckResult(
            ok=False,
            message=f"v{version} found, 18+ required",
            fixable=True,
            fix_cmd=["brew", "install", "node@18"],
        )
    except Exception as e:
        logger.debug("node version check failed: %s", e)
        return CheckResult(
            ok=False,
            message="version check failed",
            fixable=False,
            fix_note="Install Node.js 18+: https://nodejs.org/",
        )


def _check_aws_vault() -> CheckResult:
    if shutil.which("aws-vault"):
        return CheckResult(ok=True, message="installed")
    return CheckResult(
        ok=False,
        message="not installed",
        fixable=True,
        fix_cmd=["brew", "install", "aws-vault", "awscli"],
    )


def _check_aws_vault_session() -> CheckResult:
    if not shutil.which("aws-vault"):
        return CheckResult(
            ok=False,
            message="aws-vault not installed — install it first",
        )
    if _check_sso_profile is None or not _check_sso_profile():
        return CheckResult(
            ok=False,
            message="SSO profile not configured",
            fixable=False,
            fix_note="dd-apm sync setup --fix",
        )
    try:
        from anubis_apm.storage.auth import _get_credentials_via_aws_vault  # noqa: PLC0415

        creds = _get_credentials_via_aws_vault()
        if creds:
            return CheckResult(ok=True, message="SSO authenticated")
        return CheckResult(
            ok=False,
            message="SSO profile configured but credentials unavailable",
            fixable=False,
            fix_note="dd-apm sync setup --fix  (SSO session may have expired)",
        )
    except Exception as exc:
        return CheckResult(
            ok=False,
            message=f"credential check failed: {exc}",
            fixable=False,
            fix_note="dd-apm sync setup --fix",
        )


def _check_dd_trace_js_node_modules() -> CheckResult:
    """Verify dd_trace_js adapter node_modules are installed.

    The dd_trace_js adapter bundles Node.js tools (dd-generate for code
    generation, dd-analyze for static analysis). Their node_modules are
    excluded from PyInstaller bundles and from git, so they must be
    installed separately via npm ci.

    Missing modules cause hard failures:
    - eslint missing → dd-compile can't lint generated code
    - esquery missing → method extractor can't query AST nodes
    - meriyah missing → method extractor can't parse JS
    """
    if not shutil.which("node") or not shutil.which("npm"):
        return CheckResult(ok=True, message="(skipped — node/npm not installed)")

    try:
        from anubis.core.config import get_config  # noqa: PLC0415

        adapter_dir = (
            get_config().toolkit_install_root / "anubis_apm" / "repo_adapters_impl" / "dd_trace_js"
        )
    except Exception:
        return CheckResult(ok=True, message="(skipped — config not available)")

    if not adapter_dir.exists():
        return CheckResult(ok=True, message="(skipped — dd_trace_js adapter not present)")

    required_modules = ["eslint", "esquery", "meriyah"]
    missing = [m for m in required_modules if not (adapter_dir / "node_modules" / m).exists()]

    if not missing:
        return CheckResult(ok=True, message="installed")

    lock = adapter_dir / "package-lock.json"
    install_cmd = ["npm", "ci"] if lock.exists() else ["npm", "install"]
    return CheckResult(
        ok=False,
        message=f"node_modules missing: {', '.join(missing)}",
        fixable=True,
        fix_cmd=[*install_cmd, "--prefix", str(adapter_dir), "--omit=dev"],
    )


def _check_mitmproxy() -> CheckResult:
    if shutil.which("mitmdump"):
        return CheckResult(ok=True, message="installed")
    return CheckResult(
        ok=False,
        message="not installed",
        fixable=True,
        fix_cmd=["brew", "install", "mitmproxy"],
    )


def _check_config() -> CheckResult:
    try:
        from anubis.core.config import ConfigLoader  # noqa: PLC0415

        if ConfigLoader().exists():
            return CheckResult(ok=True, message="configured")
        return CheckResult(
            ok=False,
            message="not configured",
            fixable=False,
            fix_note="dd-apm config init",
        )
    except Exception as e:
        return CheckResult(ok=False, message=f"config check error: {e}")


_AGENTLESS_INTAKE_HOSTS = frozenset({
    "public-trace-http-intake.logs.datadoghq.com",
    "trace.agent.datadoghq.com",
})


def _check_trace_routing() -> CheckResult:
    """Verify the live tracer is configured for the toolkit's Org 2 agent (port 18127),
    or for the Datadog agentless intake when agentless mode is enabled.

    Reads the resolved URL from the tracer's writer rather than os.environ, since
    ddtrace snapshots its agent URL at import time — env-var checks miss the case
    where ddtrace was imported before init_env() force-overrode DD_TRACE_AGENT_URL.
    """
    agentless = os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "true").lower() not in ("0", "false")

    try:
        url = get_resolved_agent_url()
    except TracingPreflightError as e:
        return CheckResult(
            ok=False,
            message=str(e),
            fixable=False,
            fix_note="Report this to the toolkit team — preflight cannot verify trace routing.",
        )
    try:
        parsed = urllib.parse.urlparse(url)
        if parsed.port == 18127:
            return CheckResult(ok=True, message=f"correctly routed to {url}")
        if agentless and parsed.hostname in _AGENTLESS_INTAKE_HOSTS:
            return CheckResult(ok=True, message=f"agentless mode — routed to {url}")
        return CheckResult(
            ok=False,
            message=f"tracer writing to {url} — expected port 18127",
            fixable=False,
            fix_note=(
                "ddtrace was imported before init_env() ran, or `which dd-apm` resolves to a stale "
                "checkout that doesn't force-override DD_TRACE_AGENT_URL. Update the toolkit-root "
                "checkout to `main` (or the latest release) and unset any inherited "
                "DD_TRACE_AGENT_URL/DD_TRACE_AGENT_PORT/DD_AGENT_HOST shell vars."
            ),
        )
    except Exception as e:
        logger.debug("could not parse tracer agent URL %r: %s", url, e)
        return CheckResult(ok=False, message=f"could not parse tracer agent URL: {url!r}")


# ---------------------------------------------------------------------------
# Manifest — the single source of truth
# ---------------------------------------------------------------------------

PREREQS: list[Prereq] = [
    Prereq(
        name="config",
        description="dd-apm config — toolkit must be configured before use",
        required=True,
        feature=None,
        check_fn=_check_config,
    ),
    Prereq(
        name="anthropic-key",
        description="ANTHROPIC_API_KEY — required to run Claude agents",
        required=True,
        feature=None,
        check_fn=_check_anthropic_key,
    ),
    Prereq(
        name="dd-api-key",
        description="DD_API_KEY — Datadog API key for APM tracing and LLMObs (Org 2)",
        required=True,
        feature=None,
        check_fn=_check_dd_api_key,
    ),
    Prereq(
        name="dd-app-key",
        description="DD_APP_KEY — Datadog App key for LLMObs experiment submission",
        required=True,
        feature=None,
        check_fn=_check_dd_app_key,
    ),
    Prereq(
        name="runtime-app-key",
        description="DD_APP_KEY must be an App Key (not a PAT) — PATs silently drop LLMObs traces",
        required=True,
        feature=None,
        check_fn=_check_runtime_app_key,
    ),
    Prereq(
        name="dd-auth",
        description="dd-auth CLI — OAuth tool for Datadog Org 2 credentials",
        required=True,
        feature=None,
        check_fn=_check_dd_auth,
    ),
    Prereq(
        name="dd-auth-session",
        description="dd-auth session — must be authenticated to Datadog Org 2",
        required=True,
        feature=None,
        check_fn=_check_dd_auth_session,
    ),
    Prereq(
        name="docker",
        description="Docker — required to run local Datadog and test agents",
        required=True,
        feature=None,
        check_fn=_check_docker,
    ),
    Prereq(
        name="gh",
        description="GitHub CLI — required to clone tracer repos and open PRs",
        required=True,
        feature=None,
        check_fn=_check_gh,
    ),
    Prereq(
        name="node",
        description="Node.js 18+ — required for dd-trace-js workflows",
        required=True,
        feature="dd-trace-js",
        check_fn=_check_node,
    ),
    Prereq(
        name="dd-trace-js-node-modules",
        description="dd_trace_js adapter node_modules — eslint, meriyah, and other JS tool deps",
        required=True,
        feature="dd-trace-js",
        check_fn=_check_dd_trace_js_node_modules,
    ),
    Prereq(
        name="aws-vault",
        description="aws-vault CLI — required for S3 experience store",
        required=False,
        feature="s3-sync",
        check_fn=_check_aws_vault,
    ),
    Prereq(
        name="aws-vault-session",
        description="aws-vault session — SSO credentials for S3 experience store",
        required=False,
        feature="s3-sync",
        check_fn=_check_aws_vault_session,
    ),
    Prereq(
        name="mitmproxy",
        description="mitmproxy — required for eval --run (AI Gateway routing)",
        required=False,
        feature="evals",
        check_fn=_check_mitmproxy,
    ),
    Prereq(
        name="trace-routing",
        description="Trace agent routing — DD_TRACE_AGENT_URL must point to port 18127",
        required=True,
        feature=None,
        check_fn=_check_trace_routing,
    ),
]


def run_checks(
    required_only: bool = False,
    skip_features: Optional[set[str]] = None,
) -> list[tuple[Prereq, CheckResult]]:
    """Run all prerequisite checks and return (prereq, result) pairs.

    Args:
        required_only: If True, only run required prereqs.
        skip_features: Feature names to exclude (e.g. {"dd-trace-js"} for smoke).
    """
    checks = [
        p
        for p in PREREQS
        if (not required_only or p.required)
        and (skip_features is None or p.feature not in skip_features)
    ]
    return [(p, p.check()) for p in checks]
