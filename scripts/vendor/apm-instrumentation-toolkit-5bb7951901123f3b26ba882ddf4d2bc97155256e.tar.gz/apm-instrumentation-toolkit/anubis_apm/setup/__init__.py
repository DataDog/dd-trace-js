"""APM integrations setup - configures anubis framework with APM resources.

Exports both the framework initializer (for workflow commands) and the
prerequisite manifest (for dd-apm setup / doctor).

Usage:
    from anubis_apm import setup
    setup.init()

    from anubis_apm.setup import PREREQS, run_checks
"""

from pathlib import Path

from anubis.core.config import get_config
from anubis.core.context import set_repo_adapter_factory
from anubis.core.resources import ResourceManager, set_global_resource_manager

from ..repo_adapters import get_apm_adapter
from .prereqs import PREREQS, CheckResult, Prereq, run_checks

_INTEGRATIONS_ROOT = Path(__file__).parent.parent

_initialized = False


def init(repository: str | None = None) -> None:
    """Initialize anubis with APM-specific resources.

    Configures:
        - Global ResourceManager with APM prompts, skills, and system prompt
        - RepoAdapter factory for APM repository operations

    Args:
        repository: Repository to use (defaults to config's default_repository)

    Note:
        Safe to call multiple times - subsequent calls are no-ops.
    """
    global _initialized
    if _initialized:
        return

    config = get_config()
    repo_name = repository or config.default_repository
    if not repo_name:
        raise RuntimeError(
            "No repository specified and no default_repository in config.\n"
            "Run 'dd-apm config init' to set up configuration."
        )

    config.get_repo(repo_name)

    system_prompt_path = _INTEGRATIONS_ROOT / "system-prompt.md"
    system_prompt = system_prompt_path.read_text() if system_prompt_path.exists() else None

    manager = ResourceManager(
        config=config,
        prompts_root=_INTEGRATIONS_ROOT / "prompts",
        skills_root=_INTEGRATIONS_ROOT / "agent" / "skills",
        hooks_root=_INTEGRATIONS_ROOT / "agent" / "hooks",
        system_prompt=system_prompt,
    )

    set_global_resource_manager(manager)
    set_repo_adapter_factory(get_apm_adapter)
    _initialized = True


def reset() -> None:
    """Reset initialization state (primarily for testing)."""
    global _initialized
    _initialized = False


__all__ = [
    "PREREQS",
    "CheckResult",
    "Prereq",
    "init",
    "reset",
    "run_checks",
]
