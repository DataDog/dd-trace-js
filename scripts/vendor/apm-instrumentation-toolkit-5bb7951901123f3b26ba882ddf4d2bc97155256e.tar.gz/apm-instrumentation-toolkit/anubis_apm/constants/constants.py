"""Integration category constants and utilities.

Provides canonical category definitions for APM integrations.
Source of truth is the apm-semantic-conventions package.
"""

import json
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

_CONSTANTS_FILE = Path(__file__).parent / "integration_categories.json"

# Better descriptions than auto-generated ones from semantic conventions
_DESCRIPTION_OVERRIDES = {
    "aws": "AWS SDK clients",
    "cache": "Cache clients (Redis, Memcached, etc.)",
    "database": "Database clients (SQL, NoSQL, key-value stores)",
    "graphql": "GraphQL servers and clients",
    "grpc-client": "gRPC client libraries",
    "grpc-server": "gRPC server frameworks",
    "http-client": "HTTP client libraries",
    "http-server": "Web frameworks and HTTP servers",
    "llm": "LLM and AI providers (OpenAI, Anthropic, etc.)",
    "messaging": "Messaging systems (message queues, pub/sub, event streaming)",
    "search": "Search engines (Elasticsearch, OpenSearch)",
}

# Additional categories not in semantic conventions
_EXTRA_CATEGORIES = {
    "logging": {"description": "Logging libraries", "valid_span_kinds": ["internal"]},
    "library": {
        "description": "General purpose libraries",
        "valid_span_kinds": ["internal", "client", "server", "producer", "consumer"],
    },
    "custom": {
        "description": "Custom integrations",
        "valid_span_kinds": ["internal", "client", "server", "producer", "consumer"],
    },
    "not_applicable": {
        "description": "When none of the above apply",
        "valid_span_kinds": ["internal"],
    },
}

# Category name aliases
_ALIASES = {
    "web-server": "http-server",
    "web_server": "http-server",
    "web-framework": "http-server",
    "web_framework": "http-server",
    "webserver": "http-server",
    "web-client": "http-client",
    "web_client": "http-client",
    "webclient": "http-client",
    "http_server": "http-server",
    "http_client": "http-client",
    "grpc_client": "grpc-client",
    "grpc_server": "grpc-server",
    "ai": "llm",
}

# Try to load from apm-semantic-conventions package first (source of truth)
_CONSTANTS: Dict = {"categories": {}, "aliases": {}}

try:
    from apm_semantic_conventions import get_category_info

    _category_info = get_category_info()

    # Build categories with better descriptions
    categories = {}
    for name, info in sorted(_category_info.items()):
        categories[name] = {
            "description": _DESCRIPTION_OVERRIDES.get(name, info["description"]),
            "valid_span_kinds": sorted(info["valid_span_kinds"]),
        }

    # Add extra categories
    categories.update(_EXTRA_CATEGORIES)

    _CONSTANTS["categories"] = categories
    _CONSTANTS["aliases"] = _ALIASES

except ImportError:
    # Fallback to JSON file if package not installed
    if _CONSTANTS_FILE.exists():
        with open(_CONSTANTS_FILE, "r") as f:
            _CONSTANTS = json.load(f)
    else:
        # Minimal fallback
        _CONSTANTS["categories"] = _EXTRA_CATEGORIES
        _CONSTANTS["aliases"] = _ALIASES


class IntegrationCategory(str, Enum):
    """Canonical integration categories for APM instrumentation."""

    HTTP_SERVER = "http-server"
    HTTP_CLIENT = "http-client"
    DATABASE = "database"
    CACHE = "cache"
    SEARCH = "search"
    MESSAGING = "messaging"
    GRPC_CLIENT = "grpc-client"
    GRPC_SERVER = "grpc-server"
    GRAPHQL = "graphql"
    AWS = "aws"
    LLM = "llm"
    LOGGING = "logging"
    LIBRARY = "library"
    CUSTOM = "custom"
    NOT_APPLICABLE = "not_applicable"

    @classmethod
    def values(cls) -> List[str]:
        """Return list of all valid category values."""
        return [member.value for member in cls]

    @classmethod
    def from_string(cls, value: str) -> Optional["IntegrationCategory"]:
        """Convert a string to IntegrationCategory, handling aliases."""
        normalized = normalize_category(value)
        for member in cls:
            if member.value == normalized:
                return member
        return None


# Build maps from loaded constants
CATEGORY_SPAN_KIND_MAP: Dict[str, List[str]] = {
    cat_name: cat_data["valid_span_kinds"]
    for cat_name, cat_data in _CONSTANTS["categories"].items()
}

CATEGORY_ALIASES: Dict[str, str] = _CONSTANTS.get("aliases", _ALIASES)


def normalize_category(category: str) -> str:
    """Normalize a category string to its canonical form."""
    if not category:
        return IntegrationCategory.CUSTOM.value

    lower = category.lower().strip()

    # Check aliases first
    if lower in CATEGORY_ALIASES:
        return CATEGORY_ALIASES[lower]

    # Check if it's a canonical category
    if lower in _CONSTANTS["categories"]:
        return lower

    return lower


def get_valid_span_kinds(category: str) -> List[str]:
    """Get valid span_kinds for a category."""
    normalized = normalize_category(category)
    return CATEGORY_SPAN_KIND_MAP.get(normalized, ["internal"])


def get_category_description(category: str) -> str:
    """Get the description for a category."""
    normalized = normalize_category(category)
    cat_data = _CONSTANTS["categories"].get(normalized, {})
    description = cat_data.get("description", "")
    return str(description) if description else ""


def list_categories() -> List[str]:
    """Return list of all valid canonical category names."""
    return list(_CONSTANTS["categories"].keys())


__all__ = [
    "IntegrationCategory",
    "CATEGORY_SPAN_KIND_MAP",
    "CATEGORY_ALIASES",
    "normalize_category",
    "get_valid_span_kinds",
    "get_category_description",
    "list_categories",
]
