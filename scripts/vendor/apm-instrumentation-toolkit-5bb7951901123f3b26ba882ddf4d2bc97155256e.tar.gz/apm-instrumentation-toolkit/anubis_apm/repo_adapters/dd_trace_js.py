"""dd-trace-js adapter - extends generic adapter with APM-specific methods."""

import logging
import os
import re
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional

import yaml

from anubis.core.config import get_config
from anubis.core.git import revert_tracked_files
from anubis.core.repo_adapters import NodeRepoAdapter

from .base import APMAdapterMixin

logger = logging.getLogger(__name__)


class DDTraceJsAdapter(NodeRepoAdapter, APMAdapterMixin):
    """Adapter for dd-trace-js - extends generic with dd-trace specific functionality.

    Inherits:
    - Generic methods from NodeRepoAdapter (lint, install, etc.)
    - APM method interface from APMAdapterMixin (get_plugin_path, etc.)
    """

    language: str = "javascript"
    repository_id: str = "dd_trace_js"

    REFERENCE_INTEGRATIONS: ClassVar[dict[str, list[str]]] = {
        # Semantic convention categories (from apm_semantic_conventions.list_categories())
        "aws": [
            "packages/datadog-plugin-aws-sdk/",
        ],
        "cache": [
            "packages/datadog-plugin-redis/",
            "packages/datadog-plugin-ioredis/",
            "packages/datadog-plugin-memcached/",
        ],
        "database": [
            "packages/datadog-plugin-pg/",
            "packages/datadog-plugin-mysql/",
            "packages/datadog-plugin-mysql2/",
        ],
        "graphql": [
            "packages/datadog-plugin-graphql/",
        ],
        "grpc-client": [
            "packages/datadog-plugin-grpc/",
        ],
        "grpc-server": [
            "packages/datadog-plugin-grpc/",
        ],
        "http-client": [
            "packages/datadog-plugin-http/",
            "packages/datadog-plugin-fetch/",
            "packages/datadog-plugin-undici/",
        ],
        "http-server": [
            "packages/datadog-plugin-express/",
            "packages/datadog-plugin-fastify/",
            "packages/datadog-plugin-koa/",
        ],
        "llm": [
            "packages/datadog-plugin-openai/",
            "packages/datadog-plugin-langchain/",
        ],
        "messaging": [
            "packages/datadog-plugin-kafkajs/",
            "packages/datadog-plugin-amqplib/",
            "packages/datadog-plugin-rhea/",
        ],
        "search": [
            "packages/datadog-plugin-elasticsearch/",
            "packages/datadog-plugin-opensearch/",
        ],
        # Datadog feature categories (FeatureId values)
        "dsm": [
            "packages/datadog-plugin-kafkajs/",
            "packages/datadog-plugin-amqplib/",
            "packages/datadog-plugin-rhea/",
        ],
        "context_propagation": [
            "packages/datadog-plugin-kafkajs/",
            "packages/datadog-plugin-amqplib/",
            "packages/datadog-plugin-aws-sdk/",
        ],
        "dbm": [
            "packages/datadog-plugin-mysql/",
            "packages/datadog-plugin-pg/",
            "packages/datadog-plugin-mysql2/",
        ],
        "peer_service": [
            "packages/datadog-plugin-http/",
            "packages/datadog-plugin-redis/",
            "packages/datadog-plugin-pg/",
        ],
    }

    @property
    def adapter_dir(self) -> Path:
        """Get adapter directory (bundled read-only resource)."""
        return (
            get_config().toolkit_install_root / "anubis_apm" / "repo_adapters_impl" / "dd_trace_js"
        )

    def get_plugin_path(self, integration_name: str) -> str:
        """Get the path to a Node.js plugin directory.

        Args:
            integration_name: Name of the integration (e.g., '@openai/agents', 'redis')

        Returns:
            Path to plugin directory (e.g., 'packages/datadog-plugin-openai-agents/')
        """
        normalized = integration_name.replace("@", "").replace("/", "-").replace("_", "-")
        return f"packages/datadog-plugin-{normalized}/"

    def get_test_file_path(self, integration_name: str) -> str:
        """Get the path to the test file for a Node.js integration.

        Args:
            integration_name: Name of the integration (e.g., '@openai/agents', 'redis')

        Returns:
            Path to test file (e.g., 'packages/datadog-plugin-openai-agents/test/index.spec.js')
        """
        normalized = integration_name.replace("@", "").replace("/", "-").replace("_", "-")
        return f"packages/datadog-plugin-{normalized}/test/index.spec.js"

    def get_test_command(self, integration_name: str, output_dir: Optional[Path] = None) -> str:
        """Return the CI-equivalent plugin test command.

        Matches what CI runs (``.github/workflows/apm-integrations.yml`` →
        ``yarn test:plugins:ci``): ``PLUGINS=<name> npm run test:plugins``.

        The previous ``dd-debug.js`` wrapper observed only the test driver
        process, so plugin integration tests that spawn child processes
        via ``spawnPluginIntegrationTestProc`` (router, kafkajs, …) looked
        like they had "no channel subscriptions" because the channels
        fire in the child, which dd-debug can't see. That was misdiagnosed
        by the diagnosis agent as ``esmFirst``/instrumentation gaps when
        CI proves the tests pass against the same code.

        ``OTEL_*_EXPORTER`` env vars are unset because Datadog-telemetry-
        instrumented terminals (Claude Code, Cursor) set
        ``OTEL_TRACES_EXPORTER=otlp``, which routes spans through the OTLP
        exporter and bypasses the in-process ``FakeAgent`` — every span-
        asserting plugin test then silently times out.

        Args:
            integration_name: Name of the integration to test.
            output_dir: Ignored; kept for base-class signature parity.
                Test output is captured by the workflow's own log streaming.

        Returns:
            Shell command string to run plugin tests.
        """
        normalized = integration_name.replace("@", "").replace("/", "-").replace("_", "-")
        return (
            "unset OTEL_TRACES_EXPORTER OTEL_LOGS_EXPORTER OTEL_METRICS_EXPORTER "
            f"&& PLUGINS={shlex.quote(normalized)} npm run test:plugins:ci"
        )

    evalya_language_prefix: str = "node"
    # Package list is computed at runtime from the evalya OCI cache
    # (~/.evalya/cache/.../defs/iat/node-*) by APMAdapterMixin.get_evalya_packages.

    # Maps dd-trace-js plugin names to evalya def suffixes when they differ.
    # Key: plugin name (used as integration_name everywhere in the eval).
    # Value: evalya def suffix (the part after "node-" in the OCI path).
    # Example: "http" plugin → "defs/iat/node-http-client" evalya def.
    _EVALYA_DEF_NAME_MAP: ClassVar[dict[str, str]] = {
        "http": "http-client",
    }

    def get_evalya_def_path(self, package: str) -> Optional[str]:
        normalized = package.replace("@", "").replace("/", "-").replace("_", "-").lower()
        def_suffix = self._EVALYA_DEF_NAME_MAP.get(normalized, normalized)
        return f"defs/iat/node-{def_suffix}"

    def get_evalya_packages(self) -> list[str]:
        """Scan OCI cache and remap def names back to plugin names where they differ."""
        raw = super().get_evalya_packages()
        reverse_map = {v: k for k, v in self._EVALYA_DEF_NAME_MAP.items()}
        return [reverse_map.get(p, p) for p in raw]

    def setup_tracing_precheck(self, integration_name: str, ctx: Any) -> None:
        """Set dd-trace-js tracing precheck context values."""
        repo_root = get_config().get_repo_root(ctx.repository)
        plugin_path = repo_root / self.get_plugin_path(integration_name)
        ctx.set("tracing_plugin_path", str(plugin_path))
        ctx.set("tracing_test_command", self.get_test_command(integration_name))

    def get_llmobs_plugin_path(self, integration_name: str) -> str:
        """Get the path to the LLMObs plugin directory for an integration."""
        return f"packages/dd-trace/src/llmobs/plugins/{integration_name}/"

    def get_llmobs_test_file_path(self, integration_name: str) -> str:
        """Get the path to the LLMObs test spec file for an integration."""
        return f"packages/dd-trace/test/llmobs/plugins/{integration_name}/index.spec.js"

    def get_llmobs_cassette_dir(self, integration_name: str) -> str:
        """Get the VCR cassette directory for an LLMObs integration."""
        return f"test/llmobs/plugins/{integration_name}/cassettes"

    def get_llmobs_code_paths(self, integration_name: str) -> dict:
        """Get paths needed for LLMObs code generation.

        Returns a dict with keys:
        - ``plugin_src_dir``: path to the plugin source directory (e.g. where index.js lives)
        """
        plugin_path = self.get_plugin_path(integration_name)
        return {
            "plugin_src_dir": f"{plugin_path}src",
        }

    def get_llmobs_test_command(
        self,
        integration_name: str,
        working_dir: str,
        test_file: str,
        output_file: Optional[str] = None,
    ) -> str:
        """Get the command to run LLMObs tests for an integration."""
        cmd = f"cd {shlex.quote(working_dir)} && PLUGINS={shlex.quote(integration_name)} npx mocha {shlex.quote(test_file)}"
        if output_file:
            cmd += f" 2>&1 | tee {shlex.quote(output_file)}"
        return cmd

    def clean_llmobs_artifacts(
        self,
        integration_name: str,
        repo_root: "Path",
        revert_externals: bool = False,
    ) -> dict:
        """Remove LLMObs-generated files for an integration.

        Removes the LLMObs plugin directory and test directory, and reverts
        any uncommitted changes to the CompositePlugin index.js.

        Returns:
            dict with keys 'removed', 'reverted', 'errors' (lists of strings)
        """
        removed = []
        reverted = []
        errors = []

        # Remove LLMObs plugin directory
        plugin_dir = repo_root / self.get_llmobs_plugin_path(integration_name)
        if plugin_dir.exists():
            try:
                shutil.rmtree(plugin_dir)
                removed.append(str(plugin_dir.relative_to(repo_root)))
            except OSError as e:
                errors.append(f"Failed to remove plugin: {e}")

        # Remove LLMObs test directory
        test_file = repo_root / self.get_llmobs_test_file_path(integration_name)
        test_dir = test_file.parent
        if test_dir.exists():
            try:
                shutil.rmtree(test_dir)
                removed.append(str(test_dir.relative_to(repo_root)))
            except OSError as e:
                errors.append(f"Failed to remove tests: {e}")

        # Revert CompositePlugin changes (if tracked by git)
        composite_plugin = repo_root / self.get_plugin_path(integration_name) / "src" / "index.js"
        if composite_plugin.exists():
            try:
                result = subprocess.run(
                    ["git", "diff", "--name-only", str(composite_plugin.relative_to(repo_root))],
                    cwd=str(repo_root),
                    capture_output=True,
                    text=True,
                    check=True,
                )
                if result.stdout.strip():
                    subprocess.run(
                        ["git", "checkout", str(composite_plugin.relative_to(repo_root))],
                        cwd=str(repo_root),
                        capture_output=True,
                        text=True,
                        check=True,
                    )
                    reverted.append(str(composite_plugin.relative_to(repo_root)))
            except subprocess.CalledProcessError as e:
                errors.append(f"Failed to revert composite plugin: {e}")

        # Optionally revert externals.json
        if revert_externals:
            externals = repo_root / "packages" / "dd-trace" / "test" / "plugins" / "externals.json"
            if externals.exists():
                try:
                    result = subprocess.run(
                        ["git", "diff", "--name-only", str(externals.relative_to(repo_root))],
                        cwd=str(repo_root),
                        capture_output=True,
                        text=True,
                        check=True,
                    )
                    if result.stdout.strip():
                        subprocess.run(
                            ["git", "checkout", str(externals.relative_to(repo_root))],
                            cwd=str(repo_root),
                            capture_output=True,
                            text=True,
                            check=True,
                        )
                        reverted.append(str(externals.relative_to(repo_root)))
                except subprocess.CalledProcessError as e:
                    errors.append(f"Failed to revert externals.json: {e}")

        return {"removed": removed, "reverted": reverted, "errors": errors}

    def get_ground_truths_path(self) -> Optional[Path]:
        path = (
            Path(__file__).parent.parent
            / "eval"
            / "analyze"
            / "datasets"
            / "ground_truths"
            / "dd_trace_js"
        )
        return path if path.exists() else None

    def get_blind_copy_dirs(self, repo_root: Path) -> list[Path]:
        dirs = super().get_blind_copy_dirs(repo_root)
        packages_dir = repo_root / "packages"
        if packages_dir.exists():
            dirs.append(packages_dir)
        return dirs

    def get_instrumentation_deny_paths(
        self, repo_root: Path, integration_name: str = ""
    ) -> list[str]:
        instr_dir = repo_root / "packages" / "datadog-instrumentations" / "src"
        if not instr_dir.exists():
            return []
        if integration_name:
            normalized = integration_name.replace("@", "").replace("/", "-").replace("_", "-")
            plugin_dir = repo_root / f"packages/datadog-plugin-{normalized}"
            rewriter_dir = instr_dir / "helpers" / "rewriter" / "instrumentations"
            paths = [
                f"Read({instr_dir}/{normalized}.js)",
                f"Read({plugin_dir}/**)",
                f"Glob({plugin_dir}/**)",
            ]
            for ext in ("js", "json"):
                rewriter_file = rewriter_dir / f"{normalized}.{ext}"
                if rewriter_file.exists():
                    paths.append(f"Read({rewriter_file})")
            return paths
        return [f"Read({instr_dir}/**)"]

    def remove_integration(
        self,
        integration_name: str,
        repo_root: Path,
        git_source_root: Optional[Path] = None,
    ) -> List[str]:
        """Remove all files/changes for a generated dd-trace-js integration.

        Deletes plugin package, instrumentation file, and reverts registry
        entries so the integration can be regenerated cleanly for eval.

        ``git_source_root`` is the original git checkout. Required when
        ``repo_root`` is a plain directory copy (no ``.git``) — blind eval
        worktrees are created with ``cp -r`` so git commands fail there.
        When provided, tracked file revert reads pristine content from git
        and writes it to the copy instead of running ``git checkout``.

        Args:
            integration_name: e.g. "kafkajs", "@openai/agents"
            repo_root: Path to the dd-trace-js repo root (may be a plain copy)
            git_source_root: Original git checkout to read HEAD content from

        Returns:
            List of paths that were removed/reverted
        """

        removed: List[str] = []
        normalized = integration_name.replace("@", "").replace("/", "-").replace("_", "-")

        # 1. Delete plugin package directory
        plugin_dir = repo_root / "packages" / f"datadog-plugin-{normalized}"
        if plugin_dir.exists():
            shutil.rmtree(plugin_dir)
            removed.append(str(plugin_dir.relative_to(repo_root)))

        # 2. Delete instrumentation file and/or subdirectory.
        # Some integrations split instrumentation across a directory
        # (e.g. http/client.js + http/server.js) alongside or instead of a
        # flat file. Remove both forms so the worktree is fully clean.
        instr_src = repo_root / "packages" / "datadog-instrumentations" / "src"
        instr_file = instr_src / f"{normalized}.js"
        if instr_file.exists():
            instr_file.unlink()
            removed.append(str(instr_file.relative_to(repo_root)))
        instr_dir = instr_src / normalized
        if instr_dir.exists():
            shutil.rmtree(instr_dir)
            removed.append(str(instr_dir.relative_to(repo_root)))

        # 3. Delete rewriter instrumentation config (js or json)
        rewriter_dir = (
            repo_root
            / "packages"
            / "datadog-instrumentations"
            / "src"
            / "helpers"
            / "rewriter"
            / "instrumentations"
        )
        for ext in ("js", "json"):
            rewriter_file = rewriter_dir / f"{normalized}.{ext}"
            if rewriter_file.exists():
                rewriter_file.unlink()
                removed.append(str(rewriter_file.relative_to(repo_root)))

        # 4. Revert modifications to tracked files.
        tracked_files = [
            "packages/dd-trace/src/plugins/index.js",
            "index.d.ts",
            "docs/API.md",
            "docs/test.ts",
            "docs/test.js",
            ".github/workflows/apm-integrations.yml",
        ]
        removed.extend(revert_tracked_files(tracked_files, repo_root, git_source_root))

        return removed

    def get_required_test_services(self) -> List[str]:
        """Get Docker services required for running dd-trace-js tests.

        Returns:
            The test agent container is always required for dd-trace-js plugin tests.
            Additional per-integration services (e.g., redis, rabbitmq) are configured
            separately via CI config.
        """
        return ["testagent"]

    def get_ci_env_vars(self, package_name: str, required_services: List[str]) -> Dict[str, str]:
        """Get Node.js CI environment variables.

        Args:
            package_name: Normalized package name
            required_services: List of required docker services

        Returns:
            {'PLUGINS': 'package-name', 'SERVICES': 'redis mysql'}
        """
        return {
            "PLUGINS": package_name,
            "SERVICES": " ".join(required_services) if required_services else "none",
        }

    def get_ci_system(self) -> str:
        """Get the default CI system for Node.js."""
        return "github"

    def generate_ci_config(
        self,
        package_name: str,
        required_services: List[str],
        docker_compose_path: Optional[Path],
        ci_system: str = "github",
    ) -> Dict[str, Any]:
        """Generate CI configuration for Node.js package.

        Args:
            package_name: Name of the package
            required_services: List of required docker services
            docker_compose_path: Path to docker-compose.yml
            ci_system: CI system ('github', 'gitlab', 'circleci')

        Returns:
            Dictionary with 'job_name', 'config', and 'format'
        """
        job_name = self._normalize_package_name_for_ci(package_name)
        env_vars = self.get_ci_env_vars(job_name, required_services)
        return self._generate_github_actions_config(
            job_name, required_services, env_vars, docker_compose_path
        )

    # =========================================================================
    # Internal helpers
    # =========================================================================

    def _normalize_package_name_for_ci(self, package_name: str) -> str:
        """Normalize npm package name for CI usage."""
        return package_name.replace("@", "").replace("/", "-")

    def _get_ci_test_command(self) -> List[str]:
        """Get GitHub Actions test command for Node.js."""
        return ["./.github/actions/plugins/test"]

    def _generate_github_actions_config(
        self,
        job_name: str,
        required_services: List[str],
        env_vars: Dict[str, str],
        docker_compose_path: Optional[Path],
    ) -> Dict[str, Any]:
        """Generate GitHub Actions workflow configuration."""
        services_yaml = ""
        if required_services:
            services_yaml = self._generate_github_services_yaml(
                required_services, docker_compose_path
            )

        test_actions = self._get_ci_test_command()
        test_steps = ""
        for action in test_actions:
            test_steps += f"      - uses: {action}\n"
            test_steps += "        with:\n"
            test_steps += "          dd_api_key: ${{ secrets.DD_API_KEY }}\n"

        env_lines = "\n".join([f"      {key}: {value}" for key, value in env_vars.items()])

        config = f"""  {job_name}:
    runs-on: ubuntu-latest
{services_yaml}    env:
{env_lines}
    steps:
      - uses: actions/checkout@08c6903cd8c0fde910a37f88322edcfb5dd907a8 # v5.0.0
{test_steps}"""

        return {"job_name": job_name, "config": config, "format": "yaml"}

    def _generate_github_services_yaml(
        self, required_services: List[str], docker_compose_path: Optional[Path]
    ) -> str:
        """Generate GitHub Actions services YAML from docker-compose."""
        if not docker_compose_path or not docker_compose_path.exists():
            return self._generate_fallback_services_yaml(
                required_services, "docker-compose.yml not found"
            )

        try:
            with open(docker_compose_path, "r") as f:
                compose_config = yaml.safe_load(f)

            services = compose_config.get("services", {})
            services_yaml = "    services:\n"

            for service in required_services:
                if service in services:
                    service_config = services[service]
                    services_yaml += (
                        self._convert_service_to_github_actions(service, service_config) + "\n"
                    )
                else:
                    services_yaml += f"      {service}:\n"
                    services_yaml += (
                        f"        # Warning: Service '{service}' not found in docker-compose.yml\n"
                    )

            return services_yaml

        except Exception as e:
            return self._generate_fallback_services_yaml(
                required_services, f"Error reading docker-compose.yml: {e}"
            )

    def _convert_service_to_github_actions(
        self, service_name: str, service_config: Dict[str, Any]
    ) -> str:
        """Convert docker-compose service config to GitHub Actions format."""
        yaml_lines = [f"      {service_name}:"]

        if "image" in service_config:
            yaml_lines.append(f"        image: {service_config['image']}")

        if "environment" in service_config:
            yaml_lines.append("        env:")
            env_vars = service_config["environment"]

            if isinstance(env_vars, list):
                for var in env_vars:
                    if "=" in var:
                        key, value = var.split("=", 1)
                        yaml_lines.append(f"          {key}: {value}")
                    else:
                        yaml_lines.append(f"          {var}: ''")
            elif isinstance(env_vars, dict):
                for key, value in env_vars.items():
                    yaml_lines.append(f"          {key}: {value}")

        if "ports" in service_config:
            yaml_lines.append("        ports:")
            for port in service_config["ports"]:
                port_str = str(port)
                if port_str.startswith("127.0.0.1:"):
                    port_str = port_str.replace("127.0.0.1:", "", 1)
                yaml_lines.append(f"          - {port_str}")

        if "options" in service_config:
            yaml_lines.append(f"        options: {service_config['options']}")

        return "\n".join(yaml_lines)

    def _generate_fallback_services_yaml(self, required_services: List[str], reason: str) -> str:
        """Generate fallback services YAML when docker-compose.yml unavailable."""
        services_yaml = "    services:\n"
        for service in required_services:
            services_yaml += f"      {service}:\n"
            services_yaml += f"        # {reason}\n"
        return services_yaml

    # =========================================================================
    # APM-Specific: Adapter Scripts
    # =========================================================================

    def get_adapter_script(self, script_name: str) -> Path:
        """Get path to a Node.js adapter script."""
        return self.adapter_dir / "bin" / f"{script_name}.js"

    def get_static_analyzer_scripts(self) -> dict:
        """Get Node.js-specific static analyzer scripts."""
        node_dd_analyze = self.adapter_dir / "dd-analyze" / "src"
        return {
            "function_finder": node_dd_analyze / "analyzers" / "find-function.js",
            "method_extractor": node_dd_analyze / "analyzers" / "extract-all-methods.js",
            "context_capture": node_dd_analyze / "context_capture" / "capture.js",
        }

    def get_sample_app_filename(self) -> str:
        """Get Node.js sample app filename."""
        return "sample-app.js"

    def get_context_capture_command(
        self,
        *,
        context_capture_tool: str,
        analysis_file: str,
        sample_app_path: str,
        context_output_file: str,
        repo_root: Optional[Path] = None,
    ) -> str:
        """Build dd-trace-js context-capture command.

        The JS capture script requires the tracer repo root to resolve helper
        modules used by generated hooks.
        """
        args = [analysis_file, sample_app_path, context_output_file]
        if repo_root is not None:
            args.append(str(repo_root))
        return " ".join(self.get_runtime_command(Path(context_capture_tool), *args))

    def get_lint_paths(self, integration_name: str) -> List[str]:
        """Get paths to lint for a Node.js integration.

        Args:
            integration_name: Name of the integration

        Returns:
            List of paths to lint
        """
        return [
            self.get_plugin_path(integration_name),
            self.get_test_file_path(integration_name),
        ]

    # =========================================================================
    # Linting - Override to use yarn with concurrency
    # =========================================================================

    def lint_paths(self, paths: List[str], repo_root: Path, fix: bool = False) -> Dict[str, Any]:
        """Run ESLint on multiple paths using yarn with concurrency.

        dd-trace-js uses yarn and benefits from --concurrency=auto for speed.
        """
        # Use yarn eslint with concurrency (matches yarn lint behavior)
        # NOTE: Don't use --format json - it's extremely slow on large codebases
        # because it outputs metadata for every file, even clean ones
        cmd = ["yarn", "eslint", *paths, "--concurrency=auto"]
        if fix:
            cmd.append("--fix")

        try:
            result = subprocess.run(
                cmd,
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                timeout=120,  # 2 min should be plenty with concurrency
            )

            raw_output = result.stdout + result.stderr

            # Parse stylish format output for error counts and details
            errors = []
            total_errors = 0
            total_warnings = 0

            # Count problems from summary line: "X problems (Y errors, Z warnings)"
            summary_match = re.search(
                r"(\d+) problems? \((\d+) errors?, (\d+) warnings?\)", raw_output
            )
            if summary_match:
                total_errors = int(summary_match.group(2))
                total_warnings = int(summary_match.group(3))

            # Parse individual errors: "  line:col  error/warning  message  rule-id"
            current_file = None
            for line in raw_output.split("\n"):
                # File path line (no leading spaces, ends with file extension)
                if line and not line.startswith(" ") and ("/" in line or "\\" in line):
                    current_file = line.strip()
                # Error line: "  10:5  error  message  rule-id"
                elif current_file and line.strip():
                    match = re.match(r"\s+(\d+):(\d+)\s+(error|warning)\s+(.+?)\s{2,}(\S+)$", line)
                    if match:
                        errors.append({
                            "file_path": current_file,
                            "line": int(match.group(1)),
                            "column": int(match.group(2)),
                            "severity": match.group(3),
                            "message": match.group(4).strip(),
                            "rule_id": match.group(5),
                        })

            return {
                "success": result.returncode == 0,
                "error_count": total_errors,
                "warning_count": total_warnings,
                "fixable_count": 0,  # Not available in stylish format
                "errors": errors,
                "raw_output": raw_output,
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": "ESLint timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": f"ESLint failed: {e}",
            }

    def prepare_eval_worktree(
        self, worktree_path: Path, evalya_def_path: Optional[str] = None
    ) -> None:
        """Run ``yarn install`` so bundled vendor modules exist in the worktree.

        dd-trace-js mounts TRACER_DIR into the evalya container, which resolves
        Node requires against <worktree>/node_modules/ and
        <worktree>/packages/node_modules/ — both must be populated.
        """
        if not worktree_path.exists():
            logger.warning("prepare_eval_worktree: %s does not exist, skipping", worktree_path)
            return

        if (worktree_path / "node_modules").exists() and (
            worktree_path / "vendor" / "dist"
        ).exists():
            logger.info("prepare_eval_worktree: deps present, skipping install")
            return

        logger.info("prepare_eval_worktree: running yarn install in %s", worktree_path)
        installed = self._try_yarn_install(worktree_path)
        if not installed:
            logger.info("prepare_eval_worktree: yarn failed, falling back to npm install")
            self._try_npm_install(worktree_path)

    def _try_yarn_install(self, worktree_path: Path) -> bool:
        # Per-worktree yarn cache: yarn's default global cache
        # (/usr/local/share/.cache/yarn) corrupts when multiple worktrees install
        # in parallel (shared CI runner, shared filesystem). Isolating to the
        # worktree dir lets parallelism work without integrity-check failures.
        cache_dir = str(worktree_path / ".yarn-cache")
        Path(cache_dir).mkdir(parents=True, exist_ok=True)
        # Force non-TTY env so yarn doesn't query the controlling terminal
        # (escape responses otherwise leak into the parent shell output).
        env = {**os.environ, "TERM": "dumb", "NO_COLOR": "1", "CI": "true"}
        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            try:
                result = subprocess.run(
                    [
                        "yarn",
                        "install",
                        "--frozen-lockfile",
                        "--non-interactive",
                        "--network-concurrency",
                        "1",
                        "--cache-folder",
                        cache_dir,
                    ],
                    cwd=worktree_path,
                    capture_output=True,
                    stdin=subprocess.DEVNULL,
                    text=True,
                    timeout=900,
                    env=env,
                )
                if result.returncode == 0:
                    return True
                logger.warning(
                    "prepare_eval_worktree: yarn attempt %d/%d failed (exit %d): %s",
                    attempt,
                    max_attempts,
                    result.returncode,
                    result.stderr[-500:],
                )
                if attempt < max_attempts:
                    if cache_dir and Path(cache_dir).exists():
                        shutil.rmtree(cache_dir, ignore_errors=True)
                        Path(cache_dir).mkdir(parents=True, exist_ok=True)
                    nm = worktree_path / "node_modules"
                    if nm.exists():
                        shutil.rmtree(nm, ignore_errors=True)
            except subprocess.TimeoutExpired:
                logger.warning("prepare_eval_worktree: yarn timed out (attempt %d)", attempt)
            except FileNotFoundError:
                logger.warning("prepare_eval_worktree: yarn not found on PATH")
                return False
        return False

    def _try_npm_install(self, worktree_path: Path) -> bool:
        nm = worktree_path / "node_modules"
        if nm.exists():
            shutil.rmtree(nm, ignore_errors=True)
        try:
            result = subprocess.run(
                ["npm", "install", "--no-package-lock"],
                cwd=worktree_path,
                capture_output=True,
                text=True,
                timeout=900,
            )
            if result.returncode == 0:
                logger.info("prepare_eval_worktree: npm install succeeded")
                return True
            logger.warning(
                "prepare_eval_worktree: npm install failed (exit %d): %s",
                result.returncode,
                result.stderr[-500:],
            )
        except subprocess.TimeoutExpired:
            logger.warning("prepare_eval_worktree: npm install timed out")
        except FileNotFoundError:
            logger.warning("prepare_eval_worktree: npm not found on PATH")
        return False
