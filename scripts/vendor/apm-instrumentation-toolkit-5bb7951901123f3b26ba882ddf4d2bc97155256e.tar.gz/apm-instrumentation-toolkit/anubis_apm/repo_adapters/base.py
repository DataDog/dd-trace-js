"""APM adapter mixin - defines APM-specific method interface."""

import logging
import shlex
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, List, Optional, cast

from pydantic import BaseModel, Field

from anubis_apm.evalya.constants import EVALYA_TASK_ENV_KEYS

if TYPE_CHECKING:
    from anubis.core.context import Context
    from anubis.core.repo_adapters import RepoAdapter

logger = logging.getLogger(__name__)


class TestFailure(BaseModel):
    """A single test failure."""

    test_name: str = ""
    error_message: str = ""


class TestRunResult(BaseModel):
    """Result of running a filtered subset of tests."""

    command: str = ""
    filter_pattern: str = ""
    exit_code: int = 0
    tests_total: int = 0
    tests_passing: int = 0
    tests_failing: int = 0
    failures: List[TestFailure] = Field(default_factory=list)
    raw_output: str = ""
    duration_s: float = 0.0


class APMAdapterMixin(ABC):
    """Mixin defining APM-specific methods.

    Use with multiple inheritance alongside a RepoAdapter implementation:

        class NodeAPMAdapter(NodeRepoAdapter, APMAdapterMixin):
            def get_plugin_path(self, name: str) -> str:
                ...

    This provides:
    - Type hints for all APM methods
    - Enforcement that implementations provide all required methods
    - Full type hints for inherited RepoAdapter methods

    Only methods needed by all APM adapters are abstract here.
    Repo-specific methods (CI config, test instructions, etc.) live on
    the concrete adapter classes and are accessed via duck typing.
    """

    # =========================================================================
    # APM-Specific Methods (required for all adapters)
    # =========================================================================

    @abstractmethod
    def get_plugin_path(self, integration_name: str) -> str:
        """Get the path to a plugin/integration directory."""
        pass

    @abstractmethod
    def get_test_file_path(self, integration_name: str) -> str:
        """Get the path to the test file for an integration."""
        pass

    @abstractmethod
    def get_test_command(self, integration_name: str, output_dir: Optional[Path] = None) -> str:
        """Get the command to run tests for an integration."""
        pass

    @abstractmethod
    def get_sample_app_filename(self) -> str:
        """Get the filename to use for generated sample apps."""
        pass

    language: str = ""
    repository_id: str = ""

    # Maps feature IDs (FeatureId.value) and semantic category names
    # (apm_semantic_conventions.list_categories()) to reference integration paths.
    # Override in each concrete adapter with repo-specific paths.
    REFERENCE_INTEGRATIONS: ClassVar[dict[str, list[str]]] = {}
    GENERATE_APP: ClassVar[bool] = False

    def get_reference_integrations(self, key: str) -> list[str]:
        """Get reference integration paths for a feature ID or semantic category.

        Args:
            key: A FeatureId value (e.g. 'dsm', 'dbm') or a semantic category
                 from apm_semantic_conventions.list_categories() (e.g. 'http-client',
                 'messaging'). Unknown keys return [].

        Returns:
            List of repo-relative paths to reference integrations.
        """
        return self.REFERENCE_INTEGRATIONS.get(key, [])

    def normalize_namespace(
        self, package_name: str, maven_coordinates: Optional[str] = None
    ) -> str:
        """Return the workflow namespace to use for ``package_name``.

        The namespace becomes the ``.analysis/<namespace>/`` directory name, the
        ``integration_name`` injected into codegen prompts, and (for some tracers)
        a path component of the generated integration. It must therefore be a
        filesystem- and identifier-safe token.

        The default returns ``package_name`` unchanged — npm/PyPI names are already
        safe. Adapters whose package identifiers are not directly usable as a
        namespace (e.g. Java Maven coordinates ``group:artifact:version``, which
        contain colons) override this to derive a clean token.

        Args:
            package_name: The package identifier as supplied on the CLI.
            maven_coordinates: Optional explicit Maven coordinates (Java only).

        Returns:
            A filesystem-safe namespace token.
        """
        return package_name

    def supports_context_capture(self) -> bool:
        """Whether this tracer can capture runtime context for instrumentation targets.

        Context capture runs the sample app with the tracer attached and records
        the runtime values available at each hook point, so the analysis can map
        them to semantic APM tags. It depends on a language-specific capture tool
        (registered as ``context_capture`` in ``get_static_analyzer_scripts``).

        Tracers without that tool (e.g. dd-trace-java, which instruments bytecode
        and has no in-process capture script) return ``False``; the create workflow
        skips the context-capture steps for them rather than letting the agent
        thrash trying to satisfy a capture step it cannot complete.
        """
        return "context_capture" in cast("RepoAdapter", self).get_static_analyzer_scripts()

    def should_generate_app(self) -> bool:
        """Whether workflows should run the sample-app generation steps.

        Runtime context capture needs a generated sample app, so capture-capable
        tracers always return ``True``. Tracers without context capture use the
        adapter-level ``GENERATE_APP`` override.
        """
        return self.supports_context_capture() or self.GENERATE_APP

    def get_scaffold_prompt_variables(
        self, integration_name: str, removed_paths: Optional[list[str]] = None
    ) -> dict[str, str]:
        """Return repo-specific variables for scaffold/codegen prompts.

        Concrete adapters can use this to surface path conventions that are
        awkward or lossy to derive from the package name alone.
        """
        return {}

    def get_context_capture_command(
        self,
        *,
        context_capture_tool: str,
        analysis_file: str,
        sample_app_path: str,
        context_output_file: str,
        repo_root: Optional[Path] = None,
    ) -> str:
        """Build the command used by repo-specific context-capture prompt fragments."""
        return ""

    @abstractmethod
    def setup_tracing_precheck(self, integration_name: str, ctx: "Context") -> None:
        """Set context values needed by the tracing_precheck step.

        Must set at minimum:
        - ``tracing_plugin_path``: absolute path to the tracing plugin directory
        - ``tracing_test_command``: shell command to verify tracing tests pass
        """
        pass

    def get_repository_id(self) -> str:
        """Get the repository identifier (e.g. 'dd_trace_js', 'dd_trace_py').

        Used for dataset file naming, sg_rules lookup, and config resolution.
        """
        return self.repository_id

    def remove_integration(
        self,
        integration_name: str,
        repo_root: Path,
        git_source_root: Optional[Path] = None,
    ) -> list[str]:
        """Remove all files/changes for a generated integration from the repo.

        Used by the eval system to cleanly wipe a generated integration so
        it can be regenerated from scratch for evaluation.

        ``git_source_root``, when provided, is the original git checkout used
        to restore tracked file content in plain-copy worktrees (no ``.git``).

        Returns a list of paths that were removed/reverted.
        Override in concrete adapters with repo-specific file layouts.
        """
        return []

    def get_ground_truths_path(self) -> Optional[Path]:
        """Get path to ground truth targets JSON for analysis eval (Tier 2A).

        Returns None if no ground truths are available for this repo.
        """
        return None

    def get_eval_analysis_aliases(
        self, package: str, metadata: Optional[dict[str, str]] = None
    ) -> list[str]:
        """Return alternate ``.analysis/`` names for an eval package.

        Method-selection evals score canonical package names from ground truths,
        but some workflows write state under a normalized or artifact-derived
        namespace. Java is the main case: ``grpc`` installs Maven artifact
        ``grpc-core`` and writes ``.analysis/grpc-core/``. Adapters can return
        those aliases so eval scoring and cache lookup use the real output.
        """
        return []

    def get_blind_copy_dirs(self, repo_root: Path) -> list[Path]:
        """Return source directories to copy into a blind-eval shadow.

        The shadow copy replaces the full ``shutil.copytree`` of the repo,
        keeping only what the analysis agent actually needs: skills for
        guidance and the instrumentation directory for reference patterns.

        Each returned path must be a subdirectory of ``repo_root``. The
        copy preserves the relative structure (e.g. ``repo/.claude/skills/``
        → ``shadow/.claude/skills/``).

        Override in concrete adapters to add the repo-specific instrumentation
        directory. The default copies only ``.claude/skills/`` (skills live in
        the tracer repo and are read by both Claude Code and spawned agents).
        """
        skills_dir = repo_root / ".claude" / "skills"
        if skills_dir.exists():
            return [skills_dir]
        return []

    # =========================================================================
    # Integration-gen eval (evalya oracle)
    # =========================================================================

    evalya_language_prefix: str = ""
    """Evalya ``defs/iat/`` language prefix (e.g. ``"node"``, ``"python"``).

    Set in concrete adapters to enable evalya support.
    Empty string disables evalya support.
    """

    def get_evalya_def_path(self, package: str) -> Optional[str]:
        """Return the OCI-relative def path for this package, or None if unsupported."""
        if not self.evalya_language_prefix:
            return None
        normalized = package.replace("@", "").replace("/", "-").replace("_", "-").lower()
        return f"defs/iat/{self.evalya_language_prefix}-{normalized}"

    def get_evalya_task(self, package: str) -> str:
        """Return the evalya task ID within the def directory (always ``"run"``)."""
        return "run"

    def get_evalya_target_package(self, package: str) -> str:
        """Return the package name the evalya test app actually imports.

        Defaults to the integration name. Override when they differ
        (e.g. the ``psycopg`` integration instruments ``psycopg2``).
        """
        return package

    def get_evalya_packages(self) -> list[str]:
        """Return supported evalya packages by scanning the OCI cache.

        Scans ``~/.evalya/cache/oci/*/defs/iat/`` for entries matching
        ``{evalya_language_prefix}-<package>`` and returns the package
        suffixes. Falls back to an empty list if the cache hasn't been
        populated yet (first run before any ``evalya`` invocation).
        """
        if not self.evalya_language_prefix:
            return []
        cache_root = Path.home() / ".evalya" / "cache" / "oci"
        if not cache_root.exists():
            return []
        prefix = f"{self.evalya_language_prefix}-"
        seen: set[str] = set()
        for oci_dir in cache_root.iterdir():
            iat_dir = oci_dir / "defs" / "iat"
            if not iat_dir.is_dir():
                continue
            for entry in iat_dir.iterdir():
                if entry.is_dir() and entry.name.startswith(prefix):
                    seen.add(entry.name[len(prefix) :])
        return sorted(seen)

    def prepare_eval_worktree(
        self, worktree_path: Path, evalya_def_path: Optional[str] = None
    ) -> None:
        """Language-specific worktree preparation before the workflow runs.

        Override in adapters that need extra setup (e.g. Python compiling
        Cython/Rust native extensions so Docker mounts work correctly).
        Default: no-op.
        """

    def prepare_evalya_overlay(self, worktree_path: Path) -> tuple[Path, dict[str, str]]:
        """Prepare the tracer overlay mounted into evalya app containers.

        The default overlay is the tracer worktree itself. Adapters can override
        this when evalya needs a built artifact instead of live source files.

        Returns:
            ``(tracer_dir, container_env)`` where ``tracer_dir`` becomes the
            host ``TRACER_DIR`` mount source, and ``container_env`` is passed to
            evalya via ``--env KEY=VALUE``.
        """
        return worktree_path, {}

    def prepare_post_deletion_evalya_overlay(
        self, worktree_path: Path
    ) -> tuple[Path, dict[str, str]]:
        """Prepare the tracer overlay for the post-deletion coverage check."""
        return self.prepare_evalya_overlay(worktree_path)

    def get_evalya_test_command(
        self,
        worktree_path: Path,
        def_path: str,
        task: str,
        evalya_context: str,
        extra_env: Optional[dict[str, str]] = None,
    ) -> str:
        """Return the shell command the nested fixer should run for evalya."""
        return self._format_evalya_test_command(
            tracer_dir=worktree_path,
            def_path=def_path,
            task=task,
            evalya_context=evalya_context,
            extra_env=extra_env,
        )

    @staticmethod
    def _format_evalya_test_command(
        *,
        tracer_dir: Path,
        def_path: str,
        task: str,
        evalya_context: str,
        extra_env: Optional[dict[str, str]] = None,
        container_env: Optional[dict[str, str]] = None,
        prefix: str = "",
    ) -> str:
        parts = [f"{key}={shlex.quote(value)}" for key, value in sorted((extra_env or {}).items())]
        parts.extend([
            f"TRACER_DIR={shlex.quote(str(tracer_dir))}",
            "evalya",
            "run",
            "--context",
            shlex.quote(evalya_context),
            "--path",
            shlex.quote(def_path),
            "--task",
            shlex.quote(task),
        ])
        task_env = dict(container_env or {})
        for key in EVALYA_TASK_ENV_KEYS:
            if extra_env and key in extra_env:
                task_env[key] = extra_env[key]
        for key, value in sorted(task_env.items()):
            parts.extend(["--env", shlex.quote(f"{key}={value}")])
        parts.append("--no-tui")
        command = " ".join(parts)
        return f"{prefix} && {command}" if prefix else command

    def get_integration_gen_unit_test_filter(self, integration_name: str) -> Optional[str]:
        """Return the test filter for integration-gen's unit-test oracle.

        Packages without evalya defs need an explicit adapter-owned unit-test
        oracle. Returning ``None`` means the integration-gen eval is unsupported
        for this package because the harness cannot prove removal/regeneration
        changed behavior.
        """
        return None

    def run_filtered_tests(
        self,
        integration_name: str,
        filter_pattern: str,
        repo_root: Path,
        timeout: int = 300,
        source_repo: Optional[Path] = None,
    ) -> "TestRunResult":
        """Run a filtered subset of unit tests for an integration.

        Used by the unit-test oracle fallback when no evalya def exists.
        Override in adapters that support unit-test-based eval.
        Default: returns an empty result (0/0 passing) so the oracle treats it as a failure.
        """
        return TestRunResult()
