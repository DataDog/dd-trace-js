"""Unified repository detection and cloning for APM toolkit.

Single entry point for scanning the filesystem to find known repos,
identifying missing ones, and cloning new repos on demand.
"""

import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from ._repos import REPO_REGISTRY, RepoDefinition

logger = logging.getLogger(__name__)


@dataclass
class DetectedRepo:
    """A repository found on the filesystem."""

    definition: RepoDefinition
    path: Path
    language: str


@dataclass
class DetectionResult:
    """Result of scanning the filesystem for known repos."""

    found: list[DetectedRepo] = field(default_factory=list)
    missing: list[RepoDefinition] = field(default_factory=list)


def detect_repos(
    toolkit_root: Path,
    extra_search_dirs: list[Path] | None = None,
) -> DetectionResult:
    """Scan filesystem for known tracer repos.

    Search locations (priority order, first match wins per repo):
    1. toolkit_root/repos/
    2. extra_search_dirs

    Args:
        toolkit_root: Path to the APM toolkit installation.
        extra_search_dirs: Additional directories to scan.

    Returns:
        DetectionResult with found and missing repos.
    """
    search_dirs: list[Path] = []

    repos_dir = toolkit_root / "repos"
    if repos_dir.is_dir():
        search_dirs.append(repos_dir)

    if extra_search_dirs:
        for d in extra_search_dirs:
            if d.is_dir() and d not in search_dirs:
                search_dirs.append(d)

    found_names: set[str] = set()
    found: list[DetectedRepo] = []

    for search_dir in search_dirs:
        for repo_def in REPO_REGISTRY.values():
            if repo_def.internal_name in found_names:
                continue

            candidate = search_dir / repo_def.dir_name
            if candidate.is_dir() and (candidate / ".git").exists():
                language = detect_language(candidate) or repo_def.language
                found.append(DetectedRepo(definition=repo_def, path=candidate, language=language))
                found_names.add(repo_def.internal_name)

    missing = [r for r in REPO_REGISTRY.values() if r.internal_name not in found_names]

    return DetectionResult(found=found, missing=missing)


def detect_language(path: Path) -> str:
    """Detect language from repository marker files.

    Returns language string or empty string if unknown.
    """
    name = path.name.lower()

    if "js" in name or (path / "package.json").exists():
        return "node"
    if "py" in name or (path / "setup.py").exists() or (path / "pyproject.toml").exists():
        return "python"
    if "rb" in name or (path / "Gemfile").exists():
        return "ruby"
    if "go" in name or (path / "go.mod").exists():
        return "go"
    if "java" in name or (path / "pom.xml").exists() or (path / "build.gradle").exists():
        return "java"
    if "dotnet" in name or any(path.glob("*.sln")):
        return "dotnet"
    if "php" in name or (path / "composer.json").exists():
        return "php"

    return ""


def clone_repo(repo_def: RepoDefinition, target_dir: Path) -> Path | None:
    """Clone a repo, preferring gh CLI and falling back to git for public repos.

    Args:
        repo_def: Registry entry for the repo to clone.
        target_dir: Parent directory to clone into.

    Returns:
        Path to cloned repo, or None on failure.
    """
    target = target_dir / repo_def.dir_name
    if target.exists():
        if not (target / ".git").exists():
            logger.error("Directory exists but is not a git repository: %s", target)
            return None
        logger.info("Repository already exists at %s", target)
        return target

    target_dir.mkdir(parents=True, exist_ok=True)

    # Try gh first (preferred — handles auth, SSH keys, etc.)
    if shutil.which("gh"):
        try:
            result = subprocess.run(
                [
                    "gh",
                    "repo",
                    "clone",
                    repo_def.github_repo,
                    str(target),
                    "--",
                    "--depth=1",
                    "--branch",
                    repo_def.default_branch,
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
            if result.returncode == 0:
                return target
            logger.debug("gh clone failed (%s), falling back to git", result.stderr.strip())
        except FileNotFoundError:
            logger.debug("gh not found, falling back to git")
        except subprocess.TimeoutExpired:
            logger.error("Clone timed out for %s", repo_def.dir_name)
            return None

    # Fall back to plain git clone (works for public repos without gh auth)
    https_url = f"https://github.com/{repo_def.github_repo}.git"
    try:
        result = subprocess.run(
            [
                "git",
                "clone",
                "--depth=1",
                "--branch",
                repo_def.default_branch,
                https_url,
                str(target),
            ],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode == 0:
            return target
        logger.error("Failed to clone %s: %s", repo_def.dir_name, result.stderr.strip())
    except FileNotFoundError:
        logger.error("git not found")
    except subprocess.TimeoutExpired:
        logger.error("Clone timed out for %s", repo_def.dir_name)

    return None
