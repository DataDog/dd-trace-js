"""Single source of truth for all known Datadog tracer repositories.

This registry is consumed by:
- Config init: auto-detect repos on disk, show missing ones
- CLI validation: graceful error when repo not configured
- Clone command: knows GitHub URL and default branch
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class RepoDefinition:
    """Metadata for a known tracer repository.

    Attributes:
        internal_name: Underscore form used in config keys (dd_trace_js).
        dir_name: Hyphen form used on filesystem (dd-trace-js).
        github_repo: Full org/repo for cloning (DataDog/dd-trace-js).
        default_branch: Branch to clone.
        language: Language identifier.
        has_adapter: True if anubis_apm has full workflow support.
            Also serves as the "supported" flag in the UI.
        is_default: Pre-selected for fresh installs.
        marker_files: Files that identify this repo type on disk (beyond .git).
    """

    internal_name: str
    dir_name: str
    github_repo: str
    default_branch: str
    language: str
    has_adapter: bool = False
    is_default: bool = False
    marker_files: tuple[str, ...] = ()


REPO_REGISTRY: dict[str, RepoDefinition] = {}


def _register(*repos: RepoDefinition) -> None:
    for r in repos:
        REPO_REGISTRY[r.internal_name] = r


_register(
    RepoDefinition(
        internal_name="dd_trace_js",
        dir_name="dd-trace-js",
        github_repo="DataDog/dd-trace-js",
        default_branch="master",
        language="node",
        has_adapter=True,
        is_default=True,
        marker_files=("package.json",),
    ),
    RepoDefinition(
        internal_name="dd_trace_py",
        dir_name="dd-trace-py",
        github_repo="DataDog/dd-trace-py",
        default_branch="main",
        language="python",
        has_adapter=True,
        is_default=True,
        marker_files=("setup.py", "pyproject.toml"),
    ),
    RepoDefinition(
        internal_name="dd_trace_rb",
        dir_name="dd-trace-rb",
        github_repo="DataDog/dd-trace-rb",
        default_branch="master",
        language="ruby",
        marker_files=("Gemfile",),
    ),
    RepoDefinition(
        internal_name="dd_trace_go",
        dir_name="dd-trace-go",
        github_repo="DataDog/dd-trace-go",
        default_branch="main",
        language="go",
        marker_files=("go.mod",),
    ),
    RepoDefinition(
        internal_name="dd_trace_java",
        dir_name="dd-trace-java",
        github_repo="DataDog/dd-trace-java",
        default_branch="master",
        language="java",
        has_adapter=True,
        marker_files=("pom.xml", "build.gradle"),
    ),
    RepoDefinition(
        internal_name="dd_trace_dotnet",
        dir_name="dd-trace-dotnet",
        github_repo="DataDog/dd-trace-dotnet",
        default_branch="master",
        language="dotnet",
        marker_files=("*.sln",),
    ),
    RepoDefinition(
        internal_name="dd_trace_php",
        dir_name="dd-trace-php",
        github_repo="DataDog/dd-trace-php",
        default_branch="master",
        language="php",
        marker_files=("composer.json",),
    ),
    RepoDefinition(
        internal_name="evalya",
        dir_name="evalya",
        github_repo="DataDog/evalya",
        default_branch="main",
        language="go",
        marker_files=("go.mod",),
    ),
)


def get_repo_def(name: str) -> RepoDefinition | None:
    """Look up a repo definition by internal_name or dir_name."""
    normalized = name.replace("-", "_")
    return REPO_REGISTRY.get(normalized)


def get_default_repos() -> list[RepoDefinition]:
    """Repos pre-selected for fresh installs (js + py)."""
    return [r for r in REPO_REGISTRY.values() if r.is_default]


def get_all_repos() -> list[RepoDefinition]:
    """All known repos."""
    return list(REPO_REGISTRY.values())


def get_tracer_repos() -> list[RepoDefinition]:
    """All known repos excluding non-tracer tools (evalya)."""
    return [r for r in REPO_REGISTRY.values() if r.internal_name.startswith("dd_trace_")]
