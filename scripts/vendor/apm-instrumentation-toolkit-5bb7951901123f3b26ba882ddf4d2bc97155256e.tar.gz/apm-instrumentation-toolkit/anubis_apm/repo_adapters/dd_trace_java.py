"""dd-trace-java adapter - extends generic adapter with APM-specific methods."""

import logging
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional

from anubis.core.config import get_config
from anubis.core.git import revert_tracked_files
from anubis.core.repo_adapters import JavaRepoAdapter
from anubis_apm.evalya import java as evalya_java

from .base import APMAdapterMixin

logger = logging.getLogger(__name__)


class DDTraceJavaAdapter(JavaRepoAdapter, APMAdapterMixin):
    """Adapter for dd-trace-java - extends generic with dd-trace specific functionality.

    Inherits:
    - Generic methods from JavaRepoAdapter (lint, install, etc.)
    - APM method interface from APMAdapterMixin (get_plugin_path, etc.)
    """

    language: str = "java"
    repository_id: str = "dd_trace_java"
    evalya_language_prefix: str = "java"

    def get_sample_app_filename(self) -> str:
        """Get Java sample app filename."""
        return "App.java"

    def prepare_evalya_overlay(self, worktree_path: Path) -> tuple[Path, dict[str, str]]:
        """Build the eval jar and return the directory Evalya should mount."""
        return evalya_java.prepare_overlay(worktree_path)

    def prepare_post_deletion_evalya_overlay(
        self, worktree_path: Path
    ) -> tuple[Path, dict[str, str]]:
        """Build the post-deletion eval jar and return the directory Evalya should mount."""
        return evalya_java.prepare_post_deletion_overlay(worktree_path)

    def get_evalya_test_command(
        self,
        worktree_path: Path,
        def_path: str,
        task: str,
        evalya_context: str,
        extra_env: Optional[dict[str, str]] = None,
    ) -> str:
        tracer_dir, container_env, prefix = evalya_java.test_command_parts(worktree_path)
        return self._format_evalya_test_command(
            tracer_dir=tracer_dir,
            def_path=def_path,
            task=task,
            evalya_context=evalya_context,
            extra_env=extra_env,
            container_env=container_env,
            prefix=prefix,
        )

    # Packages whose instrumentation directory names don't match the eval package name.
    # Key: eval package name → Value: list of relative paths under dd-java-agent/instrumentation/
    _INSTR_DIR_OVERRIDES: ClassVar[dict[str, list[str]]] = {
        "commons-httpclient": ["commons-httpclient-2.0"],
        "aws-sdk-v1": ["aws-java/aws-java-sdk-1.11"],
        "aws-sdk-v2": ["aws-java/aws-java-sdk-2.2"],
        "elasticsearch-rest": ["elasticsearch/elasticsearch-rest/elasticsearch-rest-7.0"],
        "elasticsearch-transport": [
            "elasticsearch/elasticsearch-transport/elasticsearch-transport-5.0"
        ],
        "grpc": ["grpc-1.5"],
        "http-url-connection": ["java/java-net"],
        "jedis": ["jedis/jedis-4.0"],
        "jms": ["jms/javax-jms-1.1", "jms/jakarta-jms-3.0"],
        "kafka-clients": ["kafka/kafka-clients-0.11"],
        "kafka-streams": ["kafka/kafka-streams-0.11"],
        "lettuce": ["lettuce/lettuce-5.0"],
        "netty": ["netty/netty-4.1"],
        "openai": ["openai-java/openai-java-3.0"],
        "openai-java": ["openai-java/openai-java-3.0"],
        "rabbitmq": ["rabbitmq-amqp-2.7"],
        "servlet": ["servlet/javax-servlet"],
        "sparkjava": ["spark/sparkjava-2.3"],
        "spring-webflux": ["spring/spring-webflux/spring-webflux-5.0"],
        "spring-webmvc": ["spring/spring-webmvc/spring-webmvc-3.1"],
    }

    REFERENCE_INTEGRATIONS: ClassVar[dict[str, list[str]]] = {
        # Semantic convention categories (from apm_semantic_conventions.list_categories())
        "aws": [
            "dd-java-agent/instrumentation/aws-java/",
        ],
        "cache": [
            "dd-java-agent/instrumentation/jedis/",
            "dd-java-agent/instrumentation/lettuce/",
        ],
        "database": [
            "dd-java-agent/instrumentation/jdbc/",
            "dd-java-agent/instrumentation/mongo/",
            "dd-java-agent/instrumentation/hibernate/",
        ],
        "graphql": [
            "dd-java-agent/instrumentation/graphql-java/",
        ],
        "grpc-client": [
            "dd-java-agent/instrumentation/grpc-1.5/",
        ],
        "grpc-server": [
            "dd-java-agent/instrumentation/grpc-1.5/",
        ],
        "http-client": [
            "dd-java-agent/instrumentation/okhttp/",
            "dd-java-agent/instrumentation/apache-httpclient/",
        ],
        "http-server": [
            "dd-java-agent/instrumentation/servlet/",
            "dd-java-agent/instrumentation/netty/",
            "dd-java-agent/instrumentation/jetty/",
        ],
        "llm": [
            "dd-java-agent/instrumentation/openai-java/",
        ],
        "messaging": [
            "dd-java-agent/instrumentation/kafka/",
            "dd-java-agent/instrumentation/rabbitmq-amqp-2.7/",
            "dd-java-agent/instrumentation/jms/",
        ],
        "search": [
            "dd-java-agent/instrumentation/elasticsearch/",
            "dd-java-agent/instrumentation/opensearch/",
        ],
        # Datadog feature categories (FeatureId values)
        "dsm": [
            "dd-java-agent/instrumentation/kafka/",
            "dd-java-agent/instrumentation/rabbitmq-amqp-2.7/",
        ],
        "context_propagation": [
            "dd-java-agent/instrumentation/kafka/",
            "dd-java-agent/instrumentation/rabbitmq-amqp-2.7/",
            "dd-java-agent/instrumentation/jms/",
        ],
        "dbm": [
            "dd-java-agent/instrumentation/jdbc/",
            "dd-java-agent/instrumentation/mongo/",
        ],
        "peer_service": [
            "dd-java-agent/instrumentation/okhttp/",
            "dd-java-agent/instrumentation/apache-httpclient/",
            "dd-java-agent/instrumentation/jdbc/",
        ],
    }

    def get_ground_truths_path(self) -> Optional[Path]:
        path = (
            Path(__file__).parent.parent
            / "eval"
            / "analyze"
            / "datasets"
            / "ground_truths"
            / "dd_trace_java"
        )
        return path if path.exists() else None

    @property
    def adapter_dir(self) -> Path:
        """Get adapter directory (bundled read-only resource)."""
        return (
            get_config().toolkit_install_root
            / "anubis_apm"
            / "repo_adapters_impl"
            / "dd_trace_java"
        )

    def resolve_artifact_name(self, maven_coordinates: str) -> str:
        """Extract artifact name from Maven coordinates (group:artifact:version).

        Args:
            maven_coordinates: e.g. 'redis.clients:jedis:3.0.0'

        Returns:
            Artifact name, e.g. 'jedis'

        Raises:
            ValueError: If coordinates are not in group:artifact[:version] format
        """
        parts = maven_coordinates.split(":")
        if len(parts) < 2:
            raise ValueError(
                f"Invalid Maven coordinates '{maven_coordinates}': "
                f"expected group:artifact[:version] format"
            )
        return parts[1]

    def normalize_namespace(
        self, package_name: str, maven_coordinates: Optional[str] = None
    ) -> str:
        """Derive a clean Java namespace from Maven coordinates.

        Java packages are identified by Maven coordinates ``group:artifact[:version]``
        (e.g. ``io.reactivex.rxjava3:rxjava``). Used verbatim as a namespace, the
        colon produces an invalid ``.analysis/<ns>/`` directory and an invalid
        instrumentation module name (``dd-java-agent/instrumentation/<artifact>/``).
        Reduce to the artifact id (``rxjava``).

        Resolution order:
        1. Explicit ``maven_coordinates`` (the ``--maven-coords`` flag).
        2. ``package_name`` itself when it looks like coordinates (contains ``:``).
        3. Otherwise ``package_name`` unchanged (already a bare artifact id).
        """
        coords = maven_coordinates or (package_name if ":" in package_name else None)
        if coords:
            return self.resolve_artifact_name(coords)
        return package_name

    def get_eval_analysis_aliases(
        self, package: str, metadata: Optional[dict[str, str]] = None
    ) -> list[str]:
        """Return Java eval output namespaces for a canonical package.

        Java method-selection eval packages are named after tracer integrations
        or product concepts, while the analyze workflow writes under the Maven
        artifact namespace. For example ``aws-sdk-v1`` analyzes
        ``com.amazonaws:aws-java-sdk-core`` and writes
        ``.analysis/aws-java-sdk-core``.
        """
        aliases: list[str] = []
        coords = (metadata or {}).get("maven_coordinates")
        if coords:
            aliases.append(self.resolve_artifact_name(coords))

        # Keep common historical names as aliases in case older cache artifacts
        # were written before ground truths gained Maven coordinates.
        manual_aliases = {
            "apache-httpclient": ["httpclient"],
            "mongo": ["mongodb-driver-core"],
            "rabbitmq": ["amqp-client"],
            "servlet": ["javax.servlet-api"],
        }
        aliases.extend(manual_aliases.get(package, []))

        seen: set[str] = {package}
        unique: list[str] = []
        for alias in aliases:
            if alias and alias not in seen:
                unique.append(alias)
                seen.add(alias)
        return unique

    def prepare_maven_install(self, input: Any, ctx: Any) -> str:
        """Prepare context for a Java Maven install and return the package string to install.

        Handles all Java-specific setup so the install_package step stays adapter-agnostic:

        - Stores maven_coordinates in context for downstream steps
        - **Mutates ctx.namespace** to the artifact name (e.g. 'jedis' from
          'redis.clients:jedis:1.4.0') so that later lookups via ctx.namespace match
          the installed JAR filename
        - Returns the full Maven coordinates string to pass to install_package

        If no maven_coordinates are present, returns input.package_name unchanged and
        emits an informational message. ctx.namespace is not modified in that case.

        Implementors overriding this method MUST maintain the same namespace mutation
        contract, as extract_from_packages relies on ctx.namespace matching the artifact
        portion of the installed JAR filename.

        Args:
            input: AnalyzeInput (or compatible) with package_name / maven_coordinates fields
            ctx: Workflow context — ctx.namespace MAY be mutated as a side effect

        Returns:
            Package string to pass to install_package
        """
        if not input.maven_coordinates:
            ctx.info(
                f"No Maven coordinates provided for '{input.package_name}'. "
                f"To download and analyze a Java library JAR, supply "
                f"--maven-coords 'group:artifact:version'."
            )
            return str(input.package_name)

        ctx.info(f"Installing Java package from Maven: {input.maven_coordinates}")
        ctx.set("maven_coordinates", input.maven_coordinates)

        artifact_name = self.resolve_artifact_name(input.maven_coordinates)
        if ctx.namespace != artifact_name:
            ctx.info(
                f"Updating namespace from '{ctx.namespace}' to '{artifact_name}' "
                f"(from Maven coordinates)"
            )
            ctx.namespace = artifact_name

        return str(input.maven_coordinates)

    def get_static_analyzer_scripts(self) -> dict:
        """Get Java-specific static analyzer scripts.

        Returns:
            Dictionary mapping analyzer names to script paths:
            - method_extractor: Path to extract_all_methods.py (Java JAR analyzer)
        """
        analyzers = self.adapter_dir / "dd_analyze" / "src" / "analyzers"
        return {
            "function_finder": analyzers / "find_function.py",
            "method_extractor": analyzers / "extract_all_methods.py",
        }

    @staticmethod
    def _normalize_integration_name(integration_name: str) -> str:
        return integration_name.replace("_", "-").lower()

    @staticmethod
    def _dedupe(values: list[str]) -> list[str]:
        seen: set[str] = set()
        unique: list[str] = []
        for value in values:
            if value not in seen:
                unique.append(value)
                seen.add(value)
        return unique

    def _instrumentation_relative_paths(
        self, integration_name: str, removed_paths: Optional[list[str]] = None
    ) -> list[str]:
        instr_prefix = "dd-java-agent/instrumentation/"
        eval_paths = []
        for path in removed_paths or []:
            clean_path = path.strip().rstrip("/")
            if clean_path.startswith(instr_prefix):
                rel_path = clean_path.removeprefix(instr_prefix)
                if rel_path:
                    eval_paths.append(rel_path)
        if eval_paths:
            return self._dedupe(eval_paths)

        normalized = self._normalize_integration_name(integration_name)
        overrides = self._INSTR_DIR_OVERRIDES.get(normalized)
        if overrides:
            return self._dedupe(list(overrides))
        return [normalized]

    def _instrumentation_path(
        self, integration_name: str, removed_paths: Optional[list[str]] = None
    ) -> str:
        rel_path = self._instrumentation_relative_paths(integration_name, removed_paths)[0]
        return f"dd-java-agent/instrumentation/{rel_path}/"

    @staticmethod
    def _gradle_project_path(instrumentation_rel_path: str) -> str:
        return ":dd-java-agent:instrumentation:" + ":".join(Path(instrumentation_rel_path).parts)

    def get_scaffold_prompt_variables(
        self, integration_name: str, removed_paths: Optional[list[str]] = None
    ) -> dict[str, str]:
        rel_paths = self._instrumentation_relative_paths(integration_name, removed_paths)
        module_paths = [f"dd-java-agent/instrumentation/{rel_path}/" for rel_path in rel_paths]
        gradle_paths = [self._gradle_project_path(rel_path) for rel_path in rel_paths]
        module_list = "\n".join(f"- `{path}`" for path in module_paths)
        gradle_list = "\n".join(f"- `{path}`" for path in gradle_paths)
        guidance = (
            "## Java Module Path\n\n"
            "Use the Java adapter's resolved instrumentation module path exactly. "
            "Do not derive a different versioned directory from the package version.\n\n"
            f"**Instrumentation module path(s):**\n{module_list}\n\n"
            f"**Gradle project path(s):**\n{gradle_list}\n"
        )
        return {"scaffold_repo_guidance": guidance}

    def get_plugin_path(self, integration_name: str) -> str:
        """Get the path to a Java instrumentation directory.

        Args:
            integration_name: Name of the integration (e.g., 'feign', 'okhttp')

        Returns:
            Path to instrumentation directory (e.g., 'dd-java-agent/instrumentation/feign/')
        """
        return self._instrumentation_path(integration_name)

    def get_test_file_path(self, integration_name: str) -> str:
        """Get the path to the test file for a Java integration.

        Args:
            integration_name: Name of the integration (e.g., 'feign')

        Returns:
            Path to test directory (e.g., 'dd-java-agent/instrumentation/feign/feign-8.0/src/test/groovy/')
        """
        return self._instrumentation_path(integration_name)

    def setup_tracing_precheck(self, integration_name: str, ctx: Any) -> None:
        """Set dd-trace-java tracing precheck context values."""
        repo_root = get_config().get_repo_root(ctx.repository)
        plugin_path = repo_root / self.get_plugin_path(integration_name)
        ctx.set("tracing_plugin_path", str(plugin_path))
        ctx.set("tracing_test_command", self.get_test_command(integration_name))

    def get_test_command(self, integration_name: str, output_dir: Optional[Path] = None) -> str:
        """Get the command to run tests for a Java integration.

        Args:
            integration_name: Name of the integration to test
            output_dir: Optional directory for test output logs

        Returns:
            Shell command string to run tests
        """
        instr_rel_path = self._instrumentation_relative_paths(integration_name)[0]
        cmd = f"./gradlew {self._gradle_project_path(instr_rel_path)}:test"
        if output_dir:
            cmd += f" --rerun-tasks 2>&1 | tee {shlex.quote(str(output_dir / 'test-output.log'))}"
        return cmd

    def get_required_test_services(self) -> List[str]:
        """Get Docker services required for running dd-trace-java tests.

        Returns:
            Empty list for Java - most tests don't require external Docker services.
            Integration-specific services (e.g., redis, postgres) are typically
            handled by embedded test servers or testcontainers.
        """
        return []

    def get_instrumentation_deny_paths(
        self, repo_root: Path, integration_name: str = ""
    ) -> list[str]:
        instr_dir = repo_root / "dd-java-agent" / "instrumentation"
        if not instr_dir.exists():
            return []
        if integration_name:
            normalized = self._normalize_integration_name(integration_name)
            overrides = self._INSTR_DIR_OVERRIDES.get(normalized)
            if overrides:
                return [f"Read({instr_dir}/{rel}/**)" for rel in overrides]
            return [f"Read({instr_dir}/{normalized}/**)"]
        return [f"Read({instr_dir}/**)"]

    def remove_integration(
        self,
        integration_name: str,
        repo_root: Path,
        git_source_root: Optional[Path] = None,
    ) -> List[str]:
        """Remove all files/changes for a generated dd-trace-java integration.

        Args:
            integration_name: e.g. "jedis", "okhttp"
            repo_root: Path to the dd-trace-java repo root
            git_source_root: Original git checkout for restoring tracked files
                in plain-copy worktrees (no ``.git``)

        Returns:
            List of paths that were removed/reverted
        """
        removed: List[str] = []
        normalized = self._normalize_integration_name(integration_name)

        # 1. Delete instrumentation directory/directories.
        # Paths vary: direct (jedis), versioned (rabbitmq-amqp-2.7), nested in a
        # group dir (spring/spring-webflux), or nested+versioned (kafka/kafka-clients-3.8).
        # Some packages have directory names that don't match the eval name at all
        # (e.g. aws-sdk-v1 → aws-java/aws-java-sdk-1.11) — use explicit overrides.
        instr_root = repo_root / "dd-java-agent" / "instrumentation"
        candidates: list[Path] = []

        overrides = self._INSTR_DIR_OVERRIDES.get(normalized)
        if overrides:
            for rel_path in overrides:
                candidate = instr_root / rel_path
                if candidate.exists():
                    candidates.append(candidate)
        else:
            # Direct: instrumentation/{name} or instrumentation/{name}-*
            candidates += list(instr_root.glob(normalized))
            candidates += list(instr_root.glob(f"{normalized}-*"))
            # One level nested: instrumentation/*/{name} or instrumentation/*/{name}-*
            candidates += list(instr_root.glob(f"*/{normalized}"))
            candidates += list(instr_root.glob(f"*/{normalized}-*"))

        for candidate in candidates:
            if candidate.is_dir():
                shutil.rmtree(candidate)
                removed.append(str(candidate.relative_to(repo_root)))

        # 2. Revert modifications to tracked files
        tracked_files = [
            "settings.gradle",
            "dd-java-agent/dd-java-agent.gradle",
        ]
        removed.extend(revert_tracked_files(tracked_files, repo_root, git_source_root))

        return removed

    def get_blind_copy_dirs(self, repo_root: Path) -> list[Path]:
        dirs = super().get_blind_copy_dirs(repo_root)
        instr_dir = repo_root / "dd-java-agent" / "instrumentation"
        if instr_dir.exists():
            dirs.append(instr_dir)
        return dirs

    def get_lint_paths(self, integration_name: str) -> List[str]:
        """Get paths to lint for a Java integration.

        Args:
            integration_name: Name of the integration

        Returns:
            List of paths to lint
        """
        return [
            f"dd-java-agent/instrumentation/{rel_path}/"
            for rel_path in self._instrumentation_relative_paths(integration_name)
        ]

    # =========================================================================
    # Linting - Override to use Gradle spotless
    # =========================================================================

    def lint_paths(self, paths: List[str], repo_root: Path, fix: bool = False) -> Dict[str, Any]:
        """Run Spotless on instrumentation paths.

        dd-trace-java uses Gradle spotless for code formatting.

        Args:
            paths: List of paths to lint (e.g., ['dd-java-agent/instrumentation/jedis/'])
            repo_root: Root of the dd-trace-java repository
            fix: If True, auto-fix issues with spotlessApply

        Returns:
            Dictionary with success status, error counts, and output
        """
        # Build module-specific Gradle tasks from paths
        # Convert paths like 'dd-java-agent/instrumentation/jedis/' to ':dd-java-agent:instrumentation:jedis'
        tasks = []
        for path in paths:
            # Normalize path: remove trailing slash, convert to Gradle module path
            normalized = path.rstrip("/")
            if normalized.startswith("dd-java-agent/instrumentation/"):
                rel_path = normalized.removeprefix("dd-java-agent/instrumentation/")
                task_name = "spotlessApply" if fix else "spotlessCheck"
                tasks.append(f"{self._gradle_project_path(rel_path)}:{task_name}")

        # If no specific tasks, run global spotless
        if not tasks:
            if fix:
                cmd = ["./gradlew", "spotlessApply"]
            else:
                cmd = ["./gradlew", "spotlessCheck"]
        else:
            cmd = ["./gradlew"] + tasks

        try:
            result = subprocess.run(
                cmd,
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                timeout=300,
            )

            raw_output = result.stdout + result.stderr

            # Spotless will return non-zero if formatting is needed
            return {
                "success": result.returncode == 0,
                "error_count": 0 if result.returncode == 0 else 1,
                "warning_count": 0,
                "fixable_count": 0 if result.returncode == 0 or fix else 1,
                "errors": [],
                "raw_output": raw_output,
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": "Spotless timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": f"Spotless failed: {e}",
            }
