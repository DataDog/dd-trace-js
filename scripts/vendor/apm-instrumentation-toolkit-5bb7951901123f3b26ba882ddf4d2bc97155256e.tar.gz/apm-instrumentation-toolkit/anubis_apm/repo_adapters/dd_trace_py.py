"""dd-trace-py adapter - extends generic adapter with APM-specific methods."""

import logging
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional

import docker.errors
from anubis.core.config import get_config
from anubis.core.repo_adapters import PythonRepoAdapter
from docker.client import DockerClient

from .base import APMAdapterMixin

logger = logging.getLogger(__name__)


class DDTracePyAdapter(PythonRepoAdapter, APMAdapterMixin):
    """Adapter for dd-trace-py - extends generic with dd-trace specific functionality.

    Inherits:
    - Generic methods from PythonRepoAdapter (lint, install, etc.)
    - APM method interface from APMAdapterMixin (get_plugin_path, etc.)

    dd-trace-py structure:
    - Integrations: ddtrace/contrib/internal/{integration_name}/
    - Tests: tests/contrib/{integration_name}/
    - Test runner: riot (with pytest via scripts/ddtest)
    - CI: GitLab CI with suitespec.yml (jobs auto-defined from suitespec)
    """

    language: str = "python"
    repository_id: str = "dd_trace_py"

    REFERENCE_INTEGRATIONS: ClassVar[dict[str, list[str]]] = {
        # Semantic convention categories (from apm_semantic_conventions.list_categories())
        "aws": [
            "ddtrace/contrib/internal/botocore/",
            "ddtrace/contrib/internal/boto/",
        ],
        "cache": [
            "ddtrace/contrib/internal/redis/",
            "ddtrace/contrib/internal/pylibmc/",
            "ddtrace/contrib/internal/pymemcache/",
        ],
        "database": [
            "ddtrace/contrib/internal/psycopg/",
            "ddtrace/contrib/internal/mysql/",
            "ddtrace/contrib/internal/sqlalchemy/",
        ],
        "graphql": [
            "ddtrace/contrib/internal/graphql/",
        ],
        "grpc-client": [
            "ddtrace/contrib/internal/grpc/",
        ],
        "grpc-server": [
            "ddtrace/contrib/internal/grpc/",
        ],
        "http-client": [
            "ddtrace/contrib/internal/requests/",
            "ddtrace/contrib/internal/httpx/",
            "ddtrace/contrib/internal/urllib3/",
        ],
        "http-server": [
            "ddtrace/contrib/internal/flask/",
            "ddtrace/contrib/internal/django/",
            "ddtrace/contrib/internal/fastapi/",
        ],
        "llm": [
            "ddtrace/contrib/internal/anthropic/",
            "ddtrace/contrib/internal/openai/",
            "ddtrace/contrib/internal/langchain/",
        ],
        "messaging": [
            "ddtrace/contrib/internal/kafka/",
            "ddtrace/contrib/internal/celery/",
        ],
        "search": [
            "ddtrace/contrib/internal/elasticsearch/",
            "ddtrace/contrib/internal/algoliasearch/",
        ],
        # Datadog feature categories (FeatureId values)
        "dsm": [
            "ddtrace/contrib/internal/kafka/",
            "ddtrace/contrib/internal/celery/",
        ],
        "context_propagation": [
            "ddtrace/contrib/internal/kafka/",
            "ddtrace/contrib/internal/celery/",
            "ddtrace/contrib/internal/requests/",
        ],
        "dbm": [
            "ddtrace/contrib/internal/psycopg/",
            "ddtrace/contrib/internal/mysql/",
            "ddtrace/contrib/internal/mysqldb/",
        ],
        "peer_service": [
            "ddtrace/contrib/internal/requests/",
            "ddtrace/contrib/internal/redis/",
            "ddtrace/contrib/internal/psycopg/",
        ],
    }

    @property
    def adapter_dir(self) -> Path:
        """Get adapter directory (bundled read-only resource)."""
        return (
            get_config().toolkit_install_root / "anubis_apm" / "repo_adapters_impl" / "dd_trace_py"
        )

    def get_static_analyzer_scripts(self) -> Dict[str, Path]:
        """Get Python-specific static analyzer scripts."""
        py_dd_analyze = self.adapter_dir / "dd_analyze" / "src"
        return {
            "function_finder": py_dd_analyze / "analyzers" / "find_function.py",
            "method_extractor": py_dd_analyze / "analyzers" / "extract_all_methods.py",
            "context_capture": py_dd_analyze / "context_capture" / "capture.py",
        }

    def get_sample_app_filename(self) -> str:
        """Get Python sample app filename."""
        return "sample_app.py"

    def get_context_capture_command(
        self,
        *,
        context_capture_tool: str,
        analysis_file: str,
        sample_app_path: str,
        context_output_file: str,
        repo_root: Optional[Path] = None,
    ) -> str:
        """Build dd-trace-py context-capture command."""
        return " ".join(
            self.get_runtime_command(
                Path(context_capture_tool),
                analysis_file,
                sample_app_path,
                context_output_file,
            )
        )

    def get_plugin_path(self, integration_name: str) -> str:
        """Get the path to a Python integration directory.

        Args:
            integration_name: Name of the integration (e.g., 'flask', 'redis')

        Returns:
            Path to integration directory (e.g., 'ddtrace/contrib/internal/flask/')
        """
        normalized = self._normalize_integration_name(integration_name)
        return f"ddtrace/contrib/internal/{normalized}/"

    def get_test_file_path(self, integration_name: str) -> str:
        """Get the path to the test directory for a Python integration.

        Args:
            integration_name: Name of the integration (e.g., 'flask', 'redis')

        Returns:
            Path to test directory (e.g., 'tests/contrib/flask/')
        """
        normalized = self._normalize_integration_name(integration_name)
        return f"tests/contrib/{normalized}/"

    def get_test_command(self, integration_name: str, output_dir: Optional[Path] = None) -> str:
        """Get the command to run tests for a Python integration.

        Uses scripts/ddtest which wraps riot and handles the test environment.

        Args:
            integration_name: Name of the integration to test
            output_dir: Optional directory for test output logs

        Returns:
            Shell command string to run tests
        """
        normalized = self._normalize_integration_name(integration_name)

        cmd = f"scripts/ddtest riot run --pass-env {shlex.quote(normalized)}"

        if output_dir:
            log_file = output_dir / "test-output.log"
            cmd += f" 2>&1 | tee {shlex.quote(str(log_file))}"

        return cmd

    evalya_language_prefix: str = "python"
    # Package list is computed at runtime from the evalya OCI cache
    # (~/.evalya/cache/.../defs/iat/python-*) by APMAdapterMixin.get_evalya_packages.

    # Debian Bullseye (GLIBC 2.31) — evalya IAT sample app containers use a
    # Bullseye-based Python image. Bookworm (2.36) produces a .so that
    # requires GLIBC 2.32+, which is not available in Bullseye containers.
    # Internal mirror — Docker Hub is unreachable from the DinD CI sidecar.
    # Slim variant — mirrors only carry slim images; build-essential/cmake are apt-installed.
    # Bullseye (GLIBC 2.31) required: evalya's app-ddtrace container is Bullseye; a bookworm
    # builder (GLIBC 2.36) produces .so files that crash import on the target.
    _BUILDER_IMAGE = "registry.ddbuild.io/images/mirror/python:3.12-slim-bullseye"

    # Maps PyPI package names to their internal DD integration directory names
    # when they differ (e.g. the psycopg2 package is instrumented by ddtrace's
    # "psycopg" integration at ddtrace/contrib/internal/psycopg/).
    _INTEGRATION_NAME_MAP: ClassVar[dict[str, str]] = {
        "psycopg2": "psycopg",
    }
    _RUST_CACHE_VOLUME = "dd-apm-rust-cache"

    def prepare_eval_worktree(
        self, worktree_path: Path, evalya_def_path: Optional[str] = None
    ) -> None:
        """Build dd-trace-py native extensions inside a Linux Python 3.12 container.

        Evalya defs (notably redis) bind-mount ``${TRACER_DIR}/ddtrace`` over
        the baked-in copy in a Linux Python 3.12 container. A fresh clone has
        no compiled ``_native.cpython-*.so`` (build artifact, not in git), so
        the overlay hides the baked-in ``.so`` and ``import ddtrace`` crashes
        with ``ModuleNotFoundError: ddtrace.internal.native._native``.

        Strategy: always run ``pip install -e .`` inside a Linux Python 3.12
        Docker container so the produced ``.so`` carries the
        ``cpython-312-x86_64-linux-gnu`` abi tag that evalya's app container
        expects — regardless of whether dd-apm itself is running on macOS,
        a different Python version, or Linux CI. Rust toolchain state is
        cached in a named Docker volume so subsequent runs skip the
        ``rustup`` install.
        """
        if not worktree_path.exists():
            logger.warning("prepare_eval_worktree: %s does not exist, skipping", worktree_path)
            return

        ddtrace_dir = worktree_path / "ddtrace"
        if not ddtrace_dir.exists():
            logger.warning("prepare_eval_worktree: no ddtrace/ in %s, skipping", worktree_path)
            return

        # Skip if any compiled _native.so is already present for the active platform.
        native_dir = ddtrace_dir / "internal" / "native"
        existing_so = (
            next(native_dir.glob("_native.cpython-*.so"), None) if native_dir.exists() else None
        )
        if existing_so is not None:
            logger.info("prepare_eval_worktree: %s already present, skipping", existing_so.name)
            return

        # Build inside Linux Python 3.12. The produced .so abi tag matches the
        # docker daemon's default arch (aarch64 on Apple Silicon, x86_64 on
        # Linux CI), which is also what evalya's app container runs as on the
        # same host. ~/.cargo and ~/.rustup live in a named volume so rustup
        # install happens once per host.
        build_script = (
            "set -e; "
            "if [ ! -x /usr/bin/cmake ] || ! command -v g++ >/dev/null; then "
            "  apt-get update -qq && "
            "  apt-get install -y -qq --no-install-recommends "
            "    build-essential cmake pkg-config libssl-dev libffi-dev curl git; "
            "fi; "
            "if [ ! -x /root/.cargo/bin/cargo ]; then "
            "  curl -fsSL --proto '=https' --tlsv1.2 https://sh.rustup.rs "
            "    | sh -s -- -y --default-toolchain stable --profile minimal; "
            "fi; "
            "export PATH=/root/.cargo/bin:$PATH; "
            "pip install --disable-pip-version-check -e ."
        )
        log_path = worktree_path / ".dd-apm-prepare-build.log"
        logger.info(
            "prepare_eval_worktree: docker build via %s (log: %s)", self._BUILDER_IMAGE, log_path
        )

        try:
            client = DockerClient.from_env()
        except docker.errors.DockerException as exc:
            logger.warning("prepare_eval_worktree: Docker not available — %s", exc)
            return

        try:
            client.images.pull(self._BUILDER_IMAGE)
        except docker.errors.APIError as exc:
            logger.warning(
                "prepare_eval_worktree: failed to pull %s — %s", self._BUILDER_IMAGE, exc
            )
            return

        container = client.containers.create(
            self._BUILDER_IMAGE,
            command=["bash", "-c", build_script],
            volumes={
                str(worktree_path.absolute()): {"bind": "/tracer", "mode": "rw"},
                self._RUST_CACHE_VOLUME: {"bind": "/root", "mode": "rw"},
            },
            working_dir="/tracer",
            environment={"TERM": "dumb", "NO_COLOR": "1"},
            stdin_open=False,
        )
        try:
            container.start()
            try:
                exit_info = container.wait(timeout=1800)
            except Exception:
                logger.warning("prepare_eval_worktree: docker build timed out after 30 min")
                return
            logs = container.logs(stdout=True, stderr=True)
        finally:
            container.remove(force=True)

        log_content = (
            logs.decode("utf-8", errors="replace") if isinstance(logs, bytes) else str(logs)
        )
        try:
            log_path.write_text(log_content)
        except OSError as exc:
            logger.warning("Could not write build log to %s: %s", log_path, exc)

        exit_code = exit_info.get("StatusCode", -1)
        if exit_code != 0:
            logger.warning(
                "prepare_eval_worktree: docker build failed (exit %d). "
                "Full log saved to %s. Last 2000 chars:\n%s",
                exit_code,
                log_path,
                log_content[-2000:],
            )
        else:
            built = next(native_dir.glob("_native.cpython-*.so"), None)
            if built is not None:
                logger.info("prepare_eval_worktree: built %s", built.name)
            else:
                logger.warning(
                    "prepare_eval_worktree: build succeeded but no _native.so produced (log: %s)",
                    log_path,
                )

    def setup_tracing_precheck(self, integration_name: str, ctx: Any) -> None:
        """Set dd-trace-py tracing precheck context values."""
        repo_root = get_config().get_repo_root(ctx.repository)
        plugin_path = repo_root / self.get_plugin_path(integration_name)
        ctx.set("tracing_plugin_path", str(plugin_path))
        ctx.set("tracing_test_command", self.get_test_command(integration_name))

    def get_ground_truths_path(self) -> Optional[Path]:
        path = (
            Path(__file__).parent.parent
            / "eval"
            / "analyze"
            / "datasets"
            / "ground_truths"
            / "dd_trace_py"
        )
        return path if path.exists() else None

    def get_blind_copy_dirs(self, repo_root: Path) -> list[Path]:
        dirs = super().get_blind_copy_dirs(repo_root)
        contrib_dir = repo_root / "ddtrace" / "contrib" / "internal"
        if contrib_dir.exists():
            dirs.append(contrib_dir)
        return dirs

    def get_instrumentation_deny_paths(
        self, repo_root: Path, integration_name: str = ""
    ) -> list[str]:
        contrib_dir = repo_root / "ddtrace" / "contrib" / "internal"
        if not contrib_dir.exists():
            return []
        if integration_name:
            name = integration_name.replace("-", "_").lower()
            target = contrib_dir / name
            return [f"Read({target}/**)", f"Glob({target}/**)"]
        return [f"Read({contrib_dir}/**)", f"Glob({contrib_dir}/**)"]

    def remove_integration(
        self,
        integration_name: str,
        repo_root: Path,
        git_source_root: Optional[Path] = None,
    ) -> List[str]:
        """Remove all files/changes for a generated dd-trace-py integration.

        Args:
            integration_name: e.g. "flask", "psycopg"
            repo_root: Path to the dd-trace-py repo root
            git_source_root: Original git checkout for restoring tracked files
                in plain-copy worktrees (no ``.git``)

        Returns:
            List of paths that were removed/reverted
        """

        removed: List[str] = []
        name = self._normalize_integration_name(integration_name)

        # 1. Delete internal contrib package
        internal_dir = repo_root / "ddtrace" / "contrib" / "internal" / name
        if internal_dir.exists():
            shutil.rmtree(internal_dir)
            removed.append(str(internal_dir.relative_to(repo_root)))

        # 2. Delete top-level contrib wrapper
        wrapper = repo_root / "ddtrace" / "contrib" / f"{name}.py"
        if wrapper.exists():
            wrapper.unlink()
            removed.append(str(wrapper.relative_to(repo_root)))

        # 3. Delete test directory
        test_dir = repo_root / "tests" / "contrib" / name
        if test_dir.exists():
            shutil.rmtree(test_dir)
            removed.append(str(test_dir.relative_to(repo_root)))

        # 4. Delete snapshot files
        snapshots_dir = repo_root / "tests" / "snapshots"
        if snapshots_dir.exists():
            pattern = f"tests.contrib.{name}."
            for snapshot in snapshots_dir.glob(f"{pattern}*"):
                snapshot.unlink()
                removed.append(str(snapshot.relative_to(repo_root)))

        # 5. Revert modifications to tracked files
        tracked_files = [
            "ddtrace/contrib/integration_registry/registry.yaml",
            "tests/contrib/suitespec.yml",
            "riotfile.py",
            "docs/integrations.rst",
        ]
        for rel_path in tracked_files:
            full_path = repo_root / rel_path
            if not full_path.exists():
                continue
            result = subprocess.run(
                ["git", "diff", "--quiet", rel_path],
                cwd=repo_root,
                capture_output=True,
            )
            if result.returncode != 0:
                subprocess.run(
                    ["git", "checkout", "--", rel_path],
                    cwd=repo_root,
                    capture_output=True,
                )
                removed.append(f"{rel_path} (reverted)")

        return removed

    def get_required_test_services(self) -> List[str]:
        """Get Docker services required for dd-trace-py tests.

        The testagent service provides a mock APM agent for snapshot testing.
        """
        return ["testagent"]

    def get_lint_paths(self, integration_name: str) -> List[str]:
        """Get paths to lint for a Python integration.

        Args:
            integration_name: Name of the integration

        Returns:
            List of paths to lint
        """
        normalized = self._normalize_integration_name(integration_name)
        return [f"ddtrace/contrib/internal/{normalized}/", f"tests/contrib/{normalized}/"]

    # =========================================================================
    # Internal helpers
    # =========================================================================

    # =========================================================================
    # Internal helpers
    # =========================================================================

    def _normalize_integration_name(self, name: str) -> str:
        """Normalize integration name for dd-trace-py.

        Python package names use underscores, not hyphens.  Also applies
        _INTEGRATION_NAME_MAP for packages whose PyPI name differs from the
        internal DD integration directory name (e.g. psycopg2 → psycopg).
        """
        normalized = name.replace("-", "_").lower()
        return self._INTEGRATION_NAME_MAP.get(normalized, normalized)
