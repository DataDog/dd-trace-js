"""APM-specific repo adapters.

These extend the generic RepoAdapter from anubis with APM domain-specific methods.
"""

from typing import Union

from ._repos import get_repo_def
from .base import APMAdapterMixin
from .dd_trace_java import DDTraceJavaAdapter
from .dd_trace_js import DDTraceJsAdapter
from .dd_trace_py import DDTracePyAdapter

# All concrete adapters inherit from both RepoAdapter and APMAdapterMixin.
APMAdapter = Union[DDTraceJsAdapter, DDTracePyAdapter, DDTraceJavaAdapter]

_ADAPTER_MAP: dict[str, type[APMAdapter]] = {
    "dd_trace_js": DDTraceJsAdapter,
    "dd_trace_py": DDTracePyAdapter,
    "dd_trace_java": DDTraceJavaAdapter,
}


def get_apm_adapter(repository: str) -> APMAdapter:
    """Get the APM adapter for a repository.

    Args:
        repository: Repository name ('dd_trace_js', 'dd_trace_py', 'dd_trace_java', or with hyphens)

    Returns:
        APM adapter instance for the repository

    Raises:
        ValueError: If no adapter exists for the repository
    """
    normalized = repository.replace("-", "_")

    adapter_cls = _ADAPTER_MAP.get(normalized)
    if adapter_cls is not None:
        return adapter_cls()

    repo_def = get_repo_def(normalized)
    if repo_def:
        supported = ", ".join(_ADAPTER_MAP.keys())
        raise ValueError(
            f"Repository '{repository}' is known but does not have an APM adapter yet.\n"
            f"Supported adapters: {supported}"
        )
    raise ValueError(f"Unknown repository: {repository}")


__all__ = [
    "APMAdapter",
    "APMAdapterMixin",
    "DDTraceJavaAdapter",
    "DDTraceJsAdapter",
    "DDTracePyAdapter",
    "get_apm_adapter",
]
