"""APM-specific prompts for dd-trace workflows.

Prompts are organized under shared/ by workflow, with repo-specific content in repo/ subdirs:
- shared/{workflow}/prompt.md        - Shared prompt template
- shared/{workflow}/repo/{repo}/     - Repo-specific content (included via {{include:}})
- dd_trace_js/                       - Legacy location (being migrated to shared/)
"""
