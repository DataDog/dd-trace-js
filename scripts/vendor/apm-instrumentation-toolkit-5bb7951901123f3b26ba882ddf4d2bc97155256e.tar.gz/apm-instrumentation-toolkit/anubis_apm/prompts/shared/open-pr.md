# Open Pull Request

Create a GitHub pull request for the changes on this branch.

## Context

{{pr_context}}

## Working Directory

You are in: `{{working_dir}}`

## Instructions

Follow the `pr` skill to create a well-structured PR. Key points:

1. Run pre-flight checks (branch, uncommitted changes, commits ahead)
2. Commit any uncommitted changes first if needed
3. Check for an existing PR on this branch
4. Generate a good title and description from the changes
5. Create as **draft** PR (unless told otherwise)
6. Add the `ai-generated` label
7. Skip the review cycle — the caller will handle that separately if needed
