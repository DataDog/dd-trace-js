## Package Location

The package is installed at: `.analysis/{{package_name}}/node_modules/{{package_name}}`

## Reference: All Methods

A complete list of all extracted methods from the package is available at:
`.analysis/{{package_name}}/static/all-methods.json`

Use this file to help locate methods - it may contain file paths and line numbers that
the automatic enrichment missed.

### JavaScript/Node.js File Patterns

- Look in `dist/`, `lib/`, `src/` directories
- Check `.js`, `.mjs`, `.cjs` extensions
- For `Class.prototype.method`, search for:
  - `class Class { method(` (ES6 class syntax)
  - `Class.prototype.method` (prototype assignment)

## Common Patterns

The package may use:
- ESM: `export class Foo { method() {} }`
- CommonJS: `Foo.prototype.method = function() {}`
- TypeScript compiled to JS in dist/ or lib/
- Re-exports from sub-packages

## ESM Counterpart Errors

If validation errors mention `file_paths has no ESM entry`, the package ships both
CJS and ESM builds and the target's `file_paths` list is missing the ESM location.

To fix:
1. Read `package.json` and check the `exports` map for `"import"` fields — those are the ESM entry points
2. Also check for a `"module"` field (legacy rollup convention)
3. Scan for `.mjs` files or `*.js` files inside `esm/` or `dist/esm/` directories
4. Search the ESM files for the method (class shorthand `method(`, `export function method`, etc.)
5. Add the found path to `file_paths` with `"module_type": "esm"`

**Important**: After updating `file_paths` in the enrichment output, also update the
corresponding entry in `data/agent.json` so downstream generation steps see the ESM paths.
The agent.json uses the same `file_paths` structure under `analysis.instrumentation_targets[]`.
