# Fix Enrichment Validation Errors

The enrichments for the `{{package_name}}` package have validation errors.
Your task is to fix these errors by locating the methods in the package source code
and updating the output with correct file paths and line numbers.

## Validation Errors

{{validation_errors}}

## Current Output

```json
{{current_output}}
```

## Search Strategy

1. **Check method inventory first** - methods may already be catalogued there
2. **Search package source files** using grep or search tools

{{include_repo:patterns}}

## Sub-Package Handling

If a method is re-exported from a dependency:
1. Set `module_name` to the actual package where the function is defined
2. Use file paths relative to that package (not `../other-package/...`)

## Output Requirements

Update the enrichment data to fix the missing targets:
- Set `file_path` to the relative path within the package
- Set `line_number` to where the method is defined
- Set `kind` to `async` or `sync`
- Clear `missing_targets` when all targets are found
- Set `success` to `true` when complete
