### Java Enrichment Patterns

Java packages are **downloaded from Maven Central**, not checked out as source. The
install step produces two things next to the analysis directory:

- `lib/<artifact>-<version>.jar` — the compiled bytecode (always present).
- `sources/` — the unpacked `-sources.jar`, present **only when the library
  publishes one**. It contains real `.java` files laid out by package path, e.g.
  `sources/io/reactivex/rxjava3/core/Observable.java`.

Do **not** search the host filesystem broadly for `.java` files, and do **not**
look for `src/main/java/` — there is no source checkout. Use the `sources/`
directory below, the library's upstream repository, or the compiled bytecode — in
that order of preference.

**1. If `sources/` exists** (preferred — local, accurate line numbers):
- Map the fully-qualified class to its path: `io.reactivex.rxjava3.core.Observable`
  → `sources/io/reactivex/rxjava3/core/Observable.java`.
- Open that file, find the method, and set `file_path` (relative to `sources/`)
  and `line_number`.
- The actual implementation may live in an abstract base class or interface — if
  the method isn't where expected, check the type's supertypes.

**2. If `sources/` is absent, consult the upstream source on GitHub.** Most Java
libraries are open source. Find the project's repository (the Maven group id
usually maps to it — e.g. `io.reactivex.rxjava3` → `github.com/ReactiveX/RxJava`),
check out the tag matching the analyzed version (e.g. `v3.1.8`), and read the
real `.java` source with `WebFetch` / web search. Use it to:
- Locate the method and record a `file_path` (the repo-relative source path, e.g.
  `src/main/java/io/reactivex/rxjava3/core/Observable.java`) and `line_number`.
- Understand the method's semantics, async behaviour, and supertypes so the
  instrumentation hook point is correct.
- Match the version: APIs move between releases, so use the tag for the analyzed
  version, not `main`.

**3. If no source can be found anywhere** (no sources jar, repo not locatable):
- Confirm the method exists in the compiled bytecode. Use the method inventory
  already produced by the `all_methods` step, or run
  `javap -p -classpath lib/<artifact>-<version>.jar <fully.qualified.Class>` and
  look for the method.
- Once confirmed, set **`confirmed_in_library: true`** and leave `file_path`
  empty / `line_number` 0. A target with `confirmed_in_library: true` counts as
  found — Java bytecode instrumentation matches by fully-qualified class + method
  signature, not by source location, so a file path is not required.
- Do not loop trying to produce a `file_path` you cannot get; `confirmed_in_library`
  is the correct, complete answer when no source is available.
