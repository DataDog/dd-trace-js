### Python Search Patterns

When searching package source files:
- Look for `.py` files in the package directory and subdirectories (`core/`, `base/`, `_internal/`)
- For `Class.method`: search `def method(self`, `async def method(self`, `@classmethod`, `@staticmethod`
- Check `__init__.py` for re-exports that redirect to real module locations
- Follow module paths: `llama_index.core.base.embeddings.base` maps to `core/base/embeddings/base.py`
