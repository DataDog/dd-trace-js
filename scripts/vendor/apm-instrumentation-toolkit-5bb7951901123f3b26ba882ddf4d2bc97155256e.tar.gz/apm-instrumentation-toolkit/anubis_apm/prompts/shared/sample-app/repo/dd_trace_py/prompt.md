### Python Sample App Requirements

Generate a class-based Python sample app that exercises instrumentation targets.

#### Structure

- Single `{ClassName}SampleApp` class with `setup()`, `teardown()`, `run_all()` methods
- One method per instrumentation target, named `{class_name}_{method_name}` in snake_case
- Each method: call the real library API, capture context, handle errors gracefully
- Save captured contexts to `context-snapshot.json` via `json.dump()`

#### Import

- Import the exact package: `import {{package_name_normalized}}` (normalize hyphens to underscores)

#### Context Capture

Each capture dict must include: `className`, `methodName`, `self` (repr of instance), `arguments` (list of repr), `kwargs` (dict of repr), `result` (repr or None), `error` (dict with message/name if any)

#### Validation

1. Run: `python3 {{analysis_dir}}/{{sample_app_filename}}`
2. Check: `{{analysis_dir}}/context-snapshot.json`
3. Verify captures exist for each target, fix errors and retry
