### Java Sample App Requirements

**IMPORTANT: All generated Java files MUST be standard Java classes with proper package declaration.**

**Class Structure:**
```java
public class <PackageName>SampleApp {
  public void setup() throws Exception {
    // Connect to required services
    // Initialize clients
  }

  public void teardown() throws Exception {
    // Disconnect from services
    // Cleanup resources
  }

  // Operation methods (one per instrumentation)
  public void <operation>() throws Exception {
    // Call the actual instrumented method
    // Use real data/payloads
  }

  public static void main(String[] args) throws Exception {
    <PackageName>SampleApp app = new <PackageName>SampleApp();
    app.setup();
    try {
      app.<operation>();
    } finally {
      app.teardown();
    }
  }
}
```

**Operation Method Naming (camelCase):**
- **Format**: `{className}{MethodName}` in camelCase (e.g., `connectionQuery`, `statementExecute`)
- Convert class+method to camelCase: `Connection.query` → `connectionQuery`
- **IMPORTANT**: For each operation method, create an `Error` variant that triggers an error (e.g., `connectionQueryError`)
  - The error variant should intentionally cause an error by providing invalid parameters

**Service Ports:**
- Redis: 6379, Kafka: 9092, PostgreSQL: 5432, MongoDB: 27017, RabbitMQ: 5672, MySQL: 3306

**CRITICAL: Wrap every operation method in try-catch** so that if one operation fails, the app continues and exercises the remaining operations.

**Run with:** `java -javaagent:dd-java-agent.jar -jar sample-app.jar`
