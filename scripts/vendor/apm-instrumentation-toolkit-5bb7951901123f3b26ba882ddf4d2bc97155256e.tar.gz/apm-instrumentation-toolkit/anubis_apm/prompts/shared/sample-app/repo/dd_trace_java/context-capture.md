No context capture needed for Java.
