### Node.js Sample App Requirements

**IMPORTANT: All generated JavaScript files MUST start with these lines at the very top:**
```javascript
'use strict'

/* eslint-disable no-console */
/* eslint-disable n/no-extraneous-require */
```

**Class Structure:**
```javascript
'use strict'

/* eslint-disable no-console */
/* eslint-disable n/no-extraneous-require */

class <PackageName>SampleApp {
  async setup() {
    // Connect to required services
    // Initialize clients
  }

  async teardown() {
    // Disconnect from services
    // Cleanup resources
  }

  // Operation methods (one per instrumentation)
  async <operation>() {
    // Call the actual instrumented method
    // Use real data/payloads
  }
}
```

**Operation Method Naming (camelCase):**
- **Format**: `{className}{MethodName}` in camelCase (e.g., `connectionQuery`, `connectionBeginTransaction`, `poolQuery`)
- Convert class+method to camelCase: `Connection.query` → `connectionQuery`
- If there's no class name, use just the method name in camelCase: `query`
- **IMPORTANT**: For each operation method, create an `Error` variant that triggers an error (e.g., `connectionQueryError`, `poolQueryError`)
  - The error variant should intentionally cause an error by providing invalid parameters
  - This allows testing error handling and error tag capture

**Service Ports:**
- Redis: 6379, Kafka: 9092, PostgreSQL: 5432, MongoDB: 27017, RabbitMQ: 5672, MySQL: 3306

**Example for bull (Redis-based queue):**
```javascript
'use strict'

/* eslint-disable no-console */
/* eslint-disable n/no-extraneous-require */

const Queue = require('bull');

class BullSampleApp {
  async setup() {
    this.queue = new Queue('test-queue', {
      redis: { host: '127.0.0.1', port: 6379 }
    });
    console.log('✓ Connected to Redis');
  }

  async teardown() {
    await this.queue.close();
    console.log('✓ Closed queue');
  }

  async queueAdd () {
    const job = await this.queue.add({ message: 'Hello World' })
    console.log(`✓ Added job ${job.id}`)
  }

  // Error path: intentionally cause an error
  async queueAddError () {
    try {
      await this.queue.add(null, { invalid: 'option' })
    } catch (error) {
      console.log(`✓ Caught expected error: ${error.message}`)
      throw error
    }
  }

  async runAll() {
    try {
      await this.setup();
      console.log('--- Testing queueAdd ---');
      await this.queueAdd();
    } catch (error) {
      console.error(`Fatal error: ${error.message}`);
    } finally {
      await this.teardown();
    }
  }
}

const app = new BullSampleApp();
app.runAll().catch(console.error);
```

**CRITICAL: Wrap every operation method in try-catch** so that if one operation fails, the app continues and captures context for other operations.

**Run with:** `node sample-app.js`
