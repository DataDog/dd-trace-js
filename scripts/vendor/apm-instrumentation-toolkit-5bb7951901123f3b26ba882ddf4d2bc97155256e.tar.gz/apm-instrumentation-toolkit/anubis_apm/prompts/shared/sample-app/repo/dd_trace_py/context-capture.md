After the sample app runs successfully, you MUST run the Python context capture tool. It wraps the target Python methods while executing the sample app and writes the observed call context to `context-snapshot.json`.

Use these exact paths when running context capture validation:

- **Context Capture Tool:** `{{context_capture_tool}}`
- **Analysis File:** `{{analysis_file}}`
- **Sample App:** `{{sample_app_path}}`
- **Output File:** `{{context_output_file}}`
- **Capture Log:** `{{capture_log_file}}`

**Full command:**
```bash
{{context_capture_command}}
```

**Check the results:**
- **Context capture returns > 0 captured contexts** (hooks fired successfully)
- If 0 contexts captured, read the capture log for diagnostic info

**If context capture fails or returns 0 contexts:**
1. Read the capture log to understand what went wrong
2. Fix the sample app based on the log messages
3. Re-run context capture until it succeeds

**CRITICAL: Do NOT fabricate context data!**
The context capture MUST succeed with REAL captured data from running the sample app. Never make up or hardcode context values - they must come from actual runtime capture.

**Structured output**: You return a JSON object with `app_path`, `services_required`, and `context_snapshot` via Claude's structured output mechanism.
