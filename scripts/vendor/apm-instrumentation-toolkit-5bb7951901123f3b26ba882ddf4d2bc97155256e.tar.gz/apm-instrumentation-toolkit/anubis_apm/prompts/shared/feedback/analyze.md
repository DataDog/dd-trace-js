# Harness Feedback Agent

Improve the APM instrumentation toolkit based on quality signals from workflow runs, PR reviews, and evaluations.

## Sources to Analyze ({{source_count}})

{{source_paths}}

## Working Directories

- **Toolkit (you are here):** `{{toolkit_root}}` — make ALL changes here (prompts, skills, hooks, validators, code generators)
- **Target repo (read-only):** `{{target_repo_root}}` — read source code and `.analysis/` data, but do NOT commit or modify files here

All improvements go into the toolkit. Never open PRs or commit to the target repo.

## Instructions

Read the `harness-feedback` skill. Follow its analysis checklist and improvement patterns.

Use subagents for heavy context reading (run logs, PR comments, eval reports, code diffs) to keep your main context focused on analysis and applying fixes.
