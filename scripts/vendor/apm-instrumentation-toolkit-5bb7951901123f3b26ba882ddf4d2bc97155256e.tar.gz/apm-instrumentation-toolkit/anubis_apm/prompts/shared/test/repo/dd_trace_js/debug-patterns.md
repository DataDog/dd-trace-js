### Debug Pattern Guide (dd-trace-js)

Test output for dd-trace-js plugins comes from **mocha**. The toolkit runs
`PLUGINS=<name> npm run test:plugins:ci` (the same command CI uses). Read the
mocha summary + stack traces; the patterns below cover the common failure
shapes.

#### Reading the test output

| What you see | What it usually means |
|---|---|
| `N passing` with `0 failing` | Suite green; if you reached this prompt the run never failed |
| `M failing` followed by stack traces | Real assertion or runtime failures; read each trace top-to-bottom |
| Tests time out (`Error: Timeout of … ms exceeded`) | The integration registered but spans aren't reaching the in-process agent — most often a missing/mistyped channel name, an `esmFirst` mismatch, or `OTEL_TRACES_EXPORTER=otlp` leaking in from the shell |
| `expected X to equal Y` on `tags`/`meta`/`metrics` | Plugin produces a span but the wrong shape — extractor bug |
| `EADDRINUSE`, `ECONNREFUSED` to a port | Per-plugin service (mysql, kafka, etc.) didn't come up; `yarn services` should have provisioned it via `test:plugins:ci` |
| `Cannot find module 'datadog-plugin-…'` | `PLUGINS=` value doesn't match a `packages/datadog-plugin-<name>/` directory — name normalization issue |
| No tests run, just a help banner | `PLUGINS=` is empty or the integration name doesn't resolve to a known plugin |

#### Pass/fail counts

- The mocha summary line at the end (`X passing (Yms)` / `Z failing`) is the
  authoritative test result, not the per-test "✓"/"✗" prefixes which can be
  truncated in piped output.
- Pending tests are counted separately (`W pending`); they don't fail the
  suite.
