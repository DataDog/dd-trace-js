### Node.js Specific Failure Modes

#### `channels`
**Description:** Diagnostic channel publish/subscribe mismatch

**When to use:** Plugin is loaded by the tracer but no spans are produced — the instrumentation's `dc.publish` is firing without a subscriber, or the subscriber is wired to a name nothing publishes.

**Symptoms:**
- Tests time out waiting for spans that never arrive
- `DATADOG TRACER INTEGRATIONS LOADED` lists the plugin, but `agent` (FakeAgent) receives no payloads
- Plugin not receiving instrumentation events despite the integration loading

#### `errors`
**Description:** Error test cases failing

**When to use:** Error tags (error.message, error.type, error.stack) not captured on spans.

**Symptoms:**
- Error test cases timeout
- error: 1 tag missing from span
- Error thrown but not captured on span

#### `plugin_code`
**Description:** Plugin code errors

**When to use:** Syntax errors, logic bugs, or runtime exceptions in plugin files.

**Symptoms:**
- JavaScript syntax errors
- Runtime exceptions in plugin code
- Undefined variable or method errors

#### `orchestrion_instrumentation_config`
**Description:** Orchestrion JSON config issues

**When to use:** Instrumentation config has wrong paths, names, or settings.

**Symptoms:**
- Wrong file path in orchestrion JSON
- Class/method name mismatch
- Wrong operator (tracePromise vs traceCallback)

#### `wrapping`
**Description:** Shimmer wrapping failures

**When to use:** Legacy shimmer.wrap is wrapping the wrong method or signature doesn't match. Wrong type of tracing pattern applied.

**Symptoms:**
- Method wrapped but not called
- Arguments in wrong positions
- Callback not being intercepted
- async tracing being used instead of synchronous tracing

#### `hooking`
**Description:** Instrumentation hook failures. Or lack of instrumentation hooks firing.

**When to use:** Hook point is wrong - instrumenting the wrong lifecycle moment. No hooks or subscriber channel events firing.

**Symptoms:**
- Wrong module name being targeted for tests (tests target package. hooks target package/subpackage)
