## dd-trace-py Test Fix Patterns

### Reference Test Files

| Type | File | What to learn |
|------|------|--------------|
| APM | `tests/contrib/kafka/test_kafka.py` | `test_spans.pop_traces()` + full tag assertions |
| LLMObs | `tests/contrib/anthropic/test_anthropic_llmobs.py` | `_expected_llmobs_llm_span_event` usage |
| Snapshot | `tests/contrib/psycopg/test_psycopg_snapshot.py` | Preferred APM verification |
| VCR cassettes | `tests/contrib/anthropic/cassettes/` | HTTP recording for LLM providers |
| Test conftest | `tests/contrib/anthropic/conftest.py` | VCR setup + fixtures |
| LLMObs utils | `tests/llmobs/_utils.py` | `_expected_llmobs_llm_span_event` definition |

### Valid Patterns

- **APM tests**: call real library, `test_spans.pop_traces()`, assert span name/tags/resource
- **LLMObs tests**: use `_expected_llmobs_llm_span_event` -- assert model_name, provider, messages, tokens
- **LLM tests MUST use actual LLM calls** (via VCR cassettes) -- limit mocking as much as possible

### Forbidden Patterns

- Internal helper tests: `integration._extract_input_messages()` -- always test through real library calls
- Weak assertions: `assert mock_llmobs_writer.enqueue.called` -- use `_expected_llmobs_llm_span_event`
- Skipped tests: `pytest.mark.skip` or `pass` bodies -- implement or remove

### Running Tests

Always use `scripts/run-tests tests/contrib/{{package_name}}/` -- never `pytest` directly.
