### Debug Pattern Guide (dd-trace-py)

Look for these patterns in the test output:

| Pattern | Meaning |
|---------|---------|
| `FAILED` with `AssertionError` | Span/tag assertion mismatch |
| `ModuleNotFoundError` | Missing dependency or wrong riot venv |
| `ConnectionRefusedError` / `ECONNREFUSED` | Docker service not running |
| `riot` errors or `venv` failures | Environment setup issue |
| `pytest.mark.skip` found | Forbidden -- tests must not be skipped |
| `_expected_llmobs_llm_span_event` mismatch | LLMObs tag extraction issue |
| `pop_traces()` returns empty | Spans not being created |
| `Timeout` or test hangs | Span created but not finished, or wrong assertion |

**Interpreting pytest output:**
- Look for `X passed, Y failed, Z errors` summary line
- `E` prefix lines show assertion details
- `>` prefix lines show the failing code line
- Stack traces point to exact file and line number

**Common dd-trace-py debug flags:**
- `DD_TRACE_DEBUG=true` enables verbose tracer logging
- `ddtrace-run` is the CLI entrypoint for tracing applications
- Tests use `riot` for virtualenv management via `scripts/run-tests`
