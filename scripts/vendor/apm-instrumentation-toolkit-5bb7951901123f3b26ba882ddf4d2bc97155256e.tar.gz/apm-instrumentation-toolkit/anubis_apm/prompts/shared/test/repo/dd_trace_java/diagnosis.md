### Java Specific Failure Modes

#### `advice_binding`
**Description:** ByteBuddy advice binding failure

**When to use:** `NoSuchMethodError` or `IllegalArgumentException` during instrumentation.

**Symptoms:**
- `NoSuchMethodError` at runtime
- Advice method signature doesn't match the intercepted method
- `@Advice.Argument` index out of bounds

#### `errors`
**Description:** Error test cases failing

**When to use:** Error tags (error, error.message, error.type) not captured on spans.

**Symptoms:**
- Throwable not propagated through advice exit
- `error` tag missing from span
- Exception swallowed before reaching `@Advice.OnMethodExit`

#### `instrumentation_module`
**Description:** Module registration issues

**When to use:** Instrumentation not being applied at all.

**Symptoms:**
- No spans produced
- `ClassNotFoundException` for instrumented type
- Wrong `typeMatcher()` pattern

#### `span_lifecycle`
**Description:** Span not finishing or scope not closed

**When to use:** Span started but never finished; resource leak warnings.

**Symptoms:**
- Memory leak warnings
- Span never appears in `TEST_WRITER`
- `@Advice.OnMethodExit` not reached due to missing `suppress = Throwable.class`

#### `tag_extraction`
**Description:** Wrong or missing span tags

**When to use:** Span is created but attribute values are wrong.

**Symptoms:**
- `AssertionError` in tag value assertion
- Wrong `db.system`, `net.peer.name`, or other semantic attribute
- Tag set on wrong span in the trace
