## Critical Knowledge

### Span Lifecycle (DO NOT OMIT)

```java
@Advice.OnMethodExit(onThrowable = Throwable.class, suppress = Throwable.class)
public static void onExit(
    @Advice.Enter AgentScope scope,
    @Advice.Thrown Throwable throwable) {
  // CRITICAL: always close scope and finish span
  if (scope == null) return;
  if (throwable != null) {
    scope.span().setError(throwable);
  }
  scope.span().finish();
  scope.close();
}
```

This ensures spans always close even when exceptions are thrown.

### Test Architecture

- Tests use Groovy Spock framework (`*ForkedTest.groovy`, `*Test.groovy`)
- Integration-specific test containers are configured via `@Shared` fields
- Span assertions use `TEST_WRITER.waitForTraces(count)` to wait for async spans
- Tag assertions: `span.tags["db.system"] == "postgresql"` (string equality)

### Error Tests

Errors must propagate through the instrumented method for `throwable` to be non-null in `@Advice.OnMethodExit`. Catch-and-rethrow patterns may swallow the throwable.
