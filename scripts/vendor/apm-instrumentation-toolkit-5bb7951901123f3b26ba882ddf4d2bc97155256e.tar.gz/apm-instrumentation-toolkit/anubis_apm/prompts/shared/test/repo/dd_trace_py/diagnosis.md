## dd-trace-py Test Diagnosis

### Running Tests

**CRITICAL: Always use `scripts/run-tests`, never `pytest` or `riot` directly.**

```bash
scripts/run-tests tests/contrib/{{package_name}}/
scripts/run-tests tests/contrib/{{package_name}}/ -- -k "test_name"
```

### dd-trace-py Failure Modes

| Mode | Symptoms | What to check |
|------|----------|--------------|
| `helper_method_tests` | Tests call `_extract_*()` directly, no `test_spans.pop_traces()` | Tests must exercise real library calls |
| `weak_llmobs_assertions` | `assert mock_llmobs_writer.enqueue.called` only | Must use `_expected_llmobs_llm_span_event` |
| `weak_span_assertions` | `assert len(spans) >= 1` only | Must check span name, tags, resource |
| `shortcuts_detected` | `pytest.mark.skip` or empty test bodies | Never skip -- implement or remove |
| `improper_mocking` | Mocks public library API | Mock internal/I/O layer instead |

### APM vs LLMObs Test Separation

| Type | File pattern | Key assertion |
|------|-------------|---------------|
| APM | `test_*.py` | `test_spans.pop_traces()` + tag checks |
| LLMObs | `test_*_llmobs.py` | `_expected_llmobs_llm_span_event` |

### Reference Test Files

- APM: `tests/contrib/kafka/test_kafka.py`, `tests/contrib/psycopg/test_psycopg.py`
- LLMObs: `tests/contrib/anthropic/test_anthropic_llmobs.py`
- DSM: `tests/contrib/kafka/test_kafka_dsm.py`
