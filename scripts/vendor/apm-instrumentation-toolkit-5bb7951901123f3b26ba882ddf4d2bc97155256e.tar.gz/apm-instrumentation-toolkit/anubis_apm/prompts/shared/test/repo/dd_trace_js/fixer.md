## Critical Knowledge

### The finish() Guard (DO NOT REMOVE)

```javascript
finish (ctx) {
  // CRITICAL GUARD - DO NOT REMOVE
  if (!ctx.hasOwnProperty('result') && !ctx.hasOwnProperty('error')) return
  // ...
}
```

This ensures spans only close when the operation completes.

### Test Architecture

- Source code is in `dd-trace-js/versions/{package}@{version}/`, not node_modules
- Tests use `createIntegrationTestSuite` from plugin-test-helpers
- Package versions defined in `packages/dd-trace/test/plugins/versions/package.json`

### Error Tests

Errors must be thrown WITHIN the instrumented function scope for `ctx.error` to be populated.
