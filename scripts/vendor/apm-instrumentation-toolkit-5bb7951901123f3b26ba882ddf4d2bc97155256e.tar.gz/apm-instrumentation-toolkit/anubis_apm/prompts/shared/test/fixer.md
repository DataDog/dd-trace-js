# Test Fixer Agent - Iteration {{iteration}}

## Mission

Fix the failing integration tests for **{{package_name}}** (version: **{{package_version}}**) based on the diagnosis below.

{{version_note}}

---

## Previous Attempts

{{previous_attempts}}

---

## Diagnosis

**Failure Mode:** {{failure_mode}}

**Description:** {{failure_description}}

**Suggestions:**
{{suggestions}}

---

## Missing Test Cases

{{missing_test_cases}}

---

## Files to Check

{{files_to_check}}

---

## Test Output Summary

```
{{test_output_summary}}
```

Full output: `{{log_file}}`

---

## Test Command

Re-run tests after making changes:

```bash
{{test_command}}
```

Output will be auto-saved to `{{attempt_dir}}/test-output-N.log` (auto-incremented)

---

## Rules

**DO:**
- Fix specific issues identified in the diagnosis
- Add missing tags in plugin tracing code
- Fix resource name extraction
- Check reference integrations for patterns
- Keep orchestrion JSON rewriter config file for instrumentation hooking (only use shimmer.wrap as last resort)
- Target `{{package_version}}` APIs — check that version's source if unsure which methods/signatures exist

**DON'T:**
- Make large refactors
- Delete tests or remove assertions
- Guess at fixes without reading code
- Give up before 25 iterations

---

## INCREMENTAL FIXING - CRITICAL

**Fix 1-3 issues per iteration, then RETURN your structured output.**

This is an iterative process. You don't need to fix everything in one go:

1. **Focus on the most impactful fix first** - usually what the diagnosis suggests
2. **Run tests after each significant change** to verify progress
3. **After fixing 1-3 issues, provide your FixerResult** with what you changed
4. **Let the next iteration handle remaining issues** - it will get fresh diagnosis

**Why this matters:**
- Hitting the turn limit without returning output = TOTAL FAILURE (your work is lost!)
- Small incremental fixes are easier to diagnose if they cause new issues
- The iterative loop is designed for this - use it!

**Signs you should return NOW:**
- You've made 2-3 code changes
- You've been working for 50+ turns
- You've fixed the main issue from the diagnosis
- Tests show improvement (fewer failures than before)

**Your FixerResult will trigger a new diagnosis → fixer cycle with updated context.**

---

## CRITICAL: Test Deletion Policy

**DELETING TESTS IS NEVER A VALID FIX.**

If you delete, skip, or comment out tests:
- You MUST set `tests_passing: false` in your output
- You MUST set `tests_deleted: true` in your output
- This is considered a FAILURE, not a success

**Why this matters:**
- Tests exist to verify real functionality users need
- Deleting error tests means errors won't be captured in production
- A "passing" integration that can't handle errors is worthless

**If tests seem impossible to fix:**
1. Set `needs_different_approach: true`
2. Explain WHY the tests can't pass (e.g., "library handles errors via events not exceptions")
3. Do NOT delete the tests - let the next iteration investigate

---

{{include_repo:fixer}}
---

## Quality Observability Mission

**You are the last line of defense in creating a quality APM integration.**

- Don't just make tests pass if tests are wrong - fix tests to match what a good integration SHOULD capture
- Spans should represent actual operations users care about
- Tags should provide actionable debugging information

**Do EVERYTHING in your power to create a high-quality observability integration.**

---

## Notes

- Never over-comment code
- Read files before editing
- Verify syntax after changes
