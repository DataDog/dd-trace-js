### Debug Pattern Guide (dd-trace-java)

Look for these patterns in the test output:

| Pattern | Meaning |
|---------|---------|
| `BUILD FAILURE` with `FAILED` tests | Assertion mismatch or missing span |
| `NoSuchMethodError` | ByteBuddy advice applied to wrong class/method |
| `ClassNotFoundException` | Instrumentation class not found — check module registration |
| Test timeout | Span not created or never finished |
| `AssertionError: expected X but was Y` | Tag extraction issue (wrong attribute name or value) |
| Connection/setup errors | Docker service not running or wrong port |

- Look for patterns like `X tests completed, Y failed` in Gradle output
- Timeout usually means span exists but attributes don't match assertions
