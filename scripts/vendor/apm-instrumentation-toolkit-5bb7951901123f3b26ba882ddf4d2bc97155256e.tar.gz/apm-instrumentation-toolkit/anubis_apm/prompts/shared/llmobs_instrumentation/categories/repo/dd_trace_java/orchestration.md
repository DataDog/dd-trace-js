### Required Methods (Java)

```java
@Override
public LLMObsSpanRegisterOptions getLLMObsSpanRegisterOptions(AgentSpanContext ctx) {
  // Return options with: spanKind=WORKFLOW or AGENT, operationName
  // NO modelProvider, NO modelName
}

@Override
public void setLLMObsTags(MutableSpan span, Object response, Object request) {
  // Set: inputValue, outputValue (workflow input/output as strings)
  // NO inputMessages, NO outputMessages, NO metrics
}
```
