### Required Methods

```js
getLLMObsSpanRegisterOptions(ctx) {
  // Return: { modelProvider, modelName, spanKind: LlmObsSpanKind.LLM, operationName }
  // modelProvider may be dynamic based on which provider adapter is active
}

setLLMObsTags(ctx) {
  // Extract and set: inputMessages, outputMessages, metrics (tokens), metadata
}
```
