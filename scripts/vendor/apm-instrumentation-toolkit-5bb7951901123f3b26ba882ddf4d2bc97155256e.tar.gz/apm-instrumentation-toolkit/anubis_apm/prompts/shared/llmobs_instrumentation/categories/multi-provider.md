# LLMObs Category: MULTI_PROVIDER

## Overview

`LlmObsCategory.MULTI_PROVIDER` applies to packages that are **multi-provider frameworks** — they abstract over multiple LLM backends and route requests to different providers (e.g., ai-sdk, langchain). These packages do not call a single provider endpoint directly; instead they delegate to provider-specific adapters.

---

## Detection Signals

- Package contains routing or adapter logic to multiple providers
- Methods like `generateText`, `streamText`, `chat` that accept a model/provider parameter
- Backend/adapter pattern: `openai()`, `anthropic()`, `google()` provider factories
- No hard-coded provider URLs — provider is pluggable

---

## Plugin Implementation

- **Span kind:** `LlmObsSpanKind.LLM` (`'llm'`)
- **Instrument:** Top-level generation methods (e.g., `generateText`, `streamText`, `chat`)
- **Extract input messages:** Convert to `{content, role}` array format
- **Extract output messages:** Convert response content to `{content, role}` format
- **Extract token usage:** `input_tokens`, `output_tokens`
- **Extract metadata:** `temperature`, `max_tokens`, `model`, active provider name
- **Multi-provider routing:** Capture which provider/model is being used at runtime

{{include_repo:multi-provider,excluded_repos=dd_trace_py}}

---

## Test Strategy

- **Use VCR cassettes** with proxy baseURL — required for MULTI_PROVIDER
- Configure the provider adapter to use the VCR proxy URL as its base
- **spanKind assertion:** must be `'llm'`
- **Assert:** `inputMessages`, `outputMessages`, `metrics.input_tokens`, `metrics.output_tokens`, `metadata.model_name`, active provider

### Forbidden Patterns

- No mock servers (use VCR cassettes instead)
- No `spanKind: 'workflow'` or `spanKind: 'agent'`
- No pure function tests without cassette setup

---

## Notes

- Multi-provider frameworks may wrap provider-specific SDKs — instrument the framework layer, not the underlying SDK
- The `modelProvider` tag should reflect the actual provider being used (not the framework name)
- Study the ai-sdk or langchain plugin examples in the `llmobs-integration` skill if available
