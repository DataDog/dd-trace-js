# LLMObs Category: TOOL_CLIENT

## Overview

`LlmObsCategory.TOOL_CLIENT` applies to packages that are **protocol clients for tool execution and resource retrieval** in LLM applications (e.g., mcp-client implementing Model Context Protocol). These packages are part of LLM workflows but do not make LLM API calls themselves — they provide tool and resource access for LLM agents.

---

## Detection Signals

- Package implements a standard protocol for LLM tool access (e.g., MCP, function calling infrastructure)
- Methods for calling tools (`callTool`, `executeTool`) and retrieving resources (`getResource`, `getPrompt`)
- Not a direct LLM API wrapper — no chat completion methods
- Provides structured tool results back to LLM agents

---

## Plugin Implementation

- **Span kinds:** `LlmObsSpanKind.TOOL` (`'tool'`) and `LlmObsSpanKind.RETRIEVAL` (`'retrieval'`)
- **Map operations:**
  - Tool execution methods → `TOOL` span kind (e.g., `callTool()`)
  - Resource retrieval methods → `RETRIEVAL` span kind (e.g., `getResource()`, `getPrompt()`)
  - Autocomplete/suggestions → Regular APM span only, no LLMObs span
- **Set span tags for operation details:**
  - Tool calls: `tool.name`, `tool.parameters`
  - Resource access: `resource.uri`, `resource.type`
  - Protocol metadata: `protocol.name`, `protocol.version`

{{include_repo:tool-client,excluded_repos=dd_trace_py}}

---

## Test Strategy

- **Use mock server tests** — protocol clients need a mock server responding to protocol requests
- **NOT VCR cassettes** — VCR is for HTTP APIs; protocol clients use structured protocols
- **spanKind assertions:** must be `'tool'` or `'retrieval'`, NOT `'llm'`
- Test tool execution: call a tool method, assert TOOL span with correct tool name and parameters
- Test resource retrieval: retrieve a resource, assert RETRIEVAL span with correct URI and type
- **Validate protocol-specific metadata** in span tags

### Forbidden Patterns

- **FATAL:** VCR cassettes (protocol clients need mock servers)
- **FATAL:** `spanKind: 'llm'`
- **FATAL:** `inputMessages` / `outputMessages` (tool spans use metadata, not messages)

---

## Example: MCP Client

The Model Context Protocol (MCP) client is the canonical TOOL_CLIENT:
- `callTool(name, params)` → `TOOL` span with `tool.name` and `tool.parameters` tags
- `getResource(uri)` → `RETRIEVAL` span with `resource.uri` tag
- `getPrompt(name)` → `RETRIEVAL` span with `resource.type: 'prompt'` tag
- `complete(ref, arg)` → Regular APM span only (not an LLMObs span)

`span_kinds_supported: ["tool", "retrieval"]`

---

## Notes

- TOOL_CLIENT packages ARE part of LLM workflows — always create LLMObs instrumentation
- These packages bridge LLM agents to external tools and data sources
- Study the mcp-client plugin in the `llmobs-integration` skill if available
