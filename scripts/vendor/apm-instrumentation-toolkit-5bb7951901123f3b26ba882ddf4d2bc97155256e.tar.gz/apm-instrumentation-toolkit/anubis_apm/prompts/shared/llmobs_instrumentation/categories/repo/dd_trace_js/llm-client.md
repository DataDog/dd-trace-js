### Required Methods

```js
getLLMObsSpanRegisterOptions(ctx) {
  // Return: { modelProvider, modelName, spanKind: LlmObsSpanKind.LLM, operationName }
}

setLLMObsTags(ctx) {
  // Extract and set: inputMessages, outputMessages, metrics (tokens), metadata
}
```
