### Required Methods (Java)

```java
@Override
public LLMObsSpanRegisterOptions getLLMObsSpanRegisterOptions(AgentSpanContext ctx) {
  // Return options with: spanKind=TOOL or RETRIEVAL, operationName
  // Span kind depends on which operation type is being instrumented
}

@Override
public void setLLMObsTags(MutableSpan span, Object response, Object request) {
  // Set protocol-specific metadata
  // Tool calls: tool name, parameters
  // Resource retrieval: resource URI, type
}
```
