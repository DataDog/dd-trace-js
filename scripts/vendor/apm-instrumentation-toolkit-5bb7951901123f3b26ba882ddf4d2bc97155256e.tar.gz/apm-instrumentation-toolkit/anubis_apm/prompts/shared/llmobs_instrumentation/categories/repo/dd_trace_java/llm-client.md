### Required Methods (Java)

```java
@Override
public LLMObsSpanRegisterOptions getLLMObsSpanRegisterOptions(AgentSpanContext ctx) {
  // Return options with: modelProvider, modelName, spanKind=LLM
}

@Override
public void setLLMObsTags(MutableSpan span, Object response, Object request) {
  // Extract and set: inputMessages, outputMessages, metrics (tokens), metadata
}
```
