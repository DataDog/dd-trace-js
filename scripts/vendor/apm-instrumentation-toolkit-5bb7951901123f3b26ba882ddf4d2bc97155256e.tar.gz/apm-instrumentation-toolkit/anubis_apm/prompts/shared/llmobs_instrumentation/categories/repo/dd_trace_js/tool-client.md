### Required Methods

```js
getLLMObsSpanRegisterOptions(ctx) {
  // Return: { spanKind: LlmObsSpanKind.TOOL or RETRIEVAL, operationName }
  // Span kind depends on which operation type is being instrumented
}

setLLMObsTags(ctx) {
  // Set protocol-specific metadata
  // Tool calls: tool name, parameters
  // Resource retrieval: resource URI, type
}
```
