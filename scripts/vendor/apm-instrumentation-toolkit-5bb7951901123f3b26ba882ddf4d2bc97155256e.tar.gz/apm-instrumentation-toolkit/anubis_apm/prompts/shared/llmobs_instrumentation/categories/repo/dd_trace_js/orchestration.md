### Required Methods

```js
getLLMObsSpanRegisterOptions(ctx) {
  // Return: { spanKind: LlmObsSpanKind.WORKFLOW or AGENT, operationName }
  // NO modelProvider, NO modelName
}

setLLMObsTags(ctx) {
  // Set: inputValue, outputValue (workflow input/output as strings)
  // NO inputMessages, NO outputMessages, NO metrics
}
```
