# LLM Observability Integration Builder

## Your Mission

Build a complete LLMObs plugin for **{{integration_name}}** that instruments chat completion operations and emits proper span events.

**Handle all appropriate span kinds** based on the package category (llm, workflow, agent, tool, retrieval, embedding).

---

## Skills Required

**CRITICAL: Load this skill immediately:**

```
/skill llmobs-integration
```

The skill provides:
- LLMObsPlugin base class architecture and implementation patterns
- Package category detection (LlmObsCategory enum: LLM_CLIENT, MULTI_PROVIDER, ORCHESTRATION, INFRASTRUCTURE)
- Span kind classification (LlmObsSpanKind enum: llm, workflow, agent, tool, embedding, retrieval)
- Message extraction patterns for different providers
- Token usage and metadata extraction
- Reference implementations (OpenAI, Anthropic, Google GenAI)

**You must load this skill before generating any code.**

---

## Context

**Integration:** {{integration_name}}
**Plugin Path:** {{plugin_path}}
**LLMObs Plugin Path:** {{llmobs_plugin_path}}
**Composite Plugin Path:** {{composite_plugin_path}}
**Tracing Plugin Path:** {{tracing_plugin_path}}

---

## Your Task

### 1. Detect Package Category (REQUIRED FIRST STEP)

**CRITICAL: You MUST determine the LlmObsCategory BEFORE generating any code.**

Follow the decision tree from the llmobs-integration skill to classify into one of:
- `LlmObsCategory.LLM_CLIENT` - Direct API wrappers (openai, anthropic, genai) — {{link:llmobs_instrumentation/categories/llm-client|LLM_CLIENT guide}}
- `LlmObsCategory.MULTI_PROVIDER` - Multi-provider frameworks (ai-sdk, langchain) — {{link:llmobs_instrumentation/categories/multi-provider|MULTI_PROVIDER guide}}
- `LlmObsCategory.ORCHESTRATION` - Workflow managers (langgraph, crewai) — {{link:llmobs_instrumentation/categories/orchestration|ORCHESTRATION guide}}
- `LlmObsCategory.TOOL_CLIENT` - Protocol clients for tool execution and resource retrieval — {{link:llmobs_instrumentation/categories/tool-client|TOOL_CLIENT guide}}
- `LlmObsCategory.INFRASTRUCTURE` - Supporting infrastructure without LLM operations — {{link:llmobs_instrumentation/categories/infrastructure|INFRASTRUCTURE guide}}

**Output Requirements:**
- `package_category`: One of `llm_client`, `multi_provider`, `orchestration`, `tool_client`, `infrastructure`
- `category_confidence`: `high`, `medium`, or `low`
- `category_reasoning`: Explain what code patterns led to your decision (reference specific files/classes)

**Example:**
```
"Category: llm_client, Confidence: high
Reasoning: Package exports ChatClient class that directly calls the provider API.
No abstraction over multiple providers."
```

### 2. Analyze the Library API

Understand how chat completions work in this library:
- Locate chat completion methods (e.g., `chat.completions.create`, `messages.create`)
- Identify input format (messages array, prompt string, parameters)
- Identify output format (choices, content, token usage)
- Identify model parameters (temperature, max_tokens, etc.)

**For category-specific implementation guidance, refer to the linked category guide above.**

### 3. Generate LLMObs Plugin

Create the plugin at `{{llmobs_plugin_path}}` following the patterns from the llmobs-integration skill.

**Key implementation requirements:**
- Extend `LLMObsPlugin` base class
- Implement `getLLMObsSpanRegisterOptions(ctx)` - Returns model provider, name, span kind, operation name
- Implement `setLLMObsTags(ctx)` - Extracts and tags messages, metrics, metadata
- Convert messages to standard `{content, role}` format
- Handle errors with empty outputs: `[{content: '', role: ''}]`
- Extract token usage and metadata
- Export as array: `module.exports = [ProviderLLMObsPlugin]`

**Refer to the skill for:**
- Complete plugin structure template
- Provider-specific message extraction patterns
- Helper method implementations
- Reference plugin examples

---

## Success Criteria

- [ ] Package category detected using LlmObsCategory enum and documented with reasoning
- [ ] Plugin extends LLMObsPlugin base class
- [ ] Both required methods implemented (getLLMObsSpanRegisterOptions, setLLMObsTags)
- [ ] Messages converted to standard `{content, role}` format
- [ ] Token usage and metadata extracted
- [ ] Error handling with empty outputs
- [ ] Correct LlmObsSpanKind used (usually `'llm'`)
- [ ] Plugin file created at correct path and exported as array

---

## Notes

- Reference the llmobs-integration skill for all implementation patterns
- Study reference plugins (OpenAI, Anthropic, Google GenAI) in the skill's reference section
- Keep implementation simple - follow existing patterns
- Test strategy will be determined by LlmObsCategory in next step
