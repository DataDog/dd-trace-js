### Required Methods (Java)

```java
@Override
public LLMObsSpanRegisterOptions getLLMObsSpanRegisterOptions(AgentSpanContext ctx) {
  // Return options with: modelProvider (dynamic), modelName, spanKind=LLM
  // modelProvider may be resolved at runtime from the provider adapter or config
}

@Override
public void setLLMObsTags(MutableSpan span, Object response, Object request) {
  // Extract and set: inputMessages, outputMessages, metrics (tokens), metadata
}
```
