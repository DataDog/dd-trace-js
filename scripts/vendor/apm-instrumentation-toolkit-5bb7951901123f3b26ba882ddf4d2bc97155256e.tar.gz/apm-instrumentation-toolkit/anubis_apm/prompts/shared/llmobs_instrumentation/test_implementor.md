# LLM Observability Test Implementation

## ⚠️ CRITICAL REQUIREMENT: CATEGORY-BASED TEST STRATEGY ⚠️

**PACKAGE CATEGORY: {{package_category}}**

**THIS IS NON-NEGOTIABLE. YOU MUST FOLLOW THE CATEGORY-SPECIFIC TEST STRATEGY.**

### CATEGORY RULES (BLOCKING REQUIREMENT):

**IF category = "orchestration" (THIS PACKAGE):**
- ❌ **FORBIDDEN:** VCR cassettes, VCR proxy URLs, Client classes, HTTP baseURL configuration
- ❌ **FORBIDDEN:** Real API calls to LLM providers
- ✅ **REQUIRED:** Pure function tests using StateGraph/workflow APIs directly
- ✅ **REQUIRED:** spanKind must be 'workflow' or 'agent', NOT 'llm'
- ✅ **REQUIRED:** Test the orchestration library's own methods (invoke, stream, run)

**IF category = "llm_client" or "multi_provider":**
- ✅ **REQUIRED:** VCR cassettes with proxy baseURL
- ✅ **REQUIRED:** spanKind must be 'llm'
- ✅ **REQUIRED:** Test client API methods (chat, completion, generate)

**IF category = "tool_client":**
- ✅ **REQUIRED:** Mock server tests for protocol endpoints
- ✅ **REQUIRED:** spanKind must be 'tool' or 'retrieval', NOT 'llm'
- ✅ **REQUIRED:** Test tool execution and resource retrieval methods
- ✅ **REQUIRED:** Validate protocol-specific metadata (tool names, resource URIs)
- ❌ **FORBIDDEN:** VCR cassettes (protocol clients need mock servers)

**IF category = "infrastructure":**
- ✅ **REQUIRED:** Mock server tests
- ❌ **FORBIDDEN:** VCR cassettes
- ⚠️ **NOTE:** Infrastructure packages may not need LLMObs tests if they have no LLM operations

**VALIDATION CHECKPOINT:**
Before writing any code, state which category this package is and which strategy you will use.
If you proceed with the wrong strategy, this task will fail and you will need to start over.

---

## Skills Required

**CRITICAL: Load this skill immediately:**

```
/skill llmobs-testing
```

The skill provides category-specific strategies. **Read the ORCHESTRATION section carefully if category = "orchestration".**

---

## Context

**Integration:** {{integration_name}}
**Plugin Directory:** {{plugin_dir}}
**Methods to Test:** {{methods_to_test}}
**Test File:** {{test_file_path}}
**Cassette Directory:** {{cassette_dir}}
**Package Category:** {{package_category}} ← THIS DETERMINES YOUR ENTIRE APPROACH

---

## MANDATORY: Category Strategy Lookup

**STOP. Before proceeding, consult the llmobs-testing skill for {{package_category}} strategy.**

The skill contains specific instructions for {{package_category}}. You MUST follow them exactly.

---

## Your Task

### 1. DECLARE CATEGORY AND STRATEGY (MANDATORY FIRST STEP)

**Before writing ANY code, you MUST explicitly state:**

```
Package Category: {{package_category}}
Test Strategy: [describe the strategy you will use based on the category]
Forbidden Patterns: [list what you will NOT do based on the category]
Required Patterns: [list what you WILL do based on the category]
```

**This declaration is mandatory. If you skip this, the test will be rejected.**

### 2. Study Category-Appropriate Examples

Refer to the llmobs-testing skill for **{{package_category}}-specific examples**.

The skill lists which test files to study and which patterns to use for your category. Only study examples from your category — do not read examples from other categories as they will mislead you.

### 3. Verify Strategy Alignment (VALIDATION CHECKPOINT)

**Before writing the test file, verify:**

- [ ] I have read the llmobs-testing skill for {{package_category}}
- [ ] I understand which patterns are FORBIDDEN for {{package_category}}
- [ ] I understand which patterns are REQUIRED for {{package_category}}
- [ ] I have studied examples from {{package_category}} ONLY (not other categories)
- [ ] I can describe the test structure I will create without looking at wrong examples

### 4. Write Test File (Following Category Strategy)

Create test at {{test_file_path}}.

**CATEGORY-SPECIFIC IMPLEMENTATION:**

Refer to the llmobs-testing skill for **{{package_category}}** implementation patterns, mandatory structure, and validation checklists.

### 5. Self-Validate Before Submitting (FINAL CHECKPOINT)

**Run through this checklist. If any item fails, rewrite the test:**

**Category Compliance:**
- [ ] My test strategy matches {{package_category}} (not other categories)
- [ ] I have NOT used forbidden patterns for {{package_category}}
- [ ] I have used all required patterns for {{package_category}}

**Technical Compliance:**
- [ ] Correct imports (useLlmObs, assertLlmObsSpanEvent, MOCK_*)
- [ ] Correct spanKind for {{package_category}}
- [ ] All methods in {{methods_to_test}} are covered
- [ ] No mixing of patterns from different categories

---

## ❌ FATAL ERRORS (These Will Cause Immediate Test Failure) ❌

**ORCHESTRATION category violations ({{package_category}} = "orchestration"):**
- ❌ **FATAL:** Using `new Client()` - orchestration libraries don't have Client classes
- ❌ **FATAL:** Configuring VCR proxy baseURL (`httpOptions: { baseUrl: '...' }`)
- ❌ **FATAL:** Using spanKind: 'llm' - orchestration spans are 'workflow' or 'agent'
- ❌ **FATAL:** Reading examples from openai/google-genai tests (wrong category)
- ❌ **FATAL:** Adding modelName/modelProvider fields (orchestration isn't LLM API)

**LLM_CLIENT category violations:**
- ❌ **FATAL:** NOT using VCR proxy when category is llm_client
- ❌ **FATAL:** Using spanKind: 'workflow' when testing chat API

**ALL categories:**
- ❌ **FATAL:** Using patterns from wrong category examples
- ❌ **FATAL:** Ignoring category-specific instructions from llmobs-testing skill

**IF YOU MAKE ANY OF THESE MISTAKES, THE TEST WILL FAIL AND YOU WILL NEED TO COMPLETELY REWRITE IT.**

---

## Success Criteria (ALL Must Be True)

- [ ] Category strategy declaration completed (step 1)
- [ ] Validation checkpoints passed (steps 2, 3, 5)
- [ ] Test file uses ONLY patterns appropriate for {{package_category}}
- [ ] No forbidden patterns from {{package_category}} appear in code
- [ ] All required patterns from {{package_category}} are present
- [ ] spanKind matches category (orchestration→workflow, llm_client→llm)
- [ ] Examples studied were from {{package_category}} only (not other categories)

**If ANY criterion is false, the test is incorrect and will be rejected.**

---

## Final Reminder

**The category {{package_category}} is the single most important piece of information.**

Everything else (test structure, assertions, setup) follows from the category.

**If you use patterns from the wrong category, the test will fail no matter how well-written it is.**

**Read the llmobs-testing skill. Follow it exactly. Do not improvise.**
