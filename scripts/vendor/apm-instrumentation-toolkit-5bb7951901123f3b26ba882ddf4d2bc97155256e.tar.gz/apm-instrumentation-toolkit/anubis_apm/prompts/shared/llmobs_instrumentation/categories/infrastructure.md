# LLMObs Category: INFRASTRUCTURE

## Overview

`LlmObsCategory.INFRASTRUCTURE` applies to packages that provide **supporting infrastructure without any LLM operations** — they are not part of LLM workflows and perform no LLM-related work (e.g., general-purpose HTTP clients, configuration loaders, auth libraries used incidentally by AI packages).

---

## Detection Signals

- Package provides utilities, infrastructure, or transport — not LLM operations
- No chat completion methods, no tool calls, no resource retrieval
- Not part of the LLM workflow data path
- May be a dependency of AI packages but has no AI-specific operations itself

---

## Plugin Implementation

**No LLMObs plugin is needed for INFRASTRUCTURE packages.**

When detected as INFRASTRUCTURE:
- Set `package_category: "infrastructure"`
- Set `llmobs_plugin_path: ""`
- Set `span_kinds_supported: []`
- Return `success: true` without creating any plugin file

Do not attempt to create instrumentation for infrastructure packages.

---

## Test Strategy

Infrastructure packages have no LLMObs tests because there are no LLMObs operations to test.

If tests are needed for the underlying APM tracing integration:
- Use mock server tests appropriate for the infrastructure's protocol
- No VCR cassettes (no LLM API calls)
- No LLMObs span assertions

---

## Notes

- INFRASTRUCTURE classification stops the LLMObs workflow early — no plugin is generated
- The APM tracing integration may still be useful (regular spans for HTTP calls, etc.)
- If you are uncertain whether a package is INFRASTRUCTURE vs TOOL_CLIENT, check: does it participate in LLM agent workflows? If yes → TOOL_CLIENT. If it's purely supporting infrastructure with no role in LLM data flow → INFRASTRUCTURE.
