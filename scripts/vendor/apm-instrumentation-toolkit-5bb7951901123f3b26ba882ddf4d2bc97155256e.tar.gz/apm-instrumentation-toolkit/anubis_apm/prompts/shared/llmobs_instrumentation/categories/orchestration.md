# LLMObs Category: ORCHESTRATION

## Overview

`LlmObsCategory.ORCHESTRATION` applies to packages that are **workflow or agent orchestration frameworks** — they manage multi-step LLM workflows, agent loops, or graph-based execution (e.g., langgraph, crewai). These packages do NOT directly call LLM APIs; they coordinate other components that do.

---

## Detection Signals

- Package provides graph/DAG execution, agent loops, or workflow management
- Methods like `invoke`, `stream`, `run`, `compile` that execute a workflow
- No direct HTTP calls to LLM provider APIs
- Concepts like StateGraph, nodes, edges, agents, tasks, crews

---

## Plugin Implementation

- **Span kinds:** `LlmObsSpanKind.WORKFLOW` (`'workflow'`) or `LlmObsSpanKind.AGENT` (`'agent'`)
- **Instrument:** Workflow/agent execution methods (e.g., `invoke`, `stream`, `run`)
- **Do NOT** instrument LLM call methods — those belong to the underlying LLM_CLIENT plugins
- **inputValue / outputValue** instead of inputMessages / outputMessages
- No `modelName`, `modelProvider`, or token metrics (this isn't an LLM API call)

{{include_repo:orchestration,excluded_repos=dd_trace_py}}

---

## Test Strategy

- **Pure function tests** — call the orchestration library's own methods directly
- **NO VCR cassettes** — orchestration packages do not make HTTP calls
- **NO proxy baseURL** — there is no HTTP client to configure
- **NO Client class** — orchestration libraries use graph/workflow APIs, not client classes
- **spanKind assertion:** must be `'workflow'` or `'agent'`, NOT `'llm'`
- Test by constructing and invoking graphs/workflows/agents directly

### Forbidden Patterns

- **FATAL:** Using VCR cassettes or proxy baseURL
- **FATAL:** Configuring `httpOptions: { baseUrl: '...' }`
- **FATAL:** `spanKind: 'llm'`
- **FATAL:** Adding `modelName` / `modelProvider` fields
- **FATAL:** `inputMessages` / `outputMessages` (use `inputValue` / `outputValue`)
- **FATAL:** Reading LLM_CLIENT test examples (wrong category)

---

## Existing Plugin Check

If an LLMObs plugin already exists at `{{llmobs_plugin_path}}`:
- Return the existing plugin path with `success: true`
- Set `methods_instrumented` to methods already instrumented
- Set `span_kinds_supported: ["workflow"]` or `["agent"]` as appropriate
- Do NOT recreate or overwrite the existing plugin

---

## Notes

- Orchestration spans wrap inner LLM spans — the inner LLM calls will be captured by LLM_CLIENT plugins
- The workflow span captures high-level orchestration metrics (steps taken, graph structure)
- Study langgraph or crewai plugin examples in the `llmobs-integration` skill if available
