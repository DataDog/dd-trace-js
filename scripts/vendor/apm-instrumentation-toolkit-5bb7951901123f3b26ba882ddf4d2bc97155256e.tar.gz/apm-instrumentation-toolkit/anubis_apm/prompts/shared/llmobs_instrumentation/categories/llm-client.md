# LLMObs Category: LLM_CLIENT

## Overview

`LlmObsCategory.LLM_CLIENT` applies to packages that are **direct API wrappers** around a single LLM provider's API (e.g., openai, anthropic, google-genai). These packages make HTTP calls directly to a provider endpoint with no abstraction over multiple providers.

---

## Detection Signals

- Package exports a client class that calls a single provider's API endpoint directly
- No routing logic over multiple backends
- Methods like `chat.completions.create`, `messages.create`, `models.generateContent`
- References to provider-specific URLs (e.g., `api.openai.com`, `api.anthropic.com`)

---

## Plugin Implementation

- **Span kind:** `LlmObsSpanKind.LLM` (`'llm'`)
- **Instrument:** Chat completion methods (e.g., `chat.completions.create`, `messages.create`)
- **Extract input messages:** Convert to `{content, role}` array format
- **Extract output messages:** Convert choices/content to `{content, role}` format
- **Extract token usage:** `input_tokens`, `output_tokens` (from `usage` field)
- **Extract metadata:** `temperature`, `max_tokens`, `model`, provider-specific params
- **Error handling:** On error, set output messages to `[{content: '', role: ''}]`

{{include_repo:llm-client,excluded_repos=dd_trace_py}}

---

## Test Strategy

- **Use VCR cassettes** with proxy baseURL — required for LLM_CLIENT
- Tests make real-shaped requests replayed from cassettes (no live API calls)
- Configure client with `httpOptions: { baseUrl: '<vcr-proxy-url>' }` or equivalent
- **spanKind assertion:** must be `'llm'`
- **Assert:** `inputMessages`, `outputMessages`, `metrics.input_tokens`, `metrics.output_tokens`, `metadata.temperature`, `metadata.model_name`

### Forbidden Patterns

- No mock servers (use VCR cassettes instead)
- No `spanKind: 'workflow'` or `spanKind: 'agent'`
- No pure function tests without cassette setup

---

## Reference Examples

Study the OpenAI, Anthropic, and Google GenAI plugins in the `llmobs-integration` skill for canonical LLM_CLIENT implementations.
