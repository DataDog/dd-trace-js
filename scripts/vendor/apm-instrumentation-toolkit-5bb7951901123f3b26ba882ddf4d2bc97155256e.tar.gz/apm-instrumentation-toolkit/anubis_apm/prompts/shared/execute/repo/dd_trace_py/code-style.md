## dd-trace-py Code Style

### Critical Rules
- Follow PEP 8
- Use type hints
- Keep imports sorted (isort conventions)
- Use the dd-trace-py lint skill for lint checks/fixes; do not call `ruff` directly
