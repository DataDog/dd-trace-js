## dd-trace-js Planning Guidance

### Repository Structure
- `packages/dd-trace/` — Main library (APM, profiling, debugger, appsec, llmobs, CI visibility)
- `packages/datadog-core/` — Async context storage, shared utilities
- `packages/datadog-instrumentations/` — Instrumentation implementations
- `packages/datadog-plugin-*/` — 100+ plugins for third-party integrations
- `integration-tests/` — E2E integration tests

### Testing Patterns
- Unit tests: `./node_modules/.bin/mocha path/to/test.spec.js`
- Plugin tests: `PLUGINS="<name>" npm run test:plugins:ci`
- With services: `SERVICES="<service>" docker compose up -d $SERVICES && yarn services && npm run test:plugins:ci`

### Code Conventions
- Use `node:assert/strict` for assertions; prefer `assert.deepStrictEqual` over many `assert.strictEqual`; never `doesNotThrow()` (just call the method)
- No `async/await` in production code (use callbacks)
- Prefer optional chaining (`?.`) and nullish coalescing (`??`)
- Prefer `#private` class fields for new code
- Use `for-of` / `for` / `while` loops; never `for-in`; avoid `forEach`/`map`/`filter` in hot paths
- Files use kebab-case naming
- Line length capped at 120 characters

### Import Ordering
1. Node.js core modules (with `node:` prefix)
2. Third-party modules
3. Internal imports (by path proximity, then alpha)

Separate groups with blank lines.

### Linting
`npm run lint` to check, `npm run lint:fix` to auto-fix.
