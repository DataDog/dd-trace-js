### dd-trace-js style checks for the simplify pass

When cleaning up code, do not violate these:

- No `async/await` in production code
- Line length ≤ 120
- Files use kebab-case
- Use `node:assert/strict` in tests; never `doesNotThrow()`
- Prefer `for-of` / `for` / `while` over `forEach`/`map`/`filter` in hot paths

Run `npm run lint:fix` after edits. Full style reference is in `planning-guidance.md` (rendered for the planner above) and the repo's own `.eslintrc`.
