## dd-trace-java Implementation Guidance

### Repo Conventions
When applying the plan or writing prompts for read-only subagents:
- Instrumentation modules live in `dd-java-agent/instrumentation/<library>/` — one Gradle subproject per library, with its own `build.gradle` declaring muzzle ranges and test dependencies.
- Use ByteBuddy `@Advice` (enter/exit pattern) for new instrumentation. Advice classes must be `public static` inner classes; use fully-qualified class names in type matchers.
- Decorators live alongside advice — reference an existing instrumentation in the same family for the decorator pattern (HTTP client, messaging, datastore, etc.).
- Tests are Groovy Spock (`*Test.groovy`, `*ForkedTest.groovy`); test containers handle external service dependencies. Pick a neighbor whose hooking style matches the target for the test layout.
- Core tracing primitives (spans, context, propagation) live in `dd-trace-core/`; shared interfaces in `internal-api/`. Don't add behavior there from a per-integration plan — keep changes scoped to the instrumentation module.
- Run Spotless before returning: `./gradlew spotlessApply`.

### PR Metadata Fixes (used by `dd-apm pr`, not the implement agent)
- **PR title/name lint**: Fix via `gh pr edit --title "<type>(<scope>): <description>"` using conventional commit format. Use the integration name as scope.
- **Missing labels**: Add via `gh pr edit --add-label "<label>"`.
