### Newer API for this Repo

When an integration's instrumentation module uses an older pattern (e.g. direct `Instrumenter` subclassing with `instrumentationName()`/`typeInstrumentation()` boilerplate, or legacy decorator hand-rolling), prefer the current `InstrumenterModule` + `TypeInstrumentation` split if a neighboring instrumentation in the same family (HTTP client, messaging, datastore) already uses it. The simplify pass is where drift gets caught — do NOT re-introduce a deprecated pattern just to match older siblings.
