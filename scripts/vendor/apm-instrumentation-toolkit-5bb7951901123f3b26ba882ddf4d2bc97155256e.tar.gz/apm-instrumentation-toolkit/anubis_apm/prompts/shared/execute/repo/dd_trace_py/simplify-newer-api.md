### Newer API for this Repo

When an integration's class has an Events API reference (e.g. an HTTP client, LLM provider, or database with an existing event type under `ddtrace/contrib/_events/` and a subscriber under `ddtrace/_trace/subscribers/`), prefer the Events API pattern even if neighboring legacy integrations still create spans by hand. The simplify pass is where drift gets caught — do NOT re-introduce manual span creation just to match older neighbors.

If the diff is already on the Events API, look for opportunities to lift category-wide tags onto the shared event type instead of leaving them as ad-hoc span tags inside this integration.
