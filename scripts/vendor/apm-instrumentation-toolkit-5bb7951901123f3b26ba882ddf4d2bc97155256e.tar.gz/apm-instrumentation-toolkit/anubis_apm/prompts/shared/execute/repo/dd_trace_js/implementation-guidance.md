## dd-trace-js Implementation Guidance

### Repo Conventions
When applying the plan or writing prompts for read-only subagents:
- Package manager: **yarn for installs, npm for scripts**.
- **No `async/await` in production code** — use callbacks. (Tests can use async.)
- For plugin work, point at an existing plugin matching the target's hooking style:
  - `packages/datadog-plugin-langchain/` or `packages/datadog-plugin-bullmq/` for Orchestrion-based plugins
  - `packages/datadog-plugin-mongodb/` for shimmer-based ones
- For instrumentation work, reference the general instrumentations directory at `packages/datadog-instrumentations/` and pick a neighbor that matches the integration's class.
- **Prefer the Orchestrion JSON-rewriter API over `shimmer` for new work.** When an Orchestrion-based integration exists for a similar module, use it as the reference; fall back to `shimmer` only when the target module has no Orchestrion path yet.

### PR Metadata Fixes (used by `dd-apm pr`, not the implement agent)
- **PR title/name lint** (`pr_name_lint`, `pr-name-lint`): Fix via `gh pr edit --title "chore(<scope>): <description>"` using conventional commit format. Use the integration name as scope.
- **Missing changelog/release note**: Apply the `changelog/no-changelog` label if the change has no user-facing impact (`gh pr edit --add-label changelog/no-changelog`); otherwise add a release-note section per the PR description template.
- **Missing labels**: Add via `gh pr edit --add-label "<label>"`.
