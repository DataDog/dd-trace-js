## dd-trace-java Planning Guidance

### Repository Structure
- `dd-java-agent/instrumentation/` — Instrumentation modules (one per library)
- `dd-java-agent/agent-tooling/` — Core instrumentation framework (ByteBuddy advice, decorators)
- `dd-trace-core/` — Core tracing library (spans, context, propagation)
- `internal-api/` — Internal API interfaces shared across modules

### Testing Patterns
- Unit tests: `./gradlew :dd-java-agent:instrumentation:<module>:test`
- With rerun: `./gradlew :dd-java-agent:instrumentation:<module>:test --rerun-tasks`
- Tests use Groovy Spock framework (`*Test.groovy`, `*ForkedTest.groovy`)
- Test containers handle external service dependencies automatically

### Code Conventions
- ByteBuddy `@Advice` for instrumentation (enter/exit pattern)
- Advice classes must be `public static` inner classes
- Use fully-qualified class names in type matchers
- Spotless for code formatting: `./gradlew spotlessApply`
