## dd-trace-py Planning Guidance

### Repository Structure
- `ddtrace/contrib/` — Integration implementations (public modules)
- `ddtrace/contrib/internal/` — Internal integration code (patching, utils)
- `ddtrace/contrib/_events/` — Event dataclasses for the new Events API
- `ddtrace/_trace/subscribers/` — Shared subscribers that handle tracing for event classes
- `tests/contrib/` — Integration tests

### Testing Patterns

**CRITICAL: Never use `pytest` directly. Always use `scripts/run-tests` with `--venv`.**

```bash
# 1. Discover available test venvs and their hashes
scripts/run-tests --list tests/contrib/<name>/

# 2. Pick a hash (latest Python, matching the package version you need)

# 3. First run (installs dd-trace-py into the venv)
scripts/run-tests --venv <hash>

# 4. Subsequent runs (skip install with -s flag, much faster)
scripts/run-tests --venv <hash> -- -s -vv
```

Key flags:
- `--venv <hash>` is REQUIRED — selects the riot test environment
- `-- -s` = skip dd-trace-py reinstall (use after first run)
- `-vv` = verbose pytest output
- `-- -s -vv -k test_name` = run specific test

### Code Conventions
- Follow existing patterns in `ddtrace/contrib/`
- Use `wrapt` for monkey-patching
