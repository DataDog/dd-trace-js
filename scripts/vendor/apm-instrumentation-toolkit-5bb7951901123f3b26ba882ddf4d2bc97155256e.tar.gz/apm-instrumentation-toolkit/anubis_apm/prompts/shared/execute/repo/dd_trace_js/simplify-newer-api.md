### Newer API for this Repo

When an integration's class has an Orchestrion-based reference plugin (e.g. `packages/datadog-plugin-langchain/`, `packages/datadog-plugin-bullmq/`), prefer the Orchestrion JSON-rewriter pattern even if neighboring shimmer-based plugins still use `shimmer.wrap()`. The simplify pass is where drift gets caught — do NOT re-introduce a deprecated pattern just to match older neighbors.

If the diff is already on Orchestrion, look for opportunities to consolidate channel subscriptions or remove leftover shimmer scaffolding.
