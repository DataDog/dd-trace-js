## dd-trace-py Implementation Guidance

### Repo Conventions
When applying the plan or writing prompts for read-only subagents:
- Integration code lives in `ddtrace/contrib/internal/<name>/`.
- Public module is at `ddtrace/contrib/<name>/`.
- Tests live in `tests/contrib/<name>/`.
- Events API: event dataclasses in `ddtrace/contrib/_events/`, subscribers in `ddtrace/_trace/subscribers/`.
- Reference already-migrated integrations for the Events API pattern (e.g., `ddtrace/contrib/internal/httpx/`).

### PR Metadata Fixes (used by `dd-apm pr`, not the implement agent)
- **PR title/name lint**: Fix via `gh pr edit --title "chore(<scope>): <description>"` using conventional commit format. Use the integration name as scope.
- **Missing changelog/release note**: Add via `reno new <slug>` — this creates a YAML file under `releasenotes/notes/`. Check existing notes in that directory for the format (features / upgrade / fixes sections).
- **Missing labels**: Add via `gh pr edit --add-label "<label>"`.
