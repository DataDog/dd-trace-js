## dd-trace-java Code Style

### Critical Rules
- **ByteBuddy `@Advice`** — enter/exit pattern; advice classes must be `public static` inner classes
- Use fully-qualified class names in type matchers (`named("com.example.Foo")`)
- Run Spotless before submitting: `./gradlew spotlessApply`
- Keep instrumentation changes scoped to the target module under `dd-java-agent/instrumentation/<library>/`; do not add behavior to `dd-trace-core/` or `internal-api/`

### Tests
- Framework: Groovy Spock (`*Test.groovy`, `*ForkedTest.groovy`)
- Run a single module: `./gradlew :dd-java-agent:instrumentation:<module>:test`
- External service dependencies are handled by test containers automatically

### Import Ordering
Follow the existing file's import order. Spotless enforces the project standard — run it to auto-fix.
