# DBM Comment Propagation Implementation Guide for Node.js (dd-trace-js)

## Overview
Database Monitoring (DBM) comment propagation injects trace context as SQL comments, enabling correlation between APM traces and database monitoring data.

## Comment Format
```sql
/* dddb='mydb',dddbs='my-service',dde='prod',ddh='db.host.com',ddps='parent-service',ddpv='1.0.0' */ SELECT * FROM users
```

In **full mode**, includes traceparent:
```sql
/* dddb='mydb',dddbs='my-service',dde='prod',ddh='db.host.com',ddps='parent-service',ddpv='1.0.0',traceparent='00-abc123-def456-01' */ SELECT * FROM users
```

## Comment Fields
- `dddb` - Database name
- `dddbs` - Database service name
- `dde` - Environment
- `ddh` - Database host
- `ddps` - Parent service name
- `ddpv` - Parent service version
- `ddprs` - Peer service (if computed)
- `traceparent` - W3C traceparent (full mode only)

## Configuration
DBM is configured via plugin options:
```javascript
tracer.use('mysql', {
  dbmPropagationMode: 'full'  // 'disabled' | 'service' | 'full'
})
```

## Key API (DatabasePlugin base class)
Extend `DatabasePlugin` to get DBM support:

```javascript
const DatabasePlugin = require('../../dd-trace/src/plugins/database')

class MyDatabasePlugin extends DatabasePlugin {
  static id = 'my-database'
  static operation = 'query'
}
```

## Implementation Pattern
Use `injectDbmQuery()` to add comments to queries:

```javascript
bindStart (ctx) {
  const { sql } = ctx

  const span = this.startSpan(name, {
    resource: sql,
    meta: {
      'db.name': dbName,
      'out.host': host
    }
  }, ctx)

  // Inject DBM comment into query
  if (this.config.dbmPropagationMode !== 'disabled') {
    ctx.sql = this.injectDbmQuery(span, sql, this.serviceName)
  }

  return ctx.currentStore
}
```

## Helper Methods (from DatabasePlugin)

### `createDbmComment(span, serviceName, disableFullMode?)`
Creates the DBM comment string:
```javascript
const comment = this.createDbmComment(span, 'my-db-service')
// Returns: "dddb='...',dddbs='...',..." or with traceparent in full mode
```

### `injectDbmQuery(span, query, serviceName, disableFullMode?)`
Injects comment into query (respects `appendComment` config):
```javascript
const modifiedQuery = this.injectDbmQuery(span, 'SELECT * FROM users', 'my-db-service')
// Default: "/*comment*/ SELECT * FROM users"
// With appendComment: "SELECT * FROM users /*comment*/"
```

### `maybeTruncate(query)`
Truncates long queries based on config:
```javascript
const truncated = this.maybeTruncate(veryLongQuery)
```

## Testing DBM

### Test Structure
```javascript
describe('DBM propagation', () => {
  describe('service mode', () => {
    before(() => {
      tracer.use('mysql', { dbmPropagationMode: 'service' })
    })

    it('should inject service tags into query', async () => {
      let capturedQuery

      // Mock to capture the query
      connection.query = (sql, cb) => {
        capturedQuery = sql
        cb(null, [])
      }

      await connection.query('SELECT * FROM users')

      expect(capturedQuery).to.include('/*')
      expect(capturedQuery).to.include("dddbs='")
      expect(capturedQuery).to.include("ddps='")
      expect(capturedQuery).to.not.include('traceparent')
    })
  })

  describe('full mode', () => {
    before(() => {
      tracer.use('mysql', { dbmPropagationMode: 'full' })
    })

    it('should inject traceparent into query', async () => {
      let capturedQuery

      connection.query = (sql, cb) => {
        capturedQuery = sql
        cb(null, [])
      }

      await connection.query('SELECT * FROM users')

      expect(capturedQuery).to.include('traceparent')
    })
  })
})
```

## Files to Modify for DBM

### Plugin Main File
1. Extend `DatabasePlugin` instead of `StoragePlugin`
2. Call `injectDbmQuery()` in `bindStart` before query execution
3. Ensure span has `db.name` and `out.host` tags

### Plugin Config
- Add `dbmPropagationMode` config option
- Add `appendComment` config option (optional)

## Important Notes

### When NOT to inject
- Prepared statements (comment added at prepare time, not execute)
- Commands that don't accept comments (SET, USE, etc.)

### Query Modification
```javascript
// Only inject for actual queries
if (this.config.dbmPropagationMode !== 'disabled' && isQuery(sql)) {
  ctx.sql = this.injectDbmQuery(span, sql, serviceName)
}
```

### Stored Procedures
Some databases require special handling:
```javascript
// MySQL stored procedures - inject after CALL
const modifiedQuery = this.injectDbmQuery(span, sql, serviceName, true) // disableFullMode for some cases
```
