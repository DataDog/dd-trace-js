# Data Streams Monitoring (DSM) Feature (dd-trace-py)

## Reference Integration: **kafka**

See `ddtrace/contrib/internal/kafka/patch.py` and `ddtrace/internal/datastreams/kafka.py` for the canonical DSM pattern.

## What It Does

Tracks message pipeline latency by setting checkpoints on produce and consume operations, enabling end-to-end pipeline monitoring.

## Architecture

DSM uses event-driven separation:

1. `patch.py` emits events via `core.dispatch()` with topic/queue info
2. `ddtrace/internal/datastreams/{lib}.py` listens and sets DSM checkpoints

## Implementation Steps

1. **Add events in `patch.py`** -- dispatch produce/consume events with topic, partition, group info
2. **Create DSM handler file** at `ddtrace/internal/datastreams/{lib}.py`
3. **Set checkpoints** using `data_streams_processor().set_checkpoint()` in the handler
4. **Encode/decode pathway context** using `DsmPathwayCodec` on message headers

## Key Reference Files

| File | Pattern |
|------|---------|
| `ddtrace/contrib/internal/kafka/patch.py` | Event dispatch with topic/partition/group |
| `ddtrace/internal/datastreams/kafka.py` | DSM checkpoint handler |
| `ddtrace/data_streams/pathway.py` | `DsmPathwayCodec.encode()` / `.decode()` API |

## Testing

See `tests/contrib/kafka/test_kafka_dsm.py` for DSM-specific tests. Tests verify checkpoint creation and pathway propagation between producer and consumer.

## Gotchas

- Produce = "direction:out" checkpoint, Consume = "direction:in" checkpoint
- Pathway context is encoded in message headers via `DsmPathwayCodec`, alongside trace context in `_datadog`
- DSM handler must register with `core.on()` for the integration's events
- Always include topic/queue name in checkpoint tags
