# General Feature Implementation Guidelines (dd-trace-java)

## Architecture: Decorator + Advice Pattern

dd-trace-java uses ByteBuddy Advice classes for bytecode instrumentation, with feature logic handled through Decorators and helper classes.

### Integration Components

**InstrumenterModule** (main entry point):
- Defines type/method matchers
- Declares helper classes
- Specifies context stores
- Location: `dd-java-agent/instrumentation/{lib}-{version}/src/main/java/.../`

**Decorator** (span lifecycle + tagging):
- Extends base decorators (`HttpClientDecorator`, `DatabaseClientDecorator`, etc.)
- Handles span creation, tagging, and error handling
- Location: Same package as InstrumenterModule

**Advice class** (bytecode injection point):
- Static methods with `@Advice.OnMethodEnter` / `@Advice.OnMethodExit`
- Calls decorator methods for span lifecycle
- Must NOT contain lambdas, loggers, or instance state
- Location: Same package as InstrumenterModule

## Code Locations

| Code Type | Location |
|-----------|----------|
| Instrumentation | `dd-java-agent/instrumentation/{lib}-{version}/src/main/java/` |
| Tests | `dd-java-agent/instrumentation/{lib}-{version}/src/test/groovy/` |
| Base decorators | `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/decorator/` |
| Context propagation | `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/api/AgentPropagation.java` |
| DSM support | `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/api/PathwayContext.java` |
| DBM propagation | `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/api/Tags.java` |

## Decorator Hierarchy

Choose the most specific base decorator:

| Integration Type | Base Decorator | Key Methods |
|------------------|----------------|-------------|
| HTTP Client | `HttpClientDecorator` | `onRequest()`, `onResponse()` |
| HTTP Server | `BaseDecorator` (custom) | `spanType()`, `component()` |
| Database | `DatabaseClientDecorator` | `dbType()`, `dbInstance()` |
| Messaging | `MessagingClientDecorator` | `onProduceStart()`, `onConsumeStart()` |
| Generic | `BaseDecorator` | `afterStart()`, `beforeFinish()`, `onError()` |

## Span Naming Patterns

| Pattern | Example | Use When |
|---------|---------|----------|
| `{component}.{operation}` | `okhttp.request` | Single operation type |
| `{component}.{resource}` | `redis.command` | Resource name set separately |
| `{component}.{method}` | `jdbc.query` | Multiple operation types |

## Test Patterns

Read the test files of a reference integration in your category — they are the live source of truth for fixture setup, server bootstrapping, and `assertTraces` assertions. Do not invent a test shape; copy it.

| Pattern | Reference test file |
|---|---|
| HTTP-client Spock spec | `dd-java-agent/instrumentation/okhttp-3/src/test/groovy/.../OkHttp3Test.groovy` |
| Database / JDBC | `dd-java-agent/instrumentation/jdbc/src/test/groovy/.../JDBCInstrumentationTest.groovy` |
| Messaging (Kafka) | `dd-java-agent/instrumentation/kafka-clients-0.11/src/test/groovy/.../KafkaClientTest.groovy` |
| Cache (Jedis) | `dd-java-agent/instrumentation/jedis-1.4/src/test/groovy/.../JedisClientTest.groovy` |

Base class for all of them: `AgentTestRunner` (and its subclasses). The fixture/assertion shape is consistent across categories — pick the one closest to your integration and clone its structure.

## Gotchas

- Context propagation uses `AgentPropagation.Setter/Getter` adapters, not `_datadog` dict (that's Python)
- Advice classes must be static - no instance state allowed
- Always declare helpers in `helperClassNames()` - missing helpers cause muzzle failures
- Use `CallDepthThreadLocalMap` for reentrancy protection (but NOT across async boundaries)
- Config options go in `Config` class or system properties (`dd.{integration}.{option}`)
