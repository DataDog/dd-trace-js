# Peer Service Tagging Feature (dd-trace-java)

`peer.service` tags identify the downstream service a span depends on, powering Datadog's service-dependency map. Computed by the `PeerServiceCalculator` based on tags the integration sets on the span (peer.hostname, db.instance, messaging.destination, etc.) — you don't set `peer.service` directly.

## Reference Integrations

| Category | Reference | Computes peer.service from |
|---|---|---|
| HTTP client | `dd-java-agent/instrumentation/okhttp-3/src/main/java/.../OkHttp3Decorator.java` | URL host (via `peerHostname()`) |
| Database | `dd-java-agent/instrumentation/jdbc/src/main/java/.../JDBCDecorator.java` | `db.instance`, hostname, JDBC URL parsing |
| Messaging | `dd-java-agent/instrumentation/kafka-clients-0.11/src/main/java/.../KafkaDecorator.java` | Topic/queue name, broker hostname |
| RPC (gRPC) | `dd-java-agent/instrumentation/grpc-1.5/src/main/java/.../GrpcClientDecorator.java` | Authority/host from gRPC ClientCall |

Pick the closest one to your integration's category, read it, copy the decorator-method-override pattern.

## Core API

The PeerServiceCalculator is the canonical source of computed values:

- `dd-trace-core/src/main/java/datadog/trace/core/tagprocessor/PeerServiceCalculator.java` — implementation
- `internal-api/src/main/java/datadog/trace/api/naming/v1/PeerServiceNamingV1.java` — current naming rules (V1)

Read these to understand which input tags get used for which categories. The integration's job is to set those input tags correctly; the calculator does the rest.

## Pattern

Override the relevant `peerXxx()` methods on your category's base decorator:

| Base decorator | Override |
|---|---|
| `HttpClientDecorator` | `peerHostname(carrier)`, `peerPort(carrier)` |
| `DatabaseClientDecorator` | `dbHostname(connection)`, `dbInstance(connection)` |
| `MessagingClientDecorator` | (set `messaging.destination` directly via decorator's helpers) |

The `BaseDecorator.afterStart()` hook reads these and writes the corresponding tags on the span. The downstream `PeerServiceCalculator` computes the final `peer.service` value from those tags + user config (`dd.trace.peer.service.mapping`, `dd.trace.peer.service.defaults.enabled`).

**You should not set `peer.service` directly on the span.** Set the input tags; let the calculator compute the result. This ensures user-config overrides work correctly.

## Required input tags by category

| Category | Tags the calculator reads |
|---|---|
| HTTP | `peer.hostname`, `peer.port`, `network.destination.name` |
| Database | `db.instance`, `peer.hostname`, `peer.port` |
| Messaging | `messaging.destination`, `messaging.kafka.bootstrap.servers`, `peer.hostname` |
| RPC | `rpc.service`, `peer.hostname`, `peer.port` |

The exact tag names live in `Tags.java` (`dd-java-agent/agent-bootstrap/src/main/java/.../api/Tags.java`).

## User config overrides

Users can remap peer.service via `dd.trace.peer.service.mapping=hostname1:service1,hostname2:service2`. This happens in the calculator — your integration doesn't need to handle it.

## Tests

Reference: `dd-trace-core/src/test/groovy/datadog/trace/core/tagprocessor/PeerServiceCalculatorTest.groovy` shows the calculator's full input → output behavior across categories.

For your integration's tests, assert on the **input tags** you set (`peer.hostname`, `db.instance`, etc.) — not on `peer.service` itself. Trust the calculator.

## Gotchas

- Do not set `peer.service` directly on the span. Set input tags and let the calculator compute.
- Hostname only — no protocol prefix (`api.example.com`, not `https://api.example.com`), no path.
- Strip the port from hostname when it's the default (80 / 443 / etc.); set `peer.port` separately.
- If a value can't be determined, return `null` from the decorator method — don't set an empty string.
- Naming version (V0 vs V1) is controlled globally by config; don't hardcode V1-specific tags. Use `PeerServiceNamingV1` constants when applicable.
