# Peer Service Feature (dd-trace-py)

## Reference Integration: **redis**

See `ddtrace/contrib/internal/redis/patch.py` for setting the tags that peer service computation uses.

## What It Does

Automatically computes `peer.service` from span tags to identify downstream service dependencies.

## Architecture

Peer service is NOT implemented in `patch.py`. It is computed automatically by a `TraceProcessor`:

1. `patch.py` sets standard tags (host, port, db name, etc.)
2. `ddtrace/_trace/processor/__init__.py` (`PeerServiceProcessor`) reads those tags and computes `peer.service`

## Implementation Steps

1. **Set the right span tags** in your traced operations:
   - `net.peer.name` or `out.host` -- target hostname
   - `net.peer.port` or `out.port` -- target port
   - DB-specific: `db.name`, `db.system`
   - Messaging-specific: topic name tags
2. **That's it** -- the processor handles the rest

## Key Reference Files

| File | Pattern |
|------|---------|
| `ddtrace/contrib/internal/redis/patch.py` | Sets host/port tags correctly |
| `ddtrace/contrib/internal/psycopg/cursor.py` | Sets db.name, host, port for databases |
| `ddtrace/_trace/processor/__init__.py` | `PeerServiceProcessor` -- how it computes peer.service |
| `ddtrace/ext/peer_service.py` | Tag-to-peer-service mapping rules |

## Testing

Peer service tests verify that spans have the correct `peer.service` tag. Look at existing integration tests that assert `peer.service` values.

## Gotchas

- You never set `peer.service` directly -- set the source tags and the processor computes it
- Different span types use different source tags (see `peer_service.py` for the mapping)
- If peer service isn't appearing, check that the required source tags are being set on the span
