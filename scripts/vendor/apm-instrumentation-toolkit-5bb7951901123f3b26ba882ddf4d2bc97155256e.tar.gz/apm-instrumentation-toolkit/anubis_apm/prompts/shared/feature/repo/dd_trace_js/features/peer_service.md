# Peer Service Detection Implementation Guide for Node.js (dd-trace-js)

## Overview
Peer service detection automatically identifies the downstream service being called, enabling:
- Service map generation
- Dependency tracking
- Service-to-service latency metrics

## How It Works
The tracer computes `peer.service` from span tags using precursor tags:
1. Check if `peer.service` is already set (custom instrumentation)
2. Check plugin-specific precursors (e.g., `db.name`, `queuename`)
3. Fall back to common precursors (`net.peer.name`, `out.host`)

## Key Tags
- **`peer.service`** - The detected peer service name
- **`_dd.peer.service.source`** - Which tag the peer service was derived from
- **`_dd.peer.service.remapped_from`** - Original value if remapped via config

## Implementation

### Extend OutboundPlugin
Peer service detection is automatic when extending `OutboundPlugin`:

```javascript
const OutboundPlugin = require('../../dd-trace/src/plugins/outbound')

class MyPlugin extends OutboundPlugin {
  static id = 'my-plugin'
  // Define precursor tags specific to your plugin
  static peerServicePrecursors = ['my.service.name', 'my.host']
}
```

### Define Precursor Tags
The `peerServicePrecursors` static property defines which tags to check (in order):

```javascript
// Database plugins typically use db.name
class MySqlPlugin extends DatabasePlugin {
  static peerServicePrecursors = ['db.name']
}

// Messaging plugins use queue/topic names
class KafkaPlugin extends ProducerPlugin {
  static peerServicePrecursors = ['messaging.kafka.bootstrap.servers']
}

// HTTP clients use the target host
class HttpPlugin extends OutboundPlugin {
  static peerServicePrecursors = ['http.host', 'url.full']
}
```

### Common Precursors (Always Checked)
These are checked after plugin-specific precursors:
- `net.peer.name`
- `out.host`

## Setting Required Tags
Ensure your plugin sets the tags that peer service detection relies on:

```javascript
bindStart (ctx) {
  const { host, port, database } = ctx

  const span = this.startSpan(name, {
    resource: query,
    meta: {
      'db.name': database,       // For database plugins
      'out.host': host,          // Common fallback
      'net.peer.name': host,     // Alternative
      'queuename': queueName,    // For messaging plugins
    }
  }, ctx)

  return ctx.currentStore
}
```

## Configuration
Users can remap peer service names:
```javascript
// DD_TRACE_PEER_SERVICE_MAPPING=old-name:new-name
tracer.init({
  peerServiceMapping: {
    'old-db-host': 'production-database'
  }
})
```

## Testing Peer Service

### Test Structure
```javascript
describe('peer service', () => {
  before(() => {
    tracer.init({
      spanComputePeerService: true  // Enable peer service computation
    })
  })

  it('should set peer.service from db.name', async () => {
    await agent.use(traces => {
      const span = traces[0][0]
      expect(span.meta['peer.service']).to.equal('mydb')
      expect(span.meta['_dd.peer.service.source']).to.equal('db.name')
    })

    await db.query('SELECT 1')
  })

  it('should fall back to out.host', async () => {
    await agent.use(traces => {
      const span = traces[0][0]
      expect(span.meta['peer.service']).to.equal('db.example.com')
      expect(span.meta['_dd.peer.service.source']).to.equal('out.host')
    })

    await db.query('SELECT 1')  // When db.name is not available
  })
})
```

## Files to Modify

### Plugin Main File
1. Extend the appropriate base class (`OutboundPlugin`, `DatabasePlugin`, `ProducerPlugin`)
2. Define `static peerServicePrecursors` array
3. Ensure required tags are set in `bindStart`

### No Additional Code Needed
Peer service detection is automatic when:
- Your plugin extends `OutboundPlugin` (or its subclasses)
- You define `peerServicePrecursors`
- You set the precursor tags on spans

## Base Classes with Peer Service Support
- `OutboundPlugin` - Base for all outbound operations
- `DatabasePlugin` - Extends OutboundPlugin, adds `['db.name']` precursor
- `ProducerPlugin` - For messaging producers
- `ConsumerPlugin` - For messaging consumers
- `ClientPlugin` - For client operations

## Examples from Existing Plugins

### Database (MySQL)
```javascript
static peerServicePrecursors = ['db.name']
// Sets: db.name, out.host
```

### Messaging (Kafka)
```javascript
static peerServicePrecursors = ['messaging.kafka.bootstrap.servers']
// Sets: messaging.kafka.bootstrap.servers, kafka.topic
```

### AWS (SQS)
```javascript
static peerServicePrecursors = ['queuename']
// Sets: queuename, aws.sqs.queue_name
```
