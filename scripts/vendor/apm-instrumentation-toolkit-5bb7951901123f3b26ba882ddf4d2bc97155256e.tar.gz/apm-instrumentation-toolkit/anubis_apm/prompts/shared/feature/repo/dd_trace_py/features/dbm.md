# Database Monitoring (DBM) Feature (dd-trace-py)

## Reference Integration: **psycopg**

See `ddtrace/contrib/internal/psycopg/patch.py` and `ddtrace/contrib/internal/psycopg/cursor.py` for the canonical DBM pattern.

## What It Does

Injects trace context as SQL comments into database queries, linking APM traces to database-level monitoring.

## Architecture

DBM does NOT live in `patch.py`. It uses event-driven separation:

1. `patch.py` emits events with query info via `core.dispatch()`
2. `ddtrace/propagation/_database_monitoring.py` listens and injects SQL comments

## Implementation Steps

1. **Emit events from patch.py** with query args -- see how psycopg dispatches query events
2. **Register DBM handler** in `_database_monitoring.py` to listen for your integration's events
3. **Add config option** `dbm_propagation_mode` in `__init__.py`

## Key Reference Files

| File | Pattern |
|------|---------|
| `ddtrace/contrib/internal/psycopg/cursor.py` | Event dispatch with query args |
| `ddtrace/contrib/internal/pymysql/patch.py` | MySQL DBM pattern |
| `ddtrace/propagation/_database_monitoring.py` | SQL comment injection handler |

## Testing

See `tests/contrib/psycopg/` -- DBM tests verify SQL comments contain trace context. Look for tests that check `/*dddbs=...*/` comment patterns in executed queries.

## Gotchas

- Never modify the query in `patch.py` -- DBM injection happens in the handler
- `dbm_propagation_mode` has three values: `"disabled"`, `"service"`, `"full"` -- check existing integrations for how to handle each
- DBM only applies to database integrations with SQL queries
