# Context Propagation Feature (dd-trace-py)

## Reference Integration: **kafka**

See `ddtrace/contrib/internal/kafka/patch.py` for the canonical inject/extract pattern with non-HTTP carriers.

## What It Does

Injects trace context into outgoing messages and extracts from incoming, enabling distributed tracing across services.

## Implementation Steps

1. **Add config option** in `__init__.py`: `distributed_tracing=True`
2. **Inject on produce/send** in `patch.py` -- use `HTTPPropagator.inject(span.context, headers)` before the wrapped call (spans are created in patch.py)
3. **Extract on consume/receive** in `patch.py` -- use `HTTPPropagator.extract(headers)` and activate the extracted context
4. **Use `_datadog` attribute** for non-HTTP carriers (see kafka's produce/consume in `patch.py`)

## Key Reference Files

| File | Pattern |
|------|---------|
| `ddtrace/contrib/internal/kafka/patch.py` | Inject/extract with `_datadog` carrier on produce/consume |
| `ddtrace/contrib/internal/requests/connection.py` | HTTP header injection |
| `ddtrace/propagation/http.py` | `HTTPPropagator` API |

## Testing

See `tests/contrib/kafka/test_kafka.py` -- look for tests verifying `parent_id` linkage between producer and consumer spans.

## Gotchas

- Always gate on `config.distributed_tracing` before injecting/extracting
- Non-HTTP carriers use a `_datadog` dict, not top-level message keys
- Extract must handle missing/malformed context gracefully
