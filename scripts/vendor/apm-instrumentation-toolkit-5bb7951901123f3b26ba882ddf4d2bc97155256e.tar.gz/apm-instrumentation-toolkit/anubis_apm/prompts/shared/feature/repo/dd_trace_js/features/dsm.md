# DSM Implementation Guide for Node.js (dd-trace-js)

## CRITICAL: Tests are MANDATORY - Feature is NOT Complete Without Them!

**You MUST add tests that verify DSM works. This is NON-NEGOTIABLE.**

### What You MUST Test
1. **Producer Encoding**: Verify `dd-pathway-ctx-base64` header is ADDED by the tracer (not manually)
2. **Consumer Decoding**: Verify `setDataStreamsContext` is called with correct parameters
3. **Checkpoint Creation**: Verify `setCheckpoint` is called for produce/consume operations

### DO NOT Give Up on Tests!
- If tests are complex, simplify them - but DO NOT DELETE THEM
- If tests are failing, fix them - iterate until they pass
- The feature is NOT DONE until tests are GREEN

### Minimum Required Tests
```javascript
describe('DSM', () => {
  it('should encode DSM pathway context into producer messages')   // REQUIRED
  it('should decode DSM pathway context and set checkpoint on consume')  // REQUIRED
})
```

---

## Code Quality Guidelines

### Where to Make Changes
- **ALL changes go in plugin files** (`packages/datadog-plugin-*/src/*.js`)
- **DO NOT modify instrumentation files** (`packages/datadog-instrumentations/src/*.js`)
- Instrumentation files only handle hooking - all tracing logic belongs in plugins

### Code Cleanliness
- **Prioritize clean, readable code** - no ugly hacks or duplicated logic
- **Abstract common operations into helper functions** that can be reused
- Keep `bindStart` methods focused and readable

### Helper Function Pattern
When DSM logic is complex, extract it to a helper:
```javascript
// In the plugin file - create reusable helpers
_setProducerCheckpoint(span, ctx) {
  if (!this.config.dsmEnabled) return

  const payloadSize = getMessageSize(ctx.message)
  const edgeTags = ['direction:out', `topic:${ctx.queueName}`, 'type:bullmq']
  const dataStreamsContext = this.tracer.setCheckpoint(edgeTags, span, payloadSize)
  DsmPathwayCodec.encode(dataStreamsContext, ctx.message.headers)
}

_setConsumerCheckpoint(span, ctx) {
  if (!this.config.dsmEnabled || !ctx.headers) return

  const payloadSize = getMessageSize(ctx.message)
  this.tracer.decodeDataStreamsContext(ctx.headers)
  const edgeTags = ['direction:in', `topic:${ctx.queueName}`, 'type:bullmq']
  this.tracer.setCheckpoint(edgeTags, span, payloadSize)
}
```

### Context Storage Convention
When injecting context into custom data structures (not standard headers):
- **Use a `_datadog` attribute** to hold trace/DSM context
- This is a Datadog convention used across AWS SQS, SNS, and other integrations

```javascript
// Good - use _datadog attribute
message._datadog = {}
this.tracer.inject(span, 'text_map', message._datadog)
DsmPathwayCodec.encode(dataStreamsContext, message._datadog)

// Bad - polluting the message with multiple top-level keys
message['x-datadog-trace-id'] = traceId
message['dd-pathway-ctx-base64'] = pathwayCtx
```

---

## RESEARCH THE LIBRARY FIRST

**Before implementing DSM, you MUST understand how the library handles headers/metadata.**

Different libraries have very different mechanisms for passing metadata with messages. **DO NOT assume headers are simple key-value strings.** Research the library first!

### Research Steps (REQUIRED)
1. **Read the library's documentation** - How does it handle message metadata/headers?
2. **Examine the library's API** - What format does it expect for headers?
3. **Look at the functions you're tracing** - How do they access/pass headers?
4. **Check existing dd-trace plugins** - How do similar libraries (kafkajs, amqplib) handle this?
5. **Test header round-trip** - Can you send and receive headers successfully?

### Header Format Requirements

| Library | Carrier | Header Value Format |
|---------|---------|---------------------|
| Kafka (kafkajs) | `message.headers` | `Buffer` or `string` (values are often Buffers) |
| RabbitMQ (amqplib) | `options.headers` | Plain object with string values |
| AWS SQS | `MessageAttributes._datadog` | `{ DataType: 'String', StringValue: JSON.stringify(...) }` |
| AWS SNS | Message attributes | Structured object |
| BullMQ/Bull | `job.opts` or custom | Plain object (may need custom attribute) |

### Canonical Example: Buffer-based headers (Kafka)
```javascript
// Producer - let DsmPathwayCodec handle the format
message.headers = message.headers || {}
DsmPathwayCodec.encode(dataStreamsContext, message.headers)

// Consumer - decode Buffer values before extracting DSM context
const headerValue = Buffer.isBuffer(headers['dd-pathway-ctx-base64'])
  ? headers['dd-pathway-ctx-base64'].toString()
  : headers['dd-pathway-ctx-base64']
```

### Canonical Example: JSON-encoded headers (AWS SQS)
For SQS, DSM context is embedded in the same `_datadog` attribute as trace context:
```javascript
// Producer - inject trace + DSM into one object, then stringify
const ddInfo = {}
this.tracer.inject(span, 'text_map', ddInfo)
const dataStreamsContext = this.tracer.setCheckpoint(edgeTags, span, payloadSize)
DsmPathwayCodec.encode(dataStreamsContext, ddInfo)

params.MessageAttributes = params.MessageAttributes || {}
params.MessageAttributes._datadog = {
  DataType: 'String',
  StringValue: JSON.stringify(ddInfo)
}
```

For other library types, follow the same encode/decode pattern adapted to the library's header format.

---

## Overview
Data Streams Monitoring in dd-trace-js is implemented using:
- `tracer.setCheckpoint()` to create checkpoints
- `DsmPathwayCodec` to encode/decode pathway context in message headers
- `tracer.decodeDataStreamsContext()` to extract context on consume

## DSM Header Format

### Header Keys
- **`dd-pathway-ctx-base64`** - Primary key (base64 encoded, recommended)

### Header Value Format (base64 decoded)
```
[pathway_hash: 8 bytes][pathway_start_ms: varint][edge_start_ms: varint]
```
- Total: ~20 bytes
- Hash is little-endian
- Timestamps are varints in milliseconds

### Encoding/Decoding
```javascript
const { DsmPathwayCodec } = require('../../dd-trace/src/datastreams')

// Encode into carrier
DsmPathwayCodec.encode(dataStreamsContext, message.headers)
// Sets: message.headers['dd-pathway-ctx-base64'] = '<base64 encoded context>'

// Decode from carrier
const ctx = DsmPathwayCodec.decode(carrier)
// Returns: { hash: Buffer, pathwayStartNs: number, edgeStartNs: number }
```

## Key Imports
```javascript
const { DsmPathwayCodec, getMessageSize } = require('../../dd-trace/src/datastreams')
```

## Producer Implementation Pattern
In the producer plugin's `bindStart` method:

```javascript
if (this.config.dsmEnabled) {
  const payloadSize = getMessageSize(message)
  const edgeTags = ['direction:out', `topic:${topic}`, `type:${systemType}`]

  const dataStreamsContext = this.tracer.setCheckpoint(edgeTags, span, payloadSize)

  // Encode pathway context into message headers
  // This sets: headers['dd-pathway-ctx-base64'] = '<base64 encoded>'
  DsmPathwayCodec.encode(dataStreamsContext, message.headers)
}
```

## Consumer Implementation Pattern
In the consumer plugin's `bindStart` method:

```javascript
if (this.config.dsmEnabled && headers) {
  const payloadSize = getMessageSize(message)

  // Decode context from incoming message (reads dd-pathway-ctx-base64 header)
  this.tracer.decodeDataStreamsContext(headers)

  const edgeTags = ['direction:in', `group:${groupId}`, `topic:${topic}`, `type:${systemType}`]
  this.tracer.setCheckpoint(edgeTags, span, payloadSize)
}
```

## Edge Tags
Edge tags identify the data stream path:
- `direction:out` for producers, `direction:in` for consumers
- `topic:{name}` or `queue:{name}` for the destination
- `type:{system}` like `kafka`, `rabbitmq`, `sqs`, etc.
- `group:{id}` for consumer groups (optional)

## Configuration

### CRITICAL: Environment Variable Must Be Set BEFORE Tracer Initializes!

**`DD_DATA_STREAMS_ENABLED=true` MUST be set before any tests run or the tracer initializes!**

DSM initialization happens at tracer startup. If the env var isn't set when the tracer loads, DSM will be disabled for the entire process.

**In test files, set the env var at the TOP, BEFORE any requires:**
```javascript
'use strict'

// MUST be set BEFORE requiring dd-trace or any instrumented modules!
process.env.DD_DATA_STREAMS_ENABLED = 'true'

const agent = require('../../dd-trace/test/plugins/agent')
const { expect } = require('chai')
```

> **Note:** "Before the tracer initializes" means before the `require('dd-trace')` call in the test file, not before the process starts. Setting the env var at the top of the test file (before any `require` statements that load the tracer) is the correct approach.

**Common mistake - setting it too late:**
```javascript
// WRONG - tracer already initialized by the time this runs
describe('DSM', () => {
  before(() => {
    process.env.DD_DATA_STREAMS_ENABLED = 'true'  // Too late!
  })
})
```

### Plugin Configuration
DSM is also enabled via plugin config:
```javascript
tracer.use('kafkajs', { dsmEnabled: true })
```

**Both are required:** The environment variable enables DSM globally, and `dsmEnabled: true` enables it for specific plugins.

## Testing DSM

### CRITICAL: Do NOT Cheat on Tests!

**INVALID TEST (cheating)** - Manually adding DSM headers:
```javascript
// WRONG - You're adding the header yourself, not testing the tracer
it('should encode DSM context', async () => {
  const headers = {
    'dd-pathway-ctx-base64': 'manually-encoded-value'  // Manually added!
  }
  await producer.send({ message: 'test', headers })
  // Asserting this manually-added header exists proves NOTHING
})
```

**VALID TEST** - Verify full DSM chain: producer encodes pathway, consumer decodes and chains hash:
```javascript
it('should set DSM checkpoints on produce and consume', done => {
  const setCtxSpy = sinon.spy(DataStreamsContext, 'setDataStreamsContext')

  agent
    .assertSomeTraces(() => {
      // Producer checkpoint was set with correct hash
      const producerCtx = setCtxSpy.args[0][0]
      expect(producerCtx.hash).to.equal(expectedProducerHash)

      // Consumer checkpoint chains from producer hash
      const consumerCtx = setCtxSpy.lastCall.args[0]
      expect(consumerCtx.hash).to.equal(expectedConsumerHash)

      setCtxSpy.restore()
    })
    .then(done)
    .catch(done)

  // Send WITHOUT dd-pathway-ctx-base64 - tracer encodes on produce, decodes on consume
  producer.send({ value: 'test' })
})
```

### What Makes a DSM Test Valid

| Valid | Invalid (Cheating) |
|----------|----------------------|
| Send message WITHOUT `dd-pathway-ctx-base64` header | Manually add `dd-pathway-ctx-base64` header |
| Assert tracer INJECTED the header | Assert your manually-added header exists |
| Verify `setDataStreamsContext` was called with correct hash | Only check header exists without hash verification |
| Use spy on `DataStreamsContext.setDataStreamsContext` | Hardcode expected values without computing them |

### Required Test Imports
```javascript
const DataStreamsContext = require('../../dd-trace/src/datastreams/context')
const { computePathwayHash } = require('../../dd-trace/src/datastreams/pathway')
const { ENTRY_PARENT_HASH, DataStreamsProcessor } = require('../../dd-trace/src/datastreams/processor')
```

### Computing Expected Pathway Hash
```javascript
const getDsmPathwayHash = (topic, isProducer, parentHash) => {
  const edgeTags = isProducer
    ? ['direction:out', `topic:${topic}`, 'type:kafka']
    : ['direction:in', `topic:${topic}`, 'type:kafka']

  return computePathwayHash('test', 'tester', edgeTags, parentHash)
}

// Producer hash starts from ENTRY_PARENT_HASH
const expectedProducerHash = getDsmPathwayHash(topic, true, ENTRY_PARENT_HASH)
// Consumer hash chains from producer
const expectedConsumerHash = getDsmPathwayHash(topic, false, expectedProducerHash)
```

### Complete Test Example (REQUIRED)
```javascript
'use strict'

// MUST be at the TOP - before ANY requires!
process.env.DD_DATA_STREAMS_ENABLED = 'true'

const agent = require('../../dd-trace/test/plugins/agent')
const DataStreamsContext = require('../../dd-trace/src/datastreams/context')
const sinon = require('sinon')

describe('DSM', () => {
  let setDataStreamsContextSpy

  beforeEach(() => {
    tracer.use('myPlugin', { dsmEnabled: true })
    setDataStreamsContextSpy = sinon.spy(DataStreamsContext, 'setDataStreamsContext')
  })

  afterEach(() => {
    setDataStreamsContextSpy.restore()
  })

  it('should set DSM checkpoint on produce', async () => {
    await producer.send(message)

    expect(setDataStreamsContextSpy.args[0][0].hash).to.equal(expectedProducerHash)
  })

  it('should set DSM checkpoint on consume', async () => {
    // Produce then consume
    await producer.send(message)

    await new Promise(resolve => {
      consumer.on('message', (msg) => {
        expect(setDataStreamsContextSpy.lastCall.args[0].hash).to.equal(expectedConsumerHash)
        resolve()
      })
    })
  })
})
```

## Files to Modify for DSM

### Producer Plugin
- Add DSM checkpoint in `bindStart` after creating span
- Encode pathway context into message headers using `DsmPathwayCodec.encode()`

### Consumer Plugin
- Decode pathway context from headers in `bindStart` using `tracer.decodeDataStreamsContext()`
- Add DSM checkpoint after decoding

### Plugin Index
- Ensure `dsmEnabled` config option is available

## Helper Functions Available
- `getMessageSize(message)` - Calculate message payload size
- `DsmPathwayCodec.encode(ctx, headers)` - Inject context into headers (sets `dd-pathway-ctx-base64`)
- `DsmPathwayCodec.decode(headers)` - Extract context from headers
- `tracer.setCheckpoint(edgeTags, span, payloadSize)` - Create checkpoint
- `tracer.decodeDataStreamsContext(headers)` - Decode and set context

---

## Test Checklist Before Completion

- [ ] **`DD_DATA_STREAMS_ENABLED=true` set at TOP of test file, BEFORE any requires**
- [ ] Added `describe('DSM', ...)` test block with `dsmEnabled: true`
- [ ] Test verifies producer calls `setDataStreamsContext` with correct hash
- [ ] Test verifies consumer calls `setDataStreamsContext` chained from producer hash
- [ ] Test verifies `dd-pathway-ctx-base64` header is ADDED by tracer (not manually)
- [ ] All tests PASS (use test command from Instructions section)
- [ ] Did NOT manually add DSM headers in test (that's cheating!)

**The feature is NOT complete until ALL tests pass!**
