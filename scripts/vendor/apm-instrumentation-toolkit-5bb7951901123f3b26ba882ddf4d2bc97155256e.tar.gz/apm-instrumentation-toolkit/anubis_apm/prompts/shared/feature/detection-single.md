# Single Feature Detection: {{feature_id}}

You are checking if the **{{feature_id}}** feature should be implemented for this integration.

## Feature Guide

Read the full feature guide at: `{{feature_guide_file}}`

This file describes what the feature is, when it applies, and implementation details.

## Integration to Analyze

**Integration**: {{integration_name}}

**Analysis File**: `{{analysis_file}}`

Read this file to understand:
- The library category (database, messaging, HTTP, etc.)
- Instrumented methods and their span kinds (client, producer, consumer)
- Operations being traced
- Tags being captured

## Your Task

1. Read the analysis file at `{{analysis_file}}`
2. Determine if **{{feature_id}}** applies to this integration
3. Output your decision with reasoning

## Decision Guidelines

- **dsm** (Data Streams Monitoring): Applies to messaging/queue systems with producer AND consumer operations
- **context_propagation**: Applies to messaging systems, HTTP servers/web frameworks, and HTTP clients that need distributed trace context
- **dbm** (Database Monitoring): Applies to database clients that execute SQL queries
- **peer_service**: Applies to ANY client/producer making outbound calls (databases, messaging, HTTP, cache)

## Output

Your output must conform to the schema appended below.

Be accurate: only mark `applicable: true` if this feature genuinely applies to this library type.
