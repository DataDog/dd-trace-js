# General Feature Implementation Guidelines (dd-trace-py)

## Architecture: Patch + Handler Separation

dd-trace-py uses `patch.py` as the main entry point for wrapping library functions, with feature logic handled through different patterns depending on the integration type.

### Integration Patterns (ordered by preference for NEW integrations)

**`context_with_event()` + `TracingEvent`** (NEW — preferred for new standard integrations):
Typed event-driven pattern using `core.context_with_event()` with `TracingEvent` subclasses and `TracingSubscriber`. Events should be category-specific (e.g., one event class shared by all HTTP-client integrations). If a category event class already exists in `ddtrace/_trace/events/`, use it. If not, create the base class event + subscriber for that category. Infrastructure: `ddtrace/_trace/events.py`, `ddtrace/_trace/subscribers/`, `ddtrace/internal/core/__init__.py:311`.

**`context_with_data()` + `trace_handlers.py`** (preferred for modifying existing integrations):
Wrappers use `core.context_with_data()` to emit events, `trace_handlers.py` listeners create spans. Used by botocore, flask, httpx, django.

**LLM integrations** (anthropic, openai, etc.): `integration.trace()` in patch.py creates spans directly. Feature logic (LLMObs tags) is set via `integration.llmobs_set_tags()` in the finally block. See `ddtrace/contrib/internal/anthropic/patch.py`.

**Pin + `tracer.trace()`** (DEPRECATED — do not use in new code): Many existing integrations use `Pin.get_from(instance)` + `tracer.trace()` (kafka, redis, grpc, etc.). Do NOT use Pin in new integrations.

## Code Locations

| Code Type | Location |
|-----------|----------|
| Integration patch | `ddtrace/contrib/internal/{lib}/patch.py` |
| Integration config | `ddtrace/contrib/internal/{lib}/__init__.py` |
| LLM integrations | `ddtrace/llmobs/_integrations/{lib}.py` |
| Tracing handlers | `ddtrace/_trace/trace_handlers.py` |
| TracingEvent base | `ddtrace/_trace/events.py` |
| TracingSubscriber base | `ddtrace/_trace/subscribers/_base.py` |
| context_with_event API | `ddtrace/internal/core/__init__.py` |
| Event primitives | `ddtrace/internal/core/events.py` |
| DSM handlers | `ddtrace/internal/datastreams/{lib}.py` |
| DBM propagator | `ddtrace/propagation/_database_monitoring.py` |

## Event Naming: `{integration}.{operation}.{phase}`

Examples: `kafka.produce.start`, `redis.command.post`

## Test Rules

1. **Reuse existing test fixtures** -- never create your own tracer instance. See `tests/contrib/kafka/` for fixture patterns.
2. **Never skip tests** -- no `@pytest.mark.skip`, no `pytest.skip()`. Implement, fix, or remove.
3. **TDD** -- write failing tests first, then implement.

## Gotchas

- Context propagation on non-HTTP carriers uses a `_datadog` dict attribute (see `kafka/patch.py`)
- Handlers must wrap logic in try/except to prevent application crashes
- Never remove code marked with `# DO NOT REMOVE` or similar comments
- Config options go in `__init__.py` using `config._add()`
