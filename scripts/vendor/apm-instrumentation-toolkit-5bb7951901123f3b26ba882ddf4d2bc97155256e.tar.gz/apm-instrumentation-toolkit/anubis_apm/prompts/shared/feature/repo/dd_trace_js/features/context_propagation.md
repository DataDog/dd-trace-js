# Context Propagation Implementation Guide for Node.js (dd-trace-js)

## CRITICAL: Tests are MANDATORY - Feature is NOT Complete Without Them!

**You MUST add tests that verify context propagation works. This is NON-NEGOTIABLE.**

### What You MUST Test
1. **Producer Injection**: Verify `x-datadog-trace-id` and `x-datadog-parent-id` are INJECTED by the tracer (not manually added)
2. **Consumer Extraction**: Verify consumer span's `parent_id` equals producer span's `span_id`
3. **Distributed Trace**: Verify both spans share the same `trace_id`

### DO NOT Give Up on Tests!
- If tests are complex, simplify them - but DO NOT DELETE THEM
- If tests are failing, fix them - iterate until they pass
- The feature is NOT DONE until tests are GREEN

### Minimum Required Tests
```javascript
describe('context propagation', () => {
  it('should inject trace context into producer messages')   // REQUIRED
  it('should extract trace context and link consumer to producer')  // REQUIRED
})
```

---

## Code Quality Guidelines

### Where to Make Changes
- **ALL changes go in plugin files** (`packages/datadog-plugin-*/src/*.js`)
- **DO NOT modify instrumentation files** (`packages/datadog-instrumentations/src/*.js`)
- Instrumentation files only handle hooking - all tracing logic belongs in plugins

### Code Cleanliness
- **Prioritize clean, readable code** - no ugly hacks or duplicated logic
- **Abstract common operations into helper functions** that can be reused
- Keep `bindStart` methods focused and readable

### Helper Function Pattern
When context propagation logic is shared, extract it to helpers:
```javascript
// In the plugin file - create reusable helpers
_injectContext(span, carrier) {
  this.tracer.inject(span, 'text_map', carrier)
}

_extractContext(carrier) {
  if (!carrier) return null
  return this.tracer.extract('text_map', this._normalizeHeaders(carrier))
}

_normalizeHeaders(headers) {
  // Convert Buffer values to strings (e.g., for Kafka)
  const normalized = {}
  for (const [key, value] of Object.entries(headers)) {
    normalized[key] = Buffer.isBuffer(value) ? value.toString() : value
  }
  return normalized
}
```

### Context Storage Convention
When injecting context into custom data structures (not standard headers):
- **Use a `_datadog` attribute** to hold trace context
- This is a Datadog convention used across AWS SQS, SNS, and other integrations

```javascript
// Good - use _datadog attribute for custom carriers
message._datadog = {}
this.tracer.inject(span, 'text_map', message._datadog)

// For extraction
const parentContext = this.tracer.extract('text_map', message._datadog || {})

// Bad - polluting the message with multiple top-level keys
message['x-datadog-trace-id'] = traceId
message['x-datadog-parent-id'] = parentId
```

---

## RESEARCH THE LIBRARY FIRST

**Before implementing context propagation, you MUST understand how the library handles headers/metadata.**

Different libraries have very different mechanisms for passing metadata with messages. **DO NOT assume headers are simple key-value strings.** Research the library first!

### Research Steps (REQUIRED)
1. **Read the library's documentation** - How does it handle message metadata/headers?
2. **Examine the library's API** - What format does it expect for headers?
3. **Look at the functions you're tracing** - How do they access/pass headers?
4. **Check existing dd-trace plugins** - How do similar libraries (kafkajs, amqplib) handle this?
5. **Test header round-trip** - Can you send and receive headers successfully?

### Header Format Requirements

| Library Type | Carrier Location | Header Value Format |
|--------------|------------------|---------------------|
| Kafka (kafkajs) | `message.headers` | `Buffer` or `string` (values are often Buffers) |
| RabbitMQ (amqplib) | `options.headers` | Plain object with string values |
| AWS SQS | `MessageAttributes._datadog` | `{ DataType: 'String', StringValue: JSON.stringify(...) }` |
| AWS SNS | Message attributes or body | Structured object |
| HTTP clients | Request headers | Direct headers |
| gRPC | Metadata | Key-value pairs |

### Canonical Example: Buffer-based headers (Kafka)
```javascript
// Producer - tracer.inject handles string values, library may convert to Buffer
message.headers = message.headers || {}
this.tracer.inject(span, 'text_map', message.headers)

// Consumer - MUST decode Buffer values before extraction
function normalizeHeaders(headers) {
  if (!headers) return {}
  const normalized = {}
  for (const [key, value] of Object.entries(headers)) {
    normalized[key] = Buffer.isBuffer(value) ? value.toString() : value
  }
  return normalized
}
const parentContext = this.tracer.extract('text_map', normalizeHeaders(headers))
```

### Canonical Example: JSON-encoded headers (AWS SQS)
```javascript
// Producer - inject into object, then stringify into MessageAttributes
const ddInfo = {}
this.tracer.inject(span, 'text_map', ddInfo)
params.MessageAttributes = params.MessageAttributes || {}
params.MessageAttributes._datadog = {
  DataType: 'String',
  StringValue: JSON.stringify(ddInfo)
}

// Consumer - parse the StringValue, then extract
const datadogAttr = message.MessageAttributes?._datadog
if (datadogAttr) {
  const parsed = JSON.parse(datadogAttr.StringValue)
  const parentContext = this.tracer.extract('text_map', parsed)
}
```

For other library types, follow the same inject/extract pattern adapted to the library's header format.

---

## Overview
Context propagation in dd-trace-js uses:
- `tracer.inject(span, format, carrier)` to inject trace context
- `tracer.extract(format, carrier)` to extract trace context
- `childOf` option when creating spans to link to parent

## Trace Context Headers
Datadog uses these headers for distributed tracing:
- **`x-datadog-trace-id`** - 64-bit trace ID
- **`x-datadog-parent-id`** - 64-bit span ID
- **`x-datadog-sampling-priority`** - Sampling decision
- **`x-datadog-origin`** - Trace origin (e.g., synthetics)
- **`x-datadog-tags`** - Propagated tags (e.g., `_dd.p.dm=-0`)

Also supports W3C Trace Context (`traceparent`, `tracestate`).

## Key API
```javascript
// Inject span context into carrier (outgoing)
this.tracer.inject(span, 'text_map', carrier)

// Extract span context from carrier (incoming)
const parentContext = this.tracer.extract('text_map', carrier)
```

## Producer/Sender Pattern
Inject context into outgoing message headers:

```javascript
bindStart (ctx) {
  const { message } = ctx

  const span = this.startSpan(name, {
    resource: topic,
    meta: { component: 'my-plugin' }
  }, ctx)

  // Ensure headers object exists
  message.headers ??= {}

  // Inject trace context into message headers
  this.tracer.inject(span, 'text_map', message.headers)

  return ctx.currentStore
}
```

## Consumer/Receiver Pattern
Extract context from incoming message headers:

```javascript
bindStart (ctx) {
  const { message } = ctx
  const headers = message?.headers || {}

  // Extract parent context (add normalizeHeaders() if library uses Buffers)
  const childOf = this.tracer.extract('text_map', headers)

  // Create span linked to parent
  const span = this.startSpan(name, {
      childOf,  // Links this span to the producer span
      resource: topic,
      type: 'worker',
      meta: { component: 'my-plugin' }
  }, ctx)

  return ctx.currentStore
}
```

If the library uses Buffer headers, apply the `normalizeHeaders()` function from the Kafka example above before calling `extract`.

## Common Patterns

### Batch Messages
When producing multiple messages:
```javascript
for (const message of messages) {
  message.headers ??= {}
  this.tracer.inject(span, 'text_map', message.headers)
}
```

### Optional Header Injection
Some brokers don't support headers:
```javascript
if (!disableHeaderInjection && message.headers) {
  this.tracer.inject(span, 'text_map', message.headers)
}
```

## Files to Modify

### Producer Plugin
- Add `tracer.inject(span, 'text_map', headers)` after creating span
- Ensure message has headers object

### Consumer Plugin
- Extract context: `tracer.extract('text_map', headers)`
- Pass `childOf` to `startSpan()`
- Add header conversion if needed (see Kafka example above)

---

## Testing Context Propagation

### CRITICAL: Do NOT Cheat on Tests!

**INVALID TEST (cheating)** - Manually adding trace headers:
```javascript
// WRONG - You're adding headers yourself, not testing the tracer
it('should extract trace context', async () => {
  const headers = {
    'x-datadog-trace-id': '1234567890',  // Manually added!
    'x-datadog-parent-id': '9876543210'   // Manually added!
  }
  await producer.send({ message: 'test', headers })
  // Asserting these manually-added headers exist proves NOTHING
})
```

**VALID TEST** - Verify full propagation: producer injects headers, consumer receives them, trace IDs link:
```javascript
it('should propagate trace context from producer to consumer', done => {
  agent
    .assertSomeTraces(traces => {
      const allSpans = traces.flat()
      const producerSpan = allSpans.find(s => s.meta['span.kind'] === 'producer')
      const consumerSpan = allSpans.find(s => s.meta['span.kind'] === 'consumer')

      expect(producerSpan).to.exist
      expect(consumerSpan).to.exist

      // Tracer injected headers (not manually added)
      expect(producerSpan.trace_id).to.exist

      // Consumer extracted headers and linked to producer
      expect(consumerSpan.trace_id.toString())
        .to.equal(producerSpan.trace_id.toString())
      expect(consumerSpan.parent_id.toString())
        .to.equal(producerSpan.span_id.toString())
    })
    .then(done)
    .catch(done)

  // Send WITHOUT trace headers - tracer injects, consumer extracts
  channel.sendToQueue(testQueue, Buffer.from('test'), { headers: {} })
})
```

### What Makes a Test Valid

| Valid | Invalid (Cheating) |
|----------|----------------------|
| Send message WITHOUT trace headers | Manually add `x-datadog-*` headers |
| Assert tracer INJECTED headers | Assert your manually-added headers exist |
| Verify consumer span.parent_id === producer span.span_id | Only check headers exist without span linking |
| Verify trace_id matches across producer/consumer | Hardcode trace IDs in test |

### Complete Test Example (REQUIRED)

**You MUST add tests like these.** Add to the existing test file (e.g., `packages/datadog-plugin-{name}/test/index.spec.js`):

```javascript
describe('context propagation', () => {
  let testQueue

  beforeEach(done => {
    channel.assertQueue('', { exclusive: true }, (err, ok) => {
      if (err) return done(err)
      testQueue = ok.queue
      done()
    })
  })

  it('should inject trace context into producer messages', done => {
    agent
      .assertSomeTraces(traces => {
        const producerSpan = traces.flat().find(span =>
          span.meta['span.kind'] === 'producer'
        )

        expect(producerSpan).to.exist
        expect(producerSpan.trace_id).to.exist
        expect(producerSpan.span_id).to.exist
      })
      .then(done)
      .catch(done)

    // Send message - tracer should inject context into headers
    channel.sendToQueue(testQueue, Buffer.from('test message'))
  })

  it('should link consumer span to producer span via distributed trace', done => {
    let producerSpan
    let consumerSpan

    agent
      .assertSomeTraces(traces => {
        const allSpans = traces.flat()

        for (const span of allSpans) {
          if (span.meta['span.kind'] === 'producer') producerSpan = span
          if (span.meta['span.kind'] === 'consumer') consumerSpan = span
        }

        expect(producerSpan).to.exist
        expect(consumerSpan).to.exist

        // Verify distributed trace - same trace ID
        expect(consumerSpan.trace_id.toString())
          .to.equal(producerSpan.trace_id.toString())

        // Consumer is child of producer
        expect(consumerSpan.parent_id.toString())
          .to.equal(producerSpan.span_id.toString())
      })
      .then(done)
      .catch(done)

    // Set up consumer first
    channel.consume(testQueue, () => {}, { noAck: true })

    // Then send message - creates distributed trace
    setTimeout(() => {
      channel.sendToQueue(testQueue, Buffer.from('test'))
    }, 100)
  })
})
```

### Test Checklist Before Completion

- [ ] Added `describe('context propagation', ...)` test block
- [ ] Test verifies producer span exists with trace context
- [ ] Test verifies consumer span is CHILD of producer span (parent_id check)
- [ ] Test verifies both spans share same trace_id
- [ ] All tests PASS (use test command from Instructions section)
- [ ] Did NOT manually add trace headers in test (that's cheating!)

**The feature is NOT complete until ALL tests pass!**
