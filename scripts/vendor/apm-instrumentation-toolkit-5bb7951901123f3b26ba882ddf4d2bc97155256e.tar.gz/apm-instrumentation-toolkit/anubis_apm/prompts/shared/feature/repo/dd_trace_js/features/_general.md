# General Feature Implementation Guidelines

This document contains guidelines that apply to ALL feature implementations (DSM, context propagation, peer service, etc.).

---

## Test Setup Reuse - CRITICAL

When adding tests for new features, you MUST reuse the existing test infrastructure. Do NOT import modules directly or create your own test setup.

- **`tracer`** - Already initialized with correct config in test file's `before`/`beforeEach` hooks
- **`agent`** - Test assertion helper (`require('../../dd-trace/test/plugins/agent')`)
- **`meta.mod`** - The instrumented module; use this instead of requiring the package yourself
- **Connection objects** (Redis, RabbitMQ clients, etc.) - Already created in parent `describe` blocks

### Correct Pattern
```javascript
// Use existing test infrastructure
describe('my-plugin', () => {
  // ... existing setup code ...

  describe('DSM', () => {
    it('should set DSM checkpoint on produce', async () => {
      const { Queue } = meta.mod  // Use what's already available
      const queue = new Queue('test-queue')
      // ... test code using existing tracer and agent ...
    })
  })
})
```

### Anti-Pattern - DO NOT DO THIS
```javascript
// DON'T import the module yourself - it's already available via meta.mod
Queue = require('../../../versions/bee-queue@^1.7.1/node_modules/bee-queue')
// DON'T re-init the tracer - it's already set up
const tracer = require('dd-trace').init()
```

### What to Reuse vs. What to Add

| Reuse (Don't Recreate) | Add New (OK to Create) |
|------------------------|------------------------|
| `tracer`, `agent`, `meta.mod` | New test cases / describe blocks |
| Connection setup (Redis, RabbitMQ, etc.) | Spies for specific functions |
| Queue/channel/client instances | Feature-specific assertions |

Nest new feature tests inside the existing `withVersions` block:
```javascript
withVersions('my-plugin', 'my-library', version => {
  describe('my-plugin', () => {
    // ADD your new feature tests here, inside the existing structure:
    describe('context propagation', () => { /* ... */ })
    describe('DSM', () => { /* ... */ })
  })
})
```

Only create new setup when testing a config option that requires tracer re-initialization (rare) or when existing setup doesn't cover the scenario.

---

## Test Requirements - NEVER SKIP TESTS

**NEVER use `.skip()`, `describe.skip()`, `it.skip()`, or `xit()` in test code!**

- Write tests that actually run and verify behavior
- If a test is failing: implement the feature, fix the test, or remove it if inapplicable
- Skipping tests hides problems and creates technical debt

---

## Respecting Implementation Comments

When you see code comments that explain WHY code exists:
- `// DO NOT REMOVE` or `// REQUIRED`
- `// this line is required...`
- `// without this, X happens...`

**DO NOT remove or modify that code.** The comment is there because the code is necessary. If tests are failing, the fix is elsewhere.

---

## Code Location Guidelines

### Where to Make Changes

- **ALL tracing logic goes in plugin files** (`packages/datadog-plugin-*/src/*.js`)
- **DO NOT modify instrumentation files** (`packages/datadog-instrumentations/src/*.js`)
- Instrumentation files only handle hooking - all tracing logic belongs in plugins

### Code Cleanliness

- **Prioritize clean, readable code** - no ugly hacks or duplicated logic
- **Abstract common operations into helper functions** that can be reused
- Avoid copy-pasting the same logic multiple times - extract to a shared function
- Keep `bindStart` methods focused and readable

---

## Context Storage Convention

When injecting context into custom data structures (not standard HTTP headers):

- **Use a `_datadog` attribute** to hold trace/DSM context
- This is a Datadog convention used across AWS SQS, SNS, and other integrations

```javascript
// Good - use _datadog attribute for custom carriers
message._datadog = {}
this.tracer.inject(span, 'text_map', message._datadog)
DsmPathwayCodec.encode(dataStreamsContext, message._datadog)

// For extraction
const parentContext = this.tracer.extract('text_map', message._datadog || {})

// Bad - polluting the message with multiple top-level keys
message['x-datadog-trace-id'] = traceId
message['dd-pathway-ctx-base64'] = pathwayCtx
```
