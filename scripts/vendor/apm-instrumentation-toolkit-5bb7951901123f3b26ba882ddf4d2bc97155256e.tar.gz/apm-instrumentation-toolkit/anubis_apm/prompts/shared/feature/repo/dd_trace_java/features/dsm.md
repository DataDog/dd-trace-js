# Data Streams Monitoring (DSM) Feature (dd-trace-java)

DSM tracks end-to-end message-pipeline latency by setting `PathwayContext` checkpoints on produce and consume operations and propagating the pathway state via message headers.

## Reference Integration: **`dd-java-agent/instrumentation/kafka-clients-0.11/`**

The Kafka clients integration is the most complete DSM example. Read the producer Advice, consumer Advice, and decorator end-to-end before writing — DSM tagging is intertwined with header injection.

## Core API

`dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/api/PathwayContext.java`

Two methods you'll use:
- `PathwayContext.setCheckpoint(span, ...tags, offset)` — emit a checkpoint at this stage in the pipeline
- `PathwayContext.extractFromHeaders(carrier, getter)` / `injectToHeaders(span, carrier, setter)` — propagate the pathway across the message boundary

## Pattern (3 steps)

### 1. Producer Advice exit — checkpoint + inject

After span finish, call `PathwayContext.setCheckpoint(span, "direction:out", "topic:" + record.topic(), 0)` and inject the pathway into the outgoing message headers via the same `Setter` adapter you use for trace context propagation.

Reference: the producer Advice in `dd-java-agent/instrumentation/kafka-clients-0.11/src/main/java/.../`.

### 2. Consumer Advice enter — extract + checkpoint

Before starting the span, extract the inbound `PathwayContext` from the message headers, then call `PathwayContext.setCheckpoint(span, pathwayContext, "direction:in", "topic:" + record.topic(), record.offset())`. The offset closes the loop end-to-end so the DSM backend can compute pipeline latency.

Reference: the consumer Advice in `dd-java-agent/instrumentation/kafka-clients-0.11/src/main/java/.../`.

### 3. Header carrier adapters

Reuse the same `AgentPropagation.Setter` / `ContextVisitor` adapters used by your trace-context propagation feature — DSM piggybacks on the same carrier. See `context_propagation.md` for the carrier reference table.

## Other DSM references

| Library | Reference |
|---|---|
| AWS SQS / SNS / Kinesis (v2) | `dd-java-agent/instrumentation/aws-java/aws-java-sdk-2.2/src/dsmTest/groovy/Aws2KinesisDataStreamsTest.groovy` |
| Confluent Schema Registry | `dd-java-agent/instrumentation/confluent-schema-registry/confluent-schema-registry-4.1/src/test/groovy/ConfluentSchemaRegistryDataStreamsTest.groovy` |
| End-to-end smoke test | `dd-smoke-tests/datastreams/kafkaschemaregistry/` |

## Required checkpoint tags

| Tag | Producer | Consumer |
|---|---|---|
| `direction:out` | ✓ | — |
| `direction:in` | — | ✓ |
| `topic:{name}` or `queue:{name}` | ✓ | ✓ |
| `group:{name}` | — | ✓ (when applicable, e.g. Kafka consumer groups) |

## Tests

Reference: `dd-java-agent/instrumentation-testing/src/main/groovy/datadog/trace/agent/test/datastreams/RecordingDatastreamsPayloadWriter.groovy` provides the test helpers. Spock specs assert on `pathway.hash` tag presence and pipeline structure.

Copy the assertion shape from `Aws2KinesisDataStreamsTest.groovy` — it shows producer→consumer pathway-hash linkage.

## Gotchas

- Direction tag values are `out` / `in`, not `send` / `receive`.
- Offset: use the actual message offset on consume, `0` on produce.
- For batch operations, emit one checkpoint per message, not one per batch.
- Pathway header injection is required on the producer side — without it, the consumer can't extract a parent pathway and DSM is broken.
- DSM is opt-in via `dd.data.streams.enabled=true`. Tests need to enable it explicitly (see the `dsmTest` Gradle test set in `aws-java-sdk-2.2/`).
