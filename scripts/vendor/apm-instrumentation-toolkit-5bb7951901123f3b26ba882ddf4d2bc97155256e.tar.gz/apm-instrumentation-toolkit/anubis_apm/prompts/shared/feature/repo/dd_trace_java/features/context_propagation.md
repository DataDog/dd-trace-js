# Context Propagation Feature (dd-trace-java)

Distributed-tracing context propagation across service boundaries (HTTP headers, message metadata, gRPC metadata, etc.).

## Reference Integration: **`dd-java-agent/instrumentation/okhttp-3/`**

Read the okhttp-3 InstrumenterModule, Advice, and Setter adapter end-to-end. The Setter/Getter pattern is consistent across categories — the only thing that changes is which carrier object you wrap.

## Core APIs (read these first)

| File | What it defines |
|---|---|
| `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/api/AgentPropagation.java` | `AgentPropagation.Setter<C>`, `AgentPropagation.ContextVisitor<C>` interfaces |
| `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/httpurlconnection/HeadersInjectAdapter.java` | Minimal Setter example for `Map<String, List<String>>` carriers |

## Pattern (4 steps)

### 1. Setter adapter (client / producer side)

Implement `AgentPropagation.Setter<YourCarrier>`. The whole class is usually 5-10 lines — single `set(carrier, key, value)` method writing into your library's header/property API.

References (pick the closest carrier type):

| Carrier shape | Setter reference |
|---|---|
| HTTP headers (Map-style) | `dd-java-agent/instrumentation/apache-httpclient/apache-httpclient-4.0/src/main/java/.../HttpHeadersInjectAdapter.java` |
| Mutable Request builder | `dd-java-agent/instrumentation/okhttp-3/src/main/java/.../RequestBuilderInjectAdapter.java` |
| Kafka headers | `dd-java-agent/instrumentation/kafka-clients-0.11/src/main/java/.../TextMapInjectAdapterInterface.java` |
| AWS SQS / SNS message attributes | `dd-java-agent/instrumentation/aws-java/aws-java-sns-2.0/src/main/java/.../TextMapInjectAdapter.java` |
| gRPC Metadata | `dd-java-agent/instrumentation/armeria/armeria-grpc-0.84/src/main/java/.../GrpcInjectAdapter.java` |

### 2. Getter adapter (server / consumer side)

Implement `AgentPropagation.ContextVisitor<YourCarrier>` with a `forEachKey(carrier, classifier)` method. Iterate the carrier's keys, calling `classifier.accept(name, value)` for each.

Reference: `dd-java-agent/instrumentation/armeria/armeria-grpc-0.84/src/main/java/.../GrpcExtractAdapter.java` (typical shape — call classifier in a loop, return early if it returns false).

### 3. Injection (client / producer Advice)

In your method-enter Advice, after starting the span, call `propagate().inject(span, carrier, SETTER)`. The Advice itself stays small — most of the lifecycle code lives in the decorator.

Reference: the `OnMethodEnter` Advice in the okhttp-3 reference shows the exact span-start + inject sequence.

### 4. Extraction (server / consumer Advice)

In your method-enter Advice, before starting the span, call `propagate().extract(carrier, GETTER)` to get the parent context, then start the new span with that as the parent.

Reference: any HTTP-server integration's RequestExtract Advice (e.g., `dd-java-agent/instrumentation/netty-4.1/src/main/java/.../NettyHttpServerDecorator.java` shows the decorator-side, the corresponding Advice is in the same module).

## Propagation formats

All formats are supported automatically via `propagate()` — you don't pick. The tracer config decides what gets injected based on `dd.trace.propagation.style.{inject,extract}` (defaults to `datadog,tracecontext`).

| Format | Headers |
|---|---|
| Datadog | `x-datadog-trace-id`, `x-datadog-parent-id`, `x-datadog-sampling-priority` |
| W3C Trace Context | `traceparent`, `tracestate` |
| B3 (Zipkin) | `X-B3-TraceId`, `X-B3-SpanId`, `X-B3-Sampled` |

## Helper class declaration

Both adapters MUST be declared in your InstrumenterModule's `helperClassNames()` — missing helpers are the #1 cause of muzzle failures. For inner classes, use `$` notation (`FooAdvice$HeadersSetter`).

## Tests

Reference: `dd-java-agent/instrumentation/armeria/armeria-grpc-0.84/src/test/groovy/GrpcInjectAdapterTest.groovy` — minimal Spock spec asserting that a known trace context is correctly written into a carrier and read back.

For end-to-end propagation tests (assert that a downstream span has the expected `traceId` / `parentId`), copy from any HTTP-client or messaging reference integration's `*Test.groovy`.

## Gotchas

- Setter/Getter helpers MUST be in `helperClassNames()` (inner classes use `$`)
- HTTP headers are case-insensitive; adapters should preserve case to match the framework
- Some carriers allow multiple values per key — most APIs need single values, pick last or first
- `extract()` returns null if no parent context is present — that's the root span case
- For async work: inject BEFORE the async call dispatches, extract BEFORE processing
