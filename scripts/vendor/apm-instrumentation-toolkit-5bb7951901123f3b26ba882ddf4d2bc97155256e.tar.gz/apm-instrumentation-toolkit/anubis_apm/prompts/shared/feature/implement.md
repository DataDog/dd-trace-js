# Task: Add {{feature_id}} feature to {{integration_name}}

## Feature Implementation Guide

Read the full implementation guide at: `{{feature_guide_file}}`

## General Guidelines

Read general guidelines at: `{{general_guidelines_file}}`

## Instructions

1. **Analyze the integration**: Look in `{{plugin_path}}`
   - Check tests at `{{test_file_path}}`

2. **Write tests FIRST (TDD)**:
   - Add test cases for the new feature
   - Run tests to confirm they fail

3. **Implement the feature**:
   - Modify the plugin code
   - Follow patterns in implementation guide

4. **Run tests to verify**:
{{test_instructions}}

## Logging

All logs go to: `{{logs_dir}}/`

Save test output: `<cmd> 2>&1 | tee {{logs_dir}}/test-output-XX.log`

## Reference Integrations

{{reference_integrations}}

## CRITICAL RULES

**DELETING TESTS IS NEVER A VALID FIX.** If you delete, skip, or comment out tests, that is a FAILURE.
Tests exist to verify real functionality users need. Deleting error tests means errors won't be captured in production.

**YOU MUST ENSURE TESTS PASS BEFORE EXITING.**
- If you have not tried at least 15 test runs, you MUST NOT EXIT.
- Continue iterating until tests pass. You have 750 turns to fix the tests.
- We should NEVER exit with failing tests - failing tests will break our instrumentation.
