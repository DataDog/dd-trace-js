# Database Monitoring (DBM) Feature (dd-trace-java)

DBM adds query-level instrumentation to database client spans: query text (auto-obfuscated), connection metadata (host/port/db/user), and SQL comment injection so the database can correlate queries back to traces.

## Reference Integration: **`dd-java-agent/instrumentation/jdbc/`**

Read these files end-to-end before writing — DBM patterns are tightly coupled to the base decorator and the SQL commenter helper:

| File | Role |
|---|---|
| `dd-java-agent/instrumentation/jdbc/src/main/java/.../JDBCDecorator.java` | Extends `DatabaseClientDecorator`, sets `db.type` / `db.instance` / `db.user` / hostname tags |
| `dd-java-agent/instrumentation/jdbc/src/main/java/.../SQLCommenter.java` | Injects `traceparent` + `dddbs` SQL comment on outgoing queries |
| `dd-java-agent/instrumentation/jdbc/src/main/java/.../DBMCompatibleConnectionInstrumentation.java` | Wires the SQL commenter into Statement / PreparedStatement flow |
| `dd-java-agent/agent-bootstrap/src/main/java/datadog/trace/bootstrap/instrumentation/dbm/SharedDBCommenter.java` | Cross-driver commenter used by JDBC + Mongo |

## Pattern (3 steps)

### 1. Decorator extends `DatabaseClientDecorator`

Override `dbType()`, `dbInstance()`, `dbUser()`, `dbHostname()` — the base class wires those into the standard tag names. See `JDBCDecorator.java` for the full set.

### 2. Tag query text in the Advice

After span start, set `Tags.DB_STATEMENT` to the raw SQL. **Do not obfuscate manually** — the agent obfuscates literals and normalizes whitespace centrally. Set `Tags.DB_TYPE` to the lowercase database type (`sql`, `cassandra`, etc.).

The query-tagging Advice is small (3-5 lines added to a normal span-start). Pattern visible in any database-client `*Advice.java` under `dd-java-agent/instrumentation/jdbc/`.

### 3. SQL comment injection (DBM trace-to-query correlation)

For SQL drivers, prepend a `/* ... */` comment to the query text containing `traceparent` + `dddbs`. The Datadog DB agent picks these up and joins query stats back to traces.

Use `SharedDBCommenter` (in `agent-bootstrap`) — don't reimplement. The JDBC integration shows the wiring: `DBMCompatibleConnectionInstrumentation` instruments `Connection.prepareStatement` / `createStatement` and rewrites the query string through the commenter before it reaches the driver.

For non-SQL databases (Mongo, Redis), the analog is metadata-on-message — see `dd-java-agent/instrumentation/mongo/mongo-driver/mongo-driver-4.0/src/test/groovy/MongoDBMCommentTest.groovy` for the Mongo-side pattern.

## Required tags

| Tag | Source | Example |
|---|---|---|
| `db.type` | Decorator `dbType()` | `sql`, `redis`, `mongodb` |
| `db.statement` | Advice (raw query) | `SELECT * FROM users WHERE id = ?` |
| `db.instance` | Decorator `dbInstance()` | `myapp_production` |
| `db.user` | Decorator `dbUser()` | `app_user` |
| `peer.hostname` | Decorator `dbHostname()` | `db.example.com` |
| `peer.port` | Decorator `dbPort()` | `5432` |

## Query obfuscation

Handled centrally by the agent — literals → `?`, comments stripped, whitespace normalized. Do not pre-process the query string yourself.

Truncation cap: configurable via `dd.trace.db.statement.max.length`.

## Tests

References:
- `dd-java-agent/instrumentation/jdbc/src/test/groovy/SQLCommenterTest.groovy` — unit-level tests for the SQL commenter helper
- `dd-java-agent/instrumentation/jdbc/src/test/groovy/DBMInjectionForkedTest.groovy` — end-to-end DBM injection assertions
- `dd-java-agent/instrumentation/mongo/mongo-driver/mongo-driver-4.0/src/test/groovy/MongoDBMCommentTest.groovy` — non-SQL DBM pattern

Copy the assertion shape from the closest one — assert `db.statement`, `db.instance`, `peer.hostname`, and (for SQL DBM) the presence of the `traceparent` SQL comment in the executed query.

## Gotchas

- Prepared statements: capture the template (the question-marked form), not the bound values.
- Batch operations: tag each statement in the batch separately if the driver exposes them.
- Connection pooling: cache connection metadata in the decorator to avoid repeated `getMetaData()` calls.
- Wrap metadata extraction in try/catch — connections may be closed when the Advice runs.
- DBM SQL comment injection is opt-in via `dd.dbm.propagation.mode` (`disabled` | `service` | `full`); test all three modes if your driver routes queries differently.
