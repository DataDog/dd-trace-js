{{scaffold_repo_guidance}}

## Type Annotations (REQUIRED)

All code must compile cleanly with `./gradlew spotlessCheck` and pass the project's static analysis. Add full type declarations to every method — both parameters and return types. Never leave a method without explicit type annotations. Use the most specific types available; avoid raw types and unchecked casts.

## Java Analysis Facts

Read the final analysis artifact before choosing module paths, muzzle ranges, ByteBuddy matchers, or instrumentation package names. If it includes verified Java-specific facts under `analysis_guidance.language_specific.java` or an instrumentation target's `language_specific.java`, use those values as the source of truth unless the repository source proves they are wrong. Empty Java-specific fields mean the fact was not verified during analysis; resolve those from repository patterns rather than inventing them.

For each instrumentation target, use verified `language_specific.java` method facts such as `parameters`, `return_type`, `jvm_descriptor`, `is_static`, and `is_abstract` to write ByteBuddy matchers and `@Advice` signatures. Do not use `@Advice.This` for static methods.
