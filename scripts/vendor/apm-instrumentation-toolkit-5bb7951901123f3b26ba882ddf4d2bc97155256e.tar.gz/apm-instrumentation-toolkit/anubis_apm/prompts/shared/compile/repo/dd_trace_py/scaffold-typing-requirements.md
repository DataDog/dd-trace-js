## Type Annotations

Ensure all registration code and any `__init__.py` exports are properly typed.
