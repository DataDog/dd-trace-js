# Register Integration: {{integration_name}}

**Package:** {{package_name}} (import: {{import_name}}) — **version: {{package_version}}**
**Category:** {{category}}
**LLM integration:** {{is_llm}}

## Task

Register this integration in all required configuration files.

Read the **apm-integrations** skill — specifically the **Implementation Guide** — for the exact files to modify and the registration steps. Follow the implementation workflow steps for registration.

If this is an LLM integration (`is_llm: True`), also read the **llmobs-integrations** skill for LLMObs-specific registration steps (integration class, `__init__.py` exports, suitespec entries).

Use the variables above to determine:
- The correct integration name, package name, and import name
- Version ranges for registry and configuration entries
- Whether this is an LLM integration (determines which registration steps apply)
- Alphabetical placement in each file

{{include_repo:scaffold-typing-requirements,excluded_repos=dd_trace_js}}

After completing all registration tasks, verify with `git diff` that all expected files were modified.
