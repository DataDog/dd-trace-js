# Write Integration Code: {{integration_name}}

**Package:** {{package_name}} (import: {{import_name}}) — **version: {{package_version}}**
**Category:** {{category}}
**LLM integration:** {{is_llm}}

> **Version constraint:** Write instrumentation that targets `{{package_name}}@{{package_version}}`.
> Do not use APIs introduced in a newer release — the test suite runs against this version.

## Task

Write all integration code for this integration. Your acceptance criteria are the **test files created in the previous step** — read them first to understand exactly what the tests expect.

Read the **apm-integrations** skill for:
- The correct pattern to use for your category (see **Reference Integrations**)
- Step-by-step file creation (see **Implementation Guide**)
- Common mistakes to avoid (see **Anti-Patterns**)

If this is an LLM integration (`is_llm: True`), also read the **llmobs-integrations** skill for:
- Two-layer architecture (patch layer + integration layer)
- `BaseLLMIntegration` subclass implementation
- Message extraction, token counting, and streaming patterns
- Tool call handling

Use the variables above to determine:
- Whether to use the standard or LLM integration pattern
- Span types and kinds based on category

## Process

1. **Read the test files** to understand expectations
2. **Read the analysis artifact** for instrumentation targets and context mappings
3. **Study the canonical reference integration** for your category from the skill
4. **Write the code** following the patterns from the reference
5. **Verify** with `git diff --stat` that all expected files were created

{{include_repo:typing-requirements,excluded_repos=dd_trace_js}}

After completing all tasks, the test scaffold from the previous step should at minimum import without errors.
