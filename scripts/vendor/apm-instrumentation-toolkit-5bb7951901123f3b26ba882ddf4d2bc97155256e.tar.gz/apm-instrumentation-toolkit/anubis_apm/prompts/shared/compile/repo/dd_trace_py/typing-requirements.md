## Type Annotations (REQUIRED)

All code must pass `hatch run lint:typing` (mypy). Add full type annotations to every function and method — both parameters and return types. Read the **apm-integrations** skill's "Type Annotations" section for required patterns and signatures. Never leave a function without type annotations.
