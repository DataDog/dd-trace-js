{{scaffold_repo_guidance}}

## Type Annotations

Ensure all registration code, `InstrumentationModule` implementations, and any public API classes are properly typed. Avoid raw types in generic type parameters.

## Java Analysis Facts

Read the final analysis artifact before choosing the instrumentation module path, `settings.gradle.kts` entry, build dependency, or muzzle range. If verified Java-specific facts are present in the analysis, prefer them over guessing from the integration name. Empty Java-specific fields mean the fact was not verified during analysis; resolve those from repository patterns rather than inventing them.

For each instrumentation target, use verified `language_specific.java` method facts such as `parameters`, `return_type`, `jvm_descriptor`, `is_static`, and `is_abstract` to write ByteBuddy matchers and `@Advice` signatures. Do not use `@Advice.This` for static methods.
