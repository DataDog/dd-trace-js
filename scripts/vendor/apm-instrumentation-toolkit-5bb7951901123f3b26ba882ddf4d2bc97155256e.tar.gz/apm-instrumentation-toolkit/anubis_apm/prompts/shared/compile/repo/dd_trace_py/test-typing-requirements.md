## Type Annotations

Add type annotations to all test helper functions, fixtures, and utility functions. Test files must also pass `hatch run lint:typing`.
