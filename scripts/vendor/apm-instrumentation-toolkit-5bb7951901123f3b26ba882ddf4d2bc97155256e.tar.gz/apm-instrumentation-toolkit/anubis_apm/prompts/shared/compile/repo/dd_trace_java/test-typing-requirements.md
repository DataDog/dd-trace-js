{{scaffold_repo_guidance}}

## Type Annotations

Add type annotations to all test helper methods, fixtures, and utility functions. Test files must also compile cleanly and pass Spotless formatting checks.
