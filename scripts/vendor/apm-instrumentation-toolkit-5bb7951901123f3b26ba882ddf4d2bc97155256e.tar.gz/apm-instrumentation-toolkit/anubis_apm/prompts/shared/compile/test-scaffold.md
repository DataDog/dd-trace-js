# Create Test Scaffold: {{integration_name}}

**Package:** {{package_name}} (import: {{import_name}}) — **version: {{package_version}}**
**Category:** {{category}}
**LLM integration:** {{is_llm}}

> **Version constraint:** Write tests that target `{{package_name}}@{{package_version}}`.
> Do not assume APIs introduced in a newer release — the test suite runs against this version.

## Task

Create test files for this integration. These tests should be **runnable but failing** — they define the acceptance criteria for the integration code that will be written next.

Read the **apm-integrations** skill — specifically the **Implementation Guide** section on writing tests and the **Reference Integrations** for your category — to determine the test file structure, patterns, and assertions to use.

If this is an LLM integration (`is_llm: True`), also read the **llmobs-integrations** skill — specifically the **Testing Guide** — for LLMObs test patterns, VCR cassette setup, and `_expected_llmobs_llm_span_event()` usage.

Use the variables above to determine:
- The correct integration name, package name, and import name
- Whether this is an LLM integration (determines which test patterns to use)
- Test file locations and class names

{{include_repo:test-typing-requirements,excluded_repos=dd_trace_js}}

After completing all tasks, verify with `git diff --stat` that all expected test files were created.
