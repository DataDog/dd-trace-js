### Python Convention Fixes

- Follow PEP 8 style, imports at top
- **Full type annotations on every function** — parameters and return types. `hatch run lint:typing` (mypy) must pass. Use `Optional[X]` for nullable values, `dict[str, Any]` / `list[str]` for containers, `Callable[..., Any]` for function parameters. No bare `dict`, `list`, or `tuple` as type annotations
- Minimize comments -- no verbose explanations restating the obvious

### Event-Driven Architecture

- **Standard integrations**: `patch.py` wraps functions and emits events -- no direct span creation, no `span.finish()`. Use `context_with_data()` or `context_with_event()` to emit events; spans are created by handlers/subscribers (see `ddtrace/contrib/internal/kafka/patch.py`)
- **LLM integrations**: `patch.py` creates spans directly via `integration.trace()` and manages the span lifecycle: `span.set_exc_info()` on errors, `integration.llmobs_set_tags()` + `span.finish()` in the finally block, `BaseStreamHandler` for streaming (see `ddtrace/contrib/internal/anthropic/patch.py`)

### Test Fixes

- Use pytest fixtures -- reusable, not verbose inline setup
- **Never add `pytest.mark.skip`** -- implement the test or report the blocker
- **Never replace test bodies with `pass`** -- tests must have assertions
- LLM tests MUST use actual LLM calls (via VCR cassettes) -- limit mocking as much as possible
- LLMObs tests MUST use `_expected_llmobs_llm_span_event` (see `tests/contrib/anthropic/test_anthropic_llmobs.py`)
- APM tests should prefer snapshot testing (see `tests/contrib/psycopg/test_psycopg_snapshot.py`)
