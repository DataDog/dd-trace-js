### Debug Logging
- Remove `console.log`, `console.error`, `console.debug` calls entirely

### Convention Fixes
- Use `static x = y` not `static get x() { return y }`
- Check TracingPlugin methods before overriding (end, asyncEnd, error, finish)
- Match existing codebase patterns exactly

### CRITICAL: Channel Pattern (if shimmer instrumentation exists)
- **Start/AsyncStart channels MUST use `runStores()`, NEVER `publish()`**
- Using `publish()` for start events breaks async context propagation!
- Read skill `channels-runstores-vs-publish` for the correct pattern
- Error channels can use `publish()` (just notification)
- End/AsyncEnd channels use `publish()` (just notification, no store propagation needed)

### Test Fixes
- Replace setTimeout with sinon fake timers
