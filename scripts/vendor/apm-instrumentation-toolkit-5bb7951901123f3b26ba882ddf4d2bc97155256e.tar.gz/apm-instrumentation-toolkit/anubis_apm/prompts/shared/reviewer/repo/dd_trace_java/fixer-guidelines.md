### Debug Logging
- Remove `System.out.println`, `System.err.println`, and any debug print statements entirely

### Convention Fixes
- Use standard ByteBuddy `@Advice` annotations correctly (`@Advice.OnMethodEnter`, `@Advice.OnMethodExit`)
- Advice classes must be `public static` inner classes of the instrumentation class
- Match existing codebase patterns for `CallDepthThreadLocalMap` and span lifecycle

### CRITICAL: Advice Pattern
- **`@Advice.OnMethodEnter` must return the span/context as `@Advice.Enter`**
- **`@Advice.OnMethodExit` must receive the enter value and close spans**
- Never leak spans — always close in `@Advice.OnMethodExit` with `suppressThrowable = Throwable.class`

### Test Fixes
- Use Groovy Spock `where:` blocks for parameterized tests
- Prefer `@Shared` fields for expensive setup objects
