# Context-to-Tag Mapping Task

You are mapping semantic APM tags to runtime context paths for instrumentation.

## General Details

- **Mappings are for the {{language}} language and data access should be compatible for that langauge.**

## Operation Details

- **Method**: {{method}}
- **Operation**: {{operation}}
- **SpanKind**: {{span_kind}}
- **Instrumentation Index**: {{instrumentation_index}}

## Required Tags (MUST map ALL of these)

{{required_tags}}

## Optional Tags (map ONLY if data is available in context)

{{optional_tags}}

## Available Runtime Context

Full runtime context captured during execution is saved at: `{{context_snapshot_file}}`

Read this file to see all accessible data. You can map to any properties found there using paths like:
- `this.propertyName` - Access property on `this` object
- `args[0].field` - Access property on first argument
- `result.value` - Access property on return value

## Your Task

Map ONLY the tags listed above to context paths or literal values.

**CRITICAL RULES:**
1. **DO NOT add any custom tags** - Only map the tags explicitly listed above
2. **DO NOT create library-specific tags** (e.g., no bullmq.*, redis.*, kafka.*, etc.)
3. Map ALL required tags - they are mandatory for semantic conventions compliance
4. Map optional tags ONLY if the data exists in the runtime context
5. Use `null` for tags that cannot be mapped from available context
6. Use `'component': 'library name'` for the component tag

## Context Path Syntax

- `this.propertyName` - Access property on `this` object
- `args[0].propertyName` - Access property on first argument
- `returnValue.id` - Access property on return value (if available)
- `'literal'` - Use a literal string value (e.g., `'bullmq'`, `'produce'`)

## Mapping Examples

- messaging.system = `'bullmq'` (literal library name)
- messaging.destination.name = `this.name` (queue name from instance)
- messaging.operation = `'{{operation}}'` (literal operation name)
- span.kind = `'{{span_kind}}'` (literal span_kind: producer/consumer)
- messaging.message.id = `args[0].id` (message ID from argument)
- resource.name = `args[0].name` (job/message name)

## Tags Section Guidance

The `tags` dict should include tags that are CRITICAL for this specific operation.
Each tag should have a value that is one of:

- **Literal constant**: `"'producer'"` - A hardcoded string value (wrapped in single quotes)
- **Context path**: `"this.name"` - Extract from runtime context (same as mappings)
- **Type matcher - String**: `"__EXPECT_STRING_MATCHING__"` - Required tag, expect any string value
- **Type matcher - Number**: `"__EXPECT_NUMBER_MATCHING__"` - Required tag, expect any numeric value
- **Type matcher - Any**: `"__EXPECT_VALUE_MATCHING__"` - Required tag, expect any value
- **null**: Tag is not applicable or truly optional for this operation

## Output

Your output must conform to the schema appended below. Provide your mappings as structured JSON output.
