# Context Propagation Instrumentation

Context-propagation integrations cover libraries that coordinate async, reactive, or threaded work without performing I/O of their own. They shuttle callbacks, observers, runnables, futures, or messages across thread / scheduler / callback boundaries. This is fundamentally different from other categories — it does NOT create spans.

## What Context Propagation Instrumentation Does

Bridge the active trace context across an async boundary so that spans created inside a deferred callback / scheduled task / actor message are correctly parented to the span that was active when the boundary was constructed.

Without the instrumentation, work that runs on a pool thread / scheduler / later tick loses the active context — any span it creates becomes a root span or attaches to a leftover context from a previous request. Traces become orphaned or corrupted.

## When to Use This Category

The library:

- Returns or accepts a "deferred" type (Observable, Flowable, Single, Mono, Flux, Future, CompletionStage, Promise, ZIO effect)
- Schedules user-supplied work onto pool threads, event loops, schedulers, or fibers
- Dispatches messages or events to handlers on threads other than the caller's
- Accepts a user callback / lambda that may run on a different thread or at a later time
- Performs no I/O itself — only orchestrates work that other code performs

## What to Instrument

### Boundary Construction (Critical)
The point where a deferred / async object is created. Capture the currently-active trace context here.

### Boundary Subscribe / Invoke (Critical)
The point where the user-supplied callback is registered with the library. Restore the captured context around the callback, typically by wrapping the callback argument in a tracing decorator that re-attaches context before each of its methods runs.

For a reactive library, cover every reactive type separately (e.g. Observable, Flowable, Single, Maybe, Completable → five separate instrumentations). For an executor-family library, cover each executor-like surface (e.g. Runnable, Callable, ForkJoinTask).

## What NOT to Do

### No Span Creation
Context-propagation instrumentation does NOT create spans. No operation names, no span kinds, no span tags. If you find yourself reaching for a span-start API in a context-propagation integration, stop — you're in the wrong category.

### Skip These
- Builder / fluent-DSL methods that compose operators without subscribing — no boundary crossing if no handler ever runs
- Internal scheduling / queue implementation details — the capture/restore pair at construct + subscribe is sufficient
- Blocking methods that execute synchronously on the calling thread — no boundary to cross

## Testing

Assert **parent-child bridging of user-created spans**, not span tags on target methods (there are no such spans). The canonical pattern:

1. Open a parent span
2. Inside that span, construct the deferred / async object and subscribe with a callback
3. Have the callback create a child span
4. Assert the child span is correctly parented to the outer parent span, even if the callback ran on a different thread

Also test error and cancel paths — the wrapper must bridge context on error and completion callbacks too.
