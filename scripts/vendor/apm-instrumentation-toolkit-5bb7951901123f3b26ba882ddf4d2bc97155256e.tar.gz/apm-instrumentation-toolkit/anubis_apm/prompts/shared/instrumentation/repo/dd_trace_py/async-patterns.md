# Python Async Patterns

When analyzing Python libraries, classify each method's async pattern to choose the correct instrumentation wrapper.

## Pattern Types

| Pattern | Signature | Wrapper |
|---------|-----------|---------|
| `sync` | `def method(self, ...)` | Standard `wrap_function_wrapper` |
| `async` | `async def method(self, ...)` | Async-aware wrapper with `await` |
| `generator` | `def method(self, ...): yield ...` | Generator-aware wrapper |
| `async_generator` | `async def method(self, ...): yield ...` | Async generator wrapper |

## How to Identify

1. Check for `async def` -- indicates `async` or `async_generator`
2. Check for `yield` in body -- indicates generator variant
3. Check return type hints -- `AsyncIterator`, `Generator`, `Coroutine`

## Reference Integrations

| Pattern | Reference |
|---------|-----------|
| Sync wrapping | `ddtrace/contrib/internal/redis/patch.py` |
| Async wrapping | `ddtrace/contrib/internal/asyncpg/patch.py` |
| Mixed sync/async | `ddtrace/contrib/internal/psycopg/patch.py` (sync) + `psycopg/async_cursor.py` (async) |

## Gotchas

- Libraries with both sync and async clients need separate wrappers for each
- Use `wrapt.wrap_function_wrapper()` for sync, async-compatible variant for async
- Some libraries use sync APIs that internally do async -- check the actual I/O path
