# Java Source Code Analysis

Guide for identifying instrumentation targets in Java libraries for dd-trace-java.

## When Source Code Is Not Available Locally

dd-trace-java instruments library JARs at runtime — you often won't have the source checked out.
**Use GitHub to navigate the library source directly:**

1. Search for the library on GitHub: `github.com/{org}/{repo}`
2. Use GitHub's file search (`t` key) or code search (`/`) to jump to classes by name
3. Browse the tag matching the version being instrumented

## Instrumentation Pattern

dd-trace-java uses **ByteBuddy advice** — it injects tracing at the bytecode level by matching a type and method, then wrapping with `@Advice.OnMethodEnter` / `@Advice.OnMethodExit`.

ByteBuddy can match:
- `named("com.example.ConcreteClass")` — a specific class
- `implementsInterface(named("com.example.SomeInterface"))` — any class implementing the interface
- `extendsClass(named("com.example.AbstractBase"))` — any class extending the abstract base

**Interfaces and abstract classes are valid instrumentation targets.** When ByteBuddy targets an interface, it applies advice to ALL classes that implement it.

## Choosing the Right Abstraction Level

**Default: instrument the API contract type (interface or abstract class)** when the user's code references that type. Use the **concrete class** when users instantiate and call it directly (e.g., `new FooClient(config)` — the concrete class IS the API).

**Key test:** look at the type the user **declares** in their code. That is almost always the correct instrumentation target.

## Minimal Target Set

Each instrumentation module in dd-trace-java hooks **1–4 methods** total. Pick only the methods that produce distinct spans or perform distinct operations:

- **One method per operation type** — don't list every overload of the same method. If `execute(Request)` and `execute(Host, Request)` do the same thing, pick one.
- **Use wildcards** when multiple method variants share the same tracing semantics: `execute*` instead of enumerating `executeQuery`, `executeUpdate`, `executeBatch`.
- **Skip lifecycle methods** (constructors, close, shutdown) unless they are the actual instrumentation point (e.g., constructor hooks for interceptor injection).

## Fully-Qualified Class Names

Always use the **fully-qualified class name** as it appears in the library's source. Unqualified names are ambiguous and will not match ByteBuddy type matchers.

For inner classes, use `$` notation: `com.example.Outer$Inner`.

## Verify Against Existing Patterns

Cross-reference with existing instrumentations in `dd-java-agent/instrumentation/`:

- `typeMatcher()` tells you the **type** being instrumented (interface, abstract class, or concrete)
- `methodMatcher()` tells you the **method** (and whether to use wildcards via `nameStartsWith`)

## Java-Specific Structured Facts

When the output schema includes `language_specific.java`, fill only facts you can verify from Maven coordinates, bytecode/source, or an existing dd-java-agent module. Leave fields empty rather than guessing.

Useful package-level facts are Maven coordinates, the dd-java-agent instrumentation module path, Gradle project path, minimum supported version, muzzle directives, and reference modules. For per-target facts, include the declaring type and ByteBuddy matcher snippets only when they are source-backed or copied from a matching existing module.

Do not invent advice class names, helper classes, context stores, span lifecycle descriptions, or propagation details just to fill structure. Put uncertain implementation considerations in `implementation_notes` or `special_considerations` instead.

When `all-methods.json` is available, use its verified Java fields (`declaring_type`, `declaring_type_kind`, `parameters`, `return_type`, `jvm_descriptor`, `is_static`, `is_abstract`) to choose ByteBuddy matchers and later advice signatures. These fields describe what `@Advice.This`, `@Advice.Argument`, `@Advice.Return`, and `@Advice.Thrown` can safely reference.
