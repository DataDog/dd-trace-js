# Analysis Process

## Step 1: Classify the Package

Determine category from library purpose:
- `database`, `messaging`, `cache`, `http-server`, `http-client`
- `cloud-provider`, `object-store`, `graphql`, `rpc`
- `generative-ai`, `logging`, `faas`, `orchestration`, `context-propagation`
- `not_applicable` if none apply

## Step 2: Extract API Surface

Identify from docs and examples:
- Main classes/objects
- I/O methods
- Async patterns (promise, callback, handler registration)

## Step 3: Find Instrumentation Targets

**Critical rule for callbacks/handlers:**
Instrument WHERE the callback is **invoked**, not where it's **registered**.

```
WRONG:  worker.process(handler)     // Just stores the handler
RIGHT:  Internal processJob() call  // Actually invokes handler per-job
```

To find the invocation point:
1. Find where handler is stored: `this.processFn = handler`
2. Search for invocation: `await this.processFn(job)`

**Priority levels:**
- **Critical**: Core I/O operations (1-2 per integration)
- **Important**: Batch variants, connection lifecycle
- **Optional**: Admin operations (usually skip)

## Step 4: Context Propagation

- **Producers/clients**: Inject into outgoing headers/attributes
- **Consumers/servers**: Extract from incoming headers/attributes

## Step 5: Determine Span Kind

Match by semantic meaning, not method name:
- Sends data outbound → `producer`
- Receives/processes inbound data → `consumer`
- Query/response pattern → `client`
- Handles incoming requests → `server`
