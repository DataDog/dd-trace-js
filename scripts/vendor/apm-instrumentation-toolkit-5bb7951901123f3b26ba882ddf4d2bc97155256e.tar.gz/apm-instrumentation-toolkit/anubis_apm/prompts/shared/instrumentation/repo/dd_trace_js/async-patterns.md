# JavaScript Async Patterns

When analyzing JavaScript/Node.js libraries, identify the async pattern used by each method to determine the correct instrumentation approach.

## Pattern Classification

### Promise Pattern (`promise`)
Methods that return a Promise, including async/await functions.

```javascript
// Explicit Promise return
function query(sql) {
  return new Promise((resolve, reject) => { ... })
}

// Async function (implicitly returns Promise)
async function query(sql) {
  const result = await db.execute(sql)
  return result
}

// Usage
await queue.add(jobData)
client.send(message).then(result => ...)
```

**Characteristics:**
- Returns a Promise object
- Can be awaited
- Has `.then()` / `.catch()` methods

### Callback Pattern (`callback`)
Methods where the last parameter is a callback function invoked on completion.

```javascript
// Node.js style callback
function readFile(path, callback) {
  fs.readFile(path, (err, data) => {
    if (err) callback(err)
    else callback(null, data)
  })
}

// Usage
db.query('SELECT * FROM users', (err, rows) => {
  if (err) throw err
  console.log(rows)
})
```

**Characteristics:**
- Last argument is a function
- Callback receives `(error, result)` or similar
- Method returns immediately, callback fires later

### Async Iterator Pattern (`async_iterator`)
Methods that return async generators (async iterators) for streaming results.

```javascript
// Async generator function
async function* stream(query) {
  for await (const chunk of this.executeStream(query)) {
    yield chunk
  }
}

// Or method returning AsyncIterator
async *stream() {
  const iterator = this.processItems()
  for await (const item of iterator) {
    yield item
  }
}

// Usage
for await (const chunk of client.stream(query)) {
  console.log(chunk)
}
```

**Characteristics:**
- Returns an async iterator (object with `Symbol.asyncIterator`)
- Uses `async function*` syntax or returns AsyncIterableIterator
- Results are yielded incrementally via `yield`
- Consumed with `for await...of` loops

**When to use:** Methods like `stream()`, `streamEvents()`, or any method that returns chunks/events over time using async iteration.

**Important:** If a method returns `Promise<AsyncIterable>` or `Promise<IterableReadableStream>`, classify it as `async_iterator` (not `promise`) because the Promise resolves to a stream that yields chunks. Example:
```typescript
// This should be classified as async_iterator, not promise
async stream(): Promise<IterableReadableStream<T>>

// Usage shows it's consumed as async iterator
const stream = await obj.stream()
for await (const chunk of stream) { ... }
```

**Orchestrion support:** Use `kind: 'AsyncIterator'` in Orchestrion config for proper async generator instrumentation.

### Sync Pattern (`sync`)
Methods that execute synchronously and return the result directly.

```javascript
// Synchronous execution
function parseJSON(str) {
  return JSON.parse(str)
}

// Usage
const config = cache.getSync(key)
const result = parser.parse(input)
```

**Characteristics:**
- Returns result directly (not a Promise)
- No callback parameter
- Blocks until complete

## Determining the Pattern

**CRITICAL:** Check what the Promise resolves to BEFORE classifying as `promise`!
- If you see `Promise<IterableReadableStream>`, `Promise<AsyncIterable>`, or `Promise<AsyncIterableIterator>` → classify as `async_iterator` (NOT promise)
- The Promise wrapper doesn't determine the pattern - what it resolves to does!

1. **Check documentation** - Often explicitly states Promise-based, callback-based, or streaming
2. **Look at return type - CHECK PROMISE CONTENTS FIRST**:
   - `Promise<AsyncIterable<T>>`, `Promise<IterableReadableStream<T>>`, `Promise<AsyncIterableIterator<T>>` → `async_iterator` (Promise resolves to stream)
   - `AsyncIterableIterator<T>`, `AsyncIterable<T>`, `IterableReadableStream<T>` → `async_iterator`
   - `Promise<T>` (where T is not async iterable) → `promise`
3. **Check method name** - Methods named `stream()`, `streamEvents()`, `*Events()` often return async iterators
4. **Look for `async function*`** - Async generator syntax indicates async iterator pattern
5. **Check last parameter** - Named `callback`, `cb`, `done`, `next` suggests callback
6. **Read source code** - Look for `return new Promise`, `async function*`, `yield`, or callback invocation
7. **Check TypeScript definitions** - `.d.ts` files show return types clearly (e.g., `AsyncGenerator<T>`, `AsyncIterable<T>`)

## Mixed Patterns

Some libraries support multiple patterns:

```javascript
// Supports both callback and promise
function query(sql, callback) {
  if (callback) {
    // Callback mode
    execute(sql, callback)
  } else {
    // Promise mode
    return new Promise((resolve, reject) => {
      execute(sql, (err, result) => {
        if (err) reject(err)
        else resolve(result)
      })
    })
  }
}
```

For mixed patterns, instrument the shared entry point (or both modes) rather than only one variant. The instrumentation should detect whether a callback is provided and handle completion accordingly:
- If callback is present: wrap the callback to finish the span on invocation
- If no callback: wrap the returned Promise to finish the span on resolution/rejection

This ensures callback-based usage remains traced even when the library also supports promises.

## Event Emitter Patterns

Some operations use EventEmitter instead of callbacks/promises:

```javascript
const stream = db.query('SELECT * FROM large_table')
stream.on('data', row => console.log(row))
stream.on('end', () => console.log('done'))
stream.on('error', err => console.error(err))
```

These require special handling - typically instrument the method that creates the emitter and listen for completion events.
