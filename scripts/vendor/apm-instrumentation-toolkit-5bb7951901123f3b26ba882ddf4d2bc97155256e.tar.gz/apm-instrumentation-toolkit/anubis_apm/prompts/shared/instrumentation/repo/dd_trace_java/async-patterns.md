# Java Async Patterns

When analyzing Java libraries, identify whether methods are synchronous or asynchronous to determine the correct ByteBuddy instrumentation approach.

## Pattern Classification

### Synchronous (`sync`)
Methods that execute on the calling thread and return a result directly. The most common pattern in Java instrumentations.

```java
// Synchronous database query
ResultSet query(String sql) throws SQLException { ... }

// Synchronous HTTP call
Response execute(Request request) throws IOException { ... }
```

**Characteristics:**
- Returns a concrete result type (not a Future)
- May throw checked exceptions
- Blocks the calling thread until complete

### CompletableFuture (`async`)
Methods returning `CompletableFuture<T>` or `Future<T>` that complete asynchronously.

```java
CompletableFuture<Response> sendAsync(Request request) { ... }

Future<ResultSet> queryAsync(String sql) { ... }
```

**Characteristics:**
- Return type is `CompletableFuture<T>`, `Future<T>`, or similar
- Non-blocking — result delivered via callback or `.get()`
- Span should be finished when the Future completes, not when the method returns

### Reactive (`reactive`)
Methods returning reactive types (`Mono<T>`, `Flux<T>`, `Observable<T>`, `Single<T>`) from Project Reactor or RxJava.

```java
Mono<Response> get(String url) { ... }

Flux<Row> query(String sql) { ... }
```

**Characteristics:**
- Return type is a reactive publisher
- Lazy — execution starts on subscription
- Span lifecycle tied to publisher completion/error/cancellation

## ByteBuddy Instrumentation Guidance

- **Synchronous methods**: wrap with `@Advice.OnMethodEnter` / `@Advice.OnMethodExit` — span starts at enter, finishes at exit
- **CompletableFuture**: finish span in a completion handler attached inside the advice
- **Reactive**: delegate to the tracer's reactive propagation utilities; do not finish the span at method exit
