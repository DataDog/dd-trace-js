# Python Source Code Analysis

Guide for identifying instrumentation targets in Python packages.

## Step-by-Step

1. **Find the entry point** -- read `setup.py` or `pyproject.toml` for the main package module, then read `__init__.py` for exports
2. **Identify public API** -- look for `__all__`, direct class imports, or lazy `__getattr__` patterns
3. **Trace execution paths** -- follow user calls through the library to find where I/O happens
4. **Choose instrumentation points** -- decide between public API (stable) vs internal method (richer context)
5. **Check for inheritance** -- find base classes and which subclass performs actual I/O
6. **Verify with static analysis** -- cross-reference against `all-methods.json` if available

## Decision: Where to Instrument

- Need operation timing? Instrument the **public API method**
- Need query text, message payload, connection info? Find the **internal method** where that context is available
- Fragility concern? Prefer public API -- internal methods change between library versions

## Useful Search Patterns

```bash
grep -rn "class.*:" src/          # Class definitions
grep -rn "async def" src/          # Async methods
grep -rn "def __aenter__" src/     # Context managers
grep -rn "yield " src/             # Generators
```

## Reference

See `ddtrace/contrib/internal/kafka/patch.py` for how instrumentation targets map from library API to wrapped methods. See `ddtrace/contrib/internal/psycopg/patch.py` for a database library with multiple instrumentation points (connection + cursor).
