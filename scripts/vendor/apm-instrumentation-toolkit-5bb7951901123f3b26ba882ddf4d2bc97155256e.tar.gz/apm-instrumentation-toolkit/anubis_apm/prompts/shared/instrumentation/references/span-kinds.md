# Span Kinds

Span kinds indicate a span's role in distributed tracing.

## Definitions

| Kind | Role | Context | Examples |
|------|------|---------|----------|
| `producer` | Sends data outbound | Inject context | Queue send, topic publish |
| `consumer` | Receives data inbound | Extract context | Message handler, job processor |
| `client` | Request/response | Inject or inherit | DB query, HTTP request, cache op |
| `server` | Handles requests | Extract context | HTTP handler, RPC server |

## Category Mapping

| Category | Valid Kinds |
|----------|-------------|
| `database` | `client` |
| `messaging` | `producer`, `consumer` |
| `http-server` | `server` |
| `http-client` | `client` |
| `cache` | `client` |
| `cloud-provider` | `client` |
| `graphql` | `server`, `client` |
| `rpc` | `server`, `client` |
| `generative-ai` | `client` |
| `faas` | `server` |

## Common Mistakes

**HTTP client ≠ producer**
HTTP clients use `client` (bidirectional request/response), not `producer` (fire-and-forget).

**Database ≠ producer**
Database operations are query/response patterns → `client`.
