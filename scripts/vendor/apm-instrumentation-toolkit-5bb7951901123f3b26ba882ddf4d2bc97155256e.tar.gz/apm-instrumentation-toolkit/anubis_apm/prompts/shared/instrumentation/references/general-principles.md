# General Principles

## What to Trace

**Trace I/O and boundary-crossing operations:**
- Network requests (HTTP, database, messaging)
- Process/service boundary crossings
- Async work representing meaningful business logic

**For stateful protocols, consider lifecycle:**
- Connection establishment
- Core operations
- Connection termination

## What to Skip

- Connection pool internals
- Configuration/setup functions
- Synchronous helpers
- Internal bookkeeping

## Context Propagation

Identify where trace context should be:
- **Injected** - outgoing messages/requests
- **Extracted** - incoming messages/requests

## Guiding Principles

1. **Be conservative** - When in doubt, instrument less
2. **Trace real operations** - Base decisions on actual code paths, not just API surface
3. **Consider overhead** - Skip high-frequency, low-value operations
4. **Batch appropriately** - One span per batch, not per item
