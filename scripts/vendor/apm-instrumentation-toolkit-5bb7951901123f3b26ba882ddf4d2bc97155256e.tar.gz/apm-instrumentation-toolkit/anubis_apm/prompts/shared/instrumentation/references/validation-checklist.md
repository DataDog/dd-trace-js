# Validation Checklist

## For Each Target

1. **Is this the ACTUAL operation?**
   - ✅ Where real work happens (I/O, processing)
   - ❌ Callback registration that returns immediately

2. **Does span duration reflect real time?**
   - ✅ Completes when operation completes
   - ❌ Returns before work finishes

3. **Are we tracing where work happens?**
   - Job processors: trace per-job execution, not `process()` registration
   - Consumers: trace handler invocation, not subscription
   - Servers: trace request handling, not route registration

## Category Requirements

| Category | Must Trace |
|----------|------------|
| Database | Query/execute method |
| Messaging | Send (producer) AND receive (consumer) |
| HTTP Server | Internal request handler |
| HTTP Client | Request execution |
| Cache | Get/set operations |
| Job Queue | Enqueue AND per-job execution |

## Red Flags

Stop if:
- Only instrumenting callback **registration** (need invocation)
- Span ends before work completes
- Missing half the workflow (messaging needs both directions)
- Can't extract meaningful context

## Pre-Analysis Check

- Did you classify the package into a category FIRST?
- If `not_applicable`, did you conclude the package is not applicable for APM instrumentation instead of forcing targets?
- If a category matched, did you READ the category-specific reference file before identifying targets?
- Are your targets aligned with what the category guide says to trace?

## Final Check

- Does span duration accurately reflect operation time?
- Would these traces help debug production issues?
- Does target method exist in source code?
