# JavaScript Source Code Analysis

Guide for exploring JavaScript/Node.js package source code to identify instrumentation targets.

## Step 1: Find the Entry Point

Start with `package.json` to find the main entry:

```json
{
  "main": "lib/index.js",
  "module": "dist/esm/index.js",
  "exports": {
    ".": {
      "require": "./lib/index.js",
      "import": "./dist/esm/index.js"
    }
  }
}
```

Read the main file to understand what's exported.

## Step 2: Understand the Export Structure

Common patterns:

```javascript
// Class export
module.exports = Client
module.exports = { Client, Producer, Consumer }

// Factory export
module.exports = function createClient(options) { ... }

// Instance export
module.exports = new Client()
```

Identify the primary classes/objects users interact with.

## Step 3: Trace Code Execution Paths

Follow how user calls flow through the library:

1. User calls `producer.send(message)`
2. What method handles this?
3. What internal functions get called?
4. Where is the actual I/O performed?

Use grep to find implementations:
```bash
grep -rn "prototype.send" src/
grep -rn "async.*send" src/
grep -rn "function send" src/
```

## Step 4: Choose Instrumentation Points

When tracing an operation, decide WHERE to instrument:

### Option A: Public API Method
- **Pros**: Easy to find, matches what user calls
- **Cons**: May not have all context, may be just a wrapper

### Option B: Internal Method
- **Pros**: Has richer context (job data, message payload, connection info)
- **Cons**: More fragile to library updates, harder to find

### Option C: Callback Invocation Site
- For patterns where users register handlers called later
- Captures each invocation with full context

**Decision Framework**: Ask "What trace data would be most valuable?"
- Need per-message context? → Find internal dispatch method
- Need overall operation timing? → Instrument public method
- Need job ID, message key, etc.? → Find where that context is available

## Step 5: Follow Handler/Callback Patterns

Many libraries store user callbacks for later invocation:

```javascript
// User code registers handler
consumer.run({ eachMessage: async (msg) => { ... } })

// Library stores it
this.eachMessage = options.eachMessage

// Library invokes it later (THIS is what to instrument)
await this.eachMessage(payload)
```

To find the invocation point:
1. Find where callback is stored: `this.handler = handler`
2. Search for invocation: `this.handler(`, `await this.handler`
3. That method is often the best instrumentation target

## Step 6: Verify Against Static Analysis

Use AST-parsed method lists (like `all-methods.json`) to:
- Confirm method exists at expected location
- Get accurate file paths and line numbers
- Validate method signatures

Note: Method names may differ due to aliasing/re-exports. If a method isn't in static analysis output, verify via source code.

## Common Pitfalls

### Don't Instrument Registration Methods
```javascript
// WRONG - This just stores the handler
worker.process(jobHandler)

// RIGHT - Find where jobHandler is actually called
```

### Don't Instrument Sync Wrappers
```javascript
// WRONG - This is just a wrapper
send(data) {
  return this._send(data)  // Delegates to internal
}

// Consider instrumenting _send() if it has more context
```

### Watch for Transpiled Code
- TypeScript → JavaScript paths may differ
- `dist/`, `lib/`, `build/` contain compiled output
- Source maps can help trace back to original

## ESM Support (Critical for dd-trace-js)

Many modern Node.js packages ship **both a CJS and an ESM implementation**. The `package.json` `exports` field is the authoritative source:

```json
{
  "exports": {
    ".": {
      "require": "./lib/index.js",
      "import": "./dist/esm/index.js"
    }
  }
}
```

**Rule: When a CJS method is selected as an instrumentation target AND a matching ESM implementation exists, BOTH file paths MUST be included in the `file_paths` field of the analysis output.**

### How to Check for ESM

1. **Read `package.json` exports** — Look for `"import"` / `"module"` keys alongside `"require"` / `"main"`.
2. **Locate the ESM entry** — If an `"import"` path exists (e.g., `./dist/esm/index.js`), navigate that tree.
3. **Find the matching method** — Search for the same method name in the ESM tree.
4. **If found** — Add the ESM file path (and line number if discoverable) to `file_paths` alongside the CJS path.

### Example

A target selecting `Producer.prototype.send` in `lib/producer.js` must also include `dist/esm/producer.js` if the same method is present there:

```json
{
  "method": "Producer.prototype.send",
  "file_paths": [
    "node_modules/kafkajs/src/producer/index.js",
    "node_modules/kafkajs/src/producer/esm/index.js"
  ]
}
```

If the package has no ESM export, or the ESM entry is merely a re-export wrapper with no distinct implementation, a single CJS path is sufficient. Do not fabricate ESM paths — only include paths that actually exist in the source.

## Useful Patterns to Search For

```bash
# Find prototype methods
grep -rn "prototype\." src/

# Find async methods
grep -rn "async " src/

# Find class methods
grep -rn "class.*{" -A 50 src/

# Find event emissions
grep -rn "emit\(" src/

# Find callback invocations
grep -rn "callback\(" src/
grep -rn "\.call\(" src/
```
