"""ExperienceRetriever — select which specific files from past runs to inject.

Two modes:
  rules (default): Match step names mechanically across runs.
  agent (optional): Lightweight haiku agent for semantic matching (~$0.01/call).

The retriever returns ExperiencePointer objects pointing at raw local files.
We never summarize past run content — agents read the raw files directly.
"""

import logging
from pathlib import Path
from typing import List, Literal

from anubis.core.experience.models import ExperiencePointer

logger = logging.getLogger(__name__)

_HIGH_VALUE_STEPS = {"analyze", "compile", "scaffold", "implement"}


class ExperienceRetriever:
    """Selects raw files from cached past runs for injection into agent prompts.

    Args:
        mode: "rules" (fast, no API call) or "agent" (semantic, uses haiku).
        max_pointers: Maximum number of file pointers to return.
    """

    def __init__(
        self,
        mode: Literal["rules", "agent"] = "rules",
        max_pointers: int = 8,
    ) -> None:
        self.mode = mode
        self.max_pointers = max_pointers

    def retrieve_for_step(
        self,
        current_step_name: str,
        cached_run_dirs: List[Path],
        run_manifests: List[dict],
    ) -> List[ExperiencePointer]:
        """Select relevant file pointers from cached runs for a given step.

        Args:
            current_step_name: Name of the step currently executing (e.g., "analyze").
                Pass empty string "" to retrieve all high-value steps (used at bootstrap
                time before a specific step is known).
            cached_run_dirs: Local paths to cached run directories.
            run_manifests: Manifest dicts (plain dicts from index.json, not RunManifest objects).

        Returns:
            List of ExperiencePointer objects pointing at raw local files.
        """
        if self.mode == "agent":
            return self._retrieve_agent(current_step_name, cached_run_dirs, run_manifests)
        return self._retrieve_rules(current_step_name, cached_run_dirs, run_manifests)

    def _retrieve_rules(
        self,
        current_step_name: str,
        cached_run_dirs: List[Path],
        run_manifests: List[dict],
    ) -> List[ExperiencePointer]:
        """Rule-based: match step names, prefer high-value steps."""
        pointers: List[ExperiencePointer] = []

        for run_dir, manifest in zip(cached_run_dirs, run_manifests):
            run_id = manifest.get("run_id", run_dir.name)
            integration = manifest.get("integration", "unknown")
            status = manifest.get("status", "completed")

            steps_dir = run_dir / "steps"
            if not steps_dir.exists():
                continue

            # Priority: same step name as current, then other high-value steps
            candidate_dirs = _sorted_step_dirs(steps_dir, current_step_name)

            for step_dir in candidate_dirs[: self.max_pointers]:
                step_name = step_dir.name.split("-")[0]
                output_path = step_dir / "output.json"
                if not output_path.exists():
                    continue

                relevance = _describe_pointer(step_name, current_step_name, status)
                pointers.append(
                    ExperiencePointer(
                        run_id=run_id,
                        integration=integration,
                        step_name=step_name,
                        local_path=str(output_path),
                        relevance=relevance,
                        status=status,
                    )
                )

            # Also add code reference pointer if available
            code_ref = manifest.get("code_ref")
            if code_ref and current_step_name in ("compile", "scaffold", "implement"):
                commit = code_ref.get("commit", "")
                if commit:
                    pointers.append(
                        ExperiencePointer(
                            run_id=run_id,
                            integration=integration,
                            step_name="code",
                            local_path=f"git show {commit}:<path>",
                            relevance=f"Generated code — use: git -C $DD_TRACER_REPO show {commit[:8]}:<file>",
                            status=status,
                        )
                    )

            if len(pointers) >= self.max_pointers:
                break

        return pointers[: self.max_pointers]

    def _retrieve_agent(
        self,
        current_step_name: str,
        cached_run_dirs: List[Path],
        run_manifests: List[dict],
    ) -> List[ExperiencePointer]:
        """Agent-based: use haiku to semantically select relevant files.

        Falls back to rule-based if agent invocation fails.
        """
        try:
            return self._retrieve_agent_impl(current_step_name, cached_run_dirs, run_manifests)
        except Exception as exc:
            logger.warning("Experience retrieval agent failed, falling back to rules: %s", exc)
            return self._retrieve_rules(current_step_name, cached_run_dirs, run_manifests)

    def _retrieve_agent_impl(
        self,
        current_step_name: str,
        cached_run_dirs: List[Path],
        run_manifests: List[dict],
    ) -> List[ExperiencePointer]:
        """Actual agent-based retrieval (haiku, max 5 turns)."""
        # TODO: implement lightweight haiku agent call once agent spawning
        # infrastructure is available here. For now, fall through to rules.
        logger.debug("Agent-based retrieval not yet implemented, using rules")
        return self._retrieve_rules(current_step_name, cached_run_dirs, run_manifests)


def _sorted_step_dirs(steps_dir: Path, current_step_name: str) -> List[Path]:
    """Return step directories sorted by relevance: same-name first, then high-value."""
    all_dirs = [d for d in steps_dir.iterdir() if d.is_dir()]

    def _priority(d: Path) -> int:
        name = d.name.split("-")[0]
        if name == current_step_name:
            return 0
        if name in _HIGH_VALUE_STEPS:
            return 1
        return 2

    return sorted(all_dirs, key=_priority)


def _describe_pointer(step_name: str, current_step_name: str, status: str) -> str:
    status_label = "successful" if status == "completed" else status
    if step_name == current_step_name:
        return f"{status_label} {step_name} output (same step type)"
    return f"{status_label} {step_name} output"
