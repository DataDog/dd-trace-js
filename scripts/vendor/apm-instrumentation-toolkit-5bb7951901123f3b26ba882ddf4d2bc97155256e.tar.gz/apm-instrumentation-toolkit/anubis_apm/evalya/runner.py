"""Evalya subprocess runner — shared across eval workflows.

Executes `evalya run` against a remote OCI task definition and parses behave
scenario results from the output.
"""

import logging
import os
import shutil
import signal
import subprocess
import time
import uuid
from pathlib import Path
from typing import Dict, Optional

from .constants import EVALYA_OCI_CONTEXT
from .helpers.parse import parse_scenarios
from .helpers.utils import find_free_port
from .models import EvalyaRunResult

logger = logging.getLogger(__name__)

_OUTPUT_TAIL_CHARS = 4000


def _output_tail(raw_output: str) -> str:
    """Return a bounded tail suitable for logs, spans, and result JSON."""
    return raw_output[-_OUTPUT_TAIL_CHARS:] if raw_output else ""


def run_evalya(
    def_path: str,
    task: str = "run",
    *,
    tracer_dir: Optional[Path] = None,
    timeout: int = 600,
    build: bool = False,
    extra_env: Optional[Dict[str, str]] = None,
    container_env: Optional[Dict[str, str]] = None,
) -> EvalyaRunResult:
    """Run evalya against a remote OCI task and parse scenario results.

    Args:
        def_path: Path within the OCI context (e.g. ``"defs/iat/node-pg"``).
        task: Task ID to run within the definition (default: ``"run"``).
        tracer_dir: Local tracer directory to inject via ``TRACER_DIR``.
        timeout: Subprocess timeout in seconds.
        build: Force rebuild Docker images (``--build`` flag).
        extra_env: Additional environment variables for manifest interpolation.
        container_env: Additional variables to pass into evalya tasks with ``--env``.

    Returns:
        :class:`EvalyaRunResult` with per-scenario pass/fail data.
    """
    evalya_bin = shutil.which("evalya")
    if not evalya_bin:
        return EvalyaRunResult(error="evalya not found on PATH")

    # Pick a free port + unique Docker network so parallel evalya runs don't
    # collide on the default :3774 or share Docker network state. Without
    # --network-name, parallel invocations on the same host hit container name
    # conflicts when defs share dependency images (e.g. bullmq+ioredis both
    # spin up a "redis" container).
    server_port = find_free_port()
    network_name = f"evalya-{uuid.uuid4().hex[:12]}"

    cmd = [
        evalya_bin,
        "run",
        "--context",
        EVALYA_OCI_CONTEXT,
        "--path",
        def_path,
        "--task",
        task,
        "--no-tui",
        f"--server-port={server_port}",
        f"--network-name={network_name}",
    ]
    if build:
        cmd.append("--build")
    if container_env:
        for key, value in sorted(container_env.items()):
            cmd.extend(["--env", f"{key}={value}"])

    env = os.environ.copy()
    # Force non-TTY behavior so evalya doesn't query the user's terminal for
    # DA / OSC 11 capabilities (escape responses leak into the parent shell
    # when stdin is the controlling tty).
    env["TERM"] = "dumb"
    env["NO_COLOR"] = "1"
    if tracer_dir:
        env["TRACER_DIR"] = str(tracer_dir)
        logger.info("Running evalya with TRACER_DIR=%s", tracer_dir)
    else:
        # Strip any inherited TRACER_DIR so evalya's optional overlay mounts
        # are skipped (precheck: verify baseline tracer only).
        env.pop("TRACER_DIR", None)
        logger.info("Running evalya without TRACER_DIR (baseline only)")
    if extra_env:
        env.update(extra_env)

    logger.info("Executing: %s", " ".join(cmd))
    start = time.monotonic()

    try:
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
            start_new_session=True,
        )
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            duration = time.monotonic() - start
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError as cleanup_error:
                logger.debug(
                    "evalya process group %s exited before SIGTERM: %s",
                    process.pid,
                    cleanup_error,
                )
            try:
                stdout, stderr = process.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError as cleanup_error:
                    logger.debug(
                        "evalya process group %s exited before SIGKILL: %s",
                        process.pid,
                        cleanup_error,
                    )
                stdout, stderr = process.communicate()
            raw_output = (stdout or "") + (stderr or "")
            return EvalyaRunResult(
                error=f"evalya timed out after {timeout}s",
                raw_output=raw_output,
                output_tail=_output_tail(raw_output),
                duration_s=duration,
                exit_code=process.returncode,
            )
    except subprocess.TimeoutExpired:
        duration = time.monotonic() - start
        return EvalyaRunResult(error=f"evalya timed out after {timeout}s", duration_s=duration)
    except Exception as e:
        duration = time.monotonic() - start
        return EvalyaRunResult(error=f"evalya failed to start: {e}", duration_s=duration)

    duration = time.monotonic() - start
    raw_output = (stdout or "") + (stderr or "")
    output_tail = _output_tail(raw_output)
    scenarios = parse_scenarios(raw_output)
    error = ""
    if process.returncode != 0:
        error = f"evalya exited with code {process.returncode}"
        if not scenarios:
            error += " before producing parseable scenarios"

    logger.info(
        "evalya finished (exit=%d, %.1fs): %d/%d scenarios passing",
        process.returncode,
        duration,
        sum(1 for s in scenarios if s.passed),
        len(scenarios),
    )
    if error:
        logger.warning("%s\n--- evalya output tail ---\n%s", error, output_tail)

    return EvalyaRunResult(
        scenarios_total=len(scenarios),
        scenarios_passing=sum(1 for s in scenarios if s.passed),
        scenarios=scenarios,
        raw_output=raw_output,
        output_tail=output_tail,
        duration_s=duration,
        exit_code=process.returncode,
        error=error,
    )
