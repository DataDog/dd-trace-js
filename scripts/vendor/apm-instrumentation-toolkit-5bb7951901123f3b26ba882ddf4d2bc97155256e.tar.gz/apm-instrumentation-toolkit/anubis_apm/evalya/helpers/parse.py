"""Behave output parsers for the evalya runner."""

from typing import List, Set

from ..constants import (
    FAILING_LINE_RE,
    FAILING_SECTION_RE,
    SCENARIO_HEADER_RE,
    SCENARIO_SUMMARY_RE,
)
from ..models import EvalyaScenarioResult
from .utils import strip_prefix


def parse_failing_names(lines: List[str]) -> Set[str]:
    failing: Set[str] = set()
    in_section = False
    for line in lines:
        stripped = line.strip()
        if FAILING_SECTION_RE.match(stripped):
            in_section = True
            continue
        if in_section:
            m = FAILING_LINE_RE.match(line)
            if m:
                failing.add(m.group(1).strip())
            elif stripped and not stripped.startswith("#"):
                in_section = False
    return failing


def parse_scenarios(raw_output: str) -> List[EvalyaScenarioResult]:
    lines = [strip_prefix(line) for line in raw_output.splitlines()]
    clean = "\n".join(lines)

    failing_names = parse_failing_names(lines)

    seen: Set[str] = set()
    scenario_names: List[str] = []
    for line in lines:
        m = SCENARIO_HEADER_RE.match(line)
        if m:
            name = m.group(1).strip()
            if name not in seen:
                seen.add(name)
                scenario_names.append(name)

    if scenario_names:
        return [
            EvalyaScenarioResult(scenario=name, passed=name not in failing_names)
            for name in scenario_names
        ]

    m = SCENARIO_SUMMARY_RE.search(clean)
    if m:
        passed_count = int(m.group(1))
        failed_count = int(m.group(2))
        results = []
        for i in range(passed_count):
            results.append(EvalyaScenarioResult(scenario=f"scenario_{i + 1}", passed=True))
        for i in range(failed_count):
            results.append(EvalyaScenarioResult(scenario=f"failing_{i + 1}", passed=False))
        return results

    return []
