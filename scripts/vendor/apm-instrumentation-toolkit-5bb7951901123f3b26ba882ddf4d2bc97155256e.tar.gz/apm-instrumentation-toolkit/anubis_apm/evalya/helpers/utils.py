"""Low-level utilities for the evalya runner."""

import socket

from ..constants import PREFIX_RE


def find_free_port() -> int:
    """Return an available TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("", 0))
        return int(sock.getsockname()[1])


def strip_prefix(line: str) -> str:
    return PREFIX_RE.sub("", line)
