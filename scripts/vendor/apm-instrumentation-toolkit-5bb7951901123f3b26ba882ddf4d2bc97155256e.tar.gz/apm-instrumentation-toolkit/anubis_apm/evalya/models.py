"""Shared models for evalya results."""

from typing import List, Optional

from pydantic import BaseModel, Field


class EvalyaScenarioResult(BaseModel):
    """Result for a single evalya/behave scenario."""

    scenario: str = Field(description="Scenario name, e.g. 'SELECT query produces correct tags'")
    passed: bool = Field(description="True if scenario passed")


class EvalyaRunResult(BaseModel):
    """Aggregated result from running evalya against a package."""

    scenarios_total: int = 0
    scenarios_passing: int = 0
    scenarios: List[EvalyaScenarioResult] = Field(default_factory=list)
    raw_output: str = ""
    output_tail: str = ""
    duration_s: float = 0.0
    exit_code: Optional[int] = None
    error: str = ""
