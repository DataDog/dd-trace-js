"""Java-specific helpers for running Evalya against dd-trace-java."""

import logging
import os
import re
import shlex
import signal
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

JAVA_AGENT_BUILD_DIR = "/opt/dd-trace-java"
JAR_BUILD_TIMEOUT_S = 1800
GRADLE_OPTS = (
    "-Dorg.gradle.jvmargs=-Xms1G -Xmx5G "
    "-XX:ErrorFile=/tmp/hs_err_pid%p.log "
    "-XX:+HeapDumpOnOutOfMemoryError "
    "-XX:HeapDumpPath=/tmp"
)
GRADLE_ARGS = (
    ":dd-java-agent:shadowJar",
    "--build-cache",
    "--stacktrace",
    "--no-daemon",
    "--parallel",
    "--max-workers=4",
)
STUB_BUILD_GRADLE = """// Minimal Gradle project stub for Evalya blind-deletion builds.
plugins {
    id("java-library")
}
"""


def container_env() -> dict[str, str]:
    return {"DD_TRACE_JAVA_AGENT_BUILD_DIR": JAVA_AGENT_BUILD_DIR}


def prepare_overlay(worktree_path: Path) -> tuple[Path, dict[str, str]]:
    """Build the eval jar and return the directory Evalya should mount."""
    jar_dir = build_java_agent(worktree_path)
    return jar_dir, container_env()


def prepare_post_deletion_overlay(worktree_path: Path) -> tuple[Path, dict[str, str]]:
    """Build the post-deletion eval jar and return the directory Evalya should mount."""
    jar_dir = build_java_agent(worktree_path, allow_missing_project_stubs=True)
    return jar_dir, container_env()


def test_command_parts(worktree_path: Path) -> tuple[Path, dict[str, str], str]:
    """Return Java-specific Evalya test command inputs."""
    return java_agent_libs_dir(worktree_path), container_env(), gradle_command(worktree_path)


def build_java_agent(
    worktree_path: Path,
    timeout_s: int = JAR_BUILD_TIMEOUT_S,
    *,
    allow_missing_project_stubs: bool = False,
) -> Path:
    """Build the dd-java-agent jar and return its containing directory.

    Evalya's Java launcher can be pointed at an arbitrary mounted directory with
    ``DD_TRACE_JAVA_AGENT_BUILD_DIR``. Mounting only ``dd-java-agent/build/libs``
    keeps Evalya language-agnostic while still testing the jar built from the
    current worktree. Gradle decides what is up to date, so repeated calls avoid
    a full rebuild when inputs are warm.
    """
    if not worktree_path.exists():
        raise RuntimeError(f"build_evalya_java_agent: {worktree_path} does not exist")
    if not (worktree_path / "gradlew").exists():
        raise RuntimeError(f"build_evalya_java_agent: no gradlew in {worktree_path}")

    stubbed_projects = (
        ensure_missing_instrumentation_project_stubs(worktree_path)
        if allow_missing_project_stubs
        else []
    )
    if stubbed_projects:
        logger.info(
            "build_evalya_java_agent: created %d Gradle project stubs for deleted instrumentation",
            len(stubbed_projects),
        )

    try:
        cmd = ["./gradlew", *GRADLE_ARGS]
        log_path = worktree_path / ".dd-apm-prepare-evalya-java.log"
        env = {**os.environ, "TERM": "dumb", "NO_COLOR": "1", "CI": "true"}
        env.update(gradle_env(worktree_path))

        logger.info("build_evalya_java_agent: building dd-java-agent jar in %s", worktree_path)
        try:
            with log_path.open("w") as log_file:
                process = subprocess.Popen(
                    cmd,
                    cwd=worktree_path,
                    stdin=subprocess.DEVNULL,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    env=env,
                    start_new_session=True,
                )
                try:
                    process.wait(timeout=timeout_s)
                except subprocess.TimeoutExpired as exc:
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError as cleanup_error:
                        logger.debug(
                            "build_evalya_java_agent: process group %s exited before SIGTERM: %s",
                            process.pid,
                            cleanup_error,
                        )
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError as cleanup_error:
                            logger.debug(
                                "build_evalya_java_agent: process group %s exited before SIGKILL: %s",
                                process.pid,
                                cleanup_error,
                            )
                        process.wait()
                    raw_output = log_path.read_text(errors="replace")
                    raise RuntimeError(
                        "build_evalya_java_agent: ./gradlew :dd-java-agent:shadowJar "
                        f"timed out after {timeout_s}s. Full log: {log_path}\n"
                        f"--- output tail ---\n{raw_output[-4000:]}"
                    ) from exc
        except FileNotFoundError as exc:
            raise RuntimeError("build_evalya_java_agent: ./gradlew not found") from exc

        raw_output = log_path.read_text(errors="replace")

        if process.returncode != 0:
            raise RuntimeError(
                "build_evalya_java_agent: ./gradlew :dd-java-agent:shadowJar failed "
                f"(exit {process.returncode}). Full log: {log_path}\n"
                f"--- output tail ---\n{raw_output[-4000:]}"
            )

        jars = java_agent_jar_candidates(worktree_path)
        if not jars:
            raise RuntimeError(
                "build_evalya_java_agent: shadowJar succeeded but no dd-java-agent jar "
                f"was found under {java_agent_libs_dir(worktree_path)}.\n"
                f"{describe_java_agent_outputs(worktree_path)}\n"
                f"Full log: {log_path}\n"
                f"--- output tail ---\n{raw_output[-4000:]}"
            )
        if len(jars) > 1:
            rendered = "\n".join(f"  - {jar.relative_to(worktree_path)}" for jar in jars)
            raise RuntimeError(
                "build_evalya_java_agent: shadowJar produced multiple candidate "
                f"dd-java-agent jars under {java_agent_libs_dir(worktree_path)}:\n"
                f"{rendered}\nFull log: {log_path}"
            )
        jar = jars[0]
        logger.info("build_evalya_java_agent: using %s", jar)
        return jar.parent
    finally:
        remove_instrumentation_project_stubs(worktree_path, stubbed_projects)


def gradle_env(worktree_path: Path) -> dict[str, str]:
    return {
        "GRADLE_USER_HOME": os.environ.get("GRADLE_USER_HOME", str(worktree_path / ".gradle")),
        "GRADLE_OPTS": os.environ.get("GRADLE_OPTS", GRADLE_OPTS),
    }


def gradle_command(worktree_path: Path) -> str:
    env = gradle_env(worktree_path)
    env_prefix = " ".join(f"{key}={shlex.quote(value)}" for key, value in env.items())
    return f"{env_prefix} {shlex.join(['./gradlew', *GRADLE_ARGS])}"


def java_agent_libs_dir(worktree_path: Path) -> Path:
    for libs_dir in java_agent_libs_dirs(worktree_path):
        if usable_java_agent_jars(libs_dir):
            return libs_dir
    return java_agent_libs_dirs(worktree_path)[0]


def java_agent_libs_dirs(worktree_path: Path) -> list[Path]:
    return [root / "dd-java-agent" / "build" / "libs" for root in java_source_roots(worktree_path)]


def java_source_roots(worktree_path: Path) -> list[Path]:
    roots: list[Path] = []
    workspace_root = worktree_path / "workspace"
    if (workspace_root / "dd-java-agent").exists():
        roots.append(workspace_root)
    if (worktree_path / "dd-java-agent").exists():
        roots.append(worktree_path)
    return roots or [worktree_path]


def usable_java_agent_jars(libs_dir: Path) -> list[Path]:
    def usable_agent_jar(path: Path) -> bool:
        if path.name.endswith(("-sources.jar", "-javadoc.jar")):
            return False
        return not path.name.endswith(("-shared.jar", "-trace.jar"))

    if not libs_dir.exists():
        return []
    return sorted(
        path
        for path in libs_dir.glob("dd-java-agent*.jar")
        if path.is_file() and usable_agent_jar(path)
    )


def java_agent_jar_candidates(worktree_path: Path) -> list[Path]:
    jars: list[Path] = []
    for libs_dir in java_agent_libs_dirs(worktree_path):
        jars.extend(usable_java_agent_jars(libs_dir))
    return sorted(jars)


def describe_java_agent_outputs(worktree_path: Path) -> str:
    candidates = java_agent_jar_candidates(worktree_path)
    if candidates:
        rendered = "\n".join(f"  - {path.relative_to(worktree_path)}" for path in candidates[:20])
        return f"Candidate dd-java-agent jars:\n{rendered}"

    libs_dir = java_agent_libs_dir(worktree_path)
    ignored = noncanonical_java_agent_jars(worktree_path)
    if not libs_dir.exists():
        message = f"Build output directory does not exist: {libs_dir}"
        if ignored:
            message += "\n" + render_ignored_java_agent_jars(worktree_path, ignored)
        return message

    entries = sorted(
        path.relative_to(worktree_path)
        for path in libs_dir.rglob("*")
        if path.is_file() and path.suffix in {".jar", ".zip", ".txt", ".properties"}
    )
    if not entries:
        message = f"No jar-like files found under {libs_dir}"
        if ignored:
            message += "\n" + render_ignored_java_agent_jars(worktree_path, ignored)
        return message

    rendered = "\n".join(f"  - {entry}" for entry in entries[:40])
    message = f"Build outputs under {libs_dir.relative_to(worktree_path)}:\n{rendered}"
    if ignored:
        message += "\n" + render_ignored_java_agent_jars(worktree_path, ignored)
    return message


def noncanonical_java_agent_jars(worktree_path: Path) -> list[Path]:
    libs_dirs = set(java_agent_libs_dirs(worktree_path))
    ignored: list[Path] = []
    for path in worktree_path.rglob("dd-java-agent*.jar"):
        if not path.is_file():
            continue
        if "build" not in path.relative_to(worktree_path).parts:
            continue
        if path.parent in libs_dirs:
            continue
        ignored.append(path)
    return sorted(ignored)


def render_ignored_java_agent_jars(worktree_path: Path, jars: list[Path]) -> str:
    rendered = "\n".join(f"  - {path.relative_to(worktree_path)}" for path in jars[:20])
    return f"Ignored noncanonical dd-java-agent jars:\n{rendered}"


def settings_include_paths(line: str) -> list[str]:
    """Return every quoted Gradle project path on a settings line."""
    return re.findall(r"[\"'](:[A-Za-z0-9_.:-]+)[\"']", line)


def ensure_missing_instrumentation_project_stubs(repo_root: Path) -> list[Path]:
    """Create empty projects for deleted instrumentation dirs still included by Gradle."""
    settings_path = repo_root / "settings.gradle.kts"
    instr_root = repo_root / "dd-java-agent" / "instrumentation"
    if not settings_path.exists() or not instr_root.exists():
        return []

    project_prefix = ":dd-java-agent:instrumentation:"
    stubbed: list[Path] = []
    for line in settings_path.read_text().splitlines():
        for project_path in settings_include_paths(line):
            if not project_path.startswith(project_prefix):
                continue
            rel_parts = project_path.removeprefix(project_prefix).split(":")
            module_dir = instr_root.joinpath(*rel_parts)
            if module_dir.exists():
                continue
            module_dir.mkdir(parents=True)
            (module_dir / "build.gradle").write_text(STUB_BUILD_GRADLE)
            stubbed.append(module_dir)
    return stubbed


def remove_instrumentation_project_stubs(repo_root: Path, stubbed_projects: list[Path]) -> None:
    instr_root = repo_root / "dd-java-agent" / "instrumentation"
    for module_dir in sorted(stubbed_projects, key=lambda path: len(path.parts), reverse=True):
        build_file = module_dir / "build.gradle"
        if build_file.exists() and build_file.read_text() == STUB_BUILD_GRADLE:
            build_file.unlink()

        current = module_dir
        while current != instr_root and instr_root in current.parents:
            try:
                current.rmdir()
            except OSError:
                break
            current = current.parent
