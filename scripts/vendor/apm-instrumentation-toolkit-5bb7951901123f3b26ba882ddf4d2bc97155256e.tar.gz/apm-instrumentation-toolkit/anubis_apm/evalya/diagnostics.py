"""Diagnostics helpers for evalya workflow output."""

from anubis.core.context import Context

from .models import EvalyaRunResult

DEFAULT_OUTPUT_TAIL_CHARS = 3000


def output_tail(res: EvalyaRunResult, limit: int = DEFAULT_OUTPUT_TAIL_CHARS) -> str:
    """Return a bounded output tail for logs, spans, and result models."""
    tail = res.output_tail or (res.raw_output or "")
    return tail[-limit:] if len(tail) > limit else tail


def exit_code_label(res: EvalyaRunResult) -> str:
    """Return a display-safe exit code."""
    return "unknown" if res.exit_code is None else str(res.exit_code)


def record_output(ctx: Context, phase: str, res: EvalyaRunResult) -> str:
    """Persist raw evalya output under the current step logs directory."""
    if not res.raw_output:
        return ""
    path = ctx.step_logs() / f"{phase}_evalya_output.txt"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(res.raw_output, encoding="utf-8")
    return ctx.state.relative(path, ctx.base_dir) if ctx.state else str(path)


def log_result(ctx: Context, phase: str, res: EvalyaRunResult, log_path: str) -> None:
    """Log the high-level evalya result and saved output location."""
    ctx.info(
        f"{phase}: evalya exit_code={exit_code_label(res)} "
        f"scenarios={res.scenarios_passing}/{res.scenarios_total} "
        f"duration={res.duration_s:.1f}s "
        f"output={log_path or '(none)'}"
    )


def format_failure(message: str, res: EvalyaRunResult, log_path: str) -> str:
    """Format an evalya failure with the metadata needed to debug it."""
    parts = [
        message,
        (
            f"evalya exit_code={exit_code_label(res)} "
            f"scenarios={res.scenarios_passing}/{res.scenarios_total} "
            f"duration={res.duration_s:.1f}s"
        ),
    ]
    if log_path:
        parts.append(f"evalya output log: {log_path}")
    if res.error:
        parts.append(f"evalya error: {res.error}")
    tail = output_tail(res)
    if tail:
        parts.append(f"--- evalya output tail ---\n{tail}")
    return "\n".join(parts)
