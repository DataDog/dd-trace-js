"""Constants for the evalya runner."""

import re

# OCI context for IAT task definitions published by DataDog/evalya.
EVALYA_OCI_CONTEXT = "oci::registry.ddbuild.io/ci/evalya?ref=main"

# Host variables in this allowlist must also reach the task container via
# ``evalya run --env``. Manifest interpolation alone does not configure the app.
EVALYA_TASK_ENV_KEYS = frozenset({"FTF_FAIL_KNOWN_MISMATCHES"})

KNOWN_MISMATCH_OUTPUT_MARKER = "Known-mismatch tags recorded but not failing:"

# Evalya prefixed output format: "task_id[stdout] " or "task_id[stderr] "
PREFIX_RE = re.compile(r"^[^\[\s]+\[(?:stdout|stderr)\]\s?")

# Behave scenario summary line: "N scenarios passed, M failed[, K skipped]"
SCENARIO_SUMMARY_RE = re.compile(r"(\d+) scenarios? passed,\s*(\d+) failed")

# Behave scenario header: "  Scenario: <name>  # file:line"
SCENARIO_HEADER_RE = re.compile(r"^\s+Scenario(?:\s+Outline)?: (.+?)(?:\s*#.*)?$")

# Behave "Failing scenarios:" section header
FAILING_SECTION_RE = re.compile(r"^Failing scenarios:\s*$")

# Failing scenario line: "  features/xxx.feature:NN  Scenario name"
FAILING_LINE_RE = re.compile(r"^\s+\S+:\d+\s+(.+)$")
