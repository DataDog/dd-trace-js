#!/usr/bin/env python3
"""Extract all methods from Python source code using AST.

This analyzer extracts all public methods from classes in a Python package
to identify potential instrumentation targets.

Usage:
    python extract_all_methods.py <package_path> [--output <output_file>]
"""

import ast
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


class MethodExtractor(ast.NodeVisitor):
    """AST visitor to extract all method definitions."""

    def __init__(self):
        self.methods: List[Dict[str, Any]] = []
        self.current_class: Optional[str] = None
        self.current_file: Optional[str] = None

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """Visit class definition."""
        old_class = self.current_class
        self.current_class = node.name
        self.generic_visit(node)
        self.current_class = old_class

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Visit function definition."""
        self._extract_method(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Visit async function definition."""
        self._extract_method(node, is_async=True)
        self.generic_visit(node)

    def _extract_method(
        self, node: Union[ast.FunctionDef, ast.AsyncFunctionDef], is_async: bool = False
    ) -> None:
        """Extract method information."""
        # Skip private methods (starting with _)
        if node.name.startswith("_") and not node.name.startswith("__"):
            return

        # Skip dunder methods except __init__ and __call__
        if node.name.startswith("__") and node.name not in ("__init__", "__call__"):
            return

        method_info = {
            "name": node.name,
            "class": self.current_class,
            "file": self.current_file,
            "line": node.lineno,
            "is_async": is_async,
            "is_method": self.current_class is not None,
            "args": self._extract_args(node),
            "decorators": self._extract_decorators(node),
            "docstring": ast.get_docstring(node),
        }
        self.methods.append(method_info)

    def _extract_args(
        self, node: Union[ast.FunctionDef, ast.AsyncFunctionDef]
    ) -> List[Dict[str, Any]]:
        """Extract argument information from function."""
        args: List[Dict[str, Any]] = []

        # Regular arguments
        defaults_offset = len(node.args.args) - len(node.args.defaults)
        for i, arg in enumerate(node.args.args):
            arg_info: Dict[str, Any] = {
                "name": arg.arg,
                "type": None,
                "default": None,
            }
            # Get type annotation if present
            if arg.annotation:
                arg_info["type"] = ast.unparse(arg.annotation)

            # Get default value if present
            if i >= defaults_offset:
                default_node = node.args.defaults[i - defaults_offset]
                try:
                    arg_info["default"] = ast.unparse(default_node)
                except Exception:
                    arg_info["default"] = "<complex>"

            args.append(arg_info)

        # Keyword-only arguments
        for i, arg in enumerate(node.args.kwonlyargs):
            arg_info = {
                "name": arg.arg,
                "type": None,
                "default": None,
                "keyword_only": True,
            }
            if arg.annotation:
                arg_info["type"] = ast.unparse(arg.annotation)
            kw_default = node.args.kw_defaults[i] if i < len(node.args.kw_defaults) else None
            if kw_default is not None:
                try:
                    arg_info["default"] = ast.unparse(kw_default)
                except Exception:
                    arg_info["default"] = "<complex>"
            args.append(arg_info)

        return args

    def _extract_decorators(self, node: Union[ast.FunctionDef, ast.AsyncFunctionDef]) -> List[str]:
        """Extract decorator names."""
        decorators = []
        for decorator in node.decorator_list:
            try:
                if isinstance(decorator, ast.Name):
                    decorators.append(decorator.id)
                elif isinstance(decorator, ast.Attribute):
                    decorators.append(ast.unparse(decorator))
                elif isinstance(decorator, ast.Call):
                    if isinstance(decorator.func, ast.Name):
                        decorators.append(decorator.func.id)
                    elif isinstance(decorator.func, ast.Attribute):
                        decorators.append(decorator.func.attr)
            except Exception:
                decorators.append("<complex>")
        return decorators


def extract_all_methods(package_path: Path) -> List[Dict[str, Any]]:
    """Extract all public methods from a Python package.

    Args:
        package_path: Path to the Python package directory

    Returns:
        List of method information dicts
    """
    extractor = MethodExtractor()

    # Find all Python files
    for py_file in package_path.rglob("*.py"):
        try:
            source = py_file.read_text()
            tree = ast.parse(source, filename=str(py_file))
            extractor.current_file = str(py_file.relative_to(package_path))
            extractor.visit(tree)
        except (SyntaxError, UnicodeDecodeError) as e:
            print(f"Warning: Could not parse {py_file}: {e}", file=sys.stderr)
            continue

    return extractor.methods


def main():
    """CLI entry point."""
    if len(sys.argv) < 2:
        print("Usage: python extract_all_methods.py <package_path> [--output <output_file>]")
        sys.exit(1)

    package_path = Path(sys.argv[1])
    output_file = None

    # Parse --output argument
    if "--output" in sys.argv:
        output_idx = sys.argv.index("--output")
        if output_idx + 1 < len(sys.argv):
            output_file = Path(sys.argv[output_idx + 1])

    if not package_path.exists():
        print(f"Error: Package path does not exist: {package_path}")
        sys.exit(1)

    methods = extract_all_methods(package_path)

    # Output as JSON
    output = json.dumps(methods, indent=2, default=str)

    if output_file:
        output_file.write_text(output)
        print(f"Wrote {len(methods)} methods to {output_file}")
    else:
        print(output)


if __name__ == "__main__":
    main()
