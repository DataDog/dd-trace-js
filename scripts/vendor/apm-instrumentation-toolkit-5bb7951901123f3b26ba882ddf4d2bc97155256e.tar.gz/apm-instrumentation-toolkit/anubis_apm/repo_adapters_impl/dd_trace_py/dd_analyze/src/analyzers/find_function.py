#!/usr/bin/env python3
"""Find function definitions in Python source code using AST.

This analyzer locates specific functions/methods in Python packages
to determine instrumentation targets.

Usage:
    python find_function.py <package_path> <function_name> [--class <class_name>]
"""

import ast
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


class FunctionFinder(ast.NodeVisitor):
    """AST visitor to find function definitions."""

    def __init__(self, target_function: str, target_class: Optional[str] = None):
        self.target_function = target_function
        self.target_class = target_class
        self.results: List[Dict[str, Any]] = []
        self.current_class: Optional[str] = None
        self.current_file: Optional[str] = None

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        """Visit class definition."""
        old_class = self.current_class
        self.current_class = node.name
        self.generic_visit(node)
        self.current_class = old_class

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Visit function definition."""
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        """Visit async function definition."""
        self._check_function(node, is_async=True)
        self.generic_visit(node)

    def _check_function(
        self, node: Union[ast.FunctionDef, ast.AsyncFunctionDef], is_async: bool = False
    ) -> None:
        """Check if this function matches our target."""
        # Check if function name matches
        if node.name != self.target_function:
            return

        # Check if class constraint is satisfied
        if self.target_class:
            if self.current_class != self.target_class:
                return

        # Extract function info
        result = {
            "name": node.name,
            "class": self.current_class,
            "file": self.current_file,
            "line": node.lineno,
            "col": node.col_offset,
            "is_async": is_async,
            "args": self._extract_args(node),
        }
        self.results.append(result)

    def _extract_args(self, node: Union[ast.FunctionDef, ast.AsyncFunctionDef]) -> List[str]:
        """Extract argument names from function."""
        args = []
        for arg in node.args.args:
            args.append(arg.arg)
        return args


def find_function(
    package_path: Path,
    function_name: str,
    class_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Find all occurrences of a function in a package.

    Args:
        package_path: Path to the Python package directory
        function_name: Name of the function to find
        class_name: Optional class name to filter by

    Returns:
        List of function location dicts
    """
    finder = FunctionFinder(function_name, class_name)

    # Find all Python files
    for py_file in package_path.rglob("*.py"):
        try:
            source = py_file.read_text()
            tree = ast.parse(source, filename=str(py_file))
            finder.current_file = str(py_file.relative_to(package_path))
            finder.visit(tree)
        except (SyntaxError, UnicodeDecodeError) as e:
            print(f"Warning: Could not parse {py_file}: {e}", file=sys.stderr)
            continue

    return finder.results


def main():
    """CLI entry point."""
    if len(sys.argv) < 3:
        print(
            "Usage: python find_function.py <package_path> <function_name> [--class <class_name>]"
        )
        sys.exit(1)

    package_path = Path(sys.argv[1])
    function_name = sys.argv[2]
    class_name = None

    # Parse --class argument
    if "--class" in sys.argv:
        class_idx = sys.argv.index("--class")
        if class_idx + 1 < len(sys.argv):
            class_name = sys.argv[class_idx + 1]

    if not package_path.exists():
        print(f"Error: Package path does not exist: {package_path}")
        sys.exit(1)

    results = find_function(package_path, function_name, class_name)

    # Output as JSON
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
