#!/usr/bin/env python3
"""Context Capture Tool for dd-trace-py instrumentation analysis.

This tool wraps target methods in a Python package to capture:
- Instance (self) at call time
- Arguments and keyword arguments
- Return value or exception

Usage:
    python capture.py <analysis_file> <sample_app> <output_file>

Example:
    python capture.py final.json sample_app.py context-snapshot.json
"""

import asyncio
import functools
import inspect
import json
import sys
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

MAX_REPR_LENGTH = 500


class ContextCapture:
    """Captures context from method calls."""

    def __init__(self):
        self.snapshots: List[Dict[str, Any]] = []
        self.wrapped_methods: List[str] = []

    def wrap_method(
        self,
        module: Any,
        class_name: Optional[str],
        method_name: str,
    ) -> bool:
        """Wrap a method to capture its context.

        Args:
            module: The module containing the class/method
            class_name: Name of the class (or None for module-level function)
            method_name: Name of the method to wrap

        Returns:
            True if wrapping succeeded, False otherwise
        """
        try:
            if class_name:
                # Get the class from the module
                target_class = getattr(module, class_name, None)
                if target_class is None:
                    print(f"[Wrap] Class '{class_name}' not found in module")
                    return False

                # Get the original method
                original = getattr(target_class, method_name, None)
                if original is None:
                    print(f"[Wrap] Method '{method_name}' not found on class '{class_name}'")
                    return False

                # Create wrapper
                wrapper = self._create_wrapper(original, class_name, method_name)
                setattr(target_class, method_name, wrapper)
                self.wrapped_methods.append(f"{class_name}.{method_name}")
                print(f"[Wrap] Wrapped {class_name}.{method_name}")
            else:
                # Module-level function
                original = getattr(module, method_name, None)
                if original is None:
                    print(f"[Wrap] Function '{method_name}' not found in module")
                    return False

                wrapper = self._create_wrapper(original, None, method_name)
                setattr(module, method_name, wrapper)
                self.wrapped_methods.append(method_name)
                print(f"[Wrap] Wrapped {method_name}")

            return True

        except Exception as e:
            print(f"[Wrap] Error wrapping {class_name}.{method_name}: {e}")
            return False

    def _create_wrapper(
        self,
        original: Callable,
        class_name: Optional[str],
        method_name: str,
    ) -> Callable:
        """Create a wrapper function that captures context."""
        capture = self

        def _build_base_snapshot(instance, method_args, kwargs):
            """Build base snapshot dict."""
            return {
                "className": class_name if class_name else "<module>",
                "methodName": method_name,
                "self": _safe_repr(instance),
                "arguments": [_deep_serialize(a) for a in method_args],
                "kwargs": {k: _deep_serialize(v) for k, v in kwargs.items()},
                "result": None,
                "error": None,
            }

        @functools.wraps(original)
        def wrapper(*args, **kwargs):
            instance = args[0] if args and class_name else None
            method_args = args[1:] if class_name else args
            snapshot = _build_base_snapshot(instance, method_args, kwargs)

            try:
                result = original(*args, **kwargs)

                # Handle sync generators (streaming)
                if _is_generator(result):
                    chunks = []

                    def capturing_generator():
                        for chunk in result:
                            chunks.append(_deep_serialize(chunk))
                            yield chunk
                        # After generator exhausted, save snapshot
                        snapshot["result"] = {"_type": "generator", "chunks": chunks}
                        snapshot["isStreaming"] = True
                        capture.snapshots.append(snapshot)
                        print(
                            f"[Capture] {class_name}.{method_name} (generator) -> captured {len(chunks)} chunks"
                        )

                    return capturing_generator()

                snapshot["result"] = _deep_serialize(result)
                capture.snapshots.append(snapshot)
                print(f"[Capture] {class_name}.{method_name} -> captured")
                return result
            except Exception as e:
                snapshot["error"] = {"message": str(e), "name": type(e).__name__}
                capture.snapshots.append(snapshot)
                print(f"[Capture] {class_name}.{method_name} -> error: {e}")
                raise

        # Handle async generator functions (async streaming)
        if _is_async_generator_function(original):

            @functools.wraps(original)
            async def async_gen_wrapper(*args, **kwargs):
                instance = args[0] if args and class_name else None
                method_args = args[1:] if class_name else args
                snapshot = _build_base_snapshot(instance, method_args, kwargs)
                snapshot["returnsAsyncGenerator"] = True
                snapshot["isStreaming"] = True

                chunks = []
                try:
                    async for chunk in original(*args, **kwargs):
                        chunks.append(_deep_serialize(chunk))
                        yield chunk
                    # After async generator exhausted, save snapshot
                    snapshot["result"] = {"_type": "async_generator", "chunks": chunks}
                    capture.snapshots.append(snapshot)
                    print(
                        f"[Capture] {class_name}.{method_name} (async gen) -> captured {len(chunks)} chunks"
                    )
                except Exception as e:
                    snapshot["error"] = {"message": str(e), "name": type(e).__name__}
                    snapshot["result"] = {"_type": "async_generator", "chunks": chunks}
                    capture.snapshots.append(snapshot)
                    print(
                        f"[Capture] {class_name}.{method_name} (async gen) -> error after {len(chunks)} chunks: {e}"
                    )
                    raise

            return async_gen_wrapper

        # Handle async methods (coroutines)
        if _is_coroutine_function(original):

            @functools.wraps(original)
            async def async_wrapper(*args, **kwargs):
                instance = args[0] if args and class_name else None
                method_args = args[1:] if class_name else args
                snapshot = _build_base_snapshot(instance, method_args, kwargs)
                snapshot["returnsCoroutine"] = True

                try:
                    result = await original(*args, **kwargs)

                    # Handle async generators returned from coroutines
                    if _is_async_generator(result):
                        chunks = []

                        async def capturing_async_gen():
                            async for chunk in result:
                                chunks.append(_deep_serialize(chunk))
                                yield chunk
                            snapshot["result"] = {"_type": "async_generator", "chunks": chunks}
                            snapshot["isStreaming"] = True
                            capture.snapshots.append(snapshot)
                            print(
                                f"[Capture] {class_name}.{method_name} (async->gen) -> captured {len(chunks)} chunks"
                            )

                        return capturing_async_gen()

                    snapshot["result"] = _deep_serialize(result)
                    capture.snapshots.append(snapshot)
                    print(f"[Capture] {class_name}.{method_name} (async) -> captured")
                    return result
                except Exception as e:
                    snapshot["error"] = {"message": str(e), "name": type(e).__name__}
                    capture.snapshots.append(snapshot)
                    print(f"[Capture] {class_name}.{method_name} (async) -> error: {e}")
                    raise

            return async_wrapper

        return wrapper

    def save(self, output_file: Path) -> None:
        """Save captured snapshots to file.

        Output format is a direct array of snapshots (uses Python-specific naming, e.g. returnsCoroutine instead of JS returnsPromise).
        """
        with open(output_file, "w") as f:
            json.dump(self.snapshots, f, indent=2)
        print(f"\n[Save] Wrote {len(self.snapshots)} snapshots to {output_file}")


def _safe_repr(obj: Any, max_len: int = MAX_REPR_LENGTH) -> str:
    """Get a safe string representation of an object."""
    try:
        r = repr(obj)
        if len(r) > max_len:
            r = r[:max_len] + "..."
        return r
    except Exception:
        return f"<{type(obj).__name__}>"


def _deep_serialize(obj: Any, max_depth: int = 5, max_str_len: int = 2000) -> Any:
    """Deep serialize an object, extracting all public attributes.

    Traverses object graphs generically using __dict__ and __slots__,
    serializing all public (non-underscore-prefixed) attributes.
    """
    if max_depth <= 0:
        return _safe_repr(obj)

    # Primitives
    if obj is None or isinstance(obj, (bool, int, float)):
        return obj

    if isinstance(obj, str):
        if len(obj) > max_str_len:
            return obj[:max_str_len] + "...[truncated]"
        return obj

    if isinstance(obj, bytes):
        return f"<bytes len={len(obj)}>"

    # Lists/tuples
    if isinstance(obj, (list, tuple)):
        return [
            _deep_serialize(item, max_depth - 1, max_str_len) for item in obj[:50]
        ]  # Limit list size

    # Dicts
    if isinstance(obj, dict):
        return {
            str(k): _deep_serialize(v, max_depth - 1, max_str_len)
            for k, v in list(obj.items())[:50]
        }

    # Objects - extract all public attributes generically
    result = {"_type": type(obj).__name__}

    # Extract public attributes from __dict__ (instance attributes)
    try:
        if hasattr(obj, "__dict__"):
            for k, v in list(obj.__dict__.items())[:50]:
                if not k.startswith("_"):
                    result[k] = _deep_serialize(v, max_depth - 1, max_str_len)
    except Exception:
        pass  # best effort: __dict__ iteration may fail

    # If __dict__ gave nothing, try __slots__
    if len(result) == 1:
        try:
            if hasattr(obj, "__slots__"):
                for slot in obj.__slots__:
                    if not slot.startswith("_") and hasattr(obj, slot):
                        value = getattr(obj, slot)
                        if value is not None:
                            result[slot] = _deep_serialize(value, max_depth - 1, max_str_len)
        except Exception:
            pass  # best effort: __slots__ access may fail

    # If still nothing, fall back to repr
    if len(result) == 1:
        result["_repr"] = _safe_repr(obj)

    return result


def _is_async_generator(obj: Any) -> bool:
    """Check if an object is an async generator."""
    return inspect.isasyncgen(obj)


def _is_generator(obj: Any) -> bool:
    """Check if an object is a sync generator."""
    return inspect.isgenerator(obj)


def _is_coroutine_function(func: Callable) -> bool:
    """Check if a function is a coroutine function."""
    return asyncio.iscoroutinefunction(func)


def _is_async_generator_function(func: Callable) -> bool:
    """Check if a function is an async generator function."""
    return inspect.isasyncgenfunction(func)


def load_analysis(analysis_file: Path) -> List[Dict[str, Any]]:
    """Load instrumentation targets from analysis file."""
    with open(analysis_file) as f:
        data = json.load(f)

    instrumentations = data.get("orchestrion_config", {}).get("instrumentations", [])
    targets = []

    for instr in instrumentations:
        fq = instr.get("function_query", {})
        if fq.get("name"):
            targets.append({
                "class_name": fq.get("class"),
                "method_name": fq.get("name"),
            })

    return targets


def run_capture(
    analysis_file: Path,
    sample_app: Path,
    output_file: Path,
) -> int:
    """Run context capture.

    Args:
        analysis_file: Path to final.json with instrumentation targets
        sample_app: Path to sample_app.py to run
        output_file: Path to write context-snapshot.json

    Returns:
        Exit code (0 for success)
    """
    print(f"[Init] Context Capture Tool")
    print(f"[Init] Analysis: {analysis_file}")
    print(f"[Init] Sample app: {sample_app}")
    print(f"[Init] Output: {output_file}")
    print()

    # Load targets
    try:
        targets = load_analysis(analysis_file)
        print(f"[Load] Found {len(targets)} instrumentation targets")
        for t in targets:
            print(f"  - {t.get('class_name', '')}.{t['method_name']}")
    except Exception as e:
        print(f"[Error] Failed to load analysis: {e}")
        return 1

    if not targets:
        print("[Error] No instrumentation targets found")
        return 1

    # Create capture instance
    capture = ContextCapture()

    # Add sample app directory to path so imports work
    sample_dir = sample_app.parent.absolute()
    if str(sample_dir) not in sys.path:
        sys.path.insert(0, str(sample_dir))

    # Import the target package and wrap methods
    # Note: We need to determine the package from the analysis
    # For now, we'll wrap after the sample app imports the package
    print("\n[Info] Running sample app with wrapping...")
    print("[Info] Hooks will be installed when packages are imported")
    print()

    # Install import hooks to wrap methods when the package is loaded
    _install_import_hooks(capture, targets)

    # Run the sample app
    try:
        # Read and exec the sample app
        sample_code = sample_app.read_text()
        sample_globals = {
            "__name__": "__main__",
            "__file__": str(sample_app),
        }
        exec(compile(sample_code, sample_app, "exec"), sample_globals)
    except SystemExit as e:
        print(f"[Info] Sample app exited with code {e.code}")
    except Exception as e:
        print(f"[Error] Sample app failed: {e}")
        traceback.print_exc()

    # Save results
    capture.save(output_file)

    if capture.snapshots:
        print(f"\n[Success] Captured {len(capture.snapshots)} context snapshots")
        return 0

    print("\n[Warning] No contexts captured - check if methods were called")
    return 1


def _install_import_hooks(capture: ContextCapture, targets: List[Dict[str, Any]]) -> None:
    """Install import hooks to wrap methods when packages are loaded."""

    class PostImportHook:
        """Wrap methods after modules are imported."""

        def __init__(self, capture, targets):
            self.capture = capture
            self.targets = targets
            self.wrapped_modules = set()

        def __call__(self, module):
            """Called after each module import."""
            module_name = getattr(module, "__name__", "")

            if module_name in self.wrapped_modules:
                return

            # Try to wrap any matching targets
            for target in self.targets:
                class_name = target.get("class_name")
                method_name = target["method_name"]

                if class_name:
                    # Check if this module has the class
                    if hasattr(module, class_name):
                        self.capture.wrap_method(module, class_name, method_name)
                        self.wrapped_modules.add(module_name)
                else:
                    # Module-level function (no class)
                    if hasattr(module, method_name):
                        self.capture.wrap_method(module, None, method_name)
                        self.wrapped_modules.add(module_name)

    # Install a simple approach: patch builtins.__import__
    original_import = (
        __builtins__["__import__"] if isinstance(__builtins__, dict) else __builtins__.__import__
    )
    post_hook = PostImportHook(capture, targets)

    def custom_import(name, globals=None, locals=None, fromlist=(), level=0):
        module = original_import(name, globals, locals, fromlist, level)
        post_hook(module)
        return module

    if isinstance(__builtins__, dict):
        __builtins__["__import__"] = custom_import
    else:
        __builtins__.__import__ = custom_import


def main():
    """Main entry point."""
    if len(sys.argv) != 4:
        print("Usage: python capture.py <analysis_file> <sample_app> <output_file>")
        print()
        print("Arguments:")
        print("  analysis_file  Path to final.json with instrumentation targets")
        print("  sample_app     Path to sample_app.py to run")
        print("  output_file    Path to write context-snapshot.json")
        sys.exit(1)

    analysis_file = Path(sys.argv[1])
    sample_app = Path(sys.argv[2])
    output_file = Path(sys.argv[3])

    if not analysis_file.exists():
        print(f"Error: Analysis file not found: {analysis_file}")
        sys.exit(1)

    if not sample_app.exists():
        print(f"Error: Sample app not found: {sample_app}")
        sys.exit(1)

    exit_code = run_capture(analysis_file, sample_app, output_file)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
