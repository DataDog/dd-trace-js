'use strict'

const assert = require('assert')
const path = require('path')
const fs = require('fs')
const { extractAllMethods } = require('../../dd-analyze/src/analyzers/extract-all-methods')
const { loadGroundTruth, compareToGroundTruth } = require('./helpers')

const PACKAGES_PATH = path.join(__dirname, 'fixture-packages')

// Patterns that static analysis cannot reliably handle
// (None remaining - all 28 patterns now pass!)
const KNOWN_LIMITATIONS = []

function getPatternDirs (basePath) {
  return fs.readdirSync(basePath, { withFileTypes: true })
    .filter(d => d.isDirectory() && !d.name.startsWith('_'))
    .map(d => d.name)
    .sort()
}

describe('extract-all-methods', function () {
  const groundTruth = loadGroundTruth(PACKAGES_PATH)
  const patterns = getPatternDirs(PACKAGES_PATH)

  for (const pattern of patterns) {
    const patternPath = path.join(PACKAGES_PATH, pattern)
    const hasFixture = fs.existsSync(path.join(patternPath, 'fixture.js')) ||
      fs.existsSync(path.join(patternPath, 'fixture.mjs')) ||
      fs.readdirSync(patternPath, { recursive: true }).some(f => f.endsWith('.js'))

    if (!hasFixture) continue

    const isKnownLimitation = KNOWN_LIMITATIONS.includes(pattern)
    const testFn = isKnownLimitation ? it.skip : it

    testFn(`should extract correct methods from ${pattern}`, function () {
      const staticResult = extractAllMethods(patternPath)

      const normalized = {
        classes: staticResult.classes.map(c => ({
          name: c.name,
          methods: c.methods
            // Filter out constructor and private methods (# prefix becomes 'private' prefix after parsing)
            .filter(m => m.kind !== 'constructor' && !m.name.startsWith('private'))
            .map(m => ({
              name: m.name,
              kind: m.kind,
              isAsync: m.isAsync,
              isStatic: m.isStatic
            }))
        })),
        functions: staticResult.functions || []
      }

      const canonicalClass = normalized.classes.find(c => c.name === 'Canonical')
      assert.ok(canonicalClass, 'Canonical class not found')

      const comparison = compareToGroundTruth(
        { classes: [canonicalClass], functions: [] },
        groundTruth
      )

      assert.ok(comparison.valid, `Diffs: ${JSON.stringify(comparison.diffs, null, 2)}`)
    })
  }
})
