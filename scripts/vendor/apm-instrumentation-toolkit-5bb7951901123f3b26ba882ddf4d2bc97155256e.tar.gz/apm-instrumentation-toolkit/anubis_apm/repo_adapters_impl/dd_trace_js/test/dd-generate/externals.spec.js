'use strict'

const assert = require('assert')
const fs = require('fs')
const os = require('os')
const path = require('path')

const {
  updateExternals,
  extractSubModules,
  hasTopLevelKey,
  insertNewEntry,
  formatKey,
} = require('../../dd-generate/src/generators/externals')

const SAMPLE_EXTERNALS = `'use strict'

const { DD_MAJOR } = require('../../../../version')

module.exports = {
  ai: [
    {
      name: 'ai',
      versions: ['4.0.2'],
    },
  ],
  mocha: [
    {
      name: 'mocha',
      versions: DD_MAJOR >= 6 ? ['>=8.0.0'] : ['>=5.2.0', '>=8.0.0'],
    },
  ],
  ws: [
    {
      name: 'ws',
      versions: ['>=8.0.0'],
    },
  ],
}
`

function makeAnalysis (instrumentations) {
  return { orchestrion_config: { instrumentations } }
}

describe('dd-generate externals generator', function () {
  describe('formatKey', function () {
    it('leaves valid identifiers unquoted', function () {
      assert.strictEqual(formatKey('genkit'), 'genkit')
      assert.strictEqual(formatKey('mocha'), 'mocha')
      assert.strictEqual(formatKey('_foo$bar'), '_foo$bar')
    })

    it('single-quotes keys with hyphens or scoped names', function () {
      assert.strictEqual(formatKey('aws-sdk'), "'aws-sdk'")
      assert.strictEqual(formatKey('@scope/pkg'), "'@scope/pkg'")
    })
  })

  describe('hasTopLevelKey', function () {
    it('finds existing top-level keys', function () {
      assert.strictEqual(hasTopLevelKey(SAMPLE_EXTERNALS, 'ai'), true)
      assert.strictEqual(hasTopLevelKey(SAMPLE_EXTERNALS, 'mocha'), true)
      assert.strictEqual(hasTopLevelKey(SAMPLE_EXTERNALS, 'ws'), true)
    })

    it('returns false for missing keys', function () {
      assert.strictEqual(hasTopLevelKey(SAMPLE_EXTERNALS, 'genkit'), false)
      assert.strictEqual(hasTopLevelKey(SAMPLE_EXTERNALS, 'redis'), false)
    })

    it('does not match nested entry names like `name: \'mocha\'`', function () {
      // 'mocha' appears both as a top-level key and as a nested `name:` value.
      // Should still report true (top-level match), but for unique nested-only names should be false.
      assert.strictEqual(hasTopLevelKey(SAMPLE_EXTERNALS, 'mocha'), true)
    })
  })

  describe('insertNewEntry', function () {
    it('inserts a new entry before the closing brace', function () {
      const subModules = [{ name: '@genkit-ai/core', version: '>=1.0.0' }]
      const updated = insertNewEntry(SAMPLE_EXTERNALS, 'genkit', subModules)

      assert.match(updated, /genkit:\s*\[/)
      assert.match(updated, /name: '@genkit-ai\/core'/)
      assert.match(updated, /versions: \['>=1\.0\.0'\]/)
    })

    it('preserves the require(...) line verbatim', function () {
      const updated = insertNewEntry(SAMPLE_EXTERNALS, 'genkit', [
        { name: 'foo', version: '>=1.0.0' },
      ])
      assert.ok(
        updated.includes("const { DD_MAJOR } = require('../../../../version')"),
        'expected require(...) line to be preserved'
      )
    })

    it('preserves DD_MAJOR ternary expressions verbatim', function () {
      const updated = insertNewEntry(SAMPLE_EXTERNALS, 'genkit', [
        { name: 'foo', version: '>=1.0.0' },
      ])
      assert.ok(
        updated.includes("versions: DD_MAJOR >= 6 ? ['>=8.0.0'] : ['>=5.2.0', '>=8.0.0'],"),
        'expected DD_MAJOR ternary to be preserved verbatim'
      )
    })

    it('preserves all pre-existing entries', function () {
      const updated = insertNewEntry(SAMPLE_EXTERNALS, 'genkit', [
        { name: 'foo', version: '>=1.0.0' },
      ])
      // ai, mocha, ws all still present.
      assert.match(updated, /\bai:\s*\[/)
      assert.match(updated, /\bmocha:\s*\[/)
      assert.match(updated, /\bws:\s*\[/)
    })

    it('quotes scoped/hyphenated keys', function () {
      const updated = insertNewEntry(SAMPLE_EXTERNALS, '@scope/pkg', [
        { name: 'foo', version: '>=1.0.0' },
      ])
      assert.match(updated, /'@scope\/pkg':\s*\[/)
    })
  })

  describe('updateExternals', function () {
    let tmpDir

    beforeEach(function () {
      tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'externals-test-'))
      const targetPath = path.join(tmpDir, 'packages', 'dd-trace', 'test', 'plugins')
      fs.mkdirSync(targetPath, { recursive: true })
      fs.writeFileSync(path.join(targetPath, 'externals.js'), SAMPLE_EXTERNALS)
    })

    afterEach(function () {
      fs.rmSync(tmpDir, { recursive: true, force: true })
    })

    function readExternals () {
      return fs.readFileSync(
        path.join(tmpDir, 'packages', 'dd-trace', 'test', 'plugins', 'externals.js'),
        'utf8'
      )
    }

    it('does not crash on a file containing DD_MAJOR ternaries', async function () {
      const analysis = makeAnalysis([
        { module_name: '@genkit-ai/core', version_range: '^1.0.0' },
      ])
      // Must not throw "DD_MAJOR is not defined".
      await updateExternals(tmpDir, 'genkit', analysis)
    })

    it('inserts a new entry while preserving require and ternary', async function () {
      const analysis = makeAnalysis([
        { module_name: '@genkit-ai/core', version_range: '^1.0.0' },
        { module_name: '@genkit-ai/google-genai', version_range: '^1.0.0' },
      ])
      await updateExternals(tmpDir, 'genkit', analysis)

      const updated = readExternals()

      // New entry is in.
      assert.match(updated, /genkit:\s*\[/)
      assert.match(updated, /name: '@genkit-ai\/core'/)
      assert.match(updated, /name: '@genkit-ai\/google-genai'/)
      assert.match(updated, /versions: \['>=1\.0\.0'\]/)

      // Original `require` line untouched.
      assert.ok(
        updated.includes("const { DD_MAJOR } = require('../../../../version')"),
        'require(...) line must be preserved'
      )

      // Original DD_MAJOR ternary untouched.
      assert.ok(
        updated.includes("versions: DD_MAJOR >= 6 ? ['>=8.0.0'] : ['>=5.2.0', '>=8.0.0'],"),
        'DD_MAJOR ternary must be preserved verbatim'
      )

      // Original entries still present.
      assert.match(updated, /\bai:\s*\[/)
      assert.match(updated, /\bmocha:\s*\[/)
      assert.match(updated, /\bws:\s*\[/)
    })

    it('skips when entry already exists (non-destructive)', async function () {
      const before = readExternals()
      const analysis = makeAnalysis([
        { module_name: 'mocha-each', version_range: '^2.0.0' },
      ])
      await updateExternals(tmpDir, 'mocha', analysis)
      const after = readExternals()
      assert.strictEqual(after, before, 'file should be unchanged when key already exists')
    })

    it('is a no-op when there are no sub-modules', async function () {
      const before = readExternals()
      const analysis = makeAnalysis([
        // Same as main package — gets filtered out by extractSubModules.
        { module_name: 'genkit', version_range: '^1.0.0' },
      ])
      await updateExternals(tmpDir, 'genkit', analysis)
      const after = readExternals()
      assert.strictEqual(after, before)
    })
  })

  describe('extractSubModules', function () {
    it('skips entries matching the main package name', function () {
      const analysis = makeAnalysis([
        { module_name: 'genkit', version_range: '^1.0.0' },
        { module_name: '@genkit-ai/core', version_range: '^1.0.0' },
      ])
      const result = extractSubModules(analysis, 'genkit')
      assert.deepStrictEqual(result, [{ name: '@genkit-ai/core', version: '>=1.0.0' }])
    })

    it('deduplicates by module_name', function () {
      const analysis = makeAnalysis([
        { module_name: '@genkit-ai/core', version_range: '^1.0.0' },
        { module_name: '@genkit-ai/core', version_range: '^1.0.0' },
      ])
      const result = extractSubModules(analysis, 'genkit')
      assert.strictEqual(result.length, 1)
    })

    it('converts ^ prefix to >=', function () {
      const analysis = makeAnalysis([
        { module_name: 'foo', version_range: '^1.2.3' },
      ])
      const [mod] = extractSubModules(analysis, 'genkit')
      assert.strictEqual(mod.version, '>=1.2.3')
    })
  })
})
