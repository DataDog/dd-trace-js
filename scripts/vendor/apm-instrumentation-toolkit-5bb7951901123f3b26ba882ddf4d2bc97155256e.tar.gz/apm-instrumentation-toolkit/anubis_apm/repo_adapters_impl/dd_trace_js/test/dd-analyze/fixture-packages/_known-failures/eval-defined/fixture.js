'use strict'

/**
 * PATTERN: Methods defined via eval/new Function
 *
 * STATIC ANALYSIS FAILURE (runtime passes):
 * - Static analyzer cannot evaluate strings
 * - Method names are in strings, not AST
 * - Runtime executes eval and creates methods normally
 *
 * This tests that static analysis properly fails on dynamic code.
 */

class Canonical {
  constructor () {
    this._value = null
  }

  // Regular getter/setter (these work)
  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

// Methods defined via eval (static analysis impossible)
eval(`
  Canonical.prototype.method_sync_1 = function() {
    return 'sync'
  }
`)

eval(`
  Canonical.prototype.method_async_1 = async function() {
    return 'async'
  }
`)

eval(`
  Canonical.method_static_1 = function() {
    return 'static'
  }
`)

module.exports = { Canonical }
