'use strict'

/**
 * Runtime Introspector
 *
 * Uses JavaScript reflection to discover classes and methods from fixtures.
 * This provides ground truth - it sees exactly what the JS engine sees.
 */

const path = require('path')

function isES6Class (fn) {
  if (typeof fn !== 'function') return false
  const str = fn.toString()
  return str.startsWith('class ') || str.startsWith('class{')
}

function isClassLike (fn) {
  if (typeof fn !== 'function') return false
  if (isES6Class(fn)) return true
  if (fn.prototype && Object.getOwnPropertyNames(fn.prototype).length > 1) return true
  return false
}

function getMethodFromDescriptor (name, desc, isStatic) {
  const methods = []
  if (desc.get) methods.push({ name, kind: 'get', isAsync: false, isStatic })
  if (desc.set) methods.push({ name, kind: 'set', isAsync: false, isStatic })
  if (desc.value && typeof desc.value === 'function') {
    const ctorName = desc.value.constructor.name
    const isAsync = ctorName === 'AsyncFunction' || ctorName === 'AsyncGeneratorFunction'
    const isGenerator = ctorName === 'GeneratorFunction' || ctorName === 'AsyncGeneratorFunction'
    const method = { name, kind: 'method', isAsync, isStatic }
    if (isGenerator) method.isGenerator = true
    methods.push(method)
  }
  return methods
}

function resolveSymbolName (sym) {
  const desc = sym.description || sym.toString()
  return desc.replace(/^Symbol\(|\)$/g, '')
}

function introspectClass (name, cls) {
  const classInfo = { name, isPrototypeBased: !isES6Class(cls), methods: [] }
  const seen = new Set()

  // Instance methods from prototype (including Symbols)
  if (cls.prototype) {
    const allKeys = [...Object.getOwnPropertyNames(cls.prototype), ...Object.getOwnPropertySymbols(cls.prototype)]
    for (const key of allKeys) {
      const methodName = typeof key === 'symbol' ? resolveSymbolName(key) : key
      if (methodName === 'constructor' || seen.has(methodName)) continue
      seen.add(methodName)
      const desc = Object.getOwnPropertyDescriptor(cls.prototype, key)
      classInfo.methods.push(...getMethodFromDescriptor(methodName, desc, false))
    }
  }

  // Arrow function class fields (instance properties) - try to instantiate
  if (isES6Class(cls)) {
    try {
      const instance = Object.create(cls.prototype)
      cls.call(instance) // May fail if constructor needs args
    } catch (e) { /* ignore */ }
    try {
      const instance = new cls()
      for (const key of [...Object.getOwnPropertyNames(instance), ...Object.getOwnPropertySymbols(instance)]) {
        const methodName = typeof key === 'symbol' ? resolveSymbolName(key) : key
        if (seen.has(methodName)) continue
        const value = instance[key]
        if (typeof value === 'function') {
          seen.add(methodName)
          const ctorName = value.constructor.name
          const isAsync = ctorName === 'AsyncFunction' || ctorName === 'AsyncGeneratorFunction'
          classInfo.methods.push({ name: methodName, kind: 'method', isAsync, isStatic: false })
        }
      }
    } catch (e) { /* class may need constructor args */ }
  }

  // Static methods (including Symbols)
  const builtins = ['length', 'name', 'prototype', 'arguments', 'caller', 'super_']
  const staticKeys = [...Object.getOwnPropertyNames(cls), ...Object.getOwnPropertySymbols(cls)]
  for (const key of staticKeys) {
    const propName = typeof key === 'symbol' ? resolveSymbolName(key) : key
    if (builtins.includes(propName) || seen.has(propName)) continue
    try {
      const value = cls[key]
      if (typeof value === 'function') {
        seen.add(propName)
        const ctorName = value.constructor.name
        const isAsync = ctorName === 'AsyncFunction' || ctorName === 'AsyncGeneratorFunction'
        classInfo.methods.push({ name: propName, kind: 'method', isAsync, isStatic: true })
      }
    } catch (e) { /* some properties throw on access */ }
  }

  classInfo.methods.sort((a, b) => a.name.localeCompare(b.name))
  return classInfo
}

function introspectObject (name, obj) {
  const classInfo = { name, isObjectLiteral: true, methods: [] }
  const allKeys = [...Object.getOwnPropertyNames(obj), ...Object.getOwnPropertySymbols(obj)]
  for (const key of allKeys) {
    const methodName = typeof key === 'symbol' ? resolveSymbolName(key) : key
    if (methodName.startsWith('_')) continue // skip private
    const desc = Object.getOwnPropertyDescriptor(obj, key)
    classInfo.methods.push(...getMethodFromDescriptor(methodName, desc, false))
  }
  classInfo.methods.sort((a, b) => a.name.localeCompare(b.name))
  return classInfo
}

function isPlainObject (val) {
  return val && typeof val === 'object' && !Array.isArray(val) && Object.getPrototypeOf(val) === Object.prototype
}

function hasMethodProperties (obj) {
  if (!isPlainObject(obj)) return false
  return Object.values(Object.getOwnPropertyDescriptors(obj)).some(d => d.get || d.set || typeof d.value === 'function')
}

function introspectFixtureDir (dirPath) {
  const fixturePath = path.join(dirPath, 'fixture.js')
  delete require.cache[require.resolve(fixturePath)]

  const mod = require(fixturePath)
  const result = { classes: [], functions: [] }

  // Handle default export pattern: module.exports = Class
  if (typeof mod === 'function' && isClassLike(mod)) {
    result.classes.push(introspectClass(mod.name, mod))
  }

  // Handle named exports: module.exports = { ClassName: Class|Object|Factory }
  for (const [name, value] of Object.entries(mod)) {
    if (typeof value === 'function') {
      if (isClassLike(value)) {
        result.classes.push(introspectClass(name, value))
      } else {
        // Try as factory function - call it and inspect result
        try {
          const instance = value({}) // Pass empty config
          if (hasMethodProperties(instance)) {
            const info = introspectObject(name, instance)
            // Add static methods from factory function itself
            for (const key of Object.getOwnPropertyNames(value)) {
              if (['length', 'name', 'prototype', 'arguments', 'caller'].includes(key)) continue
              if (typeof value[key] === 'function') {
                const ctorName = value[key].constructor.name
                const isAsync = ctorName === 'AsyncFunction'
                info.methods.push({ name: key, kind: 'method', isAsync, isStatic: true })
              }
            }
            info.methods.sort((a, b) => a.name.localeCompare(b.name))
            result.classes.push(info)
          }
        } catch (e) { /* factory needs specific args */ }
      }
    } else if (hasMethodProperties(value)) {
      // Object literal API
      result.classes.push(introspectObject(name, value))
    }
  }

  result.classes.sort((a, b) => a.name.localeCompare(b.name))
  return result
}

module.exports = {
  isClassLike,
  introspectClass,
  introspectFixtureDir
}
