'use strict'

/**
 * PATTERN: Class extending base class
 *
 * ES6 class that extends another class.
 * Methods could be inherited, overridden, or new.
 */

class BaseClass {
  // Base has different methods - not part of Canonical interface
  baseMethod () {
    return 'base'
  }
}

class Canonical extends BaseClass {
  constructor () {
    super()
    this._value = null
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

module.exports = { Canonical }
