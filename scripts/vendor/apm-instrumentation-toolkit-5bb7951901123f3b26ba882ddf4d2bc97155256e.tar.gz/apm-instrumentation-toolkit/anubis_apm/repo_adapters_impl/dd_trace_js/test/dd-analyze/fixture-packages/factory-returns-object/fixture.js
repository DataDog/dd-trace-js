'use strict'

/**
 * PATTERN: Factory returning object literal
 *
 * KNOWN FAILURE: Cannot match ground truth because:
 * - No class/constructor exists
 * - No concept of "static" methods
 * - Each call returns a new object
 *
 * Static analyzer would need to trace return value.
 */

function createCanonical () {
  return {
    _value: null,

    method_sync_1 () {
      return 'sync'
    },

    async method_async_1 () {
      return 'async'
    },

    // No static possible - this is instance-level
    // method_static_1 would need to be on factory itself

    get method_getter_1 () {
      return this._value
    },

    set method_setter_1 (val) {
      this._value = val
    }
  }
}

// Static on factory function (different from class static)
createCanonical.method_static_1 = function () {
  return 'static'
}

module.exports = { Canonical: createCanonical }
