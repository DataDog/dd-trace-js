'use strict'

/**
 * PATTERN: Object.defineProperty for all methods
 *
 * All methods defined via Object.defineProperty.
 * Sometimes used for non-enumerable methods or precise control.
 */

function Canonical () {
  this._value = null
}

Object.defineProperty(Canonical.prototype, 'method_sync_1', {
  value: function () {
    return 'sync'
  },
  writable: true,
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_async_1', {
  value: async function () {
    return 'async'
  },
  writable: true,
  configurable: true
})

// Static via defineProperty on constructor
Object.defineProperty(Canonical, 'method_static_1', {
  value: function () {
    return 'static'
  },
  writable: true,
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_getter_1', {
  get () {
    return this._value
  },
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_setter_1', {
  set (val) {
    this._value = val
  },
  configurable: true
})

module.exports = { Canonical }
