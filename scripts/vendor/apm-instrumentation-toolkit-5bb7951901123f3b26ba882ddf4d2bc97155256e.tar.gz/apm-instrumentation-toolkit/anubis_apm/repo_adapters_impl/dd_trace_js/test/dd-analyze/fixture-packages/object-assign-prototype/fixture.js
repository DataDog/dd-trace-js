'use strict'

/**
 * PATTERN: Object.assign to prototype
 *
 * Methods added via Object.assign(Constructor.prototype, { ... })
 * Common in older codebases and some libraries.
 */

function Canonical () {
  this._value = null
}

// Instance methods via Object.assign
Object.assign(Canonical.prototype, {
  method_sync_1 () {
    return 'sync'
  },

  async method_async_1 () {
    return 'async'
  }
})

// Static method
Canonical.method_static_1 = function () {
  return 'static'
}

// Getter/setter via defineProperty
Object.defineProperty(Canonical.prototype, 'method_getter_1', {
  get () {
    return this._value
  },
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_setter_1', {
  set (val) {
    this._value = val
  },
  configurable: true
})

module.exports = { Canonical }
