'use strict'

/**
 * PATTERN: Webpack/bundler output style
 *
 * Simplified version of how bundlers wrap modules.
 * Each module in a function, exports passed as parameter.
 */

// Simulated webpack runtime
const __webpack_modules__ = {
  './canonical': function (module, exports) {
    class Canonical {
      constructor () {
        this._value = null
      }

      method_sync_1 () {
        return 'sync'
      }

      async method_async_1 () {
        return 'async'
      }

      static method_static_1 () {
        return 'static'
      }

      get method_getter_1 () {
        return this._value
      }

      set method_setter_1 (val) {
        this._value = val
      }
    }

    module.exports = { Canonical }
  }
}

// Simulated webpack require
function __webpack_require__ (moduleId) {
  const module = { exports: {} }
  __webpack_modules__[moduleId](module, module.exports)
  return module.exports
}

// Export the canonical class
const { Canonical } = __webpack_require__('./canonical')

module.exports = { Canonical }
