'use strict'

/**
 * PATTERN: ES6 Class Declaration
 *
 * Standard ES6 class syntax with class keyword.
 */

class Canonical {
  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

module.exports = { Canonical }
