'use strict'

/**
 * PATTERN: Default export (module.exports = Class)
 *
 * Class IS the entire export, not a property of exports.
 * Common pattern: const Foo = require('foo') gives you the class directly.
 */

class Canonical {
  constructor () {
    this._value = null
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

// Class IS the export (default style)
module.exports = Canonical
