'use strict'

/**
 * PATTERN: Computed property names from constants
 *
 * Method names derived from const variables.
 * Static analyzer must resolve the const to get method name.
 */

const SYNC_METHOD = 'method_sync_1'
const ASYNC_METHOD = 'method_async_1'
const STATIC_METHOD = 'method_static_1'
const GETTER_NAME = 'method_getter_1'
const SETTER_NAME = 'method_setter_1'

class Canonical {
  constructor () {
    this._value = null
  }

  [SYNC_METHOD] () {
    return 'sync'
  }

  async [ASYNC_METHOD] () {
    return 'async'
  }

  static [STATIC_METHOD] () {
    return 'static'
  }

  get [GETTER_NAME] () {
    return this._value
  }

  set [SETTER_NAME] (val) {
    this._value = val
  }
}

module.exports = { Canonical }
