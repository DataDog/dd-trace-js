'use strict'

/**
 * PATTERN: TypeScript compiled output (ES5 target)
 *
 * How TypeScript compiles ES6 classes when targeting ES5.
 * Uses __extends helper for inheritance, defineProperty for accessors.
 */

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
  function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value) }) }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) { try { step(generator.next(value)) } catch (e) { reject(e) } }
    function rejected(value) { try { step(generator['throw'](value)) } catch (e) { reject(e) } }
    function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected) }
    step((generator = generator.apply(thisArg, _arguments || [])).next())
  })
}

Object.defineProperty(exports, '__esModule', { value: true })
exports.Canonical = void 0

var Canonical = /** @class */ (function () {
  function Canonical () {
    this._value = null
  }

  Canonical.prototype.method_sync_1 = function () {
    return 'sync'
  }

  Canonical.prototype.method_async_1 = async function () {
    // Real tslib uses __awaiter, but we need async for runtime detection
    return 'async'
  }

  Canonical.method_static_1 = function () {
    return 'static'
  }

  Object.defineProperty(Canonical.prototype, 'method_getter_1', {
    get: function () {
      return this._value
    },
    enumerable: false,
    configurable: true
  })

  Object.defineProperty(Canonical.prototype, 'method_setter_1', {
    set: function (val) {
      this._value = val
    },
    enumerable: false,
    configurable: true
  })

  return Canonical
}())

exports.Canonical = Canonical
