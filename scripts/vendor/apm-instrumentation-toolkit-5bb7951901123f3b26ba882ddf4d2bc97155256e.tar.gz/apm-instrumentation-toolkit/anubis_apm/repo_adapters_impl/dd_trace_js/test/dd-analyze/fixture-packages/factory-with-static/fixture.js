'use strict'

/**
 * PATTERN: Factory function with static method
 *
 * Factory that creates instances. Static method on factory itself.
 * The factory IS the "class" from runtime perspective.
 */

function Canonical () {
  this._value = null
}

Canonical.prototype.method_sync_1 = function () {
  return 'sync'
}

Canonical.prototype.method_async_1 = async function () {
  return 'async'
}

// Static method on the constructor/factory
Canonical.method_static_1 = function () {
  return 'static'
}

Object.defineProperty(Canonical.prototype, 'method_getter_1', {
  get: function () {
    return this._value
  },
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_setter_1', {
  set: function (val) {
    this._value = val
  },
  configurable: true
})

module.exports = { Canonical }
