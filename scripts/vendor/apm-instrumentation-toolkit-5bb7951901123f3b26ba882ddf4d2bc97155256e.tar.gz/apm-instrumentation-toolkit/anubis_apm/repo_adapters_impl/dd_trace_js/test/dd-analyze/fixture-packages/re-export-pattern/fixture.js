'use strict'

/**
 * PATTERN: Re-export
 *
 * Module that re-exports from another file.
 * Static analyzer must follow the require() chain.
 */

module.exports = require('./_source')
