'use strict'

/**
 * PATTERN: Conditional method definition
 *
 * Methods added conditionally based on environment/config.
 * Static analyzer sees all paths, runtime only sees executed paths.
 */

class Canonical {
  constructor () {
    this._value = null
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

// Always true in this fixture (but static analyzer can't know)
const FEATURE_SYNC = true
const FEATURE_ASYNC = true

if (FEATURE_SYNC) {
  Canonical.prototype.method_sync_1 = function () {
    return 'sync'
  }
}

if (FEATURE_ASYNC) {
  Canonical.prototype.method_async_1 = async function () {
    return 'async'
  }
}

// Static always added
Canonical.method_static_1 = function () {
  return 'static'
}

module.exports = { Canonical }
