'use strict'

/**
 * PATTERN: Mixin pattern
 *
 * Methods come from multiple mixin objects merged into prototype.
 * Common for composing behavior from multiple sources.
 */

const syncMixin = {
  method_sync_1 () {
    return 'sync'
  }
}

const asyncMixin = {
  async method_async_1 () {
    return 'async'
  }
}

function Canonical () {
  this._value = null
}

// Merge mixins into prototype
Object.assign(Canonical.prototype, syncMixin, asyncMixin)

// Static method
Canonical.method_static_1 = function () {
  return 'static'
}

// Getter/setter
Object.defineProperty(Canonical.prototype, 'method_getter_1', {
  get () {
    return this._value
  },
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_setter_1', {
  set (val) {
    this._value = val
  },
  configurable: true
})

module.exports = { Canonical }
