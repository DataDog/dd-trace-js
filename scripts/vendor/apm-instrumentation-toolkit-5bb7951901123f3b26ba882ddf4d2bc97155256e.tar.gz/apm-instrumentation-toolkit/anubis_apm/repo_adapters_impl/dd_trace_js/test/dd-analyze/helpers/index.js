'use strict'

/**
 * Test helpers for dd-analyze fixture validation
 */

const validator = require('./ground-truth-validator')
const introspector = require('./runtime-introspector')

module.exports = {
  loadGroundTruth: validator.loadGroundTruth,
  compareToGroundTruth: validator.compareToGroundTruth,
  introspectFixtureDir: introspector.introspectFixtureDir,
  introspectClass: introspector.introspectClass,
  isClassLike: introspector.isClassLike
}
