'use strict'

/**
 * PATTERN: Prototype-based Class
 *
 * Constructor function with methods on prototype.
 * Note: Getters/setters use Object.defineProperty on prototype.
 * Note: Static methods are properties on the constructor function.
 */

function Canonical () {
  this._value = null
}

Canonical.prototype.method_sync_1 = function () {
  return 'sync'
}

Canonical.prototype.method_async_1 = async function () {
  return 'async'
}

// Static method on constructor
Canonical.method_static_1 = function () {
  return 'static'
}

// Getter/setter via defineProperty
Object.defineProperty(Canonical.prototype, 'method_getter_1', {
  get: function () {
    return this._value
  },
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_setter_1', {
  set: function (val) {
    this._value = val
  },
  configurable: true
})

module.exports = { Canonical }
