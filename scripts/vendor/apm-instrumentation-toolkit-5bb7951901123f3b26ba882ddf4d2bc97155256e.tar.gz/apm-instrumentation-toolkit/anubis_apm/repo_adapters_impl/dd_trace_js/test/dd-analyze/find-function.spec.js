'use strict'

const assert = require('assert')
const path = require('path')
const { findFunction, extractAllMethods } = require('../../dd-analyze/src/analyzers')
const groundTruths = require('./expectations/target-ground-truths.json')

const NODE_MODULES = path.join(__dirname, '../../node_modules')

function getMatch (result) {
  if (!result) return null
  return result.matches ? result.matches[0] : result
}

function assertFindResult (result, target) {
  const label = target.className
    ? `${target.package}:${target.className}.${target.methodName}`
    : `${target.package}:${target.functionName}`

  assert.ok(result, `Expected to find ${label}`)

  const match = getMatch(result)
  assert.ok(match, `Expected at least one match for ${label}`)
  assert.strictEqual(match.found, true, `Expected found=true for ${label}`)
  assert.ok(match.location?.file, `Expected file location for ${label}`)
  assert.ok(match.location?.line > 0, `Expected line number for ${label}`)

  // Validate expected file
  assert.strictEqual(
    match.location.file,
    target.expectedFile,
    `Expected ${label} in ${target.expectedFile}, found in ${match.location.file}`
  )

  // Validate isAsync
  const actualIsAsync = match.functionQuery?.kind === 'Async'
  assert.strictEqual(
    actualIsAsync,
    target.isAsync,
    `Expected ${label} isAsync=${target.isAsync}, got ${actualIsAsync}`
  )
}

describe('dd-analyze', function () {
  this.timeout(5000)

  describe('findFunction', function () {
    const categories = [...new Set(groundTruths.targets.map(t => t.category))]

    for (const category of categories) {
      describe(category, function () {
        for (const target of groundTruths.targets.filter(t => t.category === category)) {
          const label = target.className
            ? `${target.package}:${target.className}.${target.methodName}`
            : `${target.package}:${target.functionName}`

          it(`should find ${label}`, function () {
            const packagePath = path.join(NODE_MODULES, target.package)
            const result = findFunction(
              packagePath,
              target.methodName || target.functionName,
              target.className || null
            )

            assertFindResult(result, target)
          })
        }
      })
    }
  })

  describe('extractAllMethods', function () {
    // Group targets by package to avoid redundant extractions
    const packages = [...new Set(groundTruths.targets.map(t => t.package))]
    const extractionCache = new Map()

    function getExtraction (pkg) {
      if (!extractionCache.has(pkg)) {
        const packagePath = path.join(NODE_MODULES, pkg)
        extractionCache.set(pkg, extractAllMethods(packagePath))
      }
      return extractionCache.get(pkg)
    }

    for (const pkg of packages) {
      const targets = groundTruths.targets.filter(t => t.package === pkg)

      describe(pkg, function () {
        for (const target of targets) {
          if (target.className) {
            // Class method target
            const label = `${target.className}.${target.methodName}`

            it(`should extract ${label} in ${target.expectedFile}`, function () {
              const result = getExtraction(pkg)

              // Find class with matching name AND file
              const cls = result.classes.find(c =>
                c.name === target.className && c.file === target.expectedFile
              )

              assert.ok(cls, `Expected to find class ${target.className} in ${target.expectedFile}. ` +
                `Found classes: ${result.classes.filter(c => c.name === target.className).map(c => c.file).join(', ') || 'none'}`)

              // Find method on class
              const method = cls.methods.find(m => m.name === target.methodName)
              assert.ok(method, `Expected to find method ${target.methodName} on ${target.className}. ` +
                `Found methods: ${cls.methods.map(m => m.name).join(', ')}`)

              // Validate isAsync
              assert.strictEqual(
                method.isAsync,
                target.isAsync,
                `Expected ${label} isAsync=${target.isAsync}, got ${method.isAsync}`
              )
            })
          } else {
            // Standalone function target
            it(`should extract function ${target.functionName} in ${target.expectedFile}`, function () {
              const result = getExtraction(pkg)

              const fn = result.functions.find(f =>
                f.name === target.functionName && f.file === target.expectedFile
              )

              assert.ok(fn, `Expected to find function ${target.functionName} in ${target.expectedFile}. ` +
                `Found: ${result.functions.filter(f => f.name === target.functionName).map(f => f.file).join(', ') || 'none'}`)

              assert.strictEqual(
                fn.isAsync,
                target.isAsync,
                `Expected ${target.functionName} isAsync=${target.isAsync}, got ${fn.isAsync}`
              )
            })
          }
        }
      })
    }
  })
})
