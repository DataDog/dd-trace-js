'use strict'

const assert = require('assert')
const path = require('path')
const fs = require('fs')
const {
  loadGroundTruth,
  compareToGroundTruth,
  introspectFixtureDir,
  introspectClass,
  isClassLike
} = require('./helpers')

const PACKAGES_PATH = path.join(__dirname, 'fixture-packages')

function getPatternDirs (basePath) {
  return fs.readdirSync(basePath, { withFileTypes: true })
    .filter(d => d.isDirectory() && !d.name.startsWith('_'))
    .map(d => d.name)
    .sort()
}

async function introspectEsmFixture (fixturePath) {
  const mod = await import('file://' + fixturePath)

  // Default export
  if (mod.default && typeof mod.default === 'function') {
    return {
      classes: [introspectClass(mod.default.name || 'default', mod.default)],
      functions: []
    }
  }

  // Named exports
  const result = { classes: [], functions: [] }
  for (const [name, value] of Object.entries(mod)) {
    if (name === 'default') continue
    if (typeof value === 'function' && isClassLike(value)) {
      result.classes.push(introspectClass(name, value))
    }
  }
  result.classes.sort((a, b) => a.name.localeCompare(b.name))
  return result
}

describe('runtime-introspector', function () {
  const groundTruth = loadGroundTruth(PACKAGES_PATH)
  const patterns = getPatternDirs(PACKAGES_PATH)

  for (const pattern of patterns) {
    const patternPath = path.join(PACKAGES_PATH, pattern)
    const cjsPath = path.join(patternPath, 'fixture.js')
    const esmPath = path.join(patternPath, 'fixture.mjs')
    const hasCjs = fs.existsSync(cjsPath)
    const hasEsm = fs.existsSync(esmPath)

    if (!hasCjs && !hasEsm) continue

    const isEsm = !hasCjs && hasEsm
    const label = isEsm ? `${pattern} (ESM)` : pattern

    it(`should extract correct methods from ${label}`, async function () {
      const runtimeResult = isEsm
        ? await introspectEsmFixture(esmPath)
        : introspectFixtureDir(patternPath)

      const canonicalClass = runtimeResult.classes.find(c => c.name === 'Canonical')
      assert.ok(canonicalClass, 'Canonical class not found')

      const normalized = {
        classes: [{
          name: canonicalClass.name,
          methods: canonicalClass.methods.map(m => ({
            name: m.name,
            kind: m.kind,
            isAsync: m.isAsync,
            isStatic: m.isStatic
          }))
        }],
        functions: []
      }

      const comparison = compareToGroundTruth(normalized, groundTruth)
      assert.ok(comparison.valid, `Diffs: ${JSON.stringify(comparison.diffs, null, 2)}`)
    })
  }
})
