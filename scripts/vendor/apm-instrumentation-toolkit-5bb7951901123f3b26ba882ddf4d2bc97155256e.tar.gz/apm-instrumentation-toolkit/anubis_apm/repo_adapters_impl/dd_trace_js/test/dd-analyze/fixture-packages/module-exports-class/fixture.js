'use strict'

/**
 * PATTERN: module.exports = class
 *
 * Class as the entire module export (common in Node.js).
 * Exported as { Canonical } for consistency with other patterns.
 */

class Canonical {
  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

module.exports = { Canonical }
