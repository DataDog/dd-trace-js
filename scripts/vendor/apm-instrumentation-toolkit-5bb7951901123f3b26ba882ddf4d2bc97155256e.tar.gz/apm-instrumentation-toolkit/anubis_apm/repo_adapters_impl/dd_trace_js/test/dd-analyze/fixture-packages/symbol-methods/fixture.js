'use strict'

/**
 * PATTERN: Symbol-keyed methods
 *
 * KNOWN FAILURE: Cannot match ground truth because:
 * - Method names are Symbols, not strings
 * - Ground truth uses string names
 * - Symbols are unique, can't match "method_sync_1"
 */

const METHOD_SYNC = Symbol('method_sync_1')
const METHOD_ASYNC = Symbol('method_async_1')
const METHOD_STATIC = Symbol('method_static_1')
const METHOD_GETTER = Symbol('method_getter_1')
const METHOD_SETTER = Symbol('method_setter_1')

class Canonical {
  constructor () {
    this._value = null
  }

  [METHOD_SYNC] () {
    return 'sync'
  }

  async [METHOD_ASYNC] () {
    return 'async'
  }

  static [METHOD_STATIC] () {
    return 'static'
  }

  get [METHOD_GETTER] () {
    return this._value
  }

  set [METHOD_SETTER] (val) {
    this._value = val
  }
}

module.exports = { Canonical }
