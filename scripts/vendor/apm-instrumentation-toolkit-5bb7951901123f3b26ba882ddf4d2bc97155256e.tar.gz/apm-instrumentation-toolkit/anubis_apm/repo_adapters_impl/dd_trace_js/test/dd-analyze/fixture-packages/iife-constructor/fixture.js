'use strict'

/**
 * PATTERN: IIFE returning constructor
 *
 * Immediately Invoked Function Expression that returns a constructor.
 * Common pattern for encapsulation and private variables.
 */

const Canonical = (function () {
  // Private variable (shared across instances if needed)
  const _privateStatic = 'hidden'

  function Canonical () {
    this._value = null
  }

  Canonical.prototype.method_sync_1 = function () {
    return 'sync'
  }

  Canonical.prototype.method_async_1 = async function () {
    return 'async'
  }

  Canonical.method_static_1 = function () {
    return 'static'
  }

  Object.defineProperty(Canonical.prototype, 'method_getter_1', {
    get: function () {
      return this._value
    },
    configurable: true
  })

  Object.defineProperty(Canonical.prototype, 'method_setter_1', {
    set: function (val) {
      this._value = val
    },
    configurable: true
  })

  return Canonical
})()

module.exports = { Canonical }
