'use strict'

/**
 * PATTERN: Object.create with prototype
 *
 * Using Object.create() to set up prototype chain.
 * Older pattern, sometimes used for precise prototype control.
 */

function Canonical () {
  this._value = null
}

// Define prototype using Object.create with property descriptors
Canonical.prototype = Object.create(Object.prototype, {
  constructor: {
    value: Canonical,
    writable: true,
    configurable: true
  },
  method_sync_1: {
    value: function () {
      return 'sync'
    },
    writable: true,
    configurable: true
  },
  method_async_1: {
    value: async function () {
      return 'async'
    },
    writable: true,
    configurable: true
  },
  method_getter_1: {
    get: function () {
      return this._value
    },
    configurable: true
  },
  method_setter_1: {
    set: function (val) {
      this._value = val
    },
    configurable: true
  }
})

// Static method
Canonical.method_static_1 = function () {
  return 'static'
}

module.exports = { Canonical }
