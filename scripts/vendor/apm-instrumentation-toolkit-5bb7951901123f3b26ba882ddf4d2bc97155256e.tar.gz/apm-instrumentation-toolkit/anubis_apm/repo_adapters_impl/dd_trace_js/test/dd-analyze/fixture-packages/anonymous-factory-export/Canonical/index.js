'use strict'

/**
 * PATTERN: Anonymous factory function exported directly
 *
 * Common in libraries like kafkajs where:
 *   module.exports = ({ config }) => { return { methods... } }
 *
 * The "class" name is derived from the file/folder name.
 */

module.exports = ({ config, logger }) => {
  let _value = null

  return {
    method_sync_1 () {
      return 'sync'
    },

    async method_async_1 () {
      return 'async'
    },

    get method_getter_1 () {
      return _value
    },

    set method_setter_1 (val) {
      _value = val
    }
  }
}

// Static method on the exported function itself
module.exports.method_static_1 = function () {
  return 'static'
}
