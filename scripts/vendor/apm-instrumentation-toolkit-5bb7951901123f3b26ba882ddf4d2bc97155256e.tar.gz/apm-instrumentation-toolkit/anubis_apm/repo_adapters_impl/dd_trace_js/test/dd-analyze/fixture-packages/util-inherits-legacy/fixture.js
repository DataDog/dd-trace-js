'use strict'

/**
 * PATTERN: util.inherits (Node.js legacy)
 *
 * Node.js legacy inheritance pattern using util.inherits.
 * Still found in older codebases.
 */

const util = require('util')

function BaseClass () {}

function Canonical () {
  BaseClass.call(this)
  this._value = null
}

util.inherits(Canonical, BaseClass)

Canonical.prototype.method_sync_1 = function () {
  return 'sync'
}

Canonical.prototype.method_async_1 = async function () {
  return 'async'
}

Canonical.method_static_1 = function () {
  return 'static'
}

Object.defineProperty(Canonical.prototype, 'method_getter_1', {
  get: function () {
    return this._value
  },
  configurable: true
})

Object.defineProperty(Canonical.prototype, 'method_setter_1', {
  set: function (val) {
    this._value = val
  },
  configurable: true
})

module.exports = { Canonical }
