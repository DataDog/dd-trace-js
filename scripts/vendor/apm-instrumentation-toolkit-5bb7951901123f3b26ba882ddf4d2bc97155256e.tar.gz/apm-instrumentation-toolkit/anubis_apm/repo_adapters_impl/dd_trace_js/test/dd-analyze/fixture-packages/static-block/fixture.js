'use strict'

/**
 * PATTERN: Static initialization block (ES2022)
 *
 * Class with static {} block for complex static initialization.
 */

class Canonical {
  static #privateStatic

  // Static initialization block
  static {
    this.#privateStatic = 'initialized'
  }

  constructor () {
    this._value = null
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

module.exports = { Canonical }
