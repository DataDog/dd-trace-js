'use strict'

/**
 * PATTERN: Bound methods in constructor
 *
 * Methods bound to instance in constructor.
 * Common pattern for React class components and event handlers.
 */

class Canonical {
  constructor () {
    this._value = null
    // Bind methods to instance
    this.method_sync_1 = this.method_sync_1.bind(this)
    this.method_async_1 = this.method_async_1.bind(this)
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

module.exports = { Canonical }
