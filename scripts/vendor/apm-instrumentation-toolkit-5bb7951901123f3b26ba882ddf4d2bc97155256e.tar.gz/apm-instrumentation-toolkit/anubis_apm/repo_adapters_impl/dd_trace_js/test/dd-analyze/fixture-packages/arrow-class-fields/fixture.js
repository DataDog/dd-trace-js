'use strict'

/**
 * PATTERN: Arrow functions as class fields
 *
 * KNOWN FAILURE: Cannot fully match ground truth because:
 * - Arrow functions as class fields become instance properties, not prototype methods
 * - They show up on instances, not on Class.prototype
 * - Getters/setters cannot be arrow functions
 *
 * Runtime introspector checks prototype, won't find these.
 */

class Canonical {
  _value = null

  // These are instance properties, not prototype methods
  method_sync_1 = () => {
    return 'sync'
  }

  method_async_1 = async () => {
    return 'async'
  }

  // Static arrow works
  static method_static_1 = () => {
    return 'static'
  }

  // Getters/setters must be regular (cannot be arrows)
  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

module.exports = { Canonical }
