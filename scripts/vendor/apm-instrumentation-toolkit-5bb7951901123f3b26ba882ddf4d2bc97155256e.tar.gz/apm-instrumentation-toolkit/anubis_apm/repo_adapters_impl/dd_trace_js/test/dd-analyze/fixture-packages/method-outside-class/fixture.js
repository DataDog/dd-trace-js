'use strict'

/**
 * PATTERN: Methods defined outside class body
 *
 * Class declared, then methods added after via prototype.
 * Mix of inline and external method definitions.
 */

class Canonical {
  constructor () {
    this._value = null
  }

  // Only one method defined inline
  method_sync_1 () {
    return 'sync'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

// Method added after class definition
Canonical.prototype.method_async_1 = async function () {
  return 'async'
}

// Static added after class definition
Canonical.method_static_1 = function () {
  return 'static'
}

module.exports = { Canonical }
