'use strict'

/**
 * PATTERN: Manual decorator application
 *
 * Decorator-like pattern applied manually.
 * Similar to what TypeScript compiles decorators to.
 */

// Decorator functions
function logged (target, key, descriptor) {
  const original = descriptor.value
  descriptor.value = function (...args) {
    console.log(`Calling ${key}`)
    return original.apply(this, args)
  }
  return descriptor
}

class Canonical {
  constructor () {
    this._value = null
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

// Manual decorator application (like TypeScript's __decorate)
const descriptor = Object.getOwnPropertyDescriptor(Canonical.prototype, 'method_sync_1')
Object.defineProperty(
  Canonical.prototype,
  'method_sync_1',
  logged(Canonical.prototype, 'method_sync_1', descriptor)
)

module.exports = { Canonical }
