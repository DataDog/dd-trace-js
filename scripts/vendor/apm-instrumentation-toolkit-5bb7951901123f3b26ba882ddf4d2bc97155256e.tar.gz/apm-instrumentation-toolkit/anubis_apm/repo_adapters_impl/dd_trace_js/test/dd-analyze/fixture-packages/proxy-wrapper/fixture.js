'use strict'

/**
 * PATTERN: Proxy wrapper
 *
 * Class wrapped in Proxy for interception.
 * Runtime sees through proxy, static analysis may not.
 */

class _Canonical {
  constructor () {
    this._value = null
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

// Wrap class in Proxy
const Canonical = new Proxy(_Canonical, {
  construct (target, args) {
    return new target(...args)
  },
  get (target, prop) {
    return target[prop]
  }
})

module.exports = { Canonical }
