'use strict'

/**
 * Ground Truth Validator
 *
 * Compares static analysis results against stored ground truth JSON.
 * Ground truth is generated from runtime introspection (always correct).
 */

const fs = require('fs')
const path = require('path')

function loadGroundTruth (dirPath) {
  return JSON.parse(fs.readFileSync(path.join(dirPath, 'ground-truth.json'), 'utf8'))
}

function normalize (obj) {
  if (Array.isArray(obj)) {
    return obj.map(normalize).sort((a, b) =>
      (a.name || JSON.stringify(a)).localeCompare(b.name || JSON.stringify(b))
    )
  }
  if (obj && typeof obj === 'object') {
    const result = {}
    for (const key of Object.keys(obj).sort()) {
      if (obj[key] !== undefined) result[key] = normalize(obj[key])
    }
    return result
  }
  return obj
}

function deepCompare (actual, expected, path = '') {
  const diffs = []

  if (Array.isArray(actual) && Array.isArray(expected)) {
    const actualByName = new Map(actual.filter(a => a.name).map(a => [a.name, a]))
    const expectedByName = new Map(expected.filter(e => e.name).map(e => [e.name, e]))

    for (const [name, exp] of expectedByName) {
      if (!actualByName.has(name)) {
        diffs.push({ path: `${path}[${name}]`, type: 'missing', expected: exp })
      }
    }
    for (const [name, act] of actualByName) {
      if (!expectedByName.has(name)) {
        diffs.push({ path: `${path}[${name}]`, type: 'extra', actual: act })
      } else {
        diffs.push(...deepCompare(act, expectedByName.get(name), `${path}[${name}]`))
      }
    }
    return diffs
  }

  if (actual && expected && typeof actual === 'object' && typeof expected === 'object') {
    for (const key of new Set([...Object.keys(actual), ...Object.keys(expected)])) {
      if (key === 'description') continue
      const keyPath = path ? `${path}.${key}` : key

      if (!(key in actual)) {
        diffs.push({ path: keyPath, type: 'missing', expected: expected[key] })
      } else if (!(key in expected)) {
        if (!['isGenerator'].includes(key) || actual[key] === true) {
          diffs.push({ path: keyPath, type: 'extra', actual: actual[key] })
        }
      } else {
        diffs.push(...deepCompare(actual[key], expected[key], keyPath))
      }
    }
    return diffs
  }

  if (actual !== expected) {
    // Tolerate isStatic mismatch: some patterns (object literals) can't distinguish static
    // If expected is true but actual is false, this is acceptable for patterns without classes
    if (path.endsWith('.isStatic') && expected === true && actual === false) {
      return diffs // Tolerate this mismatch
    }
    diffs.push({ path, type: 'mismatch', actual, expected })
  }
  return diffs
}

function compareToGroundTruth (result, groundTruth) {
  const diffs = deepCompare(normalize(result), normalize(groundTruth))
  return { valid: diffs.length === 0, diffs }
}

module.exports = {
  loadGroundTruth,
  compareToGroundTruth
}
