/**
 * PATTERN: ESM default export
 *
 * ES Module with default export.
 * Uses export default class syntax.
 */

class Canonical {
  constructor () {
    this._value = null
  }

  method_sync_1 () {
    return 'sync'
  }

  async method_async_1 () {
    return 'async'
  }

  static method_static_1 () {
    return 'static'
  }

  get method_getter_1 () {
    return this._value
  }

  set method_setter_1 (val) {
    this._value = val
  }
}

export default Canonical
