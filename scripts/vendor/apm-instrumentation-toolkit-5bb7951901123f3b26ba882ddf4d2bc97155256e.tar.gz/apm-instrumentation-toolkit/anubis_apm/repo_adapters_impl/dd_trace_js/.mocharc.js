'use strict'

module.exports = {
  timeout: 5000,
  reporter: 'spec'
}
