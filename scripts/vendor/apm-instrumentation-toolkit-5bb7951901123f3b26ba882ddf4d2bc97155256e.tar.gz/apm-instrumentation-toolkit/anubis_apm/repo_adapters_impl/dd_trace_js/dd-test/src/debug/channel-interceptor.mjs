/**
 * APM v5 Debug Interceptor (ESM Version)
 * Patches diagnostic channels and span operations to provide visibility
 *
 * This ESM version is loaded via --import flag for ES Module packages.
 * It patches diagnostics_channel at import time before any other code runs.
 */

// TODO: This whole file is basically a hack for logging channel activity + span lifecycle activity. we should move all this into dd-trace-js.
import diagnostics_channel from 'diagnostics_channel'
import net from 'net'

// Debug: Log when this module is loaded
console.log('[dd-debug] ESM interceptor loading... DD_TRACE_DEBUG_PORT=' + process.env.DD_TRACE_DEBUG_PORT)

// Check if already patched (prevents double-patching when both CJS and ESM interceptors run)
if (globalThis._ddDebugV5Patched) {
  console.log('[dd-debug] ESM interceptor skipped (already patched by CJS)')
} else {
  globalThis._ddDebugV5Patched = true

  let interceptor = null

  // Save original methods before patching
  const originalChannelSubscribe = diagnostics_channel.Channel.prototype.subscribe
  const originalChannelPublish = diagnostics_channel.Channel.prototype.publish
  const originalChannelRunStores = diagnostics_channel.Channel.prototype.runStores

  function setupInterceptor (port) {
    const client = new net.Socket()

    client.connect(port, '127.0.0.1', () => {
      console.log('[dd-debug] ESM interceptor connected to debugger')
    })

    // Don't keep the process alive just for this connection
    client.unref()

    // Handle connection errors gracefully
    client.on('error', () => {
      // Ignore connection errors
    })

    interceptor = {
      client,
      channels: new Map(),
      send: (type, data) => {
        try {
          client.write(JSON.stringify({ type, data, timestamp: Date.now() }) + '\n')
        } catch (err) {
          // Ignore connection errors
        }
      }
    }

    // Apply the patched methods with interceptor available
    patchDiagnosticChannel()

    return interceptor
  }

  function patchDiagnosticChannel () {
    try {
      // Patch channel.subscribe
      if (originalChannelSubscribe) {
        diagnostics_channel.Channel.prototype.subscribe = function (listener) {
          const channelName = this.name

          interceptor?.send('channel:subscribe', {
            channel: channelName,
            listenerName: listener.name || '<anonymous>'
          })

          // Wrap the listener to see when it's invoked
          const wrappedListener = function (message) {
            interceptor?.send('channel:listener:invoke', {
              channel: channelName,
              listenerName: listener.name || '<anonymous>',
              message: serializeMessage(message)
            })
            return listener.call(this, message)
          }

          // Preserve the original listener name
          Object.defineProperty(wrappedListener, 'name', { value: listener.name || '<anonymous>' })

          // Track subscriptions
          if (!interceptor?.channels.has(channelName)) {
            interceptor?.channels.set(channelName, { subscriptions: 0, publishes: 0 })
          }
          const stats = interceptor?.channels.get(channelName)
          if (stats) stats.subscriptions++

          return originalChannelSubscribe.call(this, wrappedListener)
        }
      }

      // Patch channel.publish
      if (originalChannelPublish) {
        diagnostics_channel.Channel.prototype.publish = function (message) {
          const channelName = this.name

          // Determine if this is a tracing sub-channel
          const isTracingChannel = channelName.includes(':start') || channelName.includes(':end') ||
            channelName.includes(':error') || channelName.includes(':asyncStart') ||
            channelName.includes(':asyncEnd')

          // Log publish event
          interceptor?.send('channel:publish', {
            channel: channelName,
            message: serializeMessage(message),
            hasSubscribers: this.hasSubscribers,
            isTracingChannel
          })

          // Track publishes
          if (!interceptor?.channels.has(channelName)) {
            interceptor?.channels.set(channelName, { subscriptions: 0, publishes: 0 })
          }
          const stats = interceptor?.channels.get(channelName)
          if (stats) stats.publishes++

          return originalChannelPublish.call(this, message)
        }
      }

      // Patch channel.runStores
      if (originalChannelRunStores) {
        diagnostics_channel.Channel.prototype.runStores = function (context, fn, thisArg, ...args) {
          const channelName = this.name

          interceptor?.send('channel:runStores', {
            channel: channelName,
            context: serializeMessage(context),
            fnName: fn?.name || '<anonymous>'
          })

          return originalChannelRunStores.call(this, context, fn, thisArg, ...args)
        }
      }

      interceptor?.send('info', { message: 'Patched diagnostic_channel (ESM)' })
    } catch (err) {
      interceptor?.send('error', { message: 'Failed to patch diagnostic_channel (ESM)', error: err.message })
    }
  }

  function serializeMessage (message) {
    try {
      if (!message) return null

      if (typeof message === 'object') {
        const serialized = {}

        // Common APM fields
        if (message.req) {
          serialized.req = {
            method: message.req.method,
            url: message.req.url,
            headers: message.req.headers ? '<headers>' : undefined
          }
        }
        if (message.res) {
          serialized.res = {
            statusCode: message.res.statusCode,
            headers: message.res.headers ? '<headers>' : undefined
          }
        }
        if (message.error) {
          serialized.error = {
            message: message.error.message,
            type: message.error.constructor.name,
            stack: message.error.stack ? message.error.stack.split('\n').slice(0, 3).join('\n') : undefined
          }
        }
        if (message.result !== undefined) {
          serialized.result = String(message.result).substring(0, 100)
        }

        // Span/trace fields
        if (message.span) serialized.span = '<span>'
        if (message.parentSpan) serialized.parentSpan = '<parentSpan>'
        if (message.context) serialized.context = '<context>'

        // Include other keys (limited)
        const keys = Object.keys(message)
        for (const key of keys.slice(0, 10)) {
          if (!serialized[key] && typeof message[key] !== 'function') {
            const value = message[key]
            if (value === null || value === undefined) {
              serialized[key] = value
            } else if (typeof value === 'object') {
              if (value.constructor?.name && value.constructor.name !== 'Object') {
                serialized[key] = `<${value.constructor.name}>`
              } else {
                serialized[key] = '<object>'
              }
            } else if (typeof value === 'string' && value.length > 100) {
              serialized[key] = value.substring(0, 100) + '...'
            } else {
              serialized[key] = value
            }
          }
        }

        if (keys.length > 10) {
          serialized['...'] = `${keys.length - 10} more keys`
        }

        return serialized
      }

      return message
    } catch (err) {
      return `<error: ${err.message}>`
    }
  }

  // Patch tracer.startSpan to capture span lifecycle
  async function patchTracer () {
    try {
      // Import dd-trace as an installed package
      const ddTrace = await import('dd-trace')
      const tracer = ddTrace.default || ddTrace

      // Get the internal tracer instance
      const tracerInstance = tracer._tracer || tracer.tracer || tracer

      if (tracerInstance?.startSpan && !tracerInstance._ddDebugV5EsmPatched) {
        tracerInstance._ddDebugV5EsmPatched = true

        const originalStartSpan = tracerInstance.startSpan.bind(tracerInstance)
        tracerInstance.startSpan = function (name, options) {
          const span = originalStartSpan(name, options)

          if (span) {
            const context = span.context?.()
            if (context && !span._ddDebugV5EsmPatched) {
              span._ddDebugV5EsmPatched = true

              interceptor?.send('span:start', {
                spanId: context.toSpanId?.() || 'unknown',
                traceId: context.toTraceId?.() || 'unknown',
                operationName: name,
                resource: options?.resource,
                service: options?.service
              })

              // Patch span.finish
              const originalFinish = span.finish.bind(span)
              span.finish = function (finishTime) {
                interceptor?.send('span:finish', {
                  spanId: context.toSpanId?.() || 'unknown',
                  operationName: name,
                  finishTime: finishTime || Date.now()
                })
                return originalFinish(finishTime)
              }
            }
          }

          return span
        }

        interceptor?.send('info', { message: 'Patched tracer.startSpan (ESM)' })
      }
    } catch (err) {
      // dd-trace might not be available yet, retry
      if (err.code === 'ERR_MODULE_NOT_FOUND') {
        setTimeout(patchTracer, 100)
      }
    }
  }

  // Auto-setup if DEBUG_PORT env var is set
  if (process.env.DD_TRACE_DEBUG_PORT) {
    setupInterceptor(parseInt(process.env.DD_TRACE_DEBUG_PORT))

    // Attempt to patch tracer after dd-trace is loaded
    setTimeout(patchTracer, 100)
  }
}
