'use strict'

const chalk = require('chalk')

// Icon sets - ASCII mode avoids Unicode corruption in subprocess pipes
const ICONS = {
  emoji: {
    subscribe: '📡 SUBSCRIBE',
    publish: '📤 PUBLISH',
    listener: '🔔 LISTENER',
    wrap: '🔧 WRAP',
    runStores: '🏃 RUN STORES',
    spanTag: '🏷  SPAN TAG',
    spanStart: '▶ SPAN START',
    spanFinish: '■ SPAN FINISH',
    warning: '⚠️ ',
    success: '✅'
  },
  ascii: {
    subscribe: '[SUB] SUBSCRIBE',
    publish: '[PUB] PUBLISH',
    listener: '[LSN] LISTENER',
    wrap: '[WRP] WRAP',
    runStores: '[RUN] RUN STORES',
    spanTag: '[TAG] SPAN TAG',
    spanStart: '[>] SPAN START',
    spanFinish: '[x] SPAN FINISH',
    warning: '[!] ',
    success: '[OK]'
  }
}

class DebugFormatter {
  constructor (options = {}) {
    this.verbose = options.verbose || false
    this.showChannels = options.showChannels !== false
    this.showSpans = options.showSpans !== false
    this.showData = options.showData || false
    // Use ASCII icons when DD_ASCII_OUTPUT=1 (avoids Unicode issues in agent pipelines)
    this.icons = (options.ascii || process.env.DD_ASCII_OUTPUT === '1') ? ICONS.ascii : ICONS.emoji
    this.startTime = null
    this.stats = {
      spans: {
        started: 0,
        finished: 0,
        pending: new Map()
      },
      channels: {
        subscriptions: new Map(),
        publishes: new Map(),
        listenerInvocations: 0
      }
    }
  }

  formatTimestamp (timestamp) {
    return chalk.gray(`[+${timestamp}ms]`)
  }

  formatChannelSubscribe (data) {
    const { channel, listenerName, timestamp } = data

    // Track subscription
    if (!this.stats.channels.subscriptions.has(channel)) {
      this.stats.channels.subscriptions.set(channel, 0)
    }
    this.stats.channels.subscriptions.set(
      channel,
      this.stats.channels.subscriptions.get(channel) + 1
    )

    // Highlight the operation suffix if present
    let displayChannel = channel
    const match = channel.match(/:(start|end|asyncStart|asyncEnd|error)$/)
    if (match) {
      const operation = match[1]
      const baseChannel = channel.substring(0, channel.lastIndexOf(':'))
      displayChannel = chalk.cyan(baseChannel) + chalk.yellow(`:${operation}`)
    } else {
      displayChannel = chalk.cyan(channel)
    }

    return `${this.formatTimestamp(timestamp)} ${chalk.blue(this.icons.subscribe)} ${displayChannel} ${chalk.gray(`(${listenerName})`)}\n`
  }

  formatChannelPublish (data, showData = false) {
    const { channel, message, hasSubscribers, isTracingChannel, timestamp } = data

    // Track publish
    if (!this.stats.channels.publishes.has(channel)) {
      this.stats.channels.publishes.set(channel, 0)
    }
    this.stats.channels.publishes.set(
      channel,
      this.stats.channels.publishes.get(channel) + 1
    )

    // Extract the operation suffix if it's a tracing channel
    let displayChannel = channel
    let operation = ''
    if (isTracingChannel) {
      const match = channel.match(/:(start|end|asyncStart|asyncEnd|error)$/)
      if (match) {
        operation = match[1]
        displayChannel = channel.substring(0, channel.lastIndexOf(':'))
      }
    }

    let output = `${this.formatTimestamp(timestamp)} ${chalk.yellow(this.icons.publish)} ${chalk.cyan(displayChannel)}`

    if (operation) {
      output += chalk.yellow(`:${operation}`)
    }

    if (!hasSubscribers) {
      output += chalk.red(' (no subscribers!)')
    }

    output += '\n'

    if (showData && message) {
      output += chalk.gray('  Data: ') + this._formatMessage(message) + '\n'
    }

    return output
  }

  formatChannelListenerInvoke (data, showData = false) {
    const { channel, listenerName, message, timestamp } = data

    // Track listener invocations (proves channels were published)
    this.stats.channels.listenerInvocations++

    // Highlight the operation suffix if present
    let displayChannel = channel
    const match = channel.match(/:(start|end|asyncStart|asyncEnd|error)$/)
    if (match) {
      const operation = match[1]
      const baseChannel = channel.substring(0, channel.lastIndexOf(':'))
      displayChannel = chalk.cyan(baseChannel) + chalk.yellow(`:${operation}`)
    } else {
      displayChannel = chalk.cyan(channel)
    }

    let output = `${this.formatTimestamp(timestamp)} ${chalk.blue(this.icons.listener)} ${displayChannel} ${chalk.gray(`→ ${listenerName}`)}\n`

    if (showData && message) {
      output += chalk.gray('  Data: ') + this._formatMessage(message) + '\n'
    }

    return output
  }

  formatShimmerWrap (data) {
    const { object, method, wrapperName, massWrap, timestamp } = data

    let output = `${this.formatTimestamp(timestamp)} ${chalk.magenta(this.icons.wrap)} ${chalk.white(object)}.${chalk.yellow(method)}`

    if (massWrap) {
      output += chalk.gray(' (massWrap)')
    }

    output += chalk.gray(` → ${wrapperName}`) + '\n'

    return output
  }

  formatChannelRunStores (data, showData = false) {
    const { channel, context, fnName, timestamp } = data

    // Highlight the operation suffix if present
    let displayChannel = channel
    const match = channel.match(/:(start|end|asyncStart|asyncEnd|error)$/)
    if (match) {
      const operation = match[1]
      const baseChannel = channel.substring(0, channel.lastIndexOf(':'))
      displayChannel = chalk.cyan(baseChannel) + chalk.yellow(`:${operation}`)
    } else {
      displayChannel = chalk.cyan(channel)
    }

    let output = `${this.formatTimestamp(timestamp)} ${chalk.green(this.icons.runStores)} ${displayChannel} ${chalk.gray(`→ ${fnName}`)}\n`

    if (showData && context) {
      output += chalk.gray('  Context: ') + this._formatMessage(context) + '\n'
    }

    return output
  }

  formatSpanStart (data) {
    const { spanId, traceId, operationName, resource, service, tags, timestamp } = data

    this.stats.spans.started++
    this.stats.spans.pending.set(spanId, { operationName, startTime: timestamp })

    let output = `${this.formatTimestamp(timestamp)} ${chalk.green(this.icons.spanStart)} ${chalk.white(operationName)}\n`
    output += chalk.gray(`  Span ID: ${spanId}\n`)
    output += chalk.gray(`  Trace ID: ${traceId}\n`)

    if (resource) {
      output += chalk.gray(`  Resource: ${resource}\n`)
    }

    if (service) {
      output += chalk.gray(`  Service: ${service}\n`)
    }

    if (tags && Object.keys(tags).length > 0) {
      // Always show important tags, show all in verbose mode
      const tagEntries = Object.entries(tags)
      const limit = this.verbose ? tagEntries.length : Math.min(5, tagEntries.length)
      const formatted = tagEntries.slice(0, limit).map(([k, v]) => `${k}=${v}`).join(', ')
      output += chalk.gray('  Tags: ') + chalk.white(formatted)
      if (!this.verbose && tagEntries.length > 5) {
        output += chalk.gray(` (+${tagEntries.length - 5} more)`)
      }
      output += '\n'
    }

    return output
  }

  formatSpanFinish (data) {
    const { spanId, operationName, timestamp } = data

    this.stats.spans.finished++

    const spanInfo = this.stats.spans.pending.get(spanId)
    const duration = spanInfo ? timestamp - spanInfo.startTime : '?'
    this.stats.spans.pending.delete(spanId)

    let output = `${this.formatTimestamp(timestamp)} ${chalk.red(this.icons.spanFinish)} ${chalk.white(operationName)}`
    output += chalk.gray(` (${duration}ms)\n`)
    output += chalk.gray(`  Span ID: ${spanId}\n`)

    return output
  }

  formatSpanTag (data) {
    const { spanId, key, value, timestamp } = data

    let output = `${this.formatTimestamp(timestamp)} ${chalk.magenta(this.icons.spanTag)} ${chalk.gray(spanId)}\n`
    output += chalk.gray(`  ${key}: `) + this._formatValue(value) + '\n'

    return output
  }

  formatSummary () {
    let output = '\n' + chalk.bold('═'.repeat(70)) + '\n'
    output += chalk.bold('Debug Summary\n')
    output += chalk.bold('═'.repeat(70)) + '\n\n'

    // Span stats
    output += chalk.bold('Spans:\n')
    output += `  Started: ${chalk.green(this.stats.spans.started)}\n`
    output += `  Finished: ${chalk.green(this.stats.spans.finished)}\n`

    if (this.stats.spans.pending.size > 0) {
      output += `  ${chalk.red(this.icons.warning + ' Pending (never finished):')} ${chalk.red(this.stats.spans.pending.size)}\n`
      for (const [spanId, info] of this.stats.spans.pending.entries()) {
        output += chalk.gray(`    - ${info.operationName} (${spanId})\n`)
      }
    }

    output += '\n'

    // Channel stats
    output += chalk.bold('Channels:\n')

    if (this.stats.channels.subscriptions.size === 0) {
      output += chalk.red(`  ${this.icons.warning} No channel subscriptions detected!\n`)
    } else {
      output += chalk.green(`  ${this.stats.channels.subscriptions.size} channels subscribed\n`)
      if (this.verbose) {
        for (const [channel, count] of this.stats.channels.subscriptions.entries()) {
          output += chalk.gray(`    - ${channel}: ${count} subscriber(s)\n`)
        }
      }
    }

    // Check listener invocations OR explicit publishes
    const hasChannelActivity = this.stats.channels.listenerInvocations > 0 || this.stats.channels.publishes.size > 0

    if (!hasChannelActivity) {
      output += chalk.red(`  ${this.icons.warning} No channel activity detected!\n`)
    } else {
      if (this.stats.channels.listenerInvocations > 0) {
        output += chalk.green(`  ${this.stats.channels.listenerInvocations} listener invocation(s)\n`)
      }
      if (this.stats.channels.publishes.size > 0) {
        output += chalk.green(`  ${this.stats.channels.publishes.size} explicit publish event(s)\n`)
        if (this.verbose) {
          for (const [channel, count] of this.stats.channels.publishes.entries()) {
            output += chalk.gray(`    - ${channel}: ${count} event(s)\n`)
          }
        }
      }
    }

    output += '\n'

    // Problems detected
    const problems = []
    if (this.stats.spans.started === 0) {
      problems.push('No spans created - instrumentation may not be working')
    }
    if (this.stats.spans.pending.size > 0) {
      problems.push(`${this.stats.spans.pending.size} span(s) never finished - possible leak`)
    }
    if (this.stats.channels.subscriptions.size === 0) {
      problems.push('No channels subscribed - plugin may not be loaded')
    }
    if (this.stats.channels.publishes.size === 0 && this.stats.channels.listenerInvocations === 0) {
      problems.push('No channel activity detected - instrumentation may not be triggering')
    }

    if (problems.length > 0) {
      output += chalk.bold.red(`${this.icons.warning} Problems Detected:\n`)
      for (const problem of problems) {
        output += chalk.red(`  - ${problem}\n`)
      }
    } else {
      output += chalk.bold.green(`${this.icons.success} All checks passed!\n`)
    }

    output += '\n' + chalk.bold('═'.repeat(70)) + '\n'

    return output
  }

  _formatMessage (message) {
    if (!message) return chalk.gray('null')
    if (typeof message === 'string') return chalk.white(`"${message}"`)

    try {
      const keys = Object.keys(message)
      if (keys.length === 0) return chalk.gray('{}')

      const preview = keys.slice(0, 3).map(k => {
        const val = message[k]
        if (typeof val === 'object') return `${k}: <object>`
        return `${k}: ${val}`
      }).join(', ')

      return chalk.white(`{ ${preview}${keys.length > 3 ? ', ...' : ''} }`)
    } catch (err) {
      return chalk.gray('<error formatting>')
    }
  }

  _formatTags (tags) {
    try {
      const entries = Object.entries(tags).slice(0, 5)
      const formatted = entries.map(([k, v]) => `${k}=${v}`).join(', ')
      return chalk.white(formatted)
    } catch (err) {
      return chalk.gray('<error formatting>')
    }
  }

  _formatValue (value) {
    if (value === null || value === undefined) return chalk.gray(String(value))
    if (typeof value === 'string') return chalk.white(`"${value}"`)
    if (typeof value === 'number') return chalk.yellow(value)
    if (typeof value === 'boolean') return chalk.cyan(value)
    if (typeof value === 'object') return chalk.gray('<object>')
    return chalk.white(String(value))
  }
}

module.exports = { DebugFormatter }
