/**
 * APM v5 Debug Interceptor - ESM Loader Version
 *
 * This is a custom ESM loader that intercepts module loading AND
 * patches diagnostic channels for debugging.
 *
 * The advantage of using a loader is that sandbox subprocess spawning
 * preserves --loader flags, so this interceptor will automatically
 * be applied to subprocesses without modifying helpers/index.js.
 */

// TODO: This whole file is basically a hack for logging channel activity + span lifecycle activity. we should move all this into dd-trace-js.
import diagnostics_channel from 'diagnostics_channel'
import net from 'net'

// Debug logging
const DEBUG_PORT = process.env.DD_TRACE_DEBUG_PORT
if (DEBUG_PORT) {
  console.log('[dd-debug-loader] Loading interceptor loader... DD_TRACE_DEBUG_PORT=' + DEBUG_PORT)
}

let interceptor = null

// Set up interceptor connection
if (DEBUG_PORT && !globalThis._ddDebugV5LoaderPatched) {
  globalThis._ddDebugV5LoaderPatched = true

  const client = new net.Socket()

  client.connect(parseInt(DEBUG_PORT), '127.0.0.1', () => {
    console.log('[dd-debug-loader] Connected to debugger')
  })

  client.unref()
  client.on('error', () => {/* empty */})

  interceptor = {
    client,
    channels: new Map(),
    send: (type, data) => {
      try {
        client.write(JSON.stringify({ type, data, timestamp: Date.now() }) + '\n')
      } catch (err) {/* empty */}
    }
  }

  // Patch diagnostic_channel
  const originalSubscribe = diagnostics_channel.Channel.prototype.subscribe
  const originalPublish = diagnostics_channel.Channel.prototype.publish

  diagnostics_channel.Channel.prototype.subscribe = function (listener) {
    interceptor?.send('channel:subscribe', {
      channel: this.name,
      listenerName: listener.name || '<anonymous>'
    })

    const wrappedListener = function (message) {
      interceptor?.send('channel:listener:invoke', {
        channel: this.name,
        listenerName: listener.name || '<anonymous>',
        message: serializeMessage(message)
      })
      return listener.call(this, message)
    }.bind(this)

    return originalSubscribe.call(this, wrappedListener)
  }

  diagnostics_channel.Channel.prototype.publish = function (message) {
    interceptor?.send('channel:publish', {
      channel: this.name,
      message: serializeMessage(message),
      hasSubscribers: this.hasSubscribers
    })
    return originalPublish.call(this, message)
  }

  interceptor.send('info', { message: 'Patched diagnostic_channel (loader)' })

  // Patch dd-trace when it's available
  setTimeout(async () => {
    try {
      const ddTrace = await import('dd-trace')
      const tracer = ddTrace.default || ddTrace
      const tracerInstance = tracer._tracer || tracer.tracer || tracer

      if (tracerInstance?.startSpan && !tracerInstance._ddDebugLoaderPatched) {
        tracerInstance._ddDebugLoaderPatched = true

        const originalStartSpan = tracerInstance.startSpan.bind(tracerInstance)
        tracerInstance.startSpan = function (name, options) {
          const span = originalStartSpan(name, options)

          if (span && !span._ddDebugLoaderPatched) {
            span._ddDebugLoaderPatched = true
            const context = span.context?.()

            interceptor?.send('span:start', {
              spanId: context?.toSpanId?.() || 'unknown',
              traceId: context?.toTraceId?.() || 'unknown',
              operationName: name,
              resource: options?.resource,
              service: options?.service
            })

            const originalFinish = span.finish.bind(span)
            span.finish = function (finishTime) {
              interceptor?.send('span:finish', {
                spanId: context?.toSpanId?.() || 'unknown',
                operationName: name,
                finishTime: finishTime || Date.now()
              })
              return originalFinish(finishTime)
            }
          }

          return span
        }

        interceptor.send('info', { message: 'Patched tracer.startSpan (loader)' })
      }
    } catch (err) {
      // dd-trace not available yet
    }
  }, 100)
}

function serializeMessage (message) {
  try {
    if (!message) return null
    if (typeof message === 'object') {
      const serialized = {}
      const keys = Object.keys(message).slice(0, 10)
      for (const key of keys) {
        const value = message[key]
        if (typeof value === 'function') continue
        if (value === null || value === undefined) {
          serialized[key] = value
        } else if (typeof value === 'object') {
          serialized[key] = `<${value.constructor?.name || 'object'}>`
        } else if (typeof value === 'string' && value.length > 100) {
          serialized[key] = value.substring(0, 100) + '...'
        } else {
          serialized[key] = value
        }
      }
      return serialized
    }
    return message
  } catch (err) {
    return `<error: ${err.message}>`
  }
}

// ESM Loader hooks - we just pass through, the interceptor is set up above
export async function resolve (specifier, context, nextResolve) {
  return nextResolve(specifier, context)
}

export async function load (url, context, nextLoad) {
  return nextLoad(url, context)
}
