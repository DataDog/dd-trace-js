#!/usr/bin/env node
'use strict'

/**
 * APM v5 Debug Interceptor (CommonJS Version)
 * Patches diagnostic channels and span operations to provide visibility
 *
 * This CJS version is loaded via -r flag for CommonJS packages.
 * For ESM packages, use channel-interceptor.mjs via --import flag.
 */

// Check if already patched (prevents double-patching when both CJS and ESM interceptors run)
if (globalThis._ddDebugV5Patched) {
  // Already patched, skip
  module.exports = { setupInterceptor: () => { /* no-op when already patched */ } }
  return
}
globalThis._ddDebugV5Patched = true

let interceptor = null

// Patch diagnostic_channel IMMEDIATELY before anything else loads
// This must happen before dc-polyfill or any other code requires diagnostics_channel
const dc = require('diagnostics_channel')
const originalChannelSubscribe = dc.Channel.prototype.subscribe
const originalChannelPublish = dc.Channel.prototype.publish
const originalChannelRunStores = dc.Channel.prototype.runStores

// Define patching functions first
function patchTracingPluginClass (TracingPluginClass) {
  if (!TracingPluginClass || !TracingPluginClass.prototype) return
  if (TracingPluginClass.prototype._ddDebugV5Patched) return
  TracingPluginClass.prototype._ddDebugV5Patched = true

  const originalStartSpan = TracingPluginClass.prototype.startSpan
  if (originalStartSpan) {
    TracingPluginClass.prototype.startSpan = function (name, options, enterOrCtx) {
      // Some plugins use signature (options, ctx) instead of (name, options, ctx)
      // Detect this by checking if first arg looks like options object
      let actualName = name
      let actualOptions = options
      if (typeof name === 'object' && name !== null && !options?.meta) {
        actualOptions = name
        actualName = actualOptions.resource || actualOptions.name || this.operationName?.() || 'unknown'
      }

      interceptor?.send('plugin:startSpan', {
        pluginId: this.constructor.id || 'unknown',
        name: actualName,
        resource: actualOptions?.resource,
        service: actualOptions?.service,
        meta: actualOptions?.meta
      })

      const span = originalStartSpan.call(this, name, options, enterOrCtx)

      if (span && !span._ddDebugV5Patched) {
        const context = span.context()
        if (context) {
          span._ddDebugV5Patched = true

          const tags = extractTags(span)
          interceptor?.send('span:start', {
            spanId: context.toSpanId(),
            traceId: context.toTraceId(),
            operationName: actualName,
            resource: tags['resource.name'] || actualOptions?.resource,
            service: tags['service.name'] || actualOptions?.service,
            tags,
            startTime: span._startTime
          })

          const originalFinish = span.finish
          span.finish = function (finishTime) {
            interceptor?.send('span:finish', {
              spanId: context.toSpanId(),
              operationName: actualName,
              finishTime: finishTime || Date.now()
            })
            return originalFinish.call(this, finishTime)
          }

          const originalSetTag = span.setTag
          span.setTag = function (key, value) {
            interceptor?.send('span:tag', {
              spanId: context.toSpanId(),
              key,
              value
            })
            return originalSetTag.call(this, key, value)
          }
        }
      }

      return span
    }
  }
}

function extractTags (span) {
  try {
    // Tags can be in several places depending on the span implementation
    if (span._spanContext && span._spanContext._tags) {
      return span._spanContext._tags
    }
    if (span.context && span.context()._tags) {
      return span.context()._tags
    }
    return span._tags || span.tags || {}
  } catch (err) {
    return {}
  }
}

// Helper to find the tracer repo root
function findTracerRepoRoot () {
  const path = require('path')
  const fs = require('fs')

  // Strategy 1: Check DD_TRACER_REPO environment variable
  if (process.env.DD_TRACER_REPO) {
    const repoPath = process.env.DD_TRACER_REPO
    if (fs.existsSync(path.join(repoPath, 'packages', 'dd-trace'))) {
      return repoPath
    }
    console.error(`[dd-debug] DD_TRACER_REPO is set to '${repoPath}' but packages/dd-trace not found`)
  }

  // Strategy 2: Check .tracer-repo file in ~/.dd-apm/
  const homeDir = process.env.HOME || process.env.USERPROFILE
  if (homeDir) {
    const tracerRepoFile = path.join(homeDir, '.dd-apm', '.tracer-repo')
    if (fs.existsSync(tracerRepoFile)) {
      try {
        const repoPath = fs.readFileSync(tracerRepoFile, 'utf8').trim()
        if (repoPath && fs.existsSync(path.join(repoPath, 'packages', 'dd-trace'))) {
          return repoPath
        }
        console.error(`[dd-debug] .tracer-repo points to '${repoPath}' but packages/dd-trace not found`)
      } catch (err) {
        console.error(`[dd-debug] Failed to read .tracer-repo file: ${err.message}`)
      }
    }
  }

  // Strategy 3: Fallback to relative path (for development in dd-trace-js repo)
  const relativePath = path.join(__dirname, '../../../../../../')
  if (fs.existsSync(path.join(relativePath, 'packages', 'dd-trace'))) {
    return relativePath
  }

  console.error('[dd-debug] Could not find tracer repo root. Set DD_TRACER_REPO env var or run bootstrap script.')
  return null
}

// Try to patch TracingPlugin immediately if it's available
let tracingPluginPatched = false
try {
  const path = require('path')
  const repoRoot = findTracerRepoRoot()
  if (repoRoot) {
    const tracingPluginPath = path.join(repoRoot, 'packages', 'dd-trace', 'src', 'plugins', 'tracing')
    const TracingPlugin = require(tracingPluginPath)
    patchTracingPluginClass(TracingPlugin)
    tracingPluginPatched = true
    if (interceptor) {
      interceptor.send('info', { message: 'Patched TracingPlugin.startSpan at module load time' })
    }
  }
} catch (err) {
  // TracingPlugin not loaded yet, will patch later via module loading hook
  // This is OK - we'll patch it when Module.require loads it
}

function setupInterceptor (port) {
  const net = require('net')
  const client = new net.Socket()

  client.connect(port, '127.0.0.1', () => {
    console.log('[dd-debug] Connected to debugger')
  })

  // Don't keep the process alive just for this connection
  client.unref()

  // Also handle connection errors gracefully
  client.on('error', () => {
    // Ignore connection errors
  })

  interceptor = {
    client,
    channels: new Map(),
    send: (type, data) => {
      try {
        client.write(JSON.stringify({ type, data, timestamp: Date.now() }) + '\n')
      } catch (err) {
        // Ignore connection errors
      }
    }
  }

  // Now apply the patched methods with interceptor available
  patchDiagnosticChannel()

  // Patch module loading to intercept shimmer and dd-trace
  patchModuleLoading()

  return interceptor
}

function patchDiagnosticChannel () {
  try {
    // Use the saved original methods
    if (originalChannelSubscribe) {
      dc.Channel.prototype.subscribe = function (listener) {
        const channelName = this.name

        // Check if this is a rewriter-created orchestrion channel
        const isOrchestrionChannel = channelName.startsWith('orchestrion:')

        interceptor?.send('channel:subscribe', {
          channel: channelName,
          listenerName: listener.name || '<anonymous>',
          isOrchestrionChannel
        })

        // Wrap the listener to see when it's invoked
        const wrappedListener = function (message) {
          interceptor?.send('channel:listener:invoke', {
            channel: channelName,
            listenerName: listener.name || '<anonymous>',
            message: serializeMessage(message)
          })
          return listener.call(this, message)
        }

        // Preserve the original listener name
        Object.defineProperty(wrappedListener, 'name', { value: listener.name || '<anonymous>' })

        // Track subscriptions
        if (!interceptor?.channels.has(channelName)) {
          interceptor?.channels.set(channelName, { subscriptions: 0, publishes: 0 })
        }
        const stats = interceptor?.channels.get(channelName)
        stats.subscriptions++

        return originalChannelSubscribe.call(this, wrappedListener)
      }
    }

    // Patch channel.publish
    if (originalChannelPublish) {
      dc.Channel.prototype.publish = function (message) {
        const channelName = this.name

        // Determine if this is a tracing sub-channel (start, end, asyncStart, asyncEnd, error)
        const isTracingChannel = channelName.includes(':start') || channelName.includes(':end') ||
                                 channelName.includes(':error') || channelName.includes(':asyncStart') ||
                                 channelName.includes(':asyncEnd')

        // Check if this is a rewriter-created orchestrion channel
        const isOrchestrionChannel = channelName.startsWith('orchestrion:')

        // Log publish event with full channel name
        interceptor?.send('channel:publish', {
          channel: channelName,
          message: serializeMessage(message),
          hasSubscribers: this.hasSubscribers,
          isTracingChannel,
          isOrchestrionChannel
        })

        // Track publishes
        if (!interceptor?.channels.has(channelName)) {
          interceptor?.channels.set(channelName, { subscriptions: 0, publishes: 0 })
        }
        const stats = interceptor?.channels.get(channelName)
        stats.publishes++

        // Call original
        return originalChannelPublish.call(this, message)
      }
    }

    // Patch channel.runStores (used by TracingChannel)
    if (originalChannelRunStores) {
      dc.Channel.prototype.runStores = function (context, fn, thisArg, ...args) {
        const channelName = this.name

        interceptor?.send('channel:runStores', {
          channel: channelName,
          context: serializeMessage(context),
          fnName: fn?.name || '<anonymous>'
        })

        // Call original
        return originalChannelRunStores.call(this, context, fn, thisArg, ...args)
      }
    }

    interceptor?.send('info', { message: 'Patched diagnostic_channel' })
  } catch (err) {
    interceptor?.send('error', { message: 'Failed to patch diagnostic_channel', error: err.message })
  }
}

function patchModuleLoading () {
  try {
    const Module = require('module')
    const originalRequire = Module.prototype.require

    Module.prototype.require = function (id) {
      const module = originalRequire.apply(this, arguments)

      // Intercept shimmer loading
      if (id.includes('shimmer') || id.includes('datadog-shimmer')) {
        patchShimmerModule(module)
      }

      // Intercept dc-polyfill loading
      if (id.includes('dc-polyfill')) {
        patchDcPolyfill(module)
      }

      // Intercept dd-trace loading (main entry point)
      if (id === 'dd-trace' || id === '../../../../dd-trace' || id.includes('dd-trace/index')) {
        patchTracerModule(module)
      }

      // Intercept tracer proxy loading
      if (id.includes('dd-trace/src/proxy')) {
        patchTracerModule(module)
      }

      // Intercept TracingPlugin loading (where startSpan is called)
      if (id.includes('dd-trace/src/plugins/tracing')) {
        patchTracingPluginClass(module)
      }

      // Also patch intermediate plugin classes that inherit from TracingPlugin
      if (id.includes('dd-trace/src/plugins/server') ||
          id.includes('dd-trace/src/plugins/inbound') ||
          id.includes('dd-trace/src/plugins/client') ||
          id.includes('dd-trace/src/plugins/outbound')) {
        patchTracingPluginClass(module)
      }

      // Intercept rewriter loading to debug method rewrites
      if (id.includes('helpers/rewriter') && !id.includes('rewriter/instrumentations')) {
        patchRewriterModule(module)
      }

      return module
    }
  } catch (err) {
    interceptor?.send('error', { message: 'Failed to patch module loading', error: err.message })
  }
}

function patchShimmerModule (shimmer) {
  if (shimmer._ddDebugV5Patched) return
  shimmer._ddDebugV5Patched = true

  interceptor?.send('info', { message: 'Patching shimmer module' })

  // Patch shimmer.wrap
  const originalWrap = shimmer.wrap
  if (originalWrap) {
    shimmer.wrap = function (obj, methodName, wrapper) {
      interceptor?.send('shimmer:wrap', {
        object: obj?.constructor?.name || typeof obj,
        method: methodName,
        wrapperName: wrapper?.name || '<anonymous>'
      })
      return originalWrap.call(this, obj, methodName, wrapper)
    }
  }

  // Patch shimmer.massWrap
  const originalMassWrap = shimmer.massWrap
  if (originalMassWrap) {
    shimmer.massWrap = function (obj, methodNames, wrapper) {
      for (const methodName of methodNames) {
        interceptor?.send('shimmer:wrap', {
          object: obj?.constructor?.name || typeof obj,
          method: methodName,
          wrapperName: wrapper?.name || '<anonymous>',
          massWrap: true
        })
      }
      return originalMassWrap.call(this, obj, methodNames, wrapper)
    }
  }
}

function patchDcPolyfill (dcPolyfill) {
  if (dcPolyfill._ddDebugV5Patched) return
  dcPolyfill._ddDebugV5Patched = true

  interceptor?.send('info', { message: 'Patching dc-polyfill' })

  // Patch tracingChannel function to intercept and patch the returned TracingChannel
  const originalTracingChannel = dcPolyfill.tracingChannel
  if (originalTracingChannel) {
    dcPolyfill.tracingChannel = function (name) {
      const tracingChannelObj = originalTracingChannel.call(this, name)

      interceptor?.send('dc-polyfill:tracingChannel', {
        channelName: `tracing:${name}`
      })

      // Patch the TracingChannel object's methods
      if (tracingChannelObj && !tracingChannelObj._ddDebugV5Patched) {
        tracingChannelObj._ddDebugV5Patched = true

        // Patch traceSync
        const originalTraceSync = tracingChannelObj.traceSync
        if (originalTraceSync) {
          tracingChannelObj.traceSync = function (fn, context, thisArg, ...args) {
            interceptor?.send('tracingChannel:traceSync', {
              channel: `tracing:${name}`,
              context: serializeMessage(context)
            })
            return originalTraceSync.call(this, fn, context, thisArg, ...args)
          }
        }

        // Patch tracePromise
        const originalTracePromise = tracingChannelObj.tracePromise
        if (originalTracePromise) {
          tracingChannelObj.tracePromise = function (fn, context, thisArg, ...args) {
            interceptor?.send('tracingChannel:tracePromise', {
              channel: `tracing:${name}`,
              context: serializeMessage(context)
            })
            return originalTracePromise.call(this, fn, context, thisArg, ...args)
          }
        }

        // Patch traceCallback
        const originalTraceCallback = tracingChannelObj.traceCallback
        if (originalTraceCallback) {
          tracingChannelObj.traceCallback = function (fn, position, context, thisArg, ...args) {
            interceptor?.send('tracingChannel:traceCallback', {
              channel: `tracing:${name}`,
              context: serializeMessage(context),
              callbackPosition: position
            })
            return originalTraceCallback.call(this, fn, position, context, thisArg, ...args)
          }
        }
      }

      return tracingChannelObj
    }
  }
}

function patchRewriterModule (rewriterModule) {
  if (rewriterModule._ddDebugV5Patched) return
  rewriterModule._ddDebugV5Patched = true

  interceptor?.send('info', { message: 'Patching rewriter module' })

  // Patch the rewrite function to log when methods are rewritten
  const originalRewrite = rewriterModule.rewrite
  if (originalRewrite) {
    rewriterModule.rewrite = function (content, filename, format) {
      const result = originalRewrite.call(this, content, filename, format)

      // If content was transformed (result differs from input), log it
      if (result && result !== content) {
        // Extract module name and method info from filename
        const moduleMatch = filename.match(/node_modules\/([^/]+(?:\/[^/]+)?)\//)
        const moduleName = moduleMatch ? moduleMatch[1] : 'unknown'

        interceptor?.send('rewriter:transform', {
          filename,
          moduleName,
          format,
          originalLength: content?.length || 0,
          transformedLength: result?.length || 0
        })

        // Try to extract which channels were created by looking for the pattern
        const channelMatches = result.matchAll(/tr_ch_apm_tracingChannel\("([^"]+)"\)/g)
        for (const match of channelMatches) {
          interceptor?.send('rewriter:channelCreated', {
            channelName: match[1],
            filename,
            moduleName
          })
        }

        // Try to extract which methods were wrapped
        const methodMatches = result.matchAll(/__apm\$(\w+)/g)
        const wrappedMethods = new Set()
        for (const match of methodMatches) {
          // Filter out internal variables like __apm$original_args, __apm$traced, etc.
          if (!['original_args', 'traced', 'wrapped', 'traced_args'].includes(match[1])) {
            wrappedMethods.add(match[1])
          }
        }
        for (const method of wrappedMethods) {
          interceptor?.send('rewriter:methodWrapped', {
            methodName: method,
            filename,
            moduleName
          })
        }
      }

      return result
    }
  }

  // Patch the disable function to log when instrumentations are disabled
  const originalDisable = rewriterModule.disable
  if (originalDisable) {
    rewriterModule.disable = function (instrumentation) {
      interceptor?.send('rewriter:disable', {
        instrumentation
      })
      return originalDisable.call(this, instrumentation)
    }
  }
}

function patchTracerModule (tracerModule) {
  if (tracerModule._ddDebugV5Patched) return
  tracerModule._ddDebugV5Patched = true

  interceptor?.send('info', { message: 'Patching dd-trace tracer module' })

  // Patch the init/use methods to intercept tracer instance creation
  const originalInit = tracerModule.init
  if (originalInit) {
    tracerModule.init = function (...args) {
      const result = originalInit.apply(this, args)
      // Patch the tracer instance methods
      patchTracerInstance(tracerModule)
      patchTracerInstance(this)
      return result
    }
  }

  const originalUse = tracerModule.use
  if (originalUse) {
    tracerModule.use = function (...args) {
      const result = originalUse.apply(this, args)
      patchTracerInstance(tracerModule)
      patchTracerInstance(this)
      return result
    }
  }

  // Patch startSpan directly on the module if it exists
  if (tracerModule.startSpan) {
    patchTracerInstance(tracerModule)
  }

  // Try to get tracer from common locations
  patchTracerInstance(tracerModule._tracer)
  patchTracerInstance(tracerModule.tracer)

  // Set up a property interceptor to catch _tracer when it's set
  if (!tracerModule._tracer) {
    let _tracerValue = null
    Object.defineProperty(tracerModule, '_tracer', {
      get: () => _tracerValue,
      set: (value) => {
        _tracerValue = value
        patchTracerInstance(value)
      },
      enumerable: true,
      configurable: true
    })
  }
}

function patchTracerInstance (tracer) {
  if (!tracer) return
  if (tracer._ddDebugV5TracerPatched) return

  // Try to get the actual tracer instance
  const tracerInstance = tracer._tracer || tracer.tracer || tracer

  if (tracerInstance && tracerInstance.startSpan && !tracerInstance._ddDebugV5TracerPatched) {
    tracerInstance._ddDebugV5TracerPatched = true

    interceptor?.send('info', { message: 'Patching tracer.startSpan' })

    // Patch tracer.startSpan
    const originalStartSpan = tracerInstance.startSpan
    if (originalStartSpan) {
      tracerInstance.startSpan = function (...args) {
        const span = originalStartSpan.apply(this, args)

        if (span) {
          const context = span.context()
          interceptor?.send('span:start', {
            spanId: context.toSpanId(),
            traceId: context.toTraceId(),
            operationName: args[0],
            tags: extractTags(span),
            startTime: span._startTime
          })

          // Patch span.finish
          const originalFinish = span.finish
          span.finish = function (finishTime) {
            interceptor?.send('span:finish', {
              spanId: context.toSpanId(),
              operationName: args[0],
              finishTime: finishTime || Date.now()
            })
            return originalFinish.call(this, finishTime)
          }

          // Patch span.setTag
          const originalSetTag = span.setTag
          span.setTag = function (key, value) {
            interceptor?.send('span:tag', {
              spanId: context.toSpanId(),
              key,
              value
            })
            return originalSetTag.call(this, key, value)
          }
        }

        return span
      }
    }
  }
}

function serializeMessage (message) {
  try {
    if (!message) return null

    // For context objects, extract key info
    if (typeof message === 'object') {
      const serialized = {}

      // Common APM fields
      if (message.req) {
        serialized.req = {
          method: message.req.method,
          url: message.req.url,
          headers: message.req.headers ? '<headers>' : undefined
        }
      }
      if (message.res) {
        serialized.res = {
          statusCode: message.res.statusCode,
          headers: message.res.headers ? '<headers>' : undefined
        }
      }
      if (message.error) {
        serialized.error = {
          message: message.error.message,
          type: message.error.constructor.name,
          stack: message.error.stack ? message.error.stack.split('\n').slice(0, 3).join('\n') : undefined
        }
      }
      if (message.result !== undefined) {
        serialized.result = String(message.result).substring(0, 100)
      }

      // Span/trace fields
      if (message.span) serialized.span = '<span>'
      if (message.parentSpan) serialized.parentSpan = '<parentSpan>'
      if (message.context) serialized.context = '<context>'

      // Include other keys (limited)
      const keys = Object.keys(message)
      for (const key of keys.slice(0, 10)) { // Limit to first 10 keys
        if (!serialized[key] && typeof message[key] !== 'function') {
          const value = message[key]
          if (value === null || value === undefined) {
            serialized[key] = value
          } else if (typeof value === 'object') {
            // Try to get useful info from objects
            if (value.constructor?.name && value.constructor.name !== 'Object') {
              serialized[key] = `<${value.constructor.name}>`
            } else {
              serialized[key] = '<object>'
            }
          } else if (typeof value === 'string' && value.length > 100) {
            serialized[key] = value.substring(0, 100) + '...'
          } else {
            serialized[key] = value
          }
        }
      }

      if (keys.length > 10) {
        serialized['...'] = `${keys.length - 10} more keys`
      }

      return serialized
    }

    return message
  } catch (err) {
    return `<error: ${err.message}>`
  }
}

// Export for injection
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { setupInterceptor }
}

// Auto-setup if DEBUG_PORT env var is set
if (process.env.DD_TRACE_DEBUG_PORT) {
  setupInterceptor(parseInt(process.env.DD_TRACE_DEBUG_PORT))
}
