'use strict'

/**
 * Detect the module system type for an npm package.
 *
 * ESM Detection Logic:
 * 1. package.json "type": "module" -> ESM
 * 2. package.json "main" ends with .mjs -> ESM
 * 3. package.json "exports" has "import" condition -> ESM or Dual
 * 4. Default -> CommonJS
 */

const fs = require('fs')
const path = require('path')

/**
 * Detect whether a package uses ESM, CommonJS, or both.
 *
 * @param {string} packageDir - Path to the package directory (containing package.json)
 * @returns {'commonjs' | 'esm' | 'dual'} The module type
 */
function detectModuleType (packageDir) {
  const pkgPath = path.join(packageDir, 'package.json')

  if (!fs.existsSync(pkgPath)) {
    // No package.json found, assume CommonJS
    return 'commonjs'
  }

  let pkg
  try {
    pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'))
  } catch (err) {
    // Invalid JSON, assume CommonJS
    console.warn(`Failed to parse package.json at ${pkgPath}:`, err.message)
    return 'commonjs'
  }

  // Check explicit type field - this is the primary indicator
  if (pkg.type === 'module') {
    return 'esm'
  }

  // Check if main entry is .mjs
  if (pkg.main && pkg.main.endsWith('.mjs')) {
    return 'esm'
  }

  // Check exports field for conditional exports
  if (pkg.exports) {
    const hasImport = hasImportExport(pkg.exports)
    const hasRequire = hasRequireExport(pkg.exports)

    if (hasImport && hasRequire) {
      return 'dual'
    }

    if (hasImport) {
      return 'esm'
    }
  }

  // Default to CommonJS
  return 'commonjs'
}

/**
 * Recursively check if exports object has an "import" condition.
 *
 * @param {any} exports - The exports field from package.json
 * @returns {boolean}
 */
function hasImportExport (exports) {
  if (!exports || typeof exports !== 'object') {
    return false
  }

  // Check if it's a string ending in .mjs
  if (typeof exports === 'string') {
    return exports.endsWith('.mjs')
  }

  // Check for direct "import" key
  if ('import' in exports) {
    return true
  }

  // Recursively check nested exports (like exports['.'], exports['./feature'])
  for (const key of Object.keys(exports)) {
    const value = exports[key]
    if (typeof value === 'object' && value !== null) {
      if (hasImportExport(value)) {
        return true
      }
    }
  }

  return false
}

/**
 * Recursively check if exports object has a "require" condition.
 *
 * @param {any} exports - The exports field from package.json
 * @returns {boolean}
 */
function hasRequireExport (exports) {
  if (!exports || typeof exports !== 'object') {
    return false
  }

  // Check for direct "require" key
  if ('require' in exports) {
    return true
  }

  // Recursively check nested exports
  for (const key of Object.keys(exports)) {
    const value = exports[key]
    if (typeof value === 'object' && value !== null) {
      if (hasRequireExport(value)) {
        return true
      }
    }
  }

  return false
}

module.exports = { detectModuleType }
