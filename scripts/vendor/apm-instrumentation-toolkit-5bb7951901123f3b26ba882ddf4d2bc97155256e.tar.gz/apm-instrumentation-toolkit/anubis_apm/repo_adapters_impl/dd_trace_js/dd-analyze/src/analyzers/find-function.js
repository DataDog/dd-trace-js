'use strict'

/**
 * Find a specific function/method with fallback search strategy
 *
 * Fallback order:
 * 1. Exact match (class + method + optional filePath)
 * 2. Class + method only (no filePath constraint)
 * 3. Fuzzy search (method name across all classes)
 * 4. Standalone function search
 */

/* eslint-disable no-console */

const fs = require('fs')
const path = require('path')
const esquery = require('esquery') // eslint-disable-line import/no-extraneous-dependencies
const { parseFile, getAllJsFiles, getSnippet, getVersionRange } = require('./utils')

/**
 * Find a function with fallback search strategy
 *
 * @param {string} packagePath - Path to the package directory
 * @param {string} functionName - Method or function name to find
 * @param {string} [className] - Optional class name for method search
 * @param {string} [filePath] - Optional file path hint
 * @returns {Object|null} Result with location and source, or null if not found
 */
function findFunction (packagePath, functionName, className = null, filePath = null) {
  if (!fs.existsSync(packagePath)) {
    return null
  }

  const label = className ? `${className}.${functionName}` : functionName

  // Strategy 1: Exact match in specific file
  if (filePath && className) {
    const result = findExactInFile(packagePath, className, functionName, filePath)
    if (result) {
      if (process.env.DEBUG) console.error(`✓ Found ${label} via exact file match`)
      return result
    }
  }

  // Strategy 2: Exact class.method match across all files
  if (className) {
    const result = findExact(packagePath, className, functionName)
    if (result) {
      if (process.env.DEBUG) console.error(`✓ Found ${label} via exact match`)
      return result
    }
  }

  // Strategy 3: Fuzzy search - method name across all classes
  if (className) {
    const results = findFuzzy(packagePath, functionName)
    if (results.length > 0) {
      // Prioritize matches where className contains the requested class name
      const lowerClassName = className.toLowerCase()
      results.sort((a, b) => {
        const aClass = a.functionQuery.className.toLowerCase()
        const bClass = b.functionQuery.className.toLowerCase()
        const aExact = aClass === lowerClassName
        const bExact = bClass === lowerClassName
        const aContains = aClass.includes(lowerClassName)
        const bContains = bClass.includes(lowerClassName)

        if (aExact && !bExact) return -1
        if (bExact && !aExact) return 1
        if (aContains && !bContains) return -1
        if (bContains && !aContains) return 1
        return 0
      })

      if (process.env.DEBUG) {
        const classes = results.map(r => r.functionQuery.className).join(', ')
        console.error(`🔍 Found ${functionName} via fuzzy search in: ${classes}`)
      }
      // Return all matches - let caller/agent decide which is correct
      return results.length === 1 ? results[0] : { matches: results, count: results.length }
    }
  }

  // Strategy 4: Standalone function search
  const fnResult = findStandaloneFunction(packagePath, functionName)
  if (fnResult) {
    if (process.env.DEBUG) console.error(`✓ Found ${functionName} as standalone function`)
    return fnResult
  }

  return null
}

/**
 * Find exact match in a specific file
 */
function findExactInFile (packagePath, className, methodName, relFilePath) {
  const fullPath = path.join(packagePath, relFilePath)
  if (!fs.existsSync(fullPath)) return null

  try {
    const { ast, content } = parseFile(fullPath)
    const match = findMethodInAst(ast, className, methodName, content)

    if (match) {
      return formatResult(packagePath, relFilePath, fullPath, className, methodName, match, 'exact-file')
    }
  } catch (error) {
    // Skip unparseable files
  }

  return null
}

/**
 * Find exact class.method match across all files
 */
function findExact (packagePath, className, methodName) {
  const files = getAllJsFiles(packagePath)

  for (const file of files) {
    try {
      const { ast, content } = parseFile(file)
      const match = findMethodInAst(ast, className, methodName, content)

      if (match) {
        const relPath = path.relative(packagePath, file)
        return formatResult(packagePath, relPath, file, className, methodName, match, 'exact')
      }
    } catch (error) {
      // Skip unparseable files
    }
  }

  return null
}

/**
 * Fuzzy search - find method by name across ALL classes
 */
function findFuzzy (packagePath, methodName) {
  const files = getAllJsFiles(packagePath)
  const results = []
  const seen = new Set()

  for (const file of files) {
    try {
      const { ast, content } = parseFile(file)
      const relPath = path.relative(packagePath, file)

      // Search in all classes
      let query = `ClassDeclaration:has(MethodDefinition[key.name="${methodName}"])`
      query += `, ClassExpression:has(MethodDefinition[key.name="${methodName}"])`
      const classes = esquery.query(ast, query)

      for (const cls of classes) {
        const className = cls.id?.name || 'Anonymous'
        const key = `${className}.${methodName}`
        if (seen.has(key)) continue
        seen.add(key)

        const method = esquery.query(cls, `MethodDefinition[key.name="${methodName}"]`)[0]
        if (method) {
          results.push(formatResult(packagePath, relPath, file, className, methodName, {
            line: method.loc?.start?.line || 1,
            endLine: method.loc?.end?.line || 1,
            isAsync: method.value?.async || false,
            snippet: getSnippet(content, method.loc)
          }, 'fuzzy'))
        }
      }

      // Search prototype assignments: Foo.prototype.method = function() {}
      query = `AssignmentExpression[left.object.property.name="prototype"][left.property.name="${methodName}"]`
      for (const match of esquery.query(ast, query)) {
        const className = match.left?.object?.object?.name
        if (!className) continue

        const key = `${className}.${methodName}`
        if (seen.has(key)) continue
        seen.add(key)

        results.push(formatResult(packagePath, relPath, file, className, methodName, {
          line: match.loc?.start?.line || 1,
          endLine: match.loc?.end?.line || 1,
          isAsync: match.right?.async || false,
          snippet: getSnippet(content, match.loc)
        }, 'fuzzy-prototype'))
      }

      // Search variable property assignments: varName.method = function() {}
      query = `AssignmentExpression[left.type="MemberExpression"][left.property.name="${methodName}"]`
      for (const match of esquery.query(ast, query)) {
        const varName = match.left?.object?.name
        if (!varName) continue

        const key = `${varName}.${methodName}`
        if (seen.has(key)) continue
        seen.add(key)

        results.push(formatResult(packagePath, relPath, file, varName, methodName, {
          line: match.loc?.start?.line || 1,
          endLine: match.loc?.end?.line || 1,
          isAsync: match.right?.async || false,
          snippet: getSnippet(content, match.loc)
        }, 'fuzzy-variable'))
      }
    } catch (error) {
      // Skip unparseable files
    }
  }

  return results
}

/**
 * Find standalone function by name
 */
function findStandaloneFunction (packagePath, functionName) {
  const files = getAllJsFiles(packagePath)
  let query

  for (const file of files) {
    try {
      const { ast, content } = parseFile(file)
      const relPath = path.relative(packagePath, file)

      // Function declarations
      const funcDecl = esquery.query(ast, `FunctionDeclaration[id.name="${functionName}"]`)[0]
      if (funcDecl) {
        const isAsync = funcDecl.async || false
        return {
          found: true,
          searchType: 'function',
          // Top-level keys for Python workflow compatibility
          file: relPath,
          line: funcDecl.loc?.start?.line || 1,
          async: isAsync,
          module: {
            name: path.basename(packagePath),
            filePath: relPath,
            versionRange: getVersionRange(packagePath)
          },
          functionQuery: {
            functionName,
            kind: isAsync ? 'Async' : 'Sync',
            type: 'function'
          },
          channelName: functionName,
          location: {
            file: relPath,
            fullPath: file,
            line: funcDecl.loc?.start?.line || 1,
            endLine: funcDecl.loc?.end?.line || 1
          },
          sourceSnippet: getSnippet(content, funcDecl.loc)
        }
      }

      // Variable-assigned functions
      query = `VariableDeclarator[id.name="${functionName}"][init.type=/FunctionExpression|ArrowFunctionExpression/]`
      const varFuncs = esquery.query(ast, query)
      if (varFuncs.length > 0) {
        const decl = varFuncs[0]
        const isAsync = decl.init?.async || false
        return {
          found: true,
          searchType: 'function',
          // Top-level keys for Python workflow compatibility
          file: relPath,
          line: decl.loc?.start?.line || 1,
          async: isAsync,
          module: {
            name: path.basename(packagePath),
            filePath: relPath,
            versionRange: getVersionRange(packagePath)
          },
          functionQuery: {
            functionName,
            kind: isAsync ? 'Async' : 'Sync',
            type: 'function'
          },
          channelName: functionName,
          location: {
            file: relPath,
            fullPath: file,
            line: decl.loc?.start?.line || 1,
            endLine: decl.loc?.end?.line || 1
          },
          sourceSnippet: getSnippet(content, decl.loc)
        }
      }
    } catch (error) {
      // Skip unparseable files
    }
  }

  return null
}

// Helper functions

function findMethodInAst (ast, className, methodName, content) {
  const queries = [
    // ES6 class method: class Foo { bar() {} }
    `ClassDeclaration[id.name="${className}"] ClassBody MethodDefinition[key.name="${methodName}"]`,
    // Class expression: const Foo = class { bar() {} }
    `VariableDeclarator[id.name="${className}"] > ClassExpression ClassBody MethodDefinition[key.name="${methodName}"]`,
    // Prototype assignment: Foo.prototype.bar = function() {}
    `AssignmentExpression[left.object.object.name="${className}"]` +
    `[left.object.property.name="prototype"][left.property.name="${methodName}"]`,
    // Variable property assignment: proto.bar = function() {} (express pattern)
    `AssignmentExpression[left.object.name="${className}"][left.property.name="${methodName}"]`
  ]

  for (const query of queries) {
    try {
      const matches = esquery.query(ast, query)
      if (matches.length > 0) {
        const match = matches[0]
        return {
          line: match.loc?.start?.line || 1,
          endLine: match.loc?.end?.line || 1,
          isAsync: match.value?.async || match.right?.async || false,
          snippet: getSnippet(content, match.loc)
        }
      }
    } catch (error) {
      // Invalid query, try next
    }
  }

  return null
}

function formatResult (packagePath, relPath, fullPath, className, methodName, match, searchType) {
  return {
    found: true,
    searchType,
    // Top-level keys for Python workflow compatibility
    file: relPath,
    line: match.line,
    async: match.isAsync || false,
    module: {
      name: path.basename(packagePath),
      filePath: relPath,
      versionRange: getVersionRange(packagePath)
    },
    functionQuery: {
      className,
      methodName,
      kind: match.isAsync ? 'Async' : 'Sync',
      type: 'method' // Python expects function_query.type
    },
    channelName: `${className}_${methodName}`,
    location: {
      file: relPath,
      fullPath,
      line: match.line,
      endLine: match.endLine
    },
    sourceSnippet: match.snippet
  }
}

// CLI entry point
if (require.main === module) {
  const [packagePath, functionName, className, filePath] = process.argv.slice(2)

  if (!packagePath || !functionName) {
    console.error('Usage: node find-function.js <packagePath> <functionName> [className] [filePath]')
    process.exit(1)
  }

  const result = findFunction(packagePath, functionName, className || null, filePath || null)

  if (result) {
    console.log(JSON.stringify(result, null, 2))
    process.exit(0)
  } else {
    console.error('Not found')
    process.exit(1)
  }
}

module.exports = { findFunction, findExact, findFuzzy, findStandaloneFunction }
