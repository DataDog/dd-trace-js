'use strict'

/**
 * dd-analyze - Package analysis tool for APM instrumentation
 *
 * Main entry points:
 * 1. extractAllMethods - Extract all classes/methods/functions from a package
 * 2. flattenForWorkflow - Convert analysis to workflow-compatible format
 * 3. findFunction - Find a specific function with fallback search strategy
 *
 * Supporting modules:
 * - dynamic-resolver - Dynamic class resolution with TypeScript definitions
 * - utils - Parsing utilities (Meriyah + SWC) and JSDoc extraction
 */

const { extractAllMethods, flattenForWorkflow } = require('./extract-all-methods')
const { findFunction } = require('./find-function')
const {
  getExternalClassMethods,
  isKnownExternalClass,
  getRegisteredClasses,
  RESOLUTION_SOURCES,
  FAILURE_REASONS
} = require('./dynamic-resolver')
const { detectModuleType } = require('./detect-module-type')
const {
  parseFile,
  getAllJsFiles,
  getSnippet,
  getVersionRange,
  getPackageInfo,
  findJSDocForNode,
  parseJSDoc,
  hasSWC
} = require('./utils')

module.exports = {
  // Main analysis functions
  extractAllMethods,
  flattenForWorkflow,
  findFunction,
  detectModuleType,

  // Dynamic class resolver
  getExternalClassMethods,
  isKnownExternalClass,
  getRegisteredClasses,
  RESOLUTION_SOURCES,
  FAILURE_REASONS,

  // Utilities
  parseFile,
  getAllJsFiles,
  getSnippet,
  getVersionRange,
  getPackageInfo,
  findJSDocForNode,
  parseJSDoc,
  hasSWC
}
