'use strict'

/**
 * Dynamic Class Resolver
 *
 * Unified implementation for resolving external class information.
 * Uses ts-morph to parse @types/node TypeScript definitions for rich metadata,
 * with runtime introspection fallback for npm packages.
 *
 * Replaces external-class-registry.js with a cleaner, more dynamic approach.
 */

const path = require('path')
const fs = require('fs')

// Try to load ts-morph - it's an optional dependency
let Project = null
try {
  Project = require('ts-morph').Project
} catch (e) {
  // ts-morph not installed - will fall back to runtime introspection
}

const RESOLUTION_SOURCES = {
  NODE_BUILTIN: 'node_builtin',
  TYPESCRIPT_DEFS: 'typescript_defs',
  PACKAGE: 'package',
  INTERNAL: 'internal',
  FAILED: 'failed'
}

const FAILURE_REASONS = {
  PACKAGE_NOT_INSTALLED: 'package_not_installed',
  IMPORT_NOT_FOUND: 'import_not_found',
  INTROSPECTION_FAILED: 'introspection_failed',
  NO_PROTOTYPE: 'no_prototype',
  CLASS_NOT_EXPORTED: 'class_not_exported',
  CIRCULAR_INHERITANCE: 'circular_inheritance',
  MAX_DEPTH_EXCEEDED: 'max_depth_exceeded',
  UNKNOWN_CLASS: 'unknown_class',
  TYPE_DEFS_NOT_FOUND: 'type_defs_not_found',
  TS_MORPH_NOT_AVAILABLE: 'ts_morph_not_available'
}

const classCache = new Map()
let project = null

/**
 * Get or create the ts-morph project
 */
function getProject () {
  if (!project && Project) {
    project = new Project({
      skipFileDependencyResolution: true,
      skipAddingFilesFromTsConfig: true
    })
  }
  return project
}

/**
 * Clear all caches
 */
function clearCache () {
  classCache.clear()
  if (project) {
    project.getSourceFiles().forEach(sf => project.removeSourceFile(sf))
  }
}

/**
 * Get cache statistics
 */
function getCacheStats () {
  return {
    classesResolved: classCache.size,
    filesParsed: project ? project.getSourceFiles().length : 0
  }
}

const CLASS_TO_MODULE = {
  EventEmitter: { module: 'events', className: 'EventEmitter' },
  Stream: { module: 'stream', className: 'Stream' },
  Readable: { module: 'stream', className: 'Readable' },
  Writable: { module: 'stream', className: 'Writable' },
  Duplex: { module: 'stream', className: 'Duplex' },
  Transform: { module: 'stream', className: 'Transform' },
  'stream.Readable': { module: 'stream', className: 'Readable' },
  'stream.Writable': { module: 'stream', className: 'Writable' },
  'stream.Duplex': { module: 'stream', className: 'Duplex' },
  'stream.Transform': { module: 'stream', className: 'Transform' },
  IncomingMessage: { module: 'http', className: 'IncomingMessage' },
  ServerResponse: { module: 'http', className: 'ServerResponse' },
  Server: { module: 'http', className: 'Server' },
  ClientRequest: { module: 'http', className: 'ClientRequest' },
  Agent: { module: 'http', className: 'Agent' },
  'http.IncomingMessage': { module: 'http', className: 'IncomingMessage' },
  'http.ServerResponse': { module: 'http', className: 'ServerResponse' },
  'http.Server': { module: 'http', className: 'Server' },
  Socket: { module: 'net', className: 'Socket' },
  'net.Socket': { module: 'net', className: 'Socket' },
  'net.Server': { module: 'net', className: 'Server' },
  Buffer: { module: 'buffer', className: 'Buffer' },
  Worker: { module: 'worker_threads', className: 'Worker' },
  MessagePort: { module: 'worker_threads', className: 'MessagePort' },
  ChildProcess: { module: 'child_process', className: 'ChildProcess' },
  FSWatcher: { module: 'fs', className: 'FSWatcher' },
  ReadStream: { module: 'fs', className: 'ReadStream' },
  WriteStream: { module: 'fs', className: 'WriteStream' },
  Interface: { module: 'readline', className: 'Interface' },
  URL: { module: 'url', className: 'URL' },
  URLSearchParams: { module: 'url', className: 'URLSearchParams' },
  TLSSocket: { module: 'tls', className: 'TLSSocket' },
  Console: { module: 'console', className: 'Console' }
}

/**
 * Get the module name for a class
 */
function getModuleForClass (className) {
  const mapping = CLASS_TO_MODULE[className]
  return mapping ? mapping.module : null
}

/**
 * Check if a class name is a known external class (Node.js built-in)
 */
function isKnownExternalClass (className) {
  return className in CLASS_TO_MODULE
}

/**
 * Get all registered external class names
 */
function getRegisteredClasses () {
  return Object.keys(CLASS_TO_MODULE)
}

/**
 * Find the .d.ts file for a Node.js module
 * @param {string} moduleName - e.g., 'events', 'stream', 'http'
 * @returns {string|null} Path to .d.ts file
 */
function findTypeDefinitionFile (moduleName) {
  const possiblePaths = [
    // Local node_modules
    path.join(process.cwd(), 'node_modules', '@types', 'node', `${moduleName}.d.ts`),
    // Global types (in this package)
    path.join(__dirname, '..', '..', '..', 'node_modules', '@types', 'node', `${moduleName}.d.ts`),
    // Workspace root
    path.join(__dirname, '..', '..', '..', '..', '..', 'node_modules', '@types', 'node', `${moduleName}.d.ts`)
  ]

  for (const p of possiblePaths) {
    try {
      if (fs.existsSync(p)) {
        return p
      }
    } catch (e) {
      // Continue to next path
    }
  }

  return null
}

/**
 * Find type definition files for an npm package
 * Looks for bundled types or @types/<package>
 *
 * @param {string} packageName - e.g., 'ws', 'express', '@openai/agents'
 * @param {string} packageRoot - Root path where node_modules is located
 * @returns {string[]|null} Array of .d.ts file paths, or null if not found
 */
function findPackageTypeDefs (packageName, packageRoot = null) {
  const searchRoots = [
    packageRoot,
    process.cwd(),
    path.join(__dirname, '..', '..', '..'),
    path.join(__dirname, '..', '..', '..', '..', '..')
  ].filter(Boolean)

  // Handle scoped packages: @scope/package -> @types/scope__package
  const typesPackageName = packageName.startsWith('@')
    ? packageName.replace('@', '').replace('/', '__')
    : packageName

  for (const root of searchRoots) {
    const possiblePaths = [
      // Bundled types in the package itself
      path.join(root, 'node_modules', packageName, 'index.d.ts'),
      path.join(root, 'node_modules', packageName, 'dist', 'index.d.ts'),
      path.join(root, 'node_modules', packageName, 'lib', 'index.d.ts'),
      path.join(root, 'node_modules', packageName, 'types', 'index.d.ts'),
      // Check package.json for "types" or "typings" field
      path.join(root, 'node_modules', packageName),
      // @types/<package>
      path.join(root, 'node_modules', '@types', typesPackageName, 'index.d.ts')
    ]

    for (const p of possiblePaths) {
      try {
        // If it's a directory (package root), check package.json for types field
        if (fs.existsSync(p) && fs.statSync(p).isDirectory()) {
          const pkgJsonPath = path.join(p, 'package.json')
          if (fs.existsSync(pkgJsonPath)) {
            const pkgJson = JSON.parse(fs.readFileSync(pkgJsonPath, 'utf8'))
            const typesField = pkgJson.types || pkgJson.typings
            if (typesField) {
              const typesPath = path.join(p, typesField)
              if (fs.existsSync(typesPath)) {
                return [typesPath]
              }
            }
          }
        } else if (fs.existsSync(p) && p.endsWith('.d.ts')) {
          return [p]
        }
      } catch (e) {
        // Continue to next path
      }
    }
  }

  return null
}

/**
 * Resolve a class from an npm package's TypeScript definitions
 *
 * @param {string} packageName - The npm package name
 * @param {string} className - The class to find
 * @param {string} packageRoot - Root path for node_modules lookup
 * @returns {Object|null} Class info with methods, or null if not found
 */
function resolveFromPackageTypeDefs (packageName, className, packageRoot = null) {
  const cacheKey = `pkg:${packageName}:${className}`
  if (classCache.has(cacheKey)) {
    return classCache.get(cacheKey)
  }

  if (!Project) {
    return null
  }

  const typePaths = findPackageTypeDefs(packageName, packageRoot)
  if (!typePaths || typePaths.length === 0) {
    return null
  }

  const proj = getProject()
  if (!proj) return null

  for (const typePath of typePaths) {
    try {
      let sourceFile = proj.getSourceFile(typePath)
      if (!sourceFile) {
        sourceFile = proj.addSourceFileAtPath(typePath)
      }

      // Find the class or interface
      let classDecl = sourceFile.getClass(className)
      let isInterface = false

      if (!classDecl) {
        classDecl = sourceFile.getInterface(className)
        isInterface = true
      }

      // Check in module declarations and namespaces
      if (!classDecl) {
        for (const mod of sourceFile.getModules()) {
          classDecl = mod.getClass(className)
          if (classDecl) {
            isInterface = false
            break
          }
          const iface = mod.getInterface(className)
          if (iface) {
            classDecl = iface
            isInterface = true
            break
          }
        }
      }

      // Also check exported declarations
      if (!classDecl) {
        const exportedDecls = sourceFile.getExportedDeclarations()
        for (const [name, decls] of exportedDecls) {
          if (name === className) {
            for (const decl of decls) {
              if (decl.getKindName() === 'ClassDeclaration') {
                classDecl = decl
                isInterface = false
                break
              } else if (decl.getKindName() === 'InterfaceDeclaration') {
                classDecl = decl
                isInterface = true
                break
              }
            }
          }
        }
      }

      if (!classDecl) {
        continue // Try next type file
      }

      // Extract methods
      const methods = extractMethodsFromDeclaration(classDecl, isInterface, className)

      // Get parent class methods (inheritance)
      const inheritedMethods = []
      if (!isInterface && classDecl.getBaseClass) {
        const baseClass = classDecl.getBaseClass()
        if (baseClass) {
          const baseName = baseClass.getName()
          // Try to resolve parent from same package or Node.js builtins
          const parentInfo = resolveFromPackageTypeDefs(packageName, baseName, packageRoot) ||
                            resolveFromTypeScript(baseName)
          if (parentInfo?.methods) {
            inheritedMethods.push(...parentInfo.methods)
          }
        }
      }

      // For interfaces, get extended interfaces
      if (isInterface && classDecl.getExtends) {
        for (const ext of classDecl.getExtends()) {
          const extName = ext.getText().split('<')[0].trim()
          const parentInfo = resolveFromPackageTypeDefs(packageName, extName, packageRoot) ||
                            resolveFromTypeScript(extName)
          if (parentInfo?.methods) {
            inheritedMethods.push(...parentInfo.methods)
          }
        }
      }

      const result = {
        name: className,
        module: packageName,
        source: RESOLUTION_SOURCES.TYPESCRIPT_DEFS,
        isInterface,
        methods: [...methods, ...inheritedMethods],
        methodCount: methods.length + inheritedMethods.length
      }

      classCache.set(cacheKey, result)
      return result
    } catch (error) {
      // Try next type file
    }
  }

  return null
}

/**
 * Extract methods from a class or interface declaration using ts-morph
 */
function extractMethodsFromDeclaration (decl, isInterface, className) {
  const methods = []
  const memberMethods = decl.getMethods()

  for (const method of memberMethods) {
    try {
      const params = method.getParameters().map(p => ({
        name: p.getName(),
        type: p.getType().getText() || 'any',
        optional: p.isOptional(),
        hasDefault: p.hasInitializer()
      }))

      methods.push({
        name: method.getName(),
        parameters: params,
        returnType: method.getReturnType()?.getText() || 'void',
        isStatic: method.isStatic?.() || false,
        isAsync: method.isAsync?.() || false,
        description: method.getJsDocs().map(d => d.getDescription()).join('\n').trim() || undefined,
        inheritedFrom: className,
        isExternal: true
      })
    } catch (e) {
      // Skip methods that can't be parsed
    }
  }

  return methods
}

/**
 * Resolve a class from @types/node using ts-morph
 */
function resolveFromTypeScript (className) {
  // Check cache first
  const cacheKey = `ts:${className}`
  if (classCache.has(cacheKey)) {
    return classCache.get(cacheKey)
  }

  if (!Project) {
    return null
  }

  const proj = getProject()
  if (!proj) return null

  const moduleName = getModuleForClass(className)
  if (!moduleName) {
    return null
  }

  const typePath = findTypeDefinitionFile(moduleName)
  if (!typePath) {
    return null
  }

  try {
    let sourceFile = proj.getSourceFile(typePath)
    if (!sourceFile) {
      sourceFile = proj.addSourceFileAtPath(typePath)
    }

    // Find the class or interface
    let classDecl = sourceFile.getClass(className)
    let isInterface = false

    if (!classDecl) {
      classDecl = sourceFile.getInterface(className)
      isInterface = true
    }

    // Check in module declarations
    if (!classDecl) {
      for (const mod of sourceFile.getModules()) {
        classDecl = mod.getClass(className)
        if (classDecl) {
          isInterface = false
          break
        }
        const iface = mod.getInterface(className)
        if (iface) {
          classDecl = iface
          isInterface = true
          break
        }
      }
    }

    if (!classDecl) {
      return null
    }

    // Extract methods
    const methods = extractMethodsFromDeclaration(classDecl, isInterface, className)

    // Get parent class methods (inheritance)
    const inheritedMethods = []
    if (!isInterface && classDecl.getBaseClass) {
      const baseClass = classDecl.getBaseClass()
      if (baseClass) {
        const parentInfo = resolveFromTypeScript(baseClass.getName())
        if (parentInfo?.methods) {
          inheritedMethods.push(...parentInfo.methods)
        }
      }
    }

    // For interfaces, get extended interfaces
    if (isInterface && classDecl.getExtends) {
      for (const ext of classDecl.getExtends()) {
        const extName = ext.getText().split('<')[0]
        const parentInfo = resolveFromTypeScript(extName)
        if (parentInfo?.methods) {
          inheritedMethods.push(...parentInfo.methods)
        }
      }
    }

    const result = {
      name: className,
      module: moduleName,
      source: RESOLUTION_SOURCES.TYPESCRIPT_DEFS,
      isInterface,
      methods: [...methods, ...inheritedMethods],
      methodCount: methods.length + inheritedMethods.length
    }

    classCache.set(cacheKey, result)
    return result
  } catch (error) {
    return null
  }
}

// ============================================================================
// Runtime Introspection (Fallback)
// ============================================================================

/**
 * Extract methods from a class constructor's prototype
 */
function extractMethodsFromPrototype (ClassConstructor, className) {
  if (!ClassConstructor || !ClassConstructor.prototype) {
    return []
  }

  const methodNames = Object.getOwnPropertyNames(ClassConstructor.prototype)
    .filter(name => {
      if (name === 'constructor') return false
      try {
        return typeof ClassConstructor.prototype[name] === 'function'
      } catch (e) {
        return false
      }
    })

  return methodNames.map(name => {
    const method = ClassConstructor.prototype[name]
    let parameters = []
    try {
      const paramCount = method.length
      for (let i = 0; i < paramCount; i++) {
        parameters.push({ name: `arg${i}`, type: 'any', optional: false })
      }
    } catch (e) {
      parameters = []
    }

    return {
      name,
      parameters,
      isAsync: false,
      isStatic: false,
      inheritedFrom: className,
      isExternal: true,
      introspected: true
    }
  })
}

/**
 * Introspect a Node.js built-in class at runtime
 */
function introspectBuiltinClass (className) {
  const classMapping = CLASS_TO_MODULE[className]
  if (!classMapping) {
    return null
  }

  try {
    const mod = require(classMapping.module)
    const ClassConstructor = mod[classMapping.className]

    if (!ClassConstructor || !ClassConstructor.prototype) {
      return null
    }

    const methods = extractMethodsFromPrototype(ClassConstructor, className)

    return {
      name: className,
      source: RESOLUTION_SOURCES.NODE_BUILTIN,
      module: classMapping.module,
      methods,
      introspected: true
    }
  } catch (error) {
    return null
  }
}

/**
 * Attempt to dynamically introspect ANY class from a module path.
 * Works for installed npm packages, not just Node.js built-ins.
 *
 * Resolution order:
 * 1. Node.js built-ins via @types/node
 * 2. npm package TypeScript definitions (bundled or @types)
 * 3. Runtime introspection (fallback)
 */
function tryDynamicIntrospection (modulePath, className, packageRoot = null) {
  const result = {
    resolved: false,
    source: RESOLUTION_SOURCES.FAILED,
    reason: null,
    error: null,
    className,
    modulePath,
    methods: [],
    methodCount: 0
  }

  // Strategy 1: Check if it's a known Node.js built-in
  if (CLASS_TO_MODULE[className]) {
    // Try TypeScript definitions first (rich metadata)
    const tsResult = resolveFromTypeScript(className)
    if (tsResult) {
      return {
        resolved: true,
        source: RESOLUTION_SOURCES.TYPESCRIPT_DEFS,
        reason: null,
        error: null,
        className,
        modulePath: tsResult.module,
        methods: tsResult.methods,
        methodCount: tsResult.methods.length
      }
    }

    // Fall back to runtime introspection for Node.js built-ins
    const introspected = introspectBuiltinClass(className)
    if (introspected) {
      return {
        resolved: true,
        source: RESOLUTION_SOURCES.NODE_BUILTIN,
        reason: null,
        error: null,
        className,
        modulePath: introspected.module,
        methods: introspected.methods,
        methodCount: introspected.methods.length
      }
    }
  }

  // Strategy 2: Try npm package TypeScript definitions (rich metadata)
  if (modulePath) {
    const pkgTsResult = resolveFromPackageTypeDefs(modulePath, className, packageRoot)
    if (pkgTsResult) {
      return {
        resolved: true,
        source: RESOLUTION_SOURCES.TYPESCRIPT_DEFS,
        reason: null,
        error: null,
        className,
        modulePath: pkgTsResult.module,
        methods: pkgTsResult.methods,
        methodCount: pkgTsResult.methods.length
      }
    }
  }

  // Strategy 3: Fall back to runtime introspection
  const pathsToTry = [modulePath]

  if (packageRoot) {
    pathsToTry.unshift(path.join(packageRoot, 'node_modules', modulePath))
  }

  for (const tryPath of pathsToTry) {
    try {
      const mod = require(tryPath)

      let ClassConstructor = null

      // Direct export
      if (typeof mod === 'function' && mod.name === className) {
        ClassConstructor = mod
      }
      // Named export
      else if (mod[className]) {
        ClassConstructor = mod[className]
      }
      // Default export with the class
      else if (mod.default && mod.default[className]) {
        ClassConstructor = mod.default[className]
      }
      // The module itself is the class
      else if (typeof mod === 'function' && mod.prototype) {
        ClassConstructor = mod
      }

      if (!ClassConstructor) {
        result.reason = FAILURE_REASONS.CLASS_NOT_EXPORTED
        result.error = `Class '${className}' not found in module '${modulePath}'`
        continue
      }

      if (!ClassConstructor.prototype) {
        result.reason = FAILURE_REASONS.NO_PROTOTYPE
        result.error = `'${className}' has no prototype`
        continue
      }

      const methods = extractMethodsFromPrototype(ClassConstructor, className)

      return {
        resolved: true,
        source: RESOLUTION_SOURCES.PACKAGE,
        reason: null,
        error: null,
        className,
        modulePath: tryPath,
        methods,
        methodCount: methods.length
      }
    } catch (error) {
      result.reason = FAILURE_REASONS.PACKAGE_NOT_INSTALLED
      result.error = error.message
    }
  }

  return result
}

// ============================================================================
// Main Public API
// ============================================================================

/**
 * Get methods for an external class.
 * Tries TypeScript definitions first, then runtime introspection.
 *
 * @param {string} className - Name of the external class
 * @returns {Object|null} Class info with methods, or null if not found
 */
function getExternalClassMethods (className) {
  // Try TypeScript definitions first (rich metadata)
  const tsResult = resolveFromTypeScript(className)
  if (tsResult) {
    return tsResult
  }

  // Fall back to runtime introspection
  const introspected = introspectBuiltinClass(className)
  if (introspected) {
    return introspected
  }

  return null
}

/**
 * Get class info with resolution details
 */
function getClassInfo (className) {
  const info = getExternalClassMethods(className)
  if (!info) return null

  return {
    name: info.name,
    module: info.module,
    source: info.source,
    methods: info.methods,
    methodCount: info.methods?.length || 0
  }
}

// ============================================================================
// Exports
// ============================================================================

module.exports = {
  // Constants
  RESOLUTION_SOURCES,
  FAILURE_REASONS,
  CLASS_TO_MODULE,

  // Main API
  getExternalClassMethods,
  getClassInfo,
  isKnownExternalClass,
  getRegisteredClasses,

  // Resolution functions
  tryDynamicIntrospection,
  resolveFromTypeScript,
  resolveFromPackageTypeDefs,
  introspectBuiltinClass,

  // Utilities
  extractMethodsFromPrototype,
  findTypeDefinitionFile,
  findPackageTypeDefs,
  getModuleForClass,
  clearCache,
  getCacheStats
}
