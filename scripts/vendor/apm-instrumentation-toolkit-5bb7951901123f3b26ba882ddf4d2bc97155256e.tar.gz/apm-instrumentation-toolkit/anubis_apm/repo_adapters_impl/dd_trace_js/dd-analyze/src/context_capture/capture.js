#!/usr/bin/env node
'use strict'

/* eslint-disable no-console */

/**
 * Phase 4 Context Capture Tool
 *
 * Simplified version of dd-apm-v3 context capture that works with .analysis/ directory
 *
 * Usage:
 *   node capture.js <analysis-file> <sample-app-file> <output-file>
 */

const fs = require('fs').promises
const path = require('path')
const { fork } = require('child_process')

async function captureContext (analysisFile, sampleAppFile, outputFile, repoRoot) {
  console.log('📸 Capturing runtime context...')
  console.log(`  Analysis: ${analysisFile}`)
  console.log(`  Sample app: ${sampleAppFile}`)
  console.log(`  Output: ${outputFile}`)
  console.log(`  Repo root: ${repoRoot || '(auto-detect)'}`)

  // Read analysis file (validate path is within analysis directory)
  const analysisContent = await fs.readFile(analysisFile, 'utf8')
  const analysis = JSON.parse(analysisContent)

  // Try to load enrichments file for file_path data
  // Enrichments is in the same data/ directory as agent.json
  let enrichments = {}
  const enrichmentsPath = path.join(path.dirname(analysisFile), 'enrichments.json')
  try {
    const enrichmentsContent = await fs.readFile(enrichmentsPath, 'utf8')
    enrichments = JSON.parse(enrichmentsContent)
    console.log(`✓ Loaded enrichments from: ${enrichmentsPath}`)
  } catch (e) {
    console.log(`  (No enrichments file found at ${enrichmentsPath})`)
  }

  // Get instrumentations - support both final analysis and agent analysis formats
  // Final analysis has: orchestrion_config.instrumentations
  // Agent analysis has: analysis.instrumentation_targets
  let instrumentations = analysis.orchestrion_config?.instrumentations || []

  // If no orchestrion_config, try to convert from agent analysis format
  if (instrumentations.length === 0 && analysis.analysis?.instrumentation_targets) {
    const mainModuleName = analysis.package_name
    instrumentations = analysis.analysis.instrumentation_targets.map(target => {
      // Look up file_path and module_name from enrichments using the location as key
      const location = target.location // e.g., "Session.prototype.run"
      const enrichment = enrichments.targets?.[location]
      const filePath = enrichment?.file_path || target.file_path || 'index.js'
      // Use module_name from enrichments if available (handles sub-packages like neo4j-driver-core)
      const moduleName = enrichment?.module_name || mainModuleName

      return {
        module_name: moduleName,
        version_range: '*',
        function_query: {
          name: target.method?.split('.').pop() || target.method,
          class: target.location?.split('.')[0] || null,
          type: 'method'
        },
        file_path: filePath,
        operation: target.operation || 'unknown'
      }
    })
    // Store converted instrumentations for createInstrumentationHook
    analysis.orchestrion_config = { instrumentations }
    analysis.package = { name: mainModuleName }
  }

  if (instrumentations.length === 0) {
    throw new Error('No instrumentations found in analysis file (checked both orchestrion_config and analysis.instrumentation_targets)')
  }

  console.log(`\n✓ Found ${instrumentations.length} instrumentations to capture`)

  // Create instrumentation hook (use .cjs to work with ESM packages that have "type": "module")
  const hookPath = path.resolve(path.dirname(outputFile), 'context-capture-hook.cjs')
  await createInstrumentationHook(analysis, hookPath, repoRoot)

  console.log(`✓ Created instrumentation hook: ${hookPath}`)

  // Run sample app with hook
  const logPath = path.resolve(path.dirname(outputFile), 'capture.log')
  const capturedContexts = await runSampleAppWithHook(sampleAppFile, hookPath, logPath)

  console.log(`\n✓ Captured ${capturedContexts.length} context snapshots`)

  // Warn if no contexts were captured - this often indicates a module mismatch
  if (capturedContexts.length === 0) {
    const moduleName = analysis.package?.name || analysis.package_name || 'unknown'
    console.log('\n⚠️  WARNING: No contexts captured!')
    console.log('   This often happens when:')
    console.log('   1. Sample app imports a different package than the one being analyzed')
    console.log(`      - Analyzed package: ${moduleName}`)
    console.log('      - Check that sample-app.js uses require() with this exact package name')
    console.log('   2. The Hook for the package did not fire (check for "[Hook] Module loaded:" in logs)')
    console.log('   3. The methods being instrumented were not called by the sample app')
  }

  // Save results
  await fs.writeFile(outputFile, JSON.stringify(capturedContexts, null, 2))
  console.log(`✓ Context saved to: ${outputFile}`)
  console.log(`✓ Logs saved to: ${logPath}`)

  // Keep hook file for debugging - saved in runtime dir
  console.log(`✓ Hook file preserved for debugging: ${hookPath}`)
}

async function createInstrumentationHook (analysis, hookPath, repoRoot) {
  const instrumentations = analysis.orchestrion_config?.instrumentations || []
  const moduleName = analysis.package?.name

  // Require repo root to be explicitly provided for reliable paths
  if (!repoRoot) {
    throw new Error('repoRoot is required for context capture - paths cannot be reliably resolved without it')
  }

  // Use absolute paths to avoid issues with relative path resolution from different directories
  const shimmerPath = path.resolve(repoRoot, 'packages', 'datadog-shimmer')
  const hookHelperPath = path.resolve(
    repoRoot, 'packages', 'datadog-instrumentations', 'src', 'helpers', 'hook'
  )

  // Group instrumentations by (packageName, file) to handle dependencies
  // Supports: node_modules/pkg/file.js, ../pkg/file.js, or just file.js
  const packageFileToInstrumentations = new Map()
  instrumentations.forEach(config => {
    const filePath = config.file_path || 'index.js'
    // Use module_name from config if available (handles sub-packages)
    let targetPackage = config.module_name || moduleName
    let targetFilePath = filePath

    // Check if the file is in a dependency
    if (filePath.startsWith('node_modules/')) {
      // Format: node_modules/package-name/lib/file.js
      const parts = filePath.replace('node_modules/', '').split('/')
      if (parts[0].startsWith('@')) {
        targetPackage = parts.slice(0, 2).join('/')
        targetFilePath = parts.slice(2).join('/')
      } else {
        targetPackage = parts[0]
        targetFilePath = parts.slice(1).join('/')
      }
    } else if (filePath.startsWith('../')) {
      // Format: ../package-name/lib/file.js (relative to main package)
      const parts = filePath.replace('../', '').split('/')
      if (parts[0].startsWith('@')) {
        targetPackage = parts.slice(0, 2).join('/')
        targetFilePath = parts.slice(2).join('/')
      } else {
        targetPackage = parts[0]
        targetFilePath = parts.slice(1).join('/')
      }
    }

    const key = `${targetPackage}::${targetFilePath}`
    if (!packageFileToInstrumentations.has(key)) {
      packageFileToInstrumentations.set(key, { package: targetPackage, file: targetFilePath, configs: [] })
    }
    packageFileToInstrumentations.get(key).configs.push(config)
  })

  // Generate Hook() calls for each (package, file) pair
  const hookSetups = Array.from(packageFileToInstrumentations.values()).map(({ package: targetPackage, file: targetFilePath, configs }) => {
    // Generate the wrapper logic for all methods in this file
    const wrapperCode = configs.map((config, idx) => {
      const className = config.function_query?.class
      const methodName = config.function_query?.name
      const operation = config.operation || 'unknown'
      const isConstructor = className && methodName && className === methodName
      const varPrefix = `hook${idx}`

      if (isConstructor) {
        return `
  // Wrap constructor ${className}
  const ${varPrefix}Class = exports.default || exports['${className}'] || exports
  if (${varPrefix}Class && typeof ${varPrefix}Class === 'function') {
    shimmer.wrap(exports, '${className}', (OriginalConstructor) => {
      return function (...args) {
        if (process.send) {
          const context = {
            operation: '${operation}',
            className: '${className}',
            methodName: '${methodName}',
            arguments: args,
            self: this
          }
          process.send({ contextString: JSON.stringify(sanitizeForJson(context)) })
        }
        return new OriginalConstructor(...args)
      }
    })
    console.log('[Hook] ✓ Wrapped constructor ${className}')
  } else {
    console.log('[Hook] ⚠️  Could not find constructor ${className}')
  }`
      } else {
        return `
  // Wrap method ${className}.${methodName}
  console.log('[Hook] Intercepted ${targetFilePath}, exports keys:', Object.keys(exports))
  const ${varPrefix}Class = exports.default || exports['${className}'] || exports
  console.log('[Hook] Class for ${methodName}:', ${varPrefix}Class?.name || typeof ${varPrefix}Class)
  console.log('[Hook] Has prototype?', !!${varPrefix}Class?.prototype)
  console.log('[Hook] Has method ${methodName}?', !!${varPrefix}Class?.prototype?.['${methodName}'])

  if (${varPrefix}Class && ${varPrefix}Class.prototype && ${varPrefix}Class.prototype['${methodName}']) {
    shimmer.wrap(${varPrefix}Class.prototype, '${methodName}', (original) => {
      console.log('[Hook] Wrapper installed for ${methodName}')
      return function (...args) {
        console.log('[Hook] 🎯 METHOD CALLED: ${methodName}')
        const result = original.apply(this, args)
        // Detect if return value is a Promise (thenable)
        const isPromise = result && typeof result.then === 'function'

        const sendContext = (resolvedResult, error) => {
          if (process.send) {
            const context = {
              operation: '${operation}',
              className: ${className ? `'${className}'` : 'null'},
              methodName: '${methodName}',
              arguments: args,
              self: this,
              returnsPromise: isPromise,
              result: resolvedResult,
              error: error ? { message: error.message, name: error.name } : null
            }
            console.log('[Hook] Sending context to parent...' + (isPromise ? ' (Promise resolved)' : ''))
            process.send({ contextString: JSON.stringify(sanitizeForJson(context)) })
          }
        }

        if (isPromise) {
          // Wait for Promise to resolve/reject before capturing
          result.then(
            (resolved) => sendContext(resolved, null),
            (err) => sendContext(null, err)
          )
        } else {
          sendContext(result, null)
        }

        return result
      }
    })
    console.log('[Hook] ✓ Wrapped ${className ? className + '.' : ''}${methodName}')
  } else {
    console.log('[Hook] ⚠️  Could not find ${className ? className + '.' : ''}${methodName}')
    console.log('[Hook]     exports:', Object.keys(exports))
    console.log('[Hook]     Class:', ${varPrefix}Class?.name)
  }`
      }
    }).join('\n')

    // Normalize file path for matching (handle esm/cjs and .d.ts/.js differences)
    // e.g., "dist/esm/classes/queue.d.ts" should match "dist/cjs/classes/queue.js"
    const normalizedPath = targetFilePath
      .replace(/\\/g, '/')
      .replace(/\.d\.ts$/, '')
      .replace(/\.ts$/, '')
      .replace(/\.js$/, '')
      .replace(/\/esm\//, '/')
      .replace(/\/cjs\//, '/')

    return `
// Hook for ${targetPackage}:${targetFilePath} (normalized: ${normalizedPath})
Hook(['${targetPackage}'], { internals: true }, (exports, moduleName, moduleBaseDir) => {
  const modulePath = require('path').join(moduleBaseDir, moduleName)
  console.log('[Hook] Module loaded:', modulePath)

  // Check if this is the file we want to instrument
  // Normalize the loaded path for comparison
  const normalizedModulePath = modulePath
    .replace(/\\\\/g, '/')
    .replace(/\\.d\\.ts$/, '')
    .replace(/\\.ts$/, '')
    .replace(/\\.js$/, '')
    .replace(/\\/esm\\//, '/')
    .replace(/\\/cjs\\//, '/')

  if (!normalizedModulePath.includes('${normalizedPath}')) {
    return exports
  }

  console.log('[Hook] Instrumenting ${targetPackage}:${targetFilePath}')
  ${wrapperCode}

  return exports
})`
  }).join('\n\n')

  const hookContent = `
'use strict'

const Hook = require('${hookHelperPath.replace(/\\/g, '/')}')
const shimmer = require('${shimmerPath.replace(/\\/g, '/')}')

function sanitizeForJson(obj, maxDepth = 3, maxStringLen = 200) {
  const seen = new WeakSet();

  function sanitize(value, depth) {
    if (value === null || value === undefined) return value;

    if (typeof value === 'function') {
      return '[Function: ' + (value.name || 'anonymous') + ']';
    }

    if (typeof value === 'string') {
      if (value.length > maxStringLen) {
        return value.substring(0, maxStringLen) + '... [truncated]';
      }
      return value;
    }

    if (typeof value === 'number' || typeof value === 'boolean') {
      return value;
    }

    if (Buffer.isBuffer(value)) {
      return '[Buffer: ' + value.length + ' bytes]';
    }

    if (typeof value !== 'object') {
      return String(value);
    }

    // Handle objects and arrays
    if (seen.has(value)) {
      return '[Circular]';
    }
    seen.add(value);

    if (depth >= maxDepth) {
      return Array.isArray(value) ? '[Array]' : '[Object]';
    }

    if (Array.isArray(value)) {
      return value.slice(0, 10).map(item => sanitize(item, depth + 1));
    }

    // Object - extract properties
    const result = {};
    for (const key of Object.keys(value)) {
      // Skip deeply nested _ properties, but keep top-level ones
      if (key.startsWith('_') && depth > 1) continue;
      try {
        result[key] = sanitize(value[key], depth + 1);
      } catch (e) {
        result[key] = '[Error reading property]';
      }
    }
    return result;
  }

  return sanitize(obj, 0);
}

console.log('🔧 Setting up instrumentation hooks for context capture...')

// Set up Hook() calls - these will intercept module loads via import-in-the-middle/require-in-the-middle
${hookSetups}

console.log('✓ Instrumentation hooks ready')
console.log('  (Hooks will trigger when packages are required)\\n')
`

  await fs.writeFile(hookPath, hookContent)
}

function runSampleAppWithHook (sampleAppPath, hookPath, logPath) {
  return new Promise((resolve, reject) => {
    const capturedContexts = []
    const allOutput = []

    console.log('\n🚀 Running sample app with hooks...')

    const child = fork(sampleAppPath, [], {
      execArgv: ['-r', hookPath],
      silent: true,
      env: {
        ...process.env,
        NODE_ENV: 'test'
      }
    })

    child.on('message', ({ contextString }) => {
      if (contextString) {
        try {
          const context = JSON.parse(contextString)
          capturedContexts.push(context)
          const logLine = `📦 Captured: ${context.operation} (${context.className || 'global'}.${context.methodName})`
          console.log(`  ${logLine}`)
          allOutput.push(logLine)
        } catch (e) {
          const errorMsg = `Failed to parse context: ${e.message}`
          console.error(errorMsg)
          allOutput.push(`ERROR: ${errorMsg}`)
        }
      }
    })

    child.stdout.on('data', (data) => {
      const lines = data.toString().split('\n').filter(line => line.trim())
      lines.forEach(line => {
        console.log(`  [App] ${line}`)
        allOutput.push(`[STDOUT] ${line}`)
      })
    })

    child.stderr.on('data', (data) => {
      const lines = data.toString().split('\n').filter(line => line.trim())
      lines.forEach(line => {
        console.error(`  [Error] ${line}`)
        allOutput.push(`[STDERR] ${line}`)
      })
    })

    child.on('exit', async (code) => {
      // Save all output to log file
      try {
        await fs.writeFile(logPath, allOutput.join('\n') + '\n')
      } catch (err) {
        console.error(`Failed to write log file: ${err.message}`)
      }

      if (code === 0) {
        console.log('\n✓ Sample app completed successfully')
        resolve(capturedContexts)
      } else {
        // Still save captured contexts even if app crashes
        if (capturedContexts.length > 0) {
          console.log(`\n⚠️  Sample app exited with code ${code}, but captured ${capturedContexts.length} contexts`)
          resolve(capturedContexts)
        } else {
          reject(new Error(`Sample app exited with code ${code}`))
        }
      }
    })

    child.on('error', (err) => {
      reject(err)
    })
  })
}

async function main () {
  const args = process.argv.slice(2)

  if (args.length < 3) {
    console.error('Usage: capture.js <analysis-file> <sample-app-file> <output-file> [repo-root]')
    process.exit(1)
  }

  const [analysisFile, sampleAppFile, outputFile, repoRoot] = args

  try {
    await captureContext(analysisFile, sampleAppFile, outputFile, repoRoot)
    console.log('\n✨ Context capture complete!')
  } catch (error) {
    console.error('\n❌ Context capture failed:', error.message)
    console.error(error.stack)
    process.exit(1)
  }
}

main()
