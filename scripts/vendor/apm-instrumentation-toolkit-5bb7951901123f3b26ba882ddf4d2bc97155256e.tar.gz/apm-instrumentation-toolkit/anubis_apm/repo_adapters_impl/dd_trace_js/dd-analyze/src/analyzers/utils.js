'use strict'

/**
 * Shared utilities for dd-analyze
 *
 * Provides parsing utilities supporting both Meriyah (fast, JS-only) and
 * SWC (TypeScript support, more robust). Also includes JSDoc extraction
 * and file traversal utilities.
 */

const fs = require('fs')
const path = require('path')
const { parse: meriyahParse } = require('meriyah') // eslint-disable-line import/no-extraneous-dependencies

// Optional SWC import - falls back gracefully if not installed
let swc = null
try {
  swc = require('@swc/core') // eslint-disable-line import/no-extraneous-dependencies
} catch (e) {
  // SWC not available, will use Meriyah only
}

/**
 * Parse a JavaScript/TypeScript file.
 * Uses Meriyah for .js/.cjs files (faster), SWC for .ts/.tsx (TypeScript support).
 * Falls back to SWC if Meriyah fails.
 *
 * @param {string} filePath - Path to the file to parse
 * @param {Object} options - Parsing options
 * @param {boolean} options.extractComments - Whether to extract comments for JSDoc
 * @param {string} options.preferParser - 'meriyah' | 'swc' (default: auto-detect)
 * @returns {Object} { ast, content, comments?, parser }
 */
function parseFile (filePath, options = {}) {
  const content = fs.readFileSync(filePath, 'utf8')
  const ext = path.extname(filePath)
  const isTypeScript = ext === '.ts' || ext === '.tsx'
  const isJSX = ext === '.jsx' || ext === '.tsx'

  const isModule = filePath.endsWith('.mjs') ||
    filePath.includes('/esm/') ||
    content.includes('export default') ||
    content.includes('export {') ||
    /^import\s+/.test(content) ||
    /\nimport\s+/.test(content)

  // Use SWC for TypeScript
  if (isTypeScript && swc) {
    return parseWithSWC(content, filePath, { isTypeScript, isJSX, isModule, ...options })
  }

  // Try Meriyah first for JavaScript (faster)
  if (options.preferParser !== 'swc') {
    try {
      return parseWithMeriyah(content, filePath, { isModule, ...options })
    } catch (meriyahError) {
      // Fall back to SWC if available
      if (swc) {
        try {
          return parseWithSWC(content, filePath, { isTypeScript, isJSX, isModule, ...options })
        } catch (swcError) {
          // Both parsers failed, throw original error
          throw meriyahError
        }
      }
      throw meriyahError
    }
  }

  // Explicitly requested SWC
  if (swc) {
    return parseWithSWC(content, filePath, { isTypeScript, isJSX, isModule, ...options })
  }

  // No SWC, use Meriyah
  return parseWithMeriyah(content, filePath, { isModule, ...options })
}

/**
 * Parse with Meriyah (fast, JavaScript only)
 */
function parseWithMeriyah (content, filePath, options = {}) {
  const comments = []
  const parseOptions = {
    loc: true,
    ranges: true,
    module: options.isModule || false,
    next: true
  }

  // Enable comment extraction if requested
  if (options.extractComments) {
    parseOptions.onComment = comments
  }

  const ast = meriyahParse(content, parseOptions)

  return {
    ast,
    content,
    comments: options.extractComments ? formatMeriyahComments(comments) : undefined,
    parser: 'meriyah'
  }
}

/**
 * Parse with SWC (TypeScript support, slower)
 */
function parseWithSWC (content, filePath, options = {}) {
  if (!swc) {
    throw new Error('SWC not available - install @swc/core for TypeScript support')
  }

  const ast = swc.parseSync(content, {
    syntax: options.isTypeScript ? 'typescript' : 'ecmascript',
    tsx: options.isJSX && options.isTypeScript,
    jsx: options.isJSX && !options.isTypeScript,
    decorators: true,
    dynamicImport: true
  })

  // SWC doesn't extract comments directly, use manual extraction
  const comments = options.extractComments ? extractCommentsFromSource(content) : undefined

  return {
    ast,
    content,
    comments,
    parser: 'swc',
    spanOffset: ast.span?.start || 0 // SWC uses global span offsets
  }
}

/**
 * Format Meriyah comments to a standard structure
 */
function formatMeriyahComments (comments) {
  return comments
    .filter(c => c.type === 'Block' && c.value.trim().startsWith('*'))
    .map(c => ({
      text: c.value,
      startLine: c.loc?.start?.line || 0,
      endLine: c.loc?.end?.line || 0,
      start: c.start || 0,
      end: c.end || 0
    }))
}

/**
 * Extract JSDoc-style comments from source code manually.
 * Used for SWC parser which doesn't track comments.
 *
 * @param {string} content - Source code content
 * @returns {Array} Array of comment objects with text, startLine, endLine
 */
function extractCommentsFromSource (content) {
  const comments = []
  const lines = content.split('\n')
  let inBlockComment = false
  let currentComment = { text: '', start: 0, end: 0, startLine: 0, endLine: 0 }
  let charPos = 0

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]

    // Check for block comment start (JSDoc style)
    const blockStart = line.indexOf('/**')
    if (blockStart !== -1 && !inBlockComment) {
      inBlockComment = true
      currentComment = {
        text: line.substring(blockStart + 3),
        start: charPos + blockStart,
        startLine: i + 1
      }
    } else if (inBlockComment) {
      // Check for block comment end
      const blockEnd = line.indexOf('*/')
      if (blockEnd !== -1) {
        currentComment.text += '\n' + line.substring(0, blockEnd)
        currentComment.end = charPos + blockEnd
        currentComment.endLine = i + 1
        comments.push(currentComment)
        inBlockComment = false
      } else {
        currentComment.text += '\n' + line
      }
    }

    charPos += line.length + 1 // +1 for newline
  }

  return comments
}

/**
 * Find JSDoc comment for a given AST node based on line numbers.
 *
 * @param {Object} node - AST node with loc or span
 * @param {Array} comments - Array of parsed comments
 * @param {string} content - Source content (for span-to-line conversion)
 * @param {number} spanOffset - SWC span offset (0 for Meriyah)
 * @returns {Object|null} Parsed JSDoc or null
 */
function findJSDocForNode (node, comments, content, spanOffset = 0) {
  if (!node || !comments || comments.length === 0) return null

  // Get node's starting line
  let nodeLine
  if (node.loc?.start?.line) {
    nodeLine = node.loc.start.line
  } else if (node.span?.start && content) {
    nodeLine = spanToLine(content, node.span.start, spanOffset)
  } else {
    return null
  }

  // Find comment closest before this node (within 5 lines)
  const relevantComments = comments.filter(c =>
    c.endLine < nodeLine &&
    c.endLine >= nodeLine - 5
  )

  if (relevantComments.length === 0) return null

  // Get the closest comment
  const closestComment = relevantComments[relevantComments.length - 1]
  return parseJSDoc(closestComment.text)
}

/**
 * Parse JSDoc comment text into structured data.
 *
 * @param {string} commentText - Raw JSDoc comment text
 * @returns {Object} Parsed JSDoc with description, params, returns, etc.
 */
function parseJSDoc (commentText) {
  if (!commentText) return null

  const jsdoc = {
    description: '',
    params: [],
    returns: null,
    throws: [],
    visibility: null,
    isPublic: null,
    isPrivate: null,
    isAsync: null,
    deprecated: false
  }

  const lines = commentText.split('\n').map(l => l.trim().replace(/^\*\s?/, ''))
  const currentDescription = []

  for (const line of lines) {
    // @param {Type} name - description
    const paramMatch = line.match(/@param\s+\{([^}]+)\}\s+(\[)?([^\s\]]+)(\])?\s*(.*)/)
    if (paramMatch) {
      const [, type, optBracketStart, name, , description] = paramMatch
      const isOptional = !!optBracketStart
      const nameMatch = name.match(/([^=]+)(=(.+))?/)
      const paramName = nameMatch[1]
      const defaultValue = nameMatch[3]

      jsdoc.params.push({
        name: paramName,
        type: parseJSDocType(type),
        optional: isOptional,
        defaultValue: defaultValue || null,
        description: description?.trim() || ''
      })
      continue
    }

    // @returns {Type} description
    const returnMatch = line.match(/@returns?\s+\{([^}]+)\}\s*(.*)/)
    if (returnMatch) {
      jsdoc.returns = {
        type: parseJSDocType(returnMatch[1]),
        description: returnMatch[2]?.trim() || ''
      }
      continue
    }

    // @throws {Type} description
    const throwsMatch = line.match(/@throws\s+\{([^}]+)\}\s*(.*)/)
    if (throwsMatch) {
      jsdoc.throws.push({
        type: throwsMatch[1],
        description: throwsMatch[2]?.trim() || ''
      })
      continue
    }

    // Visibility tags
    if (line.includes('@public')) {
      jsdoc.visibility = 'public'
      jsdoc.isPublic = true
      continue
    }
    if (line.includes('@private')) {
      jsdoc.visibility = 'private'
      jsdoc.isPrivate = true
      continue
    }
    if (line.includes('@protected')) {
      jsdoc.visibility = 'protected'
      continue
    }

    // @async
    if (line.includes('@async')) {
      jsdoc.isAsync = true
      continue
    }

    // @deprecated
    if (line.includes('@deprecated')) {
      jsdoc.deprecated = true
      continue
    }

    // Description (lines without tags)
    if (!line.startsWith('@') && line.length > 0) {
      currentDescription.push(line)
    }
  }

  jsdoc.description = currentDescription.join(' ').trim()
  return jsdoc
}

/**
 * Parse JSDoc type string into structured type info.
 *
 * @param {string} typeString - Raw type string (e.g., "string|number", "Array<T>")
 * @returns {Object} Parsed type information
 */
function parseJSDocType (typeString) {
  if (!typeString) return { type: 'any' }

  typeString = typeString.trim()

  // Union types: (String|Buffer|null)
  if (typeString.includes('|')) {
    const types = typeString.replace(/[()]/g, '').split('|').map(t => t.trim())
    return { type: 'union', types, raw: typeString }
  }

  // Array types: String[], Array<String>
  if (typeString.endsWith('[]')) {
    return { type: 'array', elementType: typeString.slice(0, -2), raw: typeString }
  }
  if (typeString.startsWith('Array<') && typeString.endsWith('>')) {
    return { type: 'array', elementType: typeString.slice(6, -1), raw: typeString }
  }

  // Promise types: Promise<Type>
  if (typeString.startsWith('Promise<') && typeString.endsWith('>')) {
    return { type: 'Promise', resolveType: typeString.slice(8, -1), raw: typeString, isAsync: true }
  }

  // Function type
  if (typeString === 'Function' || typeString === 'function') {
    return { type: 'Function', isCallback: true, raw: typeString }
  }

  // Object
  if (typeString.toLowerCase() === 'object') {
    return { type: 'object', raw: typeString }
  }

  // Simple type
  return { type: typeString, raw: typeString }
}

/**
 * Convert SWC span position to line number.
 *
 * @param {string} content - File content
 * @param {number} spanPosition - SWC's global span position
 * @param {number} spanOffset - The file's starting span offset
 * @returns {number|undefined} Line number or undefined
 */
function spanToLine (content, spanPosition, spanOffset = 0) {
  if (!spanPosition || !content) return undefined
  const localPosition = spanPosition - spanOffset
  if (localPosition < 0 || localPosition > content.length) return undefined
  return content.substring(0, localPosition).split('\n').length
}

/**
 * Get all JavaScript/TypeScript files in a directory recursively.
 *
 * @param {string} dir - Directory to search
 * @param {Array} files - Accumulator (internal)
 * @returns {string[]} Array of file paths
 */
function getAllJsFiles (dir, files = []) {
  if (!fs.existsSync(dir)) return files

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name)

    if (entry.isDirectory()) {
      // Skip hidden directories, node_modules, and test directories
      if (!entry.name.startsWith('.') &&
          entry.name !== 'node_modules' &&
          entry.name !== 'test' &&
          entry.name !== 'tests' &&
          entry.name !== '__tests__') {
        getAllJsFiles(fullPath, files)
      }
    } else if (entry.isFile()) {
      // Include .js, .cjs, .mjs, .ts, .tsx (exclude .min.js, .d.ts)
      if (/\.(js|cjs|mjs|ts|tsx)$/.test(entry.name) &&
          !entry.name.endsWith('.min.js') &&
          !entry.name.endsWith('.d.ts')) {
        files.push(fullPath)
      }
    }
  }

  return files
}

/**
 * Get a snippet of code from content using location info.
 *
 * @param {string} content - Full file content
 * @param {Object} loc - Location object with start.line and end.line
 * @param {number} maxLines - Maximum number of lines to include
 * @returns {string} Code snippet
 */
function getSnippet (content, loc, maxLines = 15) {
  if (!loc) return ''
  const lines = content.split('\n')
  const start = loc.start?.line || 1
  const end = Math.min(loc.end?.line || start, start + maxLines)
  return lines.slice(start - 1, end).join('\n')
}

/**
 * Get version range from package.json.
 *
 * @param {string} packagePath - Path to package directory
 * @returns {string} Version range string (e.g., ">=2")
 */
function getVersionRange (packagePath) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(packagePath, 'package.json'), 'utf8'))
    return `>=${pkg.version.split('.')[0]}`
  } catch {
    return '>=0'
  }
}

/**
 * Load package.json metadata.
 *
 * @param {string} packagePath - Path to package directory
 * @returns {Object} Package metadata
 */
function getPackageInfo (packagePath) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(packagePath, 'package.json'), 'utf8'))
    return {
      name: pkg.name,
      version: pkg.version,
      description: pkg.description,
      main: pkg.main,
      module: pkg.module,
      exports: pkg.exports,
      type: pkg.type, // 'module' for ESM
      dependencies: pkg.dependencies || {},
      peerDependencies: pkg.peerDependencies || {}
    }
  } catch {
    return { name: path.basename(packagePath) }
  }
}

/**
 * Check if SWC parser is available.
 *
 * @returns {boolean}
 */
function hasSWC () {
  return swc !== null
}

module.exports = {
  // Parsing
  parseFile,
  parseWithMeriyah,
  parseWithSWC,
  hasSWC,

  // Comments/JSDoc
  extractCommentsFromSource,
  findJSDocForNode,
  parseJSDoc,
  parseJSDocType,

  // File utilities
  getAllJsFiles,
  getSnippet,
  getVersionRange,
  getPackageInfo,

  // SWC utilities
  spanToLine
}
