'use strict'

/**
 * Extract All Methods - Enhanced Package Analyzer
 *
 * Features:
 * - ES6 classes, class expressions, prototype-based classes
 * - Object.defineProperty getters/setters
 * - Object.assign mixin patterns
 * - Factory functions, object literal APIs
 * - Proxy wrappers, proto augmentation patterns
 * - Parent class resolution (internal + external)
 * - JSDoc extraction for descriptions and types
 * - Inherited methods from Node.js builtins
 *
 */

/* eslint-disable no-console */

const fs = require('fs')
const path = require('path')
const esquery = require('esquery') // eslint-disable-line import/no-extraneous-dependencies

const {
  parseFile,
  getAllJsFiles,
  getSnippet,
  getVersionRange,
  getPackageInfo,
  findJSDocForNode,
  spanToLine
} = require('./utils')

const {
  getExternalClassMethods,
  isKnownExternalClass,
  tryDynamicIntrospection,
  RESOLUTION_SOURCES,
  FAILURE_REASONS
} = require('./dynamic-resolver')

const isFunctionNode = (node) =>
  node?.type === 'FunctionExpression' || node?.type === 'ArrowFunctionExpression'

function createMethodEntry (name, content, loc, options = {}) {
  const {
    kind = 'method',
    isAsync = false,
    isStatic = false,
    isGenerator = false,
    parameters = [],
    description = '',
    extra = {}
  } = options

  return {
    name,
    kind,
    isAsync,
    isStatic,
    isGenerator,
    line: loc?.start?.line || 1,
    endLine: loc?.end?.line || 1,
    snippet: getSnippet(content, loc),
    parameters,
    description,
    ...extra
  }
}

function extractFromDescriptor (descriptor, propName, content, loc, isStatic = false) {
  const methods = []
  for (const prop of descriptor.properties || []) {
    const key = prop.key?.name
    if (key === 'get' || key === 'set') {
      methods.push(createMethodEntry(propName, content, loc, {
        kind: key,
        isAsync: prop.value?.async,
        isStatic
      }))
    } else if (key === 'value' && isFunctionNode(prop.value)) {
      methods.push(createMethodEntry(propName, content, loc, {
        isAsync: prop.value?.async,
        isStatic
      }))
    }
  }
  return methods
}

function extractParameters (funcNode) {
  if (!funcNode?.params) return []

  return funcNode.params.map(param => {
    // Handle different parameter types
    if (param.type === 'Identifier') {
      return { name: param.name, type: 'any', optional: false }
    } else if (param.type === 'AssignmentPattern') {
      return { name: param.left?.name || 'param', type: 'any', optional: true }
    } else if (param.type === 'RestElement') {
      return { name: param.argument?.name || 'args', type: 'any', optional: false, isRest: true }
    } else if (param.type === 'ObjectPattern') {
      return { name: 'options', type: 'object', optional: false }
    } else if (param.type === 'ArrayPattern') {
      return { name: 'array', type: 'array', optional: false }
    }
    return { name: 'param', type: 'any', optional: false }
  })
}

/**
 * Extract all classes, methods, and functions from a package.
 *
 * @param {string} packagePath - Path to the package directory
 * @param {Object} options - Analysis options
 * @param {boolean} options.includeInherited - Include inherited methods (default: true)
 * @param {boolean} options.extractJSDoc - Extract JSDoc comments (default: true)
 * @returns {Object} Analysis result with classes, functions, and metadata
 */
function extractAllMethods (packagePath, options = {}) {
  const {
    includeInherited = true,
    extractJSDoc = true
  } = options

  if (!fs.existsSync(packagePath)) {
    return { error: `Package not found: ${packagePath}`, classes: [], functions: [] }
  }

  const files = getAllJsFiles(packagePath)
  const classes = []
  const functions = []
  const seen = { classes: new Set(), functions: new Set() }
  const allImportMappings = new Map()

  const stats = {
    totalFiles: files.length,
    parsedFiles: 0,
    failedFiles: 0,
    totalClasses: 0,
    totalMethods: 0,
    totalFunctions: 0,
    classesWithParent: 0,
    resolvedParents: 0,
    parentResolutionDetails: {
      internal: 0,
      node_builtin: 0,
      package: 0,
      failed: 0,
      failureReasons: {}
    }
  }

  for (const file of files) {
    try {
      const parseResult = parseFile(file, { extractComments: extractJSDoc })
      const { ast, content, comments, parser, spanOffset } = parseResult
      const relPath = path.relative(packagePath, file)

      // Extract import mappings from this file
      const fileImports = extractImportMappings(ast)
      for (const [name, info] of fileImports) {
        allImportMappings.set(name, info)
      }

      extractClasses(ast, content, relPath, file, classes, seen.classes, {
        comments,
        parser,
        spanOffset,
        extractJSDoc
      })
      extractFunctions(ast, content, relPath, file, functions, seen.functions, {
        comments,
        parser,
        spanOffset,
        extractJSDoc
      })

      stats.parsedFiles++
    } catch (error) {
      stats.failedFiles++
    }
  }

  const classMap = new Map()
  classes.forEach(cls => classMap.set(cls.name, cls))

  if (includeInherited) {
    for (const cls of classes) {
      if (cls.extends) {
        stats.classesWithParent++
        resolveParentMethods(cls, classMap, packagePath, allImportMappings)

        // Track resolution statistics
        if (cls.parentResolution?.resolved) {
          stats.resolvedParents++
          const source = cls.parentResolution.source
          if (stats.parentResolutionDetails[source] !== undefined) {
            stats.parentResolutionDetails[source]++
          }
        } else if (cls.parentResolution) {
          stats.parentResolutionDetails.failed++
          const reason = cls.parentResolution.reason || 'unknown'
          stats.parentResolutionDetails.failureReasons[reason] =
            (stats.parentResolutionDetails.failureReasons[reason] || 0) + 1
        }
      }
    }
  }

  // Update statistics
  stats.totalClasses = classes.length
  stats.totalMethods = classes.reduce((sum, c) => sum + c.methods.length, 0)
  stats.totalFunctions = functions.length

  return {
    package: path.basename(packagePath),
    packagePath,
    packageInfo: getPackageInfo(packagePath),
    versionRange: getVersionRange(packagePath),
    classes,
    functions,
    statistics: stats
  }
}

function extractClasses (ast, content, relPath, fullPath, results, seen, options = {}) {
  const { comments, parser, spanOffset, extractJSDoc } = options
  const constValues = buildConstMap(ast)

  const addClass = (name, classNode, extra = {}) => {
    const key = `${relPath}:${name}`
    if (!name || seen.has(key)) return
    seen.add(key)

    const classInfo = {
      name,
      file: relPath,
      fullPath,
      line: classNode.loc?.start?.line || 1,
      methods: extractMethodsFromClass(classNode, content, constValues, {
        comments,
        parser,
        spanOffset,
        extractJSDoc
      }),
      ...extra
    }

    // Extract JSDoc for class description
    if (extractJSDoc && comments) {
      const jsdoc = findJSDocForNode(classNode, comments, content, spanOffset)
      if (jsdoc?.description) {
        classInfo.description = jsdoc.description
      }
    }

    results.push(classInfo)
  }

  for (const cls of esquery.query(ast, 'ClassDeclaration')) {
    const extendsName = getExtendsName(cls)
    addClass(cls.id?.name, cls, extendsName ? { extends: extendsName } : {})
  }

  for (const cls of esquery.query(ast, 'VariableDeclarator > ClassExpression')) {
    const parent = esquery.query(ast, 'VariableDeclarator').find(d => d.init === cls)
    const extendsName = getExtendsName(cls)
    addClass(parent?.id?.name, cls, extendsName ? { extends: extendsName } : {})
  }

  for (const assign of esquery.query(ast, 'AssignmentExpression[left.type="MemberExpression"][right.type="ClassExpression"]')) {
    const extendsName = getExtendsName(assign.right)
    addClass(
      assign.right?.id?.name || assign.left?.property?.name,
      assign.right,
      extendsName ? { extends: extendsName } : {}
    )
  }

  extractPrototypeClasses(ast, content, relPath, fullPath, results, seen, options)

  for (const decl of esquery.query(ast, 'VariableDeclarator[init.type="NewExpression"][init.callee.name="Proxy"]')) {
    const aliasName = decl.id?.name
    const originalClass = results.find(c => c.name === decl.init?.arguments?.[0]?.name && c.file === relPath)
    const key = `${relPath}:${aliasName}`
    if (aliasName && originalClass && !seen.has(key)) {
      seen.add(key)
      results.push({
        name: aliasName,
        file: relPath,
        fullPath,
        line: originalClass.line,
        isProxyWrapper: true,
        methods: originalClass.methods,
        extends: originalClass.extends
      })
    }
  }

  extractObjectLiteralApis(ast, content, relPath, fullPath, results, seen, options)

  // Pattern 7: Factory functions
  extractFactoryFunctions(ast, content, relPath, fullPath, results, seen, options)

  // Pattern 8: Proto augmentation
  extractProtoAugmentation(ast, content, relPath, fullPath, results, seen, options)
}

// Get extends class name from class node
function getExtendsName (classNode) {
  if (!classNode.superClass) return null

  if (classNode.superClass.type === 'Identifier') {
    return classNode.superClass.name
  } else if (classNode.superClass.type === 'MemberExpression') {
    // Handle: class Foo extends stream.Transform
    const parts = []
    let current = classNode.superClass
    while (current) {
      if (current.property?.name) parts.unshift(current.property.name)
      if (current.object?.type === 'Identifier') {
        parts.unshift(current.object.name)
        break
      }
      current = current.object
    }
    return parts.join('.')
  }
  return null
}

// Build map of const names to string values or Symbol descriptions
function buildConstMap (ast) {
  const constValues = new Map()
  for (const decl of esquery.query(ast, 'VariableDeclaration[kind="const"] > VariableDeclarator')) {
    if (!decl.id?.name) continue
    const init = decl.init
    if (init?.type === 'Literal' && typeof init.value === 'string') {
      constValues.set(decl.id.name, init.value)
    } else if (init?.type === 'CallExpression' && init?.callee?.name === 'Symbol' && init?.arguments?.[0]?.type === 'Literal') {
      constValues.set(decl.id.name, init.arguments[0].value)
    }
  }
  return constValues
}

// Build map of variable names to methods (for mixin resolution)
function buildMixinMap (ast, content, options = {}) {
  const mixins = new Map()
  for (const decl of esquery.query(ast, 'VariableDeclarator[init.type="ObjectExpression"]')) {
    if (!decl.id?.name) continue
    const methods = extractMethodsFromObjectLiteral(decl.init, content, { skipPrivate: false, ...options })
    if (methods.length > 0) mixins.set(decl.id.name, methods)
  }
  return mixins
}

// Extract methods from ES6 class body
function extractMethodsFromClass (classNode, content, constValues = new Map(), options = {}) {
  const { comments, parser, spanOffset, extractJSDoc } = options
  const methods = []

  for (const member of classNode.body?.body || []) {
    let name = member.key?.name || member.key?.value

    // Handle computed properties: [CONST_NAME]() or [Symbol('name')]()
    if (member.computed && member.key?.type === 'Identifier') {
      name = constValues.get(member.key.name) || member.key.name
    } else if (member.computed && member.key?.type === 'CallExpression' && member.key?.callee?.name === 'Symbol') {
      name = member.key.arguments?.[0]?.value || 'symbol'
    }

    if (!name) continue

    if (member.type === 'MethodDefinition') {
      const methodEntry = createMethodEntry(name, content, member.loc, {
        kind: member.kind || 'method',
        isAsync: member.value?.async,
        isStatic: member.static,
        isGenerator: member.value?.generator,
        parameters: extractParameters(member.value)
      })

      if (extractJSDoc && comments) {
        const jsdoc = findJSDocForNode(member, comments, content, spanOffset)
        if (jsdoc) {
          enrichMethodWithJSDoc(methodEntry, jsdoc)
        }
      }

      methods.push(methodEntry)
    } else if (member.type === 'PropertyDefinition' && isFunctionNode(member.value)) {
      methods.push(createMethodEntry(name, content, member.loc, {
        isAsync: member.value?.async,
        isStatic: member.static,
        parameters: extractParameters(member.value),
        extra: { isClassField: true }
      }))
    }
  }

  return methods
}

// Enrich method entry with JSDoc data
function enrichMethodWithJSDoc (methodEntry, jsdoc) {
  if (jsdoc.description) {
    methodEntry.description = jsdoc.description
  }

  // Enrich parameters with JSDoc types and descriptions
  if (jsdoc.params?.length > 0 && methodEntry.parameters) {
    methodEntry.parameters = methodEntry.parameters.map((param, idx) => {
      const jsdocParam = jsdoc.params.find(p => p.name === param.name) || jsdoc.params[idx]
      if (jsdocParam) {
        return {
          ...param,
          type: jsdocParam.type?.type || jsdocParam.type?.raw || param.type,
          optional: jsdocParam.optional ?? param.optional,
          description: jsdocParam.description
        }
      }
      return param
    })
  }

  // Add return type
  if (jsdoc.returns) {
    methodEntry.returnType = jsdoc.returns.type?.type || jsdoc.returns.type?.raw
    if (jsdoc.returns.type?.isAsync) {
      methodEntry.isAsync = true
    }
  }

  // Add visibility
  if (jsdoc.visibility) {
    methodEntry.visibility = jsdoc.visibility
  }

  // Add deprecated flag
  if (jsdoc.deprecated) {
    methodEntry.deprecated = true
  }

  methodEntry.hasJSDoc = true
}

function extractPrototypeClasses (ast, content, relPath, fullPath, results, seen, options = {}) {
  const mixinMap = buildMixinMap(ast, content, options)
  const protoMethods = new Map()

  const addMethod = (className, method) => {
    if (!protoMethods.has(className)) protoMethods.set(className, [])
    protoMethods.get(className).push(method)
  }

  const protoAssignments = esquery.query(ast,
    'AssignmentExpression[left.type="MemberExpression"][left.object.type="MemberExpression"]' +
    '[left.object.property.name="prototype"]'
  )

  for (const assign of protoAssignments) {
    const className = assign.left?.object?.object?.name
    const methodName = assign.left?.property?.name || assign.left?.property?.value
    if (!className || !methodName) continue
    addMethod(className, createMethodEntry(methodName, content, assign.loc, {
      isAsync: assign.right?.async,
      parameters: extractParameters(assign.right)
    }))
  }

  const definePropertyCalls = esquery.query(ast,
    'CallExpression[callee.object.name="Object"][callee.property.name="defineProperty"]'
  )

  for (const call of definePropertyCalls) {
    const args = call.arguments
    if (args.length < 3) continue

    const target = args[0]
    const propName = args[1]?.value
    const descriptor = args[2]

    if (!propName || descriptor?.type !== 'ObjectExpression') continue

    let className = null
    let isStatic = false

    if (target?.type === 'MemberExpression' &&
      target?.property?.name === 'prototype' &&
      target?.object?.type === 'Identifier') {
      className = target.object.name
      isStatic = false
    } else if (target?.type === 'Identifier') {
      className = target.name
      isStatic = true
    }

    if (!className) continue
    extractFromDescriptor(descriptor, propName, content, call.loc, isStatic).forEach(m => addMethod(className, m))
  }

  for (const call of esquery.query(ast, 'CallExpression[callee.object.name="Object"][callee.property.name="assign"]')) {
    const args = call.arguments
    if (args.length < 2) continue

    const target = args[0]
    if (target?.type !== 'MemberExpression' ||
        target?.property?.name !== 'prototype' ||
        target?.object?.type !== 'Identifier') continue

    const className = target.object.name
    for (let i = 1; i < args.length; i++) {
      const source = args[i]
      if (source?.type === 'Identifier') {
        mixinMap.get(source.name)?.forEach(m => addMethod(className, m))
      } else if (source?.type === 'ObjectExpression') {
        extractMethodsFromObjectLiteral(source, content, { skipPrivate: false, ...options })
          .forEach(m => addMethod(className, m))
      }
    }
  }

  const protoCreateAssigns = esquery.query(ast,
    'AssignmentExpression[left.type="MemberExpression"][left.property.name="prototype"]' +
    '[right.type="CallExpression"][right.callee.object.name="Object"][right.callee.property.name="create"]'
  )

  for (const assign of protoCreateAssigns) {
    const className = assign.left?.object?.name
    if (!className) continue

    const descriptors = assign.right.arguments?.[1]
    if (!descriptors || descriptors.type !== 'ObjectExpression') continue

    for (const prop of descriptors.properties || []) {
      if (prop.type !== 'Property') continue
      const methodName = prop.key?.name || prop.key?.value
      if (!methodName || methodName === 'constructor' || prop.value?.type !== 'ObjectExpression') continue
      extractFromDescriptor(prop.value, methodName, content, prop.loc).forEach(m => addMethod(className, m))
    }
  }

  const staticAssignments = esquery.query(ast,
    'AssignmentExpression[left.type="MemberExpression"][left.object.type="Identifier"]' +
    '[right.type=/FunctionExpression|ArrowFunctionExpression/]'
  )

  for (const assign of staticAssignments) {
    const className = assign.left?.object?.name
    const methodName = assign.left?.property?.name
    if (!className || !methodName || methodName === 'prototype') continue
    if (!protoMethods.has(className) && !results.find(c => c.name === className)) continue

    addMethod(className, createMethodEntry(methodName, content, assign.loc, {
      isAsync: assign.right?.async,
      isStatic: true,
      parameters: extractParameters(assign.right)
    }))
  }

  for (const [className, methods] of protoMethods) {
    const existingClass = results.find(c => c.name === className && c.file === relPath)
    if (existingClass) {
      existingClass.methods.push(...methods)
      continue
    }

    const key = `${relPath}:${className}`
    if (seen.has(key)) continue

    const ctorFn = esquery.query(ast, `FunctionDeclaration[id.name="${className}"]`)[0]
    if (!ctorFn) continue

    seen.add(key)
    results.push({
      name: className,
      file: relPath,
      fullPath,
      line: ctorFn.loc?.start?.line || 1,
      isPrototypeBased: true,
      methods
    })
  }
}

function extractObjectLiteralApis (ast, content, relPath, fullPath, results, seen, options = {}) {
  for (const decl of esquery.query(ast, 'VariableDeclarator[init.type="ObjectExpression"]')) {
    const name = decl.id?.name
    const key = `${relPath}:${name}`
    if (!name || seen.has(key)) continue

    const obj = decl.init
    const methods = extractMethodsFromObjectLiteral(obj, content, options)

    if (methods.length === 0) continue

    seen.add(key)
    results.push({
      name,
      file: relPath,
      fullPath,
      line: obj.loc?.start?.line || 1,
      isObjectLiteral: true,
      methods
    })
  }
}

function extractMethodsFromObjectLiteral (obj, content, options = {}) {
  const { skipPrivate = true } = options
  const methods = []

  for (const prop of obj.properties || []) {
    if (prop.type !== 'Property') continue
    const name = prop.key?.name || prop.key?.value
    if (!name || (skipPrivate && name.startsWith('_'))) continue

    if (prop.kind === 'get' || prop.kind === 'set') {
      methods.push(createMethodEntry(name, content, prop.loc, { kind: prop.kind }))
    } else if (prop.method || isFunctionNode(prop.value)) {
      methods.push(createMethodEntry(name, content, prop.loc, {
        isAsync: prop.value?.async,
        parameters: extractParameters(prop.value)
      }))
    } else if (prop.shorthand && prop.value?.type === 'Identifier') {
      methods.push(createMethodEntry(name, content, prop.loc, { isAsync: false }))
    }
  }

  return methods
}

function extractFactoryFunctions (ast, content, relPath, fullPath, results, seen, options = {}) {
  const exportAliases = new Map()

  const getReturnObj = (fn) => {
    const body = fn.body
    if (body?.type === 'ObjectExpression') return body
    if (body?.type === 'BlockStatement') {
      const ret = body.body?.find(s => s.type === 'ReturnStatement' && s.argument?.type === 'ObjectExpression')
      return ret?.argument
    }
    return null
  }

  const addStaticMethods = (methods, query) => {
    for (const s of esquery.query(ast, query + '[right.type=/FunctionExpression|ArrowFunctionExpression/]')) {
      if (s.left?.property?.name) {
        methods.push(createMethodEntry(s.left.property.name, content, s.loc, {
          isAsync: s.right?.async,
          isStatic: true,
          parameters: extractParameters(s.right)
        }))
      }
    }
  }

  const addFactory = (name, fn, methods) => {
    const key = `${relPath}:${name}`
    if (!name || seen.has(key) || methods.length === 0) return
    seen.add(key)
    results.push({
      name,
      file: relPath,
      fullPath,
      line: fn.loc?.start?.line || 1,
      isFactory: true,
      methods
    })
  }

  // Pattern: module.exports = function() { return { method() {} } }
  for (const assign of esquery.query(ast, 'AssignmentExpression[left.object.name="module"][left.property.name="exports"]')) {
    const right = assign.right
    if (right?.type === 'ObjectExpression') {
      for (const prop of right.properties || []) {
        if (prop.type === 'Property' && prop.key && prop.value?.name) {
          exportAliases.set(prop.value.name, prop.key.name || prop.key.value)
        }
      }
    } else if (isFunctionNode(right)) {
      const returnObj = getReturnObj(right)
      if (!returnObj) continue
      const methods = extractMethodsFromObjectLiteral(returnObj, content, options)
      addStaticMethods(methods, 'AssignmentExpression[left.object.object.name="module"][left.object.property.name="exports"]')
      const base = path.basename(relPath, path.extname(relPath))
      const name = (base === 'index' ? path.basename(path.dirname(relPath)) : base).replace(/^./, c => c.toUpperCase())
      addFactory(name, right, methods)
    }
  }

  // Pattern: function createFoo() { return { ... } }; module.exports = { Foo: createFoo }
  for (const fn of esquery.query(ast, 'FunctionDeclaration')) {
    const exportedName = exportAliases.get(fn.id?.name)
    if (!exportedName) continue
    const returnObj = getReturnObj(fn)
    if (!returnObj) continue
    const methods = extractMethodsFromObjectLiteral(returnObj, content, options)
    addStaticMethods(methods, `AssignmentExpression[left.object.name="${fn.id.name}"]`)
    addFactory(exportedName, fn, methods)
  }
}

function extractProtoAugmentation (ast, content, relPath, fullPath, results, seen, options = {}) {
  let alias = null

  // Pattern 1: var X = module.exports = {}
  for (const decl of esquery.query(ast, 'VariableDeclarator[init.type="AssignmentExpression"]')) {
    let curr = decl.init
    while (curr?.type === 'AssignmentExpression') {
      const left = curr.left
      if (left?.object?.name === 'module' && left?.property?.name === 'exports') {
        alias = decl.id?.name
        break
      }
      curr = curr.right
    }
    if (alias) break
  }

  // Pattern 2: var X = ...; module.exports = X
  if (!alias) {
    for (const assign of esquery.query(ast, 'AssignmentExpression[left.object.name="module"][left.property.name="exports"][right.type="Identifier"]')) {
      alias = assign.right.name
      break
    }
  }

  if (!alias) return

  // Find all alias.method = function() {} assignments
  const methods = []
  for (const assign of esquery.query(ast, `AssignmentExpression[left.object.name="${alias}"][right.type=/FunctionExpression|ArrowFunctionExpression/]`)) {
    const methodName = assign.left?.property?.name
    if (!methodName || methodName.startsWith('_')) continue
    methods.push(createMethodEntry(methodName, content, assign.loc, {
      isAsync: assign.right?.async,
      parameters: extractParameters(assign.right)
    }))
  }

  if (methods.length === 0) return

  const base = path.basename(relPath, path.extname(relPath))
  const name = base === 'index' ? path.basename(path.dirname(relPath)) : base
  const key = `${relPath}:${name}`

  if (seen.has(key)) return
  seen.add(key)
  results.push({ name, file: relPath, fullPath, line: 1, isProtoAugmentation: true, methods })
}

function extractFunctions (ast, content, relPath, fullPath, results, seen, options = {}) {
  const { comments, parser, spanOffset, extractJSDoc } = options

  const addFn = (name, node, asyncNode = node) => {
    if (!name || seen.has(name)) return
    seen.add(name)

    const fnEntry = {
      name,
      file: relPath,
      fullPath,
      isAsync: asyncNode.async || false,
      isGenerator: asyncNode.generator || false,
      line: node.loc?.start?.line || 1,
      endLine: node.loc?.end?.line || 1,
      snippet: getSnippet(content, node.loc),
      parameters: extractParameters(asyncNode)
    }

    if (extractJSDoc && comments) {
      const jsdoc = findJSDocForNode(node, comments, content, spanOffset)
      if (jsdoc) {
        if (jsdoc.description) fnEntry.description = jsdoc.description
        if (jsdoc.returns?.type?.isAsync) fnEntry.isAsync = true
      }
    }

    results.push(fnEntry)
  }

  for (const fn of esquery.query(ast, 'FunctionDeclaration')) addFn(fn.id?.name, fn)
  for (const decl of esquery.query(ast, 'VariableDeclarator[init.type=/FunctionExpression|ArrowFunctionExpression/]')) {
    addFn(decl.id?.name, decl, decl.init)
  }
}

/**
 * Extract import mappings from AST.
 * Maps imported class names to their module paths.
 *
 * @param {Object} ast - Parsed AST
 * @returns {Map<string, {module: string, imported: string}>} Import mappings
 */
function extractImportMappings (ast) {
  const imports = new Map()

  // Handle CommonJS requires: const X = require('module')
  const requireDecls = esquery.query(ast, 'VariableDeclarator[init.callee.name="require"]')
  for (const decl of requireDecls) {
    const modulePath = decl.init?.arguments?.[0]?.value
    if (!modulePath) continue

    // const X = require('module')
    if (decl.id?.type === 'Identifier') {
      imports.set(decl.id.name, { module: modulePath, imported: 'default' })
    }
    // const { X, Y } = require('module')
    if (decl.id?.type === 'ObjectPattern') {
      for (const prop of decl.id.properties || []) {
        const localName = prop.value?.name || prop.key?.name
        const importedName = prop.key?.name
        if (localName) {
          imports.set(localName, { module: modulePath, imported: importedName })
        }
      }
    }
  }

  // Handle: const X = require('module').X
  const memberRequires = esquery.query(ast, 'VariableDeclarator[init.type="MemberExpression"][init.object.callee.name="require"]')
  for (const decl of memberRequires) {
    const modulePath = decl.init?.object?.arguments?.[0]?.value
    const memberName = decl.init?.property?.name
    const localName = decl.id?.name
    if (modulePath && localName) {
      imports.set(localName, { module: modulePath, imported: memberName || localName })
    }
  }

  // Handle ES6 imports: import { X } from 'module'
  const esImports = esquery.query(ast, 'ImportDeclaration')
  for (const imp of esImports) {
    const modulePath = imp.source?.value
    if (!modulePath) continue

    for (const spec of imp.specifiers || []) {
      if (spec.type === 'ImportDefaultSpecifier') {
        imports.set(spec.local?.name, { module: modulePath, imported: 'default' })
      } else if (spec.type === 'ImportSpecifier') {
        imports.set(spec.local?.name, { module: modulePath, imported: spec.imported?.name })
      } else if (spec.type === 'ImportNamespaceSpecifier') {
        imports.set(spec.local?.name, { module: modulePath, imported: '*' })
      }
    }
  }

  return imports
}

/**
 * Resolve parent class methods with detailed resolution status.
 * Attempts multiple resolution strategies in order:
 * 1. Internal classes (defined in the same package)
 * 2. Known external classes (Node.js builtins in registry)
 * 3. Dynamic introspection (require and inspect at runtime)
 *
 * @param {Object} cls - The class to resolve parent for
 * @param {Map} classMap - Map of all internal classes by name
 * @param {string} packagePath - Root path of the package being analyzed
 * @param {Map} importMappings - Map of import name to module path
 * @param {number} depth - Current recursion depth
 * @returns {void} Mutates cls with inheritedMethods and parentResolution
 */
function resolveParentMethods (cls, classMap, packagePath, importMappings = new Map(), depth = 0) {
  // Initialize parentResolution object for detailed tracking
  // TO-DO check back to make sure we need this parent resolution for internal methods and this does not add
  // unnecessary or duplicated methods that cause the wrong method to be instrumented
  cls.parentResolution = {
    resolved: false,
    source: RESOLUTION_SOURCES.FAILED,
    reason: null,
    error: null,
    methodCount: 0,
    attemptedStrategies: []
  }

  if (depth > 5) {
    cls.parentResolution.reason = FAILURE_REASONS.MAX_DEPTH_EXCEEDED
    cls.parentResolution.error = `Inheritance chain too deep (max 5 levels)`
    cls.parentResolution.attemptedStrategies.push('max_depth_check')
    cls.inheritedMethods = []
    return
  }

  const parentName = cls.extends
  if (!parentName) {
    cls.parentResolution = null // No parent to resolve
    cls.inheritedMethods = []
    return
  }

  cls.parentResolution.parentName = parentName
  cls.parentResolution.attemptedStrategies.push('internal_lookup')

  // Strategy 1: Try internal resolution first (classes in same package)
  const internalParent = classMap.get(parentName)
  if (internalParent) {
    cls.inheritedMethods = internalParent.methods.map(m => ({
      ...m,
      inheritedFrom: internalParent.name
    }))

    // Recursively get grandparent methods
    if (internalParent.inheritedMethods) {
      cls.inheritedMethods.push(...internalParent.inheritedMethods)
    }

    cls.parentResolution = {
      resolved: true,
      source: RESOLUTION_SOURCES.INTERNAL,
      reason: null,
      error: null,
      parentName,
      parentFile: internalParent.file,
      methodCount: cls.inheritedMethods.length,
      attemptedStrategies: ['internal_lookup']
    }
    return
  }

  cls.parentResolution.attemptedStrategies.push('known_external_lookup')

  // Strategy 2: Try known external class registry (Node.js builtins)
  if (isKnownExternalClass(parentName)) {
    const externalInfo = getExternalClassMethods(parentName)
    if (externalInfo) {
      cls.inheritedMethods = externalInfo.methods.map(m => ({
        ...m,
        inheritedFrom: m.inheritedFrom || parentName,
        isExternal: true
      }))

      cls.parentResolution = {
        resolved: true,
        source: RESOLUTION_SOURCES.NODE_BUILTIN,
        reason: null,
        error: null,
        parentName,
        parentModule: externalInfo.module || externalInfo.source,
        methodCount: cls.inheritedMethods.length,
        attemptedStrategies: ['internal_lookup', 'known_external_lookup']
      }
      return
    }
  }

  cls.parentResolution.attemptedStrategies.push('import_resolution')

  // Strategy 3: Try to resolve from import statements
  const importInfo = importMappings.get(parentName)
  if (importInfo) {
    cls.parentResolution.attemptedStrategies.push('dynamic_introspection')
    cls.parentResolution.attemptedModule = importInfo.module

    const introspectionResult = tryDynamicIntrospection(
      importInfo.module,
      importInfo.imported === 'default' ? parentName : importInfo.imported,
      packagePath
    )

    if (introspectionResult.resolved) {
      cls.inheritedMethods = introspectionResult.methods.map(m => ({
        ...m,
        inheritedFrom: parentName,
        isExternal: true
      }))

      cls.parentResolution = {
        resolved: true,
        source: introspectionResult.source,
        reason: null,
        error: null,
        parentName,
        parentModule: importInfo.module,
        methodCount: cls.inheritedMethods.length,
        attemptedStrategies: cls.parentResolution.attemptedStrategies
      }
      return
    } else {
      // Record why dynamic introspection failed
      cls.parentResolution.reason = introspectionResult.reason
      cls.parentResolution.error = introspectionResult.error
    }
  } else {
    cls.parentResolution.reason = FAILURE_REASONS.IMPORT_NOT_FOUND
    cls.parentResolution.error = `Could not find import statement for '${parentName}'`
  }

  // Strategy 4: Last resort - try dynamic introspection with parent name as module
  cls.parentResolution.attemptedStrategies.push('fallback_introspection')

  const fallbackResult = tryDynamicIntrospection(parentName.toLowerCase(), parentName, packagePath)
  if (fallbackResult.resolved) {
    cls.inheritedMethods = fallbackResult.methods.map(m => ({
      ...m,
      inheritedFrom: parentName,
      isExternal: true
    }))

    cls.parentResolution = {
      resolved: true,
      source: fallbackResult.source,
      reason: null,
      error: null,
      parentName,
      parentModule: fallbackResult.modulePath,
      methodCount: cls.inheritedMethods.length,
      attemptedStrategies: cls.parentResolution.attemptedStrategies
    }
    return
  }

  // All strategies failed - mark as unresolved with detailed info
  cls.inheritedMethods = []
  cls.parentResolution.resolved = false
  cls.parentResolution.source = RESOLUTION_SOURCES.FAILED
  if (!cls.parentResolution.reason) {
    cls.parentResolution.reason = FAILURE_REASONS.UNKNOWN_CLASS
    cls.parentResolution.error = `Could not resolve parent class '${parentName}' through any strategy`
  }
}

/**
 * Flatten the extraction result into the format expected by the workflow.
 * Transforms from: { classes: [...], functions: [...] }
 * To: [{ className, method, file, _scoring, _enhanced }, ...]
 *
 * @param {Object} result - Result from extractAllMethods
 * @param {Object} options - Formatting options
 * @param {boolean} options.includeInherited - Include inherited methods in output
 * @returns {Array} Flat array of method entries
 */
function flattenForWorkflow (result, options = {}) {
  const { includeInherited = true } = options  // Include inherited by default for APM
  const flat = []

  // Add class methods
  for (const cls of result.classes || []) {
    // Build parentResolution summary for the class
    const parentResolutionSummary = cls.parentResolution ? {
      resolved: cls.parentResolution.resolved,
      source: cls.parentResolution.source,
      parentName: cls.parentResolution.parentName,
      parentModule: cls.parentResolution.parentModule,
      methodCount: cls.parentResolution.methodCount,
      // Include failure info if not resolved
      ...(cls.parentResolution.resolved ? {} : {
        reason: cls.parentResolution.reason,
        error: cls.parentResolution.error,
        attemptedStrategies: cls.parentResolution.attemptedStrategies
      })
    } : null

    for (const method of cls.methods || []) {
      flat.push({
        className: cls.name,
        method: {
          name: method.name,
          async: method.isAsync || false,
          generator: method.isGenerator || false,
          params: method.parameters?.length || 0,
          kind: method.kind || 'method'
        },
        file: cls.file,
        line: method.line || cls.line || 1,
        _scoring: { score: 90 },
        // Enhanced data (non-breaking additions)
        _enhanced: {
          description: method.description,
          parameters: method.parameters,
          returnType: method.returnType,
          visibility: method.visibility,
          isStatic: method.isStatic,
          hasJSDoc: method.hasJSDoc,
          classDescription: cls.description,
          extends: cls.extends,
          parentResolution: parentResolutionSummary
        }
      })
    }

    // Optionally include inherited methods
    if (includeInherited && cls.inheritedMethods) {
      for (const method of cls.inheritedMethods) {
        flat.push({
          className: cls.name,
          method: {
            name: method.name,
            async: method.isAsync || false,
            generator: method.isGenerator || false,
            params: method.parameters?.length || 0,
            kind: method.kind || 'method'
          },
          file: cls.file,
          line: 0, // Unknown for inherited
          _scoring: { score: 70 }, // Lower score for inherited
          _inherited: true,
          _inheritedFrom: method.inheritedFrom,
          _enhanced: {
            description: method.description,
            parameters: method.parameters,
            isExternal: method.isExternal,
            parentResolution: parentResolutionSummary
          }
        })
      }
    }
  }

  // Add standalone functions
  for (const fn of result.functions || []) {
    flat.push({
      className: fn.name, // TUI expects className, use function name
      method: {
        name: fn.name,
        async: fn.isAsync || false,
        generator: fn.isGenerator || false,
        params: fn.parameters?.length || 0,
        kind: 'function'
      },
      file: fn.file,
      line: fn.line || 1,
      _scoring: { score: 80 },
      _enhanced: {
        description: fn.description,
        parameters: fn.parameters
      }
    })
  }

  return flat
}

if (require.main === module) {
  const packagePath = process.argv[2]

  if (!packagePath) {
    console.error('Usage: node extract-all-methods.js <packagePath>')
    process.exit(1)
  }

  const result = extractAllMethods(packagePath)
  const flat = flattenForWorkflow(result)
  console.log(JSON.stringify(flat, null, 2))
}

module.exports = { extractAllMethods, flattenForWorkflow }
