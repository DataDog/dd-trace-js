'use strict'

/* eslint-disable no-console */

const { ESLint } = require('eslint')

/**
 * Unified Linter for all adapters
 *
 * Provides both single-file linting (for FileHelper) and batch linting (for dd-generate)
 */
class Linter {
    constructor (cwd) {
        this.eslint = new ESLint({
            cwd,
            fix: true
        })
    }

    /**
     * Lint and fix a single file (used by FileHelper)
     */
    async lintFile (filePath) {
        try {
            const results = await this.eslint.lintFiles([filePath])
            await ESLint.outputFixes(results)
            const formatter = await this.eslint.loadFormatter('stylish')
            const resultText = formatter.format(results)

            if (resultText) {
                console.log(resultText)
            }

            // Check for errors after fixing
            const [lintResult] = results
            if (lintResult && lintResult.errorCount > 0) {
                console.error(`❌ Found ${lintResult.errorCount} linting errors in ${filePath} after auto-fixing.`)
            }
        } catch (e) {
            // Ignore config errors (eslintrc vs flat config format issues)
            if (e.messageTemplate === 'eslintrc-incompat') {
                console.log(`   ⚠️  Skipping lint for ${filePath} (config format issue)`)
                return
            }
            console.error(`Error while linting ${filePath}:`, e.message)
        }
    }

    /**
     * Lint multiple files (used by dd-generate)
     */
    async lintFiles (filePaths) {
        if (!filePaths.length) {
            return { success: true, errors: [] }
        }

        try {
            const results = await this.eslint.lintFiles(filePaths)
            const formatter = await this.eslint.loadFormatter('stylish')
            const resultText = formatter.format(results)

            if (resultText) {
                console.log(resultText)
            }

            // Check if any files have errors
            const hasErrors = results.some(result => result.errorCount > 0)

            return {
                success: !hasErrors,
                errors: hasErrors ? this.extractErrors(results) : []
            }
        } catch (e) {
            console.error('❌ Linting failed:', e.message)
            return { success: false, errors: [{ message: e.message }] }
        }
    }

    /**
     * Fix multiple files with ESLint auto-fix (used by dd-generate)
     */
    async fixFiles (filePaths) {
        if (!filePaths.length) {
            return { success: true, fixed: 0 }
        }

        try {
            const results = await this.eslint.lintFiles(filePaths)
            await ESLint.outputFixes(results)

            // Count files that were modified
            const fixedCount = results.filter(result => result.output).length

            if (fixedCount > 0) {
                console.log(`🔧 Auto-fixed ${fixedCount} file(s)`)
            }

            return { success: true, fixed: fixedCount }
        } catch (e) {
            console.error('❌ Auto-fix failed:', e.message)
            return { success: false, errors: [{ message: e.message }] }
        }
    }

    /**
     * Filter files to only JavaScript/TypeScript files
     */
    getJavaScriptFiles (filePaths) {
        return filePaths.filter(filePath =>
            filePath.endsWith('.js') ||
            filePath.endsWith('.mjs') ||
            filePath.endsWith('.ts')
        )
    }

    /**
     * Extract structured error information from ESLint results
     */
    extractErrors (results) {
        const errors = []
        for (const result of results) {
            for (const message of result.messages) {
                if (message.severity === 2) { // Error
                    errors.push({
                        file: result.filePath,
                        line: message.line,
                        column: message.column,
                        message: message.message,
                        ruleId: message.ruleId
                    })
                }
            }
        }
        return errors
    }
}

module.exports = { Linter }
