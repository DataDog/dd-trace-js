'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const { Linter } = require('./linter')

class FileHelper {
  constructor (baseDir) {
    this.linter = new Linter(baseDir)
  }

  async createOrUpdateFile (filePath, content) {
    try {
      await fs.writeFile(filePath, content)
      await this.linter.lintFile(filePath)
    } catch (e) {
      console.error(`Error writing or linting file ${filePath}:`, e)
      throw e // Re-throw to fail the calling script
    }
  }
}

module.exports = { FileHelper }
