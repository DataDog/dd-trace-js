'use strict'

/**
 * Node.js (dd-trace-js) specific constants for APM instrumentation.
 *
 * Language-agnostic constants are in core/constants/integration_categories.json
 * This file contains Node.js specific mappings like base plugin classes.
 */

const path = require('path')
const fs = require('fs')

// Load language-agnostic categories from core constants.
// ANUBIS_RESOURCES_ROOT (frozen binary) or ANUBIS_TOOLKIT_ROOT (source install)
// are set by init_env() and inherited by subprocess calls.
const toolkitRoot = process.env.ANUBIS_RESOURCES_ROOT || process.env.ANUBIS_TOOLKIT_ROOT
if (!toolkitRoot) {
  throw new Error(
    'ANUBIS_TOOLKIT_ROOT is not set — this script must be invoked via dd-apm.'
  )
}
const coreConstantsPath = path.join(toolkitRoot, 'anubis_apm', 'constants', 'integration_categories.json')
const coreConstants = JSON.parse(fs.readFileSync(coreConstantsPath, 'utf8'))

/**
 * Map categories to dd-trace-js base plugin classes.
 * These are the plugin base classes in packages/dd-trace/src/plugins/
 */
const CATEGORY_TO_PLUGIN = {
    'http-server': 'ServerPlugin',
    'http-client': 'HttpClientPlugin',
    database: 'DatabasePlugin',
    cache: 'CachePlugin',
    messaging: null, // Uses span_kind (producer/consumer) to determine plugin
    logging: 'LogPlugin',
    library: null,
    custom: null,
    not_applicable: null
}

/**
 * Map span_kinds to dd-trace-js base plugin classes (fallback when category doesn't specify).
 */
const SPAN_KIND_TO_PLUGIN = {
    producer: 'ProducerPlugin',
    consumer: 'ConsumerPlugin',
    server: 'ServerPlugin',
    client: 'ClientPlugin'
}

/**
 * Map categories to service naming schema files.
 * These categories use schema-based operation naming (startSpan without operation name).
 * Path is relative to packages/dd-trace/src/service-naming/schemas/v1/
 */
const CATEGORY_TO_SCHEMA = {
    cache: { file: 'storage.js', spanKind: 'client' },
    database: { file: 'storage.js', spanKind: 'client' },
    search: { file: 'storage.js', spanKind: 'client' },
    messaging: { file: 'messaging.js', spanKind: null }, // spanKind determines: producer, consumer, client
    'http-client': { file: 'web.js', spanKind: 'client' },
    'http-server': { file: 'web.js', spanKind: 'server' },
    'grpc-client': { file: 'web.js', spanKind: 'client' },
    'grpc-server': { file: 'web.js', spanKind: 'server' },
    graphql: { file: 'graphql.js', spanKind: 'server' }
}

/**
 * Check if a category uses schema-based operation naming.
 *
 * @param {string} category - The category (will be normalized)
 * @returns {boolean} True if category uses schema-based naming
 */
function usesSchemaBasedNaming (category) {
    const normalized = normalizeCategory(category)
    return normalized in CATEGORY_TO_SCHEMA
}

/**
 * Get the schema file info for a category.
 *
 * @param {string} category - The category (will be normalized)
 * @returns {object|null} { file, spanKind } or null if not schema-based
 */
function getSchemaInfo (category) {
    const normalized = normalizeCategory(category)
    return CATEGORY_TO_SCHEMA[normalized] || null
}

/**
 * Get the base plugin class for a category.
 *
 * @param {string} category - The category (will be normalized via aliases)
 * @param {string} [spanKind] - Optional span_kind for fallback
 * @returns {string|null} Plugin class name or null
 */
function getBasePlugin (category, spanKind) {
    // Normalize category using aliases
    const normalized = normalizeCategory(category)

    // Check category first
    const plugin = CATEGORY_TO_PLUGIN[normalized]
    if (plugin) {
        return plugin
    }

    // Fall back to span_kind
    if (spanKind) {
        return SPAN_KIND_TO_PLUGIN[spanKind] || null
    }

    return null
}

/**
 * Normalize a category string to its canonical form.
 *
 * @param {string} category - Category string (may be an alias)
 * @returns {string} Canonical category string
 */
function normalizeCategory (category) {
    if (!category) return 'custom'

    const lower = category.toLowerCase().trim()

    // Check aliases
    if (coreConstants.aliases[lower]) {
        return coreConstants.aliases[lower]
    }

    // Check if it's a canonical category
    if (coreConstants.categories[lower]) {
        return lower
    }

    return lower
}

/**
 * Get valid span_kinds for a category.
 *
 * @param {string} category - Category string (will be normalized)
 * @returns {string[]} Array of valid span_kinds
 */
function getValidSpanKinds (category) {
    const normalized = normalizeCategory(category)
    const catData = coreConstants.categories[normalized]
    return catData ? catData.valid_span_kinds : ['internal']
}

/**
 * List all canonical category names.
 *
 * @returns {string[]} Array of category names
 */
function listCategories () {
    return Object.keys(coreConstants.categories)
}

module.exports = {
    // Core constants (language-agnostic)
    categories: coreConstants.categories,
    aliases: coreConstants.aliases,

    // Node-specific mappings
    CATEGORY_TO_PLUGIN,
    SPAN_KIND_TO_PLUGIN,
    CATEGORY_TO_SCHEMA,

    // Functions
    getBasePlugin,
    normalizeCategory,
    getValidSpanKinds,
    listCategories,
    usesSchemaBasedNaming,
    getSchemaInfo
}
