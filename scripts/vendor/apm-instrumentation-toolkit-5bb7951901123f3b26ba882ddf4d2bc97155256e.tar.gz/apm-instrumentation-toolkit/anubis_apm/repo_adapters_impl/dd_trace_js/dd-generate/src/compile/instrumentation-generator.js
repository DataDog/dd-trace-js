'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { getUniqueModules, normalizePackageName } = require('./utils')

class InstrumentationGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    this.normalizedName = normalizePackageName(integrationName)
  }

  async generate () {
    const content = this._generateInstrumentationCode()
    const filePath = path.join(
      process.cwd(),
      'packages',
      'datadog-instrumentations',
      'src',
      `${this.normalizedName}.js`
    )
    await fs.writeFile(filePath, content)
    console.log(`✅ Generated instrumentation file: ${filePath}`)
  }

  _generateInstrumentationCode () {
    const uniqueModules = getUniqueModules(this.analysis, this.integrationName)
    const mainPackage = this.analysis?.package?.name || this.integrationName
    const mainVersion = this.analysis?.package?.version

    // Check if we need a marker hook for the main package
    // This is needed when all instrumentation targets are in sub-packages
    // so that withVersions can find the tests
    const needsMarkerHook = !uniqueModules.includes(mainPackage)

    // Generate getHooks call for each unique module
    const hookCalls = uniqueModules.map(moduleName =>
      `for (const hook of getHooks('${moduleName}')) {\n  addHook(hook, exports => exports)\n}`
    ).join('\n\n')

    // Generate marker hook if needed
    let markerHook = ''
    if (needsMarkerHook && mainPackage) {
      const versionConstraint = mainVersion ? `>=${mainVersion}` : '>=1.0.0'
      markerHook = `// Marker hook for main package so withVersions can find tests
addHook({ name: '${mainPackage}', versions: ['${versionConstraint}'] }, exports => exports)

`
    }

    return `'use strict'

const { addHook, getHooks } = require('./helpers/instrument')

${markerHook}${hookCalls}
`
  }
}

module.exports = { InstrumentationGenerator }
