'use strict'

const fs = require('fs')
const path = require('path')

const templatesDir = __dirname

function loadTemplate (name) {
  const filePath = path.join(templatesDir, `${name}.js.tpl`)
  return fs.readFileSync(filePath, 'utf-8')
}

function render (template, vars) {
  let result = template
  for (const [key, value] of Object.entries(vars)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value)
  }
  return result
}

module.exports = { loadTemplate, render }
