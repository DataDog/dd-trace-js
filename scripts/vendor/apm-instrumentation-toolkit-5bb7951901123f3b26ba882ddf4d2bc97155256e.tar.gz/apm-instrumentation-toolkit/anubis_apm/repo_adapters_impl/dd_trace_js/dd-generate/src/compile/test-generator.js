'use strict'

/* eslint-disable no-console */

const path = require('path')
const { FileHelper } = require('../../../shared/file-helper')
const { toMethodName, normalizePackageName } = require('./utils')

class TestGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    this.fileHelper = new FileHelper()
  }

  generate () {
    const content = this._getTestFileContent()
    const filePath = this._getTestFilePath()
    this.fileHelper.createOrUpdateFile(filePath, content)
    console.log(`✅ Generated test file: ${filePath}`)
  }

  _getTestFilePath () {
    const normalizedName = normalizePackageName(this.integrationName)
    return path.join(process.cwd(), `packages/datadog-plugin-${normalizedName}/test/index.spec.js`)
  }

  _getTestFileContent () {
    const { name: packageName } = this.analysis.package
    const pluginType = this.analysis.category || 'database'
    const instrumentations = this.analysis.orchestrion_config?.instrumentations || []
    const normalizedName = normalizePackageName(this.integrationName)

    // Generate test cases for each instrumentation
    const testCases = instrumentations.map((instr, idx) => {
      return this._generateTestCase(instr, idx)
    }).join('\n\n')

    return `'use strict'

const { createIntegrationTestSuite } = require('../../dd-trace/test/setup/helpers/plugin-test-helpers')
const TestSetup = require('./test-setup')

const testSetup = new TestSetup()

createIntegrationTestSuite('${normalizedName}', '${packageName}', {
  category: '${pluginType}'
}, (meta) => {
  const { agent, tracer, span } = meta

  before(async () => {
    await testSetup.setup(meta.mod)
  })

  after(async () => {
    await testSetup.teardown()
  })

${testCases || '  // No test cases generated'}
})
`
  }

  _generateTestCase (instrumentation, index) {
    const className = instrumentation.function_query?.class || ''
    const methodName = instrumentation.function_query?.name || 'unknown'
    const operation = instrumentation.operation || 'unknown'
    const spanKind = instrumentation.span_kind || 'client'
    const normalizedName = normalizePackageName(this.integrationName)

    // Create a safe test description
    const testDescription = className
      ? `${className}.${methodName}() - ${operation}`
      : `${methodName}() - ${operation}`

    // Create test method name in camelCase format (e.g., "connectionQuery", "queueAddBulk")
    const testMethod = toMethodName(className, methodName)

    // Build expected span object - use normalized name for span name
    const expectedSpan = this._buildExpectedSpan(`${normalizedName}.${methodName}`, spanKind, instrumentation)
    const expectedSpanStr = this._formatExpectedSpan(expectedSpan)

    // Build expected error span object
    const expectedErrorSpan = this._buildExpectedSpan(`${normalizedName}.${methodName}`, spanKind, instrumentation, true)
    const expectedErrorSpanStr = this._formatExpectedSpan(expectedErrorSpan)

    return `  describe('${testDescription}', () => {
    it('should generate span with correct tags (happy path)', async () => {
      const traceAssertion = agent.assertFirstTraceSpan(
${expectedSpanStr}
      )

      // Execute operation via test setup
      await testSetup.${testMethod}()

      return traceAssertion
    })

    it('should generate span with error tags (error path)', async () => {
      const traceAssertion = agent.assertFirstTraceSpan(
${expectedErrorSpanStr}
      )

      // Execute operation error variant
      try {
        await testSetup.${testMethod}Error()
      } catch (err) {
        // Expected error
      }

      return traceAssertion
    })
  })`
  }

  _buildExpectedSpan (operation, spanKind, instrumentation, includeError = false) {
    const expectedSpan = {
      name: operation,
      meta: {
        'span.kind': spanKind
      },
      metrics: {}
    }

    // Add error fields if this is an error test
    if (includeError) {
      expectedSpan.error = 1
      expectedSpan.meta['error.type'] = '__PLACEHOLDER__'
      expectedSpan.meta['error.message'] = '__PLACEHOLDER__'
      expectedSpan.meta['error.stack'] = '__PLACEHOLDER__'
    }

    // Add semantic tags from context_capture
    const mappedTags = Object.entries(instrumentation.context_capture || {}).filter(([key, value]) =>
      value && value !== null && key !== 'span.kind'
    )

    // Also include tags if they exist
    if (instrumentation.tags) {
      mappedTags.push(...Object.entries(instrumentation.tags).filter(([key, value]) =>
        value && value !== null && key !== 'span.kind'
      ))
    }

    for (const [tagKey, tagMapping] of mappedTags) {
      // Skip null values
      if (tagMapping === null || tagMapping === undefined) {
        continue
      }

      // Check if it's a literal value (wrapped in single or double quotes)
      const isLiteral = typeof tagMapping === 'string' &&
        ((tagMapping.startsWith("'") && tagMapping.endsWith("'")) ||
          (tagMapping.startsWith('"') && tagMapping.endsWith('"')))

      if (isLiteral) {
        // Literal value - expect exact match
        const literalValue = tagMapping.slice(1, -1) // Remove quotes
        expectedSpan.meta[tagKey] = literalValue
      } else {
        // Context path or dynamic value - use placeholder in meta
        // We default to meta since we can't reliably determine if it's meta or metrics without a value
        expectedSpan.meta[tagKey] = '__PLACEHOLDER__'
      }
    }

    return expectedSpan
  }

  _formatExpectedSpan (expectedSpan) {
    // Convert to JSON with proper indentation (2 spaces)
    let jsonStr = JSON.stringify(expectedSpan, null, 2)

    // Replace placeholders with hardcoded fix-me string
    // This forces the AI agent to notice and replace with actual values
    jsonStr = jsonStr.replace(/"__PLACEHOLDER__"/g, "'FIX_THIS_WITH_ACTUAL_VALUE_OR_USE_ANY_STRING_IF_UNPREDICTABLE'")

    // Add indentation for the test file (8 spaces to match the assertion structure)
    return jsonStr
      .split('\n')
      .map(line => `        ${line}`)
      .join('\n')
  }
}

module.exports = { TestGenerator }
