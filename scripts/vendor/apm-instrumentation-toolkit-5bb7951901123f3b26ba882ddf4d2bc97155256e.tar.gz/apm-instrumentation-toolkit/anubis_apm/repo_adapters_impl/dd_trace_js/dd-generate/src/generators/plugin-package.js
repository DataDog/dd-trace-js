'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')

/**
 * Creates the plugin package directory structure
 *
 * V6 Approach (Orchestrion):
 * - Create plugin src/ and test/ directories
 * - Analysis stays as artifact in .analysis/ (not copied to plugin)
 * - No sample app folder in tests (orchestrion handles instrumentation)
 */
async function createPluginPackage (outputDir, integrationName, packageName, analysis) {
  // Normalize package name for directory and file paths (e.g., @scope/pkg -> scope-pkg)
  const normalizedName = integrationName.replace('@', '').replace('/', '-')

  const pluginDir = path.join(outputDir, 'packages', `datadog-plugin-${normalizedName}`)
  const srcDir = path.join(pluginDir, 'src')
  const testDir = path.join(pluginDir, 'test')

  // Create directories
  await fs.mkdir(srcDir, { recursive: true })
  await fs.mkdir(testDir, { recursive: true })

  console.log(`📦 Created plugin package structure: ${pluginDir}`)

  return pluginDir
}

module.exports = { createPluginPackage }
