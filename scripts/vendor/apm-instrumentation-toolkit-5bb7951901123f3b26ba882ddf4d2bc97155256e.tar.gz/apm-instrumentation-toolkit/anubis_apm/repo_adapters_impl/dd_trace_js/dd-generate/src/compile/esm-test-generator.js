'use strict'

/**
 * ESM Test Generator
 *
 * Generates ESM (ES Module) integration tests for packages that use "type": "module"
 * or otherwise require ESM testing approach.
 *
 * Generates two files:
 * 1. integration-test/server.mjs - Pure ESM test code that exercises the library
 * 2. integration-test/client.spec.js - CommonJS test runner with sandbox
 */

/* eslint-disable no-console */

const fs = require('fs')
const path = require('path')
const { FileHelper } = require('../../../shared/file-helper')
const { toPascalCase } = require('./utils')

class EsmTestGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    this.fileHelper = new FileHelper()
  }

  generate () {
    // Ensure integration-test directory exists
    const testDir = this._getIntegrationTestDir()
    fs.mkdirSync(testDir, { recursive: true })

    // Generate both ESM test files
    this._generateServerMjs()
    this._generateClientSpec()
  }

  _getIntegrationTestDir () {
    const normalizedName = this.integrationName.replace('@', '').replace('/', '-')
    return path.join(process.cwd(), `packages/datadog-plugin-${normalizedName}/test/integration-test`)
  }

  /**
   * Generate the server.mjs file - Pure ESM test code
   */
  _generateServerMjs () {
    const content = this._getServerMjsContent()
    const filePath = path.join(this._getIntegrationTestDir(), 'server.mjs')
    this.fileHelper.createOrUpdateFile(filePath, content)
    console.log(`✅ Generated ESM test server: ${filePath}`)
  }

  /**
   * Generate the client.spec.js file - CommonJS test runner
   */
  _generateClientSpec () {
    const content = this._getClientSpecContent()
    const filePath = path.join(this._getIntegrationTestDir(), 'client.spec.js')
    this.fileHelper.createOrUpdateFile(filePath, content)
    console.log(`✅ Generated ESM test client: ${filePath}`)
  }

  _getServerMjsContent () {
    const { name: packageName } = this.analysis.package
    const instrumentations = this.analysis.orchestrion_config?.instrumentations || []

    // Get main class/export to import
    const mainExports = this._getMainExports(instrumentations)
    const importStatement = mainExports.length > 0
      ? `import { ${mainExports.join(', ')} } from '${packageName}'`
      : `import ${toPascalCase(this.integrationName)} from '${packageName}'`

    // Generate test operations
    const testOperations = this._generateTestOperations(instrumentations)

    return `/**
 * ESM Integration Test Server
 *
 * This file exercises the ${packageName} library to generate spans.
 * It runs as a subprocess with dd-trace initialized via --loader flag.
 */

${importStatement}

// Exercise the library operations
async function main () {
  try {
${testOperations}
  } catch (err) {
    console.error('Test error:', err.message)
    process.exit(1)
  }
}

main()
`
  }

  _getClientSpecContent () {
    const { name: packageName } = this.analysis.package
    const normalizedName = this.integrationName.replace('@', '').replace('/', '-')
    const spanName = `${normalizedName}.request`

    return `'use strict'

const assert = require('node:assert/strict')
const {
  FakeAgent,
  sandboxCwd,
  useSandbox,
  checkSpansForServiceName,
  spawnPluginIntegrationTestProc
} = require('../../../../integration-tests/helpers')
const { withVersions } = require('../../../dd-trace/test/setup/mocha')

describe('esm', () => {
  let agent
  let proc

  withVersions('${normalizedName}', '${packageName}', version => {
    useSandbox([\`'${packageName}@\${version}'\`], false, [
      './packages/datadog-plugin-${normalizedName}/test/integration-test/*'
    ])

    beforeEach(async () => {
      agent = await new FakeAgent().start()
    })

    afterEach(async () => {
      proc && proc.kill()
      await agent.stop()
    })

    it('is instrumented', async () => {
      const res = agent.assertMessageReceived(({ headers, payload }) => {
        assert.strictEqual(headers.host, \`127.0.0.1:\${agent.port}\`)
        assert.ok(Array.isArray(payload))
        assert.strictEqual(checkSpansForServiceName(payload, '${spanName}'), true)
      })

      // Spawn ESM subprocess - uses default --loader from helper
      proc = await spawnPluginIntegrationTestProc(sandboxCwd(), 'server.mjs', agent.port)

      await res
    }).timeout(20000)
  })
})
`
  }

  _getMainExports (instrumentations) {
    // Extract unique class names from instrumentations
    const classNames = new Set()
    for (const instr of instrumentations) {
      const className = instr.function_query?.class
      if (className) {
        classNames.add(className)
      }
    }
    return Array.from(classNames)
  }

  _generateTestOperations (instrumentations) {
    if (instrumentations.length === 0) {
      return '    // TODO: Add test operations that exercise the library'
    }

    const operations = []
    const seenClasses = new Set()

    for (const instr of instrumentations) {
      const className = instr.function_query?.class
      const methodName = instr.function_query?.name

      if (className && !seenClasses.has(className)) {
        seenClasses.add(className)
        // Generate a simple instantiation and method call
        const varName = className.charAt(0).toLowerCase() + className.slice(1)
        operations.push(`    // Test ${className}.${methodName}()`)
        operations.push(`    // const ${varName} = new ${className}({/* config */})`)
        operations.push(`    // await ${varName}.${methodName}()`)
        operations.push('')
      }
    }

    if (operations.length === 0) {
      return '    // TODO: Add test operations that exercise the library'
    }

    return operations.join('\n')
  }
}

module.exports = { EsmTestGenerator }
