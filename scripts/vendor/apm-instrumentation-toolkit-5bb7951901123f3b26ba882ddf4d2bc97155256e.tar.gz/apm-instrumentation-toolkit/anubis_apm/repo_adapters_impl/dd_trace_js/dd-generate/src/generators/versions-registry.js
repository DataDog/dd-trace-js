'use strict'
/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')

/**
 * Extract unique modules and their versions from analysis.
 * @param {Object} analysis - The final analysis object
 * @returns {Map<string, string>} Map of module name -> version
 */
function extractModulesFromAnalysis (analysis) {
  const modules = new Map()

  // Always add the main package
  if (analysis.package?.name && analysis.package?.version) {
    modules.set(analysis.package.name, analysis.package.version)
  }

  // Extract unique modules from instrumentations
  const instrumentations = analysis.orchestrion_config?.instrumentations || []
  for (const instr of instrumentations) {
    if (instr.module_name && instr.version_range) {
      // Extract version from version_range (e.g., "^5.27.0" -> "5.27.0")
      const version = instr.version_range.replace(/^[\^~]/, '')
      // Only add if not already present (main package takes precedence)
      if (!modules.has(instr.module_name)) {
        modules.set(instr.module_name, version)
      }
    }
  }

  return modules
}

async function updateVersionsRegistry (repoRoot, packageName, packageVersion, analysis = null) {
  const versionsFilePath = path.join(
    repoRoot,
    'packages',
    'dd-trace',
    'test',
    'plugins',
    'versions',
    'package.json'
  )

  try {
    const content = await fs.readFile(versionsFilePath, 'utf8')
    const packageJson = JSON.parse(content)

    // Collect all modules to add
    const modulesToAdd = new Map()

    // If analysis is provided, extract all unique modules
    if (analysis) {
      const modules = extractModulesFromAnalysis(analysis)
      for (const [name, version] of modules) {
        if (!packageJson.dependencies[name]) {
          modulesToAdd.set(name, version)
        }
      }
    } else {
      // Fallback to single package (backwards compatibility)
      if (!packageJson.dependencies[packageName]) {
        modulesToAdd.set(packageName, packageVersion)
      }
    }

    // Check if any packages need to be added
    if (modulesToAdd.size === 0) {
      console.log('   ℹ️  All packages already exist in versions/package.json')
      return
    }

    // Insert each module alphabetically via text manipulation to preserve formatting
    let updatedContent = content
    for (const [name, version] of modulesToAdd) {
      const newEntry = `    "${name}": "${version}",`
      const lines = updatedContent.split('\n')
      let inserted = false

      // Find the dependencies section and insert alphabetically
      let inDeps = false
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].includes('"dependencies"')) {
          inDeps = true
          continue
        }
        if (inDeps) {
          const match = lines[i].match(/^ {4}"([^"]+)"/)
          if (match && match[1] > name) {
            lines.splice(i, 0, newEntry)
            inserted = true
            break
          }
          // End of dependencies block
          if (lines[i].trim() === '}' || lines[i].trim() === '},') {
            lines.splice(i, 0, newEntry)
            inserted = true
            break
          }
        }
      }

      if (!inserted) {
        console.warn(`   ⚠️  Could not find insertion point for ${name} in versions/package.json`)
        continue
      }

      updatedContent = lines.join('\n')
      console.log(`   ✅ Added ${name}@${version} to versions/package.json`)
    }

    await fs.writeFile(versionsFilePath, updatedContent)
  } catch (error) {
    console.error(`   ❌ Failed to update versions/package.json: ${error.message}`)
    throw error
  }
}

module.exports = { updateVersionsRegistry, extractModulesFromAnalysis }
