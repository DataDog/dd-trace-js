'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { FileHelper } = require('../../../shared/file-helper')
const { toPascalCase, toMethodName, normalizePackageName } = require('./utils')

class TestSetupGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    this.fileHelper = new FileHelper()
  }

  async generate () {
    const sampleAppContent = await this._readSampleAppFile()
    const implementedMethods = this._parseImplementedMethods(sampleAppContent)
    // Map sample app methods to operation-based methods
    const operationMethods = this._mapMethodsToOperations(implementedMethods)
    const content = this._getTestSetupFileContent(operationMethods, sampleAppContent)
    const filePath = this._getTestSetupFilePath()
    this.fileHelper.createOrUpdateFile(filePath, content)
    console.log(`✅ Generated test setup file: ${filePath}`)
  }

  _getTestSetupFilePath () {
    const normalizedName = normalizePackageName(this.integrationName)
    return path.join(process.cwd(), `packages/datadog-plugin-${normalizedName}/test/test-setup.js`)
  }

  async _readSampleAppFile () {
    try {
      return await fs.readFile(process.env.SAMPLE_APP_PATH, 'utf8')
    } catch (e) {
      console.warn(
        `⚠️  Could not read sample-app.js at ${process.env.SAMPLE_APP_PATH}. Test setup file will be generated with empty methods.`
      )
      return ''
    }
  }

  _mapMethodsToOperations (implementedMethods) {
    // Map sample app methods (e.g., "connectionQuery") to camelCase format
    const instrumentations = this.analysis.orchestrion_config?.instrumentations || []
    const operationMethods = {}

    // Keep setup and teardown as-is
    if (implementedMethods.setup) operationMethods.setup = implementedMethods.setup
    if (implementedMethods.teardown) operationMethods.teardown = implementedMethods.teardown

    // Map each instrumentation to its sample app method
    for (const instr of instrumentations) {
      const className = instr.function_query?.class || ''
      const methodName = instr.function_query?.name || ''

      // Sample app method naming convention: camelCase (e.g., "connectionQuery", "poolQuery")
      const sampleAppMethodName = this._getSampleAppMethodName(className, methodName)

      // Test setup method naming: same camelCase format
      const testMethodName = toMethodName(className, methodName)

      // Find the implemented method (base version)
      if (implementedMethods[sampleAppMethodName]) {
        operationMethods[testMethodName] = implementedMethods[sampleAppMethodName]
          .replace(new RegExp(`async ${sampleAppMethodName}`, 'g'), `async ${testMethodName}`)
      }

      // Also find the Error variant (e.g., connectionQueryError)
      const sampleAppErrorMethodName = `${sampleAppMethodName}Error`
      const testErrorMethodName = `${testMethodName}Error`
      if (implementedMethods[sampleAppErrorMethodName]) {
        operationMethods[testErrorMethodName] = implementedMethods[sampleAppErrorMethodName]
          .replace(new RegExp(`async ${sampleAppErrorMethodName}`, 'g'), `async ${testErrorMethodName}`)
      }
    }

    return operationMethods
  }

  _getSampleAppMethodName (className, methodName) {
    // Convert "Connection" + "query" to "connectionQuery" (camelCase)
    return toMethodName(className, methodName)
  }

  _parseImplementedMethods (content) {
    if (!content) return {}

    const methods = {}
    const classBodyMatch = content.match(/class\s+\w+\s*\{([\s\S]*)\}/)
    if (!classBodyMatch) return {}
    const classBody = classBodyMatch[1]

    // Extract the library variable name from imports
    // e.g., { Queue, Worker } from "const { Queue, Worker } = require('bullmq')")
    const destructuredMatch = content.match(/const\s+\{([^}]+)\}\s+=\s+require\(['"]([a-z][a-z0-9-_]*)['"]\)/)
    const simpleMatch = content.match(/const\s+(\w+)\s+=\s+require\(['"]([a-z][a-z0-9-_]*)['"]\)/)
    const libraryVarName = simpleMatch ? simpleMatch[1] : null
    const destructuredVars = destructuredMatch ? destructuredMatch[1].split(',').map(v => v.trim()) : []

    // Extract constructor body
    let constructorBody = ''
    const constructorMatch = classBody.match(/constructor\s*\([^)]*\)\s*\{([\s\S]*?)\n {2}\}/)
    if (constructorMatch) {
      constructorBody = constructorMatch[1].trim()
    }

    const methodSignatureRegex = /async\s+(\w+)\s*\(([^)]*)\)\s*\{/g
    let match

    while ((match = methodSignatureRegex.exec(classBody)) !== null) {
      const methodName = match[1]
      const methodParams = match[2].trim()
      const bodyStartIndex = match.index + match[0].length
      let braceCount = 1
      let bodyEndIndex = -1

      for (let i = bodyStartIndex; i < classBody.length; i++) {
        if (classBody[i] === '{') braceCount++
        if (classBody[i] === '}') braceCount--
        if (braceCount === 0) {
          bodyEndIndex = i
          break
        }
      }

      if (bodyEndIndex !== -1) {
        let methodBody = classBody.substring(bodyStartIndex, bodyEndIndex)

        methodBody = methodBody
          .split('\n')
          .filter(line => !line.trim().startsWith('console.log'))
          .join('\n')
          .trim()

        // For setup method, prepend constructor body and replace library references
        if (methodName === 'setup') {
          if (constructorBody) {
            methodBody = constructorBody + (methodBody ? '\n' + methodBody : '')
          }

          // Replace library variable references with 'module'
          if (libraryVarName) {
            // Handle both factory function calls and constructor calls
            methodBody = methodBody.replace(new RegExp(`${libraryVarName}\\(`, 'g'), 'module(')
            methodBody = methodBody.replace(new RegExp(`new ${libraryVarName}\\(`, 'g'), 'new module(')
            methodBody = methodBody.replace(new RegExp(`${libraryVarName}\\.`, 'g'), 'module.')
          }

          // Replace destructured class names with module.ClassName
          destructuredVars.forEach(varName => {
            methodBody = methodBody.replace(new RegExp(`${varName}\\(`, 'g'), `module.${varName}(`)
            methodBody = methodBody.replace(new RegExp(`new ${varName}\\(`, 'g'), `new module.${varName}(`)
            methodBody = methodBody.replace(new RegExp(`${varName}\\.`, 'g'), `module.${varName}.`)
          })
        }

        // Remove console.error statements from all methods
        methodBody = methodBody
          .split('\n')
          .filter(line => !line.trim().startsWith('console.error'))
          .join('\n')
          .trim()

        const indentedBody = methodBody.split('\n').map(line => `    ${line}`).join('\n')

        // Preserve original signature for setup (with module param) and other methods
        let signature
        if (methodName === 'setup') {
          signature = 'async setup (module)'
        } else if (methodParams) {
          // Preserve original parameters
          signature = `async ${methodName} (${methodParams})`
        } else {
          signature = `async ${methodName} ()`
        }

        methods[methodName] = `
  ${signature} {
${indentedBody}
  }`
      }
    }
    return methods
  }

  _getTestSetupFileContent (implementedMethods = {}, sampleAppContent = '') {
    // Normalize scoped package names before PascalCase (e.g., @scope/pkg -> scope-pkg -> ScopePkg)
    const normalizedName = normalizePackageName(this.integrationName)
    const className = `${toPascalCase(normalizedName)}TestSetup`
    const headerContent = this._extractHeaderContent(sampleAppContent)

    // Determine if we need http module based on methods
    const needsHttp = Object.keys(implementedMethods).some(name =>
      implementedMethods[name] && implementedMethods[name].includes('http.request')
    )

    const httpImport = needsHttp ? "const http = require('http')\n\n" : ''

    const setupMethod = implementedMethods.setup || `async setup (module) {
    // TODO: Implement setup logic.
  }`
    const teardownMethod = implementedMethods.teardown || `async teardown () {
    // TODO: Implement teardown logic.
  }`

    // Get all methods (operation methods including _error variants)
    const operationMethods = Object.keys(implementedMethods)
      .filter(name => !['setup', 'teardown', 'constructor'].includes(name))
      .map(name => {
        // Return methods as-is (no need to add expectError parameter - we use separate _error methods)
        return implementedMethods[name].trim()
      })
      .join('\n\n')

    return `'use strict'

${httpImport}${headerContent}

class ${className} {
  ${setupMethod}

  ${teardownMethod}

  // --- Operations ---
${operationMethods}
}

module.exports = ${className}
`
  }

  _extractHeaderContent (content) {
    if (!content) return ''
    const headerRegex = /'use strict'([\s\S]*?)class\s+\w+\s*\{/
    const match = content.match(headerRegex)
    if (!match) return ''

    return match[1]
      .split('\n')
      .filter(line => {
        const trimmed = line.trim()
        // Remove ALL require() statements - test setup should not have top-level imports
        if (trimmed.includes('require(')) return false
        // Keep only comments and eslint pragmas
        return trimmed.length > 0
      })
      .join('\n')
      .trim()
  }
}

module.exports = { TestSetupGenerator }
