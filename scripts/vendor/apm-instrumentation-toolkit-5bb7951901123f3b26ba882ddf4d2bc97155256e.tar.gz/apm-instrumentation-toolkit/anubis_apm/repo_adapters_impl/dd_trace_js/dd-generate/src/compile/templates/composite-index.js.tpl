'use strict'

const CompositePlugin = require('../../dd-trace/src/plugins/composite')
{{imports}}

class {{compositeClassName}} extends CompositePlugin {
  static id = '{{packageName}}'
  static plugins = {
{{pluginEntries}}
  }
}

module.exports = {{compositeClassName}}
