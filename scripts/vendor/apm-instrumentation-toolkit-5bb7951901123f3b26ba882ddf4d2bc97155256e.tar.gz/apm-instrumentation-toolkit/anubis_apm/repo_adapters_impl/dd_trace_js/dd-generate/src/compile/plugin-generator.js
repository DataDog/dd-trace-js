'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { getUniqueModules } = require('./utils')

class PluginGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    // Normalize package name for directory paths (e.g., @scope/pkg -> scope-pkg)
    const normalizedName = integrationName.replace('@', '').replace('/', '-')
    this.pluginDir = path.join(process.cwd(), 'packages', `datadog-plugin-${normalizedName}`)
    this.pluginRegistryPath = path.join(process.cwd(), 'packages', 'dd-trace', 'src', 'plugins', 'index.js')
  }

  async updatePluginRegistry () {
    const uniqueModules = getUniqueModules(this.analysis, this.integrationName)
    let content = await fs.readFile(this.pluginRegistryPath, 'utf8')

    for (const moduleName of uniqueModules) {
      content = await this._addPluginEntry(content, moduleName)
    }

    await fs.writeFile(this.pluginRegistryPath, content)
    console.log(`✅ Updated plugin registry with ${uniqueModules.length} module(s): ${uniqueModules.join(', ')}`)
  }

  async _addPluginEntry (content, pluginId) {
    // Check if already registered (with or without quotes)
    if (content.includes(`get '${pluginId}'`) || content.includes(`get ${pluginId} (`)) {
      console.log(`Plugin '${pluginId}' already exists in the registry. Skipping.`)
      return content
    }

    // Find the plugins object boundaries (const plugins = { ... })
    const start = content.indexOf('const plugins = {')
    // Find the closing brace before "module.exports"
    const exportIdx = content.indexOf('module.exports')
    const end = exportIdx !== -1 ? content.lastIndexOf('}', exportIdx) : content.lastIndexOf('}')

    if (start === -1 || end === -1 || end <= start) {
      throw new Error('Could not parse plugin registry structure.')
    }

    const objectStart = 'const plugins = {'
    const before = content.slice(0, start)
    const inner = content.slice(start + objectStart.length, end)
    const after = content.slice(end)

    // Parse existing getters to find insertion point
    const lines = inner.split('\n')
    const getters = []

    for (let idx = 0; idx < lines.length; idx++) {
      const line = lines[idx]
      const match = line.match(/^\s*get\s+([^\s]+)\s*\(\)\s*\{\s*return\s+require\(([^)]+)\)\s*\}\s*,?\s*$/)
      if (match) {
        getters.push({
          idx,
          rawKey: match[1],
          req: match[2],
          normalizedKey: match[1].replace(/^["']|["']$/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ')
        })
      }
    }

    // Find where to insert (alphabetically)
    const targetNorm = pluginId.toLowerCase()
    let insertIdx = -1

    for (const getter of getters) {
      if (getter.normalizedKey > targetNorm) {
        insertIdx = getter.idx
        break
      }
    }

    // Conditionally quote the key if it's not a valid identifier
    const key = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(pluginId) ? pluginId : `'${pluginId}'`

    // All entries point to the same plugin package (named after the integration)
    const normalizedIntegration = this.integrationName.replace('@', '').replace('/', '-')
    const newGetter = `  get ${key} () { return require('../../../datadog-plugin-${normalizedIntegration}/src') },`

    if (insertIdx === -1) {
      // Find the last getter and insert after it
      if (getters.length > 0) {
        const lastGetter = getters[getters.length - 1]
        lines.splice(lastGetter.idx + 1, 0, newGetter)
      } else {
        // No getters yet, just add it at the beginning of the object
        lines.splice(1, 0, newGetter)
      }
    } else {
      // Insert at specific position
      lines.splice(insertIdx, 0, newGetter)
    }

    // Rebuild and return content
    const newContent = before + objectStart + lines.join('\n') + after
    console.log(`  Added plugin entry for '${pluginId}'`)

    return newContent
  }
}

module.exports = { PluginGenerator }
