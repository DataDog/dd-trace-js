'use strict'
/* eslint-disable no-console */

const { PluginGenerator } = require('./plugin-generator')
const { PluginCodeGenerator } = require('./plugin-code-generator')
const { InstrumentationGenerator } = require('./instrumentation-generator')
const { OrchestrionConfigGenerator } = require('./orchestrion-config-generator')
const { HooksGenerator } = require('./hooks-generator')
const { TestGenerator } = require('./test-generator')
const { TestSetupGenerator } = require('./test-setup-generator')
const { SchemaGenerator } = require('./schema-generator')
const { EsmTestGenerator } = require('./esm-test-generator')
const { normalizePackageName } = require('./utils')

class Compiler {
  constructor (integrationName) {
    // Normalize the integration name for use in file paths, CI jobs, class names, etc.
    // e.g., '@anthropic-ai/claude-agent-sdk' -> 'anthropic-ai-claude-agent-sdk'
    // The original package name is preserved in analysis.package.name for npm references
    this.integrationName = normalizePackageName(integrationName)
    const analysisPath = process.env.ANALYSIS_PATH

    this.analysis = require(analysisPath)

    this.pluginGenerator = new PluginGenerator(this.integrationName, this.analysis)
    this.pluginCodeGenerator = new PluginCodeGenerator(this.integrationName, this.analysis)
    this.instrumentationGenerator = new InstrumentationGenerator(this.integrationName, this.analysis)
    this.orchestrionConfigGenerator = new OrchestrionConfigGenerator(this.integrationName, this.analysis)
    this.hooksGenerator = new HooksGenerator(this.integrationName, this.analysis)
    this.testGenerator = new TestGenerator(this.integrationName, this.analysis)
    this.testSetupGenerator = new TestSetupGenerator(this.integrationName, this.analysis)
    this.schemaGenerator = new SchemaGenerator(this.integrationName, this.analysis)
  }

  async main () {
    console.log(`Compiling plugin for ${this.integrationName}...`)

    // Generate plugin code (producer.js, consumer.js, index.js)
    await this.pluginCodeGenerator.generate()

    // Generate instrumentation file
    await this.instrumentationGenerator.generate()

    // Generate orchestrion config JSON
    await this.orchestrionConfigGenerator.generate()

    // Update central registries
    await this.pluginGenerator.updatePluginRegistry()
    await this.hooksGenerator.updateHooksRegistry()

    // Update service naming schema (for schema-based categories)
    await this.schemaGenerator.generate()

    // Generate tests based on module type
    await this._generateTests()

    console.log(`✅ Plugin compilation successful for ${this.integrationName}.`)
  }

  /**
   * Generate tests based on module type (ESM, CommonJS, or dual).
   */
  async _generateTests () {
    const moduleType = this.analysis.module_type || 'commonjs'
    console.log(`Module type: ${moduleType}`)

    if (moduleType === 'esm' || moduleType === 'dual') {
      const esmTestGenerator = new EsmTestGenerator(this.integrationName, this.analysis)
      esmTestGenerator.generate()
    }

    if (moduleType === 'commonjs' || moduleType === 'dual') {
      await this.testSetupGenerator.generate()
      this.testGenerator.generate()
    }
  }
}

module.exports = Compiler
