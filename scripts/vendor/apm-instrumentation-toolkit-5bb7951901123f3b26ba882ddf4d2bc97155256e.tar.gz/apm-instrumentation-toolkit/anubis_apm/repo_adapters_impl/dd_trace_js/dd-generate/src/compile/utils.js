'use strict'

/**
 * Name Sanitizer for dd-compile
 *
 * Handles sanitization of class names and method names from analysis.json
 * to create valid JavaScript identifiers.
 *
 * Example:
 *   Input:  "polka/index.js - Polka"
 *   Output: "Polka"
 *
 *   Input:  "apm:polka:polka/index.js - polka:handler"
 *   Output: "apm:polka:polka:handler"
 */

/**
 * Sanitize a class name by removing file path prefixes
 * @param {string} className - Raw class name from analysis.json (e.g., "polka/index.js - Polka")
 * @returns {string} - Sanitized class name (e.g., "Polka")
 */
function sanitizeClassName (className) {
  if (!className) return ''

  // Remove file path prefix (e.g., "polka/index.js - Polka" -> "Polka")
  const match = className.match(/^.*\s+-\s+(.+)$/)
  if (match) {
    return match[1].trim()
  }

  // If no prefix, return as-is
  return className
}

/**
 * Create a valid JavaScript identifier from a class name
 * Removes all invalid characters and converts to camelCase
 * @param {string} name - Name to convert
 * @returns {string} - Valid JavaScript identifier
 */
function toValidIdentifier (name) {
  if (!name) return ''

  // First sanitize if it has a file path prefix
  const sanitized = sanitizeClassName(name)

  // Remove all characters that aren't alphanumeric or underscore
  // Replace with empty string
  return sanitized.replace(/[^a-zA-Z0-9_$]/g, '')
}

/**
 * Convert a string to camelCase for method names
 * @param {string} str - String to convert
 * @returns {string} - camelCase string
 */
function toCamelCase (str) {
  if (!str) return ''

  const sanitized = toValidIdentifier(str)

  // Convert first char to lowercase
  return sanitized.charAt(0).toLowerCase() + sanitized.slice(1)
}

/**
 * Convert class name and method name to camelCase function name
 * e.g., "Connection" + "query" -> "connectionQuery"
 *       "Queue" + "addBulk" -> "queueAddBulk"
 * @param {string} className - Class name (e.g., "Connection", "Queue")
 * @param {string} methodName - Method name (e.g., "query", "addBulk")
 * @returns {string} - camelCase method name
 */
function toMethodName (className, methodName) {
  const safeName = methodName.replace(/[^a-zA-Z0-9]/g, '')
  if (!className) {
    return safeName.charAt(0).toLowerCase() + safeName.slice(1)
  }
  const safeClass = className.replace(/[^a-zA-Z0-9]/g, '')
  return safeClass.charAt(0).toLowerCase() + safeClass.slice(1) + safeName.charAt(0).toUpperCase() + safeName.slice(1)
}

/**
 * Convert a string to PascalCase for class names
 * Handles kebab-case, snake_case, camelCase, acronyms, and mixed inputs
 * Examples:
 *   - 'hello-world' -> 'HelloWorld'
 *   - 'SDKSession' -> 'SdkSession'
 *   - 'unstable_v2_prompt' -> 'UnstableV2Prompt'
 * @param {string} str - String to convert
 * @returns {string} - PascalCase string
 */
function toPascalCase (str) {
  if (!str) return ''

  return str
    // First split on delimiters (kebab-case, snake_case, spaces)
    .split(/[-_\s]+/)
    // Then handle camelCase and acronyms:
    // - Split between lowercase and uppercase: 'camelCase' -> 'camel', 'Case'
    // - Split acronyms from words: 'SDKSession' -> 'SDK', 'Session'
    .flatMap(word => word.split(/(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])/))
    // Capitalize first letter of each word, lowercase the rest
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join('')
}

/**
 * Get unique module names from all instrumentation targets in an analysis.
 * Each target may hook a different package (e.g., neo4j-driver-core vs neo4j-driver).
 * @param {object} analysis - Analysis object with orchestrion_config.instrumentations
 * @param {string} fallback - Fallback module name if no modules found (usually integrationName)
 * @returns {string[]} - Array of unique module names
 */
function getUniqueModules (analysis, fallback) {
  const instrumentations = analysis?.orchestrion_config?.instrumentations || []
  const modules = new Set()

  for (const instr of instrumentations) {
    if (instr.module_name) {
      modules.add(instr.module_name)
    }
  }

  // If no modules found, fall back to provided fallback
  if (modules.size === 0 && fallback) {
    modules.add(fallback)
  }

  return Array.from(modules)
}

/**
 * Normalize context paths from analysis format to ctx accessor format
 * @param {string} path - Path like "this.name", "arguments[0]", etc.
 * @returns {string} - Normalized path like "ctx.self?.name", "ctx.arguments?.[0]"
 */
function normalizeContextPath (path) {
  // Handle safe getters with optional chaining to avoid errors on undefined/null
  // Make all property accesses safe: . -> ?. and ]. -> ]?.
  const makeSafe = (p) => p.replace(/\]\./g, ']?.').replace(/\./g, '?.')

  // "this.name" -> "ctx.self?.name"
  if (path.startsWith('this.')) {
    return `ctx.self?.${makeSafe(path.substring(5))}`
  }

  // "arguments[0]" -> "ctx.arguments?.[0]"
  if (path.startsWith('arguments[')) {
    return `ctx.arguments?.${makeSafe(path.substring(9))}`
  }

  // "args[0]" -> "ctx.arguments?.[0]"
  if (path.startsWith('args[')) {
    return `ctx.arguments?.${makeSafe(path.substring(4))}`
  }

  // "returnValue.id" -> "ctx.returnValue?.id"
  if (path.startsWith('returnValue.')) {
    return `ctx.returnValue?.${makeSafe(path.substring(12))}`
  }

  // Default: assume it's a direct ctx property with optional chaining
  // "config.database" -> "ctx.config?.database"
  return `ctx.${makeSafe(path)}`
}

/**
 * Generate tag extraction code from a mapping value
 * @param {string} tagName - The tag name
 * @param {string} mapping - The mapping value (e.g., "'hardcoded'", "this.name")
 * @returns {object|null} - { tag, code } or null if mapping is invalid
 */
function generateTagExtraction (tagName, mapping) {
  // Handle null or undefined mappings - skip them
  if (mapping === null || mapping === undefined) {
    return null
  }

  // Hardcoded value: 'bullmq', "bullmq", or "\"bullmq\"" -> 'bullmq'
  // Handle JSON-escaped quotes from AI-generated mappings
  let cleanMapping = mapping
  if (mapping.startsWith('"') && mapping.endsWith('"')) {
    const inner = mapping.slice(1, -1)
    if (inner.startsWith('\\"') && inner.endsWith('\\"')) {
      cleanMapping = `"${inner.slice(2, -2)}"`
    }
  }

  if ((cleanMapping.startsWith("'") && cleanMapping.endsWith("'")) ||
    (cleanMapping.startsWith('"') && cleanMapping.endsWith('"'))) {
    return {
      tag: tagName,
      code: cleanMapping
    }
  }

  // Context path: "this.name" -> ctx.self?.name
  // Normalize to orchestrion context format
  const normalizedPath = normalizeContextPath(mapping)

  return {
    tag: tagName,
    code: normalizedPath
  }
}

/**
 * Normalize a scoped package name for use in directory paths.
 * Removes '@' prefix and replaces '/' with '-'.
 * Examples:
 *   - '@anthropic-ai/claude-agent-sdk' -> 'anthropic-ai-claude-agent-sdk'
 *   - '@scope/package' -> 'scope-package'
 *   - 'regular-package' -> 'regular-package'
 * @param {string} packageName - Package name (possibly scoped)
 * @returns {string} - Normalized name safe for directory paths
 */
function normalizePackageName (packageName) {
  if (!packageName) return ''
  return packageName.replace('@', '').replace('/', '-')
}

module.exports = {
  sanitizeClassName,
  toValidIdentifier,
  toCamelCase,
  toMethodName,
  toPascalCase,
  getUniqueModules,
  normalizeContextPath,
  generateTagExtraction,
  normalizePackageName
}
