'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')

/**
 * Converts integration name to environment variable format
 * e.g., 'bee-queue' -> 'BEE_QUEUE'
 */
function toEnvVarName (integrationName) {
  return integrationName.toUpperCase().replace(/-/g, '_')
}

/**
 * Normalize key for comparison by stripping leading underscores.
 * The file contains _DD_* entries (experimental) mixed with DD_* entries,
 * and underscore sorts after uppercase letters in ASCII which breaks
 * simple alphabetical insertion.
 */
function normalizeKey (key) {
  return key.replace(/^_+/, '')
}

async function updateSupportedConfigurations (repoRoot, integrationName) {
  const configFilePath = path.join(
    repoRoot,
    'packages',
    'dd-trace',
    'src',
    'config',
    'supported-configurations.json'
  )

  try {
    const content = await fs.readFile(configFilePath, 'utf8')

    const envVarName = `DD_TRACE_${toEnvVarName(integrationName)}_ENABLED`

    // Check if already exists
    if (content.includes(`"${envVarName}"`)) {
      console.log(`   ℹ️  ${envVarName} already exists in supported-configurations.json`)
      return
    }

    // Insert alphabetically via text manipulation to preserve original formatting.
    // Must match the file's schema: each entry is an array of objects with
    // implementation, type, and default fields.
    const newEntry = [
      `    "${envVarName}": [`,
      '      {',
      '        "implementation": "A",',
      '        "type": "boolean",',
      '        "default": "true"',
      '      }',
      '    ],'
    ].join('\n')
    const lines = content.split('\n')
    let inserted = false

    for (let i = 0; i < lines.length; i++) {
      const match = lines[i].match(/^ {4}"([^"]+)":\s*\[/)
      if (match && normalizeKey(match[1]) > normalizeKey(envVarName)) {
        lines.splice(i, 0, newEntry)
        inserted = true
        break
      }
    }

    if (!inserted) {
      // Insert before the closing brace of "supportedConfigurations"
      for (let i = lines.length - 1; i >= 0; i--) {
        if (lines[i].trim() === '}') {
          lines.splice(i, 0, newEntry)
          break
        }
      }
    }

    await fs.writeFile(configFilePath, lines.join('\n'))

    console.log(`   ✅ Added ${envVarName} to supported-configurations.json`)
  } catch (error) {
    console.error(`   ❌ Failed to update supported-configurations.json: ${error.message}`)
    throw error
  }
}

module.exports = { updateSupportedConfigurations }
