'use strict'
/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')

/**
 * Extract sub-modules from analysis that differ from the main package.
 * @param {Object} analysis - The final analysis object
 * @param {string} mainPackage - The main package name
 * @returns {Array<{name: string, version: string}>} Array of sub-modules with versions
 */
function extractSubModules (analysis, mainPackage) {
  const subModules = []
  const seen = new Set()

  const instrumentations = analysis?.orchestrion_config?.instrumentations || []
  for (const instr of instrumentations) {
    const moduleName = instr.module_name
    // Only include if different from main package and not already seen
    if (moduleName && moduleName !== mainPackage && !seen.has(moduleName)) {
      seen.add(moduleName)
      // Extract version from version_range (e.g., "^5.27.0" -> ">=5.27.0")
      const versionRange = instr.version_range || '*'
      // Convert ^ prefix to >= for externals format
      const version = versionRange.replace(/^\^/, '>=')
      subModules.push({ name: moduleName, version })
    }
  }

  return subModules
}

/**
 * Quote an object key the same way the surrounding file does:
 * unquoted if it's a valid JS identifier, single-quoted otherwise.
 * @param {string} key
 * @returns {string}
 */
function formatKey (key) {
  // Same identifier rule the existing file follows: bare identifiers vs quoted strings.
  // (Conservative: requires letter/_/$ start, then word chars.)
  if (/^[A-Za-z_$][\w$]*$/.test(key)) {
    return key
  }
  return `'${key.replace(/'/g, "\\'")}'`
}

/**
 * Render a list of sub-modules as a JS array literal matching the externals.js style.
 * @param {Array<{name: string, version: string}>} subModules
 * @param {string} indent - Indentation for the outer array (e.g. '  ' for 2 spaces).
 * @returns {string}
 */
function renderSubModulesArray (subModules, indent = '  ') {
  const inner = indent + '  '
  const entryIndent = inner + '  '
  const lines = ['[']
  for (const mod of subModules) {
    lines.push(`${inner}{`)
    lines.push(`${entryIndent}name: '${mod.name}',`)
    lines.push(`${entryIndent}versions: ['${mod.version}'],`)
    lines.push(`${inner}},`)
  }
  lines.push(`${indent}]`)
  return lines.join('\n')
}

/**
 * Find the closing `}` of the top-level `module.exports = { ... }` object literal
 * by scanning for balanced braces. Skips over string literals and comments so
 * braces inside them don't confuse the count.
 *
 * @param {string} source - Full file contents.
 * @returns {{ openIdx: number, closeIdx: number }} - Indices of the `{` and the matching `}`.
 */
function findExportsObjectBraces (source) {
  const exportsMatch = source.match(/module\.exports\s*=\s*\{/)
  if (!exportsMatch) {
    throw new Error('Could not locate `module.exports = {` in externals.js')
  }
  const openIdx = exportsMatch.index + exportsMatch[0].length - 1

  let depth = 0
  let i = openIdx
  while (i < source.length) {
    const ch = source[i]
    const next = source[i + 1]

    // Line comment
    if (ch === '/' && next === '/') {
      const eol = source.indexOf('\n', i)
      i = eol === -1 ? source.length : eol + 1
      continue
    }
    // Block comment
    if (ch === '/' && next === '*') {
      const end = source.indexOf('*/', i + 2)
      i = end === -1 ? source.length : end + 2
      continue
    }
    // String literals: ', ", `
    if (ch === '\'' || ch === '"' || ch === '`') {
      const quote = ch
      i += 1
      while (i < source.length) {
        const c = source[i]
        if (c === '\\') { i += 2; continue }
        if (c === quote) { i += 1; break }
        // Template literals can contain ${...}, but for our file we don't expect them in the
        // exports object; treating ` as a plain string is good enough since externals.js
        // doesn't use template literals at the object level.
        i += 1
      }
      continue
    }

    if (ch === '{') {
      depth += 1
    } else if (ch === '}') {
      depth -= 1
      if (depth === 0) {
        return { openIdx, closeIdx: i }
      }
    }
    i += 1
  }

  throw new Error('Could not find matching `}` for `module.exports = {` in externals.js')
}

/**
 * Check whether `module.exports` already has a top-level entry with this key.
 * Looks for `<key>:` or `'<key>':` / `"<key>":` at the top level (depth 1) of the object.
 *
 * @param {string} source
 * @param {string} key
 * @returns {boolean}
 */
function hasTopLevelKey (source, key) {
  const { openIdx, closeIdx } = findExportsObjectBraces(source)
  const body = source.slice(openIdx + 1, closeIdx)

  // Strip nested braces, comments, and strings so we only see top-level tokens.
  // Cheap-and-correct enough for keys: walk and only emit chars when depth==0.
  let depth = 0
  let i = 0
  let topLevel = ''
  while (i < body.length) {
    const ch = body[i]
    const next = body[i + 1]

    if (ch === '/' && next === '/') {
      const eol = body.indexOf('\n', i)
      i = eol === -1 ? body.length : eol + 1
      continue
    }
    if (ch === '/' && next === '*') {
      const end = body.indexOf('*/', i + 2)
      i = end === -1 ? body.length : end + 2
      continue
    }
    if (ch === '\'' || ch === '"' || ch === '`') {
      const quote = ch
      const start = i
      i += 1
      while (i < body.length) {
        const c = body[i]
        if (c === '\\') { i += 2; continue }
        if (c === quote) { i += 1; break }
        i += 1
      }
      // Keep the literal at top level (so we can detect quoted keys).
      if (depth === 0) topLevel += body.slice(start, i)
      continue
    }
    if (ch === '{' || ch === '[' || ch === '(') {
      if (depth === 0) topLevel += ' '
      depth += 1
      i += 1
      continue
    }
    if (ch === '}' || ch === ']' || ch === ')') {
      depth -= 1
      i += 1
      continue
    }
    if (depth === 0) topLevel += ch
    i += 1
  }

  // Now scan top-level text for `<ident>:` or `'<key>':` / `"<key>":`.
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const patterns = [
    new RegExp(`(^|[\\s,{])${escaped}\\s*:`),
    new RegExp(`(^|[\\s,{])'${escaped}'\\s*:`),
    new RegExp(`(^|[\\s,{])"${escaped}"\\s*:`),
  ]
  return patterns.some(p => p.test(topLevel))
}

/**
 * Insert a brand-new top-level entry into `module.exports = { ... }`, just before
 * the closing brace. Preserves the rest of the file (require lines, comments,
 * conditional ternaries like `DD_MAJOR >= 6 ? ... : ...`) byte-for-byte.
 *
 * @param {string} source
 * @param {string} key
 * @param {Array<{name: string, version: string}>} subModules
 * @returns {string}
 */
function insertNewEntry (source, key, subModules) {
  const { closeIdx } = findExportsObjectBraces(source)

  // Detect indentation used for top-level keys by looking at the line containing the closing brace.
  // The closing `}` is at the start of its line (zero indent at the object root).
  // Top-level keys are typically indented by 2 spaces; match the prevailing style.
  const before = source.slice(0, closeIdx)
  const lineStart = before.lastIndexOf('\n') + 1
  const closingLine = source.slice(lineStart, closeIdx)
  // If the closing brace is preceded by indentation (e.g. nested), capture it; otherwise default ''
  const closeIndent = /^(\s*)/.exec(closingLine)[1]
  // Top-level entries are indented one level deeper than the closing brace.
  const entryIndent = closeIndent + '  '

  const arrayLiteral = renderSubModulesArray(subModules, entryIndent)
  const formattedKey = formatKey(key)

  // Insert with a leading newline if the previous non-whitespace char isn't already a newline.
  const insertion = `${entryIndent}${formattedKey}: ${arrayLiteral},\n`

  return source.slice(0, lineStart) + insertion + source.slice(lineStart)
}

/**
 * Update externals.js with sub-module dependencies.
 *
 * Non-destructive: parses the file with a balanced-brace scanner, inserts a new
 * top-level entry before the closing `}` of `module.exports = { ... }`, and writes
 * the result back. The `require(...)` line, conditional expressions like
 * `DD_MAJOR >= 6 ? [...] : [...]`, comments, and surrounding formatting are all
 * preserved verbatim.
 *
 * Limitation: if `mainPackage` already exists in the file, this currently logs a
 * skip and does *not* mutate the existing entry. Appending sub-modules to an
 * existing entry would require a second-pass scan; treating that as a known
 * limitation is preferable to risking a destructive rewrite.
 *
 * @param {string} repoRoot - Root directory of the repository
 * @param {string} mainPackage - Main package name (key in externals.js)
 * @param {Object} analysis - The final analysis object
 */
async function updateExternals (repoRoot, mainPackage, analysis) {
  const externalsPath = path.join(
    repoRoot,
    'packages',
    'dd-trace',
    'test',
    'plugins',
    'externals.js'
  )

  const subModules = extractSubModules(analysis, mainPackage)

  if (subModules.length === 0) {
    console.log('   No sub-modules to add to externals.js')
    return
  }

  try {
    const content = await fs.readFile(externalsPath, 'utf8')

    if (hasTopLevelKey(content, mainPackage)) {
      console.log(
        `   Externals entry for ${mainPackage} already exists; skipping (non-destructive update only).`
      )
      return
    }

    const updated = insertNewEntry(content, mainPackage, subModules)
    await fs.writeFile(externalsPath, updated)

    console.log(`   Created externals entry for ${mainPackage} with ${subModules.length} sub-module(s)`)
    for (const mod of subModules) {
      console.log(`   ✅ Added ${mod.name} (${mod.version}) to externals.js under ${mainPackage}`)
    }
  } catch (error) {
    console.error(`   ❌ Failed to update externals.js: ${error.message}`)
    throw error
  }
}

module.exports = {
  updateExternals,
  extractSubModules,
  // Exported for tests:
  findExportsObjectBraces,
  hasTopLevelKey,
  insertNewEntry,
  formatKey,
}
