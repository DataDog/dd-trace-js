'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { getUniqueModules, normalizePackageName } = require('./utils')

class HooksGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    this.instrumentationsDir = path.join(process.cwd(), 'packages', 'datadog-instrumentations')
    this.hooksRegistryPath = path.join(
      process.cwd(), 'packages', 'datadog-instrumentations', 'src', 'helpers', 'hooks.js'
    )
  }

  async updateHooksRegistry () {
    const uniqueModules = getUniqueModules(this.analysis, this.integrationName)
    let content = await fs.readFile(this.hooksRegistryPath, 'utf8')

    for (const moduleName of uniqueModules) {
      content = await this._addHookEntry(content, moduleName)
    }

    await fs.writeFile(this.hooksRegistryPath, content)
    console.log(`✅ Updated hooks registry with ${uniqueModules.length} module(s): ${uniqueModules.join(', ')}`)
  }

  async _addHookEntry (content, moduleName) {
    // Check if hook already exists
    if (content.includes(`'${moduleName}':`) || content.includes(`${moduleName}:`)) {
      console.log(`Hook for '${moduleName}' already exists in the registry. Skipping.`)
      return content
    }

    const lines = content.split('\n')
    const key = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(moduleName) ? moduleName : `'${moduleName}'`

    // Check if this is an ESM module - requires esmFirst: true for proper hook registration
    const moduleType = this.analysis.module_type || 'commonjs'
    const isEsm = moduleType === 'esm' || moduleType === 'dual'

    // All hook entries point to the same instrumentation file (named after the integration)
    // Use normalized name for file path (e.g., @scope/pkg -> scope-pkg)
    const normalizedName = normalizePackageName(this.integrationName)
    const newEntry = isEsm
      ? `  ${key}: { esmFirst: true, fn: () => require('../${normalizedName}') },`
      : `  ${key}: () => require('../${normalizedName}'),`

    // Find where module.exports starts
    const exportsIndex = lines.findIndex(line => line.trim().startsWith('module.exports'))
    if (exportsIndex === -1) {
      throw new Error('Could not find "module.exports" in hooks registry.')
    }

    // Helper to check if a line is a hook entry (either simple or esmFirst format)
    const isHookEntry = (line) => line.includes(': () => require') || line.includes(': { esmFirst:')

    // Find the first hook definition line
    let insertionIndex = -1
    for (let i = exportsIndex; i < lines.length; i++) {
      if (isHookEntry(lines[i])) {
        insertionIndex = i
        break
      }
    }

    if (insertionIndex === -1) {
      // No hooks yet, find the opening brace and insert after it.
      const openBraceIndex = lines.findIndex(line => line.includes('{'), exportsIndex)
      if (openBraceIndex === -1) {
        throw new Error('Could not find opening brace in module.exports in hooks registry.')
      }
      insertionIndex = openBraceIndex + 1
    } else {
      // Find the correct alphabetical position to insert the new hook
      while (
        insertionIndex < lines.length &&
        isHookEntry(lines[insertionIndex]) &&
        lines[insertionIndex].trim().split(':')[0].replace(/['"]/g, '') < moduleName
      ) {
        insertionIndex++
      }
    }

    lines.splice(insertionIndex, 0, newEntry)
    console.log(`  Added hook for '${moduleName}'`)

    return lines.join('\n')
  }
}

module.exports = { HooksGenerator }
