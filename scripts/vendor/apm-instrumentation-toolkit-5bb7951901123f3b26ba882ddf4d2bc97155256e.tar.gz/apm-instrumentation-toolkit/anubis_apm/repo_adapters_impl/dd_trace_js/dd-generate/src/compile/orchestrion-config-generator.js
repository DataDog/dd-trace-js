'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')

class OrchestrionConfigGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    // Normalize package name for filename (e.g., @scope/pkg -> scope-pkg)
    this.normalizedName = integrationName.replace('@', '').replace('/', '-')
  }

  async generate () {
    const config = this._convertToOrchestrionFormat()
    const filePath = path.join(
      process.cwd(),
      'packages',
      'datadog-instrumentations',
      'src',
      'helpers',
      'rewriter',
      'instrumentations',
      `${this.normalizedName}.js`
    )

    // Generate JS module format matching langchain.js style
    // Convert JSON to JS object literal: unquoted keys, single-quoted strings
    const jsLiteral = JSON.stringify(config, null, 2)
      .replace(/"([^"]+)":/g, '$1:') // Unquote keys
      .replace(/: "([^"]*)"/g, ": '$1'") // Double quotes to single quotes for values

    const jsContent = `'use strict'

module.exports = ${jsLiteral}
`
    await fs.writeFile(filePath, jsContent)
    console.log(`✅ Generated orchestrion config: ${filePath}`)

    await this._updateIndexFile()
  }

  async _updateIndexFile () {
    const indexPath = path.join(
      process.cwd(),
      'packages',
      'datadog-instrumentations',
      'src',
      'helpers',
      'rewriter',
      'instrumentations',
      'index.js'
    )

    try {
      let content = await fs.readFile(indexPath, 'utf-8')
      const requireStatement = `...require('./${this.normalizedName}')`

      if (content.includes(this.normalizedName)) {
        console.log(`✅ Index already includes ${this.normalizedName}`)
        return
      }

      // Insert before closing bracket, handling trailing comma on previous line
      content = content.replace(
        /(,?)\n\]/,
        `,\n  ${requireStatement}\n]`
      )

      await fs.writeFile(indexPath, content)
      console.log(`✅ Updated index.js to include ${this.normalizedName}`)
    } catch (e) {
      console.log(`⚠️  Could not update index.js: ${e.message}`)
    }
  }

  _convertToOrchestrionFormat () {
    const instrumentations = this.analysis.orchestrion_config?.instrumentations || []

    // Expand instrumentations with file_paths into multiple entries (one per file path)
    return instrumentations.flatMap(instr => {
      const filePaths = instr.file_paths || []

      // If file_paths array exists and has entries, generate one entry per file path
      if (filePaths.length > 0) {
        return filePaths.map(fp => this._convertInstrumentation(instr, fp.path))
      }

      // Fall back to single file_path field
      return [this._convertInstrumentation(instr, instr.file_path)]
    })
  }

  _convertInstrumentation (instr, filePath) {
    const {
      module_name: moduleName,
      version_range: versionRange,
      function_query: functionQuery,
      operator
    } = instr

    // Determine kind from function_query.kind or operator
    // Check async_iterator first before checking operator
    let kind = 'Sync'
    if (functionQuery?.kind === 'async_iterator') {
      kind = 'AsyncIterator'
    } else if (operator === 'tracePromise' || functionQuery?.kind === 'async') {
      kind = 'Async'
    }

    // Generate channel name in orchestrion format: ClassName_methodName
    const className = functionQuery?.class || ''
    const methodName = functionQuery?.name || ''
    const channelName = className ? `${className}_${methodName}` : methodName

    // Determine actual module name from file_path (may be a dependency)
    const { targetModule, targetFilePath } = this._extractModuleFromPath(moduleName, filePath)

    const result = {
      module: {
        name: targetModule
      },
      functionQuery: {
        methodName
      },
      channelName
    }

    // Add optional fields
    if (versionRange) {
      // Convert semver range format: ^4.0.0 -> >=4.0.0, ~4.0.0 -> >=4.0.0
      result.module.versionRange = this._convertVersionRange(versionRange)
    }

    if (targetFilePath) {
      result.module.filePath = targetFilePath
    }

    if (className) {
      result.functionQuery.className = className
    }

    result.functionQuery.kind = kind

    return result
  }

  _convertVersionRange (range) {
    // Convert npm semver to orchestrion format
    // ^4.0.0 -> >=4.0.0
    // ~4.0.0 -> >=4.0.0
    // >=4.0.0 -> >=4.0.0
    // * -> * (keep as-is)
    if (range.startsWith('^') || range.startsWith('~')) {
      return '>=' + range.slice(1)
    }
    return range
  }

  _extractModuleFromPath (defaultModule, filePath) {
    // Extract actual module name from file_path when it points to a dependency
    // Supports formats:
    //   - node_modules/package-name/lib/file.js
    //   - ../package-name/lib/file.js (relative to main package)
    //   - lib/file.js (within same package)

    if (!filePath) {
      return { targetModule: defaultModule, targetFilePath: null }
    }

    let targetModule = defaultModule
    let targetFilePath = filePath

    if (filePath.startsWith('node_modules/')) {
      // Format: node_modules/package-name/lib/file.js
      const parts = filePath.replace('node_modules/', '').split('/')
      if (parts[0].startsWith('@')) {
        // Scoped package: @scope/package
        targetModule = parts.slice(0, 2).join('/')
        targetFilePath = parts.slice(2).join('/')
      } else {
        targetModule = parts[0]
        targetFilePath = parts.slice(1).join('/')
      }
    } else if (filePath.startsWith('../')) {
      // Format: ../package-name/lib/file.js (relative to main package)
      const parts = filePath.replace('../', '').split('/')
      if (parts[0].startsWith('@')) {
        // Scoped package: @scope/package
        targetModule = parts.slice(0, 2).join('/')
        targetFilePath = parts.slice(2).join('/')
      } else {
        targetModule = parts[0]
        targetFilePath = parts.slice(1).join('/')
      }
    }

    return { targetModule, targetFilePath }
  }
}

module.exports = { OrchestrionConfigGenerator }
