'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { sanitizeClassName, toValidIdentifier, toPascalCase, generateTagExtraction } = require('./utils')
const { getBasePlugin, usesSchemaBasedNaming, normalizeCategory } = require('../../../shared/constants')
const { loadTemplate, render } = require('./templates')

class PluginCodeGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    // Normalize package name for directory paths (e.g., @scope/pkg -> scope-pkg)
    this.normalizedName = integrationName.replace('@', '').replace('/', '-')
    this.pluginDir = path.join(process.cwd(), 'packages', `datadog-plugin-${this.normalizedName}`)
  }

  async generate () {
    const spanKinds = this._getSpanKinds()

    if (spanKinds.length === 0) {
      console.log('⚠️  No span_kinds found, skipping plugin generation')
      return
    }

    const indexPath = path.join(this.pluginDir, 'src', 'index.js')

    // Check if any span_kind has multiple targets
    const hasMultipleTargets = spanKinds.some(spanKind => {
      const instrumentations = this._getInstrumentationsForSpanKind(spanKind)
      return instrumentations.length > 1
    })

    if (spanKinds.length === 1 && !hasMultipleTargets) {
      // Single span_kind with single target: put implementation directly in index.js
      await this._generateIndexFile(spanKinds)
      console.log(`✅ Generated plugin file for ${spanKinds[0]} span_kind: ${indexPath}`)
    } else {
      // Multiple span_kinds OR multiple targets: generate separate files + composite/array
      for (const spanKind of spanKinds) {
        await this._generateSpanKindPlugin(spanKind)
      }
      await this._generateIndexFile(spanKinds)
      console.log(`✅ Generated plugin files for ${spanKinds.join(', ')} span_kinds: ${indexPath}`)
    }
  }

  _getSpanKinds () {
    const instrumentations = this.analysis.orchestrion_config?.instrumentations || []
    return [...new Set(instrumentations.map(i => i.span_kind).filter(Boolean))]
  }

  async _generateSpanKindPlugin (spanKind) {
    const content = this._generateSpanKindPluginCode(spanKind)
    const fileName = `${spanKind}.js`
    const filePath = path.join(this.pluginDir, 'src', fileName)
    await fs.writeFile(filePath, content)
    console.log(`✅ Generated ${filePath}`)
  }

  _generateSpanKindPluginCode (spanKind) {
    const basePlugin = this._getBasePluginForSpanKind(spanKind, this.analysis.category)
    const basePluginImportPath = this._getBasePluginImportPath(basePlugin)
    const instrumentations = this._getInstrumentationsForSpanKind(spanKind)

    if (instrumentations.length === 1) {
      // Single instrumentation: generate single class
      const instr = instrumentations[0]
      const className = `${toPascalCase(this.integrationName)}${toPascalCase(spanKind)}Plugin`
      const prefix = this._getChannelPrefix(instr)
      const bindStartMethod = this._generateBindStartMethod(instr)

      const template = loadTemplate('span-kind-plugin')
      return render(template, {
        basePlugin,
        basePluginImportPath,
        className,
        packageName: this.normalizedName,
        prefix,
        bindStartMethod
      })
    }

    // Multiple instrumentations: langchain pattern (base class + subclasses + dict export)
    return this._generateMultiTargetPluginCode(spanKind, basePlugin, basePluginImportPath, instrumentations)
  }

  _generateMultiTargetPluginCode (spanKind, basePlugin, basePluginImportPath, instrumentations) {
    const baseClassName = `Base${toPascalCase(this.integrationName)}${toPascalCase(spanKind)}Plugin`
    const firstInstr = instrumentations[0]
    const basePrefix = this._getChannelPrefix(firstInstr)
    const bindStartMethod = this._generateBindStartMethod(firstInstr)

    // Generate subclasses for remaining instrumentations (skip first, it uses base class directly)
    const subclasses = []
    const classNames = [baseClassName] // Base class is first in exports

    for (let i = 1; i < instrumentations.length; i++) {
      const instr = instrumentations[i]
      const className = this._getSubclassName(instr)
      classNames.push(className)
      const prefix = this._getChannelPrefix(instr)

      subclasses.push(`class ${className} extends ${baseClassName} {
  static prefix = '${prefix}'
}`)
    }

    const template = loadTemplate('span-kind-plugin')
    const baseClassCode = render(template, {
      basePlugin,
      basePluginImportPath,
      className: baseClassName,
      packageName: this.normalizedName,
      prefix: basePrefix,
      bindStartMethod
    })

    // Replace single export with base class + subclasses + dict export
    // Dict keys are plugin class names as strings for CompositePlugin consumption
    // Handle trailing newline after export statement
    const baseWithoutExport = baseClassCode.replace(/\nmodule\.exports = [^\n]+\n?$/, '')

    const subclassesStr = subclasses.length > 0 ? `${subclasses.join('\n\n')}\n` : ''

    // Build dict entries: { 'ClassName': ClassName, ... }
    const dictEntries = classNames.map(name => `  '${name}': ${name}`).join(',\n')

    return `${baseWithoutExport}
${subclassesStr}
module.exports = {
${dictEntries}
}
`
  }

  _getSubclassName (instr) {
    const className = sanitizeClassName(instr.function_query?.class || '')
    const methodName = instr.function_query?.name || this.integrationName
    const sanitizedClassName = toValidIdentifier(className)
    // If no class name, just use method name; otherwise use both
    if (!sanitizedClassName) {
      return `${toPascalCase(methodName)}Plugin`
    }
    return `${toPascalCase(sanitizedClassName)}${toPascalCase(methodName)}Plugin`
  }

  _getChannelPrefix (instr) {
    const moduleName = instr.module_name
    const className = instr.function_query?.class || ''
    const methodName = instr.function_query?.name || ''
    const channelName = className ? `${className}_${methodName}` : methodName
    return `tracing:orchestrion:${moduleName}:${channelName}`
  }

  _getBasePluginForSpanKind (spanKind, category) {
    // Use centralized constants for category-to-plugin mapping
    // This handles normalization (e.g., web-server -> http-server) and span_kind fallback
    return getBasePlugin(category, spanKind) || 'TracingPlugin'
  }

  _getBasePluginImportPath (basePlugin) {
    // Map base plugin class name to its import path
    const importPaths = {
      LogPlugin: '../../dd-trace/src/plugins/log_plugin',
      CachePlugin: '../../dd-trace/src/plugins/cache',
      DatabasePlugin: '../../dd-trace/src/plugins/database',
      StoragePlugin: '../../dd-trace/src/plugins/storage',
      ClientPlugin: '../../dd-trace/src/plugins/client',
      ServerPlugin: '../../dd-trace/src/plugins/server',
      ProducerPlugin: '../../dd-trace/src/plugins/producer',
      ConsumerPlugin: '../../dd-trace/src/plugins/consumer',
      TracingPlugin: '../../dd-trace/src/plugins/tracing',
      HttpClientPlugin: '../../datadog-plugin-http/src/client'
    }

    return importPaths[basePlugin] || '../../dd-trace/src/plugins/tracing'
  }

  _getInstrumentationsForSpanKind (spanKind) {
    return this.analysis.orchestrion_config.instrumentations.filter(i => i.span_kind === spanKind)
  }

  _generateBindStartMethod (instr) {
    const category = normalizeCategory(this.analysis.category)

    // For schema-based categories, the base plugin handles operation naming
    // Call startSpan(options, ctx) instead of startSpan(name, options, ctx)
    if (usesSchemaBasedNaming(category)) {
      return `  bindStart (ctx) {
    const meta = this.getTags(ctx)

    this.startSpan({
      meta
    }, ctx)

    return ctx.currentStore
  }

${this._generateGetTagsMethod(instr)}`
    }

    // For non-schema categories, pass explicit operation name
    const methodName = instr.function_query?.name || 'request'
    const spanName = instr.operation
      ? `'${instr.operation}'`
      : `\`\${this.constructor.id}.${methodName}\``

    return `  bindStart (ctx) {
    const meta = this.getTags(ctx)

    this.startSpan(${spanName}, {
      service: this.serviceName({ pluginService: this.config.service }),
      meta
    }, ctx)

    return ctx.currentStore
  }

${this._generateGetTagsMethod(instr)}`
  }

  _generateGetTagsMethod (instr) {
    const contextCapture = instr.context_capture || {}
    const spanKind = instr.span_kind || 'client'

    // Generate meta tags
    const metaTags = []
    metaTags.push({ tag: 'component', code: `'${this.integrationName}'` })
    metaTags.push({ tag: 'span.kind', code: `'${spanKind}'` })

    const seenTags = new Set(['component', 'span.kind'])
    for (const [tagName, mapping] of Object.entries(contextCapture)) {
      const extraction = generateTagExtraction(tagName, mapping)
      if (extraction !== null && !seenTags.has(tagName)) {
        metaTags.push(extraction)
        seenTags.add(tagName)
      }
    }

    // Only quote keys that need it (contain special chars like dots)
    const formatKey = (key) => /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(key) ? key : `'${key}'`
    const metaLines = metaTags.map(e => `      ${formatKey(e.tag)}: ${e.code}`).join(',\n')

    return `  getTags (ctx) {
    return {
${metaLines}
    }
  }`
  }

  async _generateIndexFile (spanKinds) {
    let content

    // Check if any span_kind has multiple targets
    const hasMultipleTargets = spanKinds.some(spanKind => {
      const instrumentations = this._getInstrumentationsForSpanKind(spanKind)
      return instrumentations.length > 1
    })

    if (spanKinds.length === 1 && !hasMultipleTargets) {
      // Single span_kind with single target: generate full plugin implementation in index.js
      const spanKind = spanKinds[0]
      content = this._generateSpanKindPluginCode(spanKind)
    } else {
      // Multiple span_kinds OR multiple targets: create composite
      const imports = spanKinds.map(spanKind => {
        const varName = `${spanKind}Plugin`
        return `const ${varName} = require('./${spanKind}')`
      }).join('\n')

      // Build plugin entries
      // For span_kinds with multiple targets, the import is a dict - spread it
      // For single target span_kinds, use key: value format
      const pluginEntries = spanKinds.map(spanKind => {
        const varName = `${spanKind}Plugin`
        const instrumentations = this._getInstrumentationsForSpanKind(spanKind)
        if (instrumentations.length > 1) {
          // Dict export - spread it into the plugins object
          return `    ...${varName}`
        }
        // Single class export - use as value
        return `    ${spanKind}: ${varName}`
      }).join(',\n')

      const compositeClassName = `${toPascalCase(this.integrationName)}Plugin`

      const template = loadTemplate('composite-index')
      content = render(template, {
        imports,
        compositeClassName,
        packageName: this.normalizedName,
        pluginEntries
      })
    }

    const filePath = path.join(this.pluginDir, 'src', 'index.js')
    await fs.writeFile(filePath, content)
  }
}

module.exports = { PluginCodeGenerator }
