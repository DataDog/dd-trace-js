'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { FILE_GENERATORS, INSERTION_POINTS } = require('../file-specifications')
const { getSchemaInfo, usesSchemaBasedNaming, normalizeCategory } = require('../../../shared/constants')

/**
 * Schema Generator
 *
 * Adds entries to service naming schema files for categories that use
 * schema-based operation naming (storage, messaging, web, etc.).
 * Updates both v0 and v1 schema directories.
 */

class SchemaGenerator {
  constructor (integrationName, analysis) {
    this.integrationName = integrationName
    this.analysis = analysis
    this.category = normalizeCategory(analysis.category)
    this.schemaBaseDir = path.join(process.cwd(), 'packages', 'dd-trace', 'src', 'service-naming', 'schemas')
  }

  async generate () {
    if (!usesSchemaBasedNaming(this.category)) {
      console.log(`ℹ️  Category '${this.category}' does not use schema-based naming, skipping schema generation`)
      return
    }

    const schemaInfo = getSchemaInfo(this.category)
    if (!schemaInfo) {
      console.log(`⚠️  No schema info found for category '${this.category}'`)
      return
    }

    // Get span_kinds from analysis
    const spanKinds = this._getSpanKinds()
    if (spanKinds.length === 0) {
      console.log(`⚠️  No span_kinds found in analysis, skipping schema generation`)
      return
    }

    // Update both v0 and v1 schema files
    const versions = ['v0', 'v1']
    const updatedPaths = []

    for (const version of versions) {
      const schemaPath = path.join(this.schemaBaseDir, version, schemaInfo.file)

      // Check if file exists
      try {
        await fs.access(schemaPath)
      } catch {
        console.log(`⚠️  Schema file not found: ${schemaPath}`)
        continue
      }

      // Check if entry already exists
      const content = await fs.readFile(schemaPath, 'utf-8')
      if (content.includes(`'${this.integrationName}':`)) {
        console.log(`✓ Schema entry already exists for ${this.integrationName} in ${version}/${schemaInfo.file}`)
        continue
      }

      // Generate and insert entries for each span_kind
      let updatedContent = content
      for (const spanKind of spanKinds) {
        updatedContent = this._addSchemaEntry(updatedContent, spanKind, version)
      }

      if (updatedContent !== content) {
        await fs.writeFile(schemaPath, updatedContent)
        console.log(`✅ Updated schema file: ${schemaPath}`)
        updatedPaths.push(schemaPath)
      }
    }

    return updatedPaths
  }

  _getSpanKinds () {
    const instrumentations = this.analysis.orchestrion_config?.instrumentations || []
    return [...new Set(instrumentations.map(i => i.span_kind).filter(Boolean))]
  }

  _addSchemaEntry (content, spanKind, version) {
    // Generate the entry code
    const entry = FILE_GENERATORS.generateSchemaEntry(this.integrationName, this.category, spanKind)

    // Find the insertion point within the span_kind section
    const insertionPoint = INSERTION_POINTS.findSchemaInsertionPoint(content, this.integrationName, spanKind)

    if (!insertionPoint.sectionFound) {
      console.log(`  ⚠️  Could not find '${spanKind}' section in ${version} schema file`)
      return content
    }

    // Insert the entry
    const lines = content.split('\n')

    // Check if we need a comma after the new entry (not last in section)
    const nextLine = lines[insertionPoint.lineIndex]?.trim()
    const needsComma = nextLine && !nextLine.startsWith('}')

    // Check if previous entry needs a comma
    const prevLineIndex = insertionPoint.lineIndex - 1
    const prevLine = lines[prevLineIndex]?.trim()
    const prevNeedsComma = prevLine && !prevLine.endsWith(',') && !prevLine.endsWith('{')

    if (prevNeedsComma) {
      lines[prevLineIndex] = lines[prevLineIndex].replace(/(\s*)$/, ',$1')
    }

    const entryWithComma = needsComma ? entry + ',' : entry
    lines.splice(insertionPoint.lineIndex, 0, entryWithComma)

    console.log(`  ✓ Added ${this.integrationName} entry to ${spanKind} section (${version})`)
    return lines.join('\n')
  }
}

module.exports = { SchemaGenerator }
