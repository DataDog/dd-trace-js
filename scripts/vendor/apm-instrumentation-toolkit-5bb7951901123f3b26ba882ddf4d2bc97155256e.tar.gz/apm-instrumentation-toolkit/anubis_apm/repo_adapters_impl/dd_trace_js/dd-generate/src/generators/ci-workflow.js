'use strict'

/* eslint-disable no-console */

const fs = require('fs').promises
const path = require('path')
const { FILE_GENERATORS, INSERTION_POINTS } = require('../file-specifications')

/**
 * CI Workflow Generator
 * Updates .github/workflows/apm-integrations.yml with new test job
 *
 * V5: Reads required services from .analysis/{package}/services/required-services.json
 */

async function updateCIWorkflow (repoRoot, integrationName, category) {
  const filePath = `${repoRoot}/.github/workflows/apm-integrations.yml`
  const content = await fs.readFile(filePath, 'utf-8')

  // Check if job already exists
  if (content.includes(`  ${integrationName}:`)) {
    console.log(`✓ CI workflow already includes ${integrationName} job`)
    return filePath
  }

  // Read ci-requirements.json from artifacts directory for complete job config
  let jobContent
  try {
    // New path: artifacts directory (from anubis workflow)
    const ciRequirementsFile = process.env.CI_REQUIREMENTS_PATH
    const ciRequirementsContent = await fs.readFile(ciRequirementsFile, 'utf-8')
    const ciRequirements = JSON.parse(ciRequirementsContent)

    // Use the complete config_snippet from ci-requirements.json
    // This includes actual Docker service configs from docker-compose.yml
    if (ciRequirements.config_snippet) {
      jobContent = ciRequirements.config_snippet
      console.log(`  ✓ Using complete CI config with ${ciRequirements.required_services?.length || 0} service(s)`)
    } else {
      throw new Error('No config_snippet in ci-requirements.json')
    }
  } catch (e) {
    console.log(`  ⚠️  Could not read ci-requirements.json: ${e.message}`)
    console.log('  ℹ️  Falling back to basic job generation (no services)')

    // No ci-requirements artifact - generate basic job without services
    jobContent = FILE_GENERATORS.generateCIJob(integrationName, category, [])
  }

  const insertionPoint = INSERTION_POINTS.findCIInsertionPoint(content, integrationName)

  const lines = content.split('\n')
  const jobLines = jobContent.split('\n')

  // Insert the job at the correct alphabetical position
  lines.splice(insertionPoint.lineIndex, 0, ...jobLines)

  const newContent = lines.join('\n')
  await fs.writeFile(filePath, newContent)

  console.log(`✓ Updated CI workflow: ${integrationName} job added`)
  return filePath
}

module.exports = {
  updateCIWorkflow
}
