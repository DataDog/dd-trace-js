#!/usr/bin/env node
/* eslint-disable no-console */

'use strict'

/**
 * APM Integration Scaffolder v3 (Bare)
 *
 * Purpose: Generate the minimal foundational file structure for a new integration.
 * Input: Integration name
 * Output: Plugin directory, package.json, and updates to repo-level files (CI, docs, etc.)
 */

// Import file generators
const { createPluginPackage } = require('./generators/plugin-package')
const { updateDocumentationFiles } = require('./generators/documentation')
const { updateCIWorkflow } = require('./generators/ci-workflow')
const { updateVersionsRegistry } = require('./generators/versions-registry')
const { updateSupportedConfigurations } = require('./generators/supported-configs')
const { updateExternals } = require('./generators/externals')
const { normalizePackageName } = require('./compile/utils')

class IntegrationScaffolder {
  constructor (integrationName) {
    // Normalize the integration name for file paths, CI jobs, class names, etc.
    // e.g., '@anthropic-ai/claude-agent-sdk' -> 'anthropic-ai-claude-agent-sdk'
    this.integrationName = normalizePackageName(integrationName)
    // Keep original package name for npm-related references (versions registry, externals)
    this.packageName = integrationName
    this.outputDir = null
    this.generatedFiles = []
  }

  async scaffold () {
    console.log(`🏗️  Scaffolding bare integration: ${this.integrationName}`)

    try {
      // V5: Use process.cwd() which is set by the Python caller to the repo root
      // The Python script runs this with cwd=locations.repo_root (dd-trace-js)
      this.outputDir = process.cwd()

      await this.generateFileStructure()

      console.log('✅ Bare integration scaffolded successfully.')
    } catch (error) {
      console.error('❌ Scaffolding failed:', error.message)
      throw error
    }
  }

  async generateFileStructure () {
    try {
      // V5: Read analysis file from .analysis/ directory
      const fs = require('fs').promises
      const analysisPath = process.env.ANALYSIS_PATH
      let analysis = { category: 'library' }

      try {
        const analysisContent = await fs.readFile(analysisPath, 'utf8')
        analysis = JSON.parse(analysisContent)
      } catch (e) {
        console.warn(`⚠️  Could not read analysis file from ${analysisPath}`)
        throw new Error(`Analysis file required: ${analysisPath}`)
      }

      console.log('📝 Creating plugin package structure...')
      await createPluginPackage(this.outputDir, this.integrationName, this.packageName, analysis)

      console.log('📝 Updating documentation files...')
      await updateDocumentationFiles(this.outputDir, this.integrationName, this.packageName, analysis)

      console.log('📝 Updating CI workflow...')
      await updateCIWorkflow(this.outputDir, this.integrationName, analysis.category)

      console.log('📝 Updating versions registry...')
      const packageVersion = analysis.package?.version || 'latest'
      await updateVersionsRegistry(this.outputDir, this.packageName, packageVersion, analysis)

      console.log('📝 Updating externals for sub-packages...')
      await updateExternals(this.outputDir, this.packageName, analysis)

      console.log('📝 Updating supported configurations...')
      await updateSupportedConfigurations(this.outputDir, this.integrationName)

      // V5: Generate actual instrumentation code using dd-compile
      console.log('📝 Generating instrumentation code (dd-compile)...')
      await this.compileInstrumentation()
    } catch (error) {
      console.error(`❌ File generation failed: ${error.message}`)
      throw error
    }
  }

  async compileInstrumentation () {
    const Compiler = require('./compile/index')
    const compiler = new Compiler(this.integrationName)

    const originalCwd = process.cwd()
    process.chdir(this.outputDir)

    await compiler.main()

    process.chdir(originalCwd)

    console.log('✅ Instrumentation code generated successfully')
  }
}

// CLI Interface
async function main () {
  const integrationName = process.argv[2]

  if (!integrationName) {
    console.error('Usage: dd-scaffold <integration-name>')
    console.error('')
    console.error('This will automatically:')
    console.error('  • Generate the basic integration file structure')
    console.error('  • Update documentation, CI, and other repository files')
    process.exit(1)
  }

  try {
    const scaffolder = new IntegrationScaffolder(integrationName)
    await scaffolder.scaffold()
  } catch (error) {
    process.exit(1)
  }
}

main()

module.exports = { IntegrationScaffolder }
