# dd-trace-java Adapter Implementation

Java analysis works from Maven artifacts rather than a package-manager install
tree. The adapter expects Maven coordinates (`group:artifact:version`) when it
needs third-party library bytecode.

## Static Analysis

- `dd_analyze/src/analyzers/extract_all_methods.py` extracts public methods
  from a binary JAR using `jar` and `javap`.
- `dd_analyze/src/analyzers/find_function.py` locates target classes/methods in
  unpacked Java source when sources are available.
- `JavaRepoAdapter.install_package()` downloads the binary JAR and then
  best-effort downloads/unpacks the `-sources.jar` for source-path enrichment.

If Java method extraction returns zero methods, first verify that Maven
coordinates were supplied and that the selected package path is the binary JAR,
not a `-sources.jar` or `-javadoc.jar` classifier.
