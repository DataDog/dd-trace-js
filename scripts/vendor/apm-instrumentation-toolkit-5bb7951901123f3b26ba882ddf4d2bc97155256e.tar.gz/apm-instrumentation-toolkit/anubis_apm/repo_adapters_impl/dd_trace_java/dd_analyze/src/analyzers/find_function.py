#!/usr/bin/env python3
"""Find a specific method in a Java JAR using javap.

This analyzer locates a named method (optionally filtered by class) within
a compiled JAR file.  It uses the same javap-based extraction as
extract_all_methods.py but filters down to a single target, returning file/line
as null (compiled JARs carry no source file or line-number information unless
a -g:source,lines class was compiled with debug info, which is unusual for
released artifacts).

Usage:
    python find_function.py <jar_path> <method_name> [--class <class_name>]
    python find_function.py <group>:<artifact>:<version> <method_name> [--class <class_name>]
    python find_function.py maven:<group>:<artifact>:<version> <method_name> [--class <class_name>]

Example:
    python find_function.py /path/to/jedis-1.4.0.jar get --class Jedis
    python find_function.py redis.clients:jedis:1.4.0 set
    python find_function.py maven:redis.clients:jedis:1.4.0 set
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# Reuse the JAR download + extraction logic from the sibling script
_HERE = Path(__file__).parent
sys.path.insert(0, str(_HERE))
from extract_all_methods import JavaMethodExtractor, download_maven_jar  # noqa: E402


def find_method_in_jar(
    jar_path: Path,
    method_name: str,
    class_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Find all occurrences of a method name in a JAR.

    When class_name is supplied, only classes whose fully-qualified name ends
    with the given class name are passed to javap, avoiding the cost of
    decompiling every class in the JAR.

    Args:
        jar_path: Path to the compiled JAR file
        method_name: Name of the method to search for
        class_name: Optional fully-qualified or simple class name to restrict search

    Returns:
        List of match dicts with keys: name, class, signature, modifiers,
        return_type, file (always null), line (always null)
    """
    extractor = JavaMethodExtractor(jar_path)
    all_class_names = extractor.extract_classes()

    # If a class filter is given, narrow to matching classes before running javap
    if class_name:
        candidate_classes = [
            c for c in all_class_names if c == class_name or c.endswith(f".{class_name}")
        ]
    else:
        candidate_classes = all_class_names

    matches = []
    for cls in candidate_classes:
        class_info = extractor.extract_methods(cls)
        if not class_info:
            continue
        for method in class_info["methods"]:
            if method["name"] == method_name:
                matches.append({
                    **method,
                    "file": None,
                    "line": None,
                })

    return matches


def main() -> int:
    parser = argparse.ArgumentParser(description="Find a method in a Java JAR file")
    parser.add_argument(
        "jar_or_maven",
        help="Path to JAR or Maven coordinates (maven:group:artifact:version)",
    )
    parser.add_argument("method_name", help="Method name to search for")
    parser.add_argument("--class", dest="class_name", default=None, help="Filter by class name")

    args = parser.parse_args()

    arg = args.jar_or_maven

    # Accept "maven:group:artifact:version" (legacy) or plain "group:artifact:version"
    if arg.startswith("maven:"):
        coord_str = arg[len("maven:") :]
    else:
        coord_str = arg

    coord_parts = coord_str.split(":")
    if len(coord_parts) == 3:
        group_id, artifact_id, version = coord_parts
        try:
            jar_path = download_maven_jar(group_id, artifact_id, version)
        except (subprocess.TimeoutExpired, RuntimeError) as e:
            print(f"Error downloading JAR: {e}", file=sys.stderr)
            return 1
    else:
        jar_path = Path(arg)

    try:
        results = find_method_in_jar(jar_path, args.method_name, args.class_name)
        print(json.dumps(results, indent=2))
        return 0
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error finding method: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
