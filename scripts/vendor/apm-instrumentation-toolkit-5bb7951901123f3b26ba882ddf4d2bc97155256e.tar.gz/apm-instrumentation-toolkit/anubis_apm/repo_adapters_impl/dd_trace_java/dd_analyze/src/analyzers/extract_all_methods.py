#!/usr/bin/env python3
"""Extract all public methods from Java JARs using javap.

This analyzer extracts all public methods from classes in a JAR file
to identify potential instrumentation targets for dd-trace-java.

Usage:
    python extract_all_methods.py <jar-path> [--output <output-file>]
    python extract_all_methods.py <group>:<artifact>:<version> [--output <output-file>]
    python extract_all_methods.py maven:<group>:<artifact>:<version> [--output <output-file>]

Example:
    python extract_all_methods.py /path/to/okhttp-3.14.9.jar --output methods.json
    python extract_all_methods.py com.squareup.okhttp3:okhttp:3.14.9
    python extract_all_methods.py maven:com.squareup.okhttp3:okhttp:3.14.9
"""

import argparse
import json
import subprocess
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional


class JavaMethodExtractor:
    """Extracts public methods from JAR files using javap."""

    _GENERATED_INNER_CLASS_NAMES = {"Companion", "DefaultImpls", "WhenMappings"}

    def __init__(self, jar_path: Path):
        """Initialize extractor with JAR file path.

        Args:
            jar_path: Path to the JAR file to analyze
        """
        self.jar_path = jar_path
        if not jar_path.exists():
            raise FileNotFoundError(f"JAR file not found: {jar_path}")

    def extract_classes(self) -> List[str]:
        """Extract list of .class files from JAR.

        Returns:
            List of class names (e.g., ['com/example/Foo.class'])
        """
        result = subprocess.run(
            ["jar", "tf", str(self.jar_path)],
            capture_output=True,
            text=True,
            check=True,
        )

        # Filter to useful .class files. Include named member classes because
        # dd-trace-java often instruments them (for example Foo$WithRawResponseImpl),
        # but skip common compiler-generated inner classes that explode generated
        # SDK inventories without adding stable hook points.
        classes = []
        for line in result.stdout.strip().split("\n"):
            if line.endswith(".class") and not line.endswith("module-info.class"):
                # Convert path to class name
                class_name = line[:-6].replace("/", ".")
                if self._should_include_class(class_name):
                    classes.append(class_name)

        return sorted(classes)

    def _should_include_class(self, class_name: str) -> bool:
        """Return whether a class is useful for public API/method inventory."""
        if "$" not in class_name:
            return True
        if "$$inlined$" in class_name:
            return False
        for inner_name in class_name.split("$")[1:]:
            if not inner_name:
                return False
            if inner_name[0].isdigit():
                return False
            if inner_name[0].islower():
                return False
            if inner_name in self._GENERATED_INNER_CLASS_NAMES:
                return False
        return True

    def extract_methods(self, class_name: str) -> Optional[Dict[str, Any]]:
        """Extract public methods from a class using javap.

        Args:
            class_name: Fully qualified class name (e.g., 'com.example.Foo')

        Returns:
            Dictionary with class info and methods, or None if extraction fails
        """
        try:
            # Run javap with -public (public members only) and -s (signatures)
            result = subprocess.run(
                ["javap", "-public", "-s", "-classpath", str(self.jar_path), class_name],
                capture_output=True,
                text=True,
                check=True,
                timeout=30,
            )

            output = result.stdout
            class_kind, class_modifiers = self._parse_class_header(output, class_name)
            methods = self._parse_javap_output(
                output,
                class_name,
                class_kind=class_kind,
                class_modifiers=class_modifiers,
            )

            if not methods:
                return None  # No public methods

            return {"name": class_name, "methods": methods}

        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            # Skip classes that can't be decompiled (likely internal/generated)
            return None

    def _parse_class_header(self, output: str, class_name: str) -> tuple[str, List[str]]:
        """Parse javap's class declaration line."""
        class_kind = "class"
        modifiers: List[str] = []

        for raw_line in output.split("\n"):
            line = raw_line.strip()
            if not line.startswith("public "):
                continue
            if class_name not in line:
                continue

            header = line.rstrip("{").strip()
            tokens = header.split()
            for token in ("public", "abstract", "final", "static"):
                if token in tokens:
                    modifiers.append(token)
            if "@interface" in tokens:
                class_kind = "annotation"
            elif "interface" in tokens:
                class_kind = "interface"
            elif "enum" in tokens:
                class_kind = "enum"
            elif "record" in tokens:
                class_kind = "record"
            break

        return class_kind, modifiers

    def _parse_javap_output(
        self,
        output: str,
        class_name: str,
        class_kind: str,
        class_modifiers: List[str],
    ) -> List[Dict[str, Any]]:
        """Parse javap output to extract method information.

        Args:
            output: javap command output
            class_name: Class being analyzed

        Returns:
            List of method dictionaries
        """
        methods = []
        lines = output.split("\n")

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            parsed = self._parse_method_line(line, class_name)
            if parsed:
                method_name = parsed["name"]
                return_type = parsed["return_type"]
                modifiers = parsed["modifiers"]
                parameters = parsed["parameters"]
                throws = parsed["throws"]

                # Look for the signature line (descriptor: ...)
                descriptor = None
                for j in range(i + 1, min(i + 3, len(lines))):
                    sig_line = lines[j].strip()
                    if sig_line.startswith("descriptor:"):
                        descriptor = sig_line.split(":", 1)[1].strip()
                        break

                # Skip constructors and static initializers
                if method_name == "<init>" or method_name == "<clinit>":
                    i += 1
                    continue

                # Skip private/protected methods (shouldn't appear with -public, but double-check)
                if "private" in line.lower() or "protected" in line.lower():
                    i += 1
                    continue

                methods.append({
                    "name": method_name,
                    "signature": descriptor or "unknown",
                    "jvm_descriptor": descriptor or "unknown",
                    "full_signature": line.rstrip(";"),
                    "modifiers": modifiers,
                    "is_static": "static" in modifiers,
                    "is_abstract": "abstract" in modifiers,
                    "is_final": "final" in modifiers,
                    "return_type": return_type,
                    "parameters": parameters,
                    "parameter_count": len(parameters),
                    "throws": throws,
                    "class": class_name,
                    "declaring_type": class_name,
                    "declaring_type_kind": class_kind,
                    "declaring_type_modifiers": class_modifiers,
                })

            i += 1

        return methods

    def _parse_method_line(self, line: str, class_name: str) -> Optional[Dict[str, Any]]:
        """Parse a public method declaration line from javap output."""
        if not line.startswith("public ") or "(" not in line or not line.endswith(";"):
            return None

        open_paren = line.find("(")
        close_paren = line.rfind(")")
        if close_paren < open_paren:
            return None

        prefix = line[len("public ") : open_paren].strip()
        suffix = line[close_paren + 1 :].rstrip(";").strip()
        tokens = self._split_type_tokens(prefix)
        if len(tokens) < 2:
            return None

        method_name = tokens[-1]
        if method_name == class_name or method_name == class_name.rsplit(".", 1)[-1]:
            return None
        return_type = tokens[-2]

        modifier_tokens = {
            "static",
            "final",
            "synchronized",
            "abstract",
            "native",
            "strictfp",
            "default",
        }
        modifiers = ["public", *(token for token in tokens[:-2] if token in modifier_tokens)]
        parameters = self._split_parameters(line[open_paren + 1 : close_paren].strip())
        throws: List[str] = []
        if suffix.startswith("throws "):
            throws = self._split_parameters(suffix[len("throws ") :].strip())

        return {
            "name": method_name,
            "return_type": return_type,
            "modifiers": modifiers,
            "parameters": parameters,
            "throws": throws,
        }

    def _split_type_tokens(self, raw: str) -> List[str]:
        """Split a declaration prefix on whitespace outside generic brackets."""
        parts: List[str] = []
        current: List[str] = []
        depth = 0
        for char in raw:
            if char == "<":
                depth += 1
            elif char == ">" and depth:
                depth -= 1
            if char.isspace() and depth == 0:
                value = "".join(current).strip()
                if value:
                    parts.append(value)
                current = []
                continue
            current.append(char)
        value = "".join(current).strip()
        if value:
            parts.append(value)
        return parts

    def _split_parameters(self, raw: str) -> List[str]:
        """Split javap parameter/type lists while respecting generic angle brackets."""
        if not raw:
            return []
        parts: List[str] = []
        current: List[str] = []
        depth = 0
        for char in raw:
            if char == "<":
                depth += 1
            elif char == ">" and depth:
                depth -= 1
            if char == "," and depth == 0:
                value = "".join(current).strip()
                if value:
                    parts.append(value)
                current = []
                continue
            current.append(char)
        value = "".join(current).strip()
        if value:
            parts.append(value)
        return parts

    def extract_all(self) -> List[Dict[str, Any]]:
        """Extract all public methods from all classes in the JAR.

        Returns:
            List of class dictionaries with methods
        """
        classes = self.extract_classes()
        print(f"Found {len(classes)} classes in {self.jar_path.name}", file=sys.stderr)

        results = []
        for i, class_name in enumerate(classes, 1):
            if i % 50 == 0:
                print(f"Processed {i}/{len(classes)} classes...", file=sys.stderr)

            class_info = self.extract_methods(class_name)
            if class_info:
                results.append(class_info)

        print(f"Extracted methods from {len(results)} classes", file=sys.stderr)
        return results


def download_maven_jar(group_id: str, artifact_id: str, version: str) -> Path:
    """Download a JAR from Maven Central.

    Args:
        group_id: Maven group ID (e.g., 'com.squareup.okhttp3')
        artifact_id: Maven artifact ID (e.g., 'okhttp')
        version: Version (e.g., '3.14.9')

    Returns:
        Path to downloaded JAR file
    """
    print(f"Downloading {group_id}:{artifact_id}:{version}...", file=sys.stderr)

    # Download to Maven local repository
    result = subprocess.run(
        [
            "mvn",
            "dependency:get",
            f"-Dartifact={group_id}:{artifact_id}:{version}",
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )

    if result.returncode != 0:
        raise RuntimeError(f"Failed to download JAR: {result.stderr}\n{result.stdout}")

    # JAR is in Maven local repo: ~/.m2/repository/group/artifact/version/artifact-version.jar
    maven_repo = Path.home() / ".m2" / "repository"
    group_path = group_id.replace(".", "/")
    jar_path = maven_repo / group_path / artifact_id / version / f"{artifact_id}-{version}.jar"

    if not jar_path.exists():
        raise RuntimeError(f"Maven download succeeded but JAR not found at {jar_path}")

    print(f"Downloaded to: {jar_path}", file=sys.stderr)
    return jar_path


def main():
    """Main entry point for the extractor."""
    parser = argparse.ArgumentParser(description="Extract all public methods from a Java JAR file")
    parser.add_argument(
        "jar_or_maven",
        help="Path to JAR file or Maven coordinates (maven:group:artifact:version)",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        help="Output JSON file (default: stdout)",
    )

    args = parser.parse_args()

    arg = args.jar_or_maven

    # Accept "maven:group:artifact:version" (legacy) or plain "group:artifact:version"
    if arg.startswith("maven:"):
        coord_str = arg[len("maven:") :]
    else:
        coord_str = arg

    coord_parts = coord_str.split(":")
    if len(coord_parts) == 3:
        group_id, artifact_id, version = coord_parts
        try:
            jar_path = download_maven_jar(group_id, artifact_id, version)
        except (subprocess.TimeoutExpired, RuntimeError) as e:
            print(f"Error downloading JAR: {e}", file=sys.stderr)
            return 1
    else:
        jar_path = Path(arg)

    # Extract methods
    try:
        extractor = JavaMethodExtractor(jar_path)
        results = extractor.extract_all()

        # Flatten methods list for workflow compatibility
        # Workflow expects: [{"name": "method", "class": "Foo", ...}, ...]
        # Not: {"classes": [{"name": "Foo", "methods": [...]}]}
        all_methods = []
        for class_info in results:
            all_methods.extend(class_info["methods"])

        # Log summary to stderr
        print(
            f"Extracted {len(all_methods)} methods from {len(results)} classes in {jar_path.name}",
            file=sys.stderr,
        )

        # Write flat method list to output
        if args.output:
            with open(args.output, "w") as f:
                json.dump(all_methods, f, indent=2)
            print(f"\nWrote {len(all_methods)} methods to {args.output}", file=sys.stderr)
        else:
            print(json.dumps(all_methods, indent=2))

        return 0

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error extracting methods: {e}", file=sys.stderr)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
