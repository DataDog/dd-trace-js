"""Git operations for gen/ branch management.

Gen branches store the generated code from each workflow run, making it
diff-able and checkable across runs. The workflow already commits per step;
this module only handles the push and consistent branch naming.
"""

import logging
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def get_current_commit(repo_dir: Path) -> str:
    """Return the current HEAD commit hash."""
    return _git(repo_dir, ["rev-parse", "HEAD"])


def get_base_branch_commit(repo_dir: Path, base_branch: str) -> str:
    """Return the commit hash of the given branch tip."""
    return _git(repo_dir, ["rev-parse", base_branch])


def get_current_branch(repo_dir: Path) -> str:
    """Return the current branch name (e.g., 'apm-ai-toolkit/new_integration/kafkajs/...')."""
    return _git(repo_dir, ["rev-parse", "--abbrev-ref", "HEAD"])


def get_remote_url(repo_dir: Path, remote: str = "origin") -> str:
    """Return the remote URL for the given remote name."""
    return _git(repo_dir, ["remote", "get-url", remote])


def push_gen_branch(
    repo_dir: Path,
    integration: str,
    repository_short: str,
    run_id: str,
    remote: str = "origin",
) -> Optional[str]:
    """Push the current branch to a gen/ branch in the remote.

    Branch name: gen/{repository_short}/{integration}/run-{run_id}
    Example:     gen/dd-trace-js/kafkajs/run-20260401-abc123

    Returns the final commit hash that was pushed, or None on failure.
    The gen/ namespace in the target repo should have a 90-day auto-delete
    rule configured via GitHub branch protection to avoid accumulation.

    Args:
        repo_dir: Root of the target tracer repo.
        integration: Integration name (e.g., "kafkajs").
        repository_short: Short repo name for branch (e.g., "dd-trace-js").
        run_id: Stable run ID from WorkflowState.run_id.
        remote: Git remote name (default: "origin").

    Returns:
        Commit hash of the pushed branch tip, or None if push fails.
    """
    branch_name = f"gen/{repository_short}/{integration}/run-{run_id}"
    commit = get_current_commit(repo_dir)

    try:
        # Push HEAD to the gen/ branch via a refspec — the remote will perform
        # a fast-forward update; no merge strategy flags are needed for push.
        _git(repo_dir, ["push", remote, f"HEAD:refs/heads/{branch_name}"])
        logger.info("Pushed gen branch: %s (commit %s)", branch_name, commit[:8])
        return commit
    except subprocess.CalledProcessError as exc:
        logger.warning("Failed to push gen branch %s: %s", branch_name, exc)
        return None


def _git(repo_dir: Path, args: list) -> str:
    result = subprocess.run(
        ["git"] + args,
        cwd=repo_dir,
        check=True,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()
