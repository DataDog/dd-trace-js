"""RunManifest — Pydantic models and builder for S3 run metadata.

The manifest is the lightweight index record stored in S3 alongside each run.
It is used ONLY for retrieval routing — it is never injected into agent prompts.
Only raw files (step outputs, artifacts, generated code) get injected.
"""

import logging
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Literal, Optional

from pydantic import BaseModel, Field

from anubis.core.version import get_toolkit_version

from .config_hash import compute_hash_from_state

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from anubis.core.state.models import WorkflowState


class CodeRef(BaseModel):
    """Reference to the generated code in git."""

    branch: str
    commit: str
    repo_remote: str
    base_branch: str
    base_commit: str


class ConfigSnapshot(BaseModel):
    """Config versioning — hashes of the prompts/skills used in this run."""

    run_config_hash: str = ""
    toolkit_version: str = ""
    toolkit_git_sha: str = ""
    toolkit_git_branch: str = ""
    toolkit_git_dirty: bool = False


class StepSnapshot(BaseModel):
    """Metrics and content-addressing info for one completed step."""

    template_hash: str = ""
    rendered_prompt_hash: str = ""
    skill_hashes: Dict[str, str] = Field(default_factory=dict)
    model: str = ""
    max_turns: int = 0
    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    commit: Optional[str] = None
    s3_output_key: Optional[str] = None
    s3_log_key: Optional[str] = None


class RunTotals(BaseModel):
    """Aggregated metrics for the full workflow run."""

    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    steps_completed: int = 0
    workflow_completed: bool = False


class RunManifest(BaseModel):
    """Index record for one workflow run stored in S3.

    Stored at s3://{bucket}/runs/{repo}/{integration}/{config_hash_short}/{run_id}/manifest.json.
    Also included in the global index.json for fast bootstrap queries.
    """

    version: int = 1
    run_id: str
    integration: str
    repository: str
    workflow: str
    branch: str = ""
    language: str = ""
    category: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    status: Literal["completed", "failed", "incomplete"] = "incomplete"
    environment: Literal["prod", "dev"] = "dev"
    code_ref: Optional[CodeRef] = None
    config: ConfigSnapshot = Field(default_factory=ConfigSnapshot)
    steps: Dict[str, StepSnapshot] = Field(default_factory=dict)
    totals: RunTotals = Field(default_factory=RunTotals)
    eval_report_path: Optional[str] = None
    s3_prefix: Optional[str] = None


def build_manifest(
    run_id: str,
    integration: str,
    repository: str,
    workflow: str,
    state: "WorkflowState",
    branch: str = "",
    language: str = "",
    category: Optional[str] = None,
    status: Literal["completed", "failed", "incomplete"] = "incomplete",
    environment: Literal["prod", "dev"] = "dev",
    code_ref: Optional[CodeRef] = None,
    toolkit_root: Optional[Path] = None,
) -> RunManifest:
    """Build a RunManifest from a completed (or partial) WorkflowState.

    Args:
        run_id: Stable run identifier from state.run_id.
        integration: Integration name (e.g., "kafkajs").
        repository: Tracer repository key (e.g., "dd_trace_js").
        workflow: Workflow name (e.g., "new_integration").
        state: The WorkflowState at time of manifest creation.
        language: Primary language (e.g., "javascript").
        category: Integration category (e.g., "messaging"). May be None for new runs.
        status: Run completion status.
        code_ref: Git reference to generated code, if available.
        toolkit_root: Toolkit repo root for git SHA computation.

    Returns:
        A populated RunManifest ready for S3 upload.
    """
    steps: Dict[str, StepSnapshot] = {}
    for step_name, step_state in state.steps.items():
        steps[step_name] = StepSnapshot(
            cost_usd=step_state.metrics.cost_usd,
            duration_seconds=step_state.metrics.duration_seconds,
            commit=step_state.git_commit,
        )

    config = ConfigSnapshot()
    if toolkit_root:
        config = _build_config_snapshot(toolkit_root)

    # Compute run_config_hash from prompts/skills loaded during execution.
    # flush_tracked_paths() populates state.data["_loaded_content_paths"] after each step.
    computed_hash = compute_hash_from_state(state.data)
    if computed_hash:
        config.run_config_hash = computed_hash
        logger.debug("run_config_hash: %s", computed_hash[:16])

    totals = RunTotals(
        cost_usd=state.total_cost_usd,
        duration_seconds=state.total_duration_seconds,
        steps_completed=sum(1 for s in state.steps.values() if s.status == "completed"),
        workflow_completed=state.status == "completed",
    )

    return RunManifest(
        run_id=run_id,
        integration=integration,
        repository=repository,
        workflow=workflow,
        branch=branch,
        language=language,
        category=category,
        status=status,
        environment=environment,
        code_ref=code_ref,
        config=config,
        steps=steps,
        totals=totals,
    )


def _build_config_snapshot(toolkit_root: Path) -> ConfigSnapshot:
    """Capture toolkit git state for the config snapshot."""

    def _git(args: List[str]) -> str:
        try:
            return subprocess.check_output(
                ["git"] + args,
                cwd=toolkit_root,
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
        except subprocess.CalledProcessError:
            return ""

    sha = _git(["rev-parse", "HEAD"])
    branch = _git(["rev-parse", "--abbrev-ref", "HEAD"])
    dirty_output = _git(["status", "--porcelain"])

    toolkit_ver = get_toolkit_version()

    return ConfigSnapshot(
        toolkit_version=toolkit_ver,
        toolkit_git_sha=sha,
        toolkit_git_branch=branch,
        toolkit_git_dirty=bool(dirty_output),
    )
