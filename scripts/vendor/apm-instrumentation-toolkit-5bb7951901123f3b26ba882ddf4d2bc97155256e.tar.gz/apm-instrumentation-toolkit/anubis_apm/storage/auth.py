"""AWS authentication helpers for the experience store.

Credential resolution order (automatic, no user action required):

1. Active aws-vault session — works when:
   - AWS_VAULT env var is set (aws-vault exec is already running)
   - Credentials are pre-injected into the environment

2. Standard boto3 chain — works when:
   - Environment variables are set (AWS_ACCESS_KEY_ID etc.) — for CI
   - An aws-vault exec session is already active (aws-vault injects env vars)
   - A valid ~/.aws/credentials or SSO cache exists

3. aws-vault exec fallback — works when:
   - aws-vault is installed and configured with SSO profiles
   - An SSO profile named sso-staging-engineering is in ~/.aws/config
   - The dev has completed standard Datadog AWS onboarding

4. Fail gracefully — S3 sync is opt-in. If auth fails, the workflow continues
   without remote storage and logs a clear message.

Setup (one-time, per Datadog AWS onboarding docs):
  brew install aws-vault awscli ddtool
  $DATADOG_ROOT/devtools/bin/setup-awsconfig $(whoami) > ~/.aws/config

The setup-awsconfig script generates ALL SSO profiles including
sso-staging-engineering. See:
  https://datadoghq.atlassian.net/wiki/spaces/SECENG/pages/6028265266
"""

import getpass
import io
import json
import logging
import os
import subprocess
import sys as _sys
import types
from importlib.machinery import SourceFileLoader
from pathlib import Path
from typing import Optional

import boto3
from botocore.config import Config

logger = logging.getLogger(__name__)

_BUCKET = "dd-apm-toolkit-experience"
_SSO_PROFILE = "sso-staging-engineering"

# Module-level client cache — SSO only happens once per process invocation.
# boto3 clients are thread-safe for concurrent reads.
_cached_client = None
_auth_attempted = False

# Common devtools locations (in preference order)
_DEVTOOLS_SEARCH_PATHS = [
    Path(os.environ.get("DATADOG_ROOT", "~/dd")) / "devtools",
    Path("~/dd/devtools"),
    Path("~/src/devtools"),
    Path("~/.dd-apm/devtools"),
]


def make_s3_client(region: str = "us-east-1"):
    """Create an authenticated boto3 S3 client.

    Tries the standard credential chain first; falls back to aws-vault if needed.
    Returns None (not raises) if authentication cannot be established.

    The result is cached at module level — SSO only triggers once per process.
    Subsequent calls return the same client (or None if auth failed).
    """
    global _cached_client, _auth_attempted
    if _auth_attempted:
        return _cached_client
    _auth_attempted = True

    # Tests and CI can opt out of all AWS auth (including the aws-vault fallback)
    # via DD_APM_DISABLE_S3=1. Critical for pytest — otherwise every test process
    # spawns an aws-vault SSO request.
    if os.environ.get("DD_APM_DISABLE_S3") == "1":
        logger.debug("DD_APM_DISABLE_S3=1 — skipping S3 auth")
        return None

    # Short timeouts prevent hanging on IMDS (169.254.169.254) on dev machines.
    # retries=0 so we fail fast and fall through to aws-vault immediately.
    _probe_config = Config(connect_timeout=3, read_timeout=5, retries={"max_attempts": 0})

    # Attempt 1: Standard credential chain (env vars, active aws-vault session, SSO cache)
    try:
        client = boto3.client("s3", region_name=region, config=_probe_config)
        client.list_buckets()  # Probe — fails fast if no creds
        logger.debug("AWS auth: standard credential chain")
        _cached_client = boto3.client("s3", region_name=region)
        return _cached_client
    except Exception as exc:
        logger.debug("Standard credential chain failed: %s", exc)

    # Attempt 2: aws-vault exec with SSO profile
    creds = _get_credentials_via_aws_vault()
    if creds:
        try:
            client = boto3.client(
                "s3",
                region_name=region,
                aws_access_key_id=creds["access_key"],
                aws_secret_access_key=creds["secret_key"],
                aws_session_token=creds.get("session_token"),
            )
            client.list_buckets()
            logger.debug("AWS auth: aws-vault exec %s", _SSO_PROFILE)
            _cached_client = client
            return _cached_client
        except Exception as exc:
            logger.debug("aws-vault credentials failed: %s", exc)

    logger.debug(
        "Could not establish AWS credentials — S3 sync disabled. "
        "Run 'dd-apm sync setup' to diagnose."
    )
    return None


def _get_credentials_via_aws_vault() -> Optional[dict]:
    """Extract temporary AWS credentials via aws-vault exec.

    Runs a subprocess under aws-vault that prints the injected env vars,
    then parses out the AWS credential triplet.
    """
    # Short-circuit: if we're already inside an aws-vault session, the standard
    # credential chain should have picked up the injected env vars already.
    if os.environ.get("AWS_VAULT"):
        return None

    if not _is_aws_vault_available():
        return None
    if not _has_sso_profile():
        logger.debug("aws-vault profile %s not found in ~/.aws/config", _SSO_PROFILE)
        return None

    try:
        # Inject the managed env vars so aws-vault always uses the login keychain
        # and 24h session TTL regardless of whether the user has sourced their shell rc.
        # Without this, aws-vault may fall back to its defaults (file backend, shorter TTL)
        # and fail to find cached credentials, triggering a browser SSO prompt every run.
        vault_env = {**os.environ, **_AWS_MANAGED_ENV}
        result = subprocess.run(
            [
                "aws-vault",
                "exec",
                _SSO_PROFILE,
                "--",
                "env",
            ],
            capture_output=True,
            stdin=subprocess.DEVNULL,  # Prevent Keychain password prompts from blocking
            text=True,
            timeout=120,  # Browser-based SSO can take up to 2 minutes
            env=vault_env,
        )
        if result.returncode != 0:
            logger.debug("aws-vault exec failed: %s", result.stderr.strip())
            return None

        env_vars: dict = {}
        for line in result.stdout.splitlines():
            if "=" in line:
                key, _, val = line.partition("=")
                env_vars[key] = val

        access_key = env_vars.get("AWS_ACCESS_KEY_ID", "")
        secret_key = env_vars.get("AWS_SECRET_ACCESS_KEY", "")
        session_token = env_vars.get("AWS_SESSION_TOKEN", "")

        if not access_key or not secret_key:
            return None

        return {
            "access_key": access_key,
            "secret_key": secret_key,
            "session_token": session_token or None,
        }

    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        logger.debug("aws-vault exec error: %s", exc)
        return None


def check_prerequisites() -> list[dict]:
    """Check all prerequisites for S3 experience store access.

    Returns a list of check results, each with keys:
        name: str — check name
        ok: bool — whether it passed
        detail: str — human-readable detail
        fix: str | None — how to fix if failed
    """
    checks: list[dict] = []

    # 0. Active aws-vault session (short-circuit — everything passes implicitly)
    active_session = os.environ.get("AWS_VAULT", "")
    if active_session:
        checks.append({
            "name": "aws-vault session",
            "ok": True,
            "detail": f"active session ({active_session})",
            "fix": None,
        })
        # Still check bucket access since credentials might be scoped incorrectly
        client = make_s3_client()
        auth_ok = client is not None
        checks.append({
            "name": "AWS authentication",
            "ok": auth_ok,
            "detail": "credentials valid" if auth_ok else "session present but auth probe failed",
            "fix": (
                f"Log in via SSO (opens browser):\n  aws-vault exec {_SSO_PROFILE} -- aws s3 ls"
            )
            if not auth_ok
            else None,
        })
        if auth_ok:
            _append_bucket_check(checks, client)
        return checks

    # 1. aws-vault installed
    vault_ok = _is_aws_vault_available()
    checks.append({
        "name": "aws-vault",
        "ok": vault_ok,
        "detail": "installed" if vault_ok else "not found",
        "fix": "brew install aws-vault awscli" if not vault_ok else None,
    })

    # 2. SSO profile exists
    profile_ok = _has_sso_profile()
    checks.append({
        "name": f"SSO profile ({_SSO_PROFILE})",
        "ok": profile_ok,
        "detail": "found in ~/.aws/config" if profile_ok else "not found in ~/.aws/config",
        "fix": (
            "Generate your AWS config (one-time setup):\n"
            '  [ ! -d "$DATADOG_ROOT/devtools" ] && '
            "git clone git@github.com:DataDog/devtools.git $DATADOG_ROOT/devtools\n"
            "  cd $DATADOG_ROOT/devtools && git pull && cd -\n"
            "  $DATADOG_ROOT/devtools/bin/setup-awsconfig $(whoami) > ~/.aws/config\n"
            "See: https://datadoghq.atlassian.net/wiki/spaces/SECENG/pages/6028265266\n"
            "Or run: dd-apm sync setup --fix"
        )
        if not profile_ok
        else None,
    })

    # 3. Can authenticate (only if all prerequisites pass)
    if vault_ok and profile_ok:
        client = make_s3_client()
        auth_ok = client is not None
        checks.append({
            "name": "AWS authentication",
            "ok": auth_ok,
            "detail": "credentials valid" if auth_ok else "failed to authenticate",
            "fix": (
                f"Log in via SSO (opens browser):\n  aws-vault exec {_SSO_PROFILE} -- aws s3 ls"
            )
            if not auth_ok
            else None,
        })

        # 4. Can access bucket (only if auth works)
        if auth_ok:
            _append_bucket_check(checks, client)

    return checks


def _append_bucket_check(checks: list[dict], client) -> None:
    """Append an S3 bucket accessibility check to checks list."""
    bucket = _BUCKET
    try:
        client.head_bucket(Bucket=bucket)
        bucket_ok = True
        bucket_detail = f"accessible ({bucket})"
    except Exception as exc:
        bucket_ok = False
        bucket_detail = f"cannot access {bucket}: {exc}"
    checks.append({
        "name": "S3 bucket access",
        "ok": bucket_ok,
        "detail": bucket_detail,
        "fix": "Check IAM permissions for sso-staging-engineering" if not bucket_ok else None,
    })


def _upgrade_ddtool_step() -> dict:
    """Upgrade ddtool via Homebrew (streams output to terminal)."""
    try:
        env = {**os.environ, "HOMEBREW_NO_AUTO_UPDATE": "1"}
        result = subprocess.run(
            ["brew", "upgrade", "datadog/tap/ddtool"],
            env=env,
            timeout=180,
        )
        if result.returncode == 0:
            return {"action": "ddtool upgrade", "ok": True, "detail": "upgraded via Homebrew"}
        return {
            "action": "ddtool upgrade",
            "ok": False,
            "detail": "brew upgrade failed (see output above)",
        }
    except FileNotFoundError:
        return {"action": "ddtool upgrade", "ok": False, "detail": "Homebrew not found"}
    except subprocess.TimeoutExpired:
        return {"action": "ddtool upgrade", "ok": False, "detail": "timed out"}
    except Exception as exc:
        return {"action": "ddtool upgrade", "ok": False, "detail": str(exc)}


def attempt_setup_fixes(on_step=None, on_result=None) -> list[dict]:
    """Attempt to automatically fix common setup issues.

    Performs the following steps (each independently):
    1. Install aws-vault via Homebrew (if missing)
    2. Write the DD-APM AWS managed block to shell rc (keychain backend +
       session TTL tuning — keeps creds cached across CLI invocations)
    3. If SSO profile missing and devtools found:
       a. Run setup-awsconfig; if it fails with a ddtool version error,
       b. Upgrade ddtool via Homebrew, then
       c. Retry setup-awsconfig once

    Args:
        on_step: Optional callable(action: str) invoked just before each step runs.
        on_result: Optional callable(result: dict) invoked immediately after each
                   step completes, so callers can print results inline with progress.

    Returns a list of all action results.
    """
    results: list[dict] = []

    def _step(action: str, fn):
        if on_step:
            on_step(action)
        result = fn()
        results.append(result)
        if on_result:
            on_result(result)
        return result

    def _append(result: dict):
        results.append(result)
        if on_result:
            on_result(result)

    # Step 1: Install aws-vault if missing
    if not _is_aws_vault_available():
        _step("aws-vault install", _brew_install_aws_vault)
    else:
        _append({"action": "aws-vault install", "ok": True, "detail": "already installed"})

    # Step 2: Configure aws-vault env (keychain backend + TTLs) in shell rc
    _step("aws-vault env", _configure_aws_vault_env)

    # Step 3: Run setup-awsconfig if SSO profile is missing
    if _has_sso_profile():
        _append({
            "action": "SSO profile",
            "ok": True,
            "detail": f"profile {_SSO_PROFILE} already present",
        })
        return results

    res = _step("setup-awsconfig", _run_setup_awsconfig)
    if res["ok"]:
        return results

    # Infra issues (devtools missing, import error) — upgrade won't help.
    detail = res.get("detail", "")
    if detail.startswith("devtools") or "import error" in detail:
        return results

    # Otherwise try upgrading ddtool and retry once.
    upgrade_res = _step("ddtool upgrade", _upgrade_ddtool_step)
    if not upgrade_res["ok"]:
        return results

    retry_res = _step("setup-awsconfig (retry)", _run_setup_awsconfig)
    if not retry_res["ok"]:
        # Still failing after upgrade — likely VPN/auth issue.
        _append({
            "action": "",
            "ok": None,
            "detail": "ddtool is up to date — check Appgate VPN is connected and run: ddtool auth login",
        })

    return results


def _brew_install_aws_vault() -> dict:
    """Attempt to install aws-vault via Homebrew.

    Streams brew output directly to the terminal so the user can see progress.
    Falls back to reinstall if install exits 0 but the binary still isn't found
    (can happen when the cask is registered but the binary file is missing).
    """
    env = {**os.environ, "HOMEBREW_NO_AUTO_UPDATE": "1"}
    for cmd in (
        ["brew", "install", "--cask", "aws-vault"],
        ["brew", "reinstall", "--cask", "aws-vault"],
    ):
        try:
            result = subprocess.run(cmd, env=env, timeout=180)
            if result.returncode != 0:
                return {
                    "action": "aws-vault install",
                    "ok": False,
                    "detail": f"{' '.join(cmd[1:])} failed (see output above)",
                }
            # Verify the binary actually landed on PATH
            if _is_aws_vault_available():
                return {
                    "action": "aws-vault install",
                    "ok": True,
                    "detail": "installed via Homebrew",
                }
            # Binary missing despite exit 0 — loop to try reinstall
        except FileNotFoundError:
            return {
                "action": "aws-vault install",
                "ok": False,
                "detail": "Homebrew not found — install manually: brew install --cask aws-vault",
            }
        except subprocess.TimeoutExpired:
            return {
                "action": "aws-vault install",
                "ok": False,
                "detail": "brew install timed out",
            }
        except Exception as exc:
            return {"action": "aws-vault install", "ok": False, "detail": str(exc)}

    return {
        "action": "aws-vault install",
        "ok": False,
        "detail": "installed but binary not found — try: hash -r or open a new terminal",
    }


def _get_shell_rc() -> Optional[Path]:
    """Return the path to the user's primary shell rc file."""
    shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        return Path("~/.zshrc").expanduser()
    if "bash" in shell:
        bash_profile = Path("~/.bash_profile").expanduser()
        if bash_profile.exists():
            return bash_profile
        return Path("~/.bashrc").expanduser()
    # Fallback: try common files in order
    for candidate in ["~/.zshrc", "~/.bash_profile", "~/.bashrc"]:
        p = Path(candidate).expanduser()
        if p.exists():
            return p
    return None


_AWS_BLOCK_BEGIN = "# BEGIN DD-APM AWS MANAGED BLOCK"
_AWS_BLOCK_END = "# END DD-APM AWS MANAGED BLOCK"
# Env vars written to the user's shell rc so aws-vault can reuse creds across
# CLI invocations without prompting.
#
# Only keychain-related settings and AWS_SESSION_TTL are set here:
#   - AWS_VAULT_BACKEND=keychain + AWS_VAULT_KEYCHAIN_NAME=login
#     Store creds in the macOS login keychain (stays unlocked for the login
#     session) instead of the aws-vault.keychain-db which auto-locks after
#     5 minutes idle.
#   - AWS_SESSION_TTL=24h
#     TTL for the aws-vault GetSessionToken cache. Safe to raise — AWS caps
#     at 36h for session tokens.
#
# We deliberately do NOT set AWS_ASSUME_ROLE_TTL. aws-vault raises
# "ValidationError: DurationSeconds exceeds ..." when the requested TTL is
# greater than the role's max_session_duration (commonly 1h for chained
# SSO roles). See aws-vault#263, #303, #720. Users who know their role
# allows 12h can opt in manually.
_AWS_MANAGED_ENV: dict[str, str] = {
    "AWS_VAULT_BACKEND": "keychain",
    "AWS_VAULT_KEYCHAIN_NAME": "login",
    "AWS_SESSION_TTL": "24h",
}
# Stray patterns written by older versions of this function (before the
# managed-block refactor) that we actively comment out when we find them
# outside the managed block.
_LEGACY_LINE_PATTERNS = (
    "export AWS_VAULT_BACKEND=file",
    "# aws-vault: use file backend",
)


def _render_aws_managed_block() -> str:
    lines = [
        _AWS_BLOCK_BEGIN,
        "# Managed by `dd-apm sync setup --fix`. Edit via that command.",
    ]
    lines.extend(f"export {key}={val}" for key, val in _AWS_MANAGED_ENV.items())
    lines.append(_AWS_BLOCK_END)
    return "\n".join(lines) + "\n"


def _is_legacy_backend_line(line: str) -> bool:
    stripped = line.strip()
    return stripped == _LEGACY_LINE_PATTERNS[0] or stripped.startswith(_LEGACY_LINE_PATTERNS[1])


def _rewrite_rc_content(existing: str) -> tuple[str, bool]:
    """Produce the new rc content with every managed block replaced by a fresh one.

    - Markers only match when they are the *entire* stripped line — substring
      matches inside user comments or quoted strings do not flip state.
    - ALL existing managed blocks are removed (not just the first) so that
      duplicates from buggy prior runs collapse cleanly on re-run.
    - Stray ``export AWS_VAULT_BACKEND=file`` and its comment (written by
      older versions of this function) outside any managed block are commented
      out in place so users can still recover intent.
    - Orphan ``BEGIN`` with no matching ``END`` is treated as non-managed
      content and preserved — we never blindly consume everything after a
      stray marker.

    Returns ``(new_content, did_migrate)``. The result always ends with a
    single trailing newline (POSIX convention) so downstream appends stay
    predictable.
    """
    lines = existing.splitlines()
    # First pass: identify exact (begin_idx, end_idx) pairs of well-formed
    # managed blocks. Only exact stripped-line matches count.
    block_ranges: list[tuple[int, int]] = []
    begin_idx: Optional[int] = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == _AWS_BLOCK_BEGIN:
            begin_idx = i
        elif stripped == _AWS_BLOCK_END and begin_idx is not None:
            block_ranges.append((begin_idx, i))
            begin_idx = None
    # begin_idx still set here means an orphan BEGIN with no END — leave it
    # untouched in the output; do not consume trailing lines.

    in_block_line_indices: set[int] = set()
    for start, end in block_ranges:
        in_block_line_indices.update(range(start, end + 1))

    out_lines: list[str] = []
    did_migrate = False
    for i, line in enumerate(lines):
        if i in in_block_line_indices:
            continue  # drop all managed-block lines; a fresh one is appended
        if _is_legacy_backend_line(line):
            out_lines.append(f"# [dd-apm migrated to managed block] {line}")
            did_migrate = True
            continue
        out_lines.append(line)

    # Check if all managed env vars already have the correct values as
    # standalone exports. If so, skip the managed block entirely.
    # If not, comment out any stale standalone exports for managed keys
    # so the appended block is authoritative.
    correct_lines = {f"export {k}={v}" for k, v in _AWS_MANAGED_ENV.items()}
    managed_keys = {k for k in _AWS_MANAGED_ENV}
    correct_count = sum(1 for l in out_lines if l.strip() in correct_lines)
    all_correct = correct_count == len(_AWS_MANAGED_ENV)

    if not all_correct:
        # Comment out standalone exports that set managed keys with wrong values
        # so the appended managed block is the single source of truth.
        stale_prefixes = tuple(f"export {k}=" for k in managed_keys)
        cleaned = []
        for line in out_lines:
            stripped = line.strip()
            if stripped in correct_lines:
                cleaned.append(line)
            elif stripped.startswith(stale_prefixes):
                cleaned.append(f"# [dd-apm: superseded by managed block] {line}")
                did_migrate = True
            else:
                cleaned.append(line)
        out_lines = cleaned

    # Strip trailing blank lines so we append exactly one blank-line separator
    # before the managed block — re-runs produce byte-identical output.
    while out_lines and out_lines[-1].strip() == "":
        out_lines.pop()

    if all_correct:
        combined = out_lines
    else:
        managed_lines = _render_aws_managed_block().rstrip("\n").split("\n")
        combined = out_lines + [""] + managed_lines if out_lines else managed_lines
    return "\n".join(combined) + "\n", did_migrate


def _atomic_write(path: Path, content: str) -> None:
    """Write ``content`` to ``path`` atomically via tempfile + os.replace.

    Guarantees that ``path`` is either the old content or the new content,
    never a partially written file, even if the process crashes mid-write.
    """
    tmp = path.with_suffix(path.suffix + ".dd-apm.tmp")
    tmp.write_text(content)
    os.replace(tmp, path)


def _configure_aws_vault_env() -> dict:
    """Write the DD-APM AWS managed block to the user's shell rc file.

    Exports the env vars aws-vault needs to keep creds cached across CLI
    invocations:
      - ``AWS_VAULT_BACKEND=keychain`` + ``AWS_VAULT_KEYCHAIN_NAME=login``
        (use macOS login keychain; stays unlocked for the session)
      - ``AWS_SESSION_TTL=24h``
        (fewer aws-vault session-token refreshes per workday)

    Idempotent: every existing managed block is removed and a fresh one is
    appended — re-runs never duplicate or drift. Stray ``AWS_VAULT_BACKEND=file``
    lines written by older versions of this function are commented out in
    place so users can still recover intent.

    Writes are atomic (tempfile + rename) so a crash mid-write cannot leave
    the rc file truncated. The original file is preserved as ``<rc>.dd-apm.bak``
    the first time we modify it.
    """
    shell_rc = _get_shell_rc()
    if shell_rc is None:
        return {
            "action": "aws-vault env",
            "ok": False,
            "detail": "could not detect shell rc file",
        }

    try:
        existing = shell_rc.read_text() if shell_rc.exists() else ""
    except OSError as exc:
        return {
            "action": "aws-vault env",
            "ok": False,
            "detail": f"could not read {shell_rc}: {exc}",
        }

    new_content, did_migrate = _rewrite_rc_content(existing)

    # Always sync os.environ on success so the current process sees the values
    # even when the rc file is already correct. Subsequent setup steps within
    # this same process depend on it (e.g. aws-vault exec right after --fix).
    def _sync_env() -> None:
        for key, val in _AWS_MANAGED_ENV.items():
            os.environ[key] = val

    if new_content == existing:
        _sync_env()
        return {
            "action": "aws-vault env",
            "ok": True,
            "detail": f"already configured in {shell_rc}",
        }

    # Save a one-time backup so users can recover from a bad edit.
    bak = shell_rc.with_suffix(shell_rc.suffix + ".dd-apm.bak")
    wrote_backup = False
    if shell_rc.exists() and not bak.exists():
        try:
            bak.write_text(existing)
            wrote_backup = True
        except OSError as exc:
            # Backup is best-effort; atomic write below is the real safety.
            logger.debug("Could not write rc backup %s: %s", bak, exc)

    try:
        _atomic_write(shell_rc, new_content)
    except OSError as exc:
        return {
            "action": "aws-vault env",
            "ok": False,
            "detail": f"could not write to {shell_rc}: {exc}",
        }

    _sync_env()

    bits = [
        f"updated {shell_rc}",
        "open a new terminal (or `source ~/.zshrc`) to pick up the new values",
    ]
    if did_migrate:
        bits.insert(1, "migrated stray AWS_VAULT_BACKEND=file line")
    if wrote_backup:
        bits.insert(1, f"backup at {bak}")
    return {"action": "aws-vault env", "ok": True, "detail": "; ".join(bits)}


def _find_setup_awsconfig() -> Optional[Path]:
    """Search common devtools locations for setup-awsconfig binary."""
    for base in _DEVTOOLS_SEARCH_PATHS:
        candidate = base.expanduser() / "bin" / "setup-awsconfig"
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate
    return None


def _make_patched_load_accounts(aaf):
    """Return a patched aws_account_finder.load_accounts.

    The original hardcodes expected org names and crashes with KeyError when ddtool
    returns accounts with new org names (e.g. 'ddog'). This version uses setdefault.
    """
    rms_staging = "https://runtime-metadata-service.us1.ddbuild.io"
    rms_gov = "https://runtime-metadata-service.us1-build.fed.dog"

    def load_accounts(from_gov=False):
        res = subprocess.run(["ddtool", "version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if res.returncode != 0:
            return None, res.stderr.decode() + "Failed to check ddtool version.\n"

        rms = rms_gov if from_gov else rms_staging
        res = subprocess.run(
            ["ddtool", "cloud", "aws", "accounts", "list", "--rms-addr", rms],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if res.returncode != 0:
            return (
                None,
                res.stderr.decode() + "Failed to load accounts. Do you have AppGate set up?\n",
            )

        accounts: dict = {}
        for acct in json.loads(res.stdout):
            if "organization" in acct and "alias" in acct:
                accounts.setdefault(acct["organization"], {})[aaf.process_alias(acct)] = acct[
                    "number"
                ]
        return accounts, ""

    return load_accounts


def _run_setup_awsconfig() -> dict:
    """Run setup-awsconfig to generate ~/.aws/config with SSO profiles.

    Monkey-patches two known bugs in devtools/lib/aws_account_finder.py:
    - version_too_old(): false positive for e.g. 1.105.1 (checks patch independently)
    - load_accounts(): KeyError on new org names not in its hardcoded dict (e.g. 'ddog')
    """
    script = _find_setup_awsconfig()
    if script is None:
        return {
            "action": "setup-awsconfig",
            "ok": False,
            "detail": (
                "devtools not found — clone it first:\n"
                "  git clone git@github.com:DataDog/devtools.git $DATADOG_ROOT/devtools"
            ),
        }

    lib_dir = script.parent.parent / "lib"
    if not lib_dir.is_dir():
        return {
            "action": "setup-awsconfig",
            "ok": False,
            "detail": f"devtools lib/ not found at {lib_dir}",
        }

    username = getpass.getuser()
    aws_config = Path("~/.aws/config").expanduser()

    _sys.path.insert(0, str(lib_dir))
    try:
        import aws_account_finder as _aaf  # noqa: PLC0415

        _aaf.version_too_old = lambda _v: False
        _aaf.load_accounts = _make_patched_load_accounts(_aaf)

        loader = SourceFileLoader("_setup_awsconfig", str(script))
        mod = types.ModuleType("_setup_awsconfig")
        mod.__file__ = str(script)
        mod.__spec__ = None
        mod.__package__ = ""
        loader.exec_module(mod)

        captured = io.StringIO()
        old_stdout, old_argv = _sys.stdout, _sys.argv
        _sys.stdout = captured
        _sys.argv = [str(script), username]
        try:
            mod.main()
        except SystemExit as exc:
            if exc.code != 0:
                return {
                    "action": "setup-awsconfig",
                    "ok": False,
                    "detail": f"script exited ({exc.code}) — check Appgate VPN and ddtool auth",
                }
        finally:
            _sys.stdout = old_stdout
            _sys.argv = old_argv

        config_output = captured.getvalue()
        if not config_output.strip():
            return {
                "action": "setup-awsconfig",
                "ok": False,
                "detail": "script produced no output — check Appgate VPN is connected",
            }
        aws_config.parent.mkdir(parents=True, exist_ok=True)
        aws_config.write_text(config_output)
        return {
            "action": "setup-awsconfig",
            "ok": True,
            "detail": f"~/.aws/config written ({len(config_output.splitlines())} lines)",
        }
    except ImportError as exc:
        return {"action": "setup-awsconfig", "ok": False, "detail": f"import error: {exc}"}
    except Exception as exc:
        return {"action": "setup-awsconfig", "ok": False, "detail": str(exc)}
    finally:
        lib_dir_str = str(lib_dir)
        if lib_dir_str in _sys.path:
            _sys.path.remove(lib_dir_str)


def _is_aws_vault_available() -> bool:
    try:
        subprocess.run(["aws-vault", "--version"], capture_output=True, check=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def _has_sso_profile() -> bool:
    try:
        return _SSO_PROFILE in Path("~/.aws/config").expanduser().read_text()
    except OSError:
        return False
