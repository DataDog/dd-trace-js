"""Config versioning — hash prompt and skill content to track what changed.

Two levels of hashing:

run_config_hash (coarse, for eval grouping)
    SHA256 of all prompts, includes, repo fragments, link targets, and skills
    *actually loaded* during this workflow run. Changes only when a file that
    affects THIS workflow's agent output changes. Does NOT change when:
    - The integration name changes (that's a variable, not config)
    - output_schema, user_prompt, or other runtime variables change
    - Unrelated workflows' prompts change

    Three directive types are all included:
    - {{include:path}} — inlined content is config
    - {{include_repo:name}} — repo-specific fragment is config
    - {{link:path|label}} — linked file content shapes what the agent reads

rendered_prompt_hash (fine, per-step)
    SHA256 of the fully rendered prompt after ALL variable injection.
    Captures exactly what the agent saw. Differs per integration/run.

How to collect loaded paths
    PromptLoader and SkillLoader are instrumented (see anubis/core/resources/)
    to record every file opened into WorkflowState.data["_loaded_content_paths"].
    The manifest builder reads this at workflow completion.
"""

import hashlib
import logging
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_LOADED_PATHS_KEY = "_loaded_content_paths"


def compute_run_config_hash(
    loaded_prompt_paths: List[Path],
    loaded_include_paths: List[Path],
    loaded_link_paths: List[Path],
    loaded_skill_paths: List[Path],
) -> str:
    """Hash all content that could affect agent behavior during this run.

    Sorted by path, content concatenated, SHA256 of result.
    Returns a 64-char hex string (full SHA256).
    """
    all_paths = sorted(
        set(
            list(loaded_prompt_paths)
            + list(loaded_include_paths)
            + list(loaded_link_paths)
            + list(loaded_skill_paths)
        )
    )
    h = hashlib.sha256()
    for path in all_paths:
        try:
            h.update(path.read_bytes())
        except OSError as exc:
            logger.debug("Skipping missing path for config hash: %s (%s)", path, exc)
    return h.hexdigest()


def compute_rendered_prompt_hash(rendered_text: str) -> str:
    """SHA256 of the fully rendered prompt after all variable injection."""
    return hashlib.sha256(rendered_text.encode()).hexdigest()


def extract_loaded_paths(state_data: Dict) -> Dict[str, List[Path]]:
    """Extract recorded loaded paths from WorkflowState.data.

    Returns a dict with keys:
        prompts, includes, links, skills
    """
    raw = state_data.get(_LOADED_PATHS_KEY, {})
    return {
        "prompts": [Path(p) for p in raw.get("prompts", [])],
        "includes": [Path(p) for p in raw.get("includes", [])],
        "links": [Path(p) for p in raw.get("links", [])],
        "skills": [Path(p) for p in raw.get("skills", [])],
    }


def record_loaded_path(state_data: Dict, category: str, path: Path) -> None:
    """Record a loaded file path into state.data for later config hashing.

    Called by the instrumented PromptLoader/SkillLoader.

    Args:
        state_data: WorkflowState.data dict (mutated in place).
        category: One of "prompts", "includes", "links", "skills".
        path: Absolute path to the file that was loaded.
    """
    if _LOADED_PATHS_KEY not in state_data:
        state_data[_LOADED_PATHS_KEY] = {"prompts": [], "includes": [], "links": [], "skills": []}
    paths_list = state_data[_LOADED_PATHS_KEY].setdefault(category, [])
    path_str = str(path)
    if path_str not in paths_list:
        paths_list.append(path_str)


def compute_hash_from_state(state_data: Dict) -> Optional[str]:
    """Compute run_config_hash from paths recorded in WorkflowState.data.

    Returns the hash string, or None if no paths were recorded.
    """
    loaded = extract_loaded_paths(state_data)
    all_paths = loaded["prompts"] + loaded["includes"] + loaded["links"] + loaded["skills"]
    if not all_paths:
        return None
    return compute_run_config_hash(
        loaded["prompts"],
        loaded["includes"],
        loaded["links"],
        loaded["skills"],
    )
