"""S3RunStorage — upload and download workflow run artifacts to/from S3.

Authentication uses the standard boto3 credential chain:
  1. Environment variables (AWS_ACCESS_KEY_ID etc.) — for CI
  2. Active aws-vault session (sso-staging-engineering for local dev)
  3. Explicit profile via AWS_PROFILE

The bucket is hardcoded to dd-apm-toolkit-experience (staging account).
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, List, Optional

from .auth import make_s3_client as _make_boto3_client
from .manifest import RunManifest

logger = logging.getLogger(__name__)

_BUCKET = "dd-apm-toolkit-experience"
_PREFIX = "runs"
_INDEX_KEY = "index.json"


class S3RunStorage:
    """Uploads and downloads workflow run data to/from S3.

    S3 layout::

        {bucket}/{prefix}/{repository}/{integration}/{config_hash_short}/{run_id}/
            manifest.json
            state.json
            eval_report.json      (written separately after eval)
            artifacts/
                *.json
            steps/
                {step}-{attempt}/
                    output.json   (always uploaded)
                    input.json    (always uploaded)
                    logs/agent.log  (only if DD_APM_S3_UPLOAD_LOGS=1)
    """

    def __init__(self, bucket: str = _BUCKET, prefix: str = _PREFIX) -> None:
        self.bucket = bucket
        self.prefix = prefix.rstrip("/")
        self._client = None

    @classmethod
    def from_env(cls) -> "S3RunStorage":
        """Create storage client.

        S3 sync is always on. Auth is lazy — checked on first operation.
        If credentials are unavailable, individual operations fail gracefully
        (callers wrap in try/except).
        """
        return cls()

    @property
    def client(self):
        """Lazy boto3 client init."""
        if self._client is None:
            self._client = _make_boto3_client()
        return self._client

    def _run_prefix(self, manifest: "RunManifest") -> str:
        config_hash_short = manifest.config.run_config_hash[:8] or "nohash"
        return (
            f"{self.prefix}/{manifest.repository}/{manifest.integration}"
            f"/{config_hash_short}/{manifest.run_id}"
        )

    def upload_step(
        self,
        analysis_dir: Path,
        step_name: str,
        attempt: int,
        manifest: "RunManifest",
        upload_logs: bool = False,
    ) -> None:
        """Upload a single step's outputs to S3. Called per-step for incremental sync.

        Args:
            analysis_dir: Local .analysis/{ns}/{wf}/ root.
            step_name: Step name (e.g., "analyze").
            attempt: Attempt number (e.g., 1).
            manifest: Partial manifest with run_id and routing info.
            upload_logs: Whether to upload agent.log (large, opt-in).
        """
        run_pfx = self._run_prefix(manifest)
        step_dir = analysis_dir / "steps" / f"{step_name}-{attempt}"
        if not step_dir.exists():
            return

        for fname in ("output.json", "input.json"):
            fpath = step_dir / fname
            if fpath.exists():
                key = f"{run_pfx}/steps/{step_name}-{attempt}/{fname}"
                self._upload_file(fpath, key)

        if upload_logs:
            log_path = step_dir / "logs" / "agent.log"
            if log_path.exists():
                key = f"{run_pfx}/steps/{step_name}-{attempt}/logs/agent.log"
                self._upload_file(log_path, key)

        # Also sync state.json so partial runs are recoverable
        state_path = analysis_dir / "state.json"
        if state_path.exists():
            self._upload_file(state_path, f"{run_pfx}/state.json")

        # Stamp s3_prefix and update index so partial runs are discoverable
        manifest.s3_prefix = run_pfx
        self._update_index(manifest)

    def upload_run(self, analysis_dir: Path, manifest: "RunManifest") -> Optional[str]:
        """Upload full run to S3. Returns S3 URI of manifest, or None if credentials unavailable.

        Uploads: manifest.json, state.json, artifacts/, steps/*/output.json + input.json.
        Agent logs only if DD_APM_S3_UPLOAD_LOGS=1.
        """
        if self.client is None:
            return None
        run_pfx = self._run_prefix(manifest)
        upload_logs = os.environ.get("DD_APM_S3_UPLOAD_LOGS", "") == "1"

        manifest_json = manifest.model_dump_json(indent=2)
        self.client.put_object(
            Bucket=self.bucket,
            Key=f"{run_pfx}/manifest.json",
            Body=manifest_json.encode(),
            ContentType="application/json",
        )

        for rel in ("state.json", "input.json", "output.json"):
            p = analysis_dir / rel
            if p.exists():
                self._upload_file(p, f"{run_pfx}/{rel}")

        artifacts_dir = analysis_dir / "artifacts"
        if artifacts_dir.exists():
            for f in artifacts_dir.iterdir():
                if f.is_file():
                    self._upload_file(f, f"{run_pfx}/artifacts/{f.name}")

        steps_dir = analysis_dir / "steps"
        if steps_dir.exists():
            for step_dir in steps_dir.iterdir():
                if not step_dir.is_dir():
                    continue
                for fname in ("output.json", "input.json"):
                    p = step_dir / fname
                    if p.exists():
                        self._upload_file(p, f"{run_pfx}/steps/{step_dir.name}/{fname}")
                if upload_logs:
                    log_p = step_dir / "logs" / "agent.log"
                    if log_p.exists():
                        self._upload_file(log_p, f"{run_pfx}/steps/{step_dir.name}/logs/agent.log")

        # Stamp s3_prefix so bootstrap can download this run later
        manifest.s3_prefix = run_pfx
        self._update_index(manifest)
        s3_uri = f"s3://{self.bucket}/{run_pfx}/"
        logger.info("Uploaded run to %s", s3_uri)
        return s3_uri

    def download_run(
        self,
        s3_prefix: str,
        local_dest: Path,
        selective: Optional[List[str]] = None,
    ) -> Path:
        """Download run data from S3 to local_dest.

        Args:
            s3_prefix: S3 key prefix for the run (e.g., runs/dd_trace_js/kafkajs/a1b2/run-id/).
            local_dest: Local directory to download into.
            selective: If given, only download these relative key suffixes
                       (e.g., ["steps/analyze-1/output.json"]).

        Returns:
            Path to local_dest.
        """
        if self.client is None:
            return local_dest
        local_dest.mkdir(parents=True, exist_ok=True)
        prefix = s3_prefix.rstrip("/") + "/"

        paginator = self.client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                rel = key[len(prefix) :]
                if selective and not any(rel == s or rel.startswith(s + "/") for s in selective):
                    continue
                dest_path = local_dest / rel
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                self.client.download_file(self.bucket, key, str(dest_path))

        return local_dest

    def pull_index(self) -> List[Any]:
        """Download the global index.json. Returns list of manifest dicts."""
        if self.client is None:
            return []
        try:
            response = self.client.get_object(Bucket=self.bucket, Key=_INDEX_KEY)
            data = json.loads(response["Body"].read())
            return data if isinstance(data, list) else []
        except Exception as exc:
            if "NoSuchKey" not in type(exc).__name__ and "NoSuchKey" not in str(exc):
                logger.debug("Failed to pull experience index: %s", exc)
            return []

    def list_runs(
        self,
        repository: Optional[str] = None,
        integration: Optional[str] = None,
        run_config_hash: Optional[str] = None,
        branch: Optional[str] = None,
        limit: int = 20,
    ) -> List[RunManifest]:
        """List runs, optionally filtered by repository, integration, config hash, or branch.

        Returns newest runs first (by timestamp), up to ``limit`` entries.
        All filters are optional — omit to list all runs.
        """
        index = self.pull_index()
        results = []
        for entry in index:
            if repository and entry.get("repository") != repository:
                continue
            if integration and entry.get("integration") != integration:
                continue
            if run_config_hash and not entry.get("config", {}).get(
                "run_config_hash", ""
            ).startswith(run_config_hash):
                continue
            if branch and entry.get("branch") != branch:
                continue
            try:
                results.append(RunManifest.model_validate(entry))
            except Exception:
                logger.debug("Skipping malformed manifest entry: %s", entry.get("run_id", "?"))
                continue
        # Sort newest first so the limit returns the most recent runs.
        results.sort(key=lambda r: r.timestamp, reverse=True)
        return results[:limit]

    def upload_eval_report(self, s3_run_uri: str, eval_report: dict) -> None:
        """Attach an eval report to an existing S3 run."""
        if self.client is None:
            return
        prefix = s3_run_uri.removeprefix(f"s3://{self.bucket}/").strip("/")
        key = f"{prefix}/eval_report.json"
        self.client.put_object(
            Bucket=self.bucket,
            Key=key,
            Body=json.dumps(eval_report, indent=2, default=str).encode(),
            ContentType="application/json",
        )
        logger.info("Uploaded eval report to s3://%s/%s", self.bucket, key)

    def upload_dir(self, local_dir: Path, s3_prefix: str) -> None:
        """Upload all files under local_dir to s3://{bucket}/{s3_prefix}/.

        Args:
            local_dir: Local directory whose contents to upload.
            s3_prefix: S3 key prefix (without trailing slash).
        """
        if self.client is None:
            logger.info("S3 upload skipped (no credentials): s3://%s/%s/", self.bucket, s3_prefix)
            return
        logger.info("S3 upload: %s -> s3://%s/%s/", local_dir, self.bucket, s3_prefix)
        try:
            for f in local_dir.rglob("*"):
                if not f.is_file():
                    continue
                rel = f.relative_to(local_dir)
                key = f"{s3_prefix}/{rel}"
                self._upload_file(f, key)
            logger.info("S3 upload complete: s3://%s/%s/", self.bucket, s3_prefix)
        except Exception as e:
            logger.warning("S3 upload failed (non-fatal): %s", e)

    def _upload_file(self, local_path: Path, s3_key: str) -> None:
        if self.client is None:
            return
        self.client.upload_file(str(local_path), self.bucket, s3_key)
        logger.debug("Uploaded %s -> s3://%s/%s", local_path.name, self.bucket, s3_key)

    def _update_index(self, manifest: "RunManifest") -> None:
        """Add or update the manifest entry in the global index.json."""
        if self.client is None:
            return
        index = self.pull_index()
        entry = json.loads(manifest.model_dump_json())
        index = [e for e in index if e.get("run_id") != manifest.run_id]
        index.append(entry)
        self.client.put_object(
            Bucket=self.bucket,
            Key=_INDEX_KEY,
            Body=json.dumps(index, indent=2, default=str).encode(),
            ContentType="application/json",
        )
