"""IntegrationGenTask — per-package driver for the integration-gen eval.

Owns the per-task lifecycle: instantiates :class:`IntegrationGenEvalWorkflow`,
runs it, and on completion (success or failure) persists run logs and tears
down the worktree.

Dry-run mode short-circuits the workflow entirely — it only validates that
evalya's baseline tracer passes all scenarios, no worktree needed.
"""

import logging
import os
import time
from pathlib import Path
from typing import Any, Optional, cast

from anubis.core.git import cleanup_worktree, get_git_branch
from anubis.eval.base import EvalItem, EvalSuite
from anubis.eval.models import EvalResult
from anubis_apm.evalya import EvalyaScenarioResult, run_evalya
from anubis_apm.repo_adapters.base import APMAdapterMixin

from .models import FinalEvalOutput, IntegrationGenEvalInput, IntegrationGenResult
from .storage import load_bundled_package_metadata, save_run_logs
from .workflow import IntegrationGenEvalWorkflow

logger = logging.getLogger(__name__)


class IntegrationGenTask:
    """``EvalTask`` that runs the full integration-gen workflow + evalya oracle."""

    def __init__(
        self,
        adapter: APMAdapterMixin,
        repo_root: Path,
        keep_worktree: bool = False,
        dry_run: bool = False,
    ) -> None:
        self.adapter = adapter
        self.repo_root = repo_root
        self.keep_worktree = keep_worktree
        self.dry_run = dry_run

    def run(self, item: EvalItem) -> EvalResult:
        package = item.name
        if self.dry_run:
            return _to_eval_result(_dry_run(package, self.adapter, item.metadata))
        return _to_eval_result(self._run_full(package, item.metadata))

    def _run_full(self, package: str, metadata: dict[str, Any]) -> IntegrationGenResult:
        """Drive the eval workflow end-to-end and persist run logs."""
        repository = self.adapter.get_repository_id()
        start_time = time.monotonic()

        # @workflow decorator transforms the class at runtime; mypy can't see it
        wf = cast(Any, IntegrationGenEvalWorkflow)(
            namespace=package,
            repository=repository,
            headless=True,
        )

        worktree_path: Optional[Path] = None
        run_id = ""
        result: IntegrationGenResult
        try:
            wf_result = wf.run(
                IntegrationGenEvalInput(
                    package=package,
                    repository=repository,
                    repo_root=str(self.repo_root),
                    maven_coordinates=(
                        metadata.get("analysis_maven_coordinates")
                        or metadata.get("maven_coordinates")
                        or None
                    ),
                    target_version=metadata.get("target_version") or None,
                    keep_worktree=self.keep_worktree,
                )
            )
            wp = wf.ctx.get("worktree_path", "") if hasattr(wf, "ctx") else ""
            run_id = wf.ctx.get("run_id", "") if hasattr(wf, "ctx") else ""
            if wp:
                worktree_path = Path(wp)

            if wf_result.success and wf_result.output:
                result = cast(FinalEvalOutput, wf_result.output).result
            else:
                result = IntegrationGenResult(
                    package=package,
                    repository=repository,
                    oracle="evalya",
                    error=wf_result.error or "Eval workflow failed",
                    duration_s=time.monotonic() - start_time,
                )
        except Exception as exc:
            logger.error("Integration-gen eval failed for %s: %s", package, exc, exc_info=True)
            result = IntegrationGenResult(
                package=package,
                repository=repository,
                oracle="evalya",
                error=str(exc),
                duration_s=time.monotonic() - start_time,
            )
        finally:
            if worktree_path is not None:
                save_run_logs(
                    worktree_path=worktree_path,
                    package=package,
                    repo=repository,
                    eval_name="integration-gen",
                    run_id=run_id or "unknown",
                    result_json=result.model_dump_json(indent=2),
                    workflow_base_dir=Path(wf.ctx.base_dir) if hasattr(wf, "ctx") else None,
                )
                if not self.keep_worktree:
                    cleanup_worktree(self.repo_root, worktree_path)
        return result


def _dry_run(
    package: str, adapter: APMAdapterMixin, metadata: Optional[dict[str, Any]] = None
) -> IntegrationGenResult:
    """Precheck-only path: validate evalya defs without spinning a worktree."""
    repository = adapter.get_repository_id()
    start_time = time.monotonic()
    def_path = adapter.get_evalya_def_path(package)
    task = adapter.get_evalya_task(package)
    oracle = "evalya" if def_path else "unit_tests"

    if oracle != "evalya" or not def_path:
        return IntegrationGenResult(
            package=package,
            repository=repository,
            oracle=oracle,
            error="No evalya def — package not supported for dry-run",
            duration_s=time.monotonic() - start_time,
        )

    # Verify the *baseline* tracer (baked into evalya's app image) passes all
    # scenarios. Intentionally no TRACER_DIR overlay: optional file mounts in
    # evalya defs can fail when local source is newer than the baked-in image.
    pre = run_evalya(def_path, task, tracer_dir=None)
    passed = (
        not pre.error and pre.scenarios_total > 0 and pre.scenarios_passing == pre.scenarios_total
    )
    error = pre.error or (
        "no scenarios found — check evalya def" if pre.scenarios_total == 0 else ""
    )
    if error and pre.raw_output:
        error = f"{error}\n\n--- evalya raw output (last 3000 chars) ---\n{pre.raw_output[-3000:]}"
    scenarios = [
        EvalyaScenarioResult(scenario=s.scenario, passed=s.passed) for s in (pre.scenarios or [])
    ]
    return IntegrationGenResult(
        package=package,
        repository=repository,
        oracle=oracle,
        evalya_pre_check=passed,
        evalya_precheck_scenarios_total=pre.scenarios_total,
        evalya_precheck_scenarios_passing=pre.scenarios_passing,
        evalya_scenarios=scenarios,
        evalya_exit_code=pre.exit_code,
        evalya_output_tail=pre.output_tail,
        target_version=(metadata or {}).get("target_version", ""),
        success=passed,
        error=error,
        duration_s=time.monotonic() - start_time,
    )


def _to_eval_result(r: IntegrationGenResult) -> EvalResult:
    """Convert an IntegrationGenResult to a generic EvalResult."""
    if r.oracle == "evalya":
        scenarios_total = r.evalya_scenarios_total
        scenarios_passing = r.evalya_scenarios_passing
        pass_rate = scenarios_passing / scenarios_total if scenarios_total > 0 else None
        pre_total = r.evalya_precheck_scenarios_total
        pre_passing = r.evalya_precheck_scenarios_passing
        precheck_rate = pre_passing / pre_total if pre_total > 0 else None
        metrics: dict[str, float | None] = {
            "scenarios_passing": float(scenarios_passing),
            "scenarios_total": float(scenarios_total),
            "pass_rate": pass_rate,
            "precheck_scenarios_passing": float(pre_passing),
            "precheck_scenarios_total": float(pre_total),
            "precheck_pass_rate": precheck_rate,
            "pre_check": float(r.evalya_pre_check),
        }
    else:
        tests_total = r.unit_tests_total
        tests_passing = r.unit_tests_passing
        pass_rate = tests_passing / tests_total if tests_total > 0 else None
        metrics = {
            "scenarios_passing": float(tests_passing),
            "scenarios_total": float(tests_total),
            "pass_rate": pass_rate,
        }

    metrics["turn_count"] = float(r.turn_count) if r.turn_count else None
    metrics["input_tokens"] = float(r.input_tokens) if r.input_tokens else None
    metrics["output_tokens"] = float(r.output_tokens) if r.output_tokens else None
    metrics["cache_read_input_tokens"] = (
        float(r.cache_read_input_tokens) if r.cache_read_input_tokens else None
    )
    metrics["cost_usd"] = float(r.cost_usd) if r.cost_usd else None

    tags = {
        "oracle": r.oracle,
        "repository": r.repository,
        "model": r.model or os.environ.get("ANTHROPIC_MODEL", "sonnet"),
        "branch": get_git_branch(),
        **({"target_version": r.target_version} if r.target_version else {}),
    }

    return EvalResult(
        name=r.package,
        metrics=metrics,
        tags=tags,
        status="ok" if r.success else ("error" if r.error else "fail"),
        cost_usd=r.cost_usd,
        duration_s=r.duration_s,
        error=r.error,
    )


def build_integration_gen_suite(
    adapter: APMAdapterMixin,
    repo_root: Path,
    packages: Optional[list[str]] = None,
    keep_worktree: bool = False,
    dry_run: bool = False,
    concurrency: int = 0,
) -> EvalSuite:
    """Build an EvalSuite for integration-gen eval."""
    pkg_list = packages or adapter.get_evalya_packages()
    task = IntegrationGenTask(
        adapter=adapter,
        repo_root=repo_root,
        keep_worktree=keep_worktree,
        dry_run=dry_run,
    )
    repository = adapter.get_repository_id()
    items = [
        EvalItem(name=p, metadata=load_bundled_package_metadata(repository, p)) for p in pkg_list
    ]
    return EvalSuite(
        name="integration-gen",
        items=items,
        task=task,
        concurrency=concurrency,
    )
