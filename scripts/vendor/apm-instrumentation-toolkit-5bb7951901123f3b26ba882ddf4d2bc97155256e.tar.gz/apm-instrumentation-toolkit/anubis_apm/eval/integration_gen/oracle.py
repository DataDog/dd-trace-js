"""Oracle execution helpers for integration-gen eval steps."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Optional

from anubis.core.context import Context
from anubis_apm.evalya import EvalyaRunResult, EvalyaScenarioResult, run_evalya
from anubis_apm.evalya import diagnostics as evalya_diagnostics
from anubis_apm.evalya.constants import KNOWN_MISMATCH_OUTPUT_MARKER
from anubis_apm.repo_adapters import get_apm_adapter
from anubis_apm.repo_adapters.base import APMAdapterMixin, TestRunResult

from .models import IntegrationGenResult, OracleRunOutput

EVALYA_STRICT_ENV = {"FTF_FAIL_KNOWN_MISMATCHES": "true"}

OraclePhase = Literal["precheck", "post_deletion", "final"]

_PHASE_LABELS: dict[OraclePhase, str] = {
    "precheck": "Precheck",
    "post_deletion": "Post-deletion",
    "final": "Oracle final",
}


@dataclass
class OracleRun:
    """Normalized result from either evalya or the unit-test fallback."""

    oracle: str
    total: int = 0
    passing: int = 0
    scenarios: list[EvalyaScenarioResult] = field(default_factory=list)
    evalya_exit_code: Optional[int] = None
    evalya_output_log: str = ""
    evalya_output_tail: str = ""
    error: str = ""
    unit_test_filter: str = ""
    evalya_result: Optional[EvalyaRunResult] = None
    unit_test_result: Optional[TestRunResult] = None

    def to_step_output(self) -> OracleRunOutput:
        return OracleRunOutput(
            scenarios_total=self.total,
            scenarios_passing=self.passing,
            scenarios=self.scenarios,
            evalya_exit_code=self.evalya_exit_code,
            evalya_output_log=self.evalya_output_log,
            evalya_output_tail=self.evalya_output_tail,
            error=self.error,
        )

    def format_failure(self, message: str) -> str:
        if self.evalya_result is not None:
            return evalya_diagnostics.format_failure(
                message,
                self.evalya_result,
                self.evalya_output_log,
            )
        if self.unit_test_result is not None:
            return _format_unit_test_failure(message, self.unit_test_result)
        return message


def run_oracle(ctx: Context, phase: OraclePhase) -> OracleRun:
    """Run the configured oracle for a workflow phase."""
    if ctx.get("oracle") == "evalya":
        return _run_evalya_oracle(ctx, phase)
    return _run_unit_test_oracle(ctx, phase)


def evalya_strict_error(result: EvalyaRunResult) -> str:
    """Reject soft mismatches if the remote task ignored strict mode."""
    if KNOWN_MISMATCH_OUTPUT_MARKER in result.raw_output:
        return "evalya reported known tag mismatches while strict mode was required"
    return ""


def require_precheck_passed(run: OracleRun) -> None:
    if run.error:
        raise RuntimeError(run.format_failure("Precheck evalya errored"))
    if run.total == 0:
        if run.oracle == "unit_tests":
            message = (
                "Precheck unit_tests produced 0 tests. The unit-test oracle "
                "cannot prove the existing integration works."
            )
        else:
            message = "Precheck: 0 scenarios collected - check evalya def is valid"
        raise RuntimeError(run.format_failure(message))
    if run.passing != run.total:
        if run.oracle == "unit_tests":
            message = (
                f"Precheck unit_tests only passed {run.passing}/{run.total}. Fix the "
                f"existing integration tests before running this eval."
            )
        else:
            message = (
                f"Precheck: only {run.passing}/{run.total} scenarios pass on the "
                f"baseline tracer - fix the existing integration before eval"
            )
        raise RuntimeError(run.format_failure(message))


def require_post_deletion_failed(run: OracleRun, pre_total: int) -> None:
    if run.total == 0:
        if run.oracle == "unit_tests":
            message = (
                f"Post-deletion unit_tests produced 0 tests (pre-check had {pre_total}). "
                f"This is an eval runtime failure, not coverage proof."
            )
        else:
            message = (
                f"Post-deletion evalya produced 0 parseable scenarios "
                f"(pre-check had {pre_total}). This is an eval runtime failure, "
                f"not coverage proof."
            )
        raise RuntimeError(run.format_failure(message))

    if pre_total and run.total != pre_total:
        if run.oracle == "unit_tests":
            message = (
                f"Post-deletion unit_tests ran {run.total} tests, but pre-check ran "
                f"{pre_total}. This means the oracle did not run the same contract set "
                f"before and after deletion."
            )
        else:
            message = (
                f"Post-deletion evalya collected {run.total} scenarios, but pre-check "
                f"collected {pre_total}. This means the oracle did not run the same "
                f"contract set before and after deletion."
            )
        raise RuntimeError(run.format_failure(message))

    if run.passing == run.total:
        if run.oracle == "unit_tests":
            message = (
                f"Post-deletion unit_tests still passed {run.passing}/{run.total} - the "
                f"tests don't exercise the deleted integration, the eval is meaningless. "
                f"Add tests that depend on the integration or remove this package from "
                f"the matrix."
            )
        else:
            message = (
                f"Post-deletion evalya still passed {run.passing}/{run.total} - the test "
                f"doesn't exercise the deleted integration, the eval is meaningless. Add "
                f"scenarios that depend on the integration or remove this package from "
                f"the matrix."
            )
        raise RuntimeError(run.format_failure(message))


def build_final_result(
    ctx: Context,
    run: OracleRun,
    metrics: dict,
    workflow_error: str,
    duration_s: float,
) -> IntegrationGenResult:
    """Convert final oracle output plus workflow metrics into the eval result."""
    package = ctx.namespace
    repository = ctx.repository
    pre_total = ctx.get("precheck_total", 0)
    pre_passing = ctx.get("precheck_passing", 0)
    target_version = ctx.get("target_version") or ""
    oracle_error = _final_oracle_error(run, pre_total)
    success = run.total > 0 and run.passing == run.total and not oracle_error and not workflow_error

    if run.oracle == "evalya":
        _log_final_evalya(ctx, run, oracle_error, success)
        return IntegrationGenResult(
            package=package,
            repository=repository,
            oracle="evalya",
            target_version=target_version,
            evalya_pre_check=True,
            evalya_precheck_scenarios_total=pre_total,
            evalya_precheck_scenarios_passing=pre_passing,
            evalya_scenarios_total=run.total,
            evalya_scenarios_passing=run.passing,
            evalya_scenarios=run.scenarios,
            evalya_exit_code=run.evalya_exit_code,
            evalya_output_log=run.evalya_output_log,
            evalya_output_tail=run.evalya_output_tail,
            workflow_steps_completed=metrics.get("steps_completed", 0),
            turn_count=metrics.get("turn_count", 0),
            cost_usd=metrics.get("cost_usd", 0.0),
            input_tokens=metrics.get("input_tokens", 0),
            output_tokens=metrics.get("output_tokens", 0),
            cache_read_input_tokens=metrics.get("cache_read_tokens", 0),
            duration_s=duration_s,
            model=metrics.get("model", ""),
            success=success,
            error=workflow_error or oracle_error,
        )

    if oracle_error:
        ctx.warn(run.format_failure(oracle_error))
    elif run.passing != run.total:
        ctx.warn(run.format_failure(f"Oracle final unit_tests failed: {run.passing}/{run.total}"))

    return IntegrationGenResult(
        package=package,
        repository=repository,
        oracle="unit_tests",
        target_version=target_version,
        unit_tests_total=run.total,
        unit_tests_passing=run.passing,
        unit_test_filter=run.unit_test_filter,
        workflow_steps_completed=metrics.get("steps_completed", 0),
        turn_count=metrics.get("turn_count", 0),
        cost_usd=metrics.get("cost_usd", 0.0),
        input_tokens=metrics.get("input_tokens", 0),
        output_tokens=metrics.get("output_tokens", 0),
        cache_read_input_tokens=metrics.get("cache_read_tokens", 0),
        duration_s=duration_s,
        model=metrics.get("model", ""),
        success=success,
        error=workflow_error or oracle_error,
    )


def _run_evalya_oracle(ctx: Context, phase: OraclePhase) -> OracleRun:
    def_path = ctx.get("def_path")
    task = ctx.get("task")
    worktree_path = Path(ctx.get("worktree_path"))
    adapter = get_apm_adapter(ctx.repository)
    tracer_dir: Optional[Path] = None
    container_env: dict[str, str] = {}
    label = _PHASE_LABELS[phase]

    if phase == "precheck":
        ctx.info(f"{label}: evalya baseline (no TRACER_DIR overlay)")
    else:
        if phase == "final":
            tracer_dir, container_env = adapter.prepare_evalya_overlay(worktree_path)
        else:
            tracer_dir, container_env = adapter.prepare_post_deletion_evalya_overlay(worktree_path)
        ctx.set("evalya_tracer_dir", str(tracer_dir))
        ctx.info(f"{label}: evalya TRACER_DIR={tracer_dir}")

    strict_env = EVALYA_STRICT_ENV if phase == "final" else {}
    container_env.update(strict_env)
    ctx.set("evalya_container_env", container_env)

    res = run_evalya(
        def_path,
        task,
        tracer_dir=tracer_dir,
        extra_env=strict_env,
        container_env=container_env,
    )
    log_path = evalya_diagnostics.record_output(ctx, phase, res)
    evalya_diagnostics.log_result(ctx, phase, res, log_path)
    return OracleRun(
        oracle="evalya",
        total=res.scenarios_total,
        passing=res.scenarios_passing,
        scenarios=res.scenarios or [],
        evalya_exit_code=res.exit_code,
        evalya_output_log=log_path,
        evalya_output_tail=evalya_diagnostics.output_tail(res),
        error=res.error or (evalya_strict_error(res) if phase == "final" else ""),
        evalya_result=res,
    )


def _run_unit_test_oracle(ctx: Context, phase: OraclePhase) -> OracleRun:
    package = ctx.namespace
    repository = ctx.repository
    worktree_path = Path(ctx.get("worktree_path"))
    repo_root = Path(ctx.get("repo_root"))
    adapter = get_apm_adapter(repository)
    filter_pattern = _get_unit_test_filter(adapter, package)
    label = _PHASE_LABELS[phase]

    ctx.info(f"{label}: unit_tests filter='{filter_pattern}'")
    test_result = adapter.run_filtered_tests(
        package,
        filter_pattern,
        worktree_path,
        timeout=300,
        source_repo=repo_root,
    )
    ctx.info(f"{label}: unit_tests {test_result.tests_passing}/{test_result.tests_total} passing")
    return OracleRun(
        oracle="unit_tests",
        total=test_result.tests_total,
        passing=test_result.tests_passing,
        unit_test_filter=filter_pattern,
        unit_test_result=test_result,
    )


def _get_unit_test_filter(adapter: APMAdapterMixin, package: str) -> str:
    filter_pattern = adapter.get_integration_gen_unit_test_filter(package)
    if not filter_pattern:
        raise RuntimeError(
            f"No evalya def exists for {package}/{adapter.get_repository_id()}, and "
            f"the adapter does not define an integration-gen unit-test oracle. "
            f"Add an evalya def or implement get_integration_gen_unit_test_filter() "
            f"for this repository/package."
        )
    return filter_pattern


def _final_oracle_error(run: OracleRun, pre_total: int) -> str:
    if run.error:
        return run.error
    if run.total == 0:
        noun = (
            "evalya produced 0 parseable scenarios"
            if run.oracle == "evalya"
            else "unit_tests produced 0 tests"
        )
        return f"Oracle final {noun}"
    if pre_total and run.total != pre_total:
        if run.oracle == "evalya":
            return (
                f"Oracle final evalya collected {run.total} scenarios, but pre-check "
                f"collected {pre_total}. The final oracle did not run the same "
                f"contract set as the baseline."
            )
        return (
            f"Oracle final unit_tests ran {run.total} tests, but pre-check ran "
            f"{pre_total}. The final oracle did not run the same contract set "
            f"as the baseline."
        )
    return ""


def _log_final_evalya(
    ctx: Context,
    run: OracleRun,
    oracle_error: str,
    success: bool,
) -> None:
    if oracle_error:
        ctx.warn(run.format_failure("Oracle final evalya errored"))
    elif run.passing != run.total:
        ctx.warn(
            run.format_failure(
                f"Oracle final evalya failed scenarios: {run.passing}/{run.total} passing"
            )
        )
    ctx.info(f"Oracle: {run.passing}/{run.total} -> {'PASS' if success else 'FAIL'}")


def _format_unit_test_failure(message: str, test_result: TestRunResult) -> str:
    parts = [message]
    if test_result.command:
        parts.append(f"command: {test_result.command}")
    tail = _test_output_tail(test_result.raw_output)
    if tail:
        parts.append(f"--- unit test output tail ---\n{tail}")
    return "\n".join(parts)


def _test_output_tail(raw_output: str, max_lines: int = 80) -> str:
    lines = raw_output.splitlines()
    return "\n".join(lines[-max_lines:])
