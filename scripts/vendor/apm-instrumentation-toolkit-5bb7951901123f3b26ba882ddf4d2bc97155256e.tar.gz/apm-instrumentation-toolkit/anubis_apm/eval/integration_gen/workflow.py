"""Integration-gen eval workflow.

Runs the full per-package eval pipeline as a single anubis workflow so the
entire flow (setup → precheck → deletion → post-deletion verify →
integration generation → final oracle) shows up under one APM trace tree
with per-step metrics, logs and resumability.
"""

from anubis import WorkflowConfig, workflow

from .steps import (
    apply_seed_step,
    eval_setup_step,
    oracle_final_step,
    oracle_post_deletion_step,
    oracle_precheck_step,
    remove_integration_step,
    run_new_integration_step,
)


@workflow(
    WorkflowConfig(
        name="integration_gen_eval",
        steps=[
            eval_setup_step,
            oracle_precheck_step,
            remove_integration_step,
            oracle_post_deletion_step,
            apply_seed_step,
            run_new_integration_step,
            oracle_final_step,
        ],
    )
)
class IntegrationGenEvalWorkflow:
    """E2E integration-gen eval as a single workflow.

    Pipeline:
      eval_setup → oracle_precheck → remove_integration → oracle_post_deletion
      → apply_seed → run_new_integration (nested) → oracle_final
    """
