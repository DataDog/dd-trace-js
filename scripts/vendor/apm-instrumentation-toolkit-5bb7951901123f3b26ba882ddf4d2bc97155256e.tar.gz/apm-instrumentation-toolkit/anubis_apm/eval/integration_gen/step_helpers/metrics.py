"""Aggregate cost / token / turn metrics from a nested new_integration run."""

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def load_workflow_metrics(package: str, worktree_path: Path) -> dict:
    """Load metrics from ``{worktree}/.analysis/{package}/new_integration/state.json``.

    Returns an empty dict if the state file isn't there (workflow didn't run
    or failed before writing state) — callers should fall back to defaults.
    """
    state_file = worktree_path / ".analysis" / package / "new_integration" / "state.json"
    if not state_file.exists():
        return {}
    try:
        state = json.loads(state_file.read_text())
        steps = state.get("steps", {})
        total_turns = sum(s.get("metrics", {}).get("num_turns", 0) for s in steps.values())
        model = ""
        for s in steps.values():
            for run in s.get("metrics", {}).get("agent_runs", []):
                if run.get("model"):
                    model = run["model"]
                    break
            if model:
                break
        return {
            "steps_completed": len(steps),
            "turn_count": total_turns,
            "cost_usd": state.get("total_cost_usd", 0.0),
            "input_tokens": state.get("total_input_tokens", 0),
            "output_tokens": state.get("total_output_tokens", 0),
            "cache_read_tokens": state.get("total_cache_read_input_tokens", 0),
            "model": model,
        }
    except Exception as exc:
        logger.debug("Could not load workflow metrics: %s", exc)
        return {}
