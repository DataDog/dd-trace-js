"""Render the eval-mode user prompt for the agent-driven test/fixer loop."""

from pathlib import Path
from typing import Optional, Sequence


def build_eval_user_prompt(
    package: str,
    def_path: Optional[str],
    target_package: Optional[str],
    removed_paths: Sequence[str] | None = None,
) -> str:
    """Render ``prompts/eval_user_prompt.md`` for the given package.

    Tells the agent that evalya — not the tracer's own unit tests — is the
    acceptance oracle, and how to interpret behave scenario output.

    Returns the empty string when there's no evalya def (unit_tests oracle
    fallback path) — the workflow then runs without an injected user prompt.
    """
    if not def_path:
        return ""
    target = target_package or package
    removed_paths_note = ""
    if removed_paths:
        paths = "\n".join(f"- `{path}`" for path in removed_paths)
        removed_paths_note = f"""

**Blind-deleted integration locations:**
{paths}

Use these deleted paths as the source of truth for where this integration belongs in the tracer repo. Recreate instrumentation under the same module path(s) and update shared registry files as needed; do not infer a new module directory from the package version.
"""
    template_path = Path(__file__).resolve().parent.parent / "prompts" / "eval_user_prompt.md"
    return template_path.read_text().format(
        package=package,
        target_note=f"`{target}`",
        removed_paths_note=removed_paths_note,
    )
