**Eval mode — `{package}` integration (evalya oracle)**

You are generating a dd-trace instrumentation for {target_note}. The acceptance criterion is the **evalya integration test suite**, not dd-trace unit tests. Use the provided evalya command exactly as your test command — do NOT reconstruct `TRACER_DIR`, jar paths, mount paths, or fall back to running the tracer's own unit tests directly.
{removed_paths_note}

**How to read evalya output:**
- evalya launches real Docker containers that run a sample app using {target_note}.
- The containers stream their stdout/stderr through evalya (prefixed with `task_id[stdout]`). This inner output is diagnostic — it helps you understand *why* a scenario failed, but it is NOT the acceptance criterion.
- The acceptance criterion is the **behave scenario summary** at the end of the evalya output. Look for lines like:
  ```
  N scenarios passed, M failed
  ```
  or individual scenario headers:
  ```
  Scenario: <name>  # features/xxx.feature:NN
  ```
- **Your integration is complete only when all scenarios pass** (0 failed). Even if the inner container output shows passing tests, that is not success if evalya still reports failing scenarios.

**Instrumentation guidance:**
- Each evalya scenario exercises a real {target_note} operation (e.g. a SQL query, an HTTP call, a cache GET) and verifies that APM spans are produced with correct tags (service, resource, span.kind, db.type, etc.).
- If a scenario fails, read the container output to understand which operation was called and what span data was expected vs. received.
- Focus instrumentation on the methods that are actually called during those operations — wrapping the wrong method will produce no spans or wrong spans.
