"""Steps for the integration-gen eval workflow.

Pipeline (each step persists output + logs under ``.analysis/.../steps/<name>/``):

  eval_setup           — resolve oracle config, spin up isolated git worktree
  oracle_precheck      — baseline oracle must pass before deletion
  remove_integration   — adapter.remove_integration; must return >0 paths
  oracle_post_deletion — oracle MUST fail after deletion; disambiguates
                         "tracer broken" vs "test doesn't exercise integration"
  apply_seed           — seed analyze state so the nested workflow skips it
  run_new_integration  — nested new_integration workflow (the $$ agent step)
  oracle_final         — final oracle measurement → IntegrationGenResult

Validity-gate steps (precheck, remove, post_deletion) raise on failure so
the workflow halts and the trace shows where the eval bailed.
"""

import logging
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from anubis import StepConfig, step
from anubis.core.context import Context
from anubis.core.git import create_worktree
from anubis_apm.evalya.constants import EVALYA_OCI_CONTEXT
from anubis_apm.repo_adapters import get_apm_adapter
from anubis_apm.workflows.new_integration.workflow import create_integration

from .models import (
    ApplySeedOutput,
    EvalSetupOutput,
    FinalEvalOutput,
    IntegrationGenEvalInput,
    NewIntegrationStepOutput,
    OracleRunOutput,
    RemoveIntegrationOutput,
)
from .oracle import (
    EVALYA_STRICT_ENV,
    build_final_result,
    require_post_deletion_failed,
    require_precheck_passed,
    run_oracle,
)
from .step_helpers import build_eval_user_prompt, load_workflow_metrics
from .storage import apply_seed, compute_seed_hash

logger = logging.getLogger(__name__)


# Steps skipped inside the nested new_integration workflow. The test/fixer
# loop replaces the eval oracle; lint/reviewer don't affect oracle pass/fail.
_EVAL_SKIP_STEPS = {
    "generate_app",
    "validate_app",
    "context_mapping",
    "review",
    "test_scaffold",
    "feature",
    "lint",
    "reviewer",
}


@step(StepConfig(name="eval_setup", output_type=EvalSetupOutput))
def eval_setup_step(input: IntegrationGenEvalInput, ctx: Context) -> EvalSetupOutput:
    """Resolve oracle config and spin up an isolated git worktree."""
    repo_root = Path(input.repo_root)
    adapter = get_apm_adapter(input.repository)

    def_path = adapter.get_evalya_def_path(input.package)
    task = adapter.get_evalya_task(input.package)
    oracle = "evalya" if def_path else "unit_tests"
    target_package = adapter.get_evalya_target_package(input.package) or input.package

    run_id = str(uuid.uuid4())[:8]
    worktree_path = create_worktree(repo_root, f"integration-gen-eval-{input.package}-{run_id}")
    adapter.prepare_eval_worktree(worktree_path, def_path)

    ctx.info(f"Setup: oracle={oracle} def_path={def_path or '(none)'} worktree={worktree_path}")
    if input.maven_coordinates:
        ctx.info(f"Setup: maven_coordinates={input.maven_coordinates}")
    if input.target_version:
        ctx.info(f"Setup: target_version={input.target_version}")

    ctx.set("repo_root", str(repo_root))
    ctx.set("worktree_path", str(worktree_path))
    ctx.set("def_path", def_path)
    ctx.set("task", task)
    ctx.set("oracle", oracle)
    ctx.set("target_package", target_package)
    ctx.set("run_id", run_id)
    ctx.set("start_time", time.monotonic())
    if input.maven_coordinates:
        ctx.set("maven_coordinates", input.maven_coordinates)
    if input.target_version:
        ctx.set("target_version", input.target_version)

    return EvalSetupOutput(
        worktree_path=str(worktree_path),
        def_path=def_path,
        task=task,
        oracle=oracle,
        target_package=target_package,
    )


@step(StepConfig(name="oracle_precheck", output_type=OracleRunOutput))
def oracle_precheck_step(input: Any, ctx: Context) -> OracleRunOutput:
    """Baseline oracle must pass before deletion.

    Otherwise there's no ground truth to evaluate the regenerated integration
    against.
    """
    run = run_oracle(ctx, "precheck")
    require_precheck_passed(run)
    ctx.info(f"Precheck: {run.passing}/{run.total} passing")
    ctx.set("precheck_passing", run.passing)
    ctx.set("precheck_total", run.total)
    return run.to_step_output()


@step(StepConfig(name="remove_integration", output_type=RemoveIntegrationOutput))
def remove_integration_step(input: Any, ctx: Context) -> RemoveIntegrationOutput:
    """Delete the existing integration from the worktree.

    Raises if the adapter returns no paths — that means the integration was
    never on disk in the expected layout and the rest of the eval would be
    meaningless.
    """
    package = ctx.namespace
    worktree_path = Path(ctx.get("worktree_path"))
    adapter = get_apm_adapter(ctx.repository)

    ctx.info(f"Removing {package} from {worktree_path}")
    removed = list(adapter.remove_integration(package, worktree_path) or [])
    if not removed:
        raise RuntimeError(
            f"remove_integration returned no paths for {package}/{ctx.repository}. "
            f"The integration was not present at the expected layout under "
            f"{worktree_path} — check the adapter's remove_integration mapping."
        )

    for p in removed:
        ctx.info(f"  removed: {p}")
    ctx.set("removed_integration_paths", removed)
    return RemoveIntegrationOutput(removed_paths=removed)


@step(StepConfig(name="oracle_post_deletion", output_type=OracleRunOutput))
def oracle_post_deletion_step(input: Any, ctx: Context) -> OracleRunOutput:
    """Oracle against the worktree after deletion — must fail.

    Disambiguation:
      - 0 scenarios/tests collected: abort. This means the oracle did not reach
        parseable output, which is an eval infrastructure/app-startup failure.
      - All scenarios/tests pass: oracle doesn't exercise the deleted integration
        → abort, the eval would be meaningless.
      - Some/all scenarios/tests fail: integration coverage confirmed → proceed.
    """
    pre_total = ctx.get("precheck_total", 0)
    run = run_oracle(ctx, "post_deletion")
    require_post_deletion_failed(run, pre_total)
    ctx.info(
        f"Post-deletion: {run.passing}/{run.total} passing "
        f"(some failures — integration coverage confirmed)"
    )
    return run.to_step_output()


@step(StepConfig(name="apply_seed", output_type=ApplySeedOutput))
def apply_seed_step(input: Any, ctx: Context) -> ApplySeedOutput:
    """Seed analyze state from prior runs so the nested workflow skips analyze."""
    package = ctx.namespace
    repository = ctx.repository
    repo_root = Path(ctx.get("repo_root"))
    worktree_path = Path(ctx.get("worktree_path"))
    seed_hash = compute_seed_hash(package, repository)
    adapter = get_apm_adapter(repository)

    ctx.info(f"Applying seed (hash={seed_hash})")
    apply_seed(package, repository, "integration-gen", seed_hash, repo_root, worktree_path, adapter)
    ctx.set("seed_hash", seed_hash)
    return ApplySeedOutput(seed_hash=seed_hash)


@step(StepConfig(name="run_new_integration", output_type=NewIntegrationStepOutput))
def run_new_integration_step(input: Any, ctx: Context) -> NewIntegrationStepOutput:
    """Invoke the new_integration workflow against the worktree.

    Runs as a nested workflow so its spans nest under this step's trace span.
    """
    package = ctx.namespace
    repository = ctx.repository
    worktree_path = Path(ctx.get("worktree_path"))
    def_path = ctx.get("def_path")
    task = ctx.get("task")
    oracle = ctx.get("oracle")
    target_package = ctx.get("target_package")
    maven_coordinates = ctx.get("maven_coordinates") or None
    target_version = ctx.get("target_version") or None
    test_max_iter: int = ctx.get_config("eval_test_max_iterations", 5)

    eval_test_command: Optional[str] = None
    if oracle == "evalya" and def_path:
        eval_test_command = get_apm_adapter(repository).get_evalya_test_command(
            worktree_path,
            def_path,
            task,
            EVALYA_OCI_CONTEXT,
            extra_env=EVALYA_STRICT_ENV,
        )

    user_prompt = build_eval_user_prompt(
        package, def_path, target_package, ctx.get("removed_integration_paths") or []
    )
    ctx.info(f"Running new_integration workflow (max_iter={test_max_iter})")
    result = create_integration(
        integration=package,
        repository=repository,
        skip_steps=list(_EVAL_SKIP_STEPS),
        skip_review=True,
        headless=False,
        base_dir=worktree_path,
        user_prompt=user_prompt or None,
        eval_test_command=eval_test_command,
        maven_coordinates=maven_coordinates,
        target_version=target_version,
        blind=True,
        blind_repo_root=worktree_path,
        test_max_iterations=test_max_iter,
        ctx_overrides={
            "agent_eval_account": True,
            "removed_integration_paths": ctx.get("removed_integration_paths") or [],
        },
    )

    metrics = load_workflow_metrics(package, worktree_path)

    error = "" if result.success else (result.error or "Workflow failed (unknown error)")
    if error:
        ctx.warn(f"new_integration failed: {error}")

    # Stash for oracle_final to read without re-loading workflow state.
    ctx.set("new_integration_metrics", metrics)
    ctx.set("new_integration_error", error)

    return NewIntegrationStepOutput(
        success=result.success,
        error=error,
        workflow_steps_completed=metrics.get("steps_completed", 0),
        turn_count=metrics.get("turn_count", 0),
        cost_usd=metrics.get("cost_usd", 0.0),
        input_tokens=metrics.get("input_tokens", 0),
        output_tokens=metrics.get("output_tokens", 0),
        cache_read_input_tokens=metrics.get("cache_read_tokens", 0),
        model=metrics.get("model", ""),
    )


@step(StepConfig(name="oracle_final", output_type=FinalEvalOutput))
def oracle_final_step(input: Any, ctx: Context) -> FinalEvalOutput:
    """Final oracle measurement — produces the IntegrationGenResult reported by the matrix."""
    start_time = ctx.get("start_time", time.monotonic())
    metrics: dict = ctx.get("new_integration_metrics") or {}
    workflow_error = ctx.get("new_integration_error", "")
    oracle_run = run_oracle(ctx, "final")
    result = build_final_result(
        ctx,
        oracle_run,
        metrics,
        workflow_error,
        time.monotonic() - start_time,
    )
    return FinalEvalOutput(result=result)
