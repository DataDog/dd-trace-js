"""Models for the integration-gen eval workflow.

The workflow runs the full new_integration pipeline on a clean repo (existing
integration removed) and judges the output via evalya semantic contracts.
"""

from typing import List, Optional

from pydantic import BaseModel, Field

from anubis_apm.evalya import EvalyaScenarioResult

__all__ = [
    "IntegrationGenResult",
    "IntegrationGenEvalInput",
    "EvalSetupOutput",
    "OracleRunOutput",
    "RemoveIntegrationOutput",
    "ApplySeedOutput",
    "NewIntegrationStepOutput",
    "FinalEvalOutput",
]


# ---------------------------------------------------------------------------
# Domain result
# ---------------------------------------------------------------------------


class IntegrationGenResult(BaseModel):
    """Full result of a single integration-gen eval run."""

    package: str
    repository: str
    oracle: str = "evalya"  # "evalya" or "unit_tests"
    target_version: str = ""  # pinned package version tested (empty = unknown)

    # evalya oracle results
    evalya_pre_check: bool = False  # Was the pre-check green before deletion?
    # Pre-check (baseline tracer, before agent runs)
    evalya_precheck_scenarios_total: int = 0
    evalya_precheck_scenarios_passing: int = 0
    # Final oracle (post agent code generation)
    evalya_scenarios_total: int = 0
    evalya_scenarios_passing: int = 0
    evalya_scenarios: List[EvalyaScenarioResult] = Field(default_factory=list)
    evalya_exit_code: Optional[int] = None
    evalya_output_log: str = ""
    evalya_output_tail: str = ""

    # Unit-test fallback results (packages without evalya defs, e.g. kafkajs)
    unit_tests_total: int = 0
    unit_tests_passing: int = 0
    unit_test_filter: str = ""

    # Workflow metrics
    workflow_steps_completed: int = 0
    turn_count: int = 0
    cost_usd: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    duration_s: float = 0.0
    model: str = ""

    # Outcome
    success: bool = False
    error: str = ""


# ---------------------------------------------------------------------------
# Workflow I/O models
# ---------------------------------------------------------------------------


class IntegrationGenEvalInput(BaseModel):
    """Top-level workflow input — provided by the Task per package."""

    package: str
    repository: str
    repo_root: str
    maven_coordinates: Optional[str] = None
    target_version: Optional[str] = None
    keep_worktree: bool = False
    test_max_iterations: int = 5


class EvalSetupOutput(BaseModel):
    worktree_path: str
    def_path: Optional[str] = None
    task: str = "run"
    oracle: str = "evalya"
    target_package: Optional[str] = None


class OracleRunOutput(BaseModel):
    scenarios_total: int = 0
    scenarios_passing: int = 0
    scenarios: List[EvalyaScenarioResult] = []
    evalya_exit_code: Optional[int] = None
    evalya_output_log: str = ""
    evalya_output_tail: str = ""
    error: str = ""


class RemoveIntegrationOutput(BaseModel):
    removed_paths: List[str]


class ApplySeedOutput(BaseModel):
    seed_hash: str


class NewIntegrationStepOutput(BaseModel):
    success: bool
    error: str = ""
    workflow_steps_completed: int = 0
    turn_count: int = 0
    cost_usd: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    model: str = ""


class FinalEvalOutput(BaseModel):
    """Wraps :class:`IntegrationGenResult` for the workflow's final output."""

    result: IntegrationGenResult
