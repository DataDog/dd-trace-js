"""Run log persistence — copy full workflow logs out of the worktree.

Called from ``IntegrationGenTask.run``'s finally block before the worktree is
torn down, so the agent transcript / fixer / diagnosis logs survive for
post-hoc inspection.
"""

import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from anubis_apm.storage.s3_client import S3RunStorage

from .paths import S3_EVAL_PREFIX, run_dir

logger = logging.getLogger(__name__)


def save_run_logs(
    worktree_path: Path,
    package: str,
    repo: str,
    eval_name: str,
    run_id: str,
    result_json: str,
    workflow_base_dir: Optional[Path] = None,
) -> Optional[Path]:
    """Copy full workflow logs from worktree to persistent run dir and sync to S3.

    Saves every workflow state directory under the outer eval analysis root and
    the generated worktree's ``.analysis/<package>/`` root, including oracle
    logs and nested workflow agent logs, plus ``result.json``. Returns the local
    run directory, or ``None`` on failure.
    """
    dest = run_dir(repo, eval_name, package, run_id)

    try:
        dest.mkdir(parents=True, exist_ok=True)

        worktree_analysis_root = worktree_path / ".analysis" / package
        workflow_analysis_root = (
            workflow_base_dir / ".analysis" / package
            if workflow_base_dir
            else worktree_analysis_root
        )
        analysis_roots: list[Path] = []
        for root in (workflow_analysis_root, worktree_analysis_root):
            if root.exists() and root not in analysis_roots:
                analysis_roots.append(root)

        for analysis_root in analysis_roots:
            for src in sorted(p for p in analysis_root.iterdir() if p.is_dir()):
                _copy_tree_contents(src, dest / src.name)

        # Persist the eval result alongside the logs
        (dest / "result.json").write_text(result_json)

        # Persist adapter build logs before the eval worktree is cleaned up.
        build_logs = {
            ".dd-apm-prepare-build.log": "prepare-build.log",
            ".dd-apm-prepare-evalya-java.log": "prepare-evalya-java.log",
        }
        for source_name, dest_name in build_logs.items():
            build_log = worktree_path / source_name
            if build_log.exists():
                shutil.copy2(build_log, dest / dest_name)

        logger.info("Saved run logs to %s", dest)

        # Upload to S3
        ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        s3_key = f"{S3_EVAL_PREFIX}/{repo}/{eval_name}/runs/{package}-{ts}-{run_id}"
        S3RunStorage().upload_dir(dest, s3_key)

        return dest
    except Exception as e:
        logger.warning("Failed to save run logs: %s", e)
        return None


def _copy_tree_contents(src: Path, dest: Path) -> None:
    """Copy the contents of one workflow analysis directory."""
    for item in src.iterdir():
        item_dest = dest / item.name
        item_dest.parent.mkdir(parents=True, exist_ok=True)
        if item.is_dir():
            if item_dest.exists():
                shutil.rmtree(item_dest)
            shutil.copytree(item, item_dest)
        else:
            shutil.copy2(item, item_dest)
