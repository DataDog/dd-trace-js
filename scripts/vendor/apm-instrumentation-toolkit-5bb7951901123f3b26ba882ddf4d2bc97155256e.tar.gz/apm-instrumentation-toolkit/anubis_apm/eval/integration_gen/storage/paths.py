"""Path conventions for integration-gen eval storage.

Local layout:
    ~/.dd-apm/.analysis/eval-runs/<repo>/<eval-name>/{seeds,runs}/...

S3 layout (bucket: dd-apm-toolkit-experience):
    evals/<repo>/<eval-name>/{seeds,runs}/...
"""

from datetime import datetime, timezone
from pathlib import Path

S3_EVAL_PREFIX = "evals"


def eval_runs_base() -> Path:
    """Return the base directory for local eval run storage."""
    return Path.home() / ".dd-apm" / ".analysis" / "eval-runs"


def seeds_dir(repo: str, eval_name: str) -> Path:
    """Return the seeds directory for a repo/eval-name pair."""
    return eval_runs_base() / repo / eval_name / "seeds"


def runs_dir(repo: str, eval_name: str) -> Path:
    """Return the runs directory for a repo/eval-name pair."""
    return eval_runs_base() / repo / eval_name / "runs"


def run_dir(repo: str, eval_name: str, package: str, run_id: str) -> Path:
    """Return a timestamped run directory path."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return runs_dir(repo, eval_name) / f"{package}-{ts}-{run_id}"
