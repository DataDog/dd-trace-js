"""Seed cache: pre-populate analyze workflow state to skip the analyze phase.

Resolution order in ``apply_seed``:
  1. Local seed cache (by hash) — fastest, no network.
  2. S3 seed cache (by hash) — downloaded and cached locally.
  3. Local ``<repo_root>/.analysis/<package>/new_integration/`` — dev fallback.
  4. Local ``analyze-eval/`` / ``analyze/`` — synthesized from raw analyze artifacts.
  5. Bundled artifacts in the toolkit repo — CI fallback.
  6. Nothing — workflow runs analyze from scratch.

Hashing: prompt/schema/merge inputs and bundled seed artifacts that affect
seeded ``final.json`` plus ``{package}:{repo}`` form the cache key. Any
relevant prompt, schema, or bundled seed artifact change invalidates the seed
automatically.
"""

import hashlib
import json
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional

from anubis_apm.storage.s3_client import S3RunStorage
from anubis_apm.workflows.new_integration.step_helpers.layers import merge_layers

from .paths import S3_EVAL_PREFIX, seeds_dir

if TYPE_CHECKING:
    from anubis_apm.repo_adapters.base import APMAdapterMixin

logger = logging.getLogger(__name__)

_APM_ROOT = Path(__file__).parent.parent.parent.parent

# Inputs that determine seeded final.json. Keep this deliberately small: these
# files/directories affect agent analysis shape, codegen prompts, or final merge
# behavior. Package-specific bundled seed artifacts are added separately.
_SEED_HASH_INPUTS = [
    _APM_ROOT / "prompts" / "shared" / "new_integration",
    _APM_ROOT / "prompts" / "shared" / "instrumentation",
    _APM_ROOT / "workflows" / "analyze" / "models.py",
    _APM_ROOT / "workflows" / "analyze" / "language_models",
    _APM_ROOT / "workflows" / "new_integration" / "step_helpers" / "layers.py",
    Path(__file__),
]

# Steps whose completed status is preserved in the seed. All other steps are
# stripped so future runs re-execute compile + test with fresh config.
_SEED_PRESERVE_STEPS = {"analyze", "merge_layers", "load_analysis", "merge_layers_2"}

# Steps that write files into the worktree — stripped from a copied seed so
# they always run fresh. Without this, the executor sees a pre-existing
# output.json and skips the step → no plugin files get generated.
_FILE_WRITING_STEPS = {"compile", "test"}

# Bundled agent.json + enrichments.json snapshots committed to the toolkit
# repo. Used in CI where the tracer repo is a fresh clone with no
# .analysis/ state to synthesize from.
_BUNDLED_SEEDS_ROOT = Path(__file__).parent.parent / "datasets" / "seeds"


def compute_seed_hash(package: str, repo: str) -> str:
    """Compute a hash over seed inputs + package + repo.

    When any prompt changes the hash changes and the seed is considered stale.
    Returns a 16-char hex prefix (enough uniqueness for cache keying).
    """
    h = hashlib.sha256()
    h.update(f"{package}:{repo}".encode())
    bundled_seed_dir = _BUNDLED_SEEDS_ROOT / repo / package
    _update_hash_from_path(h, bundled_seed_dir, suffixes={".json"})
    for path in _SEED_HASH_INPUTS:
        _update_hash_from_path(h, path)
    return h.hexdigest()[:16]


def _update_hash_from_path(h: Any, path: Path, suffixes: set[str] | None = None) -> None:
    """Add a seed input file or directory to ``h`` when it exists."""
    suffixes = suffixes or {".md", ".py"}
    if not path.exists():
        return
    if path.is_file():
        try:
            h.update(str(path.relative_to(_APM_ROOT)).encode())
        except ValueError:
            h.update(str(path).encode())
        try:
            h.update(path.read_bytes())
        except OSError as e:
            logger.debug("Could not read seed hash input %s: %s", path, e)
        return

    for child in sorted(path.rglob("*")):
        if child.is_file() and child.suffix in suffixes:
            _update_hash_from_path(h, child, suffixes=suffixes)


def load_bundled_package_metadata(repo: str, package: str) -> Dict[str, Any]:
    """Load static metadata for a bundled integration-gen seed, if present."""
    metadata_path = _BUNDLED_SEEDS_ROOT / repo / package / "metadata.json"
    if not metadata_path.exists():
        return {}
    try:
        metadata = json.loads(metadata_path.read_text())
    except json.JSONDecodeError as e:
        logger.warning("Invalid bundled seed metadata at %s: %s", metadata_path, e)
        return {}
    if not isinstance(metadata, dict):
        logger.warning("Bundled seed metadata at %s is not an object", metadata_path)
        return {}
    return metadata


def find_seed(repo: str, eval_name: str, seed_hash: str) -> Optional[Path]:
    """Return path to a local seed directory, downloading from S3 if needed."""
    local = seeds_dir(repo, eval_name) / seed_hash
    if local.exists() and (local / "state.json").exists():
        logger.info("Seed cache hit (local): %s", local)
        return local

    s3_key = f"{S3_EVAL_PREFIX}/{repo}/{eval_name}/seeds/{seed_hash}"
    S3RunStorage().download_run(s3_key, local)
    if (local / "state.json").exists():
        logger.info("Seed cache hit (S3 -> local): %s", local)
        return local
    return None


def save_seed(
    worktree_analysis: Path,
    package: str,
    repo: str,
    eval_name: str,
    seed_hash: str,
) -> Optional[Path]:
    """Copy workflow state to local seed cache and sync to S3.

    Saves state.json, artifacts/, and steps/*/output.json (no agent logs).
    """
    dest = seeds_dir(repo, eval_name) / seed_hash
    try:
        dest.mkdir(parents=True, exist_ok=True)

        # state.json — strip compile/test steps so future runs re-execute them
        state_src = worktree_analysis / "state.json"
        if state_src.exists():
            state = json.loads(state_src.read_text())
            steps = state.get("steps", {})
            stripped = {k: v for k, v in steps.items() if k in _SEED_PRESERVE_STEPS}
            state["steps"] = stripped
            (dest / "state.json").write_text(json.dumps(state, indent=2, default=str))

        # artifacts/
        artifacts_src = worktree_analysis / "artifacts"
        if artifacts_src.exists():
            artifacts_dest = dest / "artifacts"
            if artifacts_dest.exists():
                shutil.rmtree(artifacts_dest)
            shutil.copytree(artifacts_src, artifacts_dest)

        # steps/*/output.json only (strip agent logs, and only for analysis steps).
        # compile/test output.json must NOT be copied: the agent executor skips any
        # step whose output.json already exists, even if it's not in state.json.
        # Seeding compile output would cause the workflow to skip file generation.
        steps_src = worktree_analysis / "steps"
        if steps_src.exists():
            steps_dest = dest / "steps"
            steps_dest.mkdir(exist_ok=True)
            for step_dir in steps_src.iterdir():
                if not step_dir.is_dir():
                    continue
                # step directories are named "<step>-<attempt>", e.g. "compile-1"
                step_name = step_dir.name.rsplit("-", 1)[0]
                if step_name not in _SEED_PRESERVE_STEPS:
                    continue
                step_out = step_dir / "output.json"
                if step_out.exists():
                    (steps_dest / step_dir.name).mkdir(exist_ok=True)
                    shutil.copy2(step_out, steps_dest / step_dir.name / "output.json")

        metadata = {
            "package": package,
            "repo": repo,
            "eval_name": eval_name,
            "seed_hash": seed_hash,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        (dest / "seed-metadata.json").write_text(json.dumps(metadata, indent=2))

        logger.info("Saved seed to %s", dest)

        s3_key = f"{S3_EVAL_PREFIX}/{repo}/{eval_name}/seeds/{seed_hash}"
        S3RunStorage().upload_dir(dest, s3_key)
        return dest
    except Exception as e:
        logger.warning("Failed to save seed: %s", e)
        return None


def strip_file_writing_steps(state_dir: Path) -> None:
    """Remove compile/test checkpoints from a copied seed so they always re-run.

    When a seed is copied from a previous run, compile/test may be marked
    completed in state.json OR have output.json files in steps/. The agent
    executor skips any step whose output.json already exists (even without a
    state.json entry), so both must be stripped here.
    """
    state_file = state_dir / "state.json"
    if state_file.exists():
        try:
            state = json.loads(state_file.read_text())
            steps = state.get("steps", {})
            for step_name in list(steps):
                if step_name in _FILE_WRITING_STEPS:
                    del steps[step_name]
            state_file.write_text(json.dumps(state, indent=2))
        except Exception as e:
            logger.warning("strip_file_writing_steps: failed to update state.json: %s", e)

    steps_dir_path = state_dir / "steps"
    if not steps_dir_path.exists():
        return
    for step_dir in steps_dir_path.iterdir():
        if not step_dir.is_dir():
            continue
        step_name = step_dir.name.rsplit("-", 1)[0]
        if step_name in _FILE_WRITING_STEPS:
            shutil.rmtree(step_dir, ignore_errors=True)
            logger.debug("Removed stale step dir from seed: %s", step_dir.name)


def apply_seed(
    package: str,
    repository: str,
    eval_name: str,
    seed_hash: str,
    repo_root: Path,
    worktree_path: Path,
    adapter: "APMAdapterMixin",
) -> None:
    """Seed analysis state into the worktree so the workflow skips analyze."""
    dst = worktree_path / ".analysis" / package / "new_integration"
    dst.parent.mkdir(parents=True, exist_ok=True)

    seed_path = find_seed(repository, eval_name, seed_hash)
    if seed_path:
        logger.info("Using cached seed (hash=%s): %s", seed_hash, seed_path)
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(seed_path, dst)
        strip_file_writing_steps(dst)
        return

    src = repo_root / ".analysis" / package / "new_integration"
    if (src / "state.json").exists() and (src / "artifacts" / "final.json").exists():
        logger.info("No cached seed — falling back to local .analysis/ at %s", src)
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst)
        strip_file_writing_steps(dst)
        save_seed(dst, package, repository, eval_name, seed_hash)
        return

    for wf_name in ("analyze-eval", "analyze"):
        src_analyze = repo_root / ".analysis" / package / wf_name
        if not src_analyze.exists():
            continue
        logger.info("Synthesizing seed from %s/%s for %s", package, wf_name, seed_hash)
        if synthesize_seed_from_analyze(package, src_analyze, dst, adapter):
            save_seed(dst, package, repository, eval_name, seed_hash)
            return
        logger.warning("Could not synthesize seed from %s — trying next", src_analyze)

    bundled = _BUNDLED_SEEDS_ROOT / repository / package
    if bundled.exists():
        logger.info("Synthesizing seed from bundled artifacts for %s", package)
        if synthesize_seed_from_analyze(package, bundled, dst, adapter):
            save_seed(dst, package, repository, eval_name, seed_hash)
            return
        logger.warning("Could not synthesize seed from bundled artifacts for %s", package)

    logger.warning("No seed found (hash=%s) — workflow will run analyze from scratch", seed_hash)


def synthesize_seed_from_analyze(
    package: str,
    analyze_dir: Path,
    dst: Path,
    adapter: "APMAdapterMixin",
) -> bool:
    """Build a new_integration seed from analyze-eval/ or analyze/ workflow state.

    Reads agent.json + enrichments.json, runs merge_layers() to produce final.json,
    and writes a synthetic state.json marking analyze → merge_layers → load_analysis
    → merge_layers_2 as completed. Returns False if required artifacts are missing.
    """
    artifacts_dir = analyze_dir / "artifacts"
    agent_path = artifacts_dir / "agent.json"
    enrichments_path = artifacts_dir / "enrichments.json"
    state_path = analyze_dir / "state.json"

    if not agent_path.exists():
        logger.debug("Synthesize: missing agent.json at %s", agent_path)
        return False

    try:
        agent: Dict[str, Any] = json.loads(agent_path.read_text())
        enrichments: Optional[Dict[str, Any]] = (
            json.loads(enrichments_path.read_text()) if enrichments_path.exists() else None
        )
    except Exception as e:
        logger.warning("Synthesize: failed to load artifacts: %s", e)
        return False

    try:
        final = merge_layers(agent, enrichments, adapter=adapter)
    except Exception as e:
        logger.warning("Synthesize: merge_layers failed: %s", e)
        return False

    analysis = agent.get("analysis", {})
    targets = [t.get("location", "") for t in analysis.get("instrumentation_targets", [])]
    module_type: str = agent.get("module_type", "commonjs")
    package_name: str = agent.get("package_name", package)

    instrumentations = final.get("orchestrion_config", {}).get("instrumentations", [])
    method_targets = [
        instr.get("function_query", {}).get("name")
        for instr in instrumentations
        if instr.get("function_query", {}).get("name")
    ]
    targets_count = len(instrumentations)
    now = datetime.now(timezone.utc).isoformat()
    final_artifact_rel = f".analysis/{package}/new_integration/artifacts/final.json"

    analyze_metrics: Dict[str, Any] = {}
    if state_path.exists():
        try:
            analyze_state = json.loads(state_path.read_text())
            total_cost = sum(
                s.get("metrics", {}).get("cost_usd", 0.0)
                for s in analyze_state.get("steps", {}).values()
            )
            analyze_metrics = {"cost_usd": total_cost}
        except (json.JSONDecodeError, KeyError, TypeError):
            logger.debug("Could not read analyze metrics from %s", state_path)

    state: Dict[str, Any] = {
        "workflow": "new_integration",
        "namespace": package,
        "steps": {
            "analyze": {
                "name": "analyze",
                "status": "completed",
                "attempt": 1,
                "started_at": None,
                "completed_at": now,
                "input": None,
                "error": None,
                "metrics": analyze_metrics,
                "output": {
                    "success": True,
                    "package_name": package_name,
                    "targets": targets,
                    "module_type": module_type,
                },
            },
            "merge_layers": {
                "name": "merge_layers",
                "status": "completed",
                "attempt": 1,
                "started_at": None,
                "completed_at": now,
                "input": None,
                "error": None,
                "metrics": {},
                "output": {
                    "success": True,
                    "final_path": final_artifact_rel,
                    "targets_count": targets_count,
                    "module_type": module_type,
                },
            },
            "load_analysis": {
                "name": "load_analysis",
                "status": "completed",
                "attempt": 1,
                "started_at": None,
                "completed_at": now,
                "input": None,
                "error": None,
                "metrics": {},
                "output": {
                    "package_name": package_name,
                    "targets": method_targets,
                    "available_services": [],
                },
            },
            "merge_layers_2": {
                "name": "merge_layers_2",
                "status": "completed",
                "attempt": 1,
                "started_at": None,
                "completed_at": now,
                "input": None,
                "error": None,
                "metrics": {},
                "output": {
                    "success": True,
                    "final_path": final_artifact_rel,
                    "targets_count": targets_count,
                    "module_type": module_type,
                },
            },
        },
        "artifacts": {"final": final_artifact_rel},
    }

    try:
        dst.mkdir(parents=True, exist_ok=True)
        (dst / "artifacts").mkdir(exist_ok=True)
        (dst / "artifacts" / "final.json").write_text(json.dumps(final, indent=2))
        (dst / "state.json").write_text(json.dumps(state, indent=2))
    except Exception as e:
        logger.warning("Synthesize: failed to write seed files: %s", e)
        return False

    logger.info(
        "Synthesized seed for %s: %d targets, %d instrumentations",
        package,
        len(targets),
        targets_count,
    )
    return True
