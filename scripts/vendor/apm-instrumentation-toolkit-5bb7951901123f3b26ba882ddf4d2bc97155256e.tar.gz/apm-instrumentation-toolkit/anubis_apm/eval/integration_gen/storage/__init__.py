"""Eval-run storage: seed cache and run-logs persistence.

Local layout::

    ~/.dd-apm/.analysis/eval-runs/<repo>/<eval-name>/
      seeds/<seed-hash>/   — pre-analyzed workflow state, keyed by prompt hash
      runs/<pkg>-<ts>-<id>/ — full per-run logs + result.json

S3 mirror (bucket ``dd-apm-toolkit-experience``)::

    evals/<repo>/<eval-name>/{seeds,runs}/...
"""

from .paths import eval_runs_base, run_dir, runs_dir, seeds_dir
from .run_logs import save_run_logs
from .seeds import (
    apply_seed,
    compute_seed_hash,
    find_seed,
    load_bundled_package_metadata,
    save_seed,
    strip_file_writing_steps,
    synthesize_seed_from_analyze,
)

__all__ = [
    # paths
    "eval_runs_base",
    "run_dir",
    "runs_dir",
    "seeds_dir",
    # seeds
    "apply_seed",
    "compute_seed_hash",
    "find_seed",
    "load_bundled_package_metadata",
    "save_seed",
    "strip_file_writing_steps",
    "synthesize_seed_from_analyze",
    # run logs
    "save_run_logs",
]
