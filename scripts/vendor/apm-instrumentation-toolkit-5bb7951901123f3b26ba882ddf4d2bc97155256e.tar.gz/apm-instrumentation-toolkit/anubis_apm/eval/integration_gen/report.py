"""Cross-package report generation for the integration-gen eval suite.

These functions consume the ``list[EvalResult]`` produced by ``MatrixRunner``
after every package's workflow has finished. They produce:

- ``integration_gen_eval_detail_{repo}.md`` — markdown report, one section per
  package, with a summary table at the top.
- ``integration_gen_eval_results_{repo}.json`` — JSON serialization used by
  the CI aggregator to submit a single LLMObs experiment across pods.
"""

import json
from pathlib import Path
from typing import List

from anubis.eval import EvalResult


def write_detail_report(results: List[EvalResult], repository: str, output: Path) -> None:
    """Write a per-package markdown detail report."""
    lines: list[str] = []

    def w(s: str = "") -> None:
        lines.append(s)

    w(f"# Integration-Gen Eval Detail: {repository}")
    w()

    summary_rows: list[tuple] = []

    for r in results:
        oracle = r.tags.get("oracle", "?")
        scenarios_passing = int(r.metrics.get("scenarios_passing") or 0)
        scenarios_total = int(r.metrics.get("scenarios_total") or 0)
        pass_rate = r.metrics.get("pass_rate")
        rate_str = f"{pass_rate:.0%}" if pass_rate is not None else "---"
        pre_passing = int(r.metrics.get("precheck_scenarios_passing") or 0)
        pre_total = int(r.metrics.get("precheck_scenarios_total") or 0)
        pre_rate = r.metrics.get("precheck_pass_rate")
        pre_rate_str = f"{pre_rate:.0%}" if pre_rate is not None else "---"
        turns = int(r.metrics.get("turn_count") or 0)
        cost = r.cost_usd

        w(f"## {r.name}")
        w()
        w(
            f"**Oracle:** `{oracle}`  |  "
            f"**Pre-check:** {pre_rate_str} ({pre_passing}/{pre_total})  |  "
            f"**Post-codegen:** {rate_str} ({scenarios_passing}/{scenarios_total})  |  "
            f"Status: `{r.status}`"
        )
        if turns or cost > 0:
            in_tok = int(r.metrics.get("input_tokens") or 0)
            out_tok = int(r.metrics.get("output_tokens") or 0)
            w(
                f"**Turns:** {turns}  |  "
                f"**Cost:** ${cost:.2f}  |  "
                f"**Tokens:** {in_tok:,} in / {out_tok:,} out  |  "
                f"**Duration:** {r.duration_s:.0f}s"
            )
        if r.error:
            w()
            if "\n" in r.error:
                w("**Error:**")
                w()
                w("```")
                w(r.error)
                w("```")
            else:
                w(f"**Error:** {r.error}")
        w()

        summary_rows.append((
            r.name,
            oracle,
            pre_rate_str,
            f"{pre_passing}/{pre_total}",
            rate_str,
            f"{scenarios_passing}/{scenarios_total}",
            turns,
            cost,
            r.status,
        ))

    summary = [
        "## Summary",
        "",
        "| Package | Oracle | PreCheck% | PreCheck N | Post% | Post N | Turns | Cost | Status |",
        "|---|---|---|---|---|---|---|---|---|",
        *[
            f"| {pkg} | {oracle} | {pre} | {pre_n} | {post} | {post_n} | {turns} | ${cost:.2f} | {status} |"
            for pkg, oracle, pre, pre_n, post, post_n, turns, cost, status in summary_rows
        ],
        "",
    ]

    output.write_text("\n".join(summary) + "\n---\n\n" + "\n".join(lines))


def write_results_json(results: List[EvalResult], repository: str, output: Path) -> None:
    """Serialize EvalResults to JSON for cross-pod aggregation in CI."""
    payload = {
        "repository": repository,
        "results": [r.model_dump() for r in results],
    }
    output.write_text(json.dumps(payload, indent=2, default=str))
