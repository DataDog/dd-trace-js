"""Matrix eval runner for method selection across multiple packages."""

import json
import logging
from pathlib import Path
from typing import List, Optional

from anubis_apm.repo_adapters.base import APMAdapterMixin
from anubis_apm.shared.naming import slugify_package_name
from anubis_apm.workflows.analyze.models import AgentAnalysis

logger = logging.getLogger(__name__)


def load_agent_analysis(path: Path) -> AgentAnalysis:
    """Load AgentAnalysis from a JSON file, handling all output formats."""
    with open(path) as f:
        data = json.load(f)
    if "analysis" in data and "package_name" in data:
        return AgentAnalysis(**data)
    if "output" in data:
        return AgentAnalysis(**data["output"])
    return AgentAnalysis(**data)


def _find_analyze_output(analysis_dir: Path) -> Optional[Path]:
    """Find the analyze step output file in an analysis directory."""
    candidates = [
        analysis_dir / "steps" / "analyze-1" / "output.json",
        analysis_dir / "steps" / "agent_analysis-1" / "output.json",
    ]
    steps_dir = analysis_dir / "steps"
    if steps_dir.exists():
        for step_dir in sorted(steps_dir.iterdir()):
            if "analy" in step_dir.name.lower():
                output = step_dir / "output.json"
                if output.exists():
                    candidates.insert(0, output)

    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def get_matrix_packages(adapter: APMAdapterMixin) -> List[str]:
    """Get all packages available in the ground truths for a repository.

    Scans ``{gt_dir}/{category}/{pkg}-targets.json`` files and returns a
    sorted list of unique package names from the ``package`` field inside each file.
    """
    gt_path = adapter.get_ground_truths_path()
    if not gt_path or not gt_path.exists():
        return []

    packages: set = set()
    for cat_dir in gt_path.iterdir():
        if not cat_dir.is_dir():
            continue
        for path in cat_dir.glob("*-targets.json"):
            try:
                with open(path) as f:
                    data = json.load(f)
                for t in data.get("targets", []):
                    pkg = t.get("package", "")
                    if pkg:
                        packages.add(pkg)
            except Exception:
                logger.debug("Could not read %s", path)
    return sorted(packages)


def _find_package_analysis(
    base: Path,
    package: str,
    cache_dir: Optional[Path] = None,
    aliases: Optional[list[str]] = None,
) -> Optional[Path]:
    """Find an analysis output for a package across workflow directories.

    Search order (first match wins):
    1. ``analyze-eval`` — isolated eval runs (never collide with regular workflow state)
    2. ``analyze`` / ``new_integration`` — regular workflow runs (read-only fallback)
    3. ``cache_dir`` — persistent eval cache (survives ``--force``)
    """
    normalized = slugify_package_name(package)
    names: list[str] = []
    seen: set[str] = set()
    for name in [package, normalized, *(aliases or [])]:
        if name and name not in seen:
            names.append(name)
            seen.add(name)
    # Prefer eval-specific directory, then fall back to regular workflow directories
    workflow_priority = ["analyze-eval", "analyze", "new_integration"]
    for workflow in workflow_priority:
        for name in names:
            analysis_dir = base / name / workflow
            if analysis_dir.exists():
                output = _find_analyze_output(analysis_dir)
                if output:
                    return output
    # Last resort: eval cache (persists across --force clears)
    if cache_dir:
        for name in names:
            cached = cache_dir / name / "output.json"
            if cached.exists():
                return cached
    return None
