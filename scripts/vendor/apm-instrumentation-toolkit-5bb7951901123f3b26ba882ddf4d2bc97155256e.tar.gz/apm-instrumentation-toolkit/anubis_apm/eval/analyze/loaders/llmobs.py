"""LLMObs submission for matrix method selection evals."""

import logging
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from ddtrace.llmobs._experiment import BaseSummaryEvaluator, SummaryEvaluatorContext

from anubis.eval import submit_eval_results
from anubis.eval.llmobs import _get_branch, _get_project_name
from anubis.eval.models import EvalResult
from anubis_apm.eval.analyze.loaders.hashes import (
    compute_all_category_hashes,
    get_package_categories,
)

_DATASETS_DIR = Path(__file__).parent.parent / "datasets"

logger = logging.getLogger(__name__)


def _make_method_selection_summary_evaluator() -> Any:
    """Summary evaluator with micro-averaged precision/recall/F1 for method selection evals.

    Uses raw counts (true_positives, false_positives, critical_gt_count,
    critical_true_positives) to compute micro-averages that are more stable
    than macro-averaging per-package ratios on thin ground truth sets.
    """

    class _MethodSelectionSummary(BaseSummaryEvaluator):
        def __init__(self) -> None:
            super().__init__(name="aggregate")

        def evaluate(self, context: SummaryEvaluatorContext) -> Any:
            totals: Dict[str, List[float]] = defaultdict(list)
            for output in context.outputs:
                if not isinstance(output, dict):
                    continue
                for k in (
                    "true_positives",
                    "false_positives",
                    "critical_true_positives",
                    "critical_gt_count",
                    "false_negatives",
                    "cost_usd",
                ):
                    val = output.get(k)
                    if isinstance(val, (int, float)):
                        totals[k].append(float(val))

            result: Dict[str, Any] = {}

            # Micro-averaged precision: sum(TP) / (sum(TP) + sum(FP))
            sum_tp = sum(totals.get("true_positives", []))
            sum_fp = sum(totals.get("false_positives", []))
            if sum_tp + sum_fp > 0:
                precision = round(sum_tp / (sum_tp + sum_fp), 4)
                result["precision"] = precision

            # Micro-averaged recall: sum(critical_TP) / sum(critical_gt_count)
            sum_cgt = sum(totals.get("critical_gt_count", []))
            sum_ctp = sum(totals.get("critical_true_positives", []))
            if sum_cgt > 0:
                recall = round(sum_ctp / sum_cgt, 4)
                result["recall"] = recall
                precision_val = result.get("precision")
                if precision_val is not None and (precision_val + recall) > 0:
                    result["f1"] = round(2 * precision_val * recall / (precision_val + recall), 4)

            # Full-recall rate: fraction of packages where no critical target was missed.
            # Exclude packages with zero critical GT targets (no recall signal).
            fn_vals = []
            for o in context.outputs:
                if not isinstance(o, dict):
                    continue
                cgt = o.get("critical_gt_count")
                fn = o.get("false_negatives")
                if isinstance(cgt, (int, float)) and cgt > 0 and isinstance(fn, (int, float)):
                    fn_vals.append(float(fn))
            if fn_vals:
                result["full_recall_rate"] = round(
                    sum(1 for v in fn_vals if v == 0) / len(fn_vals), 4
                )

            result["evaluated"] = len([o for o in context.outputs if isinstance(o, dict)])
            return result

    return _MethodSelectionSummary()


def submit_matrix_to_llmobs(
    results: List[EvalResult],
    repository: str,
    project_name: Optional[str] = None,
    experiment_name: Optional[str] = None,
    categories: Optional[List[str]] = None,
) -> bool:
    """Submit matrix eval results to LLMObs.

    When multiple categories are given, each is submitted as its own
    experiment/dataset so trend lines stay comparable over time.

    Args:
        results: EvalResult list from MatrixRunner.run().
        repository: Repository identifier (e.g. "dd_trace_js").
        project_name: LLMObs project (default: auto).
        experiment_name: Override experiment name (default: stable per repo+branch).
        categories: Category filter(s) in effect. Multiple categories are submitted
            separately so each gets its own stable experiment trend line.

    Returns:
        True if all submissions succeeded.
    """
    scored_results = [r for r in results if r.metrics]
    if not scored_results:
        logger.warning("No results with metrics to submit")
        return False

    project_name = project_name or _get_project_name()
    pkg_to_cat = get_package_categories(_DATASETS_DIR / "ground_truths" / repository)

    # Multiple categories → one submission per category
    if categories and len(categories) > 1:
        all_ok = True
        for cat in sorted(categories):
            cat_results = [r for r in scored_results if pkg_to_cat.get(r.name, "") == cat]
            if cat_results:
                ok = _submit_one(
                    cat_results, repository, project_name, experiment_name, [cat], pkg_to_cat
                )
                all_ok = ok and all_ok
        return all_ok

    return _submit_one(
        scored_results, repository, project_name, experiment_name, categories, pkg_to_cat
    )


def _submit_one(
    results: List[EvalResult],
    repository: str,
    project_name: str,
    experiment_name: Optional[str],
    categories: Optional[List[str]],
    pkg_to_cat: Dict[str, str],
) -> bool:
    base = f"matrix_method_selection__{repository}__{_get_branch()}"
    scope = categories[0] if categories else ""
    exp_name = experiment_name or (f"{base}__{scope}" if scope else base)
    dataset_name = (
        f"method_selection_{repository}__{scope}" if scope else f"method_selection_{repository}"
    )
    print(f"  Experiment: {exp_name}  Dataset: {dataset_name}  Project: {project_name}")

    categories_in_run = {pkg_to_cat.get(r.name, "") for r in results}
    cat_hashes = compute_all_category_hashes(repository, categories_in_run)
    prompt_hashes_str = ",".join(f"{k}={v}" for k, v in sorted(cat_hashes.items()) if k)

    tags: dict = {
        "repository": repository,
        "evaluated_packages": str(len(results)),
        "prompt_hashes": prompt_hashes_str,
    }
    if categories:
        tags["categories"] = ",".join(sorted(categories))

    return submit_eval_results(
        results,
        experiment_name=exp_name,
        dataset_name=dataset_name,
        project_name=project_name,
        tags=tags,
        summary_evaluator=_make_method_selection_summary_evaluator(),
    )
