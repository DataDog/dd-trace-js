"""Prompt hash utilities for category-level cache invalidation.

Hashes are computed over the prompt files used for a given category so that
only packages whose category prompts changed need to be re-evaluated.

Uses ``anubis.eval.hashing.hash_eval_inputs`` for the actual content hashing.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Iterable, Optional

from anubis.eval.hashing import hash_eval_inputs

logger = logging.getLogger(__name__)

_PROMPT_DIR = Path(__file__).parent.parent.parent.parent / "prompts" / "shared" / "instrumentation"


def compute_category_prompt_hash(category: str, repository: str) -> str:
    """Return a 12-char SHA-256 hex digest for base prompt files + one category guide.

    Changing ``messaging.md`` only invalidates messaging packages.
    Changing ``references/general-principles.md`` invalidates all.
    Adding a new ``{{link:...}}`` or ``{{include_repo:...}}`` directive to
    ``prompt.md`` without changing its prose does not change the hash.
    """
    prompts = [_PROMPT_DIR / "prompt.md"]
    extras = sorted((_PROMPT_DIR / "references").glob("*.md"))

    repo_dir = _PROMPT_DIR / "repo" / repository
    if repo_dir.exists():
        extras.extend(sorted(repo_dir.glob("*.md")))

    cat_file = _PROMPT_DIR / "categories" / f"{category}.md"
    if cat_file.exists():
        extras.append(cat_file)

    return hash_eval_inputs(prompts=prompts, extras=extras)


def compute_all_category_hashes(repository: str, categories: Iterable[str]) -> Dict[str, str]:
    """Return ``{category: hash}`` for all given categories."""
    return {cat: compute_category_prompt_hash(cat, repository) for cat in categories if cat}


def fetch_last_category_hashes(
    repository: str,
    site: str,
    api_key: str,
    app_key: str,
) -> Dict[str, str]:
    """Query Datadog Spans v2 API for ``{category: hash}`` from the last matrix eval.

    Returns an empty dict on any error (network, auth, missing tag).
    The caller should fall back to the local JSON cache in that case.
    """
    import requests as _req  # noqa: PLC0415

    url = f"https://api.{site}/api/v2/spans/events/search"
    try:
        resp = _req.post(
            url,
            headers={
                "DD-API-KEY": api_key,
                "DD-APPLICATION-KEY": app_key,
                "Content-Type": "application/json",
            },
            json={
                "data": {
                    "type": "search_request",
                    "attributes": {
                        "filter": {
                            "query": f"@repository:{repository} operationname:experiment",
                            "from": "now-90d",
                            "to": "now",
                        },
                        "sort": "-timestamp",
                        "page": {"limit": 1},
                    },
                }
            },
            timeout=8,
        )
        spans = resp.json().get("data", [])
        if not spans:
            logger.debug("fetch_last_category_hashes: no experiment spans found for %s", repository)
            return {}
        attrs = spans[0].get("attributes", {}).get("attributes", {})
        hashes_str = attrs.get("prompt_hashes", "")
        if not hashes_str:
            logger.debug(
                "fetch_last_category_hashes: no prompt_hashes tag on latest span for %s", repository
            )
            return {}
        result = dict(pair.split("=", 1) for pair in hashes_str.split(",") if "=" in pair)
        logger.debug(
            "fetch_last_category_hashes: retrieved %d category hashes for %s",
            len(result),
            repository,
        )
        return result
    except Exception as e:
        logger.debug("fetch_last_category_hashes failed: %s", e)
    return {}


def get_package_categories(gt_path: Optional[Path]) -> Dict[str, str]:
    """Return ``{package: category}`` by scanning the ground-truth directory.

    ``gt_path`` is the repository directory (e.g. ``.../ground_truths/dd_trace_js/``).
    Category names come from subdirectory names; package names from the ``package``
    field inside each per-package targets file.
    """
    if not gt_path or not gt_path.exists():
        return {}
    result: Dict[str, str] = {}
    for cat_dir in sorted(gt_path.iterdir()):
        if not cat_dir.is_dir():
            continue
        category = cat_dir.name
        for path in sorted(cat_dir.glob("*-targets.json")):
            try:
                with open(path) as f:
                    data = json.load(f)
                for t in data.get("targets", []):
                    pkg = t.get("package", "")
                    if pkg:
                        result[pkg] = category
            except Exception:
                logger.debug("Could not read %s", path)
    return result
