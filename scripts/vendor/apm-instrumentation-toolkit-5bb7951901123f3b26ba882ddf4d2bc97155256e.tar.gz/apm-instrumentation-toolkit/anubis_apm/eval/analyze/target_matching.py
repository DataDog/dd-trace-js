"""Structured target matching for analyze step evaluation.

Replaces fuzzy string matching with canonical TargetID-based matching.
Four-pass algorithm:
  1. Exact (module, class, method) match
  2. Class-absent fallback (unique method name in module)
  3. Alternative match — method appears in a GT target's alternatives list
  4. Absorption — remaining spec targets that appear in any GT target's alternatives
     are absorbed (not a false positive, but not a true positive either)

Ground truth targets carry their own alternatives, eliminating the separate
call_chains/ data files. New language support requires only a per-package
targets file under ground_truths/{repo}/{category}/{pkg}-targets.json.
"""

import json
import logging
import re
from collections import Counter
from enum import Enum
from pathlib import Path
from typing import List, Optional, Tuple

from pydantic import BaseModel, ConfigDict, Field

from anubis_apm.shared.naming import bare_package_name

logger = logging.getLogger(__name__)


class MatchQuality(str, Enum):
    """Quality of a match between a spec target and a ground truth target."""

    EXACT = "exact"  # Same (module, class, method) — agent found the identical method
    CLASS_ABSENT = "class_absent"  # Method matched, but one side was missing the class name
    ALTERNATIVE = "alternative"  # Agent picked a valid alternative hook point for this operation
    CALL_CHAIN = "call_chain"  # Legacy alias kept for existing serialised data


class AlternativeTarget(BaseModel):
    """A valid but non-preferred hook point for the same operation as its parent GT target.

    If the agent selects this instead of or in addition to the preferred GT target:
    - It is absorbed (not counted as a false positive)
    - If it's the *only* pick for this operation (GT target was not directly matched),
      it elevates to an ALTERNATIVE-quality true positive and the GT target is consumed.
    """

    model_config = ConfigDict(populate_by_name=True)

    class_name: str = Field(alias="className", default="")
    method_name: str = Field(alias="methodName")


class GroundTruthTarget(BaseModel):
    """A single ground truth instrumentation target.

    Minimum required for a new language: ``package``, ``class_name``/``method_name``,
    ``critical``. Everything else is optional enrichment.
    """

    model_config = ConfigDict(populate_by_name=True)

    package: str
    class_name: str = Field(alias="className", default="")
    method_name: str = Field(alias="methodName", default="")
    function_name: str = Field(alias="functionName", default="")  # module-level functions
    expected_file: str = Field(alias="expectedFile", default="")
    is_async: bool = Field(alias="isAsync", default=False)
    operation: str = ""  # "produce", "query" — informational
    category: str = ""  # "database", "messaging"

    # Scoring tier
    critical: bool = True
    # acceptable=True: completely optional.
    # Not a false negative if missed; absorbed (not a false positive) if selected.
    acceptable: bool = False

    # Valid alternative hook points for the same operation.
    # Agent selecting any of these → ALTERNATIVE-quality TP, this GT target consumed.
    alternatives: List[AlternativeTarget] = Field(default_factory=list)

    @property
    def effective_method(self) -> str:
        return self.method_name or self.function_name

    @property
    def display(self) -> str:
        cls = self.class_name
        method = self.effective_method
        if cls:
            return f"{cls}.{method}"
        return method

    @property
    def file_hint(self) -> str:
        """Alias for expected_file — used by callers that predate the rename."""
        return self.expected_file


class TargetID(BaseModel):
    """Canonical, unambiguous instrumentation target identifier for spec (agent) targets."""

    module: str  # "kafkajs", "pg", "redis"
    class_name: str = ""  # "Client", "Producer", "" for module-level
    method_name: str  # "query", "send"
    file_hint: str = ""  # "lib/client.js"
    critical: bool = True  # unused for spec; kept for symmetry
    operation: str = ""  # informational only

    @property
    def display(self) -> str:
        if self.class_name:
            return f"{self.class_name}.{self.method_name}"
        return self.method_name


class TargetMatchResult(BaseModel):
    """Result of matching spec targets against ground truth targets."""

    matched: List[Tuple[TargetID, GroundTruthTarget, str]] = Field(default_factory=list)
    unmatched_spec: List[TargetID] = Field(default_factory=list)  # true false positives
    unmatched_gt: List[GroundTruthTarget] = Field(default_factory=list)  # false negatives
    absorbed_spec: List[TargetID] = Field(default_factory=list)  # valid alternatives, not penalised


def from_spec_target(target) -> TargetID:
    """Convert an AgentInstrumentationTarget to TargetID.

    Handles common formats agents produce in the method field:
      - "Producer.prototype.send"   → class=Producer, method=send
      - "Client.send"               → class=Client, method=send
      - "send"                      → class="", method=send (location used as fallback)
    """
    method = getattr(target, "method", "")
    # Strip "prototype" — it's a JS implementation detail, not a class name
    parts = [p for p in method.split(".") if p and p.lower() != "prototype"]

    if len(parts) >= 2:
        class_name = parts[-2]
        method_name = parts[-1]
    elif len(parts) == 1:
        method_name = parts[0]
        # Fall back to location field for class info
        location = getattr(target, "location", "")
        loc_parts = [p for p in location.split(".") if p and p.lower() != "prototype"]
        # If location ends with the method name (e.g. "Producer.send"), strip it to get the class
        if loc_parts and loc_parts[-1].lower() == method_name.lower():
            loc_parts = loc_parts[:-1]
        class_name = loc_parts[-1] if loc_parts else ""
    else:
        method_name = ""
        class_name = ""

    return TargetID(
        module=getattr(target, "module_name", ""),
        class_name=class_name,
        method_name=method_name,
        file_hint=getattr(target, "file_path", ""),
    )


# ---------------------------------------------------------------------------
# Kept for callers that still use the old dict→TargetID conversion.
# New code should use load_ground_truths() which returns GroundTruthTarget.
# ---------------------------------------------------------------------------
def from_ground_truth(gt: dict) -> TargetID:
    """Convert a ground truth dict to TargetID (legacy helper)."""
    return TargetID(
        module=gt.get("package", ""),
        class_name=gt.get("className", ""),
        method_name=gt.get("methodName") or gt.get("functionName", ""),
        file_hint=gt.get("expectedFile", ""),
        critical=gt.get("critical", True),
    )


# ---------------------------------------------------------------------------
# Internal matching helpers
# ---------------------------------------------------------------------------


def _modules_match(spec_mod: str, gt_mod: str) -> bool:
    """Check if two module names refer to the same package.

    Handles common mismatches between agent output and GT:
    - Submodule paths: "redis.client" matches "redis"
    - Underscore/hyphen: "confluent_kafka" matches "confluent-kafka"
    - Scoped packages: "@elastic/transport" matches "transport" or "elastic-transport"
    """

    def _norm(m: str) -> str:
        return m.replace("_", "-").lower()

    s = _norm(spec_mod)
    g = _norm(gt_mod)
    if s == g:
        return True

    s_bare = s.rsplit("/", maxsplit=1)[-1]
    g_bare = g.rsplit("/", maxsplit=1)[-1]
    if s_bare == g_bare:
        return True

    s_pkg = s.split(".")[0]
    g_pkg = g.split(".")[0]
    if s_pkg == g_pkg:
        return True

    s_bare_pkg = s_bare.split(".")[0]
    g_bare_pkg = g_bare.split(".")[0]
    if s_bare_pkg == g_bare_pkg:
        return True

    s_root = s.split("/")[0]
    g_root = g.split("/")[0]
    return s_root == g_root


def _class_matches(a: str, b: str) -> bool:
    """True if two class name strings refer to the same class.

    Allows FQN vs simple-name mismatches: 'Connection' matches
    'redis.clients.jedis.Connection' by checking suffix after a dot boundary.
    """
    a, b = a.lower(), b.lower()
    if a == b:
        return True
    # FQN suffix match: one is the trailing simple-name of the other
    return a == b.rsplit(".", 1)[-1] or b == a.rsplit(".", 1)[-1]


def _method_matches(spec_method: str, gt_method: str) -> bool:
    """True if spec method satisfies the GT method pattern.

    GT methods ending with '*' are prefix wildcards (e.g. 'execute*' matches
    'executeQuery', 'executeUpdate', etc.). Specific variants score the same
    as an exact match — the agent correctly identified the hook point.
    """
    s, g = spec_method.lower(), gt_method.lower()
    if s == g:
        return True
    if g.endswith("*"):
        return s.startswith(g[:-1])
    return False


def _exact_match(spec: TargetID, gt: GroundTruthTarget) -> bool:
    """True if (module, class_name, method_name) all match."""
    if not _method_matches(spec.method_name, gt.effective_method):
        return False
    if not _class_matches(spec.class_name, gt.class_name):
        return False
    # GT FQN class already encodes the library — module check is redundant and
    # unreliable for Java where agents use Java package paths, not library names.
    if "." in gt.class_name:
        return True
    return _modules_match(spec.module, gt.package)


def _alt_match(spec: TargetID, alt: AlternativeTarget) -> bool:
    """True if spec matches an alternative (method required, class optional)."""
    if spec.method_name.lower() != alt.method_name.lower():
        return False
    if not alt.class_name or not spec.class_name:
        return True
    return _class_matches(spec.class_name, alt.class_name)


# ---------------------------------------------------------------------------
# Public matching API
# ---------------------------------------------------------------------------


def match_targets(
    spec_targets: List[TargetID],
    gt_targets: List[GroundTruthTarget],
) -> TargetMatchResult:
    """Match spec targets against ground truth targets.

    Four-pass matching (each spec target matches at most once, greedy):

    Pass 1 — Exact: (module, class_name, method_name) all match → EXACT
    Pass 2 — Class-absent fallback: one side missing class_name, unique method → CLASS_ABSENT
    Pass 3 — Alternative: spec matches a GT target's alternatives list → ALTERNATIVE
    Post  — Absorption: remaining spec targets that appear in any GT target's
            alternatives are moved to absorbed_spec (not false positive, not TP)

    Unmatched acceptable GT targets are excluded from unmatched_gt (no FN penalty).
    """
    result = TargetMatchResult()
    remaining_spec = list(spec_targets)
    remaining_gt = list(gt_targets)

    # Pass 1: exact matches
    for spec in list(remaining_spec):
        for gt in list(remaining_gt):
            if _exact_match(spec, gt):
                result.matched.append((spec, gt, MatchQuality.EXACT))
                remaining_spec.remove(spec)
                remaining_gt.remove(gt)
                break

    # Pass 2a: class-absent fallback — spec has no class, GT may have one
    gt_method_counts: Counter = Counter()
    for gt in remaining_gt:
        key = (gt.package.lower().rsplit("/", maxsplit=1)[-1], gt.effective_method.lower())
        gt_method_counts[key] += 1

    for spec in list(remaining_spec):
        if spec.class_name and spec.class_name.lower() != "module":
            continue
        for gt in list(remaining_gt):
            if gt.class_name and gt.class_name.lower() != "module":
                key = (gt.package.lower().rsplit("/", maxsplit=1)[-1], gt.effective_method.lower())
                if gt_method_counts[key] > 1:
                    continue
            if spec.method_name.lower() != gt.effective_method.lower():
                continue
            if not _modules_match(spec.module, gt.package):
                continue
            result.matched.append((spec, gt, MatchQuality.CLASS_ABSENT))
            remaining_spec.remove(spec)
            remaining_gt.remove(gt)
            break

    # Pass 2b: symmetric class-absent — GT has no class, spec does
    for spec in list(remaining_spec):
        if not spec.class_name or spec.class_name.lower() == "module":
            continue
        for gt in list(remaining_gt):
            if gt.class_name and gt.class_name.lower() != "module":
                continue
            if spec.method_name.lower() != gt.effective_method.lower():
                continue
            if not _modules_match(spec.module, gt.package):
                continue
            result.matched.append((spec, gt, MatchQuality.CLASS_ABSENT))
            remaining_spec.remove(spec)
            remaining_gt.remove(gt)
            break

    # Pass 3: alternative match — spec matches a GT target's alternatives list
    for spec in list(remaining_spec):
        for gt in list(remaining_gt):
            if not _modules_match(spec.module, gt.package):
                continue
            for alt in gt.alternatives:
                if _alt_match(spec, alt):
                    result.matched.append((spec, gt, MatchQuality.ALTERNATIVE))
                    remaining_spec.remove(spec)
                    remaining_gt.remove(gt)
                    break
            else:
                continue
            break

    # Absorption pass: remaining spec targets that appear in ANY GT target's
    # alternatives (including already-matched GT targets) → absorbed, not FP.
    # This handles the case where a preferred GT target was already consumed but
    # the agent also picked other methods in the same alternative group.
    for spec in list(remaining_spec):
        for gt in gt_targets:
            if not _modules_match(spec.module, gt.package):
                continue
            for alt in gt.alternatives:
                if _alt_match(spec, alt):
                    result.absorbed_spec.append(spec)
                    remaining_spec.remove(spec)
                    break
            else:
                continue
            break

    # Acceptable GT targets generate no false negatives — remove from unmatched_gt
    result.unmatched_spec = remaining_spec
    result.unmatched_gt = [gt for gt in remaining_gt if not gt.acceptable]
    return result


def _pkg_slug(name: str) -> str:
    """Convert a package name to a filesystem-safe slug (e.g. '@elastic/transport' → 'elastic-transport')."""
    slug = re.sub(r"[^a-z0-9.-]", "-", name.lower())
    return re.sub(r"-+", "-", slug).strip("-")


def _find_gt_file(ground_truths_path: Path, package_name: str) -> Optional[Path]:
    """Locate the ground truth JSON file for a package."""
    if not ground_truths_path or not ground_truths_path.exists():
        return None

    slug = _pkg_slug(package_name)
    bare_pkg = bare_package_name(package_name)

    for cat_dir in sorted(ground_truths_path.iterdir()):
        if not cat_dir.is_dir():
            continue
        candidate = cat_dir / f"{slug}-targets.json"
        if candidate.exists():
            return candidate

    for cat_dir in sorted(ground_truths_path.iterdir()):
        if not cat_dir.is_dir():
            continue
        for path in sorted(cat_dir.glob("*-targets.json")):
            with open(path) as f:
                raw = json.load(f)
            targets_raw = raw.get("targets", [])
            if not targets_raw:
                continue
            gt_pkg = targets_raw[0].get("package", "")
            if gt_pkg == package_name or bare_package_name(gt_pkg) == bare_pkg:
                return path

    return None


def load_ground_truths(
    ground_truths_path: Path,
    package_name: str,
) -> List[GroundTruthTarget]:
    """Load ground truths for a package from the split directory structure.

    ``ground_truths_path`` should be the repository directory (e.g.
    ``.../ground_truths/dd_trace_js/``). Each package lives in
    ``{category}/{slug}-targets.json`` under that directory.
    """
    gt_file = _find_gt_file(ground_truths_path, package_name)
    if not gt_file:
        return []

    with open(gt_file) as f:
        data = json.load(f)
    return [GroundTruthTarget.model_validate(t, by_alias=True) for t in data.get("targets", [])]


def load_ground_truth_metadata(
    ground_truths_path: Path,
    package_name: str,
) -> dict:
    """Load top-level metadata from a ground truth file (e.g. maven_coordinates)."""
    gt_file = _find_gt_file(ground_truths_path, package_name)
    if not gt_file:
        return {}

    with open(gt_file) as f:
        data = json.load(f)
    return {k: v for k, v in data.items() if k != "targets"}
