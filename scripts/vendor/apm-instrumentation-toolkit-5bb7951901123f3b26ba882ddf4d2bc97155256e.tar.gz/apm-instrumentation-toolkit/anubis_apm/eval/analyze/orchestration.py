"""Method selection eval orchestration.

``MethodSelectionOrchestrator`` is the ``EvalOrchestrator`` subclass that drives
the full lifecycle: pre-eval (run missing analyses with prompt-hash gating)
and post-eval (write a detailed markdown report).
"""

import concurrent.futures
import json
import logging
import os
import shutil
import threading
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from anubis.core.config import get_config
from anubis.eval import EvalOrchestrator, EvalResult, EvalSuite
from anubis_apm.blind import (
    BLIND_DENY_RULES,
    cleanup_blind_worktree,
    create_blind_worktree,
)
from anubis_apm.eval.analyze import (
    from_spec_target,
    load_ground_truth_metadata,
    load_ground_truths,
    match_targets,
)
from anubis_apm.eval.analyze.loaders.hashes import (
    compute_all_category_hashes,
    fetch_last_category_hashes,
    get_package_categories,
)
from anubis_apm.eval.analyze.loaders.matrix import _find_package_analysis, load_agent_analysis
from anubis_apm.repo_adapters import get_apm_adapter
from anubis_apm.shared.naming import slugify_package_name
from anubis_apm.workflows.analyze import analyze_package

logger = logging.getLogger(__name__)


class MethodSelectionOrchestrator(EvalOrchestrator):
    """Orchestrates method selection evals: pre-eval analyses + detail report.

    Attributes populated after ``run()``:
        detail_path: Path to the markdown detail report written in ``post_eval``.
    """

    def __init__(
        self,
        *,
        repository: str,
        analysis_base: Optional[Path],
        gt_path: Path,
        cache_dir: Optional[Path],
        run_missing: bool = False,
        blind: bool = False,
        force: bool = False,
        concurrency: int = 0,
        console=None,
    ) -> None:
        self.repository = repository
        self.analysis_base = analysis_base
        self.gt_path = gt_path
        self.cache_dir = cache_dir
        self.run_missing = run_missing
        self.blind = blind
        self.force = force
        self.concurrency = concurrency
        self.console = console
        self.detail_path: Optional[Path] = None

    def pre_eval(self, suite: EvalSuite) -> EvalSuite:
        if not self.run_missing:
            return suite
        _run_missing_analyses(
            [item.name for item in suite.items],
            self.repository,
            self.analysis_base,
            concurrency=min(self.concurrency or len(suite.items), 10),
            blind=self.blind,
            force=self.force,
            cache_dir=self.cache_dir,
            gt_path=self.gt_path,
            console=self.console,
        )
        return suite

    def post_eval(self, suite: EvalSuite, results: List[EvalResult]) -> None:
        self.detail_path = Path(f"matrix_eval_detail_{self.repository}.md")
        write_detail_report(results, self.repository, self.gt_path, self.detail_path)


def _run_missing_analyses(
    packages: list[str],
    repository: str,
    analysis_base: Path | None,
    *,
    concurrency: int = 4,
    blind: bool = False,
    force: bool = False,
    cache_dir: Path | None = None,
    gt_path: Path | None = None,
    console=None,
) -> None:
    """Run the analyze workflow for packages without existing outputs.

    Uses prompt-hash gating: packages whose category prompts haven't changed
    since the last run are skipped, even if outputs exist.
    """

    def _print(msg: str) -> None:
        if console is not None:
            console.print(msg)
        else:
            print(msg)

    base = analysis_base or Path(".analysis")
    hash_file: Path | None = cache_dir / "prompt_hashes.json" if cache_dir else None
    stored_hashes: dict[str, str] = {}
    current_hashes: dict[str, str] = {}
    adapter = get_apm_adapter(repository)
    aliases_by_package = _analysis_aliases_by_package(adapter, packages, gt_path)

    if force:
        cleared = _clear_eval_dirs(packages, base, aliases_by_package=aliases_by_package)
        cache_cleared = _clear_eval_cache(
            packages, cache_dir, aliases_by_package=aliases_by_package
        )
        if cleared:
            _print(f"[yellow]--force: cleared {cleared} eval workflow director(ies)[/]")
        if cache_cleared:
            _print(f"[yellow]--force: cleared {cache_cleared} eval cache entr(ies)[/]")
        missing = packages
    else:
        missing, current_hashes, stored_hashes = _filter_by_prompt_hash(
            packages, repository, base, cache_dir, gt_path, _print
        )

    if not missing:
        _print("[green]All packages have analysis outputs.[/]\n")
        return

    _base_ctx_overrides: dict = {"agent_eval_account": True}
    _blind_repo_root: Path | None = None
    _blind_adapter = None
    if blind:
        try:
            _blind_repo_root = get_config().get_repo_root(repository)
            if _blind_repo_root:
                _blind_adapter = adapter
                # Deny rules are set here for all packages; _repo_root is set
                # per-package in _analyze_one once the worktree is created.
                _base_ctx_overrides["agent_permission_deny"] = BLIND_DENY_RULES + [
                    f"Read({_blind_repo_root}/**)",
                    f"Glob({_blind_repo_root}/**)",
                ]
                _print(
                    "[dim]Blind mode:[/] will delete integration from per-package copy; "
                    "original repo reads blocked"
                )
        except Exception as e:
            _print(f"[yellow]Blind mode: could not init adapter ({e})[/]")

    skipped = [p for p in packages if p not in missing]
    if skipped:
        _print(f"[dim]Skipping {len(skipped)} package(s) with existing analysis:[/]")
        for p in sorted(skipped):
            _print(f"  [dim]· {p}[/]")
        _print("")

    _print(
        f"[bold]Running analyze workflow for {len(missing)} packages[/] "
        f"[dim](concurrency={concurrency})[/]"
    )

    # Persistent run log: one JSON record per event, appended as they happen.
    # Survives mid-run process kills — inspect with: cat <cache_dir>/run_log.jsonl | python3 -m json.tool
    run_log: Path | None = (cache_dir / "run_log.jsonl") if cache_dir else None
    _log_lock = threading.Lock()

    def _append_log(record: dict) -> None:
        if not run_log:
            return
        record.setdefault("ts", datetime.now(timezone.utc).isoformat())
        try:
            run_log.parent.mkdir(parents=True, exist_ok=True)
            with _log_lock:
                with run_log.open("a") as f:
                    f.write(json.dumps(record) + "\n")
        except OSError as e:
            logger.debug("Failed to write run log: %s", e)

    _append_log({
        "event": "start",
        "packages": missing,
        "skipped": skipped,
        "concurrency": concurrency,
    })

    try:
        disk = shutil.disk_usage(base)
        total_gb = disk.total / (1024**3)
        free_gb = disk.free / (1024**3)
        used_pct = (disk.used / disk.total) * 100
        _print(
            f"[dim]Disk: {free_gb:.1f} GB free / {total_gb:.1f} GB total ({used_pct:.0f}% used)[/]"
        )
        _append_log({
            "event": "disk_usage",
            "total_gb": round(total_gb, 2),
            "free_gb": round(free_gb, 2),
            "used_pct": round(used_pct, 1),
        })
    except OSError:
        logger.debug("Could not read disk usage")

    def _analyze_one(package: str) -> tuple[str, bool, str]:
        _append_log({"event": "package_start", "package": package})
        worktree_path: Path | None = None
        try:
            ctx_overrides = dict(_base_ctx_overrides)
            if blind and _blind_adapter and _blind_repo_root:
                try:
                    worktree_path = create_blind_worktree(
                        _blind_repo_root, package, adapter=_blind_adapter
                    )
                except Exception as e:
                    _print(
                        f"  [yellow]Blind [{package}]: worktree setup failed ({e}), running non-blind[/]"
                    )
                    worktree_path = None
                else:
                    removed = _blind_adapter.remove_integration(
                        package, worktree_path, git_source_root=_blind_repo_root
                    )
                    if not removed:
                        raise RuntimeError(
                            f"Blind [{package}]: remove_integration returned no paths. "
                            "Refusing to run a non-blind method-selection eval."
                        )
                    ctx_overrides["_repo_root"] = str(worktree_path)
                    paths_str = "\n".join(f"    {p}" for p in removed)
                    _print(
                        f"  [dim]Blind [{package}]:[/] worktree {worktree_path.name}, "
                        f"removed {len(removed)} path(s):\n{paths_str}"
                    )

            maven_coords = None
            if gt_path:
                meta = load_ground_truth_metadata(gt_path, package)
                maven_coords = meta.get("maven_coordinates")

            result = analyze_package(
                package_name=package,
                repository=repository,
                headless=True,
                skip_git=True,
                ctx_overrides=ctx_overrides or None,
                state_name="analyze-eval",
                maven_coordinates=maven_coords,
            )
            output_path: Path | None = None
            missing_output_error = ""
            if result.success:
                output_path = _find_package_analysis(
                    base,
                    package,
                    aliases=aliases_by_package.get(package, []),
                )
                logger.info(
                    "[%s] analyze done success=True output_path=%s base=%s",
                    package,
                    output_path,
                    base,
                )
                if output_path is None:
                    # Diagnose: log what actually exists so we can identify the mismatch
                    pkg_dir = base / package
                    pkg_exists = pkg_dir.exists()
                    subdirs = (
                        sorted(str(p.name) for p in pkg_dir.iterdir() if p.is_dir())
                        if pkg_exists
                        else []
                    )
                    eval_dir = pkg_dir / "analyze-eval"
                    eval_contents = (
                        sorted(str(p.name) for p in eval_dir.iterdir()) if eval_dir.exists() else []
                    )
                    steps_dir = eval_dir / "steps"
                    step_dirs = (
                        sorted(str(p.name) for p in steps_dir.iterdir())
                        if steps_dir.exists()
                        else []
                    )
                    expected = (
                        pkg_dir / "analyze-eval" / "steps" / "agent_analysis-1" / "output.json"
                    )
                    logger.warning(
                        "[%s] output not found — pkg_dir=%s exists=%s subdirs=%s "
                        "eval_contents=%s step_dirs=%s expected=%s",
                        package,
                        pkg_dir,
                        pkg_exists,
                        subdirs,
                        eval_contents,
                        step_dirs,
                        expected,
                    )
                    _print(
                        f"  [yellow]⚠ [{package}] output not found after success. "
                        f"pkg_dir_exists={pkg_exists} subdirs={subdirs} "
                        f"eval_contents={eval_contents} step_dirs={step_dirs} "
                        f"expected={expected} expected_exists={expected.exists()}[/]"
                    )
                    missing_output_error = (
                        "workflow reported success but wrote no fresh analyze-eval output"
                    )
                if output_path and output_path.exists() and cache_dir:
                    dest = cache_dir / package / "output.json"
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(output_path, dest)
            success = result.success and not missing_output_error
            error_msg = missing_output_error or (
                "" if result.success else (result.error or "unknown")
            )
            _append_log({
                "event": "package_done",
                "package": package,
                "success": success,
                "output_found": output_path is not None,
                "error": error_msg,
            })
            return package, success, error_msg
        except Exception as e:
            tb = traceback.format_exc()
            error_msg = f"{type(e).__name__}: {e}"
            _append_log({
                "event": "package_error",
                "package": package,
                "error": error_msg,
                "traceback": tb,
            })
            logger.warning("Analysis failed for %s:\n%s", package, tb)
            return package, False, error_msg
        finally:
            if worktree_path:
                cleanup_blind_worktree(worktree_path)

    _print(f"  [dim]Queued: {', '.join(missing)}[/]")
    with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures: dict[concurrent.futures.Future, str] = {
            executor.submit(_analyze_one, p): p for p in missing
        }
        completed = 0
        for future in concurrent.futures.as_completed(futures):
            package, success, error = future.result()
            completed += 1
            remaining = len(missing) - completed
            still = f"  [dim]({remaining} remaining)[/]" if remaining else ""
            if success:
                _print(f"  [green]\\u2713[/] {package}{still}")
            else:
                _print(f"  [red]\\u2717[/] {package}: {error}{still}")
                log_path = (
                    base
                    / package
                    / "analyze-eval"
                    / "steps"
                    / "agent_analysis-1"
                    / "logs"
                    / "agent.log"
                )
                if log_path.exists():
                    _print(f"    [dim]logs: {log_path}[/]")

    _append_log({"event": "analysis_complete", "packages": missing})

    _print("")

    if not force and hash_file and current_hashes:
        try:
            hash_file.parent.mkdir(parents=True, exist_ok=True)
            merged = {**(stored_hashes or {}), **current_hashes}
            hash_file.write_text(json.dumps(merged))
        except Exception as e:
            logger.debug("Failed to write prompt hash cache: %s", e)


def write_detail_report(
    results: "list",
    repository: str,
    gt_path: Path,
    output: Path,
) -> None:
    """Write a detailed per-package markdown report of eval results.

    Args:
        results: List of EvalResult from MatrixRunner.run().
        repository: Repository identifier for the report header.
        gt_path: Path to ground truths JSON file.
        output: Destination path for the markdown report.

    For each package, re-loads the analysis output and runs target matching
    to show the full matched/missed/extra breakdown.
    """
    lines: list[str] = []

    def w(s: str = "") -> None:
        lines.append(s)

    w(f"# Matrix Eval Detail: {repository}")
    w()

    summary_rows: list[tuple] = []

    for r in results:
        gt_targets = load_ground_truths(gt_path, r.name)
        critical_gt = [t for t in gt_targets if t.critical]
        output_file = r.tags.get("output_file")

        if r.status != "ok" or not output_file:
            w(f"## {r.name}  _(no analysis)_")
            w()
            if gt_targets:
                w("**Ground truths:**")
                for gt in gt_targets:
                    crit = " critical" if gt.critical else ""
                    op = (
                        f" `{getattr(gt, 'operation', '')}`" if getattr(gt, "operation", "") else ""
                    )
                    w(f"- `{gt.display}` ({gt.file_hint}){op}{crit}")
            w()
            summary_rows.append((r.name, "---", "---", len(critical_gt), r.status))
            continue

        analysis = load_agent_analysis(Path(output_file))
        spec_targets_raw = analysis.analysis.instrumentation_targets
        spec_targets = [from_spec_target(t) for t in spec_targets_raw]
        match_result = match_targets(spec_targets, gt_targets)

        critical_matched = sum(1 for _, gt, _ in match_result.matched if gt.critical)
        precision = len(match_result.matched) / len(spec_targets) if spec_targets else 0.0
        recall: float | None = critical_matched / len(critical_gt) if critical_gt else None

        recall_str = f"{recall:.0%}" if recall is not None else "---"
        w(f"## {r.name}")
        w()
        absorbed = len(match_result.absorbed_spec)
        w(
            f"**Precision:** {precision:.0%}  |  **Recall:** {recall_str}  |  "
            f"Matched: {len(match_result.matched)}  FP: {len(match_result.unmatched_spec)}  "
            f"FN: {len([g for g in match_result.unmatched_gt if g.critical])}"
            + (f"  Absorbed: {absorbed}" if absorbed else "")
        )
        w()

        if match_result.matched:
            w("### Matched")
            w()
            w("| Agent selected | Ground truth | File | Quality |")
            w("|---|---|---|---|")
            for spec, gt, quality in match_result.matched:
                file_ok = ""
                if spec.file_hint and gt.file_hint:
                    sn = spec.file_hint.replace("\\", "/")
                    gn = gt.file_hint.replace("\\", "/")
                    file_ok = " ok" if (sn.endswith(gn) or gn.endswith(sn)) else " miss"
                crit_mark = " (critical)" if gt.critical else ""
                qual = quality.value if hasattr(quality, "value") else str(quality)
                w(
                    f"| `{spec.display}` | `{gt.display}`{crit_mark} "
                    f"| `{gt.file_hint}`{file_ok} | {qual} |"
                )
            w()

        if match_result.unmatched_gt:
            w("### Missed ground truths (false negatives)")
            w()
            w("| Ground truth | File | Critical | Operation |")
            w("|---|---|---|---|")
            for gt in match_result.unmatched_gt:
                crit = "**yes**" if gt.critical else "no"
                op = f"`{getattr(gt, 'operation', '')}`" if getattr(gt, "operation", "") else "---"
                w(f"| `{gt.display}` | `{gt.file_hint}` | {crit} | {op} |")
            w()

        if match_result.absorbed_spec:
            w("### Absorbed (valid alternative hook points)")
            w()
            for spec in match_result.absorbed_spec:
                w(f"- `{spec.display}` (module: `{spec.module}`)")
            w()

        if match_result.unmatched_spec:
            w("### Extra agent targets (false positives)")
            w()
            for spec in match_result.unmatched_spec:
                orig = next(
                    (
                        t
                        for t in spec_targets_raw
                        if t.method.rsplit(".", 1)[-1].lower() == spec.method_name.lower()
                    ),
                    None,
                )
                file_hint = (
                    f" `{orig.file_path}`" if orig and getattr(orig, "file_path", None) else ""
                )
                w(f"- `{spec.display}` (module: `{spec.module}`){file_hint}")
            w()

        summary_rows.append((r.name, f"{precision:.0%}", recall_str, len(critical_gt), "ok"))

    summary = [
        "## Summary",
        "",
        "> **Precision** = agent's correct picks / agent's total picks",
        "> **Recall** = critical GT matched / total critical GT targets",
        "",
        "| Package | Prec | Recall | Critical GT | Status |",
        "|---|---|---|---|---|",
        *[
            f"| {pkg} | {prec} | {recall} | {crit} | {status} |"
            for pkg, prec, recall, crit, status in summary_rows
        ],
        "",
    ]

    output.write_text("\n".join(summary) + "\n---\n\n" + "\n".join(lines))


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _clear_eval_dirs(
    packages: list[str],
    base: Path,
    aliases_by_package: Optional[dict[str, list[str]]] = None,
) -> int:
    """Remove analyze-eval directories for the given packages and aliases."""
    cleared = 0
    for p in packages:
        names: list[str] = []
        seen: set[str] = set()
        for name in [p, slugify_package_name(p), *((aliases_by_package or {}).get(p, []))]:
            if name and name not in seen:
                names.append(name)
                seen.add(name)
        for name in names:
            eval_dir = base / name / "analyze-eval"
            if eval_dir.exists():
                shutil.rmtree(eval_dir)
                cleared += 1
    return cleared


def _filter_by_prompt_hash(
    packages: list[str],
    repository: str,
    base: Path,
    cache_dir: Optional[Path],
    gt_path: Optional[Path],
    _print,
) -> tuple[list[str], dict[str, str], dict[str, str]]:
    """Return (missing_packages, current_hashes, stored_hashes) after prompt-hash gating."""
    adapter = get_apm_adapter(repository)
    aliases_by_package = _analysis_aliases_by_package(adapter, packages, gt_path)
    pkg_to_category = get_package_categories(gt_path)
    categories_present = {pkg_to_category.get(p, "") for p in packages}
    current_hashes = compute_all_category_hashes(repository, categories_present)

    # Try Datadog first, then local file
    stored_hashes = _load_stored_hashes(repository, cache_dir)

    stale_categories = {
        cat for cat, h in current_hashes.items() if cat and stored_hashes.get(cat) != h
    }
    fresh_categories = set(current_hashes) - stale_categories

    if stale_categories:
        if not stored_hashes:
            _print(
                f"[yellow]No stored prompt hashes found — running all packages "
                f"({', '.join(sorted(stale_categories))})[/]"
            )
        else:
            _print(
                f"[yellow]Prompts changed for: {', '.join(sorted(stale_categories))} "
                f"— re-running affected packages[/]"
            )

    missing = [
        p
        for p in packages
        if not _find_package_analysis(
            base,
            p,
            cache_dir=cache_dir,
            aliases=aliases_by_package.get(p, []),
        )
        or pkg_to_category.get(p, "") in stale_categories
    ]

    # Clear stale eval state so agents re-run
    stale_missing = [p for p in missing if pkg_to_category.get(p, "") in stale_categories]
    if stale_missing:
        cleared = _clear_eval_dirs(
            stale_missing,
            base,
            aliases_by_package=aliases_by_package,
        )
        cache_cleared = _clear_eval_cache(
            stale_missing,
            cache_dir,
            aliases_by_package=aliases_by_package,
        )
        if cleared:
            logger.debug("Cleared %d stale analyze-eval state(s) for re-run", cleared)
        if cache_cleared:
            logger.debug("Cleared %d stale eval cache entr(ies) for re-run", cache_cleared)

    skipped = [p for p in packages if p not in missing]
    if skipped and fresh_categories:
        _print(
            f"[dim]Skipping {len(skipped)} package(s) with unchanged prompts "
            f"({', '.join(sorted(fresh_categories))}): {', '.join(skipped)}[/]"
        )

    return missing, current_hashes, stored_hashes


def _analysis_aliases_by_package(
    adapter,
    packages: list[str],
    gt_path: Optional[Path],
) -> dict[str, list[str]]:
    """Build package -> analysis namespace aliases from adapter + GT metadata."""
    aliases: dict[str, list[str]] = {}
    for package in packages:
        metadata = load_ground_truth_metadata(gt_path, package) if gt_path else {}
        package_aliases = adapter.get_eval_analysis_aliases(package, metadata)
        if package_aliases:
            aliases[package] = package_aliases
    return aliases


def _clear_eval_cache(
    packages: list[str],
    cache_dir: Optional[Path],
    aliases_by_package: Optional[dict[str, list[str]]] = None,
) -> int:
    """Remove persistent eval cache entries for packages and aliases being rerun."""
    if not cache_dir:
        return 0
    cleared = 0
    for p in packages:
        names: list[str] = []
        seen: set[str] = set()
        for name in [p, slugify_package_name(p), *((aliases_by_package or {}).get(p, []))]:
            if name and name not in seen:
                names.append(name)
                seen.add(name)
        for name in names:
            cached = cache_dir / name
            if cached.exists():
                if cached.is_dir():
                    shutil.rmtree(cached)
                else:
                    cached.unlink()
                cleared += 1
    return cleared


def _load_stored_hashes(repository: str, cache_dir: Optional[Path]) -> dict[str, str]:
    """Load stored prompt hashes from Datadog or local cache."""
    api_key = os.environ.get("DD_API_KEY", "")
    app_key = os.environ.get("DD_APP_KEY", "")
    site = os.environ.get("DD_SITE", "datadoghq.com")

    if api_key and app_key:
        hashes = fetch_last_category_hashes(repository, site, api_key, app_key)
        if hashes:
            return hashes

    hash_file = cache_dir / "prompt_hashes.json" if cache_dir else None
    if hash_file and hash_file.exists():
        try:
            data: dict[str, str] = json.loads(hash_file.read_text())
            return data
        except Exception as e:
            logger.debug("Failed to read local hash file: %s", e)

    return {}
