"""Analyze-step eval package — method selection evaluation against ground truths."""

from .loaders.hashes import (
    compute_all_category_hashes,
    fetch_last_category_hashes,
    get_package_categories,
)
from .loaders.llmobs import submit_matrix_to_llmobs
from .loaders.matrix import _find_package_analysis, get_matrix_packages
from .target_matching import (
    AlternativeTarget,
    GroundTruthTarget,
    MatchQuality,
    TargetID,
    TargetMatchResult,
    from_ground_truth,
    from_spec_target,
    load_ground_truth_metadata,
    load_ground_truths,
    match_targets,
)
from .task import build_method_selection_suite

__all__ = [
    "AlternativeTarget",
    "GroundTruthTarget",
    "MatchQuality",
    "TargetID",
    "TargetMatchResult",
    "_find_package_analysis",
    "build_method_selection_suite",
    "compute_all_category_hashes",
    "fetch_last_category_hashes",
    "from_ground_truth",
    "from_spec_target",
    "get_matrix_packages",
    "get_package_categories",
    "load_ground_truth_metadata",
    "load_ground_truths",
    "match_targets",
    "submit_matrix_to_llmobs",
]
