"""MethodSelectionTask — APM-specific EvalTask for method selection evals.

Implements the ``EvalTask`` protocol from ``anubis.eval``. Thread-safe:
``run()`` is called concurrently by ``MatrixRunner``.

Typical usage::

    from anubis.eval import EvalItem, EvalSuite, MatrixRunner
    from anubis_apm.eval.analyze.task import build_method_selection_suite

    suite = build_method_selection_suite(adapter, analysis_base=base, cache_dir=cache_dir)
    results = MatrixRunner().run(suite)
"""

import json
import logging
from pathlib import Path
from typing import List, Optional

from anubis.core.git import get_git_branch
from anubis.eval.base import EvalItem, EvalSuite
from anubis.eval.models import EvalResult
from anubis_apm.eval.analyze.loaders.hashes import get_package_categories
from anubis_apm.eval.analyze.loaders.matrix import (
    _find_package_analysis,
    get_matrix_packages,
    load_agent_analysis,
)
from anubis_apm.eval.analyze.target_matching import (
    MatchQuality,
    TargetMatchResult,
    from_spec_target,
    load_ground_truth_metadata,
    load_ground_truths,
    match_targets,
)
from anubis_apm.repo_adapters.base import APMAdapterMixin
from anubis_apm.shared.naming import slugify_package_name

logger = logging.getLogger(__name__)


def _extract_model_from_state(state: dict) -> str:
    """Extract the model from the first agent_run that has one in state.json."""
    for step in state.get("steps", {}).values():
        for run in step.get("metrics", {}).get("agent_runs", []):
            if run.get("model"):
                return str(run["model"])
    return ""


def _print_package_match(
    package: str,
    result: TargetMatchResult,
    fp: int,
    fn: int,
) -> None:
    exact = sum(
        1 for _, _, q in result.matched if (q.value if hasattr(q, "value") else q) == "exact"
    )
    alt = sum(
        1
        for _, _, q in result.matched
        if (q.value if hasattr(q, "value") else q) in ("alternative", "class_absent")
    )
    covered = len(result.absorbed_spec)
    lines = [
        f"  {package}: exact-matches={exact} alt-matches={alt} covered-alts={covered} fp={fp} critical-misses={fn}"
    ]
    for spec, gt, quality in result.matched:
        q = quality.value if hasattr(quality, "value") else quality
        lines.append(f"    ✓ [{q}] {spec.display} → {gt.display}")
    for spec in result.absorbed_spec:
        lines.append(f"    ~ [covered alt] {spec.display}")
    for gt in result.unmatched_gt:
        crit = " [critical]" if gt.critical else ""
        lines.append(f"    ✗ [miss{crit}] {gt.display}")
    for spec in result.unmatched_spec:
        lines.append(f"    ✗ [FP] {spec.display}")
    print("\n".join(lines) + "\n")


class MethodSelectionTask:
    """Run method selection eval for one package and return a scored EvalResult."""

    def __init__(
        self,
        adapter: APMAdapterMixin,
        analysis_base: Optional[Path] = None,
        cache_dir: Optional[Path] = None,
    ) -> None:
        self._adapter = adapter
        self._base = analysis_base or Path(".analysis")
        self._cache_dir = cache_dir
        self._gt_path = adapter.get_ground_truths_path()
        self._pkg_categories = get_package_categories(self._gt_path)

    def run(self, item: EvalItem) -> EvalResult:
        package = item.name
        category = self._pkg_categories.get(package, "")
        aliases = self._analysis_aliases(package)
        tags = {
            "category": category,
            "repository": self._adapter.repository_id,
            "branch": get_git_branch(),
        }

        analyze_output = _find_package_analysis(
            self._base,
            package,
            cache_dir=self._cache_dir,
            aliases=aliases,
        )
        if not analyze_output:
            return EvalResult(name=package, status="no_analysis", tags=tags)

        tags["output_file"] = str(analyze_output)
        cost, duration, turns, tokens, model = self._load_state_metrics(package)
        if model:
            tags["model"] = model

        if not self._gt_path:
            return EvalResult(
                name=package, status="error", error="no ground truths path", tags=tags
            )

        try:
            analysis = load_agent_analysis(analyze_output)
            # Use the eval package name first (reliable for all repos); fall back to
            # analysis.package_name for cases where the eval name differs from the GT.
            # Java agents write Maven coords (com.rabbitmq:amqp-client) which don't
            # match GT slugs, so the eval name is always the better primary key.
            gt_targets = load_ground_truths(self._gt_path, package) or load_ground_truths(
                self._gt_path, analysis.package_name
            )

            if not gt_targets:
                return EvalResult(name=package, status="no_ground_truths", tags=tags)

            # Acceptable targets are never penalized if missed — exclude from recall denominator.
            critical_gt = [gt for gt in gt_targets if gt.critical and not gt.acceptable]
            tags["critical_targets"] = str(len(critical_gt))

            spec_targets = [from_spec_target(t) for t in analysis.analysis.instrumentation_targets]
            result = match_targets(spec_targets, gt_targets)

            total_matched = len(result.matched)
            critical_matched = sum(
                1 for _, gt, _ in result.matched if gt.critical and not gt.acceptable
            )
            critical_unmatched = [gt for gt in result.unmatched_gt if gt.critical]

            absorbed = len(result.absorbed_spec)
            fp = len(result.unmatched_spec)
            fn = len(critical_unmatched)
            _print_package_match(package, result, fp, fn)

            metrics: dict[str, float | None] = {
                "true_positives": float(total_matched),
                "critical_true_positives": float(critical_matched),
                "critical_gt_count": float(len(critical_gt)),
                "false_positives": float(fp),
                "false_negatives": float(fn),
                "absorbed": float(absorbed),
                "exact_matches": float(
                    sum(1 for _, _, q in result.matched if q == MatchQuality.EXACT)
                ),
                "alternative_matches": float(
                    sum(1 for _, _, q in result.matched if q == MatchQuality.ALTERNATIVE)
                ),
                "input_tokens": float(tokens.get("input", 0)),
                "output_tokens": float(tokens.get("output", 0)),
                "cache_read_input_tokens": float(tokens.get("cache_read", 0)),
            }
            if spec_targets:
                metrics["precision"] = total_matched / len(spec_targets)
            if critical_gt:
                metrics["recall"] = critical_matched / len(critical_gt)
            if cost:
                metrics["cost_usd"] = cost
            if duration:
                metrics["duration_s"] = duration
            if turns:
                metrics["num_turns"] = float(turns)

            return EvalResult(
                name=package,
                metrics=metrics,
                tags=tags,
                cost_usd=cost,
                duration_s=duration,
            )

        except Exception as exc:
            logger.error("MethodSelectionTask failed for %s: %s", package, exc)
            return EvalResult(name=package, status="error", error=str(exc), tags=tags)

    def _analysis_aliases(self, package: str) -> list[str]:
        """Return adapter-specific analysis aliases for this eval package."""
        if not self._gt_path:
            return []
        metadata = load_ground_truth_metadata(self._gt_path, package)
        return self._adapter.get_eval_analysis_aliases(package, metadata)

    def _load_state_metrics(self, package: str) -> tuple[float, float, int, dict, str]:
        """Load cost/duration/turns/token/model metrics from state.json."""
        normalized = slugify_package_name(package)
        names: list[str] = []
        seen: set[str] = set()
        for name in [package, normalized, *self._analysis_aliases(package)]:
            if name and name not in seen:
                names.append(name)
                seen.add(name)
        for name in names:
            state_path = self._base / name / "analyze-eval" / "state.json"
            if state_path.exists():
                try:
                    state = json.loads(state_path.read_text())
                    model = _extract_model_from_state(state)
                    return (
                        state.get("total_cost_usd", 0.0),
                        state.get("total_duration_seconds", 0.0),
                        state.get("total_turns", 0),
                        {
                            "input": state.get("total_input_tokens", 0),
                            "output": state.get("total_output_tokens", 0),
                            "cache_read": state.get("total_cache_read_input_tokens", 0),
                        },
                        model,
                    )
                except Exception as exc:
                    logger.debug("Could not read state.json for %s: %s", package, exc)
        return 0.0, 0.0, 0, {}, ""


def build_method_selection_suite(
    adapter: APMAdapterMixin,
    analysis_base: Optional[Path] = None,
    cache_dir: Optional[Path] = None,
    packages: Optional[List[str]] = None,
    repository: Optional[str] = None,
    concurrency: int = 0,
) -> EvalSuite:
    """Build an EvalSuite for method selection evaluation.

    Args:
        adapter: Repo adapter providing ground truths and repository info.
        analysis_base: Base directory for analysis outputs (default: ``.analysis/``).
        cache_dir: Persistent eval cache that survives ``--force`` clears.
        packages: Packages to evaluate (default: all in ground truths).
        repository: Override repository ID (default: adapter's ID).
        concurrency: Max parallel workers (0 = one per package).
    """
    repo = repository or adapter.repository_id
    resolved: List[str] = packages if packages is not None else get_matrix_packages(adapter)

    task = MethodSelectionTask(adapter, analysis_base=analysis_base, cache_dir=cache_dir)
    return EvalSuite(
        name=f"method_selection_{repo}",
        items=[EvalItem(name=p) for p in resolved],
        task=task,
        concurrency=concurrency,
        dataset_name=f"method_selection_{repo}",
    )
