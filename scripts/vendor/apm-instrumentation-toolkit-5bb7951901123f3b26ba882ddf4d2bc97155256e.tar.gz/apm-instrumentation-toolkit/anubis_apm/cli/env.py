"""Environment bootstrapping — single source of truth is config.yaml.

Loads env configuration from .anubis/config.yaml (``env:`` section).
Falls back to DEFAULT_ENV if the section is absent or the file is missing.
All DD_* / DATADOG_* vars inherited from the shell are stripped first —
no shell contamination possible.

IMPORTANT: init_env() MUST be the first callable in every entry point before
any anubis or ddtrace imports. Violating this causes ddtrace to lock onto
wrong agent URLs or stale credentials from the shell.
"""

import logging
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

from rich.console import Console as _Console

_console = _Console(stderr=True)

_SENSITIVE_KEYS = {"DD_API_KEY", "DD_APP_KEY"}

_DD_AUTH_DOMAIN = "app.datadoghq.com"
_APPGATE_CHECK_URL = "https://datadoghq.atlassian.net/wiki"
_APPGATE_CHECK_TIMEOUT = 5

# Canonical defaults — single definition, used both for env bootstrapping
# and for writing into config.yaml on first run (ensure_env_defaults).
DEFAULT_ENV: dict[str, str] = {
    "DD_TRACE_AGENT_URL": "http://localhost:18127",
    "DD_AGENT_HOST": "localhost",
    "DD_TRACE_AGENT_PORT": "18127",
    "DD_SITE": "datadoghq.com",
    "DD_SERVICE": "apm-ai-integration-toolkit",
    "DD_TRACE_SAMPLE_RATE": "1.0",
    "DD_TRACE_PARTIAL_FLUSH_ENABLED": "true",
    "DD_TRACE_PARTIAL_FLUSH_MIN_SPANS": "1",
    "DD_LOGS_INJECTION": "true",
    "DD_LLMOBS_AGENTLESS_ENABLED": "true",
    "DD_APM_LONG_RUNNING_FLUSH_INTERVAL": "10",
    "DD_APM_REQUIRED_ORG": "8dee7c38-00cb-11ea-a77b-8b5a08d3b091",
}
# DD_ENV and DD_VERSION are set dynamically in init_env() and intentionally
# omitted here so ensure_env_defaults() does not freeze them into config.yaml.


def _require_dd_auth() -> None:
    """Inject Org 2 credentials via dd-auth — mandatory for local non-CI runs.

    Fails with sys.exit() if:
    - dd-auth binary not found on PATH
    - Appgate VPN not reachable
    - dd-auth returns non-zero

    On success, sets DD_API_KEY, DD_APP_KEY, DD_SITE in os.environ.
    """
    if not shutil.which("dd-auth"):
        print(
            "Error: dd-auth not found. Install it with: brew install datadog/tap/dd-auth",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        req = urllib.request.Request(_APPGATE_CHECK_URL, method="HEAD")
        urllib.request.urlopen(req, timeout=_APPGATE_CHECK_TIMEOUT)  # noqa: S310
    except (urllib.error.URLError, OSError):
        print(
            "Error: Appgate VPN not connected — dd-auth requires VPN access to Datadog internal.",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        result = subprocess.run(
            ["dd-auth", "--domain", _DD_AUTH_DOMAIN, "--force-app-key", "--output"],
            capture_output=True,
            text=True,
            timeout=120,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"Error: dd-auth invocation failed: {e}", file=sys.stderr)
        sys.exit(1)

    if result.returncode != 0:
        stderr = result.stderr.strip()
        print(f"Error: dd-auth failed (exit {result.returncode}): {stderr}", file=sys.stderr)
        sys.exit(1)

    for line in result.stdout.strip().splitlines():
        if "=" in line:
            key, _, value = line.partition("=")
            key = key.strip()
            if key in ("DD_API_KEY", "DD_APP_KEY", "DD_SITE"):
                os.environ[key] = value.strip()


def init_env(toolkit_root: Path) -> None:
    """Bootstrap the process environment from config.yaml.

    MUST be the first callable in every entry point — before any anubis or
    ddtrace imports. Sets ANUBIS_TOOLKIT_ROOT, strips all inherited DD_*/
    DATADOG_* shell vars, then applies the ``env:`` section from config.yaml
    (falling back to DEFAULT_ENV). Credentials come from dd-auth (locally)
    or from CI-injected vars (in CI).

    Args:
        toolkit_root: Path to the toolkit root (user data dir or source tree root).
    """
    # Guard: ddtrace must not be imported before init_env() runs. If it is,
    # ddtrace has already cached DD_API_KEY=None from the pre-init environment
    # and LLMObs.enable(agentless=True) will raise ValueError later.
    # This catches the bug at the source rather than as a cryptic downstream error.
    if "ddtrace" in sys.modules:
        _console.print(
            "[bold red]ERROR:[/] ddtrace was imported before init_env() — "
            "environment variables will not take effect.\n"
            "Ensure no top-level import in the entry point transitively imports "
            "anubis.core.tracing before calling init_env()."
        )

    os.environ.setdefault("ANUBIS_TOOLKIT_ROOT", str(toolkit_root))

    # Create ~/.dd-apm/ before ddtrace initialises so DD_TRACE_LOG_FILE
    # (set below) never fails with FileNotFoundError.
    try:
        (Path.home() / ".dd-apm").mkdir(parents=True, exist_ok=True)
    except OSError as e:
        logging.debug("Could not create ~/.dd-apm log directory: %s", e)

    # In CI or remote workspaces, save injected credentials before stripping.
    ci_creds: dict[str, str] = {}
    if os.environ.get("CI") or os.environ.get("DD_APM_REMOTE"):
        for k in ("DD_API_KEY", "DD_APP_KEY", "DD_SITE"):
            if k in os.environ:
                ci_creds[k] = os.environ[k]

    # Strip DD_* / DATADOG_* from inherited env — no shell contamination possible.
    # This prevents dd-trace-js dev shells (DD_TRACE_AGENT_URL=:8126) from silently
    # redirecting traces away from the toolkit's Org 2 agent on port 18127.
    #
    # Exception: DD_APM_* vars are this toolkit's own control flags (DD_APM_MOCK_AGENTS,
    # DD_APM_SKIP_SYNC, etc.) — they are legitimately set by CI / tests and must survive.
    # DD_TRACE_ENABLED / DD_TRACE_DEBUG are behavioral overrides, not credentials.
    _KEEP_EXACT = frozenset({"DD_TRACE_ENABLED", "DD_TRACE_DEBUG"})
    stripped: list[str] = []
    for key in list(os.environ.keys()):
        if key.startswith(("DD_", "DATADOG_")):
            if key.startswith("DD_APM_") or key in _KEEP_EXACT:
                continue
            del os.environ[key]
            stripped.append(key)

    # Log stripped vars so users aren't silently surprised.
    # Skip CI credentials (they'll be restored below) and the log file path (set per-run).
    _ci_keys = set(ci_creds)
    _silent_keys = {"DD_TRACE_LOG_FILE"}
    visible_stripped = sorted(k for k in stripped if k not in _ci_keys and k not in _silent_keys)
    if visible_stripped:
        _console.print(
            f"  [dim]○ Stripped {len(visible_stripped)} shell DD_*/DATADOG_* var(s):[/] "
            f"[dim]{', '.join(visible_stripped)}[/]"
        )
        _console.print(
            "  [dim]  Customize via [cyan]env:[/][dim] in [cyan]~/.anubis/config.yaml[/]"
        )

    # config.yaml is the single source of truth for env defaults.
    config_file = toolkit_root / ".anubis" / "config.yaml"
    if config_file.exists():
        try:
            import yaml  # noqa: PLC0415

            data = yaml.safe_load(config_file.read_text()) or {}
            # Merge: DEFAULT_ENV provides the baseline; config.yaml overrides specific keys.
            # Using `or DEFAULT_ENV` would silently discard all defaults when any env: key
            # is present — e.g. a config with only DD_SERVICE set would lose DD_TRACE_AGENT_URL.
            env_section = {**DEFAULT_ENV, **data.get("env", {})}
        except Exception as e:
            logging.debug("Could not load config.yaml env section: %s — using defaults", e)
            env_section = DEFAULT_ENV
    else:
        env_section = DEFAULT_ENV

    # Log any values that differ from DEFAULT_ENV (user customisations in config.yaml).
    # Only compare keys that exist in DEFAULT_ENV — keys outside it (DD_ENV, DD_VERSION)
    # are set dynamically and are not overrides.
    overrides = {
        k: str(v)
        for k, v in env_section.items()
        if k in DEFAULT_ENV and k not in _SENSITIVE_KEYS and str(v) != DEFAULT_ENV[k]
    }
    if overrides:
        parts = "  ".join(f"[cyan]{k}[/][dim]={v}[/]" for k, v in sorted(overrides.items()))
        _console.print(f"  [dim]○ Config overrides:[/] {parts}")

    # DD_ENV and DD_VERSION are always computed — strip stale values from
    # config.yaml so they don't shadow the dynamic logic below.
    _DYNAMIC_KEYS = {"DD_ENV", "DD_VERSION"}
    for k, v in env_section.items():
        if k in _DYNAMIC_KEYS:
            continue
        s = str(v)
        os.environ[k] = str(Path(s).expanduser()) if "~" in s else s

    # _DD_APM_TRACING_AGENTLESS_ENABLED must mirror the FINAL DD_LLMOBS_AGENTLESS_ENABLED
    # so APM spans and LLMObs spans use the same submission path. This MUST run after
    # the env_section loop above applies config.yaml — computing it earlier captures
    # the pre-config default and ignores a user who sets DD_LLMOBS_AGENTLESS_ENABLED:
    # false in config.yaml (which would then wrongly skip the local-agent preflight).
    _llmobs_agentless = os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "true").lower() not in (
        "0",
        "false",
    )
    os.environ["_DD_APM_TRACING_AGENTLESS_ENABLED"] = "true" if _llmobs_agentless else "false"

    # DD_ENV: "ci" in any CI environment, "production" for frozen binary (dogbrew)
    # installs, "development" for source checkouts.  CI takes priority over frozen
    # because the smoke-frozen job runs the binary inside CI.
    _is_ci = bool(
        os.environ.get("CI") or os.environ.get("BUILDKITE") or os.environ.get("GITLAB_CI")
    )
    _is_frozen = bool(getattr(sys, "frozen", False))
    if _is_ci:
        os.environ["DD_ENV"] = "ci"
    elif _is_frozen:
        os.environ["DD_ENV"] = "production"
    else:
        os.environ["DD_ENV"] = "development"

    # DD_VERSION: always the installed package version.
    try:
        from importlib.metadata import version as _pkg_version  # noqa: PLC0415

        os.environ["DD_VERSION"] = _pkg_version("dd-apm-integration-ai-toolkit")
    except Exception:
        os.environ["DD_VERSION"] = "dev"

    # Per-invocation tracer log — one file per dd-apm run, never shared across runs.
    # Set after env_section so it can't be overridden via config.yaml.
    _ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    _log_dir = Path.home() / ".dd-apm" / "tracer-logs"
    try:
        _log_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        _log_dir = Path.home() / ".dd-apm"
    os.environ["DD_TRACE_LOG_FILE"] = str(_log_dir / f"tracer-{_ts}.log")

    # Credentials: CI system injects them in CI; dd-auth is mandatory locally.
    # Skip dd-auth for commands that run before credentials are needed — setup, doctor,
    # config, and update must work for new users who haven't installed dd-auth yet.
    # Peek at sys.argv[1] so this remains argparse-free (init_env runs before parsing).
    _AUTH_EXEMPT = frozenset({"setup", "doctor", "config", "help", "update", "version", "steps"})
    _first_arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if ci_creds:
        os.environ.update(ci_creds)
    elif (
        not os.environ.get("CI")
        and not os.environ.get("DD_APM_REMOTE")
        and _first_arg not in _AUTH_EXEMPT
    ):
        _require_dd_auth()


def ensure_env_defaults(config_file: Path) -> None:
    """Write ``env: DEFAULT_ENV`` into config.yaml if the ``env:`` key is absent.

    Preserves all other keys. Prints one line if it writes.

    Args:
        config_file: Path to .anubis/config.yaml.
    """
    if not config_file.exists():
        return

    try:
        import yaml  # noqa: PLC0415

        data = yaml.safe_load(config_file.read_text()) or {}

        dirty = False

        if "env" not in data:
            data["env"] = DEFAULT_ENV
            dirty = True
            print(f"[dd-apm] Wrote default env section to {config_file}")

        # Remove stale DD_ENV / DD_VERSION from config.yaml — these are now
        # computed dynamically in init_env() and must not be pinned.
        if "env" in data:
            _DYNAMIC_KEYS = {"DD_ENV", "DD_VERSION"}
            stale = _DYNAMIC_KEYS & data["env"].keys()
            if stale:
                for k in stale:
                    del data["env"][k]
                dirty = True

        if dirty:
            config_file.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True))
    except Exception as e:
        logging.debug("Could not update config.yaml with env defaults: %s", e)
