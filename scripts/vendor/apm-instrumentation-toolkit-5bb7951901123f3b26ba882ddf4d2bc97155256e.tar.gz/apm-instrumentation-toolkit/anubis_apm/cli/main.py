"""Main CLI entry point with parser setup and command routing.

IMPORTANT: This module MUST NOT import anything from ``anubis`` or
``anubis_apm`` (except ``.env``) at the **module level**.  The setuptools
console-script entry point (``dd-apm``) imports this module *before*
``console_entry()`` can call ``init_env()``.  Any top-level import that
transitively reaches ``ddtrace`` (e.g. ``anubis.core.workflow`` →
``anubis.core.tracing`` → ``from ddtrace.llmobs import LLMObs``) will
cause ddtrace to cache ``DD_API_KEY=None`` from the pre-init environment,
and ``LLMObs.enable(agentless_enabled=True)`` will later raise
``ValueError: DD_API_KEY is required …`` even though dd-auth already
injected it.

All ``anubis.*`` / ``anubis_apm.*`` imports are deferred to function
bodies below.
"""

import argparse
import importlib.metadata
import logging
import os
import sys
from pathlib import Path

from .env import ensure_env_defaults, init_env


class _GroupedHelpFormatter(argparse.RawDescriptionHelpFormatter):
    """Suppress the flat auto-generated subcommand listing.

    The grouped command listing lives in the epilog instead.
    """

    def _format_action(self, action: argparse.Action) -> str:
        if isinstance(action, argparse._SubParsersAction):
            return ""
        return super()._format_action(action)


# Silence ddtrace's writer flush errors (e.g. "failed to send, dropping N traces").
# These appear when the Datadog agent isn't running — expected for CLI management
# commands (sync, config, status, etc.) that don't start the agent.  For workflow
# commands the preflight check ensures the agent is running, so flush succeeds and
# there is nothing to suppress.
logging.getLogger("ddtrace.internal.writer.writer").setLevel(logging.CRITICAL)

EPILOG = """
Most workflow commands share these flags:
  --prompt <text>                 Guide the agent with extra context or instructions
  --model  <id>                   Override the model  (e.g. anthropic/claude-opus-4-7)
  --fresh                         Discard state and start over
  --from   <step>                 Resume from a specific step
  --from <step> --rollback-git    Resume and reset repo files to step's git snapshot
  --stop-after <step>             Run up to and including <step>, then stop
  --skip   <step1,step2>          Skip steps
  --workspace [name]              Run in a remote Datadog workspace

Core workflows:
  create  <pkg>                   Instrument a package end-to-end  ← start here
    --mode=agent                    Fully autonomous (no prompts)
  analyze <pkg>                   Identify classes and methods to instrument
    --experience                    Seed from past runs (experimental)
  feature <pkg>                   Auto-detect and add missing features
                                    (db.system, peer.service, span.kind, ...)
  llm-obs <pkg>                   Generate LLM Observability layer

Evaluation:
  dd-apm eval run-matrix                                    Score packages against ground truths
  dd-apm eval run-matrix --run                              Run missing analyses, then score
  dd-apm eval run-matrix --packages kafkajs,redis           Evaluate specific packages only
  dd-apm eval run-matrix --category databases               Filter by category
  dd-apm eval run-matrix --submit                           Submit results to LLMObs Experiments
  dd-apm eval run-matrix --type integration-gen             Run integration-gen eval (evalya oracle)
  dd-apm eval run-matrix --type integration-gen --run       Run workflow + evalya oracle per package
  dd-apm eval clean kafkajs                                 Remove generated integration for re-eval

Refinement workflows:
  test    <pkg>                   Diagnose and fix failing tests
  lint    <pkg>                   Fix linting issues
  review  <pkg>                   AI code review
  semantic <pkg>                  Semantic validation via evalya

State & navigation:
  status  <pkg>                   Show workflow progress
  list                            List all integrations
  clean   <pkg>                   Reset state  [--workflow <name> for one workflow]
  diff    <pkg>                   View integration changes
  rollback <pkg> <step>           Roll back to a previous checkpoint
    --rollback-git                  Also reset repo files to that step's git snapshot
  steps   <workflow>              List steps for a workflow (auto-discovered)
  pr      <pkg>                   Open a pull request
    --babysit                       Watch CI and auto-fix failures

Setup & health:
  setup                           Install missing deps and configure (first-time)
  doctor                          Check prerequisites and environment health
  smoke                           End-to-end smoke test (spawns a haiku agent)
  config                          Manage configuration  (init / list / add-repo / ...)
  version                         Show toolkit version

Remote execution:
  --workspace [name]              Run any workflow in a Datadog workspace
  workspace list                  List active workspaces
  workspace delete <name>         Delete a workspace
  workspace deploy <name>         Re-deploy toolkit to a workspace

Other:
  eval    run-matrix              Score packages against ground truths
    --run                           Run missing analyses first
    --packages <x,y>                Evaluate specific packages only
    --submit                        Submit results to LLMObs Experiments
  sync                            Manage the S3 experience store
  update                          Update toolkit to the latest version
"""


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser with all commands registered."""
    from .commands import (  # noqa: PLC0415
        register_config_commands,
        register_eval_commands,
        register_feature_commands,
        register_feedback_commands,
        register_post_workflow_commands,
        register_pr_commands,
        register_setup_commands,
        register_state_commands,
        register_steps_commands,
        register_sync_commands,
        register_workflow_commands,
        register_workspace_commands,
    )

    try:
        _version = importlib.metadata.version("dd-apm-integration-ai-toolkit")
    except importlib.metadata.PackageNotFoundError:
        _version = "dev"

    parser = argparse.ArgumentParser(
        description=(
            "dd-apm: Datadog APM Integration Toolkit\n\n"
            "Automates APM instrumentation for Datadog tracers using AI agents.\n"
            "Run any command with --help for detailed usage  (e.g. dd-apm create --help)\n"
            "Questions or issues? Reach out in #apm-integrations-ai-toolkit."
        ),
        formatter_class=_GroupedHelpFormatter,
        epilog=EPILOG,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {_version}")

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")

    # Register all command groups
    register_setup_commands(subparsers)
    register_config_commands(subparsers)
    register_workflow_commands(subparsers)
    register_feature_commands(subparsers)
    register_feedback_commands(subparsers)
    register_state_commands(subparsers)
    register_pr_commands(subparsers)
    register_post_workflow_commands(subparsers)
    register_sync_commands(subparsers)
    register_eval_commands(subparsers)
    register_steps_commands(subparsers)
    register_workspace_commands(subparsers)

    # Version command (same output as --version, discoverable as a subcommand)
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(handler=lambda _args: print(_version) or 0)

    # Help command
    subparsers.add_parser("help", help="Show this help message")

    return parser


def console_entry() -> int:
    """Console-scripts entry point — bootstraps env before running CLI.

    Called by both the setuptools-installed ``dd-apm`` wrapper and ``bin/dd-apm``.
    ``bin/dd-apm`` calls ``init_env()`` first, so the ``ANUBIS_TOOLKIT_ROOT``
    guard below skips a duplicate call.

    Tracing is NOT initialised here — it is deferred to run_preflight() so the
    tracer writer only starts after the Docker agents are confirmed healthy.
    """
    # Derive toolkit root from package location (anubis_apm/cli/main.py -> repo root)
    toolkit_root = Path(__file__).resolve().parent.parent.parent
    # Prefer ANUBIS_TOOLKIT_ROOT if already set (e.g. by bin/dd-apm)
    if "ANUBIS_TOOLKIT_ROOT" not in os.environ:
        init_env(toolkit_root)

    # Write default env section to config.yaml if absent (idempotent).
    ensure_env_defaults(toolkit_root / ".anubis" / "config.yaml")

    return main()


def main() -> int:
    """Main entry point for the CLI.

    Wraps all execution in a terminal guard to ensure the terminal is always
    restored to a usable state, even if a workflow crashes or is interrupted.
    """
    from anubis.core.output import restore_terminal_for_input  # noqa: PLC0415
    from anubis.core.tracing import shutdown_tracing  # noqa: PLC0415

    try:
        return _run_cli()
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    finally:
        shutdown_tracing()
        restore_terminal_for_input()


def _run_cli() -> int:
    """Run the CLI commands."""
    from anubis.core.config import ConfigLoader  # noqa: PLC0415

    from .commands.config import cmd_config_init  # noqa: PLC0415
    from .update_check import check_and_warn, start_check  # noqa: PLC0415

    parser = build_parser()
    args = parser.parse_args()

    if not args.command or args.command == "help":
        parser.print_help()
        return 0

    # Start background version check (cached 24h, non-blocking).
    # Skip for the update command itself — pointless to warn while upgrading.
    if args.command != "update":
        start_check()

    # First-run auto-setup: if no config exists and we're in an interactive
    # terminal, guide the user through initial configuration automatically.
    # Skip for config/help commands — they handle the unconfigured state themselves.
    _setup_exempt = {"config", "help", "setup", "doctor", "version", "steps"}
    if args.command not in _setup_exempt and sys.stdin.isatty():
        loader = ConfigLoader()
        if not loader.exists():
            print("Welcome to dd-apm! Let's get you set up first.")
            print()
            init_result: int = cmd_config_init(args) or 0
            if init_result != 0:
                return init_result
            print()

    if hasattr(args, "handler"):
        result = args.handler(args)
        # Show update warning after the command so it doesn't clutter the output.
        if args.command != "update":
            check_and_warn()
        return result if isinstance(result, int) else 0

    parser.print_help()
    return 1
