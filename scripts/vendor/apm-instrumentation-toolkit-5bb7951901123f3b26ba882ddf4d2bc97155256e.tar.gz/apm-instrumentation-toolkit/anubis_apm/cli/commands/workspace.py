"""Workspace management commands: list, delete, deploy."""

import argparse
import logging

from anubis.workspace.manager import WorkspaceManager
from anubis.workspace.models import WorkspaceConfig, WorkspaceInfo

from ..console import console, print_header, print_success

logger = logging.getLogger(__name__)


def cmd_workspace_list(args: argparse.Namespace) -> int:
    """List active workspaces."""
    print_header("dd-apm workspace list")

    manager = WorkspaceManager()
    try:
        workspaces = manager.list_workspaces()
    except RuntimeError as exc:
        console.print(f"[red]Error:[/] {exc}")
        return 1

    if not workspaces:
        console.print("[dim]No active workspaces.[/]")
        return 0

    for ws in workspaces:
        name = ws.get("name", "unknown")
        console.print(f"  [cyan]{name}[/]  (ssh: workspace-{name})")

    console.print()
    console.print(f"[dim]{len(workspaces)} workspace(s)[/]")
    return 0


def cmd_workspace_delete(args: argparse.Namespace) -> int:
    """Delete a workspace."""
    name = args.name
    print_header(f"dd-apm workspace delete {name}")

    manager = WorkspaceManager()
    if not manager.workspace_exists(name):
        console.print(f"[yellow]Workspace '{name}' not found.[/]")
        return 1

    try:
        manager.delete(name)
        print_success(f"Workspace '{name}' deleted.")
        return 0
    except RuntimeError as exc:
        console.print(f"[red]Error:[/] {exc}")
        return 1


def cmd_workspace_deploy(args: argparse.Namespace) -> int:
    """Deploy or update the toolkit in an existing workspace."""
    name = args.name
    print_header(f"dd-apm workspace deploy {name}")

    config = WorkspaceConfig(name=name)
    manager = WorkspaceManager(config)

    if not manager.workspace_exists(name):
        console.print(f"[yellow]Workspace '{name}' not found.[/]")
        console.print("Create one with: [cyan]dd-apm <command> --workspace[/]")
        return 1

    workspace = WorkspaceInfo(name=name, ssh_host=f"workspace-{name}")

    console.print("Deploying toolkit...")
    try:
        manager.deploy_toolkit(workspace)
        print_success(f"Toolkit deployed to workspace '{name}'.")
        return 0
    except RuntimeError as exc:
        console.print(f"[red]Error:[/] {exc}")
        return 1


def register_workspace_commands(subparsers: argparse._SubParsersAction) -> None:
    """Register workspace management subcommands."""
    ws_parser = subparsers.add_parser(
        "workspace",
        help="Manage remote Datadog workspaces",
    )
    ws_sub = ws_parser.add_subparsers(dest="workspace_command", metavar="<action>")

    # workspace list
    list_parser = ws_sub.add_parser("list", help="List active workspaces")
    list_parser.set_defaults(handler=cmd_workspace_list)

    # workspace delete
    delete_parser = ws_sub.add_parser("delete", help="Delete a workspace")
    delete_parser.add_argument("name", help="Workspace name to delete")
    delete_parser.set_defaults(handler=cmd_workspace_delete)

    # workspace deploy
    deploy_parser = ws_sub.add_parser("deploy", help="Deploy or update the toolkit in a workspace")
    deploy_parser.add_argument("name", help="Workspace name to deploy to")
    deploy_parser.set_defaults(handler=cmd_workspace_deploy)

    ws_parser.set_defaults(handler=lambda _args: ws_parser.print_help() or 0)
