"""dd-apm sync — manage the remote experience store.

Provides commands to push, pull, list, and inspect workflow run artifacts
stored in S3. S3 sync is always on; requires AWS credentials (see dd-apm sync setup).

Usage::

    dd-apm sync setup                      Check prerequisites and auth
    dd-apm sync setup --fix                Auto-fix common setup issues
    dd-apm sync login                      Log in via SSO (opens browser)
    dd-apm sync push kafkajs               Push current run to S3
    dd-apm sync pull                       Pull latest runs across all integrations
    dd-apm sync pull kafkajs               Pull latest run for a specific integration
    dd-apm sync pull kafkajs --run-id ...  Pull specific run
    dd-apm sync list                       List all stored runs
    dd-apm sync list kafkajs               List runs for a specific integration
    dd-apm sync list --config-hash <hash>  Filter by config version
    dd-apm sync inspect <run-id>           Show full manifest for a run
    dd-apm sync refresh                    Refresh local S3 index
"""

import json
import subprocess

from rich.table import Table

from anubis.core.config import get_config
from anubis.core.experience.cache import ExperienceCache
from anubis.core.state.models import WorkflowState
from anubis_apm.storage.auth import (
    _SSO_PROFILE,
    attempt_setup_fixes,
    check_prerequisites,
)
from anubis_apm.storage.s3_client import S3RunStorage
from anubis_apm.storage.workflow_hooks import push_run_to_s3

from ..console import console, print_header
from ..decorators import with_config


def _make_storage() -> S3RunStorage:
    """Create S3RunStorage."""
    return S3RunStorage.from_env()


def _require_client(storage: S3RunStorage) -> bool:
    """Print an error and return False when S3 client is unavailable."""
    if storage.client is None:
        console.print(
            "[yellow]S3 sync unavailable[/] — run [cyan]dd-apm sync setup --fix[/] to configure."
        )
        return False
    return True


@with_config
def cmd_sync_push(args) -> int:
    """Push the current run for an integration to S3."""
    namespace = args.integration
    repository = getattr(args, "repository", None) or get_config().default_repository
    workflow_name = getattr(args, "workflow", "new_integration")

    config = get_config()
    base_dir = config.get_repo_root(repository)
    state = WorkflowState.load(workflow_name, namespace, base_dir)
    if state is None:
        console.print(f"[red]No state found for {namespace}/{workflow_name}.[/]")
        return 1

    analysis_dir = state.root(base_dir)
    push_run_to_s3(
        analysis_dir=analysis_dir,
        state=state,
        namespace=namespace,
        repository=repository,
        workflow_name=workflow_name,
        repo_dir=base_dir,
        success=state.status == "completed",
        category=state.data.get("_category"),
        language=state.data.get("_language", ""),
    )
    console.print(
        f"  [green]✓[/] Pushed [cyan]{namespace}/{workflow_name}[/] "
        f"[dim](run {state.run_id}) — uploading in background[/]"
    )
    return 0


@with_config
def cmd_sync_pull(args) -> int:
    """Pull runs from S3 to the local experience cache.

    If no integration is given, pulls the latest run across all integrations.
    """
    namespace = getattr(args, "integration", None)
    repository = getattr(args, "repository", None) or get_config().default_repository
    workflow_name = getattr(args, "workflow", "new_integration")
    run_id = getattr(args, "run_id", None)

    storage = _make_storage()
    if not _require_client(storage):
        return 1
    config = get_config()
    base_dir = config.get_repo_root(repository)
    cache = ExperienceCache(base_dir)
    cache.ensure_dirs()

    if run_id:
        runs = storage.list_runs(repository=repository, integration=namespace)
        target = next((r for r in runs if r.run_id == run_id), None)
        if target is None:
            label = f" for {namespace}" if namespace else ""
            console.print(f"[red]Run {run_id} not found{label}.[/]")
            return 1
        runs_to_pull = [target]
    else:
        limit = 5 if namespace is None else 1
        runs = storage.list_runs(repository=repository, integration=namespace, limit=limit)
        if not runs:
            label = f" for {namespace}" if namespace else ""
            console.print(f"[yellow]No runs found{label}.[/]")
            return 1
        runs_to_pull = runs

    for run in runs_to_pull:
        if run.s3_prefix is None:
            console.print(f"  [yellow]⚠[/] Run {run.run_id} has no S3 prefix — skipping.")
            continue
        ns = run.integration
        dest = cache.run_dir(repository, ns, workflow_name, run.run_id)
        storage.download_run(run.s3_prefix, dest)
        console.print(f"  [green]✓[/] Pulled [cyan]{ns}[/] run [dim]{run.run_id}[/] → {dest}")

    return 0


@with_config
def cmd_sync_list(args) -> int:
    """List stored runs, optionally filtered by integration."""
    namespace = getattr(args, "integration", None)
    # Only filter by repository when explicitly requested — omitting it shows all repos.
    repository = getattr(args, "repository", None)
    config_hash = getattr(args, "config_hash", None)
    limit = getattr(args, "limit", 20)

    storage = _make_storage()
    if not _require_client(storage):
        return 1
    runs = storage.list_runs(
        repository=repository,
        integration=namespace,
        run_config_hash=config_hash,
        limit=limit,
    )

    if not runs:
        label = f" for {namespace}" if namespace else ""
        console.print(f"[dim]No runs found{label}.[/]")
        return 0

    show_repo = repository is None
    table = Table(show_header=True, header_style="bold dim", box=None, pad_edge=False)
    table.add_column("RUN ID", style="cyan", min_width=28)
    if show_repo:
        table.add_column("REPOSITORY", style="dim", min_width=12)
    table.add_column("INTEGRATION", min_width=14)
    table.add_column("STATUS", min_width=10)
    table.add_column("CATEGORY", style="dim", min_width=12)
    table.add_column("COST", justify="right", min_width=8)
    table.add_column("STEPS", justify="right")

    for run in runs:
        cat = run.category or "-"
        cost = f"${run.totals.cost_usd:.2f}"
        steps = str(run.totals.steps_completed)
        status_style = (
            "green" if run.status == "completed" else "red" if run.status == "failed" else "yellow"
        )
        row = [run.run_id]
        if show_repo:
            row.append(run.repository.replace("dd_trace_", "").replace("_", "-"))
        row += [run.integration, f"[{status_style}]{run.status}[/]", cat, cost, steps]
        table.add_row(*row)

    console.print(table)
    return 0


@with_config
def cmd_sync_inspect(args) -> int:
    """Show the full manifest for a specific run."""
    run_id = args.run_id

    storage = _make_storage()
    if not _require_client(storage):
        return 1

    # Search all integrations for this run_id
    raw_index = storage.pull_index()
    entry = next((e for e in raw_index if e.get("run_id") == run_id), None)
    if entry is None:
        console.print(f"[red]Run {run_id} not found in index.[/]")
        return 1

    console.print_json(json.dumps(entry, default=str))
    return 0


@with_config
def cmd_sync_refresh(args) -> int:
    """Refresh the local S3 manifest index."""
    config = get_config()
    repository = getattr(args, "repository", None) or config.default_repository
    base_dir = config.get_repo_root(repository)

    storage = _make_storage()
    if not _require_client(storage):
        return 1
    index = storage.pull_index()
    if not index:
        console.print("[yellow]Remote index is empty or unreachable.[/]")
        return 0

    cache = ExperienceCache(base_dir)
    cache.ensure_dirs()
    cache.save_index(index)
    console.print(f"  [green]✓[/] Refreshed local index: [dim]{len(index)} runs[/]")
    return 0


def cmd_sync_setup(args) -> int:
    """Check prerequisites for experience store access."""
    do_fix = getattr(args, "fix", False)

    if do_fix:
        print_header("Experience Store — Auto-Fix")
        console.print()

        def _on_step(action: str) -> None:
            console.print(f"  [dim]Running: {action}...[/]")

        def _on_result(res: dict) -> None:
            if res.get("ok") is None:  # hint / extra context line
                console.print(f"    [dim]{res['detail']}[/]")
            elif res["ok"]:
                console.print(f"  [green]✓[/] {res['action']}: [dim]{res['detail']}[/]")
            else:
                console.print(f"  [yellow]⚠[/] {res['action']}: {res['detail']}")

        attempt_setup_fixes(on_step=_on_step, on_result=_on_result)

        console.print()
        console.print("[dim]Re-running prerequisite checks...[/]")
        console.print()

    print_header("Experience Store Setup Check")

    checks = check_prerequisites()
    all_ok = True

    for check in checks:
        if check["ok"]:
            console.print(f"  [green]✓[/] {check['name']}: [dim]{check['detail']}[/]")
        else:
            all_ok = False
            console.print(f"  [red]✗[/] {check['name']}: {check['detail']}")
            if check.get("fix"):
                for line in check["fix"].splitlines():
                    console.print(f"    [dim]{line.strip()}[/]")

    console.print()
    if all_ok:
        console.rule("[bold green]All checks passed — experience store is ready[/]", style="green")
    else:
        console.print("[yellow]Some checks failed. Fix the issues above, then re-run:[/]")
        console.print("  [cyan]dd-apm sync setup[/]")
        console.print()
        if not do_fix:
            console.print("  Or run [cyan]dd-apm sync setup --fix[/] to attempt automatic fixes.")
        console.print(
            "[dim]Full setup docs: "
            "https://datadoghq.atlassian.net/wiki/spaces/SECENG/pages/6028265266[/]"
        )
    return 0 if all_ok else 1


def cmd_sync_login(_args) -> int:
    """Log in to AWS SSO via aws-vault (opens browser)."""
    console.print("[dim]Launching SSO login — a browser window will open...[/]")
    console.print(f"[dim]Profile: {_SSO_PROFILE}[/]")
    console.print()

    try:
        # Run aws sts get-caller-identity under aws-vault to trigger the SSO login
        # flow. We do NOT capture output so the SSO prompt/browser flow works
        # interactively. The user sees the normal aws-vault output.
        result = subprocess.run(
            ["aws-vault", "exec", _SSO_PROFILE, "--", "aws", "sts", "get-caller-identity"],
            stdin=None,  # allow interactive SSO prompts
            timeout=120,
        )
        if result.returncode == 0:
            console.print()
            console.print(f"  [green]✓[/] Logged in to [cyan]{_SSO_PROFILE}[/]")
            console.print("  [dim]Run [cyan]dd-apm sync setup[/dim] to verify.[/]")
            return 0
        console.print()
        console.print(f"  [red]✗[/] Login failed (exit {result.returncode})")
        console.print(
            f"  [dim]Try manually: aws-vault exec {_SSO_PROFILE} -- aws sts get-caller-identity[/]"
        )
        return 1
    except FileNotFoundError:
        console.print("[red]aws-vault not found.[/] Install it: [cyan]brew install aws-vault[/]")
        return 1
    except subprocess.TimeoutExpired:
        console.print("[red]Login timed out.[/] Try again or log in manually.")
        return 1


def cmd_sync_default(_args) -> int:
    """Default sync handler — print help."""
    console.print(
        "[bold]dd-apm sync[/] — manage the remote experience store\n\n"
        "[dim]Subcommands:[/]\n"
        "  [cyan]setup[/]                     Check prerequisites and auth\n"
        "  [cyan]setup --fix[/]               Auto-fix common setup issues\n"
        "  [cyan]login[/]                     Log in via SSO (opens browser)\n"
        "  [cyan]push[/] <integration>        Push current run to S3\n"
        "  [cyan]pull[/] [integration]        Pull runs from S3 (all if omitted)\n"
        "  [cyan]list[/] [integration]        List stored runs (all if omitted)\n"
        "  [cyan]inspect[/] <run-id>          Show run manifest\n"
        "  [cyan]refresh[/]                   Refresh local index\n"
    )
    return 0


def register_sync_commands(subparsers) -> None:
    """Register dd-apm sync subcommand group."""
    sync_parser = subparsers.add_parser(
        "sync",
        help="Manage the remote experience store (S3)",
    )
    sync_parser.set_defaults(handler=cmd_sync_default)

    sync_sub = sync_parser.add_subparsers(dest="sync_command", help="Sync subcommand")

    # setup
    p = sync_sub.add_parser("setup", help="Check prerequisites and auth for experience store")
    p.add_argument(
        "--fix",
        action="store_true",
        help="Attempt to auto-fix common setup issues (install aws-vault, configure backend)",
    )
    p.set_defaults(handler=cmd_sync_setup)

    # login
    p = sync_sub.add_parser("login", help="Log in via AWS SSO (opens browser)")
    p.set_defaults(handler=cmd_sync_login)

    # push
    p = sync_sub.add_parser("push", help="Push current run to S3")
    p.add_argument("integration", help="Integration name (e.g., kafkajs)")
    p.add_argument("--repository", help="Repository (default: from config)")
    p.add_argument("--workflow", default="new_integration", help="Workflow name")
    p.set_defaults(handler=cmd_sync_push)

    # pull
    p = sync_sub.add_parser("pull", help="Pull runs from S3")
    p.add_argument(
        "integration", nargs="?", default=None, help="Integration name (omit to pull all)"
    )
    p.add_argument("--repository", help="Repository (default: from config)")
    p.add_argument("--workflow", default="new_integration", help="Workflow name")
    p.add_argument("--run-id", dest="run_id", help="Specific run ID (default: latest)")
    p.set_defaults(handler=cmd_sync_pull)

    # list
    p = sync_sub.add_parser("list", help="List stored runs")
    p.add_argument(
        "integration", nargs="?", default=None, help="Integration name (omit to list all)"
    )
    p.add_argument("--repository", help="Repository (default: from config)")
    p.add_argument("--config-hash", dest="config_hash", help="Filter by config version hash")
    p.add_argument("--limit", type=int, default=20, help="Max runs to show")
    p.set_defaults(handler=cmd_sync_list)

    # inspect
    p = sync_sub.add_parser("inspect", help="Show full manifest for a run")
    p.add_argument("run_id", help="Run ID (e.g., 20260401-143022-a3f2b1)")
    p.add_argument("--repository", help="Repository hint (default: from config)")
    p.set_defaults(handler=cmd_sync_inspect)

    # refresh
    p = sync_sub.add_parser("refresh", help="Refresh local S3 manifest index")
    p.add_argument("--repository", help="Repository (default: from config)")
    p.set_defaults(handler=cmd_sync_refresh)
