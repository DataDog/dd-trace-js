"""Configuration management commands."""

import logging
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from anubis.core.config import ConfigError, ConfigLoader
from anubis.core.config.models import AnubisConfig, RepositoryConfig
from anubis.core.tracing.dd_auth import (
    has_dd_api_key_in_env,
    is_dd_auth_available,
)
from anubis_apm.repo_adapters._repo_detection import clone_repo, detect_language, detect_repos
from anubis_apm.repo_adapters._repos import RepoDefinition, get_all_repos, get_repo_def
from anubis_apm.storage.auth import attempt_setup_fixes

from ..console import console, create_table

logger = logging.getLogger(__name__)

UNKNOWN_LANGUAGE = "unknown"


def _resolve_repo_language(
    path: Path,
    repo_name: str | None = None,
    explicit_language: str | None = None,
) -> str:
    """Resolve a repository language from explicit input, detection, or registry."""
    if explicit_language:
        return explicit_language

    detected_language = detect_language(path)
    if detected_language:
        logger.info(
            "Resolved repository language for %s (%s) from markers: %s",
            repo_name or path.name,
            path,
            detected_language,
        )
        return detected_language

    if repo_name:
        repo_def = get_repo_def(repo_name)
        if repo_def:
            logger.info(
                "Resolved repository language for %s (%s) from registry: %s",
                repo_name,
                path,
                repo_def.language,
            )
            return repo_def.language

    logger.warning(
        "Could not resolve repository language for %s (%s)",
        repo_name or path.name,
        path,
    )
    return UNKNOWN_LANGUAGE


def _prompt(message: str, default: str = "") -> str:
    """Prompt for input, returning default when stdin is closed/not interactive."""
    if not sys.stdin.isatty():
        return default
    try:
        return input(message)
    except EOFError:
        return default


def _setup_env_api_key() -> None:
    """Guide the user to provision Datadog credentials.

    dd-auth is the only supported credential source. Keys are ephemeral
    (JIT-provisioned via OAuth) and are never persisted to disk.
    """
    console.print()
    console.print("[bold]Datadog Tracing Setup[/]")
    console.print("-" * 40)

    if has_dd_api_key_in_env():
        console.print("[green]\u2713[/] DD_API_KEY already available in the environment")
        return

    if is_dd_auth_available():
        console.print()
        console.print("[green]\u2713[/] [bold]dd-auth[/] detected.")
        console.print("  Datadog credentials will be auto-provisioned at runtime via dd-auth.")
        console.print("  [dim]dd-auth keys are ephemeral \u2014 they are not persisted to disk.[/]")
        console.print()
        console.print("Start tracing infrastructure with: [cyan]docker compose up -d[/]")
    else:
        console.print()
        console.print("[red]\u2717[/] dd-auth not found \u2014 required for Datadog credentials.")
        console.print("  Install: [cyan]brew install datadog/tap/dd-auth[/]")
        console.print()
        console.print("  dd-auth auto-provisions ephemeral API/APP keys via OAuth.")
        console.print("  No manual key management needed.")


def _cmd_available(cmd: str) -> bool:
    """Check if a command exists in PATH."""
    return shutil.which(cmd) is not None


def _get_shell_rc() -> Path | None:
    """Return the user's primary shell rc file."""
    shell = os.environ.get("SHELL", "")
    home = Path.home()
    if "zsh" in shell:
        return home / ".zshrc"
    if "bash" in shell:
        bash_profile = home / ".bash_profile"
        return bash_profile if bash_profile.exists() else home / ".bashrc"
    for rc in [home / ".zshrc", home / ".bash_profile", home / ".bashrc"]:
        if rc.exists():
            return rc
    return home / ".zshrc"


def _check_node_version() -> tuple[bool, str]:
    """Return (ok, version_string). ok is False if Node is missing or < 18."""
    if not _cmd_available("node"):
        return False, ""
    try:
        result = subprocess.run(["node", "--version"], capture_output=True, text=True, timeout=5)
        version = result.stdout.strip().lstrip("v")
        major = int(version.split(".")[0])
        return major >= 18, version
    except Exception:
        return False, ""


def _check_prerequisites() -> None:
    """Check optional prerequisites and print advisory messages."""
    console.print()
    console.print("[bold]Checking prerequisites...[/]")
    console.print("-" * 40)

    # Node.js (required for dd-trace-js workflows)
    node_ok, node_version = _check_node_version()
    if node_ok:
        console.print(f"[green]\u2713[/] Node.js v{node_version}")
    elif node_version:
        console.print(f"[red]\u2717[/] Node.js v{node_version} found, but 18+ required")
        console.print("  [dim]Upgrade: nvm install 18 or brew install node[/]")
    else:
        console.print("[red]\u2717[/] Node.js not found (18+ required)")
        console.print("  [dim]Install: https://nodejs.org/en/download/[/]")

    # GitHub CLI
    if _cmd_available("gh"):
        console.print("[green]\u2713[/] GitHub CLI (gh) available")
    else:
        console.print("[yellow]\u26a0[/] GitHub CLI (gh) not found")
        console.print("  [dim]Needed to clone tracer repos: brew install gh[/]")

    # Docker
    try:
        docker_running = (
            subprocess.run(["docker", "info"], capture_output=True, timeout=5).returncode == 0
        )
    except subprocess.TimeoutExpired:
        docker_running = False
    if docker_running:
        console.print("[green]\u2713[/] Docker available and running")
    elif _cmd_available("docker"):
        console.print(
            "[yellow]\u26a0[/] Docker installed but not running — "
            "start your container runtime (e.g. `colima start`, `orb start`)"
        )
    else:
        console.print("[yellow]\u26a0[/] Docker not found")
        console.print("  [dim]Needed for integration tests: https://docs.docker.com/get-docker/[/]")

    # dd-auth
    if _cmd_available("dd-auth"):
        console.print("[green]\u2713[/] dd-auth available")
    else:
        console.print(
            "[yellow]\u26a0[/] dd-auth not found [dim](optional — auto-provisions DD credentials)[/]"
        )
        console.print("  [dim]Install: brew install datadog/tap/dd-auth[/]")

    # aws-vault
    if _cmd_available("aws-vault"):
        console.print("[green]\u2713[/] aws-vault available")
    else:
        console.print(
            "[yellow]\u26a0[/] aws-vault not found [dim](optional — needed for S3 experience store)[/]"
        )
        console.print("  [dim]Install: brew install aws-vault awscli[/]")

    # mitmproxy
    if _cmd_available("mitmdump"):
        console.print("[green]\u2713[/] mitmproxy available")
    else:
        console.print(
            "[yellow]\u26a0[/] mitmproxy not found [dim](required for eval --run AI Gateway routing)[/]"
        )
        console.print("  [dim]Install: brew install mitmproxy[/]")

    console.print()


def _setup_anthropic_key() -> None:
    """Prompt for ANTHROPIC_API_KEY and save to shell profile if not set."""
    if os.environ.get("ANTHROPIC_API_KEY"):
        console.print("[green]\u2713[/] ANTHROPIC_API_KEY is set")
        return

    console.print()
    console.print("[bold]Anthropic API Key[/]")
    console.print("-" * 40)
    console.print("The toolkit drives Claude for its agent steps. How Claude is")
    console.print("authenticated depends on your personal environment:")
    console.print(
        "  [dim]• If Claude access is already configured (e.g. via the Datadog AI\n"
        "    Gateway or an existing ANTHROPIC_API_KEY), it may work out of the\n"
        "    box — press Enter to skip this step.[/]"
    )
    console.print(
        "  [dim]• Otherwise set a personal key from "
        "[link=https://console.anthropic.com/settings/keys]"
        "console.anthropic.com/settings/keys[/link].[/]"
    )
    console.print()

    api_key = _prompt("Enter your ANTHROPIC_API_KEY (or press Enter to skip): ")

    if not api_key:
        console.print(
            "[yellow]Skipped.[/] Relying on your existing environment / AI Gateway config. "
            "If workflows fail with an auth error, set ANTHROPIC_API_KEY in your shell profile."
        )
        return

    shell_rc = _get_shell_rc()
    export_line = f"export ANTHROPIC_API_KEY={shlex.quote(api_key)}"

    if shell_rc:
        existing = shell_rc.read_text() if shell_rc.exists() else ""
        if "ANTHROPIC_API_KEY" not in existing:
            with shell_rc.open("a") as f:
                f.write(f"\n# Anthropic API key (added by dd-apm config init)\n{export_line}\n")
            console.print(f"[green]\u2713[/] ANTHROPIC_API_KEY saved to {shell_rc}")
            console.print(f"  [dim]Run: source {shell_rc}[/]")
        else:
            console.print(f"[dim]ANTHROPIC_API_KEY already present in {shell_rc}[/]")
    else:
        console.print("[yellow]\u26a0[/] Could not detect shell profile. Add manually:")
        console.print(f"  [cyan]{export_line}[/]")

    os.environ["ANTHROPIC_API_KEY"] = api_key
    console.print()


def _gh_authenticated() -> bool:
    """Return True if gh CLI has a valid, working token."""
    try:
        result = subprocess.run(["gh", "api", "user", "--silent"], capture_output=True, timeout=10)
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def _build_evalya(toolkit_root: Path) -> None:
    """Note evalya availability without blocking config init.

    evalya is the integration-test runner used only by semantic-validation
    workflows. The runner (anubis_apm/evalya/runner.py) resolves evalya from
    PATH and executes tests via the prebuilt OCI image — it does NOT use a
    source-built binary, and it degrades gracefully when evalya is absent.

    A `make build` from source is a multi-minute Go compile that previously ran
    synchronously here with captured output, silently blocking first-run setup
    for the majority of users who never touch semantic validation. Surface the
    manual build command instead of blocking on it.
    """
    evalya_dir = toolkit_root / "repos" / "evalya"
    if not evalya_dir.exists():
        return

    if shutil.which("evalya") or (evalya_dir / "bin" / "evalya").exists():
        console.print("[green]\u2713[/] evalya available")
        return

    console.print(
        "[dim]\u26a0 evalya not built (only needed for semantic-validation workflows).[/]"
    )
    console.print(f"  [dim]Build when needed: make -C {evalya_dir}/src build[/]")


def _clone_and_register(
    repo_def: RepoDefinition,
    repos_dir: Path,
    config: AnubisConfig,
) -> bool:
    """Clone a single repo and add it to config. Returns True on success."""
    console.print(f"  Cloning {repo_def.dir_name} (branch: {repo_def.default_branch})...")
    cloned_path = clone_repo(repo_def, repos_dir)
    if not cloned_path:
        console.print(f"  [red]\u2717[/] Failed to clone {repo_def.dir_name}")
        return False

    console.print(f"  [green]\u2713[/] Cloned {repo_def.dir_name}")
    config.repositories[repo_def.internal_name] = RepositoryConfig(
        name=repo_def.internal_name,
        path=cloned_path,
        language=repo_def.language,
    )
    return True


def _offer_clone_repos(
    cloneable: list[RepoDefinition],
    loader: ConfigLoader,
    config: AnubisConfig,
) -> None:
    """Display cloneable repos and handle user selection."""
    console.print("[bold]Not found (available to clone):[/]")
    for i, repo_def in enumerate(cloneable, 1):
        supported = "" if repo_def.has_adapter else "  [dim]\\[not yet supported][/]"
        console.print(f"  [cyan]{i})[/] {repo_def.internal_name}  ({repo_def.language}){supported}")
    console.print()

    choice = _prompt("Clone additional repos? Enter numbers (e.g. 1,3) or Enter to skip: ")
    if not choice:
        return

    if not _gh_authenticated():
        console.print()
        console.print("[red]\u2717[/] GitHub CLI not authenticated.")
        console.print("Fix your token and re-run:")
        console.print("  [cyan]1. export GH_TOKEN=\\$(ddtool auth github token)[/]")
        console.print("  [cyan]2. dd-apm config init[/]")
        console.print()
        return

    repos_dir = loader.toolkit_root / "repos"
    to_clone = _parse_selection(choice, cloneable)
    console.print()
    for repo_def in to_clone:
        _clone_and_register(repo_def, repos_dir, config)

    evalya_def = get_repo_def("evalya")
    evalya_dir = repos_dir / "evalya"
    if evalya_def and not evalya_dir.exists():
        console.print("  Cloning evalya (integration test runner)...")
        cloned_path = clone_repo(evalya_def, repos_dir)
        if cloned_path:
            console.print("  [green]\u2713[/] Cloned evalya")
            config.repositories["evalya"] = RepositoryConfig(
                name="evalya", path=cloned_path, language="go"
            )

    console.print()


def _apm_setup_callback(loader: ConfigLoader) -> AnubisConfig:
    """APM-specific interactive setup: detect, clone, configure repos.

    This is passed to ConfigLoader.init_interactive() as the setup_callback,
    replacing the generic fallback with full repo registry awareness.
    """
    config = AnubisConfig(
        toolkit_root=loader.toolkit_root,
        default_repository="",
        repositories={},
    )

    console.print("Scanning for repositories...")
    console.print()

    result = detect_repos(loader.toolkit_root)

    # Show found repos
    if result.found:
        console.print("[bold]Found on disk:[/]")
        for detected in result.found:
            supported = "" if detected.definition.has_adapter else "  [dim]\\[not yet supported][/]"
            console.print(
                f"  [green]*[/] {detected.definition.internal_name}  "
                f"({detected.language})    {detected.path}{supported}"
            )

            repo = RepositoryConfig(
                name=detected.definition.internal_name,
                path=detected.path,
                language=detected.language,
            )
            config.repositories[detected.definition.internal_name] = repo
        console.print()

    # Show missing repos with clone option
    cloneable = sorted(
        [r for r in result.missing if r.internal_name != "evalya"],
        key=lambda r: (not r.has_adapter, r.internal_name),
    )
    if cloneable and _cmd_available("gh"):
        _offer_clone_repos(cloneable, loader, config)

    if not config.repositories:
        # No repos found or cloned — fall back to manual path entry
        console.print("No repositories detected.")
        console.print()
        path_str = _prompt("Path to tracer repository: ")
        if not path_str:
            raise ConfigError("Repository path is required.")

        path = Path(path_str).expanduser().resolve()
        if not path.exists():
            raise ConfigError(f"Path does not exist: {path}")
        if not (path / ".git").exists():
            raise ConfigError(f"Not a git repository: {path}")

        name = path.name.replace("-", "_")
        language = _resolve_repo_language(path, name)
        console.print(f"\nDetected: {name} ({language})")
        repo = RepositoryConfig(name=name, path=path, language=language)
        config.repositories[name] = repo

    # Select default repository
    if not config.repositories:
        raise ConfigError("No repositories configured.")

    repo_names = list(config.repositories.keys())
    if len(repo_names) == 1:
        config.default_repository = repo_names[0]
    else:
        # Auto-pick dd_trace_js if available, otherwise first
        default = "dd_trace_js" if "dd_trace_js" in config.repositories else repo_names[0]

        console.print("[bold]Select default repository:[/]")
        for i, name in enumerate(repo_names, 1):
            marker = " (default)" if name == default else ""
            console.print(f"  [cyan]{i})[/] {name}{marker}")

        choice = _prompt(f"Default [{repo_names.index(default) + 1}]: ")
        if choice:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(repo_names):
                    default = repo_names[idx]
            except ValueError:
                if choice in repo_names:
                    default = choice

        config.default_repository = default

    return config


def _parse_selection(choice: str, options: list) -> list:
    """Parse comma-separated numeric selection (e.g. '1,3') into list items."""
    selected = []
    for part in choice.split(","):
        part = part.strip()
        if not part.isdigit():
            continue
        idx = int(part) - 1
        if 0 <= idx < len(options):
            selected.append(options[idx])
    return selected


def cmd_config_init(_args):
    """Initialize configuration interactively."""
    # 1. Check optional prerequisites (advisory, never blocks)
    _check_prerequisites()

    # 2. Set up ANTHROPIC_API_KEY if missing
    _setup_anthropic_key()

    loader = ConfigLoader()

    try:
        # 3. Interactive repo config with full registry-aware detection
        config = loader.init_interactive(setup_callback=_apm_setup_callback)
        console.print()
        console.print(f"[green]\u2713[/] Configuration saved to: {loader.config_file}")
        console.print()
        console.print("Configured repositories:")
        for name, repo in config.repositories.items():
            default = " [dim](default)[/]" if name == config.default_repository else ""
            console.print(f"  \u2022 {name}: {repo.path}{default}")

        # 4. Copy bundled docker-compose.yml to toolkit_root so Docker services
        # can be started automatically by workflow preflight checks.
        resources_root = Path(os.environ.get("ANUBIS_RESOURCES_ROOT", ""))
        if resources_root:
            src_compose = resources_root / "docker-compose.yml"
            dst_compose = loader.toolkit_root / "docker-compose.yml"
            if src_compose.exists() and not dst_compose.exists():
                shutil.copy2(src_compose, dst_compose)
                console.print(f"[green]\u2713[/] Docker Compose config installed to: {dst_compose}")

        # 5. Build evalya if it was cloned
        _build_evalya(loader.toolkit_root)

        # 6. Prompt for org 2 DD_API_KEY
        _setup_env_api_key()

        # 7. Run AWS/sync setup so S3 experience store works out of the box
        console.print()
        console.print("[bold]Setting up AWS access for S3 experience store...[/]")
        console.print()

        def _on_step(action: str) -> None:
            console.print(f"  [dim]Running: {action}...[/]")

        def _on_result(res: dict) -> None:
            if res.get("ok") is None:
                console.print(f"    [dim]{res['detail']}[/]")
            elif res["ok"]:
                console.print(f"  [green]\u2713[/] {res['action']}: [dim]{res['detail']}[/]")
            else:
                console.print(f"  [dim]\u25cb {res['action']}: {res['detail']}[/]")

        attempt_setup_fixes(on_step=_on_step, on_result=_on_result)
        console.print()

        return 0
    except Exception as e:
        console.print(f"[red]Error:[/] {e}")
        return 1


def cmd_config_clone(args):
    """Clone a known repository and add it to configuration."""
    repo_def = get_repo_def(args.name)
    if not repo_def:
        console.print(f"[red]Unknown repository: {args.name}[/]")
        console.print()
        console.print("Known repositories:")
        for r in get_all_repos():
            supported = "" if r.has_adapter else " [dim](not yet supported)[/]"
            console.print(f"  {r.internal_name} ({r.language}){supported}")
        return 1

    loader = ConfigLoader()
    target_dir = (
        Path(args.path).expanduser().resolve() if args.path else loader.toolkit_root / "repos"
    )

    console.print(f"Cloning {repo_def.dir_name} (branch: {repo_def.default_branch})...")
    cloned_path = clone_repo(repo_def, target_dir)
    if not cloned_path:
        console.print(f"[red]Failed to clone {repo_def.dir_name}[/]")
        return 1

    console.print(f"[green]\u2713[/] Cloned to {cloned_path}")

    try:
        loader.add_repository(
            name=repo_def.internal_name,
            path=cloned_path,
            language=repo_def.language,
        )
        console.print(f"[green]\u2713[/] Added {repo_def.internal_name} to configuration")
    except ConfigError as e:
        console.print(f"[yellow]\u26a0[/] Cloned but could not add to config: {e}")
        console.print(
            f"  Add manually: dd-apm config add-repo {repo_def.internal_name} {cloned_path}"
        )

    return 0


def cmd_config_list(_args):
    """List configuration."""
    loader = ConfigLoader()
    if not loader.exists():
        console.print("[yellow]Workspace not initialized.[/]")
        console.print("Run [cyan]dd-apm config init[/] to get started.")
        return 1

    try:
        config = loader.load()

        console.print()
        console.print(f"[dim]Config file:[/] {loader.config_file}")
        console.print(f"[dim]Toolkit root:[/] {config.toolkit_root}")
        console.print()

        if config.repositories:
            table = create_table("Repositories")
            table.add_column("Name", style="cyan")
            table.add_column("Path")
            table.add_column("Language")
            table.add_column("Default")

            for name, repo in config.repositories.items():
                is_default = "\u2713" if name == config.default_repository else ""
                table.add_row(name, str(repo.path), repo.language, is_default)

            console.print(table)
        else:
            console.print("[yellow]No repositories configured.[/]")

        # Show tracing configuration status
        console.print()
        if has_dd_api_key_in_env():
            console.print(
                "[green]\u2713[/] DD_API_KEY available via dd-auth (ephemeral, not persisted)"
            )
        else:
            console.print("[red]\u2717[/] DD_API_KEY not available")
            if is_dd_auth_available():
                console.print(
                    "  [dim]dd-auth is installed \u2014 credentials will be auto-provisioned at runtime.[/]"
                )
            else:
                console.print("  Install dd-auth: [cyan]brew install datadog/tap/dd-auth[/]")

        console.print()
        return 0
    except Exception as e:
        console.print(f"[red]Error:[/] {e}")
        return 1


def cmd_config_add_repo(args):
    """Add a repository to configuration."""
    loader = ConfigLoader()
    try:
        repo_path = Path(args.path).expanduser().resolve()
        language = _resolve_repo_language(repo_path, args.name, args.language)
        if language == UNKNOWN_LANGUAGE:
            raise ConfigError(
                f"Could not detect language for repository at {repo_path}. "
                "Pass it explicitly with --language."
            )

        config = loader.add_repository(
            name=args.name,
            path=repo_path,
            language=language,
            set_default=args.default,
        )
        console.print(f"[green]\u2713[/] Added repository '{args.name}'")
        if args.default or config.default_repository == args.name:
            console.print("  Set as default repository")
        return 0
    except ConfigError as e:
        console.print(f"[red]Error:[/] {e}")
        return 1


def cmd_config_remove_repo(args):
    """Remove a repository from configuration."""
    loader = ConfigLoader()
    try:
        loader.remove_repository(args.name)
        console.print(f"[green]\u2713[/] Removed repository '{args.name}'")
        return 0
    except ConfigError as e:
        console.print(f"[red]Error:[/] {e}")
        return 1


def cmd_config_default(_args):
    """Show help for config command."""
    console.print("Usage: dd-apm config <command>")
    console.print("Commands:")
    console.print("  init        Initialize configuration interactively")
    console.print("  list        List configured repositories")
    console.print("  clone       Clone and configure a known repository")
    console.print("  add-repo    Add a repository")
    console.print("  remove-repo Remove a repository")
    return 1


def register_config_commands(subparsers):
    """Register config commands with the parser."""
    config_parser = subparsers.add_parser("config", help="Manage configuration")
    config_parser.set_defaults(handler=cmd_config_default)

    config_subparsers = config_parser.add_subparsers(dest="config_command", help="Config command")

    init_parser = config_subparsers.add_parser(
        "init", help="Initialize configuration interactively"
    )
    init_parser.set_defaults(handler=cmd_config_init)

    list_parser = config_subparsers.add_parser("list", help="List configured repositories")
    list_parser.set_defaults(handler=cmd_config_list)

    clone_parser = config_subparsers.add_parser(
        "clone", help="Clone and configure a known repository"
    )
    clone_parser.add_argument("name", help="Repository name (e.g., dd_trace_java or dd-trace-java)")
    clone_parser.add_argument("--path", help="Clone directory (default: toolkit_root/repos/)")
    clone_parser.set_defaults(handler=cmd_config_clone)

    add_parser = config_subparsers.add_parser("add-repo", help="Add a repository")
    add_parser.add_argument("name", help="Repository name (e.g., dd_trace_js)")
    add_parser.add_argument("path", help="Path to repository")
    add_parser.add_argument(
        "--language",
        "-l",
        default=None,
        help="Language (auto-detected by default; e.g., node, python, dotnet)",
    )
    add_parser.add_argument(
        "--default", "-d", action="store_true", help="Set as default repository"
    )
    add_parser.set_defaults(handler=cmd_config_add_repo)

    remove_parser = config_subparsers.add_parser("remove-repo", help="Remove a repository")
    remove_parser.add_argument("name", help="Repository name to remove")
    remove_parser.set_defaults(handler=cmd_config_remove_repo)
