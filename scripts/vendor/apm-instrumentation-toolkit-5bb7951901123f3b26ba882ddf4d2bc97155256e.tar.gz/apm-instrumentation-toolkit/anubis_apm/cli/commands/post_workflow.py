"""Post-workflow actions: diff, open IDE, launch Claude, interactive menu."""

import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional

from anubis.core.config import get_config
from anubis.core.output import restore_terminal_for_input
from anubis_apm.repo_adapters import get_apm_adapter

from ..console import console
from ..utils import add_workflow_args
from .pr import create_pr


def _detect_ide() -> Optional[str]:
    """Detect available IDE, preferring Cursor > VS Code > $EDITOR."""
    for cmd in ("cursor", "code"):
        if shutil.which(cmd):
            return cmd
    return os.environ.get("EDITOR")


def show_diff(repo_path: Path, paths: List[str]) -> None:
    """Show git diff scoped to integration paths, piped through pager."""
    cmd = ["git", "diff", "--"] + paths
    pager = os.environ.get("PAGER", "less -R")
    try:
        diff = subprocess.run(
            cmd,
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=30,
        )
        if not diff.stdout.strip():
            console.print("  [dim]No changes to show.[/]")
            return

        # Pipe through pager
        subprocess.run(
            pager.split(),
            input=diff.stdout,
            cwd=str(repo_path),
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        console.print(f"  [red]Error showing diff:[/] {e}")


def open_ide(repo_path: Path, paths: List[str]) -> None:
    """Open integration files in detected IDE."""
    ide = _detect_ide()
    if not ide:
        console.print("  [yellow]No IDE detected.[/] Set $EDITOR or install cursor/code.")
        return

    # Open the first path (plugin directory)
    target = str(repo_path / paths[0]) if paths else str(repo_path)
    try:
        subprocess.Popen(
            [ide, target],
            cwd=str(repo_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        console.print(f"  [green]Opened in {ide}[/]")
    except (FileNotFoundError, OSError) as e:
        console.print(f"  [red]Failed to open {ide}:[/] {e}")


def open_claude(repo_path: Path, integration: str, paths: List[str]) -> None:
    """Launch Claude Code in target repo for interactive review."""
    claude = shutil.which("claude")
    if not claude:
        console.print(
            "  [yellow]Claude Code not found.[/] Install: npm install -g @anthropic-ai/claude-code"
        )
        return

    files_hint = ", ".join(paths[:3]) if paths else "all changed files"
    prompt = (
        f"Review the unstaged changes for the {integration} integration. "
        f"Key files: {files_hint}. "
        f"Check for correctness, missing tests, and style issues."
    )
    try:
        console.print(f"  [cyan]Launching Claude Code in {repo_path}...[/]")
        subprocess.run([claude, prompt], cwd=str(repo_path))
    except (FileNotFoundError, OSError) as e:
        console.print(f"  [red]Failed to launch Claude:[/] {e}")


def _resolve_paths(integration: str, repository: str) -> tuple[Path, List[str]]:
    """Resolve repo path and integration paths from config."""
    config = get_config()
    repo_path = config.get_repo_root(repository)
    adapter = get_apm_adapter(repository)
    paths = [adapter.get_plugin_path(integration)]
    return repo_path, paths


def post_workflow_menu(
    repo_path: Path,
    integration: str,
    repository: str,
    paths: List[str],
) -> None:
    """Interactive menu shown after workflow completion."""
    restore_terminal_for_input()

    console.print()
    console.rule("[dim]What's next?[/]", style="dim")
    console.print("  [cyan]\\[d][/]iff     View changes")
    console.print("  [cyan]\\[p][/]r       Commit, push, open PR")
    console.print("  [cyan]\\[i][/]de      Open in IDE")
    console.print("  [cyan]\\[c][/]laude   Review with Claude Code")
    console.print("  [cyan]\\[q][/]uit     Exit")

    while True:
        try:
            choice = input("> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break

        if choice in ("d", "diff"):
            show_diff(repo_path, paths)
        elif choice in ("p", "pr"):
            _run_pr_command(integration, repository)
        elif choice in ("i", "ide", "code"):
            open_ide(repo_path, paths)
        elif choice in ("c", "claude"):
            open_claude(repo_path, integration, paths)
            break  # Claude takes over the terminal
        elif choice in ("q", "quit", "exit"):
            break
        else:
            console.print(f"  [dim]Unknown: {choice}[/]")


def _run_pr_command(integration: str, repository: str) -> None:
    """Delegate to dd-apm pr command logic."""
    create_pr(integration, repository)


# =========================================================================
# Standalone CLI command handlers
# =========================================================================


def cmd_diff(args) -> int:
    """Show diff for integration changes."""
    repo_path, paths = _resolve_paths(args.integration, args.repository)
    show_diff(repo_path, paths)
    return 0


def cmd_open(args) -> int:
    """Open integration in IDE."""
    repo_path, paths = _resolve_paths(args.integration, args.repository)
    open_ide(repo_path, paths)
    return 0


def cmd_claude(args) -> int:
    """Launch Claude Code for integration review."""
    repo_path, paths = _resolve_paths(args.integration, args.repository)
    open_claude(repo_path, integration=args.integration, paths=paths)
    return 0


def register_post_workflow_commands(subparsers) -> None:
    """Register diff, open, and claude commands."""
    # diff command
    diff_parser = subparsers.add_parser("diff", help="View integration changes")
    add_workflow_args(diff_parser)
    diff_parser.set_defaults(handler=cmd_diff)

    # open command
    open_parser = subparsers.add_parser("open", help="Open integration in IDE")
    add_workflow_args(open_parser)
    open_parser.set_defaults(handler=cmd_open)

    # claude command
    claude_parser = subparsers.add_parser("claude", help="Review with Claude Code")
    add_workflow_args(claude_parser)
    claude_parser.set_defaults(handler=cmd_claude)
