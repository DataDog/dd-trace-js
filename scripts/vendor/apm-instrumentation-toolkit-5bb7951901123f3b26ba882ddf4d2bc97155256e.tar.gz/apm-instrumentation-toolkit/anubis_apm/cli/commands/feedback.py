"""Feedback command: analyze signals and improve the toolkit harness."""

import logging
from typing import Any, cast

from anubis.core.config import get_config
from anubis_apm.workflows.feedback import FeedbackInput, FeedbackWorkflow

from ..console import console, print_header, print_success
from ..decorators import workflow_command
from ..utils import add_common_args, check_gh_auth

logger = logging.getLogger(__name__)


@workflow_command("feedback")
def cmd_feedback(args) -> int:
    """Run the feedback workflow to analyze signals and improve the harness."""
    # Validate at least one source is provided
    has_sources = args.pr or args.run or args.eval or args.all
    if not has_sources:
        console.print("[red]Error:[/] No sources provided.")
        console.print("Provide at least one of: --pr, --run, --eval, or --all")
        return 1

    # Fail fast if gh auth is broken — don't waste opus tokens
    try:
        check_gh_auth()
    except RuntimeError as e:
        console.print(f"[red]Error:[/] {e}")
        return 1

    print_header("dd-apm: Feedback Loop")
    console.print()

    repo_path = get_config().get_repo_root(args.repository)

    # base_dir = target repo so git checkpointing works there (not in toolkit).
    # The workflow's setup() overrides ctx.base_dir to toolkit_root so the agent
    # runs in the toolkit where prompts/skills/hooks live.
    kwargs: dict[str, Any] = {
        "namespace": "feedback",
        "repository": args.repository,
        "headless": args.headless,
        "base_dir": repo_path,
        "from_step": args.from_step,
        "rollback_git": args.rollback_git,
        "model": args.model,
        "base_branch": args.base_branch,
        "user_prompt": args.prompt,
    }

    workflow = cast(Any, FeedbackWorkflow)(**kwargs)

    input_data = FeedbackInput(
        pr_urls=args.pr or [],
        run_paths=args.run or [],
        eval_paths=args.eval or [],
        scan_recent=args.all,
        repository=args.repository,
    )

    result = workflow.run(input_data)

    console.print()
    if result.success:
        output = result.output
        # Final output may be PrResult (if OpenPrStep ran) or FeedbackResult.
        # Feedback stats are stored in context by after_step for either case.
        improvements = getattr(output, "improvements_applied", None)
        if improvements is None:
            improvements = workflow.ctx.get("improvements_applied", 0)
        summary = workflow.ctx.get("feedback_summary", "") or getattr(output, "summary", "")
        pr_url = getattr(output, "pr_url", "")

        print_success(f"Feedback complete: {improvements} improvement(s) applied")
        if pr_url:
            console.print(f"PR: {pr_url}")
        if summary:
            console.print(f"\n{summary}")
        return 0

    console.print(f"[red]Error:[/] {result.error}")
    return 1


def register_feedback_commands(subparsers) -> None:
    """Register the feedback command."""
    parser = subparsers.add_parser(
        "feedback",
        help="Analyze signals and improve the toolkit harness",
    )
    parser.add_argument(
        "--pr",
        action="append",
        default=None,
        help="PR URL to analyze (repeatable)",
    )
    parser.add_argument(
        "--run",
        action="append",
        default=None,
        help="Path to run state directory (repeatable)",
    )
    parser.add_argument(
        "--eval",
        action="append",
        default=None,
        help="Path to eval report file (repeatable)",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Scan .analysis/ for recent runs",
    )
    # Shared runtime args: --repository, --headless, --model, --from, --skip, etc.
    add_common_args(parser)
    parser.set_defaults(handler=cmd_feedback)
