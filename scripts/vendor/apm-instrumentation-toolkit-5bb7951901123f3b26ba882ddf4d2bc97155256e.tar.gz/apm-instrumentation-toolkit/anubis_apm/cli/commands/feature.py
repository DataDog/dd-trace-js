"""Feature management commands."""

from anubis.core.tracing import shutdown_tracing
from anubis_apm.workflows.feature import FeatureId, FeatureInput, FeatureWorkflow

from ..console import console, create_table, print_header, print_success
from ..decorators import workflow_command
from ..utils import add_workflow_args


@workflow_command("feature add")
def cmd_feature_add(args):
    """Add feature(s) to an existing integration."""
    available = [f.value for f in FeatureId]

    if args.feature:
        features = [f.strip() for f in args.feature.split(",")]
        invalid = [f for f in features if f not in available]
        if invalid:
            console.print(f"[red]\u2717[/] Unknown feature(s): {', '.join(invalid)}")
            console.print(f"   Available features: [cyan]{', '.join(available)}[/]")
            return 1
        feature_ids = features
        title = f"Adding {', '.join(features)} to {args.integration}"
    else:
        feature_ids = None
        title = f"Detecting and adding features to {args.integration}"

    print_header(f"dd-apm: {title}")

    if feature_ids is None:
        console.print(
            "[dim]Mode:[/] Auto-detection - will detect applicable features and implement them"
        )
    else:
        console.print(f"[dim]Features:[/] {', '.join(feature_ids)}")
    console.print()

    try:
        workflow = FeatureWorkflow(
            namespace=args.integration,
            repository=getattr(args, "repository", None),
            model=getattr(args, "model", None),
            inject_experience=getattr(args, "experience", False),
            step_configs={"feature_implement": {"sandbox": False}},
        )
        result = workflow.run(
            FeatureInput(
                package_name=args.integration,
                feature_ids=feature_ids,
            )
        )

        console.print()
        if result.success:
            if result.output and result.output.features_implemented:
                console.print(
                    f"[green]\u2713[/] Implemented: {', '.join(result.output.features_implemented)}"
                )
            elif result.output:
                console.print("[dim]No features were applicable for this integration.[/]")
            print_success("Feature workflow complete!")
        else:
            console.rule("[bold red]Feature addition failed[/]", style="red")
        return 0 if result.success else 1
    except KeyboardInterrupt:
        console.print("\n")
        console.print("[yellow]Feature workflow cancelled[/]")
        shutdown_tracing()
        return 0


def cmd_feature_list(_args):
    """List available features."""
    features = [f.value for f in FeatureId]

    console.print()
    table = create_table("Available Features")
    table.add_column("Feature", style="cyan")
    table.add_column("Description")

    descriptions = {
        "dsm": "Data Streams Monitoring - track message queues and streams",
        "context_propagation": "Distributed trace context across services",
        "dbm": "Database Monitoring - SQL comment injection",
        "peer_service": "Peer service detection for service maps",
    }

    for feature_id in features:
        desc = descriptions.get(feature_id, "No description")
        table.add_row(feature_id, desc)

    console.print(table)
    console.print()
    console.print("[dim]Usage:[/] dd-apm feature add [cyan]<integration>[/] [cyan][feature][/]")
    console.print("[dim]Examples:[/]")
    console.print(
        "  dd-apm feature add [cyan]kafkajs[/]           # Auto-detect applicable features"
    )
    console.print("  dd-apm feature add [cyan]kafkajs[/] [cyan]dsm[/]       # Add specific feature")
    console.print("  dd-apm feature add [cyan]kafkajs[/] [cyan]dsm,peer_service[/]  # Add multiple")
    console.print()
    return 0


def cmd_feature_default(_args):
    """Show help for feature command."""
    console.print("Usage: dd-apm feature <command>")
    console.print("Commands:")
    console.print("  add <integration> [feature]  Add feature(s) to integration")
    console.print("  list                         List available features")
    return 1


def register_feature_commands(subparsers):
    """Register feature commands with the parser."""
    feature_parser = subparsers.add_parser("feature", help="Add features to integrations")
    feature_parser.set_defaults(handler=cmd_feature_default)

    feature_subparsers = feature_parser.add_subparsers(
        dest="feature_command", help="Feature command"
    )

    add_parser = feature_subparsers.add_parser("add", help="Add feature(s) to integration")
    add_workflow_args(add_parser)
    add_parser.add_argument(
        "feature", nargs="?", default=None, help="Feature(s) to add (comma-separated)"
    )
    add_parser.set_defaults(handler=cmd_feature_add)

    list_parser = feature_subparsers.add_parser("list", help="List available features")
    list_parser.set_defaults(handler=cmd_feature_list)
