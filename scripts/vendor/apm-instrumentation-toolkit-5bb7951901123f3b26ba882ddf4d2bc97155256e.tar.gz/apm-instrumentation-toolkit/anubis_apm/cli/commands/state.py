"""State management commands: status, list, clean, checkpoints, rollback, update."""

import shutil
import subprocess
from datetime import datetime

from anubis.core.config import ConfigLoader, get_config
from anubis.core.state import WorkflowState
from anubis_apm.repo_adapters import get_apm_adapter

from ..console import console, create_table
from ..decorators import with_config
from ..utils import clear_state, normalize_name


def cmd_status(args):
    """Show workflow status."""
    if ConfigLoader().needs_init():
        console.print("[yellow]Workspace not initialized.[/]")
        console.print("Run [cyan]dd-apm config init[/] to get started.")
        return 1

    config = get_config()
    repository = getattr(args, "repository", None)
    state = WorkflowState.load(
        "new_integration", args.integration, config.get_repo_root(repository)
    )

    if not state:
        console.print(f"[red]No workflow found for '{args.integration}'[/]")
        return 1

    completed = state.get_completed_steps()
    checkpoints = state.get_all_checkpoints()

    console.print()
    console.rule(f"[bold]Workflow Status: {args.integration}[/]")
    console.print()
    console.print(f"  [dim]Workflow:[/] [cyan]{state.workflow}[/]")
    console.print(f"  [dim]Run ID:[/]   {state.run_id}")
    console.print(f"  [dim]Completed steps:[/] {len(completed)}")
    if state.apm_trace_id:
        console.print(
            f"  [dim]APM Trace:[/] https://app.datadoghq.com/apm/trace/{state.apm_trace_id}"
        )
    if state.llmobs_trace_id:
        console.print(
            f"  [dim]LLMObs:[/]    https://app.datadoghq.com/llm/traces/trace/{state.llmobs_trace_id}"
        )
    console.print()

    if completed:
        console.print("[dim]Completed Phases:[/]")
        for step_name in completed:
            checkpoint = checkpoints.get(step_name)
            timestamp = (
                checkpoint.completed_at.isoformat()
                if checkpoint and checkpoint.completed_at
                else "N/A"
            )
            console.print(f"  [green]\u2713[/] {step_name} [dim]({timestamp})[/]")
    console.print()

    return 0


@with_config
def cmd_list(args):
    """List all integration workflows."""
    config = get_config()
    repository = getattr(args, "repository", None)
    analysis_dir = config.get_analysis_root(repository)
    repo_root = config.get_repo(repository).path

    if not analysis_dir.exists():
        console.print("[dim]No integrations found.[/]")
        return 0

    integrations = []
    for integration_dir in analysis_dir.iterdir():
        if not integration_dir.is_dir():
            continue

        state_file = integration_dir / "new_integration" / "state.json"
        if state_file.exists():
            try:
                state = WorkflowState.load("new_integration", integration_dir.name, repo_root)
                if state:
                    completed = state.get_completed_steps()
                    integrations.append({
                        "name": integration_dir.name,
                        "steps": len(completed),
                        "status": "complete" if state.is_completed("reviewer") else "in progress",
                    })
            except Exception:
                integrations.append({
                    "name": integration_dir.name,
                    "steps": "?",
                    "status": "unknown",
                })

    if not integrations:
        console.print("[dim]No integrations found.[/]")
        return 0

    console.print()
    table = create_table("Integration Workflows")
    table.add_column("Integration", style="cyan")
    table.add_column("Steps", style="dim")
    table.add_column("Status")

    for integration in integrations:
        status_style = "green" if integration["status"] == "complete" else "yellow"
        table.add_row(
            str(integration["name"]),
            str(integration["steps"]),
            f"[{status_style}]{integration['status']}[/]",
        )

    console.print(table)
    console.print()

    return 0


@with_config
def cmd_clean(args):
    """Clean up workflow state and optionally workflow-generated files."""
    config = get_config()
    repository = getattr(args, "repository", None)
    analysis_root = config.get_analysis_root(repository)
    workflow = getattr(args, "workflow", None)

    raw_dir = analysis_root / args.integration
    normalized_dir = analysis_root / normalize_name(args.integration)
    exists = raw_dir.exists() or normalized_dir.exists()

    if not exists and workflow != "llmobs":
        console.print(f"[dim]No workflow found for '{args.integration}'[/]")
        return 0

    if not args.force:
        scope = f"'{workflow}' workflow" if workflow else "all workflows"
        console.print(f"[yellow]Clean up {scope} for '{args.integration}'?[/]")
        confirm = console.input("[dim]Type 'y' to confirm:[/] ")
        if confirm.lower() != "y":
            console.print("[dim]Cancelled.[/]")
            return 0

    # For llmobs workflow: also remove generated files via adapter
    if workflow == "llmobs":
        repo_root = config.get_repo_root(repository)
        adapter = get_apm_adapter(repository or config.default_repository)
        if hasattr(adapter, "clean_llmobs_artifacts"):
            integration_name = normalize_name(args.integration)
            revert_externals = getattr(args, "revert_externals", False)
            result = adapter.clean_llmobs_artifacts(integration_name, repo_root, revert_externals)

            if result["removed"]:
                console.print("[green]✓ Removed:[/]")
                for item in result["removed"]:
                    console.print(f"  [dim]- {item}[/]")
            if result["reverted"]:
                console.print("[yellow]✓ Reverted:[/]")
                for item in result["reverted"]:
                    console.print(f"  [dim]- {item}[/]")
            if result["errors"]:
                console.print("[red]✗ Errors:[/]")
                for err in result["errors"]:
                    console.print(f"  [dim]- {err}[/]")

    clear_state(args.integration, workflow, repository=repository)
    console.print(f"[green]✓[/] Cleaned up '{args.integration}'")
    return 0


def cmd_checkpoints(args):
    """List all checkpoints for a workflow."""
    if ConfigLoader().needs_init():
        console.print("[yellow]Workspace not initialized.[/]")
        console.print("Run [cyan]dd-apm config init[/] to get started.")
        return 1

    config = get_config()
    workflow = args.workflow or "new_integration"
    repository = getattr(args, "repository", None)
    state = WorkflowState.load(workflow, args.integration, config.get_repo_root(repository))
    if not state:
        console.print(f"[dim]No workflow state found for {args.integration} ({workflow})[/]")
        return 0

    checkpoints = state.get_all_checkpoints()

    if not checkpoints:
        console.print(f"[dim]No checkpoints found for {args.integration} ({workflow})[/]")
        return 0

    console.print()
    table = create_table(f"Checkpoints: {args.integration} ({workflow})")
    table.add_column("#", style="dim")
    table.add_column("Step", style="cyan")
    table.add_column("Attempt", style="dim")
    table.add_column("Timestamp")

    def format_timestamp(ts):
        if ts:
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                return dt.strftime("%Y-%m-%d %H:%M")
            except ValueError:
                return ts  # Return original if parsing fails
        return "-"

    i = 0
    for step_name, checkpoint in checkpoints.items():
        i += 1
        timestamp_str = checkpoint.completed_at.isoformat() if checkpoint.completed_at else None
        table.add_row(
            str(i),
            step_name,
            str(checkpoint.attempt),
            format_timestamp(timestamp_str),
        )

    console.print(table)
    console.print()

    return 0


@with_config
def cmd_rollback(args):
    """Roll back workflow to a specific step."""
    config = get_config()
    base_dir = config.get_repo().path
    workflow = args.workflow or "new_integration"
    state = WorkflowState.load(workflow, args.integration, base_dir)
    if not state:
        console.print(f"[red]No workflow state found for {args.integration} ({workflow})[/]")
        return 1

    step_state = state.steps.get(args.step)
    if not step_state or step_state.status != "completed":
        console.print(f"[red]Step '{args.step}' not found in checkpoints[/]")
        console.print()
        console.print("[dim]Available checkpoints:[/]")
        for step in state.get_completed_steps():
            console.print(f"  - {step}")
        return 1

    if not args.force:
        console.print(f"[yellow]Roll back to before '{args.step}'?[/]")
        confirm = console.input("[dim]Type 'y' to confirm:[/] ")
        if confirm.lower() != "y":
            console.print("[dim]Cancelled.[/]")
            return 0

    # Optionally reset repo files to the git snapshot taken at the start of the step
    rollback_git = getattr(args, "rollback_git", False)
    if rollback_git:
        state.rollback_files(args.step, base_dir)

    try:
        state.rollback(args.step, base_dir)
        state.save(base_dir)
        console.print(f"[green]\u2713[/] Rolled back state to before '{args.step}'")
    except ValueError as e:
        console.print(f"[red]Error:[/] {e}")
        return 1

    console.print()
    console.print(f"[dim]Resume with:[/] dd-apm create {args.integration}")
    return 0


def cmd_update(args):
    """Update toolkit to latest version via dogbrew."""
    from .setup import cmd_doctor  # noqa: PLC0415

    if not shutil.which("dogbrew"):
        console.print("[red]✗[/] dogbrew not found — cannot update automatically.")
        console.print("[dim]Install dogbrew or update manually from source.[/]")
        return 1

    console.print("Updating via dogbrew...")
    result = subprocess.run(["dogbrew", "install", "dd-apm"])
    if result.returncode != 0:
        console.print("[red]✗[/] Update failed.")
        return result.returncode

    console.print()
    return cmd_doctor(args)


def register_state_commands(subparsers):
    """Register state management commands with the parser."""
    # Status command
    status_parser = subparsers.add_parser("status", help="Show workflow status")
    status_parser.add_argument("integration", help="Integration name")
    status_parser.set_defaults(handler=cmd_status)

    # List command
    list_parser = subparsers.add_parser("list", help="List all workflows")
    list_parser.add_argument("--repository", "-r", default=None, help="Repository name")
    list_parser.set_defaults(handler=cmd_list)

    # Clean command
    clean_parser = subparsers.add_parser("clean", help="Clean up workflow state")
    clean_parser.add_argument("integration", help="Integration name")
    clean_parser.add_argument("--repository", "-r", default=None, help="Repository name")
    clean_parser.add_argument("--force", "-f", action="store_true", help="Skip confirmation")
    clean_parser.add_argument(
        "--workflow", type=str, default=None, help="Workflow name to clean (default: all)"
    )
    clean_parser.add_argument(
        "--revert-externals", action="store_true", help="Also revert externals.json (llmobs only)"
    )
    clean_parser.set_defaults(handler=cmd_clean)

    # Checkpoints command
    checkpoints_parser = subparsers.add_parser("checkpoints", help="List workflow checkpoints")
    checkpoints_parser.add_argument("integration", help="Integration name")
    checkpoints_parser.add_argument("--workflow", type=str, default=None, help="Workflow name")
    checkpoints_parser.set_defaults(handler=cmd_checkpoints)

    # Rollback command
    rollback_parser = subparsers.add_parser("rollback", help="Roll back to a previous step")
    rollback_parser.add_argument("integration", help="Integration name")
    rollback_parser.add_argument("step", help="Step to roll back to")
    rollback_parser.add_argument("--workflow", type=str, default=None, help="Workflow name")
    rollback_parser.add_argument("--force", "-f", action="store_true", help="Skip confirmation")
    rollback_parser.add_argument(
        "--rollback-git",
        action="store_true",
        default=False,
        help="Also reset the repo working tree to the git snapshot taken at the start of <step>",
    )
    rollback_parser.set_defaults(handler=cmd_rollback)

    # Update command
    update_parser = subparsers.add_parser(
        "update", help="Update toolkit to latest version via dogbrew"
    )
    update_parser.set_defaults(handler=cmd_update)
