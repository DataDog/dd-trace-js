"""Eval run-matrix command — method selection eval across all packages."""

import logging
import os
import shutil
from pathlib import Path

from anubis.core.tracing import is_llmobs_enabled
from anubis.eval import print_eval_failure_details, print_eval_summary
from anubis_apm.cli.console import console
from anubis_apm.cli.decorators import PreflightError, workflow_command
from anubis_apm.eval.analyze import get_matrix_packages, submit_matrix_to_llmobs
from anubis_apm.eval.analyze.loaders.hashes import (
    compute_all_category_hashes,
    get_package_categories,
)
from anubis_apm.eval.analyze.orchestration import MethodSelectionOrchestrator
from anubis_apm.eval.analyze.task import build_method_selection_suite
from anubis_apm.repo_adapters import get_apm_adapter

from .utils import resolve_repo_root

logger = logging.getLogger(__name__)


def cmd_eval_run_matrix(args) -> int:
    """Dispatch to workflow or CI-safe mode based on --run flag."""
    if getattr(args, "run", False):
        return int(_cmd_eval_run_matrix_run(args))
    return int(_cmd_eval_run_matrix_score(args))


@workflow_command("eval-matrix", resume_hint="eval run-matrix --run")
def _cmd_eval_run_matrix_run(args) -> int:
    """--run mode: full workflow startup (API keys, docker, tracing), then eval."""
    _check_mitmproxy()
    return _eval_matrix_impl(args, run_missing=True)


def _check_mitmproxy() -> None:
    """Verify mitmdump is available. Raises PreflightError if not found."""
    if shutil.which("mitmdump") is None:
        raise PreflightError(
            "mitmdump not found — required for eval AI Gateway header injection.\n"
            "  Install with: brew install mitmproxy"
        )


def _cmd_eval_run_matrix_score(args) -> int:
    """Score-only mode: CI-safe, no AI needed — runs without a configured workspace."""
    if hasattr(args, "repository") and args.repository:
        args.repository = args.repository.replace("-", "_")
    return _eval_matrix_impl(args, run_missing=False)


def _eval_matrix_impl(args, *, run_missing: bool) -> int:
    """Run method selection eval: resolve packages, score, summarize."""
    model = getattr(args, "model", None)
    if model:
        os.environ["ANTHROPIC_MODEL"] = model

    adapter = get_apm_adapter(args.repository)
    repository = args.repository

    gt_path = adapter.get_ground_truths_path()
    if not gt_path or not gt_path.exists():
        console.print(f"[red]No ground truths found for {repository}[/]")
        return 1

    analysis_base = _resolve_analysis_base(args, repository)
    packages = _resolve_packages(args, adapter, gt_path)
    if packages is None:
        return 1

    cache_dir: Path | None = (analysis_base / "evals" / repository) if analysis_base else None

    blind = run_missing and not getattr(args, "no_blind", False)
    _print_eval_header(repository, packages, gt_path, analysis_base, cache_dir, run_missing, blind)

    service = os.environ.get("DD_SERVICE", "apm-ai-integration-toolkit")
    if is_llmobs_enabled():
        console.print(f"  [dim]LLMObs tracing: enabled (ml_app={service})[/]")
    else:
        console.print("  [dim]LLMObs tracing: disabled (set DD_API_KEY to enable)[/]")
    anthropic_model = os.environ.get("ANTHROPIC_MODEL", "")
    if anthropic_model:
        console.print(
            f"  [dim]Model override:[/] [cyan]{anthropic_model}[/] [dim](all agent steps)[/]"
        )
    else:
        console.print("  [dim]Model:[/] step defaults (no ANTHROPIC_MODEL set)")
    _print_prompt_hashes(repository, packages, gt_path)

    orchestrator = MethodSelectionOrchestrator(
        repository=repository,
        analysis_base=analysis_base,
        gt_path=gt_path,
        cache_dir=cache_dir,
        run_missing=run_missing,
        blind=blind,
        force=getattr(args, "force", False),
        concurrency=getattr(args, "concurrency", None) or 0,
        console=console,
    )
    suite = build_method_selection_suite(
        adapter,
        analysis_base=analysis_base,
        cache_dir=cache_dir,
        packages=packages,
        concurrency=getattr(args, "concurrency", None) or 0,
    )
    console.print(f"[dim]Scoring {len(suite.items)} packages...[/]")
    w = 24  # width of the widest label
    print(
        "\n  Legend:\n"
        f"    {'✓ [exact]':<{w}} agent found the preferred hook point\n"
        f"    {'✓ [alternative]':<{w}} agent found a valid alternative hook point (counts as a match)\n"
        f"    {'~ [covered alt]':<{w}} agent found a valid alternative, but this operation was already matched by another pick — not penalised, not counted\n"
        f"    {'✗ [miss critical]':<{w}} agent missed a required hook point\n"
        f"    {'✗ [miss]':<{w}} agent missed an optional hook point\n"
        f"    {'✗ [FP]':<{w}} agent selected a hook point not in the ground truth\n"
    )
    results, _ = orchestrator.run(suite)
    console.print(
        f"[dim]Scored:[/] {sum(1 for r in results if r.status == 'ok')} ok, "
        f"{sum(1 for r in results if r.status != 'ok')} skipped/error "
        f"({', '.join(f'{r.name}={r.status}' for r in results if r.status != 'ok') or 'none'})"
    )

    print_eval_summary(
        results,
        title=f"Method Selection Matrix: {repository}",
        metric_columns=[
            "precision",
            "recall",
            "false_positives",
            "absorbed",
            "false_negatives",
            "input_tokens",
            "output_tokens",
        ],
        metric_labels={
            "precision": "Precision",
            "recall": "Recall",
            "false_positives": "False Pos",
            "absorbed": "Cov Alts",
            "false_negatives": "Misses",
            "input_tokens": "In Tokens",
            "output_tokens": "Out Tokens",
        },
        metric_formats={
            "false_positives": "{:.0f}",
            "absorbed": "{:.0f}",
            "false_negatives": "{:.0f}",
            "input_tokens": "{:.0f}",
            "output_tokens": "{:.0f}",
            "cost_usd": "${:.4f}",
        },
        extra_columns={"cost_usd": "Cost($)"},
        sum_columns=[
            "false_positives",
            "absorbed",
            "false_negatives",
            "input_tokens",
            "output_tokens",
            "cost_usd",
        ],
    )
    print_eval_failure_details(results)
    console.print(
        f"\n[bold cyan]Detail report ->[/] [bright_white underline]{orchestrator.detail_path.resolve() if orchestrator.detail_path else ''}[/]"
    )

    if getattr(args, "submit", False):
        missing_keys = [k for k in ("DD_API_KEY", "DD_APP_KEY") if not os.environ.get(k)]
        if missing_keys:
            console.print(
                f"[yellow]Skipping LLMObs submission — not set: {', '.join(missing_keys)}[/]\n"
                f"  Install dd-auth: [cyan]brew install datadog/tap/dd-auth[/]\n"
                f"  Or add keys to ~/.dd-apm/.anubis/config.yaml"
            )
        else:
            category_filter = getattr(args, "category", None)
            categories = (
                [c.strip() for c in category_filter.split(",")] if category_filter else None
            )
            scoreable = [r for r in results if r.metrics]
            if not scoreable:
                console.print("[yellow]No scored results — skipping LLMObs submission[/]")
            elif submit_matrix_to_llmobs(results, repository, categories=categories):
                console.print("[green]Submitted to LLMObs[/]")
            else:
                console.print("[yellow]LLMObs submission failed (check DD_API_KEY / DD_APP_KEY)[/]")

    return _eval_matrix_exit_code(results, run_missing=run_missing)


def _eval_matrix_exit_code(results, *, run_missing: bool) -> int:
    """Return the process exit code for method-selection eval results."""
    if run_missing and any(r.status != "ok" for r in results):
        return 1
    return 0 if any(r.status == "ok" for r in results) else 1


def _print_eval_header(
    repository: str,
    packages: list[str],
    gt_path: Path,
    analysis_base: Path | None,
    cache_dir: Path | None,
    run_missing: bool,
    blind: bool,
) -> None:
    console.print(f"[bold]Eval Matrix:[/] {repository} ({len(packages)} packages)")
    console.print(f"[dim]Ground truths:[/] {gt_path}")
    console.print(f"[dim]Analysis base:[/] {analysis_base or 'not found'}")
    if run_missing:
        console.print(f"[dim]Mode:[/] --run ({'blind' if blind else 'no-blind'})")
    console.print()
    if cache_dir:
        console.print(f"[dim]Eval cache:[/] {cache_dir}")


def _print_prompt_hashes(repository: str, packages: list[str], gt_path: Path) -> None:
    pkg_categories = get_package_categories(gt_path)
    cats_in_scope = sorted({pkg_categories.get(p, "") for p in packages} - {""})
    if not cats_in_scope:
        return
    cat_hashes = compute_all_category_hashes(repository, cats_in_scope)
    console.print("[dim]Prompt hashes:[/]")
    for c in cats_in_scope:
        if c not in cat_hashes:
            continue
        pkgs_str = " ".join(sorted(p for p in packages if pkg_categories.get(p) == c))
        console.print(f"  [dim]{c}[/] [cyan]{cat_hashes[c][:8]}[/] [dim]{pkgs_str}[/]")


def _resolve_analysis_base(args, repository: str) -> Path | None:
    """Resolve analysis base directory from args or config."""
    repo_dir = resolve_repo_root(args, repository, args_attr="analysis_base")
    return repo_dir / ".analysis" if repo_dir else None


def _resolve_packages(args, adapter, gt_path) -> list[str] | None:
    """Resolve package list from args, applying filters. Returns None on error."""
    all_packages = get_matrix_packages(adapter)
    if args.packages:
        selected = {p.strip() for p in args.packages.split(",")}
        packages = [p for p in all_packages if p in selected]
        not_found = selected - set(all_packages)
        if not_found:
            console.print(f"[yellow]Packages not in ground truths: {', '.join(not_found)}[/]")
    else:
        packages = all_packages

    if getattr(args, "category", None):
        selected_cats = {c.strip().lower() for c in args.category.split(",")}
        pkg_categories = get_package_categories(gt_path)
        packages = [p for p in packages if pkg_categories.get(p, "").lower() in selected_cats]
        if not packages:
            console.print(f"[yellow]No packages found for category: {args.category}[/]")
            return None
        console.print(f"[dim]Category filter:[/] {args.category} ({len(packages)} packages)")

    return packages
