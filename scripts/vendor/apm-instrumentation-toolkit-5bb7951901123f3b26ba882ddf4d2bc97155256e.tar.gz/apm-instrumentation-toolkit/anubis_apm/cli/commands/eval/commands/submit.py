"""``dd-apm eval submit-results`` — aggregate per-pod result JSONs into one LLMObs submission.

Used by CI after a per-package matrix run: each pod writes
``integration_gen_eval_results_<repo>.json`` (renamed to a unique filename per
matrix entry). A follow-on aggregator job downloads all of them and calls this
subcommand to submit a single experiment containing every package's record.

Example::

    dd-apm eval submit-results \\
        results-dd_trace_js-*.json results-dd_trace_py-*.json \\
        --experiment-name "integration_gen__main" \\
        --dataset-name "integration_gen_combined"
"""

import json
import logging
from pathlib import Path
from typing import List

from anubis.eval import EvalResult, submit_eval_results
from anubis_apm.cli.console import console

logger = logging.getLogger(__name__)


def cmd_eval_submit_results(args) -> int:
    """Read result JSONs and submit a single LLMObs experiment."""
    files: List[Path] = [Path(p) for p in args.files]
    missing = [str(f) for f in files if not f.exists()]
    if missing:
        console.print(f"[red]Missing result files:[/] {', '.join(missing)}")
        return 1

    results: List[EvalResult] = []
    repos = set()
    for f in files:
        try:
            payload = json.loads(f.read_text())
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON in {f}:[/] {e}")
            return 1
        if isinstance(payload, dict):
            if payload.get("repository"):
                repos.add(payload["repository"])
            entries = payload.get("results", [])
        else:
            entries = payload
        for entry in entries:
            try:
                results.append(EvalResult(**entry))
            except Exception as e:
                console.print(f"[yellow]Skipping malformed entry in {f}:[/] {e}")

    if not results:
        console.print("[yellow]No results to submit[/]")
        return 1

    tags = {"repositories": ",".join(sorted(repos))} if repos else {}
    if args.tags:
        for kv in args.tags:
            if "=" in kv:
                k, v = kv.split("=", 1)
                tags[k] = v

    console.print(
        f"[bold]Submitting:[/] {len(results)} results "
        f"({len(repos)} repos) → experiment=[cyan]{args.experiment_name}[/] "
        f"dataset=[cyan]{args.dataset_name}[/]"
    )

    ok = submit_eval_results(
        results,
        experiment_name=args.experiment_name,
        dataset_name=args.dataset_name,
        tags=tags or None,
    )
    if ok:
        console.print("[green]Submitted to LLMObs[/]")
        return 0
    console.print("[red]LLMObs submission failed (check DD_API_KEY / DD_APP_KEY)[/]")
    return 1
