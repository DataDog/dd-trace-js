"""Evaluation commands for measuring integration quality.

Available commands:
  dd-apm eval run-matrix                        Run method-selection eval for all packages
  dd-apm eval run-matrix --type integration-gen Run integration-gen eval (evalya oracle)
  dd-apm eval clean <integration>               Remove generated integration for re-eval
"""

import argparse

from .commands.admin import cmd_eval_clean
from .commands.integration_gen import cmd_eval_run_integration_gen
from .commands.run import cmd_eval_run_matrix
from .commands.submit import cmd_eval_submit_results

__all__ = [
    "register_eval_commands",
    "cmd_eval_run_matrix",
    "cmd_eval_run_integration_gen",
    "cmd_eval_clean",
    "cmd_eval_submit_results",
]

_EVAL_TYPES = ["analyze", "integration-gen"]


def _cmd_run_matrix_dispatch(args) -> int:
    """Dispatch run-matrix to the correct eval type based on --type."""
    if getattr(args, "type", "analyze") == "integration-gen":
        if not args.repository:
            raise SystemExit("error: --repository is required for --type integration-gen")
        return cmd_eval_run_integration_gen(args)
    return cmd_eval_run_matrix(args)


def register_eval_commands(subparsers: argparse._SubParsersAction) -> None:
    """Register eval subcommands."""
    eval_parser = subparsers.add_parser(
        "eval",
        help="Evaluate generated integration quality",
        description="Multi-tiered evaluation of generated APM integrations",
    )
    eval_sub = eval_parser.add_subparsers(dest="eval_command", help="Eval command")

    default_repo = None

    # run-matrix: Evaluate all packages (method-selection or integration-gen oracle)
    matrix_p = eval_sub.add_parser(
        "run-matrix",
        help="Run eval for all packages (--type selects eval flavor)",
    )
    matrix_p.add_argument(
        "--type",
        choices=_EVAL_TYPES,
        default="analyze",
        help="Eval type: 'analyze' (method-selection, default) or 'integration-gen' (evalya oracle)",
    )
    matrix_p.add_argument("--repository", "-r", default=default_repo, help="Repository")
    matrix_p.add_argument(
        "--analysis-base",
        help="Base directory for analysis outputs (default: .analysis/)",
    )
    matrix_p.add_argument(
        "--run",
        action="store_true",
        help="Run the workflow for packages missing outputs (analyze or new_integration)",
    )
    matrix_p.add_argument(
        "--concurrency",
        type=int,
        default=None,
        metavar="N",
        help="Number of parallel analyses when using --run (default: number of packages)",
    )
    matrix_p.add_argument(
        "--packages",
        help="Comma-separated list of packages to evaluate (default: all in ground truths / evalya)",
    )
    matrix_p.add_argument(
        "--category",
        help="Comma-separated categories to evaluate (e.g. databases,messaging). Intersects with --packages.",
    )
    matrix_p.add_argument(
        "--submit",
        action="store_true",
        help="Submit results to LLMObs (requires DD_API_KEY + DD_APP_KEY)",
    )
    matrix_p.add_argument(
        "--no-blind",
        action="store_true",
        dest="no_blind",
        help="Allow agent to read existing instrumentation files (disables default blind mode)",
    )
    matrix_p.add_argument(
        "--force",
        action="store_true",
        help="Re-run analysis even for packages that already have outputs (clears cached results)",
    )
    matrix_p.add_argument(
        "--model",
        default=None,
        metavar="MODEL",
        help=(
            "Model to use for all agent steps (e.g. anthropic/claude-sonnet-4-6, "
            "bedrock/moonshotai.kimi-k2). Sets ANTHROPIC_MODEL; overrides any existing env value."
        ),
    )
    # integration-gen specific flags (only used when --type integration-gen)
    matrix_p.add_argument(
        "--repo-root",
        dest="repo_root",
        help="[integration-gen] Path to tracer repo root (default: from config or DD_TRACER_REPO)",
    )
    matrix_p.add_argument(
        "--keep-worktree",
        action="store_true",
        dest="keep_worktree",
        help="[integration-gen] Keep the eval worktree after run (useful for debugging)",
    )
    matrix_p.add_argument(
        "--dry-run",
        action="store_true",
        dest="dry_run",
        help="[integration-gen] Run evalya pre-check against repo root only — no worktree, no AI",
    )
    matrix_p.set_defaults(handler=_cmd_run_matrix_dispatch)

    # clean: Remove generated integration for fresh eval generation
    clean_p = eval_sub.add_parser(
        "clean",
        help="Remove generated integration from repo so it can be regenerated for eval",
    )
    clean_p.add_argument("integration", help="Integration name (e.g. kafkajs)")
    clean_p.add_argument("--repository", "-r", default=default_repo, help="Repository")
    clean_p.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be removed without actually removing",
    )
    clean_p.set_defaults(handler=cmd_eval_clean)

    # submit-results: aggregate per-pod result JSONs into a single LLMObs experiment
    submit_p = eval_sub.add_parser(
        "submit-results",
        help="Submit aggregated EvalResult JSON files as one LLMObs experiment",
    )
    submit_p.add_argument(
        "files",
        nargs="+",
        help="Paths to results JSON files (each contains {results: [EvalResult, ...]})",
    )
    submit_p.add_argument(
        "--experiment-name",
        required=True,
        help="LLMObs experiment name (stable across runs for trend tracking)",
    )
    submit_p.add_argument(
        "--dataset-name",
        required=True,
        help="LLMObs dataset name to pull-or-create and submit against",
    )
    submit_p.add_argument(
        "--tags",
        nargs="*",
        default=[],
        help="Extra tags as key=value pairs (e.g. --tags repository=combined)",
    )
    submit_p.set_defaults(handler=cmd_eval_submit_results)

    # Handle bare `dd-apm eval` with no subcommand
    eval_parser.set_defaults(handler=lambda args: eval_parser.print_help())
