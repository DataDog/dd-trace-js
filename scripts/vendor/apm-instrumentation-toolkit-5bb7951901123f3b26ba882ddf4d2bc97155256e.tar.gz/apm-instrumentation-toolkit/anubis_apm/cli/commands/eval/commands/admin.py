"""Admin commands: clean."""

import logging

from anubis_apm.cli.console import console
from anubis_apm.cli.utils import _resolve_repo_dir
from anubis_apm.repo_adapters import get_apm_adapter

logger = logging.getLogger(__name__)


def cmd_eval_clean(args) -> int:
    """Remove generated integration from repo for clean eval regeneration."""
    adapter = get_apm_adapter(args.repository)
    repo_dir = _resolve_repo_dir(args.repository)

    if not repo_dir or not repo_dir.exists():
        console.print(f"[red]Repo directory not found for {args.repository}[/]")
        return 1

    if args.dry_run:
        console.print(f"[bold]Dry run:[/] would remove '{args.integration}' from {repo_dir}")
        plugin_path = adapter.get_plugin_path(args.integration)
        plugin_dir = repo_dir / plugin_path
        if plugin_dir.exists():
            console.print(f"  [dim]would remove:[/] {plugin_path}")
        return 0

    console.print(f"[bold]Removing integration:[/] {args.integration} from {repo_dir}")
    removed = adapter.remove_integration(args.integration, repo_dir)

    if not removed:
        console.print("[yellow]Nothing to remove — integration not found or already clean[/]")
        return 0

    for path in removed:
        console.print(f"  [red]\u2717[/] {path}")

    console.print(f"\n[green]Removed {len(removed)} items.[/]")
    console.print(f"[dim]Run 'dd-apm create {args.integration}' to regenerate.[/]")
    return 0
