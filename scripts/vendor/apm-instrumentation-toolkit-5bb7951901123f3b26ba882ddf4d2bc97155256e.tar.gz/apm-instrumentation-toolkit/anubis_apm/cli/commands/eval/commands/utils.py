"""Shared utilities for eval CLI commands."""

import logging
import os
from pathlib import Path

from anubis.core.config import get_config

logger = logging.getLogger(__name__)


def resolve_repo_root(args, repository: str, args_attr: str = "repo_root") -> Path | None:
    """Resolve the tracer repo root from args, config, or DD_TRACER_REPO env var."""
    if getattr(args, args_attr, None):
        return Path(getattr(args, args_attr))

    try:
        repo_dir: Path | None = get_config().get_repo_root(repository)
        if repo_dir:
            return repo_dir
    except Exception as e:
        logger.debug("Could not resolve repo root from config: %s", e)

    repo_path = os.environ.get("DD_TRACER_REPO")
    return Path(repo_path) if repo_path else None
