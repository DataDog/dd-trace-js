"""Eval integration-gen command — full workflow + evalya oracle per package."""

import logging
import os
from pathlib import Path
from typing import List

from anubis.core.tracing.config import _get_branch
from anubis.eval import MatrixRunner, print_eval_failure_details, print_eval_summary
from anubis.eval.models import EvalResult
from anubis_apm.cli.console import console
from anubis_apm.cli.decorators import with_config, workflow_command
from anubis_apm.eval.integration_gen import (
    build_integration_gen_suite,
    write_detail_report,
    write_results_json,
)
from anubis_apm.repo_adapters import get_apm_adapter

from .utils import resolve_repo_root

logger = logging.getLogger(__name__)


def cmd_eval_run_integration_gen(args) -> int:
    """Dispatch to workflow or CI-safe mode based on --run flag."""
    if getattr(args, "run", False):
        return int(_cmd_eval_run_integration_gen_run(args))
    return int(_cmd_eval_run_integration_gen_score(args))


@workflow_command("eval-integration-gen")
def _cmd_eval_run_integration_gen_run(args) -> int:
    """--run mode: full workflow startup (Docker preflight, APM tracing), then eval."""
    return _eval_integration_gen_impl(args)


@with_config
def _cmd_eval_run_integration_gen_score(args) -> int:
    """Score-only mode: CI-safe, re-scores existing evalya outputs."""
    return _eval_integration_gen_impl(args)


def _eval_integration_gen_impl(args) -> int:
    """Run integration-gen eval: resolve packages, run workflow + oracle, summarize."""
    model = getattr(args, "model", None)
    if model:
        os.environ["ANTHROPIC_MODEL"] = model

    repository = args.repository
    adapter = get_apm_adapter(repository)

    repo_root = resolve_repo_root(args, repository)
    if repo_root is None:
        console.print(f"[red]Could not resolve repo root for {repository}[/]")
        return 1

    if getattr(args, "packages", None):
        packages = [p.strip() for p in args.packages.split(",")]
    else:
        packages = adapter.get_evalya_packages()

    if getattr(args, "category", None):
        console.print(
            f"[yellow]--category not yet supported for integration-gen "
            f"(ignoring: {args.category})[/]"
        )

    if not packages:
        console.print(f"[yellow]No evalya packages found for {repository}[/]")
        return 1

    dry_run = getattr(args, "dry_run", False)
    concurrency = getattr(args, "concurrency", None) or 0
    run_mode = "--run" if getattr(args, "run", False) else "score-only"
    console.print(f"[bold]Eval Integration-Gen:[/] {repository} ({len(packages)} packages)")
    console.print(f"[dim]Repo root:[/] {repo_root}")
    console.print(f"[dim]Mode:[/] {run_mode}")
    if concurrency:
        console.print(f"[dim]Concurrency:[/] {concurrency}")
    console.print()

    keep_worktree = getattr(args, "keep_worktree", False)

    suite = build_integration_gen_suite(
        adapter=adapter,
        repo_root=repo_root,
        packages=packages,
        keep_worktree=keep_worktree,
        dry_run=dry_run,
        concurrency=concurrency,
    )

    submit = getattr(args, "submit", False)
    submitted = False
    runner = MatrixRunner()
    if submit:
        results, submitted = runner.run_and_submit(
            suite,
            experiment_name=f"integration_gen__{repository}__{_get_branch()}",
            dataset_name=f"integration_gen_{repository}",
            tags={"repository": repository},
        )
    else:
        results = runner.run(suite)

    detail_path = Path(f"integration_gen_eval_detail_{repository}.md")
    write_detail_report(results, repository, detail_path)
    results_json_path = Path(f"integration_gen_eval_results_{repository}.json")
    write_results_json(results, repository, results_json_path)

    print_eval_summary(
        results,
        title=f"Integration-Gen Eval: {repository}",
        metric_columns=[
            "precheck_pass_rate",
            "pass_rate",
            "scenarios_passing",
            "scenarios_total",
            "turn_count",
        ],
        metric_labels={
            "precheck_pass_rate": "PreCheck%",
            "pass_rate": "Post%",
            "scenarios_passing": "Passed",
            "scenarios_total": "Total",
            "turn_count": "Turns",
        },
        extra_columns={"cost_usd": "Cost($)", "duration_s": "Time(s)"},
        metric_formats={
            "precheck_pass_rate": "{:.0%}",
            "pass_rate": "{:.0%}",
            "scenarios_passing": "{:.0f}",
            "scenarios_total": "{:.0f}",
            "turn_count": "{:.0f}",
            "cost_usd": "${:.2f}",
            "duration_s": "{:.0f}s",
        },
    )

    _print_run_totals(results)
    print_eval_failure_details(results)

    console.print(f"\n[bold cyan]Detail report ->[/] [bright_white underline]{detail_path}[/]")

    if submit:
        if submitted:
            console.print("[green]Submitted to LLMObs[/]")
        else:
            console.print("[yellow]LLMObs submission failed (check DD_API_KEY / DD_APP_KEY)[/]")

    return _exit_code_for_results(results)


def _exit_code_for_results(results: List[EvalResult]) -> int:
    """Return success only when every integration-gen package completed cleanly."""
    if not results:
        return 1
    return 0 if all(r.status == "ok" for r in results) else 1


def _print_run_totals(results: List[EvalResult]) -> None:
    """Print aggregate cost/token/duration totals below the summary table."""
    scored = [r for r in results if r.status == "ok"]
    if not scored:
        return

    total_cost = sum(r.cost_usd for r in scored)
    total_duration = sum(r.duration_s for r in scored)
    total_turns = sum(int(r.metrics.get("turn_count") or 0) for r in scored)
    total_in = sum(int(r.metrics.get("input_tokens") or 0) for r in scored)
    total_out = sum(int(r.metrics.get("output_tokens") or 0) for r in scored)
    total_cache = sum(int(r.metrics.get("cache_read_input_tokens") or 0) for r in scored)

    if total_cost == 0 and total_turns == 0:
        return

    parts = [f"[bold]Totals ({len(scored)} packages):[/]"]
    parts.append(f"${total_cost:.2f} cost")
    parts.append(f"{total_turns} turns")
    parts.append(f"{total_in:,} input / {total_out:,} output tokens")
    if total_cache:
        parts.append(f"{total_cache:,} cache-read tokens")
    parts.append(f"{total_duration:.0f}s total duration")
    console.print("  ".join(parts))
