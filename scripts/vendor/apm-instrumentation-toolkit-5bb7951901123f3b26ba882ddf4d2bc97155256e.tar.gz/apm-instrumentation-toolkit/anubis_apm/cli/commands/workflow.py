"""Workflow commands: create, test, lint, review, execute, generate-sample-app, llm-obs."""

import logging
import subprocess
import sys
from functools import partial
from pathlib import Path
from typing import Any

from anubis.core.config import get_config
from anubis.core.resources.spec import TaskSpec
from anubis.workflows.lint import LintInput, LintWorkflow
from anubis.workflows.reviewer import ReviewerWorkflow
from anubis.workflows.reviewer.models import ReviewInput
from anubis.workflows.sample_app import SampleAppInput, SampleAppWorkflow
from anubis.workflows.test import TestInput, TestWorkflow
from anubis_apm.blind import restore_deleted_integration, setup_blind_for_workflow
from anubis_apm.repo_adapters import get_apm_adapter
from anubis_apm.workflows.analyze import analyze_package
from anubis_apm.workflows.execute import ExecuteInput, ExecuteWorkflow
from anubis_apm.workflows.llmobs.models import LlmObsInput
from anubis_apm.workflows.llmobs.workflow import LlmObsWorkflow
from anubis_apm.workflows.new_integration import NewIntegrationWorkflow
from anubis_apm.workflows.reviewer_checks import load_checks
from anubis_apm.workflows.semantic_tests import create_semantic_validation_workflow

from ..console import console, print_header, print_mode_info, print_success
from ..decorators import workflow_command
from ..utils import (
    add_source_arg,
    add_spec_arg,
    add_workflow_args,
    parse_analyze_skip_steps,
    parse_skip_phases,
)
from .post_workflow import post_workflow_menu

logger = logging.getLogger(__name__)


def _common_workflow_kwargs(args) -> dict[str, Any]:
    """Build common kwargs shared by all workflows."""
    adapter = get_apm_adapter(args.repository)
    namespace = adapter.normalize_namespace(args.integration, getattr(args, "maven_coords", None))
    return {
        "namespace": namespace,
        "repository": args.repository,
        "user_prompt": args.prompt,
        "skip_steps": set(parse_skip_phases(args.skip)),
        "headless": args.headless,
        "from_step": args.from_step,
        "rollback_git": args.rollback_git,
        "model": args.model,
        "base_branch": args.base_branch,
        "inject_experience": getattr(args, "experience", False),
        "stop_after": args.stop_after,
    }


def _get_adapter_context(args):
    """Get config, adapter, and common paths for adapter-based workflows."""
    config = get_config()
    adapter = get_apm_adapter(args.repository)
    paths = [adapter.get_plugin_path(args.integration)]
    prompt_variables = {
        "package_name": args.integration,
        "files_to_check": "\n".join(f"- `{p}`" for p in paths),
        "package_version": "latest",
        "version_note": "",
    }
    return config, adapter, paths, prompt_variables


@workflow_command("analyze")
def cmd_analyze(args):
    """Run analyze workflow to identify instrumentation targets."""
    print_header(f"dd-apm: Analyzing {args.integration}")

    result = analyze_package(
        package_name=args.integration,
        repository=args.repository,
        user_prompt=args.prompt,
        skip_steps=parse_analyze_skip_steps(args.skip),
        headless=args.headless,
        maven_coordinates=getattr(args, "maven_coords", None),
        blind=getattr(args, "blind", False),
    )

    console.print()
    if result.success and result.output is not None:
        print_success(f"Analysis complete! Found {len(result.output.targets)} targets.")
        return 0
    console.print(f"[red]Error:[/] {result.error}")
    console.rule("[bold red]Analysis failed[/]", style="red")
    return 1


@workflow_command("create", "new_integration")
def cmd_create(args):
    """Create a new integration workflow (or resume existing)."""
    print_header(f"dd-apm: Creating integration for {args.integration}")
    print_mode_info(args.mode, args.headless, args.prompt)

    skip_review = args.mode == "agent" or args.headless
    ctx_overrides: dict = {}
    blind_cleanup = None
    if getattr(args, "blind", False):
        blind_overrides, blind_cleanup = setup_blind_for_workflow(args.integration, args.repository)
        ctx_overrides.update(blind_overrides)
    workflow = NewIntegrationWorkflow(  # type: ignore[call-arg]
        **_common_workflow_kwargs(args),
        config={
            "skip_review": skip_review,
            "maven_coordinates": getattr(args, "maven_coords", None),
            "ctx_overrides": ctx_overrides,
        },
    )
    try:
        result = workflow.run()  # type: ignore[attr-defined]
    except Exception:
        if blind_cleanup:
            restore_deleted_integration(*blind_cleanup)
        raise
    else:
        # workflow.run() returns Result(success=False) on failure rather than raising,
        # so the except branch above only fires for unexpected exceptions. Restore here
        # for the common failure path so the repo is not left with the integration deleted.
        if blind_cleanup and not result.success:
            restore_deleted_integration(*blind_cleanup)

    console.print()
    if result.success:
        print_success("Integration creation complete!")
        if not args.headless:
            config, adapter, paths, _ = _get_adapter_context(args)
            repo_path = config.get_repo_root(args.repository)
            post_workflow_menu(repo_path, args.integration, args.repository, paths)
        return 0
    console.print(f"[red]Error:[/] {result.error}")
    console.rule("[bold red]Integration creation failed or was cancelled[/]", style="red")
    return 1


@workflow_command("test")
def cmd_test(args):
    """Run test workflow."""
    print_header(f"dd-apm: Testing {args.integration}")

    config, adapter, paths, prompt_variables = _get_adapter_context(args)
    workflow = TestWorkflow(
        **_common_workflow_kwargs(args),
        working_dir=config.get_repo_root(args.repository),
        test_command=adapter.get_test_command(args.integration),
        paths=paths,
        prompt_variables=prompt_variables,
        integration=args.integration,
        step_configs={"diagnosis": {"sandbox": False}, "fixer": {"sandbox": False}},
    )

    result = workflow.run(TestInput(max_iterations=args.max_iterations))
    console.print()
    if result.success:
        print_success(f"Tests passing after {result.output.iterations} iterations!")
        return 0
    console.rule("[bold red]Tests failed[/]", style="red")
    return 1


@workflow_command("lint")
def cmd_lint(args):
    """Run lint workflow."""
    print_header(f"dd-apm: Linting {args.integration}")

    config, adapter, default_paths, _ = _get_adapter_context(args)
    paths = args.paths if args.paths else default_paths

    workflow = LintWorkflow(
        **_common_workflow_kwargs(args),
        lint_fn=partial(adapter.lint_paths, repo_root=config.get_repo_root(args.repository)),
        format_lint_fn=adapter.format_lint_errors_for_prompt,
        working_dir=config.get_repo_root(args.repository),
        integration=args.integration,
    )

    result = workflow.run(
        LintInput(paths=paths, auto_fix=args.fix, max_iterations=args.max_iterations)
    )
    console.print()
    if result.success:
        print_success("Lint complete!")
        return 0
    if result.output:
        console.print(f"[yellow]Lint found {result.output.final_errors} errors[/]")
    else:
        console.print(f"[red]Lint failed: {result.error}[/]")
    return 1


@workflow_command("review")
def cmd_review(args):
    """Run reviewer workflow."""
    print_header(f"dd-apm: Reviewing {args.integration}")

    config, adapter, paths, prompt_variables = _get_adapter_context(args)
    workflow = ReviewerWorkflow(
        **_common_workflow_kwargs(args),
        working_dir=config.get_repo_root(args.repository),
        checks=load_checks(args.repository),
        paths=paths,
        test_command=adapter.get_test_command(args.integration),
        prompt_variables=prompt_variables,
        integration=args.integration,
    )

    result = workflow.run(ReviewInput())
    console.print()
    if result.success:
        print_success("Review complete!")
        return 0
    console.rule("[bold red]Review failed or was cancelled[/]", style="red")
    return 1


@workflow_command("semantic")
def cmd_semantic(args):
    """Run semantic validation workflow (evalya integration tests)."""
    print_header(f"dd-apm: Semantic validation for {args.integration}")

    try:
        # create_semantic_validation_workflow runs the workflow and returns Result
        result = create_semantic_validation_workflow(
            integration_name=args.integration,
            max_iterations=args.max_iterations,
            repository=args.repository,
        )
        console.print()

        # Check workflow execution success and extract output
        if not result.success:
            console.rule("[bold red]✗ Workflow execution failed[/]", style="red")
            if result.error:
                console.print(f"[red]Error: {result.error}[/]")
            return 1

        # Access the SemanticTestResult from result.output
        output = result.output
        if output and output.success:
            print_success(f"Semantic tests passing after {output.iterations} iterations!")
            return 0
        else:
            # Phase 1: Exit with 0 even if tests fail (expected behavior)
            iterations = output.iterations if output else 0
            console.print(
                f"[dim]Tests did not pass after {iterations} iterations (Phase 1 expected)[/]"
            )
            console.rule(
                "[bold yellow]⚠ Workflow complete - tests failed (Phase 1)[/]", style="yellow"
            )
            return 0  # Exit 0 in Phase 1
    except KeyboardInterrupt:
        console.print("\n[yellow]Semantic validation cancelled[/]")
        return 0


def _resolve_spec(value: str) -> str:
    """Resolve --spec value: read from stdin, file, or treat as direct text."""
    if value == "-":
        return sys.stdin.read()
    # Only try path resolution for short strings that could plausibly be file paths
    if len(value) < 512:
        try:
            path = Path(value)
            if path.is_file():
                return path.read_text()
        except OSError as e:
            logger.debug("Could not read file at path %s: %s", value, e)
    return value


@workflow_command("execute")
def cmd_execute(args):
    """Run spec-driven execute workflow."""
    if not args.spec and not args.source:
        console.print("[red]Error:[/] one of --spec or --source is required")
        return 1

    # ``--source``-only path: the planner reads the dynamic context, picks
    # a spec template from ``specs/``, and the workflow merges it in. If
    # the planner can't identify a template, it halts so the engineer can
    # rerun with ``--spec`` explicitly.
    if args.spec:
        # Use from_source so file-based specs record their absolute path on
        # ``spec.source_path`` — the framework's auto-inject lifts that onto
        # ``ctx.spec_path`` so prompt fragments referencing ``{{spec_path}}``
        # resolve. Going through ``_resolve_spec`` + ``parse`` would silently
        # drop the path and leave the placeholder unbound.
        spec = TaskSpec.from_source(args.spec)
    else:
        spec = None

    # ``--source`` is additive when ``--spec`` is set, and primary when it
    # isn't. The CLI fetches it either way; the workflow's plan step uses
    # ``ctx.spec_path is None`` to decide whether to require spec selection.
    if args.source is not None:
        try:
            dynamic = TaskSpec.from_dynamic_source(args.source)
        except ValueError as exc:
            console.print(f"[red]Error:[/] {exc}")
            return 1
        spec = spec.merge(dynamic) if spec is not None else dynamic

    # By construction one of --spec / --source was supplied (checked above),
    # so `spec` is guaranteed non-None here. The assert narrows the type for
    # mypy through the rest of the function.
    assert spec is not None

    print_header(f"dd-apm: Execute — {args.integration}")
    if spec.scope:
        console.print(f"[dim]Scope:[/] {spec.scope}")
    console.print()

    workflow = ExecuteWorkflow(  # type: ignore[call-arg]
        **_common_workflow_kwargs(args),
        config={"task_spec": spec, "spec_explicit": bool(args.spec)},
    )

    result = workflow.run(ExecuteInput(spec=spec))  # type: ignore[attr-defined]
    console.print()
    if result.success:
        print_success("Execute complete!")
        return 0
    console.print(f"[red]Error:[/] {result.error}")
    return 1


@workflow_command("generate-sample-app")
def cmd_generate_sample_app(args):
    """Generate a sample application from a spec and/or prompt."""
    if not args.spec and not args.prompt:
        console.print("[red]Error:[/] Must provide --spec, --prompt, or both")
        return 1

    print_header("dd-apm: Generating sample app")

    app_spec = _resolve_spec(args.spec) if args.spec else None

    # Resolve language: explicit --language flag, fallback to repository config
    language = getattr(args, "language", None)
    if not language and args.repository:
        try:
            config = get_config()
            language = config.get_repo(args.repository).language
        except (KeyError, ValueError) as e:
            logging.debug("Could not determine language for repository %r: %s", args.repository, e)

    output_dir = Path(args.output_dir).resolve()
    workflow = SampleAppWorkflow(
        output_dir=output_dir,
        app_spec=app_spec,
        language=language,
        user_prompt=args.prompt,
        namespace=args.integration,
        repository=args.repository,
        model=args.model,
        headless=args.headless,
    )

    result = workflow.run(SampleAppInput(output_dir=str(output_dir)))
    console.print()
    if result.success:
        print_success(f"Sample app generated: {result.output.app_path}")
        return 0
    console.print(f"[red]Error:[/] {result.error}")
    if result.output and result.output.validation_errors:
        for err in result.output.validation_errors:
            console.print(f"  [red]- {err}[/]")
    return 1


def register_workflow_commands(subparsers):
    """Register workflow commands with the parser."""
    # Generate sample app command (integration is optional, defaults to "sample-app")
    sample_parser = subparsers.add_parser(
        "generate-sample-app", help="Generate a sample application from a spec file"
    )
    add_workflow_args(sample_parser, require_integration=False)
    sample_parser.add_argument(
        "--spec", default=None, help="App spec: file path, direct text, or '-' for stdin"
    )
    sample_parser.add_argument(
        "--output-dir", default=".", help="Directory to write the generated app (default: cwd)"
    )
    sample_parser.add_argument(
        "--language",
        default=None,
        help="Target language (e.g., node, python). Inferred from --repository if omitted",
    )
    sample_parser.set_defaults(handler=cmd_generate_sample_app)

    # Analyze command
    analyze_parser = subparsers.add_parser(
        "analyze", help="Analyze a package to identify instrumentation targets"
    )
    add_workflow_args(analyze_parser)
    analyze_parser.add_argument(
        "--blind",
        action="store_true",
        default=False,
        help=(
            "Blind-test mode: delete the integration from the repo before running, "
            "then block all git commands and dd-trace GitHub access so the agent "
            "cannot recover the deleted code. Deleted files are restored automatically "
            "after the run. Use this to evaluate how well the agent can analyse a "
            "package from scratch when the existing implementation is absent."
        ),
    )
    analyze_parser.set_defaults(handler=cmd_analyze)

    # Execute command (spec-driven workflow)
    execute_parser = subparsers.add_parser("execute", help="Run spec-driven execute workflow")
    add_workflow_args(execute_parser)
    add_spec_arg(execute_parser, required=False)
    add_source_arg(execute_parser)
    execute_parser.set_defaults(handler=cmd_execute)

    # Create command
    create_parser = subparsers.add_parser(
        "create", help="Create new integration (or resume existing)"
    )
    add_workflow_args(create_parser)
    create_parser.add_argument(
        "--mode", choices=["guided", "agent"], default="guided", help="Workflow mode"
    )
    create_parser.add_argument(
        "--blind",
        action="store_true",
        default=False,
        help=(
            "Blind-test mode: delete the integration from the repo before running, "
            "then block all git commands and dd-trace GitHub access so the agent "
            "cannot recover the deleted code. On success the generated files are "
            "left in place for review; on failure the originals are restored. "
            "Use this to evaluate how well the agent can recreate an integration "
            "from scratch when the existing implementation is absent."
        ),
    )
    create_parser.set_defaults(handler=cmd_create)

    # Test command
    test_parser = subparsers.add_parser("test", help="Run test workflow")
    add_workflow_args(test_parser)
    test_parser.add_argument("--max-iterations", type=int, default=10, help="Max fix iterations")
    test_parser.set_defaults(handler=cmd_test)

    # Lint command
    lint_parser = subparsers.add_parser("lint", help="Run lint workflow")
    add_workflow_args(lint_parser)
    lint_parser.add_argument(
        "--paths", "-p", nargs="*", help="Paths to lint (default: plugin path)"
    )
    lint_parser.add_argument("--fix", action="store_true", help="Auto-fix lint issues")
    lint_parser.add_argument("--max-iterations", type=int, default=3, help="Max fix iterations")
    lint_parser.set_defaults(handler=cmd_lint)

    # Review command
    review_parser = subparsers.add_parser("review", help="Run reviewer workflow")
    add_workflow_args(review_parser)
    review_parser.set_defaults(handler=cmd_review)

    # Semantic validation command
    semantic_parser = subparsers.add_parser(
        "semantic", help="Run semantic validation workflow (evalya integration tests)"
    )
    add_workflow_args(semantic_parser)
    semantic_parser.set_defaults(repository="dd_trace_py")
    semantic_parser.add_argument(
        "--max-iterations", type=int, default=10, help="Max fix iterations"
    )
    semantic_parser.set_defaults(handler=cmd_semantic)

    # LLM obs command (assumes tracing already exists)
    llm_obs_parser = subparsers.add_parser(
        "llm-obs", help="Generate LLM Obs layer (assumes tracing plugin exists)"
    )

    add_workflow_args(llm_obs_parser)
    llm_obs_parser.add_argument(
        "--max-fix-iterations",
        type=int,
        default=10,
        help="Max fix iterations for llmobs tests",
    )
    llm_obs_parser.set_defaults(handler=cmd_llm_obs)


@workflow_command("llm-obs")
def cmd_llm_obs(args):
    """Generate LLM Obs layer (assumes tracing plugin exists)."""
    print_header(f"dd-apm: Creating LLM Obs Layer for {args.integration}")

    console.print("[dim]Generating LLM observability layer...[/]")
    console.print(f"[dim]Max fix iterations:[/] {getattr(args, 'max_fix_iterations', 10)}")
    console.print()

    # Use explicit --base-branch if provided; otherwise detect the tracer
    # repo's current branch so the llmobs workflow includes in-progress work.
    base_branch = args.base_branch
    if not base_branch:
        tracer_repo = get_config().get_repo_root(args.repository)
        _branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=str(tracer_repo),
            capture_output=True,
            text=True,
        )
        base_branch = _branch_result.stdout.strip() if _branch_result.returncode == 0 else None

    workflow = LlmObsWorkflow(  # type: ignore[call-arg]
        namespace=args.integration,
        repository=args.repository,
        headless=args.headless,
        base_branch=base_branch,
        config={
            "max_llmobs_iterations": getattr(args, "max_fix_iterations", 10),
        },
    )

    result = workflow.run(  # type: ignore[attr-defined]
        LlmObsInput(
            integration_name=args.integration,
            max_llmobs_iterations=getattr(args, "max_fix_iterations", 10),
        )
    )

    console.print()
    llm_obs_result = getattr(result.output, "llm_obs_result", None) if result.output else None
    tests_passed = (
        llm_obs_result is not None
        and llm_obs_result.tests_passing
        and llm_obs_result.final_failing == 0
    )
    if result.success and result.output and tests_passed:
        print_success("LLM Obs Layer Complete!")
        console.print()

        # Show llmobs results
        if llm_obs_result:
            console.print("[green]✓[/] LLM observability layer ready!")
            console.print()
            console.print("[dim]LLMObs Stats:[/]")
            console.print(f"  Tests passing: [green]{llm_obs_result.final_passing}[/]")
            console.print(
                "  Tests failing: "
                f"{'[red]' if llm_obs_result.final_failing > 0 else '[dim]'}"
                f"{llm_obs_result.final_failing}"
                f"{'[/]' if llm_obs_result.final_failing > 0 else '[/]'}"
            )
            console.print(f"  Tests skipped: [dim]{llm_obs_result.final_skipped}[/]")
            console.print(f"  Iterations: [cyan]{llm_obs_result.total_iterations}[/]")
            console.print(f"  Test file: [dim]{llm_obs_result.test_file_path}[/]")
            console.print()

        console.print("[dim]Next Steps:[/]")
        console.print("  1. Review generated LLMObs code")
        console.print("  2. Run the LLMObs tests to verify")
        console.print("  3. Record VCR cassettes if needed")
        console.print("  4. Create PR!")
        console.print()

        return 0

    console.rule("[bold red]LLM Obs Layer Failed[/]", style="red")
    console.print()

    # Show error message if available
    if result.error:
        console.print(f"[red]Error:[/] {result.error}")
        console.print()

    # Show llmobs failure details
    if llm_obs_result:
        console.print("[red]✗ LLM Obs Plugin[/]")
        console.print(f"  Failed after {llm_obs_result.total_iterations} iterations")
        console.print()
        console.print(
            f"  [dim]Tests:[/] {llm_obs_result.final_passing}✓ / "
            f"{llm_obs_result.final_failing}✗ / "
            f"{llm_obs_result.final_skipped}⊘"
        )
        last_diag = llm_obs_result.history[-1].diagnosis if llm_obs_result.history else None
        failure_mode = last_diag.failure_mode.value if last_diag else None
        failure_details = (
            last_diag.failure_details[:200] if last_diag and last_diag.failure_details else None
        )
        if failure_mode:
            console.print(f"  [dim]Failure Mode:[/] {failure_mode}")
        if failure_details:
            console.print(f"  [dim]Details:[/] {failure_details}...")
        if llm_obs_result.error:
            console.print()
            console.print(f"  [dim]Error:[/] {llm_obs_result.error}")

    console.print()
    console.print("[dim]Debug Info:[/]")
    console.print(f"  Run [cyan]dd-apm status {args.integration}[/] to check workflow state")
    console.print()

    return 1
