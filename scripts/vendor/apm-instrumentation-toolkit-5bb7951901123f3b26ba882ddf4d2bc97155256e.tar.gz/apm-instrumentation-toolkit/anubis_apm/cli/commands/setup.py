"""Setup and health-check commands (dd-apm setup / dd-apm doctor)."""

from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import subprocess
import time
from datetime import datetime, timezone
from typing import Any, Optional

import httpx

from anubis_apm.setup.prereqs import CheckResult, Prereq, run_checks

from ..console import console, print_header, print_success

logger = logging.getLogger(__name__)


def _run_fix(fix_cmd: list[str]) -> bool:
    """Run an auto-fix command.  Returns True on success."""
    if fix_cmd and shutil.which(fix_cmd[0]) is None:
        console.print(f"  [yellow]Skipped:[/] [cyan]{fix_cmd[0]}[/] not installed on this system")
        return False
    console.print(f"  [dim]Running:[/] {' '.join(fix_cmd)}")
    try:
        result = subprocess.run(fix_cmd)
    except FileNotFoundError:
        console.print(f"  [yellow]Skipped:[/] [cyan]{fix_cmd[0]}[/] not installed on this system")
        return False
    return result.returncode == 0


def _print_check_row(prereq: Prereq, result: CheckResult) -> None:
    status = "[green]✓[/]" if result.ok else "[red]✗[/]"
    required_tag = "" if prereq.required else " [dim](optional)[/]"
    feature_tag = f" [dim][{prereq.feature}][/]" if prereq.feature else ""
    console.print(f"  {status}  {prereq.name}{required_tag}{feature_tag}")
    if not result.ok:
        console.print(f"       [dim]{result.message}[/]")
        if result.fix_note:
            console.print(f"       [yellow]Fix:[/] {result.fix_note}")
        elif result.fix_cmd:
            console.print(f"       [yellow]Fix:[/] {' '.join(result.fix_cmd)}")


def cmd_doctor(args: argparse.Namespace) -> int:
    """Read-only health check against the prerequisite manifest."""
    required_only: bool = getattr(args, "required", False)
    as_json: bool = getattr(args, "json", False)

    results = run_checks(required_only=required_only)

    failed_pairs: list[tuple[Prereq, CheckResult]] = [(p, r) for p, r in results if not r.ok]
    required_failed_pairs: list[tuple[Prereq, CheckResult]] = [
        (p, r) for p, r in results if not r.ok and p.required
    ]

    if as_json:
        payload: list[dict[str, Any]] = []
        for prereq, result in results:
            entry: dict[str, Any] = {
                "name": prereq.name,
                "description": prereq.description,
                "required": prereq.required,
                "ok": result.ok,
                "message": result.message,
                "fixable": result.fixable,
            }
            if prereq.feature:
                entry["feature"] = prereq.feature
            if result.fix_cmd:
                entry["fix_cmd"] = result.fix_cmd
            if result.fix_note:
                entry["fix_note"] = result.fix_note
            payload.append(entry)
        print(json.dumps(payload, indent=2))
        return 1 if required_failed_pairs else 0

    print_header("dd-apm doctor")

    for prereq, result in results:
        _print_check_row(prereq, result)

    console.print()

    if not failed_pairs:
        print_success("All checks passed")
        return 0

    if required_failed_pairs:
        console.print(f"[red]{len(required_failed_pairs)} required check(s) failed.[/]")
        if any(r.fixable for _, r in required_failed_pairs):
            console.print("Run [cyan]dd-apm setup[/] to auto-fix installable issues.")
        return 1

    console.print(f"[yellow]{len(failed_pairs)} optional check(s) failed.[/]")
    return 0


def cmd_setup(args: argparse.Namespace) -> int:
    """First-run installer: install deps, run auth flows, configure."""
    print_header("dd-apm setup")
    console.print("Checking prerequisites and installing missing dependencies...")
    console.print()

    results = run_checks(required_only=False)

    # Phase 1: auto-install anything with a fix_cmd (brew packages)
    installed_any = False
    for prereq, result in results:
        if result.ok or not result.fix_cmd:
            continue
        console.print(f"[yellow]Installing[/] {prereq.name}...")
        if _run_fix(result.fix_cmd):
            console.print(f"  [green]✓[/] {prereq.name} installed")
            installed_any = True
        else:
            console.print(f"  [red]✗[/] Failed to install {prereq.name}")
            if result.fix_note:
                console.print(f"    {result.fix_note}")

    if installed_any:
        console.print()
        # Re-run checks to pick up newly-installed tools
        results = run_checks(required_only=False)

    # Phase 2: report anything still failing (manual auth steps, etc.)
    manual_steps = [(p, r) for p, r in results if not r.ok and r.fix_note and not r.fix_cmd]
    if manual_steps:
        console.print("[bold]Manual steps required:[/]")
        for prereq, result in manual_steps:
            console.print(f"  [yellow]![/]  {prereq.name}: {result.message}")
            console.print(f"       [cyan]{result.fix_note}[/]")
        console.print()

    # Phase 3: run config init if not already configured
    try:
        from anubis.core.config import ConfigLoader  # noqa: PLC0415

        if not ConfigLoader().exists():
            console.print("[bold]Running initial configuration...[/]")
            console.print()
            from .config import cmd_config_init  # noqa: PLC0415

            init_result = cmd_config_init(args) or 0
            if init_result != 0:
                return init_result
            console.print()
    except Exception as e:
        console.print(f"[yellow]Warning:[/] Config init skipped: {e}")

    # Phase 4: final doctor pass
    console.print("[bold]Final health check:[/]")
    console.print()
    return cmd_doctor(args)


def _api_base(dd_site: Optional[str] = None) -> str:
    """Return the Datadog API base URL for the configured site.

    DD_SITE is typically ``datadoghq.com`` (US1). The UI lives at
    ``app.datadoghq.com``; the API lives at ``api.datadoghq.com``.
    If DD_SITE already has an ``app.`` prefix (misconfigured env), strip it.
    """
    site = dd_site or os.environ.get("DD_SITE") or "datadoghq.com"
    site = site.removeprefix("app.")
    return f"https://api.{site}"


def _poll_api(
    method: str,
    url: str,
    *,
    headers: dict,
    params: Optional[dict] = None,
    json: Optional[dict] = None,
    timeout: float,
    poll_interval: float,
    label: str,
) -> Optional[dict]:
    """Poll a Datadog API endpoint until it returns data or the deadline passes.

    Returns the first element of ``response.json()["data"]`` on success.
    Returns None on timeout or a non-retryable HTTP error.
    """
    deadline = time.monotonic() + timeout
    attempt = 0
    while time.monotonic() < deadline:
        attempt += 1
        try:
            if method == "GET":
                response = httpx.get(url, params=params, headers=headers, timeout=10.0)
            else:
                response = httpx.post(url, json=json, headers=headers, timeout=10.0)
            if response.status_code == 200:
                data = response.json().get("data")
                if data:
                    return dict(data[0])
                remaining = deadline - time.monotonic()
                if remaining > 0:
                    time.sleep(min(poll_interval, remaining))
                continue
            logger.debug(
                "%s %s HTTP %s on attempt %d: %s",
                label,
                method,
                response.status_code,
                attempt,
                response.text[:200],
            )
            if response.status_code in (401, 403):
                console.print(
                    f"  [red]Backend API auth error (HTTP {response.status_code})"
                    " — check DD_API_KEY / DD_APP_KEY have read scope[/]"
                )
            elif response.status_code in (400, 422):
                console.print(
                    f"  [dim]Backend API query error (HTTP {response.status_code}): "
                    f"{response.text[:120]}[/]"
                )
            else:
                console.print(f"  [dim]Backend API returned HTTP {response.status_code}[/]")
            return None
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError) as e:
            logger.debug("%s attempt %d failed: %s", label, attempt, e)
            remaining = deadline - time.monotonic()
            if remaining > 0:
                time.sleep(min(poll_interval, remaining))

    return None


def _verify_llmobs_trace_ingested(
    trace_id: str,
    timeout: float = 60.0,
    poll_interval: float = 3.0,
) -> Optional[dict]:
    """Poll the LLMObs spans search API to confirm a trace was ingested."""
    api_key = os.environ.get("DD_API_KEY", "").strip()
    app_key = os.environ.get("DD_APP_KEY", "").strip()
    if not api_key or not app_key:
        missing = "DD_API_KEY" if not api_key else "DD_APP_KEY"
        console.print(f"  [yellow]Backend verification skipped — {missing} not set[/]")
        return None

    url = f"{_api_base()}/api/v2/llm-obs/v1/spans/events/search"
    headers = {"DD-API-KEY": api_key, "DD-APPLICATION-KEY": app_key}
    body = {
        "data": {
            "type": "spans",
            "attributes": {
                "filter": {"trace_id": trace_id, "from": "now-1h", "to": "now"},
                "page": {"limit": 1},
            },
        }
    }
    return _poll_api(
        "POST",
        url,
        headers=headers,
        json=body,
        timeout=timeout,
        poll_interval=poll_interval,
        label="llmobs",
    )


def _verify_apm_trace_ingested(
    trace_id: str,
    timeout: float = 60.0,
    poll_interval: float = 3.0,
) -> Optional[dict]:
    """Poll the APM spans search API to confirm a trace was ingested by trace_id."""
    api_key = os.environ.get("DD_API_KEY", "").strip()
    app_key = os.environ.get("DD_APP_KEY", "").strip()
    if not api_key or not app_key:
        missing = "DD_API_KEY" if not api_key else "DD_APP_KEY"
        console.print(f"  [yellow]Backend verification skipped — {missing} not set[/]")
        return None

    # GET /api/v2/spans/events — trace_id is a reserved field (no @ prefix).
    url = f"{_api_base()}/api/v2/spans/events"
    headers = {"DD-API-KEY": api_key, "DD-APPLICATION-KEY": app_key}
    params = {
        "filter[query]": f"trace_id:{trace_id}",
        "filter[from]": "now-1h",
        "filter[to]": "now",
        "page[limit]": "1",
    }
    return _poll_api(
        "GET",
        url,
        headers=headers,
        params=params,
        timeout=timeout,
        poll_interval=poll_interval,
        label="apm",
    )


def cmd_smoke(args: argparse.Namespace) -> int:
    """End-to-end smoke test: spawn a real agent, verify the full APM stack works."""
    from anubis.core.config import ConfigLoader, get_config  # noqa: PLC0415
    from anubis.workflows.smoke import SmokeWorkflow  # noqa: PLC0415
    from anubis.workflows.smoke.models import SmokeInput  # noqa: PLC0415
    from anubis_apm import setup  # noqa: PLC0415
    from anubis_apm.cli.preflight import PreflightError, run_preflight  # noqa: PLC0415

    print_header("dd-apm smoke")

    if not ConfigLoader().exists():
        console.print("[red]No configuration found.[/] Run [cyan]dd-apm config init[/] first.")
        return 1

    # Run prereq checks so users see a full health picture before the test runs.
    # Skip repo-specific features (e.g. dd-trace-js node_modules) — smoke is repo-agnostic.
    _SMOKE_SKIP_FEATURES = {"dd-trace-js", "dd-trace-py", "dd-trace-java"}
    # In CI, dd-auth / dd-auth-session aren't required (dd-sts provides credentials)
    # and gh isn't needed for the smoke test itself.
    _CI_EXEMPT = {"dd-auth", "dd-auth-session", "gh"} if os.environ.get("CI") else set()
    console.print("[bold]Prerequisite checks[/]")
    console.print()
    prereq_results = run_checks(required_only=False, skip_features=_SMOKE_SKIP_FEATURES)
    required_failed: list[tuple[Prereq, CheckResult]] = [
        (p, r) for p, r in prereq_results if not r.ok and p.required and p.name not in _CI_EXEMPT
    ]
    for prereq, check_result in prereq_results:
        _print_check_row(prereq, check_result)
    console.print()
    if required_failed:
        console.print(
            f"[red]{len(required_failed)} required prerequisite(s) failed.[/] "
            "Fix them before running the smoke test."
        )
        return 1

    try:
        run_preflight(args)
    except PreflightError as exc:
        console.print(f"  [red]✗[/] {exc}")
        return 1

    setup.init()
    repository = get_config().default_repository

    console.print()
    console.print("Running smoke test (haiku, max_turns=1)...")
    console.print()

    try:
        workflow = SmokeWorkflow(repository=repository)
        result = workflow.run(SmokeInput())
    except Exception as e:
        console.print(f"[red]Smoke test failed:[/] {e}")
        return 1

    if result and result.success:
        output = result.output
        console.print(f"[green]✓[/] {getattr(output, 'message', 'passed')}")
        console.print()

        ctx = getattr(workflow, "_ctx", None)
        llmobs_url = ctx.get("llmobs_trace_url") if ctx else None
        llmobs_trace_id: Optional[str] = ctx.get("llmobs_trace_id") if ctx else None
        apm_url = ctx.get("apm_trace_url") if ctx else None
        apm_trace_id: Optional[str] = ctx.get("apm_trace_id") if ctx else None

        console.print("[bold]Trace Links[/]")
        console.print("  [dim]Links may take a few seconds to populate.[/]")
        if llmobs_url:
            console.print(f"  [dim]LLM Observability:[/] [purple link={llmobs_url}]{llmobs_url}[/]")
        if apm_url:
            console.print(f"  [dim]APM Trace:[/]         [purple link={apm_url}]{apm_url}[/]")
        if not llmobs_url and not apm_url:
            console.print("  [yellow]Trace links unavailable — check tracing is configured.[/]")
        console.print(
            "  [dim]Test Agent UI:[/]     [purple link=http://localhost:18080]http://localhost:18080[/]"
        )
        console.print()

        # Verify both APM and LLMObs traces were ingested by the Datadog backend.
        # Both checks share a single 90s deadline so they don't stack sequentially.
        if llmobs_trace_id or apm_trace_id:
            console.print("[bold]Backend verification[/]")
            console.print("  [dim]Polling Datadog backend for trace ingestion (up to 90s)...[/]")

            _verify_deadline = time.monotonic() + 90.0

            if llmobs_trace_id:
                remaining = max(0.0, _verify_deadline - time.monotonic())
                llmobs_span = _verify_llmobs_trace_ingested(llmobs_trace_id, timeout=remaining)
                if llmobs_span:
                    console.print("  [green]✓[/] LLMObs trace confirmed")
                    attrs = llmobs_span.get("attributes") or {}
                    name = attrs.get("name", "")
                    kind = attrs.get("span_kind", "")
                    start_ns = attrs.get("start_ns")
                    started = ""
                    if start_ns:
                        try:
                            started = datetime.fromtimestamp(
                                int(start_ns) / 1e9, tz=timezone.utc
                            ).strftime("%H:%M:%S UTC")
                        except Exception:
                            pass
                    parts = [p for p in [name, kind, started] if p]
                    if parts:
                        console.print(f"     [dim]{('  ·  ').join(parts)}[/]")
                else:
                    console.print(
                        "  [yellow]⚠[/] LLMObs trace not yet indexed — links above are still valid"
                    )

            if apm_trace_id:
                remaining = max(0.0, _verify_deadline - time.monotonic())
                apm_span = _verify_apm_trace_ingested(apm_trace_id, timeout=remaining)
                if apm_span:
                    console.print("  [green]✓[/] APM trace confirmed")
                    attrs = apm_span.get("attributes") or {}
                    resource = attrs.get("resource_name", "")
                    service = attrs.get("service", "")
                    ts = attrs.get("start_timestamp", "")
                    started = ts.split("T")[1].split(".")[0] + " UTC" if "T" in ts else ""
                    parts = [p for p in [resource, service, started] if p]
                    if parts:
                        console.print(f"     [dim]{('  ·  ').join(parts)}[/]")
                else:
                    console.print(
                        "  [yellow]⚠[/] APM trace not yet indexed — links above are still valid"
                    )

            console.print()

        print_success("Smoke test passed")
        return 0

    console.print("[red]✗[/] Agent returned failure result")
    return 1


def register_setup_commands(subparsers: argparse._SubParsersAction) -> None:
    """Register setup, doctor, and smoke sub-commands."""
    # doctor
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Check prerequisites and environment health",
    )
    doctor_parser.add_argument(
        "--required",
        action="store_true",
        default=False,
        help="Only check required prerequisites",
    )
    doctor_parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Output results as JSON (for CI pipelines and agents)",
    )
    doctor_parser.set_defaults(handler=cmd_doctor)

    # setup
    setup_parser = subparsers.add_parser(
        "setup",
        help="Install missing dependencies and configure the toolkit (first-run)",
    )
    setup_parser.set_defaults(handler=cmd_setup)

    # smoke
    smoke_parser = subparsers.add_parser(
        "smoke",
        help="End-to-end smoke test: spawn a haiku agent and verify the framework works",
    )
    smoke_parser.set_defaults(handler=cmd_smoke)
