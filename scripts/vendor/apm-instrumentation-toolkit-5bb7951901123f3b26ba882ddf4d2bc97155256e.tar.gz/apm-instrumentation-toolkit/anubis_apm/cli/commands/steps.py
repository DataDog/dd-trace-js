"""dd-apm steps <workflow> — list steps for a workflow."""

import argparse
import importlib
import logging
import pkgutil
import textwrap
from typing import Type

from anubis.core.steps.agent import AgentStep
from anubis.core.workflow import Workflow

logger = logging.getLogger(__name__)

# Packages scanned for Workflow subclasses. Adding a new workflow under any of
# these packages makes it discoverable by `dd-apm steps` automatically — no
# updates to this file required.
_WORKFLOW_PACKAGES = ("anubis.workflows", "anubis_apm.workflows")

# Friendly CLI aliases for workflows whose internal `name` differs from how
# users invoke them on the command line (e.g. `dd-apm create` runs the
# `new_integration` workflow). Keep this small — only add when the CLI name
# genuinely diverges from the workflow's internal name.
_CLI_ALIASES = {
    "create": "new_integration",
    "review": "reviewer",
}


def _iter_submodules(package_name: str):
    """Yield all submodules under a package, importing them as we go."""
    try:
        package = importlib.import_module(package_name)
    except ImportError as exc:
        logger.debug("Could not import workflow package %s: %s", package_name, exc)
        return

    if not hasattr(package, "__path__"):
        return

    for module_info in pkgutil.walk_packages(package.__path__, prefix=f"{package_name}."):
        try:
            yield importlib.import_module(module_info.name)
        except ImportError as exc:
            logger.debug("Skipped %s during workflow discovery: %s", module_info.name, exc)


def _all_subclasses(cls: type) -> set[type]:
    seen: set[type] = set()
    stack = list(cls.__subclasses__())
    while stack:
        sub = stack.pop()
        if sub in seen:
            continue
        seen.add(sub)
        stack.extend(sub.__subclasses__())
    return seen


def _discover_workflows() -> dict[str, Type[Workflow]]:
    """Walk the workflow packages and return a {name: class} map.

    Discovers every concrete Workflow subclass by importing every submodule
    under `_WORKFLOW_PACKAGES` and walking `Workflow.__subclasses__`. CLI
    aliases in `_CLI_ALIASES` are added as additional keys pointing at the
    same class.
    """
    for package in _WORKFLOW_PACKAGES:
        for _module in _iter_submodules(package):
            pass  # importing is the side-effect we need

    found: dict[str, Type[Workflow]] = {}
    for cls in _all_subclasses(Workflow):
        name = getattr(cls, "name", None)
        if not isinstance(name, str) or not name:
            continue
        found.setdefault(name, cls)

    for alias, target in _CLI_ALIASES.items():
        if target in found:
            found.setdefault(alias, found[target])

    return found


def _get_description(step_class) -> str:
    """Get the step description, preferring the config `description` field over docstring."""
    desc: str | None = getattr(step_class, "description", None)
    if desc and desc.strip():
        return desc.strip().splitlines()[0]
    # Fall back to docstring first line
    for source in (getattr(step_class, "_wrapped_fn", None), step_class):
        if source is None:
            continue
        raw: str | None = getattr(source, "__doc__", None)
        if raw and raw.strip():
            return raw.strip().splitlines()[0]
    return ""


def _get_notes(step_class) -> str:
    """Get the step notes (special cases, caveats, language-specific guidance)."""
    notes = getattr(step_class, "notes", None)
    return notes.strip() if notes and notes.strip() else ""


def _step_rows(step_class, indent: int = 0) -> list[tuple[str, str, str, str]]:
    """Recursively expand nested workflows into flat (name, description, type, notes) rows."""
    rows: list[tuple[str, str, str, str]] = []
    prefix = "  " * indent

    is_workflow = isinstance(step_class, type) and issubclass(step_class, Workflow)
    if is_workflow:
        wf_name = getattr(step_class, "name", step_class.__name__)
        desc = _get_description(step_class)
        notes = _get_notes(step_class)
        rows.append((f"{prefix}{wf_name} (nested)", desc, "workflow", notes))
        for child in getattr(step_class, "steps", []):
            rows.extend(_step_rows(child, indent + 1))
    else:
        name = getattr(step_class, "name", step_class.__name__)
        desc = _get_description(step_class)
        notes = _get_notes(step_class)
        is_agent = isinstance(step_class, type) and issubclass(step_class, AgentStep)
        step_type = "agent" if is_agent else "step"
        rows.append((f"{prefix}{name}", desc, step_type, notes))

    return rows


def cmd_steps(args: argparse.Namespace) -> None:
    workflows = _discover_workflows()
    workflow_name = args.workflow
    cls = workflows.get(workflow_name)
    if cls is None:
        known = ", ".join(sorted(workflows))
        print(f"Unknown workflow '{workflow_name}'. Known workflows: {known}")
        raise SystemExit(1)

    rows: list[tuple[str, str, str, str]] = []
    for step_class in getattr(cls, "steps", []):
        rows.extend(_step_rows(step_class))

    if not rows:
        print(f"No steps found for workflow '{workflow_name}'.")
        return

    show_notes = not getattr(args, "no_notes", False)

    name_w = max(len(r[0]) for r in rows)
    desc_w = max(len(r[1]) for r in rows) if any(r[1] for r in rows) else 0
    type_w = 8

    header = f"{'STEP':<{name_w}}  {'DESCRIPTION':<{desc_w}}  {'TYPE':<{type_w}}"
    print(header)
    print("-" * len(header))
    for i, (name, desc, step_type, notes) in enumerate(rows):
        if i > 0:
            print()
        print(f"{name:<{name_w}}  {desc:<{desc_w}}  {step_type:<{type_w}}")
        if show_notes and notes:
            indent = "  " * (len(name) - len(name.lstrip()))
            for line in notes.splitlines():
                print(f"  {indent}  {line}")


def register_steps_commands(subparsers) -> None:
    """Register the `steps` subcommand."""
    parser = subparsers.add_parser(
        "steps",
        help="List steps for a workflow",
        description=textwrap.dedent(
            """\
            List all steps for a given workflow, including their descriptions and types.
            Nested workflows are expanded inline with indentation.

            Workflows are discovered automatically by scanning the workflow packages.
            Run `dd-apm steps <invalid>` to see the full list of known names.

            Examples:
              dd-apm steps create
              dd-apm steps test
              dd-apm steps lint
            """
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("workflow", help="Workflow name (auto-discovered)")
    parser.add_argument(
        "--no-notes",
        action="store_true",
        default=False,
        dest="no_notes",
        help="Suppress per-step notes (shown by default)",
    )
    parser.set_defaults(handler=cmd_steps)
