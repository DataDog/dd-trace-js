"""Runtime preflight checks for workflow commands.

All checks that run before a workflow starts live here. They have side
effects (credential injection, Docker restarts, console output) and raise
PreflightError on hard failures.

Static, no-side-effect checks for ``dd-apm doctor`` live in
``anubis_apm/setup/prereqs.py``.

Adding a new preflight check
----------------------------
1. Write a ``_preflight_<name>(args)`` function — print status, raise PreflightError on failure.
2. Add a ``PreflightCheck`` entry to ``PREFLIGHT_CHECKS``.
3. Use ``should_run_fn`` if the check should be skipped under certain conditions.
"""

import logging
import os
from dataclasses import dataclass, field
from typing import Callable, Optional

from anubis.core.config import ConfigLoader
from anubis.core.docker import ensure_services_running, get_container_env_var, restart_service
from anubis.core.tracing import (
    TracingPreflightError,
    check_tracing_requirements,
    get_resolved_agent_url,
    get_tracer_log_file,
)
from anubis.core.tracing.dd_auth import DdAuthError, get_org2_credentials
from anubis_apm.repo_adapters import get_apm_adapter
from anubis_apm.repo_adapters._repos import REPO_REGISTRY
from anubis_apm.setup.prereqs import _check_anthropic_key, _check_dd_api_key, _check_dd_app_key
from anubis_apm.storage.auth import _has_sso_profile, _is_aws_vault_available

from .console import console
from .utils import clear_state

logger = logging.getLogger(__name__)

# Services defined in docker-compose.yml that tracing requires
_TRACING_SERVICES = ["datadog-agent", "dd-apm-test-agent"]

# container_name from docker-compose.yml — used to inspect running agent credentials
_AGENT_CONTAINER = "datadog-agent-org2"


class PreflightError(Exception):
    """Raised when a required preflight check fails and the workflow cannot proceed."""


# ---------------------------------------------------------------------------
# PreflightCheck — the class
# ---------------------------------------------------------------------------


@dataclass
class PreflightCheck:
    """A single runtime preflight check with side effects.

    Unlike ``Prereq`` (which returns a ``CheckResult`` and has no side effects),
    preflight checks print their own status to the console and raise
    ``PreflightError`` on hard failures. They may also restart Docker services or
    inject credentials into the environment.
    """

    name: str
    description: str
    check_fn: Callable  # (args) -> None; raises PreflightError on failure
    should_run_fn: Optional[Callable] = field(default=None)  # (args) -> bool

    def should_run(self, args) -> bool:
        if self.should_run_fn is not None:
            return bool(self.should_run_fn(args))
        return True

    def run(self, args) -> None:
        self.check_fn(args)


# ---------------------------------------------------------------------------
# Check functions — one per PreflightCheck entry
# ---------------------------------------------------------------------------


def _preflight_config(args) -> None:
    """Validate config health and surface the active repository."""
    try:
        loader = ConfigLoader()
        config = loader.load()
    except Exception:
        # let needs_init / downstream handle load failures
        repository = getattr(args, "repository", None)
        console.print(f"  [green]✓[/] Config valid [dim](repository: {repository or 'unknown'})[/]")
        return

    default = config.default_repository
    try:
        get_apm_adapter(default)
    except ValueError:
        console.print(
            f"[yellow]Configuration issue:[/] default repository '{default}' is not supported."
        )
        console.print("Run [cyan]dd-apm config init[/] to reconfigure.")
        raise PreflightError("Configuration is invalid. Run 'dd-apm config init' to reconfigure.")

    try:
        repo_root = config.get_repo_root(default)
        if not repo_root.exists():
            console.print(
                f"[red]Error:[/] repository path for '{default}' does not exist: {repo_root}"
            )
            console.print(
                f"Run [cyan]dd-apm config add-repo {default} <path>[/] to update the path."
            )
            raise PreflightError(
                "Configuration is invalid. Run 'dd-apm config init' to reconfigure."
            )
    except PreflightError:
        raise
    except Exception:
        pass  # get_repo_root failure handled downstream

    # Hint: show any supported repos that aren't configured yet.
    try:
        unconfigured = [
            r.dir_name
            for r in REPO_REGISTRY.values()
            if r.has_adapter and r.internal_name not in config.repositories
        ]
        if unconfigured:
            console.print(
                f"  [dim]○ More tracers available: {', '.join(unconfigured)} "
                f"— run [cyan]dd-apm config init[/] to add them[/]"
            )
    except Exception:
        logger.debug("Could not check for unconfigured repos", exc_info=True)

    repository = getattr(args, "repository", None) or default
    console.print(f"  [green]✓[/] Config valid [dim](repository: {repository})[/]")


def _check_required_api_keys() -> None:
    """Verify required API keys are set. Raises PreflightError if any are missing."""
    checks = [
        ("ANTHROPIC_API_KEY", _check_anthropic_key),
        ("DD_API_KEY", _check_dd_api_key),
        ("DD_APP_KEY", _check_dd_app_key),
    ]
    results = [(name, fn()) for name, fn in checks]
    failures = [(name, result) for name, result in results if not result.ok]
    if not failures:
        return
    missing = [name for name, _ in failures]
    lines = [f"Required API key(s) not set: {', '.join(missing)}"]
    for name, result in failures:
        if result.fix_note:
            lines.append(f"  {name}: {result.fix_note}")
    raise PreflightError("\n".join(lines))


def _preflight_api_keys(args) -> None:
    _check_required_api_keys()
    console.print("  [green]✓[/] API keys configured")


def _preflight_local_agents(args) -> None:
    """Enforce Org 2 credentials, then start Docker agents and verify tracing ports.

    Skipped in CI and remote workspace mode (agents aren't available there).

    Auth flow (strict — no fallbacks):
      1. Get fresh Org 2 credentials via dd-auth. Hard fail if unavailable or empty.
      2. Force-inject into os.environ, overriding any ambient shell or .env value.
      3. If the Datadog agent container is running with a stale DD_API_KEY, restart it.
      4. Start any services that aren't running.
      5. Verify tracing ports are reachable.
    """
    is_ci = bool(os.environ.get("CI") or os.environ.get("CI_JOB_ID"))
    is_agentless = os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "true").lower() not in (
        "0",
        "false",
    )
    is_remote = bool(os.environ.get("DD_APM_REMOTE"))
    if is_ci or is_agentless or is_remote:
        label = (
            "CI environment"
            if is_ci
            else ("agentless mode" if is_agentless else "remote workspace")
        )
        console.print(f"  [dim]○ Docker agents skipped ({label})[/]")
        return

    working_dir = ConfigLoader().toolkit_root

    # 1. Mandatory Org 2 auth — no fallback to shell env or .env
    try:
        credentials = get_org2_credentials()
    except DdAuthError as exc:
        raise PreflightError(f"Org 2 auth required: {exc}") from exc

    # 2. Force-inject into current process (overrides whatever shell had)
    for key, value in credentials.items():
        os.environ[key] = value

    fresh_api_key = credentials["DD_API_KEY"]
    if not fresh_api_key:
        raise PreflightError("dd-auth returned an empty DD_API_KEY")

    # 3. If the running agent container has a different key, restart it so the
    #    correct key is mounted — updating os.environ alone doesn't affect it.
    container_key = get_container_env_var(_AGENT_CONTAINER, "DD_API_KEY")
    if container_key is not None and container_key != fresh_api_key:
        console.print("  [yellow]⟳[/] Datadog agent has stale credentials — restarting")

        ok = restart_service(
            "datadog-agent",
            working_dir,
            wait_seconds=75,
            on_info=lambda msg: console.print(f"  [dim]{msg}[/]"),
            on_error=lambda msg: console.print(f"  [red]{msg}[/]"),
            on_success=lambda msg: console.print(f"  [green]✓[/] {msg}"),
        )
        if not ok:
            raise PreflightError(
                "Failed to restart datadog-agent with Org 2 credentials.\n"
                "  Check Docker logs: docker logs datadog-agent-org2"
            )

    # 4. Start any services that aren't already running
    ensure_services_running(
        services=_TRACING_SERVICES,
        working_dir=working_dir,
        wait_seconds=5,
        on_info=lambda msg: console.print(f"  [dim]{msg}[/]"),
        on_error=lambda msg: console.print(f"  [red]{msg}[/]"),
        on_success=lambda msg: console.print(f"  [green]✓[/] {msg}"),
        on_warn=lambda msg: console.print(f"  [yellow]{msg}[/]"),
    )

    # 5. Verify tracing ports are reachable
    try:
        check_tracing_requirements(raise_on_error=True)
    except TracingPreflightError as exc:
        raise PreflightError(str(exc)) from exc

    # 6. Surface the resolved tracer agent URL.
    try:
        console.print(f"  [green]✓[/] Tracer agent URL: [dim]{get_resolved_agent_url()}[/]")
    except Exception as exc:
        console.print(f"  [yellow]⚠[/] Could not verify tracer agent URL: [dim]{exc}[/]")

    # 7. Show the tracer log file for debugging span-loss without DD_TRACE_DEBUG=true.
    console.print(f"  [green]✓[/] Tracer log file: [dim]{get_tracer_log_file()}[/]")
    console.print("  [green]✓[/] Datadog org: [dim]Org 2 (Datadog internal)[/]")


def _preflight_s3_sync(args) -> None:
    """Probe S3 credentials so any SSO browser popup happens at preflight, not mid-run.

    The resulting boto3 client is cached at module level — all subsequent S3
    operations reuse it without re-prompting.
    """
    # Already inside an active aws-vault session — credentials are injected.
    active_session = os.environ.get("AWS_VAULT", "")
    if active_session:
        console.print(
            f"  [green]✓[/] S3 experience store configured [dim](aws-vault: {active_session})[/]"
        )
        return

    # CI: env vars are injected fresh — no probe needed.
    is_ci = bool(os.environ.get("CI") or os.environ.get("CI_JOB_ID"))
    if is_ci and os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY"):
        console.print("  [green]✓[/] S3 experience store configured [dim](env vars)[/]")
        return

    from anubis_apm.storage.auth import make_s3_client  # noqa: PLC0415

    console.print("  [dim]Checking S3 credentials...[/]", end="\r")
    client = make_s3_client()
    if client:
        console.print("  [green]✓[/] S3 experience store configured                ")
    elif _is_aws_vault_available() and _has_sso_profile():
        console.print(
            "  [dim]○ S3 sync unavailable[/] [dim](auth failed — run 'dd-apm sync setup --fix')[/]"
        )
    else:
        console.print(
            "  [dim]○ S3 sync unavailable[/] [dim](run 'dd-apm sync setup --fix' to enable)[/]"
        )


# ---------------------------------------------------------------------------
# Helpers used by should_run_fn
# ---------------------------------------------------------------------------


def is_sync_disabled(args=None) -> bool:
    """Return True if S3 sync should be skipped entirely.

    Sync is disabled when --skip-sync is passed OR DD_APM_SKIP_SYNC=1 is set.
    This allows non-technical users (PMs, etc.) to opt out via env var without
    seeing any S3/AWS-related messages.
    """
    if getattr(args, "skip_sync", False):
        return True
    return os.environ.get("DD_APM_SKIP_SYNC", "").lower() in ("1", "true", "yes")


def _tracing_disabled() -> bool:
    return os.environ.get("DD_TRACE_ENABLED", "").lower() in ("0", "false")


def _mock_mode_no_tracing() -> bool:
    """Return True when running with a mock agent and tracing disabled.

    In this mode no LLM calls are made (no ANTHROPIC_API_KEY needed) and
    no traces are emitted (no DD_API_KEY / DD_APP_KEY needed), so the
    api-keys preflight check can be skipped.
    """
    mock_active = os.environ.get("DD_APM_MOCK_AGENTS", "").lower() in ("1", "true", "yes")
    return mock_active and _tracing_disabled()


# ---------------------------------------------------------------------------
# Manifest — the single source of truth for preflight checks
# ---------------------------------------------------------------------------

PREFLIGHT_CHECKS: list[PreflightCheck] = [
    PreflightCheck(
        name="config",
        description="Config health: default_repository must have a valid APM adapter and exist on disk",
        check_fn=_preflight_config,
    ),
    PreflightCheck(
        name="api-keys",
        description="Required API keys: ANTHROPIC_API_KEY, DD_API_KEY, DD_APP_KEY",
        check_fn=_preflight_api_keys,
        should_run_fn=lambda args: not _mock_mode_no_tracing(),
    ),
    PreflightCheck(
        name="local-agents",
        description="Org 2 credentials, Docker agents, and tracing port verification",
        check_fn=_preflight_local_agents,
        should_run_fn=lambda args: not _tracing_disabled(),
    ),
    PreflightCheck(
        name="s3-sync",
        description="S3 experience store credential probe",
        check_fn=_preflight_s3_sync,
        should_run_fn=lambda args: not is_sync_disabled(args),
    ),
]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run_preflight(args) -> None:
    """Run all preflight checks before a workflow starts, then initialise tracing.

    Raises PreflightError on any hard failure. Called by the
    ``@workflow_command`` decorator before handing off to the command function.

    Tracing is initialised at the end so the ddtrace writer only starts after
    Docker agents are confirmed healthy — avoids dropped-trace noise during a
    stale-credentials restart.
    """
    console.print()
    console.rule("[dim]Preflight[/]", style="dim")
    console.print()

    for check in PREFLIGHT_CHECKS:
        if check.should_run(args):
            check.run(args)

    if getattr(args, "fresh", False):
        integration = getattr(args, "integration", None)
        if integration:
            clear_state(integration, None, getattr(args, "repository", None))
        console.print(f"  [green]✓[/] Workflow state reset [dim](--fresh)[/]")

    # Infrastructure confirmed healthy — now safe to start the tracer.
    import ddtrace.auto  # noqa: PLC0415, F401

    from anubis.core.tracing import init_tracing  # noqa: PLC0415

    init_tracing()
