"""Background version check against GitHub releases.

Starts a daemon thread at CLI startup to avoid blocking the command.
The result is cached for 24 hours so the API is not called on every invocation.
"""

from __future__ import annotations

import json
import logging
import threading
import time
import urllib.request
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_RELEASES_URL = "https://api.github.com/repos/DataDog/apm-instrumentation-toolkit/releases/latest"
_CACHE_FILE = Path.home() / ".dd-apm" / "update-check.json"
_CACHE_TTL_SECONDS = 86400  # 24 hours
_FETCH_TIMEOUT_SECONDS = 5
_WAIT_TIMEOUT_SECONDS = 2  # max time check_and_warn() blocks at command end

_result: dict = {"latest": None, "done": False}
_thread: Optional[threading.Thread] = None


def _current_version() -> Optional[str]:
    try:
        return _pkg_version("dd-apm-integration-ai-toolkit")
    except PackageNotFoundError:
        # Editable installs in some environments don't register the package
        # metadata. Skip the update check rather than warn the user; this is
        # expected control flow, not a runtime error.
        logger.debug("dd-apm package metadata not found, skipping update check")
        return None


def _parse_semver(v: str) -> tuple[int, ...]:
    """Parse 'v1.2.3' or '1.2.3' into a comparable int tuple. Ignores pre-release suffix."""
    core = v.lstrip("v").split("-")[0]
    try:
        return tuple(int(x) for x in core.split("."))
    except ValueError:
        return (0,)


def _load_cache() -> Optional[dict[str, object]]:
    try:
        if _CACHE_FILE.exists():
            data: dict[str, object] = json.loads(_CACHE_FILE.read_text())
            checked_at = data.get("checked_at", 0)
            if (
                isinstance(checked_at, (int, float))
                and time.time() - checked_at < _CACHE_TTL_SECONDS
            ):
                return data
    except Exception as e:
        # Cache corruption or unreadable file — fall through to refetch. Best-effort
        # cache, never want to fail the user-facing command on a cache I/O issue.
        logger.debug("Update-check cache load failed, refetching: %s", e)
    return None


def _save_cache(latest: Optional[str]) -> None:
    try:
        _CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _CACHE_FILE.write_text(json.dumps({"checked_at": time.time(), "latest": latest}))
    except Exception as e:
        # Best-effort cache write — tolerate read-only FS, permission issues, etc.
        logger.debug("Update-check cache save failed: %s", e)


def _fetch_latest_stable() -> Optional[str]:
    """Return the latest non-prerelease tag from GitHub, or None on any error."""
    try:
        req = urllib.request.Request(_RELEASES_URL, headers={"User-Agent": "dd-apm-toolkit"})
        with urllib.request.urlopen(req, timeout=_FETCH_TIMEOUT_SECONDS) as resp:
            data = json.loads(resp.read())
        if data.get("prerelease"):
            return None
        tag = data.get("tag_name", "").lstrip("v")
        return tag or None
    except Exception as exc:
        logger.debug("Update check fetch failed: %s", exc)
        return None


def start_check() -> None:
    """Kick off a background version check. Call once at CLI startup."""
    global _thread

    cached = _load_cache()
    if cached is not None:
        _result["latest"] = cached.get("latest")
        _result["done"] = True
        return

    def _run() -> None:
        latest = _fetch_latest_stable()
        _save_cache(latest)
        _result["latest"] = latest
        _result["done"] = True

    _thread = threading.Thread(target=_run, daemon=True, name="dd-apm-update-check")
    _thread.start()


def check_and_warn() -> None:
    """Print a one-line warning if a newer stable release exists.

    Waits up to _WAIT_TIMEOUT_SECONDS for the background thread to finish.
    Silently skips if the check didn't complete in time or if the current
    install is a pre-release (rc/dev builds are ahead of the stable channel).
    """
    if _thread and _thread.is_alive():
        _thread.join(timeout=_WAIT_TIMEOUT_SECONDS)

    if not _result["done"]:
        return

    latest = _result.get("latest")
    if not latest:
        return

    current = _current_version()
    if not current:
        return

    # Pre-release installs (rc, dev) are ahead of the stable channel — skip.
    if "-" in current:
        return

    if _parse_semver(latest) > _parse_semver(current):
        from .console import console  # noqa: PLC0415

        console.print(
            f"\n  [yellow]A new version of dd-apm is available:[/] "
            f"[dim]{current}[/] → [cyan]{latest}[/]"
            f"  [dim]Run [cyan]dd-apm update[/] to upgrade.[/]"
        )
