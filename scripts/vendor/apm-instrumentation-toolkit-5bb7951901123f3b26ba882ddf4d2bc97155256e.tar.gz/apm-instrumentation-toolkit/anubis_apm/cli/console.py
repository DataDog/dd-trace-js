"""Shared Rich console and output helpers."""

from rich.console import Console
from rich.table import Table

console = Console()


def print_header(title: str) -> None:
    """Print a styled header with blue rule."""
    console.print()
    console.rule(f"[bold blue]{title}[/]", style="blue")
    console.print()


def print_success(message: str) -> None:
    """Print a success footer with green rule."""
    console.rule(f"[bold green]{message}[/]", style="green")


def print_error(message: str) -> None:
    """Print an error message in red."""
    console.print(f"[red]Error:[/] {message}")


def print_cancelled(command: str, integration: str, *, full_hint: str | None = None) -> None:
    """Print cancellation message with resume hint."""
    console.print(f"\n[yellow]{command.title()} cancelled[/]")
    resume = full_hint or f"{command} {integration}"
    console.print(f"   Resume with: [cyan]dd-apm {resume}[/]")
    console.print()


def print_mode_info(mode: str | None, headless: bool, prompt: str | None) -> None:
    """Print mode and guidance information."""
    if headless:
        console.print("[dim]Mode:[/] [cyan]headless[/] - no user interaction.")
    elif mode == "guided":
        console.print(
            "[dim]Mode:[/] [cyan]guided[/] - you'll review analysis and make selections interactively."
        )
        console.print("[dim]Press Ctrl+C at any time to pause.[/]")
    elif mode == "agent":
        console.print(
            "[dim]Mode:[/] [cyan]agent[/] - fully autonomous, no user interaction needed."
        )
        console.print("[dim]Press Ctrl+C to stop.[/]")

    if prompt:
        console.print(f"[dim]Guidance:[/] [cyan]{prompt}[/]")

    console.print()


def create_table(title: str) -> Table:
    """Create a Rich table with consistent styling."""
    return Table(title=title)
