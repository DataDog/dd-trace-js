"""Entry point for the PyInstaller frozen binary (dd-apm.spec entrypoint).

Sets two env vars before any imports so the app knows where to find things:
  ANUBIS_RESOURCES_ROOT — sys._MEIPASS (read-only bundled files: prompts, skills, etc.)
  ANUBIS_TOOLKIT_ROOT   — ~/.dd-apm/  (user-writable: config, .env, .analysis/)

Also temporarily silences fd 2 during imports to suppress ddtrace's import-time
stderr noise (C extension load failures, OTEL warnings) which appear before any
app code runs and cannot be suppressed via Python logging alone.
"""

import os
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    _meipass = Path(sys._MEIPASS)  # type: ignore[attr-defined]
    os.environ.setdefault("ANUBIS_RESOURCES_ROOT", str(_meipass))

    _data_dir = Path.home() / ".dd-apm"
    try:
        _data_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        print(f"Warning: could not create {_data_dir}: {e}", file=sys.stderr)
    os.environ.setdefault("ANUBIS_TOOLKIT_ROOT", str(_data_dir))

# Enrich PATH with common tool locations (Homebrew, user bins) so dd-auth,
# aws-vault, docker, etc. are findable even when launched from a bare shell.
_extra_dirs = [
    "/opt/homebrew/bin",
    "/opt/homebrew/sbin",
    os.path.expanduser("~/.local/bin"),
    "/usr/local/bin",
]
_current = os.environ.get("PATH", "")
_current_set = set(_current.split(os.pathsep))
_missing = [d for d in _extra_dirs if d and d not in _current_set and os.path.isdir(d)]
if _missing:
    os.environ["PATH"] = (
        os.pathsep.join([_current] + _missing) if _current else os.pathsep.join(_missing)
    )

# Call init_env BEFORE importing anubis — must run first so DD_TRACE_AGENT_URL
# and DD_API_KEY are set before any ddtrace import.  Tracing itself is deferred
# to run_preflight() so the writer only starts after Docker agents are healthy.
#
# anubis_apm.cli.env only uses stdlib + pyyaml — safe to import before silencing.
from anubis_apm.cli.env import (  # noqa: E402, PLC0415
    ensure_env_defaults,  # pyright: ignore[reportAttributeAccessIssue]
    init_env,
)

if getattr(sys, "frozen", False):
    _toolkit_root = Path(os.environ["ANUBIS_TOOLKIT_ROOT"])
    init_env(_toolkit_root)
    ensure_env_defaults(_toolkit_root / ".anubis" / "config.yaml")

# Silence fd-level stderr during ddtrace import. ddtrace prints warnings about
# missing C extensions and OTEL env vars directly to fd 2, bypassing Python
# logging, so this is the only way to suppress them. Tracing still works —
# this only affects import-time noise, not runtime behavior.
_stderr_bak = os.dup(2)
_devnull = os.open(os.devnull, os.O_WRONLY)
os.dup2(_devnull, 2)
os.close(_devnull)

try:
    from anubis_apm.cli.main import main  # noqa: E402, PLC0415
finally:
    os.dup2(_stderr_bak, 2)
    os.close(_stderr_bak)

if __name__ == "__main__":
    sys.exit(main())
