"""Shared CLI utilities."""

import logging
import os
import shutil
import subprocess
from pathlib import Path

from anubis.core.config import get_config

from .console import console

logger = logging.getLogger(__name__)


def check_gh_auth() -> None:
    """Raise RuntimeError if `gh auth status` fails.

    Call this before running any workflow that uses GitHub CLI
    to fail fast instead of wasting agent turns on an expired token.
    """
    try:
        subprocess.run(
            ["gh", "auth", "status"],
            check=True,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(
            "GitHub CLI (gh) is not installed. Install it: https://cli.github.com"
        ) from exc
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"GitHub auth check failed — run `gh auth login` to fix.\n{exc.stderr.strip()}"
        ) from exc


def normalize_name(name: str) -> str:
    """Normalize integration name for filesystem paths."""
    return name.replace("@", "").replace("/", "-").replace("_", "-")


def _clear_git_state(normalized: str, workflow: str | None, repo_path: Path) -> None:
    """Clear git tags and branches for a workflow.

    Tags follow pattern: apm-ai-toolkit/{workflow}/{namespace}/{timestamp}/{step}
    Branches follow pattern: apm-ai-toolkit/{workflow}/{namespace}/{timestamp}
    """
    if workflow:
        tag_patterns = [f"apm-ai-toolkit/{workflow}/{normalized}/*"]
        branch_patterns = [f"apm-ai-toolkit/{workflow}/{normalized}/*"]
    else:
        tag_patterns = [f"apm-ai-toolkit/*/{normalized}/*"]
        branch_patterns = [f"apm-ai-toolkit/*/{normalized}/*"]

    # Delete matching tags
    try:
        tags: list[str] = []
        for pattern in tag_patterns:
            result = subprocess.run(
                ["git", "tag", "-l", pattern],
                capture_output=True,
                text=True,
                cwd=str(repo_path),
                timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                tags.extend(t for t in result.stdout.strip().split("\n") if t)

        for tag in tags:
            subprocess.run(
                ["git", "tag", "-d", tag],
                capture_output=True,
                cwd=str(repo_path),
                timeout=10,
            )
        if tags:
            logger.debug(f"Cleared {len(tags)} git tags for {normalized}")
    except Exception as e:
        logger.debug(f"Failed to clear git tags: {e}")

    # Delete matching branches
    try:
        branches: list[str] = []
        for pattern in branch_patterns:
            if "*" in pattern:
                result = subprocess.run(
                    ["git", "branch", "--list", pattern],
                    capture_output=True,
                    text=True,
                    cwd=str(repo_path),
                    timeout=10,
                )
                if result.returncode == 0:
                    branches.extend(
                        b.strip().lstrip("* ")
                        for b in result.stdout.strip().split("\n")
                        if b.strip()
                    )
            else:
                branches.append(pattern)

        # Get current branch to avoid deleting it
        current = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True,
            text=True,
            cwd=str(repo_path),
            timeout=10,
        )
        current_branch = current.stdout.strip() if current.returncode == 0 else ""

        for branch in branches:
            if branch and branch != current_branch:
                subprocess.run(
                    ["git", "branch", "-D", branch],
                    capture_output=True,
                    cwd=str(repo_path),
                    timeout=10,
                )
        if branches:
            logger.debug(f"Cleared git branches for {normalized}")
    except Exception as e:
        logger.debug(f"Failed to clear git branches: {e}")


def clear_state(
    integration: str, workflow: str | None = None, repository: str | None = None
) -> None:
    """Clear workflow state: analysis directory, git tags, and git branches."""
    config = get_config()
    normalized = normalize_name(integration)

    # State directory uses the raw namespace (e.g. "@langchain/langgraph"),
    # not the normalized form. Try both to be safe.
    analysis_root = config.get_analysis_root(repository)
    for name in (integration, normalized):
        base = analysis_root / name
        target = base / workflow if workflow else base
        if target.exists():
            shutil.rmtree(target)

    # Git tags/branches use the normalized name
    repo_path = config.get_repo_root(repository)
    _clear_git_state(normalized, workflow, repo_path)


_PHASE_TO_STEPS: dict[str, list[str]] = {
    "analyze": ["analyze"],
    "review": ["review"],
    "sample-app": ["generate_app", "validate_app"],
    "context-capture": ["context_mapping"],
    "compile": ["compile"],
    "test": ["test"],
    "features": ["feature"],
    "reviewer": ["reviewer"],
    "plan": ["plan"],
    "plan_review": ["plan_review"],
    "implement": ["implement"],
}


def parse_skip_phases(skip_arg: str | None) -> list[str]:
    """Parse and validate --skip argument, returning step names for the workflow."""
    if not skip_arg:
        return []

    valid_phases = set(_PHASE_TO_STEPS.keys())
    phases = [p.strip().lower() for p in skip_arg.split(",")]

    invalid = set(phases) - valid_phases
    if invalid:
        console.print(f"[yellow]Warning: Unknown phases to skip: {', '.join(invalid)}[/]")
        console.print(f"[dim]Valid phases: {', '.join(sorted(valid_phases))}[/]")

    step_names = []
    for p in phases:
        if p in _PHASE_TO_STEPS:
            step_names.extend(_PHASE_TO_STEPS[p])
    return step_names


# Analyze workflow step names (from anubis_apm/workflows/analyze/steps.py)
_ANALYZE_STEPS = {
    "install_package",
    "all_methods",
    "docs_collection",
    "agent_analysis",
    "metadata_enrichment",
}


def parse_analyze_skip_steps(skip_arg: str | None) -> list[str]:
    """Parse and validate --skip argument for the analyze workflow.

    Unlike parse_skip_phases (which validates against create-workflow phases),
    this validates against the actual analyze workflow step names.
    """
    if not skip_arg:
        return []

    steps = [s.strip().lower() for s in skip_arg.split(",")]

    invalid = set(steps) - _ANALYZE_STEPS
    if invalid:
        console.print(f"[yellow]Warning: Unknown analyze steps to skip: {', '.join(invalid)}[/]")
        console.print(f"[dim]Valid steps: {', '.join(sorted(_ANALYZE_STEPS))}[/]")

    return [s for s in steps if s in _ANALYZE_STEPS]


def add_common_args(parser) -> None:
    """Add runtime arguments shared by ALL workflow commands (no integration arg).

    Use this for commands that don't take a positional integration argument
    (e.g., ``dd-apm feedback``). For commands that need ``integration``, use
    :func:`add_workflow_args` instead — it calls this internally.
    """
    try:
        default_repo = get_config().default_repository
    except Exception:
        default_repo = "dd_trace_js"
    parser.add_argument("--repository", "-r", default=default_repo, help="Repository")
    parser.add_argument("--headless", action="store_true", help="Run without user interaction")
    parser.add_argument("--prompt", type=str, default=None, help="Custom guidance for the agent")
    parser.add_argument(
        "--max-cost",
        dest="max_cost_usd",
        type=float,
        default=None,
        metavar="USD",
        help="Per-agent cost limit in USD. At 80%% a warning is injected; at 100%% the agent is aborted.",
    )
    parser.add_argument("--fresh", action="store_true", help="Clear existing state before running")
    parser.add_argument(
        "--from",
        dest="from_step",
        help="Resume from a specific step. Rewinds workflow state only — files on disk are untouched.",
    )
    parser.add_argument(
        "--rollback-git",
        action="store_true",
        help=(
            "Pair with --from: also reset the target repo's working tree to the git snapshot taken "
            "at the start of <step>, so the re-run sees a clean slate. Use when a later step wrote "
            "files you don't want to inherit, or when the earlier step is non-idempotent against "
            "existing edits."
        ),
    )
    parser.add_argument(
        "--skip", type=str, default=None, help="Comma-separated list of steps to skip"
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="Model override for agent steps (e.g., opus, sonnet)",
    )
    parser.add_argument(
        "--base-branch",
        type=str,
        default=os.environ.get("DD_APM_BASE_BRANCH"),
        help="Base branch in target repo (default: auto-detect main/master, env: DD_APM_BASE_BRANCH)",
    )
    parser.add_argument(
        "--experience",
        action="store_true",
        help="Inject experience from past runs into agent prompts (experimental)",
    )
    parser.add_argument(
        "--skip-sync",
        action="store_true",
        dest="skip_sync",
        help="Skip S3 push/pull of run artifacts",
    )
    parser.add_argument(
        "--workspace",
        nargs="?",
        const=True,
        default=None,
        metavar="NAME",
        help=(
            "Run in a remote Datadog workspace. "
            "Optionally provide a workspace name (auto-generated if omitted)"
        ),
    )
    parser.add_argument(
        "--maven-coords",
        type=str,
        default=None,
        help="Maven coordinates for Java (group:artifact:version, e.g., 'redis.clients:jedis:1.4.0')",
    )
    parser.add_argument(
        "--stop-after",
        dest="stop_after",
        type=str,
        default=None,
        help="Stop the workflow after the named step completes (e.g. --stop-after compile)",
    )


def add_workflow_args(parser, *, require_integration: bool = True) -> None:
    """Add common arguments shared by ALL workflow commands.

    Args:
        parser: argparse parser to add arguments to
        require_integration: If True (default), integration is a required positional arg.
            If False, it's optional with default None.
    """
    if require_integration:
        parser.add_argument("integration", help="Integration name")
    else:
        parser.add_argument(
            "integration", nargs="?", default="sample-app", help="Integration name (optional)"
        )
    add_common_args(parser)


def add_spec_arg(parser, *, required: bool = True) -> None:
    """Add the ``--spec`` argument used by spec-driven workflows.

    Spec input is a generic concept (``TaskSpec`` lives in
    ``anubis.core.resources.spec``) and is expected to feed any workflow
    that operates on a task description — execute today, plus any future
    spec-driven workflow. Keeping the argument definition in one place
    means a new spec-consuming workflow just calls ``add_spec_arg(parser)``
    instead of redefining the flag inline (which is how it was when only
    execute consumed it).
    """
    parser.add_argument(
        "--spec",
        required=required,
        help="Task spec: file path, inline text, or '-' for stdin",
    )


def add_source_arg(parser) -> None:
    """Add the ``--source`` argument for dynamic context.

    See ``TaskSpec.from_dynamic_source`` for accepted input formats
    (GitHub issue/PR URL, Actions job URL, file, stdin, inline text).

    Named ``--source`` (not ``--from``) because ``--from`` is already the
    resume-from-step flag and overloading it would be confusing.
    """
    parser.add_argument(
        "--source",
        dest="source",
        default=None,
        help=(
            "Dynamic context: GitHub issue/PR URL, GitHub Actions "
            "failed-job URL, file path, inline text, or '-' for stdin. "
            "Merged with --spec when both are passed."
        ),
    )


def get_toolkit_root() -> Path:
    """Get the toolkit root directory."""
    return Path(__file__).parent.parent.parent


def _resolve_repo_dir(repository: str | None = None) -> Path | None:
    """Resolve the target repository directory.

    Priority order:
    1. Per-worktree config (.anubis/config.yaml) — most specific, wins
    2. DD_TRACER_REPO env var — explicit per-command override
    3. None if neither is available
    """
    try:
        config = get_config()
        return config.get_repo_root(repository)
    except Exception as e:
        logger.debug("get_config() failed for repo root lookup: %s", e)

    repo_path = os.environ.get("DD_TRACER_REPO")
    if repo_path:
        return Path(repo_path)

    return None
