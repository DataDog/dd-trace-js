"""CLI package for dd-apm command.

Note: This __init__.py intentionally has no eager imports. Importing
submodules like ``main`` would trigger the full CLI import chain which
pulls in ddtrace before env vars are set by the entry point (bin/dd-apm).

Use direct imports instead::

    from anubis_apm.cli.main import main
    from anubis_apm.cli.console import console
"""
