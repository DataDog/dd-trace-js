"""CLI decorators for common command patterns."""

import logging
import os
from functools import wraps
from pathlib import Path
from typing import Callable, TypeVar

from anubis.core.config import ConfigLoader, get_config
from anubis.core.state.models import WorkflowState
from anubis.core.tracing import shutdown_tracing
from anubis_apm import setup
from anubis_apm.storage.workflow_hooks import push_run_to_s3

from .console import console, print_cancelled
from .preflight import PreflightError, is_sync_disabled, run_preflight

F = TypeVar("F", bound=Callable)
logger = logging.getLogger(__name__)


def _normalize_repository(args) -> None:
    """Normalize repository name (hyphens to underscores) if present."""
    if hasattr(args, "repository") and args.repository:
        args.repository = args.repository.replace("-", "_")


def _ensure_analysis_symlink(repository: str) -> None:
    """Create convenience symlink: toolkit_root/.analysis/{repo}/ -> repo's .analysis/.

    Gives a single browsing point for all repos' analysis state without
    changing where state is actually stored.
    """
    try:
        config = get_config()
        repo_analysis = config.get_analysis_root(repository)
        repo_short = repository.replace("_", "-")
        toolkit_link = config.toolkit_root / ".analysis" / repo_short

        if toolkit_link.is_symlink() or toolkit_link.exists():
            return

        toolkit_link.parent.mkdir(parents=True, exist_ok=True)
        toolkit_link.symlink_to(repo_analysis)
    except Exception as exc:
        logger.debug("Could not create analysis symlink: %s", exc)


def with_config(func: F) -> F:
    """Ensure config exists and initialize APM before running command."""

    @wraps(func)
    def wrapper(args):
        loader = ConfigLoader()
        if loader.needs_init():
            console.print("[yellow]Workspace not initialized.[/]")
            console.print("Run [cyan]dd-apm config init[/] to get started.")
            return 1

        # Frozen binary: also require docker-compose.yml which config init installs.
        # Guards against old source-installs that have config.yaml but haven't gone
        # through the new binary's config init flow.
        if os.environ.get("ANUBIS_RESOURCES_ROOT"):
            if not (loader.toolkit_root / "docker-compose.yml").exists():
                console.print("[yellow]Workspace setup incomplete.[/]")
                console.print("Run [cyan]dd-apm config init[/] to complete setup.")
                return 1

        _normalize_repository(args)
        setup.init()

        # Validate requested repository exists in config before any workflow runs.
        repository = getattr(args, "repository", None)
        if repository:
            try:
                get_config().get_repo(repository)
            except KeyError as exc:
                console.print(f"[red]{exc}[/]")
                return 1

        # Create .analysis/ symlink for this repo (one-time, best-effort)
        repository = repository or get_config().default_repository
        _ensure_analysis_symlink(repository)

        return func(args)

    return wrapper  # type: ignore[return-value]


def _run_post_sync(args, exit_code: int, workflow_type: str) -> None:
    """Push the completed run to S3 after workflow finishes.

    Reads state from disk (already flushed by the workflow), builds a manifest,
    and uploads in a background thread. Skipped when sync is disabled.
    Failures are logged at debug level only — no user-visible noise.
    Exit code 0 = completed, non-zero = failed.
    """
    if is_sync_disabled(args):
        return

    namespace = getattr(args, "integration", None)
    repository = getattr(args, "repository", None) or "dd_trace_js"
    wf_name = workflow_type

    if not namespace:
        return

    try:
        config = get_config()
        base_dir: Path = config.get_repo_root(repository)
        state = WorkflowState.load(wf_name, namespace, base_dir)
        if state is None:
            return

        analysis_dir = state.root(base_dir)
        push_run_to_s3(
            analysis_dir=analysis_dir,
            state=state,
            namespace=namespace,
            repository=repository,
            workflow_name=wf_name,
            repo_dir=base_dir,
            success=exit_code == 0,
            category=state.data.get("_category"),
            language=state.data.get("_language", ""),
        )
        status = "completed" if exit_code == 0 else "failed"
        logger.debug("Run %s (%s) synced to S3", state.run_id, status)
    except Exception as exc:
        logger.debug("Post-sync failed (non-fatal): %s", exc)


def _run_in_workspace(args, command_name: str) -> int:
    """Intercept a workflow command and run it in a remote workspace."""
    from anubis.workspace.orchestrator import run_in_workspace  # noqa: PLC0415
    from anubis_apm.repo_adapters._repos import get_repo_def  # noqa: PLC0415

    workspace_arg = args.workspace
    workspace_name = workspace_arg if isinstance(workspace_arg, str) else None

    repository = getattr(args, "repository", None)
    repo_clone_url: str | None = None
    repo_branch: str | None = None
    repo_language: str = "node"
    if repository:
        repo_def = get_repo_def(repository)
        if repo_def:
            repo_clone_url = f"https://github.com/{repo_def.github_repo}.git"
            repo_branch = repo_def.default_branch
            repo_language = repo_def.language

    # Reconstruct command args from the full argparse namespace so workflow-
    # specific flags (--fix, --max-fix-iterations, --blind, --spec, etc.) are
    # forwarded transparently instead of being silently dropped.
    remote_args: list[str] = []
    integration = getattr(args, "integration", None)
    if integration:
        remote_args.append(integration)

    _SKIP_ARGS = frozenset({
        "handler",
        "workspace",
        "repository",
        "integration",
        "skip_sync",
        "skip_eval",
    })
    _RENAMED_ARGS = {"from_step": "from", "stop_after": "stop-after"}

    for key, val in vars(args).items():
        if key in _SKIP_ARGS or val is None:
            continue
        cli_flag = f"--{_RENAMED_ARGS.get(key, key).replace('_', '-')}"
        if isinstance(val, bool):
            if val:
                remote_args.append(cli_flag)
        else:
            remote_args.extend([cli_flag, str(val)])

    toolkit_root_path = Path(os.environ.get("ANUBIS_TOOLKIT_ROOT", "")).resolve()
    toolkit_root: Path | None = toolkit_root_path if toolkit_root_path.exists() else None

    console.print("[bold]Running in workspace...[/]")
    console.print()

    def _status(msg: str) -> None:
        console.print(f"  [dim]{msg}[/]")

    try:
        result = run_in_workspace(
            command=command_name,
            command_args=remote_args,
            workspace_name=workspace_name,
            repository=repository,
            repo_clone_url=repo_clone_url,
            repo_branch=repo_branch,
            repo_language=repo_language,
            toolkit_root=toolkit_root,
            stream=True,
            on_status=_status,
        )
    except RuntimeError as exc:
        console.print(f"  [red]Error:[/] {exc}")
        return 1

    if result.branch_pushed:
        console.print()
        console.print(f"[green]Results pushed to branch:[/] {result.branch_pushed}")
        console.print(f"  Run: git checkout {result.branch_pushed}")

    return result.exit_code


def workflow_command(name: str, workflow_type: str | None = None, resume_hint: str | None = None):
    """Decorator for workflow commands with common handling.

    Provides:
    - Config verification and APM initialization (via @with_config)
    - Docker agent startup and tracing preflight checks
    - --fresh state clearing
    - KeyboardInterrupt handling with graceful shutdown and resume hint
    - Automatic post-workflow eval (CI-safe checks, skippable with --skip-eval)
    - Tracing shutdown
    - Post-workflow S3 sync (always on unless --skip-sync)
    - --workspace: transparent remote execution in a Datadog workspace
    """
    # workflow_type overrides name for state lookup; fall back to the command name
    # which matches the workflow's state directory (e.g. "lint", "test").
    effective_workflow_type = workflow_type or name

    def decorator(func: F) -> F:
        @wraps(func)
        @with_config
        def wrapper(args):
            # Workspace mode: delegate entirely to remote execution
            if getattr(args, "workspace", None) is not None:
                return _run_in_workspace(args, name)

            try:
                run_preflight(args)
            except PreflightError as exc:
                console.print(f"  [red]✗[/] {exc}")
                shutdown_tracing()
                return 1

            exit_code = 1
            try:
                exit_code = func(args)
            except KeyboardInterrupt:
                print_cancelled(
                    name,
                    getattr(args, "integration", None) or name,
                    full_hint=resume_hint,
                )
                exit_code = 130  # standard SIGINT exit code
            finally:
                shutdown_tracing()

            _run_post_sync(args, exit_code or 0, effective_workflow_type)
            return exit_code

        return wrapper  # type: ignore[return-value]

    return decorator
