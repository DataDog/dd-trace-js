"""Shared filesystem path constants for anubis_apm."""

from pathlib import Path

# Root of the anubis_apm package
_PKG_ROOT = Path(__file__).resolve().parent.parent

# Eval datasets (ground truths, fixtures) live here
DATASETS_DIR = _PKG_ROOT / "eval" / "datasets"
