"""Package name normalization utilities.

Used across workflows to normalize npm package names to file-safe formats
that match dd-trace-js instrumentation and plugin naming conventions.
Also provides generic slugification helpers for filesystem and dataset lookups.
"""


def normalize_package_name(package_name: str) -> str:
    """Normalize package name to file-safe format.

    Converts npm package names to the format used by dd-trace-js for
    instrumentation files and plugin directories.

    Examples:
        '@anthropic-ai/sdk' -> 'anthropic'
        '@openai/openai' -> 'openai'
        'cohere-ai' -> 'cohere'
        '@langchain/langgraph' -> 'langchain-langgraph'
        '@langchain/core' -> 'langchain'

    Args:
        package_name: NPM package name (e.g., '@scope/name' or 'name')

    Returns:
        Normalized name suitable for file paths and plugin directories.
    """
    # Handle scoped packages: @scope/name -> scope-name (for most)
    if package_name.startswith("@"):
        parts = package_name[1:].split("/")
        if len(parts) == 2:
            scope, name = parts

            # Special cases where scope IS the package (e.g., @langchain/core -> langchain)
            if name in ("core", "sdk"):
                name = scope

            # For sub-packages like @langchain/langgraph -> langchain-langgraph
            elif scope != name:
                # But not for @anthropic-ai/sdk -> anthropic (sdk is generic)
                if name not in ("sdk",):
                    name = f"{scope}-{name}"

            # Clean up scope-related suffixes
            name = name.replace("-ai", "").strip("-")

            # Known mappings that override the above
            known_mappings = {
                "anthropic": "anthropic",
                "openai": "openai",
                "cohere": "cohere",
            }

            for key, value in known_mappings.items():
                if key in name:
                    return value

            return name.lower()

    # Non-scoped packages
    name = package_name

    # Common transformations
    transformations = {
        "sdk": "",  # Remove generic 'sdk'
        "-ai": "",  # Remove '-ai' suffix
    }

    for old, new in transformations.items():
        name = name.replace(old, new)

    # Clean up
    name = name.strip("-").lower()

    # Handle known mappings
    known_mappings = {
        "anthropic": "anthropic",
        "openai": "openai",
        "cohere": "cohere",
    }

    for key, value in known_mappings.items():
        if key in name:
            return value

    return name


def slugify_package_name(package: str) -> str:
    """Slugify a package name for filesystem lookups.

    Simple character replacement — strips scope markers and normalizes
    separators so that ``@scope/my_pkg`` and ``my-pkg`` resolve to the
    same directory name.

    Not the same as ``normalize_package_name``, which applies semantic
    JS-specific mappings for dd-trace plugin dirs.
    """
    return package.replace("@", "").replace("/", "-").replace("_", "-").lower()


def bare_package_name(package: str) -> str:
    """Extract the bare package name for identity matching.

    Strips scope prefix and normalizes separators:
    ``@scope/my_pkg`` → ``my-pkg``, ``my_pkg`` → ``my-pkg``.
    """
    return package.lstrip("@").rsplit("/", maxsplit=1)[-1].replace("_", "-").lower()
