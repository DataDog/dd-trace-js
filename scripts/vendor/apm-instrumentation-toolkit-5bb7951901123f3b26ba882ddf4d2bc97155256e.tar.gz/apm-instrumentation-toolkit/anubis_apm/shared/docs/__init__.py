"""Documentation collection utilities."""

from .collector import DocumentationCollector

__all__ = ["DocumentationCollector"]
