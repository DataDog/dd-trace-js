"""
Python Documentation Fetcher
Orchestrates fetching documentation from PyPI, GitHub, and type stubs
"""

from typing import TYPE_CHECKING, Any, Dict, Tuple

from anubis_apm.shared.docs.collectors.dd_trace_py.pypi_registry import fetch_from_pypi
from anubis_apm.shared.docs.collectors.dd_trace_py.type_stubs import fetch_type_stubs
from anubis_apm.shared.docs.collectors.general.github import fetch_from_github

if TYPE_CHECKING:
    from anubis.core.output.emitter import EventEmitter


def fetch_python_docs(
    package_name: str, results: Dict[str, Any], emitter: "EventEmitter"
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Fetch documentation for a Python package

    Args:
        package_name: Name of the PyPI package
        results: Results dict to populate
        emitter: Event emitter for output

    Returns:
        Tuple of (pypi_data, github_data)
    """
    # 1. Fetch from PyPI registry
    pypi_data = fetch_from_pypi(package_name, emitter)
    results["sources"]["pypi"] = pypi_data

    if "error" in pypi_data:
        emitter.emit("error", message=f"PyPI: {pypi_data['error']}")
        # Return empty github_data on PyPI error
        return pypi_data, {"error": "PyPI fetch failed", "source": "github"}

    emitter.emit("success", message=f"Found version {pypi_data.get('version')}")

    # 2. Fetch from GitHub
    emitter.emit("step_start", step="Fetching from GitHub")
    repo_info = pypi_data.get("repository")
    repo_url = repo_info.get("url") if repo_info else None

    if repo_url:
        github_data = fetch_from_github(repo_url)
        results["sources"]["github"] = github_data

        if "error" not in github_data:
            readme = github_data.get("readme")
            docs = github_data.get("docs")
            examples = github_data.get("examples")
            emitter.emit("info", message=f"README: {'Found' if readme else 'Not found'}")
            emitter.emit("info", message=f"Docs folder: {'Found' if docs else 'Not found'}")
            emitter.emit("info", message=f"Examples folder: {'Found' if examples else 'Not found'}")
        else:
            emitter.emit("error", message=f"GitHub: {github_data['error']}")
    else:
        emitter.emit("warn", message="No repository URL found")
        github_data = {"error": "No repository URL", "source": "github"}
        results["sources"]["github"] = github_data

    # 3. Check for type stubs
    emitter.emit("step_start", step="Checking Python type stubs")
    stubs_data = fetch_type_stubs(package_name, pypi_data)
    results["sources"]["type_stubs"] = stubs_data

    if stubs_data["has_types"]:
        emitter.emit("success", message=f"Types found (source: {stubs_data['source']})")
    else:
        emitter.emit("info", message="No type stubs found")

    return pypi_data, github_data
