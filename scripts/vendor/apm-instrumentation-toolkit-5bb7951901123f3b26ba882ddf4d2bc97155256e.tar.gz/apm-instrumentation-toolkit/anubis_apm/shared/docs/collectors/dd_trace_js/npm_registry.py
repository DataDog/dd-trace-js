"""
NPM Registry Fetcher
Fetches package metadata, README, and repository info from npm registry
"""

from typing import TYPE_CHECKING, Any, Dict

import requests

if TYPE_CHECKING:
    from anubis.core.output.emitter import EventEmitter


def fetch_from_npm(package_name: str, emitter: "EventEmitter") -> Dict[str, Any]:
    """
    Fetch package information from npm registry

    Args:
        package_name: Name of the npm package (e.g., '@confluentinc/kafka-javascript')
        emitter: Event emitter for output

    Returns:
        Dictionary containing package metadata, README, and repository info
    """
    url = f"https://registry.npmjs.org/{package_name}"

    try:
        emitter.emit("step_start", step="Fetching from npm registry")

        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        latest = data.get("dist-tags", {}).get("latest")
        if not latest:
            return {"error": "No latest version found", "source": "npm-registry"}

        latest_version = data.get("versions", {}).get(latest, {})

        return {
            "name": data.get("name"),
            "version": latest,
            "description": data.get("description"),
            "homepage": data.get("homepage"),
            "repository": data.get("repository"),
            "readme": data.get("readme"),
            "keywords": data.get("keywords", []),
            "license": data.get("license"),
            "dependencies": latest_version.get("dependencies", {}),
            "main": latest_version.get("main"),
            "types": latest_version.get("types") or latest_version.get("typings"),
            "exports": latest_version.get("exports"),
            "source": "npm-registry",
        }

    except requests.exceptions.RequestException as e:
        return {"error": str(e), "source": "npm-registry"}
