"""
PyPI Registry Fetcher
Fetches package metadata, README, and repository info from PyPI
"""

from typing import TYPE_CHECKING, Any, Dict

import requests

if TYPE_CHECKING:
    from anubis.core.output.emitter import EventEmitter


def fetch_from_pypi(package_name: str, emitter: "EventEmitter") -> Dict[str, Any]:
    """
    Fetch package information from PyPI registry

    Args:
        package_name: Name of the PyPI package (e.g., 'requests', 'flask')
        emitter: Event emitter for output

    Returns:
        Dictionary containing package metadata, README, and repository info
    """
    url = f"https://pypi.org/pypi/{package_name}/json"

    try:
        emitter.emit("step_start", step="Fetching from PyPI registry")

        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        info = data.get("info", {})

        # Extract repository URL from project_urls or home_page
        repository = None
        project_urls = info.get("project_urls") or {}
        for key in ["Source", "Repository", "GitHub", "Code", "Source Code"]:
            if key in project_urls:
                repository = project_urls[key]
                break
        if not repository:
            # Try home_page if it looks like a repo
            home_page = info.get("home_page", "")
            if home_page and ("github.com" in home_page or "gitlab.com" in home_page):
                repository = home_page

        # Extract documentation URL
        docs_url = None
        for key in ["Documentation", "Docs", "Homepage"]:
            if key in project_urls:
                docs_url = project_urls[key]
                break

        # Get dependency info
        dependencies = info.get("requires_dist", []) or []

        return {
            "name": info.get("name"),
            "version": info.get("version"),
            "description": info.get("summary"),
            "homepage": info.get("home_page") or docs_url,
            "repository": {"url": repository} if repository else None,
            "readme": info.get("description"),  # PyPI stores full description here
            "readme_content_type": info.get("description_content_type"),
            "keywords": info.get("keywords", "").split(",") if info.get("keywords") else [],
            "license": info.get("license"),
            "dependencies": dependencies,
            "requires_python": info.get("requires_python"),
            "author": info.get("author"),
            "author_email": info.get("author_email"),
            "classifiers": info.get("classifiers", []),
            "project_urls": project_urls,
            "package_url": info.get("package_url"),
            "release_url": info.get("release_url"),
            "source": "pypi-registry",
        }

    except requests.exceptions.RequestException as e:
        return {"error": str(e), "source": "pypi-registry"}
