"""
GitHub Repository Fetcher
Fetches README, examples, and docs from GitHub repositories
"""

import base64
import logging
import re
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


def fetch_from_github(repo_url: Optional[str]) -> Dict[str, Any]:
    """
    Fetch documentation from GitHub repository

    Args:
        repo_url: GitHub repository URL or dict with 'url' key

    Returns:
        Dictionary containing README, docs, examples, and metadata
    """
    if not repo_url:
        return {"error": "No repository URL provided", "source": "github"}

    # Handle dict with 'url' key
    if isinstance(repo_url, dict):
        repo_url = repo_url.get("url", "")

    # Parse GitHub URL to get owner/repo
    match = re.search(r"github\.com[/:]([\w-]+)/([\w-]+)", repo_url)
    if not match:
        return {"error": "Invalid GitHub URL", "source": "github"}

    owner, repo = match.groups()
    repo = repo.replace(".git", "")
    base_url = f"https://api.github.com/repos/{owner}/{repo}"

    try:
        return {
            "readme": _fetch_github_readme(base_url),
            "docs": _fetch_github_directory(base_url, "docs"),
            "examples": _fetch_github_directory(base_url, "examples"),
            "metadata": _fetch_github_metadata(base_url),
            "repository": {"owner": owner, "repo": repo},
            "source": "github",
        }

    except requests.exceptions.RequestException as e:
        return {"error": str(e), "source": "github"}


def _fetch_github_readme(base_url: str) -> Optional[str]:
    """Fetch the repository README, tolerating common filename variants."""
    # start by probing the generic readme enpoint
    readme = _fetch_github_content(f"{base_url}/readme", "repository README")
    if readme:
        return readme

    # if no success there, try various common spellings/casing of the readme file
    for path in ["README.md", "readme.md", "README.rst", "README.txt", "Readme.md"]:
        readme = _fetch_github_file(base_url, path)
        if readme:
            return readme
    return None


def _fetch_github_file(base_url: str, path: str) -> Optional[str]:
    """Fetch a single file from GitHub"""
    return _fetch_github_content(f"{base_url}/contents/{path}", path)


def _fetch_github_content(url: str, description: str) -> Optional[str]:
    """Fetch base64-encoded content from a GitHub API content endpoint."""
    try:
        response = requests.get(url, timeout=10)
        if not response.ok:
            return None

        data = response.json()
        if "content" in data:
            return base64.b64decode(data["content"]).decode("utf-8")
        return None

    except Exception as e:
        # Failed to fetch GitHub file - log and return None
        logger.debug("Failed to fetch GitHub content %s: %s", description, e)
        return None


def _fetch_github_directory(base_url: str, path: str) -> Optional[List[Dict[str, str]]]:
    """Fetch directory listing from GitHub"""
    try:
        response = requests.get(f"{base_url}/contents/{path}", timeout=10)
        if not response.ok:
            return None

        data = response.json()
        if isinstance(data, list):
            return [
                {
                    "name": item["name"],
                    "path": item["path"],
                    "type": item["type"],
                    "download_url": item.get("download_url"),
                }
                for item in data
            ]
        return None

    except Exception as e:
        # Failed to fetch GitHub directory - log and return None
        logger.debug(f"Failed to fetch GitHub directory {path}: {e}")
        return None


def _fetch_github_metadata(base_url: str) -> Optional[Dict[str, Any]]:
    """Fetch repository metadata from GitHub"""
    try:
        response = requests.get(base_url, timeout=10)
        if not response.ok:
            return None

        data = response.json()
        return {
            "stars": data.get("stargazers_count"),
            "forks": data.get("forks_count"),
            "issues": data.get("open_issues_count"),
            "language": data.get("language"),
            "updated_at": data.get("updated_at"),
        }

    except Exception as e:
        # Failed to fetch GitHub metadata - log and return None
        logger.debug(f"Failed to fetch GitHub metadata: {e}")
        return None
