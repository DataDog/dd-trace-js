"""Maven Central registry fetcher for Java package metadata."""

import json
import urllib.request
from typing import Any, Dict, Optional


def fetch_from_maven(
    group_id: str, artifact_id: str, version: Optional[str] = None
) -> Dict[str, Any]:
    """Fetch package metadata from Maven Central.

    Args:
        group_id: Maven group ID (e.g. 'redis.clients')
        artifact_id: Maven artifact ID (e.g. 'jedis')
        version: Optional specific version; if None, fetches latest

    Returns:
        Dict with keys: group_id, artifact_id, version, description,
        repository, homepage, source: 'maven-central'
    """
    result: Dict[str, Any] = {
        "group_id": group_id,
        "artifact_id": artifact_id,
        "version": version,
        "description": None,
        "repository": None,
        "homepage": None,
        "source": "maven-central",
    }

    try:
        # Search Maven Central for the artifact
        query = f"g:{group_id}+AND+a:{artifact_id}"
        url = f"https://search.maven.org/solrsearch/select?q={query}&rows=1&wt=json"

        with urllib.request.urlopen(url, timeout=15) as response:
            data = json.loads(response.read().decode("utf-8"))

        docs = data.get("response", {}).get("docs", [])
        if not docs:
            result["error"] = f"No results for {group_id}:{artifact_id} on Maven Central"
            return result

        doc = docs[0]
        if not version:
            result["version"] = doc.get("latestVersion")

        # Maven Central doesn't expose description directly; use the artifact coordinates
        result["description"] = f"{group_id}:{artifact_id}"

        # Derive GitHub URL from common patterns (many OSS Java libs host on GitHub)
        # Maven Central SCM info is only in POM, not in search API; best-effort from group_id
        github_org = _infer_github_org(group_id, artifact_id)
        if github_org:
            result["repository"] = {"url": f"https://github.com/{github_org}/{artifact_id}"}
            result["homepage"] = f"https://github.com/{github_org}/{artifact_id}"

    except Exception as e:
        result["error"] = str(e)

    return result


def _infer_github_org(group_id: str, artifact_id: str) -> Optional[str]:
    """Best-effort mapping from Maven group ID to GitHub org name.

    This covers common patterns used by OSS Java libraries.
    Returns None when the mapping is ambiguous.
    """
    # io.github.<org> and com.github.<org> patterns
    for prefix in ("io.github.", "com.github."):
        if group_id.startswith(prefix):
            return group_id[len(prefix) :]

    # Well-known group→org mappings
    known = {
        "redis.clients": "redis",
        "com.squareup.okhttp3": "square",
        "com.squareup.retrofit2": "square",
        "org.apache.httpcomponents": "apache",
        "org.apache.kafka": "apache",
        "com.google.guava": "google",
        "com.google.protobuf": "protocolbuffers",
        "io.grpc": "grpc",
        "io.netty": "netty",
        "org.mongodb": "mongodb",
        "org.springframework": "spring-projects",
    }
    return known.get(group_id)
