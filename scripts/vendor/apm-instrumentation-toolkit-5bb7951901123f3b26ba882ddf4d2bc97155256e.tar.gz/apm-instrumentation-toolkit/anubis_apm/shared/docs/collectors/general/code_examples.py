"""
Code Examples Fetcher
Downloads actual code from examples directories and extracts code blocks from README
"""

import logging
import re
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


def fetch_code_examples(github_data: Dict[str, Any], readme: Optional[str]) -> Dict[str, Any]:
    """
    Fetch code examples from GitHub examples directory and README

    Args:
        github_data: GitHub data from github fetcher
        readme: README content from npm or github

    Returns:
        Dictionary containing code examples from various sources
    """
    readme_examples: List[Dict[str, Any]] = []
    example_files: List[Dict[str, Any]] = []

    # 1. Extract code blocks from README
    if readme:
        readme_examples = _extract_code_blocks_from_readme(readme)

    # 2. Download example files from GitHub
    examples_list = github_data.get("examples", [])
    if examples_list:
        repo = github_data.get("repository", {})
        if repo:
            example_files = _download_example_files(examples_list, repo)

    return {
        "readme_examples": readme_examples,
        "example_files": example_files,
        "source": "code-examples",
    }


def _extract_code_blocks_from_readme(readme: str) -> List[Dict[str, Any]]:
    """Extract code blocks from README markdown"""
    code_blocks = []

    # Pattern to match fenced code blocks with optional language
    pattern = r"```(\w*)\n(.*?)```"
    matches = re.finditer(pattern, readme, re.DOTALL)

    for i, match in enumerate(matches):
        language = match.group(1) or "unknown"
        code = match.group(2).strip()

        # Try to find context (heading before code block)
        context = _find_context_before_code(readme, match.start())

        code_blocks.append({
            "index": i,
            "language": language,
            "code": code,
            "context": context,
            "lines": len(code.split("\n")),
        })

    return code_blocks


def _find_context_before_code(readme: str, position: int) -> Optional[str]:
    """Find the nearest heading or sentence before a code block"""
    # Look back up to 500 characters
    search_start = max(0, position - 500)
    text_before = readme[search_start:position]

    # Try to find a heading (# or ##)
    heading_match = re.search(r"#+\s+(.+?)[\n\r]", text_before[::-1])
    if heading_match:
        return heading_match.group(1)[::-1].strip()

    # Fallback: get the last sentence
    sentences = text_before.split(".")
    if len(sentences) > 1:
        return sentences[-2].strip()

    return None


def _download_example_files(
    examples_list: List[Dict[str, str]], repo: Dict[str, str]
) -> List[Dict[str, Any]]:
    """Download example files from GitHub"""
    example_files = []

    for example in examples_list:
        if example["type"] != "file":
            continue

        # Only download common code file extensions
        name = example["name"]
        if not _is_code_file(name):
            continue

        download_url = example.get("download_url")
        if not download_url:
            continue

        try:
            response = requests.get(download_url, timeout=10)
            if response.ok:
                content = response.text
                example_files.append({
                    "name": name,
                    "path": example["path"],
                    "code": content,
                    "lines": len(content.split("\n")),
                    "size_bytes": len(content),
                })
        except Exception as e:
            # Failed to read example file - log and skip
            logger.debug(f"Failed to read code example {example['path']}: {e}")
            continue

    return example_files


def _is_code_file(filename: str) -> bool:
    """Check if file is a code file worth downloading"""
    code_extensions = {
        ".js",
        ".ts",
        ".jsx",
        ".tsx",
        ".mjs",
        ".cjs",
        ".py",
        ".java",
        ".go",
        ".rs",
        ".rb",
        ".php",
        ".c",
        ".cpp",
        ".h",
        ".hpp",
        ".cs",
        ".swift",
        ".kt",
        ".scala",
        ".sh",
        ".bash",
    }

    return any(filename.endswith(ext) for ext in code_extensions)


def extract_api_patterns(code_examples: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    """
    Extract common API usage patterns from code examples

    Args:
        code_examples: List of code examples with 'code' field

    Returns:
        Dictionary of detected patterns (imports, class instantiation, method calls)
    """
    imports: set[str] = set()
    class_instantiation: set[str] = set()
    method_calls: set[str] = set()
    async_patterns: List[str] = []

    for example in code_examples:
        code = example.get("code", "")

        # Extract require/import statements (JavaScript/TypeScript)
        for match in re.finditer(r"(?:require|import)\s*\(['\"]([^'\"]+)['\"]\)", code):
            imports.add(match.group(1))

        for match in re.finditer(r"import\s+.*?\s+from\s+['\"]([^'\"]+)['\"]", code):
            imports.add(match.group(1))

        # Extract new ClassName() patterns
        for match in re.finditer(r"new\s+(\w+)\s*\(", code):
            class_instantiation.add(match.group(1))

        # Extract method calls like object.method()
        for match in re.finditer(r"(\w+)\.(\w+)\s*\(", code):
            method_calls.add(f"{match.group(1)}.{match.group(2)}")

        # Detect async patterns
        if "async" in code or "await" in code:
            async_patterns.append(example.get("context", "Unknown"))

        if ".then(" in code or ".catch(" in code:
            async_patterns.append(f"Promise chain in {example.get('context', 'Unknown')}")

    # Convert sets to sorted lists
    return {
        "imports": sorted(imports),
        "class_instantiation": sorted(class_instantiation),
        "method_calls": sorted(method_calls),
        "async_patterns": async_patterns,
    }
