"""
Python Type Stubs Fetcher
Checks for type hints and stub packages for Python libraries
"""

import logging
from typing import Any, Dict, Optional

import requests

logger = logging.getLogger(__name__)


def fetch_type_stubs(package_name: str, pypi_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check for Python type stubs for a package

    Args:
        package_name: Name of the PyPI package
        pypi_data: Package data from PyPI registry

    Returns:
        Dictionary containing type information
    """
    has_types = False
    source: Optional[str] = None
    stubs_info: Optional[Dict[str, Any]] = None

    # Check classifiers for typing info (PEP 561)
    classifiers = pypi_data.get("classifiers", [])
    for classifier in classifiers:
        if "Typing :: Typed" in classifier:
            has_types = True
            source = "bundled"
            stubs_info = {"marker": "py.typed", "pep561": True}
            break

    if not has_types:
        # Try to fetch from types- or -stubs package
        stubs_package_names = [
            f"types-{package_name}",
            f"{package_name}-stubs",
        ]

        for stubs_package in stubs_package_names:
            try:
                response = requests.get(f"https://pypi.org/pypi/{stubs_package}/json", timeout=10)
                if response.ok:
                    data = response.json()
                    has_types = True
                    source = "stubs-package"
                    stubs_info = {
                        "package": stubs_package,
                        "version": data.get("info", {}).get("version"),
                    }
                    break
            except Exception as e:
                # Network errors are expected for packages without stubs
                logger.debug(f"Failed to fetch {stubs_package}: {e}")

    return {"has_types": has_types, "source": source, "stubs_info": stubs_info}
