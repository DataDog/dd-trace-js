"""
Documentation Site Crawler
Attempts to identify official package documentation sites
"""

from typing import Any, Dict, List, Optional
from urllib.parse import urlparse


def fetch_from_doc_site(homepage: Optional[str]) -> Dict[str, Any]:
    """
    Identify documentation sites for the package

    Args:
        homepage: Homepage URL from package.json

    Returns:
        Dictionary containing documentation site information
    """
    if not homepage:
        return {"error": "No homepage provided", "source": "doc-site"}

    potential_doc_sites: List[Dict[str, str]] = []
    is_doc_site = False

    try:
        parsed = urlparse(homepage)

        # Check if homepage itself is a doc site
        if "docs." in parsed.netloc or "/docs" in parsed.path:
            is_doc_site = True
            potential_doc_sites.append({
                "type": "homepage_is_docs",
                "url": homepage,
                "note": "Homepage is documentation site",
            })

        # For GitHub repos, suggest checking the repo's wiki/docs
        if "github.com" in parsed.netloc:
            repo_match = parsed.path.rstrip("/").rstrip("#readme")
            potential_doc_sites.append({
                "type": "github_repo",
                "url": f"https://github.com{repo_match}",
                "note": "Check README, wiki, and /docs folder in repository",
            })

        # Common doc site patterns based on domain
        base_domain = parsed.netloc.replace("www.", "")
        if base_domain and not base_domain.startswith("github.com"):
            # Try to find associated doc sites
            common_doc_patterns = [
                f"https://docs.{base_domain}",
                f"https://{base_domain}/docs",
                f"https://{base_domain}/documentation",
            ]

            for doc_url in common_doc_patterns:
                potential_doc_sites.append({
                    "type": "potential",
                    "url": doc_url,
                    "note": "Common documentation URL pattern (not verified)",
                })

        return {
            "homepage": homepage,
            "potential_doc_sites": potential_doc_sites,
            "is_doc_site": is_doc_site,
            "source": "doc-site",
        }

    except Exception as e:
        return {"error": str(e), "source": "doc-site"}
