"""dd-trace-py documentation collectors."""

from anubis_apm.shared.docs.collectors.dd_trace_py.fetch import fetch_python_docs

__all__ = ["fetch_python_docs"]
