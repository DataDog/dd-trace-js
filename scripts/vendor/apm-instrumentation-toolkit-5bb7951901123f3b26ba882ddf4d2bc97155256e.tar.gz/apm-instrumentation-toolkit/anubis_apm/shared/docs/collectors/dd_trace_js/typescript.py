"""
TypeScript Definitions Fetcher
Extracts API surface from TypeScript definition files
"""

import logging
from typing import Any, Dict, Optional

import requests

logger = logging.getLogger(__name__)


def fetch_type_definitions(package_name: str, npm_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fetch TypeScript definitions for a package

    Args:
        package_name: Name of the npm package
        npm_data: Package data from npm registry

    Returns:
        Dictionary containing type information
    """
    has_types = False
    source: Optional[str] = None
    definitions: Optional[Dict[str, Any]] = None

    # Check if package has built-in types
    if npm_data.get("types"):
        has_types = True
        source = "bundled"
        definitions = {"path": npm_data["types"]}
    else:
        # Try to fetch from @types
        types_package = f"@types/{package_name.replace('@', '').replace('/', '__')}"
        try:
            response = requests.get(f"https://registry.npmjs.org/{types_package}", timeout=10)
            if response.ok:
                data = response.json()
                has_types = True
                source = "@types"
                definitions = {
                    "package": types_package,
                    "version": data.get("dist-tags", {}).get("latest"),
                }
        except Exception as e:
            # Network errors are expected for packages without @types
            logger.debug(f"Failed to fetch @types/{package_name}: {e}")

    return {"has_types": has_types, "source": source, "definitions": definitions}
