"""Java documentation fetcher — Maven Central + GitHub."""

from typing import TYPE_CHECKING, Any, Dict, Tuple

from anubis_apm.shared.docs.collectors.dd_trace_java.maven_registry import fetch_from_maven
from anubis_apm.shared.docs.collectors.general.github import fetch_from_github

if TYPE_CHECKING:
    from anubis.core.output.emitter import EventEmitter


def fetch_java_docs(
    package_name: str,
    results: Dict[str, Any],
    emitter: "EventEmitter",
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Fetch documentation for a Java package.

    Accepts either Maven coordinates (group:artifact:version or group:artifact)
    or a plain artifact name.  For Maven coordinates the registry lookup is
    precise; for a plain name the caller should ideally pass full coordinates.

    Args:
        package_name: Maven coordinates (e.g. 'redis.clients:jedis:1.4.0')
                      or plain artifact name (e.g. 'jedis')
        results: Results dict to populate (mutated in-place)
        emitter: Event emitter for progress output

    Returns:
        Tuple of (maven_data, github_data)
    """
    # Parse Maven coordinates
    parts = package_name.split(":")
    if len(parts) >= 2:
        group_id, artifact_id = parts[0], parts[1]
        version = parts[2] if len(parts) >= 3 else None
    else:
        # Plain name — can't do a precise Maven lookup
        group_id, artifact_id, version = None, package_name, None

    # 1. Fetch from Maven Central
    emitter.emit("step_start", step="Fetching from Maven Central")
    if group_id:
        maven_data = fetch_from_maven(group_id, artifact_id, version)
    else:
        maven_data = {
            "error": (
                f"Cannot fetch Maven metadata for '{package_name}' without group ID. "
                f"Provide full Maven coordinates (group:artifact:version)."
            ),
            "source": "maven-central",
        }

    results["sources"]["maven"] = maven_data

    if "error" in maven_data:
        emitter.emit("error", message=f"Maven Central: {maven_data['error']}")
        return maven_data, {"error": "Maven fetch failed", "source": "github"}

    emitter.emit(
        "success",
        message=f"Found {maven_data.get('group_id')}:{maven_data.get('artifact_id')} "
        f"v{maven_data.get('version')}",
    )

    # 2. Fetch from GitHub
    emitter.emit("step_start", step="Fetching from GitHub")
    repo_info = maven_data.get("repository")
    repo_url = repo_info.get("url") if repo_info else None

    if repo_url:
        github_data = fetch_from_github(repo_url)
        results["sources"]["github"] = github_data

        if "error" not in github_data:
            emitter.emit(
                "info", message=f"README: {'Found' if github_data.get('readme') else 'Not found'}"
            )
            emitter.emit(
                "info",
                message=f"Docs folder: {'Found' if github_data.get('docs') else 'Not found'}",
            )
            emitter.emit(
                "info",
                message=f"Examples: {'Found' if github_data.get('examples') else 'Not found'}",
            )
        else:
            emitter.emit("error", message=f"GitHub: {github_data['error']}")
    else:
        emitter.emit("info", message="No repository URL found — skipping GitHub fetch")
        github_data = {"error": "No repository URL", "source": "github"}
        results["sources"]["github"] = github_data

    return maven_data, github_data
