from typing import TYPE_CHECKING, Any, Dict, Tuple

from anubis_apm.shared.docs.collectors.dd_trace_js.npm_registry import fetch_from_npm
from anubis_apm.shared.docs.collectors.dd_trace_js.typescript import fetch_type_definitions
from anubis_apm.shared.docs.collectors.general.github import fetch_from_github

if TYPE_CHECKING:
    from anubis.core.output.emitter import EventEmitter


def fetch_node_docs(
    package_name: str, results: Dict[str, Any], emitter: "EventEmitter"
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Fetch documentation for a Node.js package

    Args:
        package_name: Name of the npm package
        results: Results dict to populate
        emitter: Event emitter for output

    Returns:
        Tuple of (npm_data, github_data)
    """
    # 1. Fetch from language package registry
    npm_data = fetch_from_npm(package_name, emitter)
    results["sources"]["npm"] = npm_data

    if "error" in npm_data:
        emitter.emit("error", message=f"npm: {npm_data['error']}")
        # Return empty github_data on npm error
        return npm_data, {"error": "npm fetch failed", "source": "github"}
    else:
        emitter.emit("success", message=f"Found version {npm_data.get('version')}")

    # 2. Fetch from GitHub
    emitter.emit("step_start", step="Fetching from GitHub")
    repo_url = npm_data.get("repository")
    if repo_url:
        github_data = fetch_from_github(repo_url)
        results["sources"]["github"] = github_data

        if "error" not in github_data:
            readme = github_data.get("readme")
            docs = github_data.get("docs")
            examples = github_data.get("examples")
            emitter.emit("info", message=f"README: {'Found' if readme else 'Not found'}")
            emitter.emit("info", message=f"Docs folder: {'Found' if docs else 'Not found'}")
            emitter.emit("info", message=f"Examples folder: {'Found' if examples else 'Not found'}")
        else:
            emitter.emit("error", message=f"GitHub: {github_data['error']}")
    else:
        emitter.emit("warn", message="No repository URL found")
        github_data = {"error": "No repository URL", "source": "github"}
        results["sources"]["github"] = github_data

    # 3. Fetch TypeScript definitions
    emitter.emit("step_start", step="Checking TypeScript definitions")
    ts_data = fetch_type_definitions(package_name, npm_data)
    results["sources"]["typescript"] = ts_data

    if ts_data["has_types"]:
        emitter.emit("success", message=f"Types found (source: {ts_data['source']})")
    else:
        emitter.emit("info", message="No type definitions found")

    return npm_data, github_data
