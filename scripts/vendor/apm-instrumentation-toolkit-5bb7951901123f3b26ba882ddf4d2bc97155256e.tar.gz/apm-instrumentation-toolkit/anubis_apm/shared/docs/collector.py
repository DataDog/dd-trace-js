"""
Main Documentation Collector
Orchestrates fetching from all sources and combines results
"""

import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, Optional

from anubis_apm.shared.docs.collectors.dd_trace_java.fetch import fetch_java_docs
from anubis_apm.shared.docs.collectors.dd_trace_js.fetch import fetch_node_docs
from anubis_apm.shared.docs.collectors.dd_trace_py.fetch import fetch_python_docs
from anubis_apm.shared.docs.collectors.general.code_examples import (
    extract_api_patterns,
    fetch_code_examples,
)
from anubis_apm.shared.docs.collectors.general.doc_sites import fetch_from_doc_site

if TYPE_CHECKING:
    from anubis.core.output.emitter import EventEmitter


LANGUAGE_COLLECTORS = {
    "dd_trace_java": fetch_java_docs,
    "dd_trace_js": fetch_node_docs,
    "dd_trace_py": fetch_python_docs,
}


class DocumentationCollector:
    """Collects comprehensive documentation for npm packages"""

    results: Dict[str, Any]
    sources: Dict[str, Any]

    def __init__(self, package_name: str, language: str, emitter: "EventEmitter"):
        self.package_name = package_name
        self.language = language
        self.emitter = emitter
        self.sources = {}
        self.results = {
            "package": package_name,
            "collected_at": datetime.utcnow().isoformat(),
            "sources": self.sources,
        }

    def collect_all(self) -> Optional[Dict[str, Any]]:
        """
        Collect documentation from all available sources

        Returns:
            Dictionary containing all collected documentation, or None if no collector
        """
        if self.language in LANGUAGE_COLLECTORS:
            collector = LANGUAGE_COLLECTORS[self.language]
            registry_data, github_data = collector(self.package_name, self.results, self.emitter)

            if not registry_data:
                return None

            # 4. Check documentation sites
            self.emitter.emit("step_start", step="Identifying documentation sites")
            homepage = registry_data.get("homepage")
            if homepage:
                doc_site_data = fetch_from_doc_site(homepage)
                self.sources["doc_site"] = doc_site_data

                if "error" not in doc_site_data:
                    potential = doc_site_data.get("potential_doc_sites", [])
                    if doc_site_data.get("is_doc_site"):
                        self.emitter.emit("success", message="Homepage is a documentation site")
                    elif potential:
                        self.emitter.emit(
                            "info", message=f"Identified {len(potential)} potential doc locations"
                        )
                    else:
                        self.emitter.emit("info", message="No documentation sites identified")
                else:
                    self.emitter.emit("error", message=f"Doc sites: {doc_site_data['error']}")
            else:
                self.emitter.emit("info", message="No homepage URL found")
                self.sources["doc_site"] = {"error": "No homepage URL", "source": "doc-site"}

            # 5. Fetch code examples
            self.emitter.emit("step_start", step="Fetching code examples")
            readme = github_data.get("readme") or registry_data.get("readme")
            code_examples_data = fetch_code_examples(github_data, readme)
            self.sources["code_examples"] = code_examples_data

            readme_count = len(code_examples_data.get("readme_examples", []))
            file_count = len(code_examples_data.get("example_files", []))
            self.emitter.emit("info", message=f"README code blocks: {readme_count}")
            self.emitter.emit("info", message=f"Example files: {file_count}")

            # Extract API patterns
            all_examples = code_examples_data.get("readme_examples", []) + code_examples_data.get(
                "example_files", []
            )
            if all_examples:
                api_patterns = extract_api_patterns(all_examples)
                self.sources["api_patterns"] = api_patterns
                self.emitter.emit(
                    "info",
                    message=f"Detected {len(api_patterns.get('method_calls', []))} API methods",
                )

            self.emitter.emit("success", message="Collection complete")
            return self.results
        return None

    def save_to_file(self, output_path: str, separate_examples: bool = True) -> None:
        """
        Save collected documentation to a JSON file

        Args:
            output_path: Path to save main documentation
            separate_examples: If True, save code examples to separate file
        """
        # Save main documentation
        main_data = self.results.copy()

        # Optionally separate code examples into their own file
        if separate_examples and "code_examples" in self.sources:
            examples = self.sources.pop("code_examples")

            # Save examples separately
            examples_path = output_path.replace(".json", "-examples.json")
            with open(examples_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "package": self.package_name,
                        "collected_at": self.results["collected_at"],
                        "code_examples": examples,
                    },
                    f,
                    indent=2,
                    ensure_ascii=False,
                )
            self.emitter.emit("info", message=f"Saved examples to {examples_path}")

        # Save main documentation
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(main_data, f, indent=2, ensure_ascii=False)
        self.emitter.emit("info", message=f"Saved documentation to {output_path}")

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of collected documentation"""
        npm = self.sources.get("npm", {})
        github = self.sources.get("github", {})
        ts = self.sources.get("typescript", {})

        return {
            "package": self.package_name,
            "version": npm.get("version"),
            "description": npm.get("description"),
            "has_readme": bool(npm.get("readme") or github.get("readme")),
            "has_types": ts.get("has_types", False),
            "has_examples": bool(github.get("examples")),
            "has_docs_folder": bool(github.get("docs")),
            "repository": github.get("repository"),
            "homepage": npm.get("homepage"),
        }
