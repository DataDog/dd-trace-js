"""Shared final-review step — engineer reviews the diff and approves / requests changes.

Headless runs auto-approve; interactive runs show a ``git diff --stat`` and
prompt for yes / no / edit. ``feedback`` is populated when the engineer
chooses ``edit``, and the host workflow can route that back to its earlier
implementation step via ``ResetToStep``.

Importable from any workflow::

    from anubis_apm.steps import final_review_step

    @workflow(WorkflowConfig(name='my_workflow', steps=[..., final_review_step]))
    class MyWorkflow:
        def after_step(self, step_name, output, ctx):
            if step_name == 'final_review' and not output.approved:
                if output.feedback:
                    ctx.set('revision_feedback', output.feedback)
                    raise ResetToStep('implement', guidance=output.feedback)
                raise WorkflowError('Changes rejected by engineer')
            return output
"""

from typing import Any, Optional

from pydantic import BaseModel

from anubis import StepConfig, step
from anubis.core.context import Context
from anubis.core.git import detect_default_branch, get_diff_from_base_branch


class FinalReviewResult(BaseModel):
    """Output of :func:`final_review_step`."""

    approved: bool
    feedback: Optional[str] = None


@step(StepConfig(name="final_review", output_type=FinalReviewResult))
def final_review_step(step_input: Any, ctx: Context) -> FinalReviewResult:
    """Present the workflow's accumulated diff for engineer review.

    In headless mode auto-approves. In interactive mode shows a
    ``git diff --stat`` summary, points the user at ``git diff main...HEAD``
    for the full picture, and prompts ``yes / no / edit``. ``edit`` collects
    free-form feedback that the host workflow can route back to whichever
    step should re-run.
    """
    if ctx.headless:
        ctx.info("Headless mode — auto-approving final result")
        return FinalReviewResult(approved=True)

    # Pass None when no explicit base_branch is configured so the helper
    # auto-detects (handles `master`-default repos correctly). Hardcoding
    # "main" here would force the wrong base on those repos and the
    # function would fall back to `git diff HEAD`, which is empty in
    # checkpoint-committed worktrees → final_review auto-approves nothing.
    base_branch = ctx.state.base_branch if ctx.state else None
    display_base_branch = base_branch
    if display_base_branch is None and ctx.base_dir:
        display_base_branch = detect_default_branch(ctx.base_dir)
    diff = get_diff_from_base_branch(ctx.base_dir, base_branch) if ctx.base_dir else ""
    if not diff:
        ctx.info("No changes to review")
        return FinalReviewResult(approved=True)

    # Prior steps checkpoint-commit, so the working tree is often clean while
    # the real changes live on the workflow branch vs base.
    stat = get_diff_from_base_branch(ctx.base_dir, base_branch, stat=True) if ctx.base_dir else ""

    print()  # noqa: T201
    print("─" * 60)  # noqa: T201
    print("  Changes ready for review")  # noqa: T201
    print("─" * 60)  # noqa: T201
    if stat:
        for line in stat.splitlines():
            print(f"  {line}")  # noqa: T201
    print()  # noqa: T201
    print(f"  Run 'git diff {display_base_branch}...HEAD' to see the full diff.")  # noqa: T201
    print()  # noqa: T201

    while True:
        response = (
            input("  Approve changes? [y]es / [n]o / [e]dit (request changes): ").strip().lower()
        )

        if response in ("y", "yes", ""):
            return FinalReviewResult(approved=True)
        if response in ("n", "no"):
            return FinalReviewResult(approved=False)
        if response in ("e", "edit"):
            print("Describe the changes you want (end with empty line):")  # noqa: T201
            lines: list[str] = []
            while True:
                line = input("")
                if line == "":
                    break
                lines.append(line)
            feedback = "\n".join(lines)
            return FinalReviewResult(approved=False, feedback=feedback)

        print("Please enter y, n, or e.")  # noqa: T201
