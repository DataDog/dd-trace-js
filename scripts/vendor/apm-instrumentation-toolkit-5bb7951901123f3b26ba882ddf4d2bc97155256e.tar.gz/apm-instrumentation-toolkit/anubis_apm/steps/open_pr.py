"""Shared step: open a pull request for current branch changes.

Reusable agent step that creates/updates a GitHub PR using the pr skill.
Can be added to any workflow that produces code changes.

Usage::

    from anubis_apm.steps.open_pr import OpenPrStep

    @workflow(WorkflowConfig(
        name="my_workflow",
        steps=[..., OpenPrStep],
    ))
    class MyWorkflow: ...

The step reads ``pr_context`` from the workflow context to include
in the PR description. Set it before this step runs::

    ctx.set("pr_context", "Summary of what changed and why")
"""

from typing import TYPE_CHECKING, Any, Dict

from pydantic import BaseModel, Field

from anubis import AgentStepConfig, agent_step

if TYPE_CHECKING:
    from anubis.core.context import Context


class PrResult(BaseModel):
    """Output from the open-pr step."""

    pr_url: str = Field(default="", description="URL of the created/updated PR")
    pr_number: int = Field(default=0, description="PR number")
    created: bool = Field(default=False, description="True if new PR was created (vs updated)")
    draft: bool = Field(default=True, description="True if PR is a draft")
    summary: str = Field(default="", description="Brief description of what was done")


@agent_step(
    AgentStepConfig(
        name="open_pr",
        prompt="open-pr",
        output_type=PrResult,
        model="sonnet",
        max_turns=30,
        timeout_minutes=10,
        use_repo_root=True,
        skills=["pr"],
    )
)
class OpenPrStep:
    """Agent step that creates or updates a GitHub PR for current changes.

    Expects ``pr_context`` in the workflow context with a summary of what
    changed. The agent uses the ``pr`` skill to handle branch detection,
    PR template, labeling, etc.
    """

    def get_prompt_variables(self, input_data: Any, ctx: "Context") -> Dict[str, str]:
        """Provide variables for the prompt template."""
        pr_context = ctx.get("pr_context", "Changes from automated workflow.")
        working_dir = str(ctx.base_dir) if ctx.base_dir else "."
        return {
            "pr_context": pr_context,
            "working_dir": working_dir,
        }
