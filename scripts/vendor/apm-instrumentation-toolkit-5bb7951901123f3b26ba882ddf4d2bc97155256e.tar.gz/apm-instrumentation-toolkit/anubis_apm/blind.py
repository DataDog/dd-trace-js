"""Blind-mode helpers: permission deny rules, deletion step, and restore.

Use ``blind=True`` on ``analyze_package()`` / ``create_integration()`` or pass
``--blind`` on the CLI to prevent the agent from recovering code that has been
deleted from the target repository.

When blind mode is active:
- ``blind_setup_step`` runs as the first workflow step (after git branch setup)
  and deletes the integration so the agent starts from scratch.
- All git commands and dd-trace GitHub URLs are blocked via deny rules.
- A prompt notice warns the agent it is in a blind test run.
- On workflow failure the deleted files are restored via git checkout.
- On workflow success (create) the generated files are kept for review.

The deletion is intentionally deferred to ``blind_setup_step`` rather than done
before ``workflow.run()`` — the workflow's git branch setup does
``git reset --hard HEAD`` which would restore any pre-run deletions.

For concurrent eval runs, use ``create_blind_worktree`` / ``cleanup_blind_worktree``
instead — they create an isolated hard-linked shadow that is safe to remove.
"""

import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel

from anubis import StepConfig, step
from anubis.core.config import get_config
from anubis.core.context import Context
from anubis_apm.repo_adapters import get_apm_adapter

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Permission deny rules
# ---------------------------------------------------------------------------

# Block git commands that can surface deleted file content from history.
BLIND_GIT_DENY: list[str] = [
    "Bash(git:*)",
    # gh CLI can fetch raw file content from GitHub API, bypassing WebFetch rules
    "Bash(gh:*)",
]

# Block dd-trace GitHub access so the agent can't fetch deleted source from
# the remote repository. WebSearch is intentionally not blocked — agents may
# legitimately search for third-party package docs.
BLIND_WEB_DENY: list[str] = [
    "WebFetch(https://github.com/DataDog/dd-trace-*)",
    "WebFetch(https://raw.githubusercontent.com/DataDog/dd-trace-*)",
]

# Combined set: blocks both history recovery and web-based source lookup.
BLIND_DENY_RULES: list[str] = BLIND_GIT_DENY + BLIND_WEB_DENY

# ---------------------------------------------------------------------------
# Shadow worktree helpers
# ---------------------------------------------------------------------------


def create_blind_worktree(repo_root: Path, package: str, adapter: Optional[Any] = None) -> Path:
    """Create a minimal shadow directory for blind mode — no .git, no full repo copy.

    Uses hard links instead of copies so concurrent shadow directories cost
    near-zero disk space — file content is shared via inodes, only directory
    metadata is new.  Falls back to regular copies when hard links fail
    (cross-filesystem, unsupported FS, etc.).

    ``remove_integration()`` later deletes only the target package's hard links
    from this shadow, leaving the original repo untouched.
    """
    slug = package.replace("@", "").replace("/", "-").replace("_", "-")
    copy_path = repo_root.parent / f".blind-{slug}"
    if copy_path.exists():
        shutil.rmtree(copy_path)
    copy_path.mkdir(parents=True)

    dirs_to_copy: list[Path] = adapter.get_blind_copy_dirs(repo_root) if adapter else []
    if not dirs_to_copy:
        skills_dir = repo_root / ".claude" / "skills"
        if skills_dir.exists():
            dirs_to_copy = [skills_dir]

    def _ignore_noise(src: str, names: list[str]) -> list[str]:
        return [n for n in names if n in ("node_modules", "__pycache__", ".pytest_cache")]

    def _hardlink_or_copy(src: str, dst: str) -> None:
        try:
            os.link(src, dst)
        except OSError:
            shutil.copy2(src, dst)

    for src_dir in dirs_to_copy:
        rel = src_dir.relative_to(repo_root)
        dst = copy_path / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(
            src_dir,
            dst,
            symlinks=True,
            dirs_exist_ok=True,
            ignore=_ignore_noise,
            copy_function=_hardlink_or_copy,
        )

    return copy_path


def cleanup_blind_worktree(worktree_path: Path) -> None:
    """Remove a blind-mode shadow directory."""
    if worktree_path.exists():
        shutil.rmtree(worktree_path)


BLIND_PROMPT_PREFIX = """\
## Blind Test Mode

This is a blind test run. The integration files have been intentionally \
removed from this repository to evaluate how well you can recreate them from \
scratch. Work only from the package source code and documentation available to \
you now. Do not attempt to recover the deleted implementation through git \
history, GitHub, search engines, or any other means — treat it as if it never \
existed.\
"""


# ---------------------------------------------------------------------------
# Blind setup step (runs as first workflow step, after git branch setup)
# ---------------------------------------------------------------------------


class BlindSetupOutput(BaseModel):
    deleted_paths: list[str] = []


@step(StepConfig(name="blind_setup", output_type=BlindSetupOutput))
def blind_setup_step(input: Any, ctx: Context) -> BlindSetupOutput:
    """Delete the integration after git branch setup.

    Deletion is deferred to this step because the workflow's git setup runs
    ``git reset --hard HEAD`` which would restore any files deleted before
    ``workflow.run()``.  By running here (first step, after git setup), we
    ensure the agent starts with the integration files already gone.

    No-ops when ``_blind_mode`` is not set in context.
    """
    if not ctx.get("_blind_mode"):
        return BlindSetupOutput()

    explicit = ctx.get("_blind_repo_root")
    repo_root = Path(explicit) if explicit else get_config().get_repo_root(ctx.repository)
    if not repo_root:
        ctx.info("Blind mode: repo root not found, skipping deletion")
        return BlindSetupOutput()

    adapter = get_apm_adapter(ctx.repository)
    new_paths = list(adapter.remove_integration(ctx.namespace, repo_root) or [])

    if not new_paths:
        if explicit:
            # Explicit worktree (eval path): the eval workflow already removed
            # the integration before launching this nested run. Since nested
            # workflows skip git reset --hard HEAD, the files were not restored.
            # This is expected — proceed without deletion.
            ctx.info(
                f"Blind mode: no paths removed for {ctx.namespace}/{ctx.repository} "
                f"— integration already cleaned up by caller (explicit worktree)"
            )
            return BlindSetupOutput()
        raise RuntimeError(
            f"Blind mode: remove_integration returned no paths for "
            f"{ctx.namespace}/{ctx.repository} at {repo_root}. Refusing to "
            f"proceed — a blind run with the integration still on disk is not "
            f"blind. Check that the adapter's remove_integration() recognises "
            f"this package."
        )

    ctx.info(
        f"Blind mode active — deleted {len(new_paths)} path(s) for {ctx.namespace}/{ctx.repository}"
    )
    for p in new_paths:
        ctx.info(f"  removed: {p}")

    # Extend the shared list created by setup_blind_for_workflow so callers
    # holding a reference to it (via blind_cleanup) see the populated paths.
    paths_ref = ctx.get("_blind_deleted_paths")
    if isinstance(paths_ref, list):
        paths_ref.extend(new_paths)

    return BlindSetupOutput(deleted_paths=new_paths)


def restore_deleted_integration(repo_root: Path, deleted_paths: list[str]) -> None:
    """Best-effort restore of files deleted by setup_blind_for_workflow.

    Intended for error recovery — on success, generated code is kept intentionally.
    Skips paths with annotation suffixes from revert_tracked_files (those were
    already at HEAD and don't need restoration).
    """
    clean_paths = [
        p for p in deleted_paths if " (reverted)" not in p and " (restored from HEAD)" not in p
    ]
    if not clean_paths:
        return
    try:
        subprocess.run(
            ["git", "checkout", "HEAD", "--", *clean_paths],
            cwd=repo_root,
            capture_output=True,
            check=True,
        )
        logger.info("Blind mode: restored %d path(s) from HEAD", len(clean_paths))
        for p in clean_paths:
            logger.info("  restored: %s", p)
    except Exception as exc:
        logger.warning("Blind mode: restore failed (%s)", exc)


def setup_blind_for_workflow(
    integration: str,
    repository: str,
    repo_root: Optional[Path] = None,
) -> tuple[dict, Optional[tuple[Path, list[str]]]]:
    """Set up blind mode for a workflow run.

    Returns context overrides that activate blind mode and deny rules that
    prevent the agent from recovering deleted code.  Actual file deletion is
    deferred to ``blind_setup_step`` (the first workflow step), because the
    workflow's git branch setup runs ``git reset --hard HEAD`` which would
    restore any files deleted here.

    Args:
        integration: Package/integration name.
        repository: Repository identifier (e.g. ``"dd_trace_js"``).
        repo_root: Explicit root directory to delete from.  When provided (e.g.
            an isolated git worktree), ``blind_setup_step`` deletes from that
            directory instead of the configured repo root.  The second return
            value is ``None`` in this case — the caller owns cleanup of the
            directory (typically by removing the entire worktree).

    The second return value is a ``(repo_root, deleted_paths)`` tuple for
    error-recovery via ``restore_deleted_integration()`` when no explicit
    ``repo_root`` is given.  When ``repo_root`` is provided the caller owns
    cleanup so ``None`` is returned instead.

    On setup failure returns deny-rules-only overrides and ``None`` so the
    caller can still run with partial protection.

    Usage::

        overrides, blind_cleanup_info = setup_blind_for_workflow(integration, repository)
        try:
            result = run_workflow(..., ctx_overrides=overrides)
        except Exception:
            if blind_cleanup_info:
                restore_deleted_integration(*blind_cleanup_info)
            raise
    """
    try:
        if repo_root is not None:
            # Explicit root (e.g. an isolated worktree): blind_setup_step will
            # delete from there; no git-based restore needed — caller cleans up.
            logger.info(
                "Blind mode queued for %s/%s — explicit root %s",
                repository,
                integration,
                repo_root,
            )
            overrides = {
                "agent_permission_deny": BLIND_DENY_RULES,
                "agent_prompt_prefix": BLIND_PROMPT_PREFIX,
                "_blind_mode": True,
                "_blind_repo_root": str(repo_root),
            }
            return overrides, None

        resolved = get_config().get_repo_root(repository)
        if not resolved:
            logger.warning(
                "Blind mode: repo root not found for %s/%s, using deny rules only",
                repository,
                integration,
            )
            return {
                "agent_permission_deny": BLIND_DENY_RULES,
                "agent_prompt_prefix": BLIND_PROMPT_PREFIX,
                "_blind_mode": True,
            }, None

        logger.info(
            "Blind mode queued for %s/%s — deletion deferred to blind_setup step",
            repository,
            integration,
        )
        # Shared mutable list: blind_setup_step will extend it with deleted paths
        # after the workflow's git setup completes, so restore_deleted_integration
        # has the correct paths when called by the caller after wf.run().
        deleted_paths: list[str] = []
        overrides = {
            "agent_permission_deny": BLIND_DENY_RULES,
            "agent_prompt_prefix": BLIND_PROMPT_PREFIX,
            "_blind_mode": True,
            "_blind_deleted_paths": deleted_paths,
        }
        return overrides, (resolved, deleted_paths)
    except Exception as exc:
        logger.warning("Blind mode: setup failed (%s), using deny rules only", exc)
        return {
            "agent_permission_deny": BLIND_DENY_RULES,
            "agent_prompt_prefix": BLIND_PROMPT_PREFIX,
            "_blind_mode": True,
        }, None
