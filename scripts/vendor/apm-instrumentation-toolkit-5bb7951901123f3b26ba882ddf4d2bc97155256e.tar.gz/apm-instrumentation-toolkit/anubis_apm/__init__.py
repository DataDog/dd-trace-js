"""APM Integrations package (anubis_apm).

This package contains APM domain-specific code that extends the generic
Anubis framework with dd-trace specific functionality.

Submodules:
    setup: Initialize anubis with APM factories (prompts, skills, adapters)
    repo_adapters: APMAdapterMixin and repo-specific implementations
    data: IntegrationFiles, models
    workflows: APM workflow implementations
    prompts: APM-specific prompts
    repo_adapters_impl: RepoAdapter implementations (dd-analyze, dd-generate, etc.)

Usage:
    from anubis_apm import setup
    setup.init()  # Initialize anubis with APM configuration

Note: Imports are lazy to avoid triggering ddtrace initialization before
env vars are loaded by the entry point (bin/dd-apm).
"""

__all__ = [
    "setup",
    "APMAdapter",
    "APMAdapterMixin",
    "DDTraceJsAdapter",
    "DDTracePyAdapter",
    "get_apm_adapter",
]

_LAZY_SUBMODULES = {"setup"}
_LAZY_ATTRS = {
    "APMAdapter",
    "APMAdapterMixin",
    "DDTraceJsAdapter",
    "DDTracePyAdapter",
    "get_apm_adapter",
}


def __getattr__(name: str):  # noqa: ANN001
    if name in _LAZY_SUBMODULES:
        import importlib  # noqa: PLC0415

        mod = importlib.import_module(f".{name}", __name__)
        globals()[name] = mod
        return mod
    if name in _LAZY_ATTRS:
        from .repo_adapters import (  # noqa: PLC0415
            APMAdapter,
            APMAdapterMixin,
            DDTraceJsAdapter,
            DDTracePyAdapter,
            get_apm_adapter,
        )

        _exports = {
            "APMAdapter": APMAdapter,
            "APMAdapterMixin": APMAdapterMixin,
            "DDTraceJsAdapter": DDTraceJsAdapter,
            "DDTracePyAdapter": DDTracePyAdapter,
            "get_apm_adapter": get_apm_adapter,
        }
        globals().update(_exports)
        return _exports[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
