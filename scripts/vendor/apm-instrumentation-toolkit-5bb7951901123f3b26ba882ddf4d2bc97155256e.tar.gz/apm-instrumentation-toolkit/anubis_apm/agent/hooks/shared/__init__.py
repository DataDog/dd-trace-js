"""Shared SDK hooks applied to all repositories."""
