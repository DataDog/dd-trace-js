"""Test quality enforcement hook.

PreToolUse hook that ensures agents write meaningful, thorough tests.
Uses a deny-then-allow pattern: first write to a test file is denied
with quality guidance, forcing the agent to acknowledge the requirements.
"""

import os
from typing import Any, Dict, Optional, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    PreToolUseHookInput,
    SyncHookJSONOutput,
)

# Directory segments that indicate test locations
_TEST_DIR_SEGMENTS = {"test", "tests", "spec", "__tests__"}

# Filename patterns that indicate test files (before extension)
_TEST_FILE_PATTERNS = (".test.", ".spec.", "_test.", "_spec.", "test_")


def _is_test_file(filepath: str) -> bool:
    """Check if a filepath is a test file based on path segments and filename conventions."""
    lower = filepath.lower()
    filename = os.path.basename(lower)

    # Check filename patterns: *.test.*, *.spec.*, *_test.*, *_spec.*, test_*
    if any(pattern in filename for pattern in _TEST_FILE_PATTERNS):
        return True

    # Check directory segments: tests/, test/, spec/, __tests__/
    parts = set(lower.replace("\\", "/").split("/"))
    return bool(parts & _TEST_DIR_SEGMENTS)


def build_test_quality_hook() -> HookCallback:
    """Build a PreToolUse hook that enforces test quality standards.

    Uses a deny-then-allow pattern: the first write/edit to a test file
    is denied with quality guidance. The agent must re-attempt, ensuring
    the warning is read before proceeding.

    Returns:
        Hook callback compatible with Claude Agent SDK HookMatcher.
    """
    warned_files: set[str] = set()

    async def test_quality_hook(
        input_data: HookInput,
        tool_use_id: Optional[str],
        context: HookContext,
    ) -> HookJSONOutput:
        """PreToolUse hook that enforces test quality on first write."""
        if input_data.get("hook_event_name") != "PreToolUse":
            return SyncHookJSONOutput()

        data = cast(PreToolUseHookInput, input_data)
        tool_name = data["tool_name"]
        tool_input: Dict[str, Any] = data["tool_input"]

        if tool_name not in ("Write", "Edit"):
            return SyncHookJSONOutput()

        filepath: str = tool_input.get("file_path", "")
        if not _is_test_file(filepath):
            return SyncHookJSONOutput()

        # Allow on second attempt (agent has seen the warning)
        if filepath in warned_files:
            return SyncHookJSONOutput()

        warned_files.add(filepath)

        warning = f"""\
============================================================
TEST FILE MODIFICATION - QUALITY CHECK REQUIRED
============================================================
File: {filepath}

STOP! Before re-attempting this write, verify ALL of the following:

1. MEANINGFUL ASSERTIONS
   - Tests assert on REAL output data, not just "it didn't throw"
   - Assert on the full structure of produced observability data (spans, metrics, logs)
   - Check ALL relevant fields: name, service, resource, type, tags, metadata
   - Include tag-level assertions with actual expected values

2. REAL-WORLD SCENARIOS
   - Tests call the REAL library API as an end user would
   - Do NOT test internal/private methods directly
   - Do NOT instantiate internal classes directly
   - Cover common usage patterns, edge cases, and error handling

3. COMPLETE COVERAGE
   - Assert on the entire span/event structure, not just one field
   - Verify error tags and error handling paths
   - Check all metadata fields the integration captures
   - Test both success and failure scenarios

4. NO SHALLOW TESTS
   - Avoid tests that only check "something was called"
   - Avoid tests that only verify a count without checking content
   - Every assertion should validate actual data values

Would a senior engineer approve these tests as thorough and meaningful?

TO PROCEED: Re-run the same {tool_name} command.
============================================================"""

        return SyncHookJSONOutput(
            hookSpecificOutput={
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": warning,
            }
        )

    return test_quality_hook
