"""Shared lint hook — runs the active repo adapter's linter on modified files.

Cross-repo shareable: works for any tracer repo because the lint command is
delegated to the active repo adapter's ``lint_paths()`` method. Each adapter
already implements lint_paths for its own toolchain (ruff for Python, Spotless
for Java, ESLint for JavaScript) — this hook reuses that single source of
truth instead of re-implementing the dispatch.

Failures are fed back to the agent as ``stopReason`` via ``continue_=False``
so the agent fixes them before completing.
"""

import logging
import subprocess
from pathlib import Path
from typing import Any, List, Optional, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    StopHookInput,
    SubagentStopHookInput,
    SyncHookJSONOutput,
)

# SDK event names this module's hooks register against. The SDKHookLoader
# uses this to wire the hook into ClaudeAgentOptions.hooks at the right key.
events = ["Stop", "SubagentStop"]

logger = logging.getLogger(__name__)

# Cap output sent back to the agent — keeps the stop reason from blowing up
# the next turn's context window if a linter dumps thousands of errors.
_MAX_OUTPUT_CHARS = 2000


def _get_modified_files() -> List[str]:
    """All files modified in the working tree vs HEAD, including untracked.

    Combines ``git diff --name-only HEAD`` (tracked + staged) with
    ``git ls-files --others --exclude-standard`` (untracked-but-not-ignored).
    Without the second call, brand-new files an agent just created would be
    invisible to the hook.
    """
    files: set[str] = set()

    try:
        diff_result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD", "--diff-filter=ACM"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if diff_result.returncode == 0:
            files.update(f for f in diff_result.stdout.strip().split("\n") if f)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    try:
        untracked_result = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if untracked_result.returncode == 0:
            files.update(f for f in untracked_result.stdout.strip().split("\n") if f)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    return sorted(files)


def _build_failure_context(adapter: Any, lint_result: dict) -> str:
    """Format lint failures into a stopReason string for the agent.

    Prefers the adapter's own formatter when available, falling back to a
    truncated combined output dump. Truncates to keep the agent's context
    from filling with linter noise.
    """
    formatter = getattr(adapter, "format_lint_errors_for_prompt", None)
    if callable(formatter):
        try:
            formatted = formatter(lint_result)
        except Exception as e:
            logger.warning("Adapter format_lint_errors_for_prompt raised: %s", e)
            formatted = str(lint_result.get("raw_output", ""))
    else:
        formatted = str(lint_result.get("raw_output", ""))

    if len(formatted) > _MAX_OUTPUT_CHARS:
        formatted = formatted[:_MAX_OUTPUT_CHARS] + (
            f"\n... (truncated, {len(formatted)} total chars)"
        )

    return f"## Lint Failures\n\n{formatted}\n"


def build_lint_hook(adapter: Any) -> HookCallback:
    """Build a hook that runs the repo adapter's linter on modified files.

    Cross-repo shareable: every adapter has ``lint_paths(paths, repo_root, fix=True)``,
    so the hook can stay language-agnostic — the adapter chooses the tool
    (ruff, spotless, yarn lint, etc.) based on the repo it represents.
    Fires on Stop and SubagentStop. Failures are fed back as additionalContext
    via continue_=False so the agent fixes them before completing.

    Args:
        adapter: Repo adapter providing ``lint_paths()`` and (optionally)
            ``format_lint_errors_for_prompt()``. Passed in by the SDKHookLoader
            via signature inspection.

    Returns:
        Hook callback compatible with Claude Agent SDK HookMatcher.
    """

    async def lint_hook(
        input_data: HookInput,
        _tool_use_id: Optional[str],
        _context: HookContext,
    ) -> HookJSONOutput:
        event = input_data.get("hook_event_name")

        if event == "SubagentStop":
            data = cast(SubagentStopHookInput, input_data)
            if data.get("agent_type") not in ("general-purpose", None):
                return SyncHookJSONOutput()
        elif event == "Stop":
            cast(StopHookInput, input_data)
        else:
            return SyncHookJSONOutput()

        files = _get_modified_files()
        if not files:
            return SyncHookJSONOutput()

        # Adapter decides which paths it handles; per-file linters (ruff,
        # eslint) filter by extension, project-level linters (gradle/spotless)
        # ignore the list and lint at module level.
        try:
            lint_result = adapter.lint_paths(paths=files, repo_root=Path("."), fix=True)
        except Exception as e:
            # Don't block the agent if the adapter itself fails — log and skip.
            logger.warning("Lint hook: adapter.lint_paths raised: %s", e)
            return SyncHookJSONOutput()

        if lint_result.get("success"):
            return SyncHookJSONOutput()

        # Some adapters report success=False with error_count=0 when the
        # underlying tool isn't installed (e.g. ruff missing, gradle missing).
        # Treat that as a skip rather than a block so the agent isn't trapped
        # in dev environments without the toolchain.
        if lint_result.get("error_count", 0) == 0:
            return SyncHookJSONOutput()

        return SyncHookJSONOutput(
            continue_=False,
            stopReason=_build_failure_context(adapter, lint_result),
        )

    return lint_hook
