"""Build hook for dd-trace-java.

Runs `./gradlew :dd-java-agent:instrumentation:{module}:compileJava`
for each module touched by modified .java files when the main agent
finishes a turn. Compile errors are fed back to the agent as
additionalContext so it fixes them in the next turn — without waiting
for the test loop to surface them.

Fires on `Stop` only (not `SubagentStop`). Compile is project-level
work that should run after the main agent's turn settles, not inside
short-lived subagents whose work the main agent will integrate later.
"""

import logging
import subprocess
from typing import List, Optional, Set, Tuple, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    StopHookInput,
    SyncHookJSONOutput,
)

# SDK event names this module's hooks register against. The SDKHookLoader
# uses this to wire the hook into ClaudeAgentOptions.hooks at the right key.
events = ["Stop"]

logger = logging.getLogger(__name__)

_INSTRUMENTATION_PREFIX = "dd-java-agent/instrumentation/"
_BUILD_TIMEOUT_S = 300
_MAX_OUTPUT_CHARS = 4000


def _extract_gradle_modules(files: List[str]) -> Set[str]:
    """Map modified .java files to Gradle module paths.

    The dd-trace-java repo uses a flat module layout under
    `dd-java-agent/instrumentation/{name}/` (and optionally a versioned
    subdirectory `{name}/{name}-{version}/`). This walks the path and
    builds the matching Gradle path (e.g., ':dd-java-agent:instrumentation:jedis').

    Files outside the instrumentation tree, or non-.java files, are
    ignored — they don't need a compileJava run.
    """
    modules: Set[str] = set()
    for file in files:
        if not file.endswith(".java"):
            continue
        if not file.startswith(_INSTRUMENTATION_PREFIX):
            continue

        relative = file[len(_INSTRUMENTATION_PREFIX) :]
        parts = relative.split("/")
        if len(parts) < 2:
            continue

        # First segment is always the module name.
        module_path_segments = [parts[0]]

        # If the second segment looks like a versioned subdirectory of the
        # same module (e.g., "jedis-1.4" inside "jedis/"), include it.
        if len(parts) >= 3 and parts[1].startswith(parts[0] + "-"):
            module_path_segments.append(parts[1])

        gradle_path = ":dd-java-agent:instrumentation:" + ":".join(module_path_segments)
        modules.add(gradle_path)
    return modules


def _get_modified_files() -> List[str]:
    """All files modified in the working tree vs HEAD, including untracked.

    Combines ``git diff --name-only HEAD`` (tracked + staged) with
    ``git ls-files --others --exclude-standard`` (untracked-but-not-ignored).
    Without the second call, brand-new .java files an agent just created
    would be invisible to the hook — a common path because agents create
    new instrumentation source before any `git add`.
    """
    files: set[str] = set()

    try:
        diff_result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD", "--diff-filter=ACM"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if diff_result.returncode == 0:
            files.update(f for f in diff_result.stdout.strip().split("\n") if f)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    try:
        untracked_result = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if untracked_result.returncode == 0:
            files.update(f for f in untracked_result.stdout.strip().split("\n") if f)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    return sorted(files)


def _run_compile(modules: Set[str]) -> Tuple[bool, str, bool]:
    """Run `./gradlew {module}:compileJava` for each module.

    Returns (passed, output, skipped). `skipped` is True only when
    gradlew is missing (FileNotFoundError) — callers should treat
    that as no-op rather than failure.
    """
    tasks = [f"{m}:compileJava" for m in sorted(modules)]
    cmd = ["./gradlew"] + tasks
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=_BUILD_TIMEOUT_S,
        )
        passed = result.returncode == 0
        output = (result.stdout + result.stderr).strip()
        return passed, output, False
    except subprocess.TimeoutExpired:
        return False, f"compileJava timed out after {_BUILD_TIMEOUT_S}s", False
    except FileNotFoundError:
        return True, "gradlew not found, skipping compile check", True


def _build_failure_context(output: str) -> str:
    """Build the additionalContext string from a compile failure."""
    if len(output) > _MAX_OUTPUT_CHARS:
        output = output[:_MAX_OUTPUT_CHARS] + f"\n... (truncated, {len(output)} total chars)"
    return (
        "## Java Compile Failures\n\n"
        "`./gradlew compileJava` failed on modified modules. Fix these errors:\n\n"
        "```\n"
        f"{output}\n"
        "```\n"
    )


def build_java_build_hook() -> HookCallback:
    """Build a hook that runs `./gradlew {module}:compileJava` after the main agent completes.

    Fires on `Stop` (main agent finished). Computes the affected Gradle
    modules from modified .java files (including untracked) and runs
    compileJava on each. Compile errors are fed back to the agent as
    additionalContext via continue_=False.

    Returns:
        Hook callback compatible with Claude Agent SDK HookMatcher.
    """

    async def java_build_hook(
        input_data: HookInput,
        _tool_use_id: Optional[str],
        _context: HookContext,
    ) -> HookJSONOutput:
        event = input_data.get("hook_event_name")
        if event != "Stop":
            return SyncHookJSONOutput()

        cast(StopHookInput, input_data)

        files = _get_modified_files()
        if not files:
            return SyncHookJSONOutput()

        modules = _extract_gradle_modules(files)
        if not modules:
            return SyncHookJSONOutput()

        passed, output, skipped = _run_compile(modules)
        if skipped or passed:
            return SyncHookJSONOutput()

        return SyncHookJSONOutput(
            continue_=False,
            stopReason=_build_failure_context(output),
        )

    return java_build_hook
