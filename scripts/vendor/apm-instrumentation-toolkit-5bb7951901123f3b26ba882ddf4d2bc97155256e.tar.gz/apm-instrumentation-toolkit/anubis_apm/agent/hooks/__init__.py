"""SDK hooks for agent execution.

Organized by repository with shared hooks applied to all:
- shared/ - hooks applied to all repositories
- dd_trace_js/ - JavaScript tracer-specific hooks
- dd_trace_py/ - Python tracer-specific hooks

Each hook module exports build_*_hook() functions that return
HookCallback callables compatible with the Claude Agent SDK.

Hook discovery is handled by SDKHookLoader in anubis.core.resources.
"""
