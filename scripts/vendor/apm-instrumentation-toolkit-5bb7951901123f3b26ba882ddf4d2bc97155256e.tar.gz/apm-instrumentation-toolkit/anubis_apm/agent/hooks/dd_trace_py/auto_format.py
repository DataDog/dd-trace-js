"""Auto-format hook for dd-trace-py.

Runs `hatch run lint:fmt` on modified Python files when an agent or subagent
completes, ensuring consistent formatting without the agent needing to remember.
"""

import logging
import subprocess
from typing import Optional, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    StopHookInput,
    SubagentStopHookInput,
    SyncHookJSONOutput,
)

# SDK event names this module's hooks register against. The SDKHookLoader
# uses this to wire the hook into ClaudeAgentOptions.hooks at the right key.
events = ["Stop", "SubagentStop"]

logger = logging.getLogger(__name__)


def _get_modified_py_files() -> list[str]:
    """Get Python files modified in the working tree (staged + unstaged)."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD", "--diff-filter=ACM"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        return [f for f in result.stdout.strip().split("\n") if f.endswith(".py")]
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return []


def build_auto_format_hook() -> HookCallback:
    """Build a hook that auto-formats modified Python files when agents complete.

    Fires on Stop (main agent done) and SubagentStop (subagent done).
    Finds all .py files modified vs HEAD and runs `hatch run lint:fmt` on them.
    Failures are logged at debug level — formatting is best-effort.

    Returns:
        Hook callback compatible with Claude Agent SDK HookMatcher.
    """

    async def auto_format_hook(
        input_data: HookInput,
        _tool_use_id: Optional[str],
        _context: HookContext,
    ) -> HookJSONOutput:
        event = input_data.get("hook_event_name")

        if event == "SubagentStop":
            data = cast(SubagentStopHookInput, input_data)
            # Only format for general-purpose subagents, not quick lookups
            if data.get("agent_type") not in ("general-purpose", None):
                return SyncHookJSONOutput()
        elif event == "Stop":
            cast(StopHookInput, input_data)
        else:
            return SyncHookJSONOutput()

        py_files = _get_modified_py_files()
        if not py_files:
            return SyncHookJSONOutput()

        # Format all modified Python files in one call
        try:
            subprocess.run(
                ["hatch", "run", "lint:fmt", "--"] + py_files,
                capture_output=True,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            logger.debug("Auto-format timed out after 60s")
        except FileNotFoundError:
            logger.debug("hatch not found, skipping auto-format")
        except OSError as e:
            logger.debug("Auto-format failed: %s", e)

        return SyncHookJSONOutput()

    return auto_format_hook
