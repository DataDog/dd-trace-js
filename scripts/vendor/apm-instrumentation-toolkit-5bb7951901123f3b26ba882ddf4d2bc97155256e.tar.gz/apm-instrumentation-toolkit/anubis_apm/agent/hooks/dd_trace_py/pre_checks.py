"""Pre-checks hook for dd-trace-py.

Runs hatch lint checks on modified Python files when an agent or subagent
completes. Any failures are fed back to the agent as additional context so
it can fix them in the next turn.

Mirrors the CI pre-checks job so agents produce CI-passing code.
"""

import logging
import subprocess
from typing import Optional, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    StopHookInput,
    SubagentStopHookInput,
    SyncHookJSONOutput,
)

# SDK event names this module's hooks register against. The SDKHookLoader
# uses this to wire the hook into ClaudeAgentOptions.hooks at the right key.
events = ["Stop", "SubagentStop"]

logger = logging.getLogger(__name__)

# Checks to run on modified Python files, in order.
# Each is a tuple of (hatch script, description).
# We skip expensive/irrelevant checks (C/CMake formatting, riot, suitespec).
_CHECKS: list[tuple[list[str], str]] = [
    (["hatch", "run", "lint:fmt", "--"], "auto-format"),
    (["hatch", "run", "lint:ruff", "--"], "ruff lint"),
    (["hatch", "run", "lint:typing", "--"], "type check (mypy)"),
]

# Full suite check (no file args) — only run on Stop (main agent done)
_FULL_CHECKS: list[tuple[list[str], str]] = [
    (["hatch", "run", "lint:error-log-check"], "error-log format"),
    (["hatch", "run", "lint:sg"], "ast-grep patterns"),
]


def _get_modified_py_files() -> list[str]:
    """Get Python files modified in the working tree vs HEAD."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD", "--diff-filter=ACM"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return [f for f in result.stdout.strip().split("\n") if f.endswith(".py") and f]
    except subprocess.TimeoutExpired:
        logger.debug("git diff timed out while listing modified files")
    except FileNotFoundError:
        logger.debug("git not found, skipping modified file detection")
    except OSError as e:
        logger.debug("Failed to list modified files: %s", e)
    return []


def _run_check(cmd: list[str], files: list[str] | None, timeout: int = 60) -> tuple[bool, str]:
    """Run a check command, optionally with file args. Returns (passed, output)."""
    full_cmd = cmd + files if files else cmd
    try:
        result = subprocess.run(
            full_cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        passed = result.returncode == 0
        output = (result.stdout + result.stderr).strip()
        return passed, output
    except subprocess.TimeoutExpired:
        return False, f"Check timed out after {timeout}s"
    except (FileNotFoundError, OSError) as e:
        return True, f"Check skipped: {e}"  # Don't fail if hatch not found


def _build_failure_context(failures: list[tuple[str, str]]) -> str:
    """Build the additionalContext string from check failures."""
    lines = [
        "## Pre-Check Failures",
        "",
        "The following CI checks failed on your changes. Fix these before the workflow completes:",
        "",
    ]
    for name, output in failures:
        lines.append(f"### {name}")
        # Truncate very long output
        if len(output) > 2000:
            output = output[:2000] + f"\n... (truncated, {len(output)} total chars)"
        lines.append("```")
        lines.append(output)
        lines.append("```")
        lines.append("")
    lines.append("Use `hatch run lint:fmt -- <file>` to auto-fix formatting issues.")
    lines.append("Use `hatch run lint:typing -- <file>` to check types on a specific file.")
    return "\n".join(lines)


def build_pre_checks_hook() -> HookCallback:
    """Build a hook that runs dd-trace-py CI pre-checks after agents complete.

    Fires on Stop (main agent) and SubagentStop (each subagent).
    Runs hatch lint checks on modified Python files and feeds failures
    back to the agent as additionalContext so it can fix them.

    Returns:
        Hook callback compatible with Claude Agent SDK HookMatcher.
    """

    async def pre_checks_hook(
        input_data: HookInput,
        _tool_use_id: Optional[str],
        _context: HookContext,
    ) -> HookJSONOutput:
        event = input_data.get("hook_event_name")

        is_main_agent_stop = event == "Stop"
        is_subagent_stop = event == "SubagentStop"

        if not is_main_agent_stop and not is_subagent_stop:
            return SyncHookJSONOutput()

        if is_subagent_stop:
            data = cast(SubagentStopHookInput, input_data)
            # Only run for general-purpose subagents doing code work
            if data.get("agent_type") not in ("general-purpose", None):
                return SyncHookJSONOutput()
        else:
            cast(StopHookInput, input_data)

        py_files = _get_modified_py_files()
        if not py_files:
            return SyncHookJSONOutput()

        failures: list[tuple[str, str]] = []

        # Run per-file checks
        for cmd, name in _CHECKS:
            passed, output = _run_check(cmd, py_files)
            if not passed and output:
                failures.append((name, output))

        # Run full-suite checks only on main agent stop (avoid running per-subagent)
        if is_main_agent_stop:
            for cmd, name in _FULL_CHECKS:
                passed, output = _run_check(cmd, None, timeout=120)
                if not passed and output:
                    failures.append((name, output))

        if not failures:
            return SyncHookJSONOutput()

        # Block the agent from stopping and feed failures back as the stop reason.
        # The agent will receive this as context and fix the issues before completing.
        context = _build_failure_context(failures)
        return SyncHookJSONOutput(
            continue_=False,
            stopReason=context,
        )

    return pre_checks_hook
