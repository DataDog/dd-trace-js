"""Test runner enforcement hook for dd-trace-py.

Blocks direct use of pytest, riot run, and scripts/ddtest riot run.
Agents must use scripts/run-tests instead.
"""

import re
import shlex
from typing import Optional, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    PreToolUseHookInput,
    SyncHookJSONOutput,
)

# Bad patterns and their human-readable names.
# Order matters — more specific patterns first.
_BAD_PATTERNS = [
    # scripts/ddtest riot run (before bare riot, to give the more specific message)
    (
        re.compile(r"(\.\/)?scripts/ddtest\s+riot\s+run\b"),
        "scripts/ddtest riot run",
    ),
    # riot run with any flags (riot run, riot -v run, riot --pass-env run, etc.)
    # Excludes riot list.
    (
        re.compile(r"\briot(\s+(-{1,2}[A-Za-z][A-Za-z0-9-]*))*\s+run\b"),
        "riot run",
    ),
    # python -m pytest
    (
        re.compile(r"python[23]?\s+(-[A-Za-z]+\s+)*-m\s+pytest\b"),
        "python -m pytest",
    ),
    # bare pytest / py.test (possibly prefixed with env vars like DD_TRACE_DEBUG=true)
    (
        re.compile(r"(^|[;&|]{1,2})\s*(\w+=\S+\s+)*py(\.test|test)\b"),
        "pytest",
    ),
]

_BLOCK_MESSAGE = """\
BLOCKED: '{matched}' is not allowed in dd-trace-py.

Use scripts/run-tests instead:

  # Discover available venvs for changed files:
  scripts/run-tests --list <file-or-dir>

  # Run a specific venv (fast iteration):
  scripts/run-tests --venv <hash>

  # Run with extra pytest args:
  scripts/run-tests --venv <hash> -- -s -vv -k test_name

Read the run-tests skill for full guidance."""

_RUN_TESTS_BLOCK_MESSAGE = """\
BLOCKED: scripts/run-tests requires --venv flag.

  # First discover available venvs:
  scripts/run-tests --list <file-or-dir>

  # Then run with a venv hash:
  scripts/run-tests --venv <hash>

  # With extra pytest args:
  scripts/run-tests --venv <hash> -- -s -vv"""

# Match any invocation of scripts/run-tests (with optional ./ prefix)
_RUN_TESTS_PATTERN = re.compile(r"(\.\/)?scripts/run-tests\b")


def _run_tests_missing_venv(command: str) -> bool:
    """Check if a scripts/run-tests invocation is missing the --venv flag.

    Parses the command arguments properly so that --venv is matched as a
    standalone argument rather than via substring matching. Allows --list
    and --help without requiring --venv.

    Args:
        command: The full shell command string.

    Returns:
        True if scripts/run-tests is invoked without --venv (and without
        --list or --help), False otherwise.
    """
    if not _RUN_TESTS_PATTERN.search(command):
        return False

    try:
        args = shlex.split(command)
    except ValueError:
        # Malformed shell string — fall back to conservative allow
        return False

    # Find the index of the scripts/run-tests token
    run_tests_idx = None
    for i, arg in enumerate(args):
        if arg.endswith("scripts/run-tests"):
            run_tests_idx = i
            break

    if run_tests_idx is None:
        return False

    # Extract only the args that belong to scripts/run-tests (before any --)
    # Args after -- are passed through to pytest and must not be inspected.
    run_tests_args = args[run_tests_idx + 1 :]
    try:
        separator_idx = run_tests_args.index("--")
        run_tests_args = run_tests_args[:separator_idx]
    except ValueError:
        pass  # No -- separator; all args belong to run-tests

    # Allow --list and --help without --venv
    if "--list" in run_tests_args or "--help" in run_tests_args:
        return False

    # Require --venv as a standalone argument (before --)
    return "--venv" not in run_tests_args


def build_test_runner_hook() -> HookCallback:
    """Build a PreToolUse hook that blocks disallowed test commands.

    Denies any Bash call that uses pytest, riot run, or scripts/ddtest riot run
    directly. Agents must use scripts/run-tests.

    Returns:
        Hook callback compatible with Claude Agent SDK HookMatcher.
    """

    async def test_runner_hook(
        input_data: HookInput,
        _tool_use_id: Optional[str],
        _context: HookContext,
    ) -> HookJSONOutput:
        if input_data.get("hook_event_name") != "PreToolUse":
            return SyncHookJSONOutput()

        data = cast(PreToolUseHookInput, input_data)
        if data["tool_name"] != "Bash":
            return SyncHookJSONOutput()

        command: str = data["tool_input"].get("command", "")
        if not command:
            return SyncHookJSONOutput()

        for pattern, label in _BAD_PATTERNS:
            if pattern.search(command):
                return SyncHookJSONOutput(
                    hookSpecificOutput={
                        "hookEventName": "PreToolUse",
                        "permissionDecision": "deny",
                        "permissionDecisionReason": _BLOCK_MESSAGE.format(matched=label),
                    }
                )

        # Block scripts/run-tests without --venv (allow --list and --help)
        if _run_tests_missing_venv(command):
            return SyncHookJSONOutput(
                hookSpecificOutput={
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": _RUN_TESTS_BLOCK_MESSAGE,
                }
            )

        return SyncHookJSONOutput()

    return test_runner_hook
