"""Python tracer-specific SDK hooks."""
