"""JavaScript tracer-specific SDK hooks."""
