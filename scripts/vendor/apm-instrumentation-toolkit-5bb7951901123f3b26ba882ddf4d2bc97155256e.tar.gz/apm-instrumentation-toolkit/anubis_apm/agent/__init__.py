"""APM agent resources - skills for AI agents."""
