## Intent

<!-- What problem does this solve? What's the goal? -->

## Changes

<!-- What was modified and why each change was necessary -->
<!-- If touching anubis/ vs anubis_apm/, explain the separation rationale -->

## Test plan

- [ ] `pytest tests/` passes
- [ ] `ruff check anubis/ anubis_apm/` is clean

## Documentation

- [ ] Updated `CLAUDE.md` if behavior/commands/architecture changed
- [ ] Updated skills (`.claude/skills/`) if workflows or patterns changed
- [ ] Updated docstrings for new/changed public APIs
- [ ] Updated `docs/` (Sphinx) if applicable
