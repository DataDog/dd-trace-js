# Changelog

All notable changes are documented here and in [GitHub Releases](https://github.com/DataDog/apm-instrumentation-toolkit/releases).














## [1.2.0-rc6] - 2026-06-12

- feat(java): make dd-trace-java create workflow work end-to-end (#448)

## [1.2.0-rc5] - 2026-06-11

- docs(execute): document execute workflow in AGENTS.md and drive-toolkit skill (#435)
- fix(preflight): don't false-positive tracing checks in agentless mode (#445)

## [1.2.0-rc4] - 2026-06-05

- fix(build): use noarchive=True so ddtrace modules exist as real files on disk (#432)

## [1.2.0-rc3] - 2026-06-05

- feat(plugin): interactive Claude Code plugin for step-by-step toolkit orchestration (#311)
- feat(tracing): long-running span partial flush for APM and LLMObs (#430)
- feat(workspace): add --workspace flag for remote execution in Datadog workspaces (#390)
- fix(reviewer): replace input() hang + propagate error status to root span (#423)
- ci: migrate darwin-arm64 build to tart VM runner (#429)
- feat(tracing): aggregate child LLM token/cost metrics onto root workflow span (#424)
- feat(specs): add runtime-update.md for tracer runtime version bumps (#365)
- feat(tracing): persist APM and LLMObs trace IDs in workflow state (#418)
- feat(cli): add --source flag (additive, no --spec change) (#358)
- fix(harness-feedback): invert fix priority order, add decision tree and constraints (#376)
- fix(tracing): ensure traces flush on Ctrl+C and tag repository on all spans (#417)
- fix(analyze): provide fallback package_path for Java eval prompt rendering (#416)
- fix(ci): add EVAL_REPOS filter, fix EVAL_MODEL override for eval triggers (#406)
- fix(ci): fix EVAL_MODEL override for integration-gen eval jobs (#404)
- fix(state): clear pr_url/pr_number on rollback and clear (#415)
- fix(ci): prevent dashboard-refresh failures from skipping eval jobs (#414)
- fix(runner): pass repository and repo_adapter to fixer agent spawns (#413)
- feat(state): track current_branch, pr_url, pr_number in WorkflowState (#411)
- feat(steps): first-class description/notes on steps; show by default in dd-apm steps (#412)
- fix(git): reset to origin/<base> after pull, not stale local HEAD (#410)
- fix(ux): accept full-word commands in interactive menus (#405)
- fix(ci): respect pre-set ANTHROPIC_MODEL in setup-claude-auth.sh (#403)
- fix(setup): check all dd_trace_js adapter deps and fix frozen smoke (#400)
- fix(ci): use make install in auth-common, rename eval-method-selection, fix dispatch (#402)
- fix(dd-debug): use npm instead of yarn to run tests (#399)
- fix(git): respect --base-branch flag and recreate branches from wrong base (#398)
- fix(ci): always auto-run eval-integration-gen-submit after evals (#401)
- feat(cli): add dd-apm steps, --stop-after, --rollback-git, --live, --version (#395)
- fix(analyze): raise on method extractor failures instead of silently continuing (#393)
- fix: externals.js preserve require/ternaries, non-interactive stdin, eval model tag (#394)
- feat(env): clean env, defer tracer init, collapse config to single source (#392)
- feat(tracing): improve workflow.user and add workflow.origin tag (#389)
- feat(feedback): structured halt channel with manual recovery (#348)
- feat(execute): require problem_statement + prior_decision_context + root_cause in plan output (#357)
- ci(eval): wire integration-gen evals onto the scheduled cron (#387)
- feat(eval): add branch and target_version tags to eval results (#386)
- feat(eval): thread target package version through install, analysis, and codegen (#379)
- Help the agents find the files they need (#373)
- feat(agent): add permission_allow + mcp_servers + sdk_hooks to spawn_agent (#381)
- fix(dashboard): strip restricted_roles from PUT payload to fix 500 error (#375)
- feat(eval): integration-gen eval — anubis workflow + evalya oracle (#294)
- point claude to agent md (#374)
- chore: update CODEOWNERS to apm-idm-iat (#377)
- refactor(semantic-tests): use evalya package and adapter methods (#362)
- feat(infra): evalya package, worktree helpers, repo adapter evalya support, blind mode wiring (#361)
- feat(agents): add MockAgentRunner for CI smoke tests (#372)
- chore: misc fixes — dd-auth app_key, s3_client.upload_dir, eval model tag, DD_APP_KEY preflight (#363)
- fix(enrichment): use adapter.language attr, not get_language() method (#371)
- refactor(config): split toolkit_root into toolkit_user_root and toolkit_install_root (#366)
- more robust readme fetching (#349)
- Prefer github readme over the one supplied by the package store (#359)
- feat(java): add feature workflow fragments + add-apm-integrations skill (#340)
- feat(hooks): shared lint hook with extension-based routing (#338)
- feat(java): add Maven coordinates support for analysis workflow (#297)
- feat(blind): blind mode for agent-proof eval and manual testing (#353)
- fix(deps): upgrade ddtrace to >=4.8.0; inline moved LLMObs constants (#352)
- get correct repo when spawning agents (#350)
- feat(hooks): dd-trace-java build hook for compileJava feedback (#339)
- fix(tracing): suppress ddtrace startup log noise; smoke outputs trace links (#347)
- fix(reliability): subprocess timeouts, stop_services logger, silent excepts (#346)
- feat(execute): add implement step to spec-driven workflow (#322)

## [1.2.0-rc2] - 2026-05-08

- feat(tracing): always-on ddtrace DEBUG log to `~/.dd-apm/tracer.log` + per-workflow tracer log in analysis dir (#344)
- fix(tracing): preflight reads tracer's actual writer URL (catches silent misroute when env var and writer diverge) (#344)
- feat(preflight): surface resolved tracer agent URL and log file path in CLI output (#344)
- chore(tracing): trim Trace Links output — drop deprecated preview UI URL and redundant trace IDs (#344)
- feat(eval): emit num_turns + fix release pre-release flagging (#337)

## [1.2.0-rc1] - 2026-05-07

- fix(babysit-prs): pick up dd-gitlab/* failures on re-runs (#334)
- feat(setup): dd-apm setup, doctor, and smoke commands (#333)
- fix(auth): enforce Org 2 credentials, auto-refresh stale dd-auth cache (#332)
- Auto language detection on repo add (#325)

## [1.1.0] - 2026-05-05

- feat(tracing): tag LLMObs spans with OS username + org validation (#319)
- feat(execute): spec-driven plan + plan_review workflow (#321)
- feat(babysit-prs): add shareable PR watcher daemon (#318)
- feat(eval): method selection eval improvements — GT accuracy, per-package logging, split ground truths (#317)
- feat(eval): AI Gateway cost extraction via MITM proxy + eval scoring fixes (#308)
- feat(eval): add --model flag to eval run-matrix and EVAL_MODEL CI variable (#312)
- feat(ci): add scheduled weekly run for method-selection matrix eval (#315)
- feat(ci): AI Gateway eval routing + diagnose dd-sts 403 (#299)
- feat(dashboard): use dd-octo-sts for GitHub PR data in dashboard-refresh (#301)
- feat(config): unified repo registry, detection, and clone command (#298)
- feat(prompts): strict mode for include_repo directives (#293)
- feat(anubis): TaskSpec loader, activate include_repo fragments, raise SDK buffer (#290)
- feat(observability): Datadog dashboard, LLMObs agentless fix, PR tracking, scheduled refresh (#296)
- feat(eval): add generic anubis.eval framework (#289)
- feat(java): add Java repo adapters for dd-trace-java (#258)
- fix(dashboard): wire all filters + add IAT user story (#326)
- fix(semantic-tests): export TRACER_DIR so evalya mounts dev tracer (#320)
- fix(ci): gate eval-run-matrix on EVAL_SCHEDULED variable to prevent hourly runs (#323)
- fix(eval-proxy): strip ?beta=true query param and mock count_tokens for all models (#316)
- fix(eval-proxy): suppress noisy false-positive warnings + fix bad resume hint (#314)
- fix(git-state): clean working tree before creating new workflow branch (#313)
- fix(tracing): block workflows when trace agent URL resolves to port 8126 (#319)
- refactor(adapters): REFERENCE_INTEGRATIONS with full semantic category coverage (#309)
- refactor(eval): run-matrix eval — strip deferred modules, reorganize datasets by repo (#261)

## [1.0.9] - 2026-04-16

- fix(storage): disable S3 auth in tests to prevent aws-vault SSO spam (#286)
- feat(ci): AI Gateway auth + manual smoke test (#283)

## [1.0.8] - 2026-04-16

- Release 1.0.8

## [1.0.7] - 2026-04-16

- Release 1.0.7

## [1.0.6] - 2026-04-15

- fix(runtime): bump requires-python to >=3.11 — asyncio.timeout requires 3.11+
- fix(s3): cache boto3 client at module level to prevent double SSO prompt
- fix(s3): increase aws-vault subprocess timeout to 120s for browser-based SSO
- fix(preflight): defer S3 credential probe to first upload — don't trigger SSO at startup
- test(ci): add binary smoke test (GitLab) and import/resource checks (GitHub) to catch packaging failures pre-release
- fix(ci): pin all tooling (mypy, ruff, black, GitHub CI matrix) to Python 3.13; macOS GitLab builds now use python3.13 explicitly so the binary embeds the right stdlib
- fix(docs): update bootstrap.sh and install.sh version requirement to Python 3.13

## [1.0.5] - 2026-04-15

- Release 1.0.5

## [1.0.4] - 2026-04-15

- fix(deps): declare requests as explicit dependency (#275)

## [1.0.3] - 2026-04-15

- fix(release): use self-extracting binary for dogbrew --onedir support
- fix(docs): correct dogbrew install version syntax (@ not --cli-version)
- feat(config): dynamic repo clone menu driven by SUPPORTED_REPOS registry

## [1.0.2] - 2026-04-15

- fix(config): validate default_repository on every command invocation
- feat(preflight): show config validity check as preflight line item
- docs(readme): add dogbrew permission fix and PATH ordering note
- docs(releasing): add post-release verification steps and troubleshooting
- fix(ci): gate build and publish on chore(release) commit message (#272)
- fix(ci): replace tomllib with grep for version parsing in dogbrew-publish (#271)

## [1.0.1] - 2026-04-15

- fix(ci): use macos:sonoma runner tag for darwin-arm64 build (#269)
- chore(release): v1.0.0 (#268)
- fix(ci): create GitHub Release directly in auto-tag job (#266)
- Revert "chore(release): v1.0.0 (#264)" (#267)

## [1.0.0] - 2026-04-15

Initial release of the APM Instrumentation Toolkit — an AI-powered CLI for creating and maintaining Datadog APM integrations.

### Supported Tracers

- **dd-trace-js** (Node.js) — creates integrations under `packages/datadog-plugin-{name}/`, tests via mocha, ESM support via `dd-trace-js` ESM counterpart validator
- **dd-trace-py** (Python) — creates integrations under `ddtrace/contrib/internal/{name}/`, tests via riot/pytest
- Additional tracers can be added via the repository adapter interface (`anubis_apm/repo_adapters/`)

### Workflows

All workflows are invoked via `dd-apm <command> <package>` and support checkpointing — interrupted runs resume from the last completed step.

**`dd-apm analyze <package>`** — Identify instrumentation targets in a package. Installs the package, extracts public API methods, collects documentation, and produces a structured analysis with recommended integration categories and span coverage.

**`dd-apm create <package>`** — Full integration lifecycle: context capture → analysis → code generation → sample app → instrumentation → tests → enrichment → code review. Two modes:
- `--mode guided` *(default)* — pauses at key checkpoints for human review
- `--mode agent` — fully autonomous end-to-end

**`dd-apm test <package>`** — Run integration tests and iteratively fix failures. Supports `--max-iterations <n>` (default 10).

**`dd-apm lint <package>`** — Run the tracer's linter and auto-fix violations. Supports `--fix`, `--paths/-p <paths>`, `--max-iterations <n>` (default 3).

**`dd-apm review <package>`** — Run repository-specific reviewer checks in parallel with auto-fix loop.

**`dd-apm semantic <package>`** — Run evalya semantic integration tests to validate span shape and tag coverage against Datadog conventions. Supports `--max-iterations <n>` (default 10).

**`dd-apm llm-obs <package>`** — Generate the LLM Observability layer for AI integrations (dd-trace-js only; requires the tracing plugin to already exist).

**`dd-apm generate-sample-app`** — Generate a working sample application from a spec. Accepts `--spec <file-or-text>`, `--output-dir <dir>`, `--language <lang>`.

**`dd-apm feature add <package>`** — Auto-detect and add missing features to an existing integration.

**`dd-apm pr <package> --babysit`** — Open a pull request and watch CI until all checks pass.

**Common flags** available on all workflow commands:
- `--repository/-r` — target tracer repo (default: from `dd-apm config`)
- `--from <step>` — resume from a specific step (skip already-completed work)
- `--prompt` — inject custom guidance into the agent prompt
- `--model` — override the Claude model (e.g. `opus`, `sonnet`)
- `--headless` — non-interactive mode
- `--experience` — inject relevant past run artifacts into prompts (experimental)
- `--skip-sync` — skip S3 push/pull for this run

### Agent Capabilities

Workflows are powered by Claude agents that run inside isolated working directories. Three facilities shape agent behavior:

**Skills** — Domain knowledge documents injected into the agent's context at step start. Provided skills:
- `datadog-semantics` — Datadog span/tag conventions, operation naming, peer service, error handling
- `observability-patterns` — General APM integration patterns across tracer SDKs
- `integration-internals` (dd-trace-js) — Plugin architecture, shimmer patterns, ESM support, diagnostic channels, performance guidelines
- `apm-integrations` (dd-trace-py) — Integration design decisions, anti-patterns, reference implementations
- `llmobs-integrations` (dd-trace-py) — LLM Observability layer patterns for Python

**Hooks** — Lightweight callbacks that fire around agent tool use, used to enforce quality gates without touching prompt text. Provided hooks:
- `test_quality` (shared) — PreToolUse hook that blocks low-quality test writes (e.g. excessive mocking, missing assertions)
- `auto_format` (dd-trace-py) — Auto-runs the formatter after code edits
- `pre_checks` (dd-trace-py) — Validates file structure before the agent starts writing

**Prompts** — Modular Markdown templates with composition directives:
- `{{include:path}}` — inline another template (recursive)
- `{{include_repo:name}}` — include a repo-specific fragment; silently skipped if the fragment doesn't exist (safe for new tracers)
- `{{link:path}}` — make a file available to the agent on demand without inlining it
- Variable substitution via `{{variable}}`

Repo-specific fragments live alongside shared templates at `prompts/shared/{workflow}/repo/{repo}/` and are merged automatically at runtime — adding a new fragment customizes agent behavior for one tracer without affecting others.

### Experience Store (S3)

Agents learn from past runs. After each workflow, step inputs/outputs are uploaded to S3 (`dd-apm-toolkit-experience`, staging account — access via `sso-staging-engineering` birthright). On the next run for the same integration or category, relevant past outputs are available as context.

- S3 sync is automatic; no configuration required beyond AWS auth
- Failed runs are stored alongside successful ones — they serve as negative examples
- `dd-apm sync setup/push/pull/list/inspect/refresh` — manual store management
- `DD_APM_S3_UPLOAD_LOGS=1` — include full agent logs in uploads (large, opt-in)

### Distribution

- Dogbrew distribution — `dogbrew install dd-apm` (#255, #263)
- Cross-platform frozen binaries (linux-amd64/arm64, darwin-amd64/arm64) built via PyInstaller on GitLab CI
- `scripts/release.sh` — one-command releases; CI auto-tags and publishes GitHub Releases on merge
