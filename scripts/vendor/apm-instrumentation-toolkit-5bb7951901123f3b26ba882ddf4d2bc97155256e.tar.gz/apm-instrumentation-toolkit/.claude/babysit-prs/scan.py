#!/usr/bin/env python3
"""Scan open toolkit PRs for new comments and CI failures.

Outputs JSON to stdout:
  {
    "new_items": [...],
    "toolkit_root": "...",
    "state_file": "..."
  }

Item shape:
  comment/review: {id, pr_number, branch, type, author, body}
  ci:             {id, pr_number, branch, type, name}
"""

import json
import logging
import re
import subprocess
from pathlib import Path
from typing import cast

log = logging.getLogger(__name__)


def run(cmd: list[str], cwd: str | None = None) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, returncode=1, stdout="", stderr="")


def get_toolkit_root() -> Path:
    result = run(["git", "worktree", "list", "--porcelain"])
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            return Path(line.split(" ", 1)[1])
    return Path.cwd()


def load_state(state_file: Path) -> dict:
    if state_file.exists():
        try:
            return cast(dict, json.loads(state_file.read_text()))
        except (json.JSONDecodeError, OSError) as e:
            log.warning("Could not read state file %s: %s", state_file, e)
    return {"handled": [], "last_run": None}


def get_open_prs(cwd: str) -> list[dict]:
    result = run(
        [
            "gh",
            "pr",
            "list",
            "--author",
            "@me",
            "--state",
            "open",
            "--json",
            "number,title,headRefName,url",
        ],
        cwd=cwd,
    )
    if result.returncode != 0:
        return []
    try:
        return cast(list[dict], json.loads(result.stdout))
    except (json.JSONDecodeError, ValueError) as e:
        log.debug("Failed to parse open PRs response: %s", e)
        return []


_ZERO_TIME = "0001-01-01T00:00:00Z"


def get_checks(pr_number: int, cwd: str) -> list[dict]:
    """Return failing CI checks. Uses gh's 'bucket' field (fail/pass/pending/skipping).

    Uniquifier: prefer `link` (e.g. gitlab build URL — rotates per attempt) over
    `completedAt`, which is zero-value for commit statuses (DDCI, dd-gitlab/*).
    Without this, a re-run that fails the same status name would re-use the same
    item ID and stay forever in `handled`.
    """
    result = run(
        ["gh", "pr", "checks", str(pr_number), "--json", "name,bucket,completedAt,link"],
        cwd=cwd,
    )
    if result.returncode != 0:
        return []
    try:
        checks = json.loads(result.stdout)
        items = []
        for c in checks:
            if c.get("bucket") != "fail":
                continue
            link = c.get("link") or ""
            completed = c.get("completedAt") or ""
            uniq = link or (completed if completed != _ZERO_TIME else "")
            items.append({
                "id": f"ci:{c['name']}:{pr_number}:{uniq}",
                "pr_number": pr_number,
                "type": "ci",
                "name": c["name"],
                "web_url": link,
            })
        return items
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        log.debug("Failed to parse checks for PR #%d: %s", pr_number, e)
        return []


def get_review_comments(pr_number: int, cwd: str) -> list[dict]:
    """Return non-approved reviews with non-empty bodies."""
    result = run(
        [
            "gh",
            "api",
            f"repos/:owner/:repo/pulls/{pr_number}/reviews",
            "--jq",
            '[.[] | select((.state == "CHANGES_REQUESTED" or .state == "COMMENTED") and (.body | length) > 0)'
            ' | {id: ("review:" + (.id | tostring)), author: .user.login, body, state}]',
        ],
        cwd=cwd,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return []
    try:
        return [
            {
                "id": i["id"],
                "pr_number": pr_number,
                "type": "review",
                "author": i["author"],
                "body": i["body"],
                "state": i["state"],
            }
            for i in json.loads(result.stdout)
        ]
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        log.debug("Failed to parse review comments for PR #%d: %s", pr_number, e)
        return []


def get_inline_comments(pr_number: int, cwd: str) -> list[dict]:
    """Return inline diff comments. Includes in_reply_to_id to identify agent replies."""
    result = run(
        [
            "gh",
            "api",
            f"repos/:owner/:repo/pulls/{pr_number}/comments",
            "--jq",
            '[.[] | {id: ("comment:" + (.id | tostring)), author: .user.login, body, in_reply_to_id}]',
        ],
        cwd=cwd,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return []
    try:
        return [
            {
                "id": i["id"],
                "pr_number": pr_number,
                "type": "comment",
                "author": i["author"],
                "body": i["body"],
                "in_reply_to_id": i.get("in_reply_to_id"),
            }
            for i in json.loads(result.stdout)
        ]
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        log.debug("Failed to parse inline comments for PR #%d: %s", pr_number, e)
        return []


def get_issue_comments(pr_number: int, cwd: str) -> list[dict]:
    """Return regular PR conversation comments (the bottom-of-page comment box)."""
    result = run(
        [
            "gh",
            "api",
            f"repos/:owner/:repo/issues/{pr_number}/comments",
            "--jq",
            '[.[] | {id: ("issue-comment:" + (.id | tostring)), author: .user.login, body}]',
        ],
        cwd=cwd,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return []
    try:
        return [
            {
                "id": i["id"],
                "pr_number": pr_number,
                "type": "issue-comment",
                "author": i["author"],
                "body": i["body"],
            }
            for i in json.loads(result.stdout)
        ]
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        log.debug("Failed to parse issue comments for PR #%d: %s", pr_number, e)
        return []


def check_comment_replied(item: dict, self_author: str, cwd: str) -> bool:
    """Return True if self_author has replied to this comment/review item."""
    pr = item["pr_number"]
    item_type = item["type"]
    raw_id = item["id"].split(":", 1)[1]  # strip "comment:" / "review:" / "issue-comment:" prefix

    if item_type == "comment":
        # Inline diff comment: look for a reply with in_reply_to_id == raw_id
        result = run(
            [
                "gh",
                "api",
                f"repos/:owner/:repo/pulls/{pr}/comments",
                "--jq",
                f'[.[] | select(.in_reply_to_id == {raw_id} and .user.login == "{self_author}")] | length',
            ],
            cwd=cwd,
        )
    elif item_type in ("review", "issue-comment"):
        # Issue-level comment: look for any issue comment from self_author after this item
        result = run(
            [
                "gh",
                "api",
                f"repos/:owner/:repo/issues/{pr}/comments",
                "--jq",
                f'[.[] | select(.user.login == "{self_author}")] | length',
            ],
            cwd=cwd,
        )
    else:
        return True  # CI and unknown types — not comment-based, skip check

    try:
        return int(result.stdout.strip()) > 0
    except (ValueError, AttributeError):
        return True  # on API error, assume replied to avoid infinite retry


def find_session_for_branch(branch: str, toolkit_root: Path) -> tuple[str | None, Path | None]:
    """Find the most recent Claude session that worked on the given branch.

    Looks only in the project dirs that correspond to worktrees checked out on
    that branch — not all toolkit dirs — to avoid false-positive matches from
    sessions that merely mentioned the branch name in conversation.

    Returns (session_id, worktree_path) so the caller can run claude from the
    right directory. Either value may be None if not found.
    """
    projects_dir = Path.home() / ".claude" / "projects"
    if not projects_dir.exists():
        return None, None

    # Find all worktrees checked out on this branch
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        cwd=str(toolkit_root),
        capture_output=True,
        text=True,
    )
    worktree_paths: list[Path] = []
    current_path: Path | None = None
    for line in result.stdout.splitlines():
        if line.startswith("worktree "):
            current_path = Path(line.split(" ", 1)[1])
        elif line.startswith("branch ") and current_path:
            if line == f"branch refs/heads/{branch}":
                worktree_paths.append(current_path)

    # For each matching worktree, look in its specific project dir
    # Claude slugifies paths by replacing non-alphanumeric chars with '-'
    for wt_path in worktree_paths:
        wt_slug = re.sub(r"[^a-zA-Z0-9]", "-", str(wt_path))
        wt_project_dir = projects_dir / wt_slug
        if not wt_project_dir.exists():
            continue
        jsonl_files = list(wt_project_dir.glob("*.jsonl"))
        if jsonl_files:
            best = max(jsonl_files, key=lambda f: f.stat().st_mtime)
            return best.stem, wt_path

    return None, worktree_paths[0] if worktree_paths else None


def main() -> None:
    toolkit_root = get_toolkit_root()
    state_dir = toolkit_root / ".claude" / "babysit-prs"
    state_dir.mkdir(parents=True, exist_ok=True)
    state_file = state_dir / "state.json"

    state = load_state(state_file)
    handled = set(state.get("handled", []))
    cwd = str(toolkit_root)

    prs = get_open_prs(cwd)
    if not prs:
        print(json.dumps({"new_items": [], "toolkit_root": cwd, "state_file": str(state_file)}))
        return

    new_items = []
    for pr in prs:
        pr_number = pr["number"]
        branch = pr["headRefName"]
        all_items = (
            get_checks(pr_number, cwd)
            + get_review_comments(pr_number, cwd)
            + get_inline_comments(pr_number, cwd)
            + get_issue_comments(pr_number, cwd)
        )
        for item in all_items:
            if item["id"] not in handled:
                item["branch"] = branch
                new_items.append(item)

    print(json.dumps({"new_items": new_items, "toolkit_root": cwd, "state_file": str(state_file)}))


if __name__ == "__main__":
    main()
