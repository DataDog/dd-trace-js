#!/usr/bin/env bash
# Start the babysit-prs watcher daemon in the background.
# Usage: ./start.sh [--interval SECONDS] [--once] [--init]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -f "$SCRIPT_DIR/watch.pid" ]]; then
    pid=$(cat "$SCRIPT_DIR/watch.pid")
    if kill -0 "$pid" 2>/dev/null; then
        echo "babysit-prs already running (PID $pid)"
        echo "Log: tail -f $SCRIPT_DIR/watch.log"
        exit 0
    fi
fi

# Auto-baseline on first run so existing items aren't re-dispatched
if [[ ! -f "$SCRIPT_DIR/state.json" ]]; then
    echo "First run — baselining existing items (no dispatch)..."
    python "$SCRIPT_DIR/watch.py" --init
fi

nohup python "$SCRIPT_DIR/watch.py" "$@" &>/dev/null &
echo "babysit-prs started (PID $!)"
echo "Log: tail -f $SCRIPT_DIR/watch.log"
