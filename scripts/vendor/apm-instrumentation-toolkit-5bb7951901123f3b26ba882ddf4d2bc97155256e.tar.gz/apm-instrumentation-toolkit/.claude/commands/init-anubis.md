# APM Instrumentation Toolkit - Contributor Onboarding

You are working on the **APM Instrumentation Toolkit**, which automates APM instrumentation for Datadog tracers using AI agents.

## Setup

Read these skills to get started:

1. Read `.claude/skills/contributing/SKILL.md` - Framework architecture, code style, where to add code
2. Read `.claude/skills/debugging/SKILL.md` - Log locations, common issues, troubleshooting

## For Writing Workflows

When you need to create workflows or steps, read `.claude/skills/anubis-workflow/SKILL.md` which covers:
- Step types (Step, AgentStep, CompositeStep)
- Workflow configuration
- Batching, validation, context API
- Full API references in `references/` subdirectory

## Quick Context

**Two packages:**
- `anubis/` - Generic workflow framework (language-agnostic)
- `anubis_apm/` - dd-trace specific implementations

**Lint:** `ruff check anubis/ anubis_apm/`
**Tests:** `pytest tests/`
**State:** `.analysis/{namespace}/{workflow}/`
