---
name: contributing
description: Guide for contributing to anubis core framework and anubis_apm. Use when developing new framework features, steps, workflows, or tracer support. Covers code style, architecture decisions, and where to add code.
---

# Contributing Guide

## Architecture: anubis vs anubis_apm

**anubis/** - Generic workflow framework. Language-agnostic, reusable across any domain.
- Steps, workflows, context, validation
- Agent spawning, prompt loading, skill loading
- No dd-trace or APM-specific code here

**anubis_apm/** - APM-specific implementations built on anubis.
- dd-trace workflows, steps, prompts
- Repo adapters (currently dd-trace-js, more planned)
- Domain skills for instrumentation

**Rule:** If it could work for any workflow domain, it goes in `anubis/`. If it's APM/dd-trace specific, it goes in `anubis_apm/`.

## Code Style

```python
# Imports: stdlib, third-party, local (blank line separated)
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel

from anubis.core.steps import Step
```

**Required:**
- All imports at file top (no inline imports - ruff PLC0415)
- Specific exceptions only (no bare `except:`)
- Pydantic models for all step I/O
- Type hints with generics (`Step[I, O]`)

**Lint:** `ruff check anubis/ anubis_apm/`

## anubis Core Development

### Directory Structure
```
anubis/core/
├── steps/
│   ├── step.py          # Base Step class
│   ├── agent.py         # AgentStep
│   ├── composite.py     # CompositeStep
│   └── executors/       # Step execution logic
├── workflow.py          # Workflow orchestration
├── context/             # Context API
├── experience/          # Cross-run learning (generic)
│   ├── selector.py      # RunSelector — relevance scoring
│   ├── cache.py         # ExperienceCache — local LRU cache
│   └── models.py        # ExperiencePointer
├── validation/          # Validators, fixer loop
├── config/              # ConfigLoader, get_config()
├── resources/           # PromptLoader, SkillLoader, ResourceManager
├── agents/
│   ├── spawn.py         # spawn_agent()
│   └── runners/         # Claude SDK runner
```

### Adding Core Features

**New step attribute:**
1. Add to `Step` class in `anubis/core/steps/step.py`
2. Handle in executor (`executors/`)
3. Add to `StepConfig` in `anubis/_api.py`
4. Document in skill references

**New context method:**
1. Add to `Context` in `anubis/core/context/context.py`
2. Consider state persistence implications
3. Add tests

**New validation feature:**
1. Add to `anubis/core/validation/`
2. Integrate with fixer loop if needed

### Testing Core
```bash
pytest tests/anubis/core/          # All core tests
pytest tests/anubis/core/steps/    # Step tests
```

## anubis_apm Development

### Directory Structure
```
anubis_apm/
├── workflows/           # APM workflows
├── steps/               # APM-specific steps
├── prompts/
│   └── shared/          # Shared prompts organized by workflow
│       ├── {workflow}/          # prompt.md + repo/{repo}/ for tracer content
│       └── instrumentation/    # Example: categories/, references/, repo/dd_trace_js/
├── agent/
│   └── skills/          # Domain skills (dd_trace_js/, dd_trace_py/, shared/)
├── storage/             # Experience store (S3, manifests, auth)
│   ├── s3_client.py     # S3RunStorage
│   ├── manifest.py      # RunManifest model
│   ├── auth.py          # AWS auth (boto3 + aws-vault)
│   └── workflow_hooks.py# Bootstrap, sync, push hooks
├── experience/          # Experience retrieval
│   └── retrieval.py     # ExperienceRetriever
├── repo_adapters/
│   ├── base.py          # APMAdapterMixin
│   └── dd_trace_js.py   # JS adapter
└── repo_adapters_impl/
    └── dd_trace_js/     # JS scripts, analyzers
```

### Adding a New Workflow
```python
# anubis_apm/workflows/my_workflow.py
from anubis import workflow, WorkflowConfig
from pydantic import BaseModel

class MyInput(BaseModel):
    package_name: str

class MyOutput(BaseModel):
    result: str

@workflow(WorkflowConfig(
    name="my_workflow",
    steps=[PrepareStep, AnalyzeStep, ValidateStep],
))
class MyWorkflow:
    def setup(self, ctx):
        # Initialize context
        return ctx

    def after_step(self, step_name, output, ctx):
        # Post-step hooks
        return output
```

### Adding a New Step
```python
# anubis_apm/steps/my_step.py
from anubis import agent_step, AgentStepConfig

@agent_step(AgentStepConfig(
    name="my_step",
    prompt="my-prompt",
    output_type=MyOutput,
    model="sonnet",
    skills=["datadog-semantics"],
))
class MyStep:
    def get_prompt_variables(self, input, ctx):
        return {"package": ctx.namespace}
```

### Adding Prompts

Prompts are organized as self-contained directories under `anubis_apm/prompts/shared/`:

```
shared/my-workflow/
├── prompt.md              # Main template (language-agnostic)
└── repo/
    └── dd_trace_js/       # JS-specific fragments
        └── patterns.md    # Auto-included via {{include_repo:patterns}}
```

```markdown
<!-- anubis_apm/prompts/shared/my-workflow/prompt.md -->

Analyze {{package_name}} for instrumentation targets.

## Language-Specific Patterns
{{include_repo:patterns}}

{{output_schema}}
```

**Directives:**
- `{{include_repo:name}}` — includes `repo/{repo}/name.md` relative to the template directory. Silently removed if the file doesn't exist (graceful degradation for new tracers).
- `{{include:path}}` — inlines another template (recursive, relative to prompts root)
- `{{link:path|label}}` — inserts a markdown link for on-demand reading by agents

Variables injected automatically: `output_schema`, `package_name`, `namespace`

### Adding New Tracer Support

1. Create adapter in `anubis_apm/repo_adapters/my_tracer.py`:
```python
class MyTracerAdapter(RepoAdapter, APMAdapterMixin):
    def get_plugin_path(self, name: str) -> str:
        return f"src/integrations/{name}/"

    def get_test_file_path(self, name: str) -> str:
        return f"test/{name}/index.spec.js"

    def get_test_command(self, name: str, output_dir=None) -> str:
        return f"npm test -- --grep {name}"

    def setup_tracing_precheck(self, integration_name: str, ctx) -> None:
        """Set tracing_plugin_path and tracing_test_command in context."""
        repo_root = get_config().get_repo_root(ctx.repository)
        ctx.set("tracing_plugin_path", str(repo_root / self.get_plugin_path(integration_name)))
        ctx.set("tracing_test_command", self.get_test_command(integration_name))
```

2. Add repo-specific prompt fragments: `anubis_apm/prompts/shared/{workflow}/repo/my_tracer/`
3. Create skills: `anubis_apm/agent/skills/my_tracer/`
4. Register adapter in factory

### Experience Store / Storage

S3-backed storage of workflow run artifacts. Two separate concerns:

1. **S3 sync (always on)** — Every workflow pushes results to S3 and pulls relevant past runs at startup. Managed in `anubis_apm/storage/`.
2. **Experience injection (opt-in)** — Past run outputs injected into agent prompts via `--experience` flag. Generic rendering in `anubis/core/resources/prompts.py` (`_build_experience_section`).

**Key files:**
- `anubis_apm/storage/s3_client.py` — `S3RunStorage` (upload/download/index)
- `anubis_apm/storage/manifest.py` — `RunManifest` Pydantic model
- `anubis_apm/storage/workflow_hooks.py` — `bootstrap_experience()`, `push_run_to_s3()`
- `anubis_apm/storage/auth.py` — AWS auth helpers
- `anubis/core/experience/selector.py` — `RunSelector` (generic relevance scoring)
- `anubis/core/experience/cache.py` — `ExperienceCache` (local LRU)
- `anubis/core/resources/prompts.py` — `_build_experience_section()` (prompt rendering)
- `anubis_apm/cli/commands/sync.py` — `dd-apm sync` CLI commands

**Architecture rule:** Generic experience scoring/cache lives in `anubis/core/experience/`. S3 client, manifests, auth, and workflow hooks live in `anubis_apm/storage/`. Experience retrieval logic is in `anubis_apm/experience/`.

### Testing APM
```bash
pytest tests/anubis_apm/           # All APM tests
pytest tests/anubis_apm/workflows/ # Workflow tests
```

## State Location

```
.analysis/{namespace}/{workflow}/
├── state.json       # Checkpoints, metrics
├── artifacts/       # Named artifacts
└── steps/{name}-{attempt}/
    ├── input.json
    ├── output.json
    └── logs/
```

Clean: `dd-apm clean <package>`

## Claude Code Plugin

The toolkit ships a Claude Code plugin at `plugin/` that lets developers drive workflows interactively without leaving their editor. If you're modifying workflow steps, step descriptions, or the CLI, update the plugin skill as well:

- `plugin/skills/drive-toolkit/SKILL.md` — orchestration spine (setup, workflow choice, pause rules)
- `plugin/skills/drive-toolkit/references/step-review.md` — per-step review guidance
- `plugin/skills/drive-toolkit/references/monitoring.md` — background monitoring, failure recovery

Install the plugin locally to test changes:
```bash
claude plugin install ./plugin
```

## PR Checklist

- [ ] `ruff check` passes
- [ ] No inline imports
- [ ] No bare except blocks
- [ ] Pydantic models for step I/O
- [ ] Tests for new functionality
- [ ] Core changes are language-agnostic
- [ ] APM changes in anubis_apm/
- [ ] Plugin skill updated if workflow steps or CLI changed
