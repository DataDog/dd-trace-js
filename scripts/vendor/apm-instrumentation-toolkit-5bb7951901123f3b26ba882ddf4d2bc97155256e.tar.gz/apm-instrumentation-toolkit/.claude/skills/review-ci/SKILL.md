---
name: review-ci
description: >
  Review CI results for the current branch, commit, or PR — both GitLab CI
  (gitlab.ddbuild.io) and GitHub Actions. Identifies failed jobs and tests,
  checks for flakes, and gives actionable fix instructions. Also supports
  triggering or replaying CI jobs. Use when CI is failing, when you need to
  understand what's blocking a PR, or to autonomously iterate on fixes.
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
  - Grep
  - Glob
  - mcp__datadog-mcp__get_prs_by_head_branch
  - mcp__datadog-mcp__search_pr_insights
  - mcp__datadog-mcp__search_datadog_ci_pipeline_events
  - mcp__datadog-mcp__aggregate_datadog_ci_pipeline_events
  - mcp__datadog-mcp__search_datadog_test_events
  - mcp__datadog-mcp__aggregate_datadog_test_events
  - mcp__datadog-mcp__get_datadog_flaky_tests
  - mcp__datadog-mcp__search_datadog_logs
  - mcp__datadog-mcp__get_datadog_code_coverage_branch_summary
  - mcp__datadog-mcp__get_datadog_code_coverage_commit_summary
---

# CI Review Skill — APM Instrumentation Toolkit

Review CI for the toolkit repo, identify failures, and autonomously fix + re-trigger.

## Prerequisite: Datadog MCP

This skill requires the Datadog MCP. Check if `mcp__datadog-mcp__*` tools are
available. If NOT, instruct the user:

```
claude mcp add --transport http datadog-mcp \
  "https://mcp.datadoghq.com/api/unstable/mcp-server/mcp?toolsets=core,software-delivery"
```

## Repository constants

```
GITHUB_REPO_URL = https://github.com/DataDog/apm-instrumentation-toolkit
GITHUB_REPO_ID  = github.com/datadog/apm-instrumentation-toolkit   # lowercase, no scheme
GITLAB_PROJECT  = DataDog/apm-instrumentation-toolkit
GITLAB_BASE_URL = https://gitlab.ddbuild.io
GITLAB_API_BASE = https://gitlab.ddbuild.io/api/v4
GITLAB_PROJECT_ID = <resolve via API if needed — see Step 0>
```

## Step 0: Resolve the target

If the user supplied a GitLab job URL like `https://gitlab.ddbuild.io/.../jobs/<id>`:
- Extract the job ID directly and skip to Step 3.

Otherwise, resolve from git:

```bash
git rev-parse --abbrev-ref HEAD   # branch
git rev-parse HEAD                # full commit SHA
```

Resolve the GitLab project ID (needed for API calls):

```bash
# URL-encode the project path
PROJECT_ENCODED="DataDog%2Fapm-instrumentation-toolkit"
curl -fsSL "${GITLAB_API_BASE}/projects/${PROJECT_ENCODED}" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN:-}" | jq .id
```

If `GITLAB_TOKEN` is not set, try authanywhere:

```bash
authanywhere -output-token gitlab 2>/dev/null
```

## Step 1: Find the PR (if not already known)

```
get_prs_by_head_branch:
  repo_url    = https://github.com/DataDog/apm-instrumentation-toolkit
  head_branch = <branch>
```

Pick the most recent open PR.

## Step 2: Get failed CI jobs

### Via Datadog MCP (preferred — surfaces both GitLab and GitHub Actions)

```
search_datadog_ci_pipeline_events:
  query    = @git.commit.sha:<full_sha> @ci.status:error
  ci_level = job
  from     = now-7d
  sort     = -timestamp
```

Note `pipeline_name` per failure:
- Contains `apm-instrumentation-toolkit` → **GitLab CI**
- `Build`, `Smoke`, `Eval`, etc. → **GitHub Actions** (unlikely; toolkit uses GitLab)

### Via GitLab API (direct — useful when you have a specific job ID from a URL)

```bash
# Get a single job
curl -fsSL "${GITLAB_API_BASE}/projects/${PROJECT_ID}/jobs/${JOB_ID}" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}" | jq '{name,status,stage,web_url,started_at,finished_at}'

# List failed jobs for the latest pipeline on a branch
curl -fsSL "${GITLAB_API_BASE}/projects/${PROJECT_ID}/pipelines?ref=${BRANCH}&status=failed&per_page=5" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}" | jq '.[0].id'

PIPELINE_ID=<id>
curl -fsSL "${GITLAB_API_BASE}/projects/${PROJECT_ID}/pipelines/${PIPELINE_ID}/jobs?scope[]=failed" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}" | jq '.[] | {id,name,status,stage,web_url}'
```

## Step 3: Get detailed job logs

### GitLab job logs via Datadog (preferred — indexed, searchable)

```
search_datadog_logs:
  query = @ci.job.id:<job_id>
  from  = <job start time>
  to    = <job end time + 1h>
  sort  = timestamp
```

If 0 results, retry with `storage_tier=flex_and_indexes`.

### GitLab job logs via API (fallback — raw trace)

```bash
curl -fsSL "${GITLAB_API_BASE}/projects/${PROJECT_ID}/jobs/${JOB_ID}/trace" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}" | tail -200
```

### GitHub Actions logs (not in Datadog)

```bash
gh run list --commit <sha> --json databaseId,name,status,conclusion
gh run view <databaseId> --log-failed
```

## Step 4: Get failed test events

```
search_datadog_test_events:
  query      = @git.commit.sha:<head_sha> @test.status:fail
  test_level = test
  from       = now-7d
  page_limit = 10
```

Key fields: `test.name`, `test.suite`, `test.source.file`, `error.message`,
`test.is_known_flaky` (true → pre-existing noise, skip).

## Step 5: PR insights

```
search_pr_insights:
  repo_url  = https://github.com/DataDog/apm-instrumentation-toolkit
  pr_number = <pr_number>
```

## Step 6: Fix and re-trigger (autonomous loop)

After diagnosing failures, fix the root cause, commit, push, then re-trigger:

### Retry/play a failed manual job via GitLab API

```bash
# Retry a failed job
curl -X POST -fsSL \
  "${GITLAB_API_BASE}/projects/${PROJECT_ID}/jobs/${JOB_ID}/retry" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}"

# Play a manual job
curl -X POST -fsSL \
  "${GITLAB_API_BASE}/projects/${PROJECT_ID}/jobs/${JOB_ID}/play" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}"
```

### Trigger a new pipeline on a branch

```bash
curl -X POST -fsSL \
  "${GITLAB_API_BASE}/projects/${PROJECT_ID}/pipeline" \
  -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}" \
  -F "ref=${BRANCH}"
```

### Poll until job completes

```bash
while true; do
  STATUS=$(curl -fsSL "${GITLAB_API_BASE}/projects/${PROJECT_ID}/jobs/${JOB_ID}" \
    -H "PRIVATE-TOKEN: ${GITLAB_TOKEN}" | jq -r .status)
  echo "Job ${JOB_ID}: ${STATUS}"
  case "$STATUS" in
    success|failed|canceled|skipped) break ;;
    *) sleep 60 ;;
  esac
done
```

## Step 7: Present actionable summary

### Overall status
One line: "X GitLab job failures, Y test failures (Z known-flaky)."

### Failed jobs
For each non-flaky failure:

```
**[Job name]** (stage: <stage>, <duration>s)
Root cause: <extracted error>
Files affected: <paths and line numbers>
Fix: <concrete command or action>
```

### Known-flaky (noise — no action needed)
List briefly.

## Getting a GitLab token

If `GITLAB_TOKEN` is not available in the environment, try:

```bash
# Option 1: authanywhere (Datadog internal)
authanywhere -output-token gitlab 2>/dev/null

# Option 2: check shell env
echo $GITLAB_TOKEN

# Option 3: glab auth (if glab CLI is installed)
glab auth status
glab auth token
```

If none work, ask the user to run `glab auth login --hostname gitlab.ddbuild.io` or
set `GITLAB_TOKEN` manually.
