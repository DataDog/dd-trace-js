---
name: harness-feedback
description: Analyze workflow runs, PR reviews, eval results, and code diffs to identify
  and fix issues in the toolkit's prompts, skills, hooks, and validators. Use after
  runs produce suboptimal results, after PR reviews surface recurring issues, after
  eval failures, or proactively to improve quality. Triggers on "improve the harness",
  "feedback loop", "analyze run", "fix prompts from PR feedback", "why did the agent
  do X wrong".
---

# Harness Feedback

Analyze quality signals from workflow runs, PR reviews, and evaluations. Trace issues to root causes in the harness (prompts, skills, hooks, validators). Apply targeted fixes.

## Orchestration Strategy

Use subagents for heavy context reading to keep main context clean for analysis and fixes.

**Delegate these to subagents:**
- "Read state.json and agent logs at `<path>`. Summarize: which steps failed, high iteration counts, errors, and what the agent seemed confused about."
- "Read PR comments and CI results for `<url>`. List each actionable comment with the file/line it references."
- "Read eval report at `<path>`. List failed checks with details."
- "Diff the agent's auto-committed code `<sha>` against merged code. For each changed file, explain what was corrected."

**Keep in main context:** Root cause analysis, tracing issues to harness components, applying fixes, verification.

## Toolkit Layout

| Component | Location |
|-----------|----------|
| Prompt templates | `anubis_apm/prompts/shared/{workflow}/prompt.md` |
| Repo-specific fragments | `anubis_apm/prompts/shared/{workflow}/repo/{repo}/` |
| Category-specific guidance | `anubis_apm/prompts/shared/instrumentation/categories/` |
| Domain skills (per-repo) | `anubis_apm/agent/skills/{repo}/` |
| Domain skills (shared) | `anubis_apm/agent/skills/shared/` |
| Agent hooks | `anubis_apm/agent/hooks/` |
| Reviewer checks | `anubis_apm/workflows/reviewer_checks/` |
| Generic validators | `anubis/core/validation/` |
| Repo adapters + code gen | `anubis_apm/repo_adapters_impl/{repo}/` (e.g., `dd_trace_js/dd-generate/`) |
| Integration categories | `anubis_apm/constants/integration_categories.json` |
| Toolkit dev skills | `.claude/skills/` |
| Target repo skills | `{target_repo}/.claude/skills/` |

## Workflow

1. **Gather context** -- Spawn subagents to read each source. Collect summaries.
2. **Analyze** -- Follow the [analysis checklist](references/analysis-checklist.md).
3. **Trace to root cause** -- Map each issue to a harness component.
4. **Apply fixes** -- Follow the [improvement patterns](references/improvement-patterns.md).
5. **Verify** -- Run `ruff check anubis/ anubis_apm/` and `pytest tests/` after changes.

## Evidence-First Rule (CRITICAL)

**Never apply a fix without first finding the actual code/content responsible for the issue.**

Every signal (PR comment, agent error, eval failure) points to a *symptom*. Before changing anything, you MUST trace back to the *cause* — the specific line, file, or missing instruction in the harness that produced the bad behavior.

### How to find evidence

1. **Keyword grep across the entire toolkit.** Don't accept the first match. Search broadly:
   - `grep -r "orchestration" anubis_apm/` — find ALL files mentioning the concept
   - `grep -r "ci-workflow\|apm-integrations" anubis_apm/` — find where CI routing happens
   - `find anubis_apm -name "*.md" -path "*/categories/*"` — check if category-specific content already exists
2. **Read the actual code path.** If the agent generated wrong code, find the code generator, prompt, or skill that guided it. For dd-trace-js, code generation lives in `anubis_apm/repo_adapters_impl/dd_trace_js/dd-generate/` — not in skills.
3. **Verify content doesn't already exist.** Before adding content to a skill or prompt, search for it. The toolkit has category-specific guidance in `prompts/shared/instrumentation/categories/`, repo-specific fragments in `prompts/shared/{workflow}/repo/{repo}/`, and per-repo skills. Content duplication causes drift.
4. **Be skeptical.** If you can't find the harness component that caused the issue, it may be a one-off agent judgment error — not worth a harness change. Don't invent fixes for problems you can't trace.

### Subagent evidence gathering

When delegating to subagents, require them to return **specific file paths and line numbers**, not summaries. Example prompts:
- "Find every file in `anubis_apm/` that mentions orchestration. Return full paths."
- "Find the code that decides which CI workflow file a new integration goes into. Return the file path and the relevant function."
- "Search for existing category-specific instrumentation guidance in `anubis_apm/prompts/shared/instrumentation/categories/`. List all files."

## Fix Priority Order

**Code generators and mechanical enforcement before prompt additions.**

Prompt additions are fragile (the agent may not read them), cumulative (context grows monotonically), and duplicative (same lesson ends up in multiple files). Structural fixes are enforced regardless of whether the agent reads anything.

Priority, highest to lowest:

1. **Code generator fix** — wrong file name, wrong base class selection, missing category in `integration_categories.json`. If the generator produces it wrong every time, fix the generator.
2. **Hook or validator** — enforces rules mechanically. Use when agents repeatedly ignore a prompt instruction (PostToolUse hook) or when output can be validated structurally (validator).
3. **Review skill update** — route reviewer lessons into the repo's review skill (`anubis_apm/agent/skills/{repo}/review/` or similar), not into generation prompts. This centralizes quality knowledge and keeps it data-driven. **This is the primary output of feedback analysis.**
4. **Prompt/skill content change** — only for domain knowledge the model genuinely lacks (Datadog-specific semantic conventions, dd-trace-js internal APIs). General programming knowledge ("extract utils", "avoid inheritance") belongs in the review skill or nowhere — if the model keeps getting it wrong, the root cause is wrong reference integrations or conflicting examples, not missing prompt text.

### Decision Tree

Before making any change, work through this in order:

1. **Can this be fixed in the code generator?** (wrong output every run, not a judgment call) → Fix `repo_adapters_impl/{repo}/dd-generate/` or `integration_categories.json`.
2. **Can this be enforced mechanically?** (file protection, output shape, AST check) → Add a hook or validator.
3. **Is this domain knowledge the model genuinely cannot infer from pre-training or from reading the codebase?** Fill in: "The model cannot know this because ___." If the blank is hard to fill, this is not a prompt addition — it's a review skill entry or nothing.
4. **Is this general programming knowledge?** → Investigate root cause (wrong reference integrations? conflicting examples? context overload?). Adding "remember to X" to a prompt won't fix it if the model is copying a bad pattern from a reference integration.

## Rules

- **Evidence first** — never change a file without identifying WHY the current content caused the issue. If unsure, skip it.
- Never restructure or refactor existing code — make minimal, targeted changes.
- **One lesson, one location** — if a fix applies to a concept that appears in multiple files, pick the single most authoritative location. Cross-reference from others if needed; never duplicate.
- **Net-zero line budget for prompt/skill changes** — when adding content, remove equivalent content (outdated guidance, duplicated instructions, verbose examples). Information density, not line count, is the goal — but the constraint forces conscious trimming.
- **Prompt additions require explicit justification** — before adding any line to a prompt or skill, state: "The model cannot know this from pre-training or from reading the codebase because ___." If the blank can't be filled convincingly, skip the change.
- Don't add large code blocks to skills — use `{{link:path|label}}` pointers.
- **Search before adding** — always search the toolkit for existing content before creating new content. Duplicate content drifts.
- Keep changes scoped: repo-specific issues go to `repo/{repo}/` fragments or `skills/{repo}/`. Shared issues go to shared prompts/skills.
- **Fix the source, not the symptom** — if the agent generated wrong code, fix the code generator or its input prompt, not just the reviewer guidelines.
- Run ruff + tests after every change.
