# Analysis Checklist

Step-by-step framework for analyzing quality signals and tracing them to root causes.

## 1. Gather Context

Spawn subagents to read each source type. Collect structured summaries before analyzing.

## 2. Read Run State

From subagent summary of `state.json`:
- Which steps failed or had errors?
- Which steps had high iteration counts (agent looping)?
- What was the total cost and duration? Unusual?

## 3. Read Agent Logs

From subagent summary of `steps/*/logs/agent.log`:
- Did the agent loop on the same action repeatedly?
- Did it edit wrong files or create files in wrong locations?
- Did it ignore instructions from prompts or skills?
- Where did it seem confused or stuck?

## 4. Read Step Outputs

Check `steps/*/output.json` for:
- Incomplete or structurally wrong output
- Missing fields the downstream steps expect
- Output that doesn't match the Pydantic model

## 5. Read PR Feedback (if provided)

From subagent summary of PR comments:
- Map each review comment to what the agent did or didn't do
- Categorize: wrong code, missing code, style issue, wrong file, logic error
- Note which comments are recurring across PRs (systemic vs one-off)

## 6. Read Code Diff (if available)

From subagent summary comparing agent's auto-committed code vs merged PR:
- Each human correction reveals what the agent got wrong
- This is the **strongest signal** -- it shows exactly what needed fixing
- Categorize corrections: missing import, wrong API usage, bad pattern, missing feature

## 7. Trace to Root Cause (EVIDENCE REQUIRED)

**For each issue, you MUST find the specific harness file responsible before proposing a fix.**

### 7a. Find the actual source

Use subagents to grep broadly across the toolkit. Don't guess — find it:
- If the agent generated wrong code → find the code generator (`repo_adapters_impl/`) or prompt that guided it
- If the agent put content in the wrong place → search for where similar content already exists
- If a category/feature is missing → check `integration_categories.json`, `prompts/shared/instrumentation/categories/`, and existing skills
- If the agent ignored an instruction → find the exact instruction in the prompt/skill and verify it was actually loaded

### 7b. Verify no duplication

Before adding content anywhere, search the toolkit:
```
grep -r "<keyword>" anubis_apm/prompts/ anubis_apm/agent/skills/ anubis_apm/constants/
```
If content already exists, update it — don't duplicate it in a second location.

### 7c. Classify the cause

| Cause | Evidence needed | Action |
|-------|----------------|--------|
| Instruction missing from prompt/skill | Show the prompt/skill that SHOULD have it but doesn't | Add it there |
| Instruction present but agent ignored | Show the exact line the agent should have followed | Make more prominent, consider hook |
| Instruction wrong or outdated | Show the outdated line and what it should say | Fix it |
| Code generator bug | Show the generator code that produces wrong output | Fix the generator |
| Agent lacked domain knowledge | Show what knowledge was missing and where it should live | Add to most specific location |
| Agent used wrong pattern for this repo | Show the pattern mismatch | Add to repo-specific fragment |
| One-off judgment call, not systemic | Explain why this isn't worth a harness change | **Skip it** |
| Can't find the root cause | Insufficient evidence | **Skip it — don't guess** |

### 7d. Be skeptical

- If you can't identify the specific harness file that caused the issue, **do not make a change**
- If the fix is adding content that looks similar to existing content elsewhere, **you're probably duplicating — find and update the original**
- If the agent's mistake seems like a reasonable judgment call given what it knew, **skip it**

## 8. Determine Scope

- **Repo-specific** issues: Fix in `repo/{repo}/` prompt fragments or `skills/{repo}/`
- **Shared/cross-repo** issues: Fix in shared prompts or `skills/shared/`
- **Code generator** issues: Fix in `repo_adapters_impl/{repo}/` — this is where code generation logic lives, not in skills
- **Framework** issues (rare): Fix in `anubis/core/` only if truly generic
