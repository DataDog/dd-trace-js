# Improvement Patterns

How to fix each harness component type when a root cause is identified.

## Fix Patterns by Component

| Component | Location | How to Fix |
|-----------|----------|------------|
| Prompt template | `anubis_apm/prompts/shared/{workflow}/prompt.md` | Add or clarify instruction. Use `{{include_repo:}}` for repo-specific content. |
| Repo prompt fragment | `anubis_apm/prompts/shared/{workflow}/repo/{repo}/` | Add new `.md` file or update existing. Referenced via `{{include_repo:name}}`. |
| Domain skill (per-repo) | `anubis_apm/agent/skills/{repo}/{name}/SKILL.md` | Add instruction to SKILL.md or detail to `references/`. |
| Domain skill (shared) | `anubis_apm/agent/skills/shared/{name}/SKILL.md` | Add cross-repo knowledge. |
| Target repo skill | `{target_repo}/.claude/skills/{name}/SKILL.md` | Fix in the target repo, not the toolkit. |
| Agent hook | `anubis_apm/agent/hooks/{scope}/` | Add or fix PreToolUse/PostToolUse hook. |
| Reviewer check | `anubis_apm/workflows/reviewer_checks/` | Add or fix check YAML config. |
| Validator | `anubis/core/validation/` | Add validation rule (only if truly generic). |

## Fix Priority

See the priority order and decision tree in [SKILL.md](../SKILL.md#fix-priority-order) — apply the first fix type that applies.

## Guidelines

### Code Generator Fixes
- dd-trace-js code generation lives in `anubis_apm/repo_adapters_impl/dd_trace_js/dd-generate/` — fix bugs there, not in skills or prompts
- Category-specific instrumentation guidance already exists in `anubis_apm/prompts/shared/instrumentation/categories/` — update it, don't duplicate into skills
- Integration metadata lives in `anubis_apm/constants/integration_categories.json` — add categories there

### Hook Changes
- Hooks enforce rules mechanically -- use when agents repeatedly ignore a prompt instruction
- PreToolUse hooks can block dangerous operations
- PostToolUse hooks can validate outputs

### Review Skill Updates
- The review skill is the primary home for reviewer lessons mined from PR feedback
- Keeps quality knowledge centralized, data-driven, and out of generation prompts
- Add entries for recurring patterns: wrong base class, non-idiomatic test assertions, unnecessary tags, etc.
- Note the limitation: review skills feed into the reviewer step (post-generation), not into primary generation. For patterns the generation agent repeatedly gets wrong, also fix the code generator or reference integrations.

### Prompt / Skill Changes
- Add to the most specific location (repo-specific fragment > shared fragment > skill)
- Use `{{include_repo:name}}` to pull repo-specific patterns — don't put repo-specific code in shared prompts
- Use `references/` for detailed content, keep SKILL.md lean
- Don't paste production code — use `{{link:path|label}}` pointers so agents read actual source

### When NOT to Change the Harness
- **Can't find the root cause** — if you can't identify the specific file that caused the issue, don't make a change
- **Content already exists elsewhere** — if you're about to add content that looks like something in `categories/`, `skills/`, or `repo/`, you're duplicating. Find and update the original.
- **General programming knowledge** — "don't create unnecessary inheritance", "extract utils". The model knows this; investigate why it's losing (wrong reference integrations? conflicting examples?) rather than adding reminder text.
- One-off judgment calls that aren't systemic
- Issues already fixed by other changes in the same PR
- Style preferences that vary by reviewer
- Problems in user-provided input, not agent behavior
