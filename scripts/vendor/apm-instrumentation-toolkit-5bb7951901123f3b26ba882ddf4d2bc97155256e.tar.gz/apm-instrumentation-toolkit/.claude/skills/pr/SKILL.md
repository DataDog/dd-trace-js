---
name: pr
description: >
  Create and update GitHub pull requests with well-structured descriptions.
  Use when asked to open a PR, submit changes for review, or when a workflow
  completes and changes need to be proposed. Handles draft PRs, existing PR
  detection, branch management, and PR description generation. Triggers:
  "open a pr", "create a pull request", "submit for review", "/pr".
---

# PR Creation Skill

Create well-structured GitHub pull requests using `gh` CLI.

## Workflow

### 1. Determine Context

This skill works in two contexts:
- **Toolkit PRs** — changes to this repository (anubis/, anubis_apm/, etc.). Do **not** add the `apm-integration-toolkit` label to these.
- **Target repo PRs** — changes made by workflows to target repositories (dd-trace-js, dd-trace-py, etc.). **Always** add both `ai-generated` and `apm-integration-toolkit` labels to these — `apm-integration-toolkit` powers the observability dashboard PR tracking.

Determine which repo you're creating a PR for based on the current working directory and what the user is asking.

### 2. Pre-flight Checks

```bash
# Detect default branch
DEFAULT_BRANCH=$(git symbolic-ref refs/remotes/origin/HEAD 2>/dev/null | sed 's@^refs/remotes/origin/@@') || DEFAULT_BRANCH="main"

# Must be on a non-default branch
git branch --show-current  # Should NOT be $DEFAULT_BRANCH

# No uncommitted changes (commit or stash first)
git status --porcelain

# Must have commits ahead of base
git log ${DEFAULT_BRANCH}..HEAD --oneline  # Must have output
```

If no commits ahead, warn the user and stop.

### 3. Detect Existing PR

```bash
gh pr view --json number,title,body,isDraft 2>/dev/null
```

- If a PR exists → **update flow** (use `gh pr edit`)
- If no PR exists → **create flow**

### 4. Generate PR Content

**Title:** Conventional commit style (`feat(scope): description`), under 70 characters.

**Description:** Check the **target repo's** `.github/pull_request_template.md` first — if it exists, use that structure. Also check for a CLAUDE.md in the target repo for PR conventions. Otherwise use:

```markdown
🤖 Generated with [APM Instrumentation Toolkit](https://github.com/DataDog/apm-instrumentation-toolkit)

## Summary
<1-3 bullet points: what changed and why>

## Test plan
<How to verify the changes>

🤖 Generated with [APM Instrumentation Toolkit](https://github.com/DataDog/apm-instrumentation-toolkit)
```

Always include the AI attribution both at the top and bottom of the PR description.

**Agent session:** Include a short `## Agent session` section so the PR author can find the agent run and, when the CLI supports it, restart the same session.

```markdown
## Agent session

- Start command:
```bash
<exact command, or "not available from this agent runtime">
```
```

Capture the command from the current agent runtime without assuming a specific CLI. Prefer explicit metadata if available (session id, transcript path, resume command, or start command). Do not stop at the process command line when a conversation id can be discovered from the agent's local state.

For Codex, check `~/.codex/history.jsonl` for the current or most recent matching user prompt/cwd, then check the matching `~/.codex/sessions/**/rollout-*.jsonl` `session_meta`. When a Codex session id is available, record `codex resume <session_id>` as the start command. For Claude, prefer exposed resume/session metadata or local transcript paths, and use the CLI's documented resume form when known. For other CLIs such as `pi`, use their documented resume command if a session id is exposed.

If a session id is not discoverable after those checks, record `not available` and say what was checked. Otherwise inspect the local process command line and record the observed invocation. Support any agent CLI name, including `codex`, `claude`, `pi`, or another binary. Do not invent a resume command if only the generic start command is visible. Never include tokens, API keys, prompts containing secrets, absolute local filesystem paths, home directories, usernames, transcript paths, or working-directory paths unless the user explicitly requests them.

**Trace links:** If workflow trace URLs are available in `.analysis/` state or context, include:

```markdown
## Observability
- [APM Trace](<apm_trace_url>)
- [LLMObs Trace](<llmobs_trace_url>)
```

Only include whichever are available — don't block PR creation if absent.

**References:** Check for repo-specific requirements in this skill's `references/` directory. Load the matching file if the current repo has one.

### 5. Create or Update

```bash
# Create label (ignore error if exists)
gh label create apm-integration-toolkit --description "PR created by the APM Instrumentation Toolkit" --color "8B5CF6" 2>/dev/null || true

# Push branch with tracking
git push -u origin HEAD

# Create (default to draft) — ALWAYS include the apm-integration-toolkit label
gh pr create --draft --title "<title>" --body "<body>" --label "ai-generated" --label "apm-integration-toolkit"

# Or update existing
gh pr edit <number> --title "<title>" --body "<body>"

# Add label (required on every toolkit PR — used for dashboard PR tracking)
gh pr edit --add-label apm-integration-toolkit
```

> **Required:** The `apm-integration-toolkit` label **must always be set** on every PR created or updated by the toolkit in **target repos** (dd-trace-js, dd-trace-py, etc.). It is used by the observability dashboard to track open and merged PRs across repos. Never omit it.
>
> **Do NOT apply this label to PRs in the toolkit repo itself** (`apm-instrumentation-toolkit`). Those are internal development PRs and should not appear on the dashboard.

### 6. Review Cycle (automatic — do not skip)

Immediately after creating or updating the PR, run these steps without asking:

1. **Run `/code-review <pr-number>`** to get Claude review
2. **Check CI status:** `gh pr checks <number>`
3. **Fix all issues** found by review and CI — commit, push, and re-check
4. **Check for reviewer comments** (Codex, humans, bots):
   - `gh api repos/{owner}/{repo}/pulls/{number}/comments` for inline comments
   - `gh api repos/{owner}/{repo}/pulls/{number}/reviews` for review summaries
5. **Respond to all comments** with explanations + reactions
6. Repeat until clean

### 7. After Pushing Review Fixes

When pushing changes to address PR review feedback:

1. **ALWAYS comment on the PR** immediately after pushing using `gh pr comment <number>`
2. **List each issue addressed** with:
   - Issue number or description from the review
   - Specific fix applied with code snippets
   - File/line references where changes were made
   - Verification steps or test results confirming the fix
3. **Use clear formatting** with checkmarks (✅), code blocks, and section headers
4. **Comment immediately after pushing** — don't wait or batch multiple pushes

This helps reviewers quickly understand what's been fixed without having to dig through commit diffs.

### 8. Safety Rules

- **Always default to `--draft`** unless user explicitly says "ready for review"
- **Check for existing PR** before creating (no duplicates)
- **Never force-push**
- **Confirm with user** before creating non-draft PRs
- Engineers are responsible for PRs they open and maintaining the resulting code
