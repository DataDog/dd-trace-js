# Toolkit PR Requirements

Requirements specific to the `apm-instrumentation-toolkit` repository.

## PR Description as Specification

- **Intent:** What problem does this solve? What's the goal?
- **Changes:** What was modified and why each change was necessary
- **Architecture:** If touching `anubis/` vs `anubis_apm/`, explain the separation rationale

## Documentation Checklist

- Was `CLAUDE.md` updated if behavior/commands/architecture changed?
- Were agent skills (`.claude/skills/`) updated if workflows or patterns changed?
- Were docstrings updated for new/changed public APIs?
- Was `docs/` (Sphinx) updated if applicable?

## Review Process

- Codex review runs automatically on toolkit PRs
- Run `/code-review <pr-number>` manually
- Address ALL findings from both reviewers (don't filter by score — fix them)
- Reply to every comment with explanation + reaction

## Testing

Include in PR description:

```
## Test plan
- [ ] `pytest tests/` passes
- [ ] `ruff check anubis/ anubis_apm/` is clean
- [ ] <specific test steps for these changes>
```

## Commit Style

- Conventional commits: `feat(scope):`, `fix(scope):`, `refactor(scope):`, etc.
- GPG signed (never `--no-gpg-sign`)
