---
name: debugging
description: Guide for debugging anubis workflows and agent steps. Use when a workflow fails, an agent produces incorrect output, or you need to understand what happened. Covers log locations, common issues, and troubleshooting steps.
---

# Debugging Workflows

## Log & State Locations

```
.analysis/{namespace}/{workflow}/
├── state.json              # Workflow state, checkpoints, metrics
├── input.json              # Workflow input
├── output.json             # Workflow output (if completed)
├── artifacts/              # Named artifacts from steps
└── steps/
    └── {step_name}-{attempt}/
        ├── input.json      # Step input
        ├── output.json     # Step output
        └── logs/
            └── agent.log   # Agent conversation transcript
```

**Quick access:**
```bash
# View workflow state
cat .analysis/kafkajs/new_integration/state.json | jq .

# View step output
cat .analysis/kafkajs/new_integration/steps/analyze-1/output.json | jq .

# Read agent transcript
cat .analysis/kafkajs/new_integration/steps/analyze-1/logs/agent.log
```

## Common Issues

### Workflow Won't Start

**Symptom:** Error on workflow initialization

**Check:**
1. Is `DD_TRACER_REPO` set? Points to dd-trace-js repo root
2. Is `ANTHROPIC_API_KEY` set?
3. Does `.analysis/` directory exist and have write permissions?

### Step Fails Validation

**Symptom:** `ValidationError` after step completes

**Debug:**
1. Check step output: `.analysis/{ns}/{wf}/steps/{step}-{attempt}/output.json`
2. Check validators defined on the step
3. Look for fixer attempts in subsequent `-{attempt}` directories

**Fix:**
- Adjust validators if too strict
- Improve prompt to produce valid output
- Add `validation_required=False` to skip (temporary)

### Agent Runs Out of Turns

**Symptom:** `max_turns reached` error

**Debug:**
1. Read agent transcript: `steps/{step}/logs/agent.log`
2. Look for loops, repeated actions, or confusion

**Fix:**
- Increase `max_turns` in step config
- Simplify prompt - agent may be over-exploring
- Add skills to provide domain knowledge
- Use `step_configs` to override at runtime:
  ```python
  wf = MyWorkflow(step_configs={'analyze': {'max_turns': 100}})
  ```

### Agent Produces Wrong Output

**Symptom:** Output doesn't match expected schema or content

**Debug:**
1. Read agent transcript to understand reasoning
2. Check prompt template for clarity
3. Verify `output_schema` is injected correctly

**Fix:**
- Clarify prompt instructions
- Add examples to prompt
- Add/improve validators to catch issues
- Load relevant skills for domain knowledge

### Workflow Stuck / Won't Resume

**Symptom:** Workflow hangs or re-runs completed steps

**Debug:**
1. Check `state.json` for checkpoint status
2. Look for corrupted state

**Fix:**
```bash
# Rollback state and restart from a step
dd-apm create <package> --from=<step>

# Also reset git files to the checkpoint before that step
dd-apm create <package> --from=<step> --rollback-git

# Clean state and restart from scratch
dd-apm clean <package>
```

### CompositeStep Loops Forever

**Symptom:** `max_iterations reached` on CompositeStep

**Debug:**
1. Check `should_continue()` logic
2. Review iteration outputs in `steps/{composite}:att{N}:iter{M}:{stage}/`

**Fix:**
- Fix `should_continue()` to return `False` when done
- Increase `max_iterations` if legitimately need more
- Add `should_exit_early()` to break on success

## Debugging Techniques

### Enable Verbose Logging

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Inspect State Programmatically

```python
from anubis.core.state import WorkflowState

state = WorkflowState.load("my_workflow", "kafkajs", base_dir)
print(state.get_completed_steps())
print(state.get_output("analyze"))
```

### Run Single Step

```python
# Skip to specific step by marking others complete
wf = MyWorkflow(
    namespace="test",
    config={'skip_steps': {'prepare', 'validate'}},
)
```

### Test Step in Isolation

```python
from anubis_apm.steps import AnalyzeStep
from tests.fixtures import mock_context

step = AnalyzeStep()
ctx = mock_context(namespace="test")
result = step.execute(input_data, ctx)
```

### Disable Sandbox for Debugging

```python
wf = MyWorkflow(
    namespace="test",
    step_configs={'analyze': {'sandbox': False}},
)
```

## Reading Agent Transcripts

Agent logs show full conversation. Key things to look for:

```
# Tool calls
<tool_call name="Read">...</tool_call>

# Agent reasoning (if visible)
I need to find the integration file...

# Errors
Error: File not found...

# Final output
<structured_output>{"targets": [...]}</structured_output>
```

**Red flags:**
- Repeated tool calls (looping)
- "I don't have access to..." (permission/sandbox issue)
- Wrong file paths (needs better prompt context)
- No structured output at end (ran out of turns)

## Experience Store (S3 Sync)

S3 sync runs automatically on every workflow. If you see warnings at preflight:

**"AWS credentials not configured"**
- Run: `dd-apm sync setup` to diagnose
- Or: `aws-vault exec sso-staging-engineering -- dd-apm create <pkg>`

**Experience cache location:**
```
.analysis/.experience/
├── index.json                                    # Cached S3 manifest index
└── dd_trace_js/kafkajs/new_integration/<run_id>/  # Pulled step outputs
```

**Useful sync commands:**
```bash
dd-apm sync setup           # Check auth and prerequisites
dd-apm sync list             # List all stored runs
dd-apm sync list kafkajs     # List runs for one integration
dd-apm sync pull             # Pull latest runs from S3
dd-apm sync inspect <run-id> # Show full manifest
```

**Experience injection** (experimental): Pass `--experience` to inject past run outputs into agent prompts. Off by default.

## Clean Up

```bash
# Remove all state for a package
dd-apm clean <package>

# Remove specific workflow state
rm -rf .analysis/<package>/<workflow>/

# Keep artifacts, reset checkpoints
# Edit state.json, set "checkpoints": {}

# Experience cache is separate — dd-apm clean does NOT touch .experience/
# To clear: rm -rf .analysis/.experience/
```
