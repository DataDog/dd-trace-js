# Anubis APM Reference

**Package:** `anubis_apm/`

Anubis APM provides dd-trace-specific implementations for the anubis workflow framework.

**Currently supports:** dd-trace-js

**Planned:** dd-trace-py, dd-trace-go, dd-trace-rb, dd-trace-java, dd-trace-dotnet, dd-trace-php

---

## Repository Adapters

Repository adapters provide tracer-specific functionality.

### DDTraceJsAdapter

**File:** `anubis_apm/repo_adapters/dd_trace_js.py`

```python
from anubis_apm.repo_adapters import DDTraceJsAdapter

adapter = DDTraceJsAdapter()

# Plugin paths
adapter.get_plugin_path('kafkajs')
# -> 'packages/datadog-plugin-kafkajs/'

# Test commands (uses dd-debug.js)
adapter.get_test_command('kafkajs', output_dir=Path('/tmp'))
# -> 'node /path/to/dd-debug.js kafkajs --verbose --output-dir /tmp'

# Reference integrations by feature
adapter.get_reference_integrations('dsm')
# -> ['packages/datadog-plugin-kafkajs/', 'packages/datadog-plugin-amqplib/', ...]

# Linting
adapter.lint_paths(['packages/'], repo_root, fix=True)
```

### Adapter Interface

| Method | Description |
|--------|-------------|
| `get_plugin_path(name)` | Path to plugin directory |
| `get_test_file_path(name)` | Path to test file |
| `get_test_command(name, output_dir)` | Test command with dd-debug |
| `get_reference_integrations(key)` | Reference plugin paths for a feature ID or semantic category |
| `get_required_test_services()` | Docker services required to run tests |
| `get_lint_paths(name)` | Paths to pass to the linter |
| `get_ci_env_vars(pkg, services)` | CI environment variables |
| `get_ci_system()` | CI system name (`"github"`, `"gitlab"`) |
| `generate_ci_config(pkg, services, compose, ci)` | Full CI job config dict |
| `lint_paths(paths, repo_root, fix)` | Run linter |

### Reference Integrations

`get_reference_integrations(key)` accepts both semantic category names (from `apm_semantic_conventions.list_categories()`) and Datadog feature IDs (`FeatureId` enum values). All adapters must cover every key.

**Semantic categories** — do not hardcode; always get the live list:

```python
from apm_semantic_conventions import list_categories
list_categories()  # source of truth
```

**Datadog feature IDs** — do not hardcode; always read from the enum:

```python
from anubis_apm.workflows.feature.models import FeatureId
[f.value for f in FeatureId]  # source of truth
```

---

## APM Prompts

APM-specific prompt templates live in `anubis_apm/prompts/`:

```
anubis_apm/prompts/
├── dd_trace_js/        # dd-trace-js specific
│   ├── analyze.md
│   ├── test-diagnosis.md
│   └── sample-app-generator.md
└── shared/             # Cross-tracer shared
    └── common.md
```

Prompts are loaded via the configured `PromptLoader` with tracer-specific directories taking priority.

---

## APM Skills

APM-specific skills for agents:

```
anubis_apm/skills/
└── node/               # Node.js/dd-trace-js skills
    ├── instrumentation/SKILL.md
    ├── testing/SKILL.md
    └── debugging/SKILL.md
```

---

## APM Setup

### Environment

| Variable | Description |
|----------|-------------|
| `DD_TRACER_REPO` | Path to dd-trace-js repository |
| `ANTHROPIC_API_KEY` | API key for Claude agents |

### Bootstrap

At startup, anubis_apm configures global providers:

```python
from anubis.core.config import (
    set_prompts_factory,
    set_skill_loader_factory,
    set_base_dir_provider,
    set_toolkit_dir_provider,
)

# Configure for dd-trace-js
set_base_dir_provider(lambda: Path(os.environ['DD_TRACER_REPO']))
set_prompts_factory(lambda repo, user: create_apm_prompts(repo, user))
set_skill_loader_factory(lambda repo: create_apm_skill_loader(repo))
set_toolkit_dir_provider(lambda: toolkit.toolkit_root)
```

---

## APM Workflows

Pre-built workflows for dd-trace development:

| Workflow | Description |
|----------|-------------|
| `AnalyzeWorkflow` | Analyze integration for targets |
| `LintWorkflow` | Run linting with auto-fix |
| `TestWorkflow` | Run tests with diagnostics |
| `IntegrationWorkflow` | Full integration pipeline |

### Usage

```python
from anubis_apm.workflows import AnalyzeWorkflow

wf = AnalyzeWorkflow(
    namespace='kafkajs',
    repository='dd_trace_js',
    user_prompt='Focus on producer methods',
    step_configs={
        'analyze': {'max_turns': 100},
    },
)

result = wf.run(AnalyzeInput(package_name='kafkajs'))
```

---

## Adding New Tracers

To add support for a new tracer (e.g., dd-trace-py):

### 1. Create Repo Adapter

```python
# anubis_apm/repo_adapters/dd_trace_py.py
from anubis.core.repo_adapters import PythonRepoAdapter
from .base import APMAdapterMixin

class DDTracePyAdapter(PythonRepoAdapter, APMAdapterMixin):
    def get_plugin_path(self, name: str) -> str:
        return f"ddtrace/contrib/{name}/"

    def get_test_command(self, name: str, output_dir: Path = None) -> str:
        return f"pytest ddtrace/contrib/{name}/tests/"

    # ... implement other APMAdapterMixin methods
```

### 2. Create Prompts

```
anubis_apm/prompts/dd_trace_py/
├── analyze.md
├── test-diagnosis.md
└── sample-app-generator.md
```

### 3. Create Skills (Optional)

```
anubis_apm/skills/python/
├── instrumentation/SKILL.md
└── testing/SKILL.md
```

### 4. Register Adapter

Update the adapter factory to return the appropriate adapter based on repository.
