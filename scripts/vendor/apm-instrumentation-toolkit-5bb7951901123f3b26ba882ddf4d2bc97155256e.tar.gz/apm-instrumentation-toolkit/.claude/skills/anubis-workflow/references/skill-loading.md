# Skill Loading Reference

**Files:** `anubis/core/resources/skills.py`, `anubis/core/resources/registry.py`

Skills are domain knowledge documents loaded into agent prompts and installed to agent working directories.

---

## Creating Skills

**Recommended:** Teams should create their own repository-specific skills to capture domain knowledge, coding patterns, and best practices unique to their codebase.

### Using the Skill Creator

Use the `skill-creator` skill to write new skills:

```
.claude/skills/skill-creator/SKILL.md
```

The skill-creator provides:
- Templates for skill structure
- Best practices for skill content
- Validation scripts for skill format

### Why Create Repo Skills?

1. **Domain knowledge** - Capture patterns specific to your codebase
2. **Onboarding** - Help agents (and humans) understand conventions
3. **Consistency** - Ensure agents follow established patterns
4. **Efficiency** - Reduce agent exploration time with pre-documented knowledge

### Skill Directory

Place skills in `.claude/skills/` at your repository root:

```
your-repo/
└── .claude/
    └── skills/
        ├── your-domain/
        │   └── SKILL.md
        └── your-patterns/
            └── SKILL.md
```

---

## SkillLoader

```python
from anubis.core.resources import SkillLoader, SkillRegistry

loader = SkillLoader(
    skills_dirs=[
        Path('.claude/skills'),           # Project skills first
        Path('my_app/skills/domain'),     # Domain-specific
    ],
    registry=registry,  # Optional: for skill groups
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `skills_dirs` | List[Path] | Required | Directories to search (priority order) |
| `registry` | SkillRegistry | None | Registry for resolving skill groups |

---

## Skill Semantics

| Value | Behavior |
|-------|----------|
| `skills=None` | NO skills loaded |
| `skills=[]` | ALL skills loaded |
| `skills=['a', 'b']` | Only named skills/groups loaded |

```python
# Load no skills
loader.get_summaries(None)  # -> ""

# Load ALL available skills
loader.get_summaries([])  # -> All skill summaries

# Load specific skills
loader.get_summaries(['instrumentation', 'testing'])
```

---

## Skill File Layouts

Two layouts are supported:

### Flat Layout

```
skills/
├── instrumentation.md
├── testing.md
└── debugging.md
```

### Directory Layout (Preferred)

```
skills/
├── instrumentation/
│   ├── SKILL.md
│   └── references/
│       └── patterns.md
├── testing/
│   └── SKILL.md
└── debugging/
    └── SKILL.md
```

Directory layout is preferred for complex skills with reference files.

---

## SkillRegistry

Groups skills for easier loading:

```python
from anubis.core.skills import SkillRegistry

registry = SkillRegistry({
    'debugging': ['instrumentation-debug', 'log-analyzer'],
    'testing': ['test-runner', 'test-patterns'],
    'all': ['debugging', 'testing'],  # Groups can reference other groups
})

# Resolve groups to individual skills
skills = registry.resolve(['debugging', 'test-runner'])
# -> ['instrumentation-debug', 'log-analyzer', 'test-runner']
```

| Method | Description |
|--------|-------------|
| `resolve(skills)` | Resolve names/groups to flat deduplicated list |
| `add_group(name, skills)` | Add or update a skill group |
| `get_groups()` | Get all registered groups |

---

## Methods

### list_all()

List all available skill names:

```python
skills = loader.list_all()
# -> ['debugging', 'instrumentation', 'testing', ...]
```

### get_skill_path(name)

Find skill file by name:

```python
path = loader.get_skill_path('instrumentation')
# -> Path('.claude/skills/instrumentation/SKILL.md')
```

### get_summary(name)

Get summary for a single skill:

```python
summary = loader.get_summary('instrumentation')
# -> "Guide for creating instrumentations..."
```

Summary is extracted from:
1. YAML front matter `description` field
2. `## Summary` or `## Description` section
3. First non-header paragraph (fallback)

### get_summaries(skills)

Get formatted summaries for multiple skills:

```python
summaries = loader.get_summaries(['instrumentation', 'testing'])
```

Returns formatted markdown with skill names and descriptions, ready for prompt injection.

### install(skills, working_dir)

Install skill files to agent working directory:

```python
installed = loader.install(['instrumentation'], working_dir=Path('/tmp/agent'))
# -> [Path('/tmp/agent/.claude/skills/instrumentation/SKILL.md')]
```

Skills are copied to `{working_dir}/.claude/skills/{name}/SKILL.md`.

---

## Skill File Format

Skills should have YAML front matter with name and description:

```markdown
---
name: instrumentation
description: Guide for creating instrumentations in dd-trace-js
---

# Instrumentation Guide

Detailed content here...

## Quick Start
...

## Best Practices
...
```

### Summary Extraction

The loader extracts summaries in this priority:

1. **YAML front matter** - `description` field
   ```yaml
   ---
   description: Guide for creating instrumentations
   ---
   ```

2. **Summary section** - `## Summary` or `## Description`
   ```markdown
   ## Summary
   This skill provides guidance for...
   ```

3. **First paragraph** - First non-header text (fallback)

---

## Skill Installation Flow

During agent execution:

1. **Install**: Skills copied to `{working_dir}/.claude/skills/{name}/SKILL.md`
2. **Inject**: Skill summaries prepended to prompt with instructions
3. **Execute**: Agent reads skills from `.claude/skills/` as instructed
4. **Cleanup**: Installed skills removed after agent completes

```python
# In spawn_agent()
installed_skills = skill_loader.install(skills, working_directory)
try:
    # Run agent...
finally:
    # Clean up installed skills
    for skill_path in installed_skills:
        skill_path.unlink()
```

---

## Integration with AgentStep

AgentStep specifies skills via the `skills` attribute:

```python
@agent_step(AgentStepConfig(
    name="analyze",
    prompt="analyze",
    output_type=AnalysisOutput,
    skills=['datadog-semantics', 'observability-patterns'],  # Skills to load
))
class AnalyzeStep:
    pass
```

The agent executor:
1. Installs specified skills to working directory
2. Prepends skill summaries to the prompt
3. Cleans up skills after completion

---

## Global Configuration

Applications configure the skill loader factory at startup:

```python
from anubis.core.resources import SkillLoader, SkillRegistry, ResourceManager

def create_skill_loader(repository: str) -> SkillLoader:
    registry = SkillRegistry({
        'all': ['instrumentation', 'testing', 'debugging'],
    })
    return SkillLoader(
        skills_dirs=[Path(f'my_app/skills/{repository}')],
        registry=registry,
    )

set_skill_loader_factory(create_skill_loader)
```

---

## Best Practices

### For Teams

1. **Create repo-specific skills** - Capture your domain knowledge
2. **Use the skill-creator** - Follow established patterns
3. **Keep skills updated** - Evolve with your codebase
4. **Document conventions** - Help agents follow your patterns

### For Skill Content

1. **Use directory layout** for skills with reference files
2. **Include YAML front matter** with clear description
3. **Group related skills** in the registry
4. **Keep skills focused** - one domain per skill
5. **Include examples** - concrete code samples help agents
6. **Reference existing code** - point to real implementations
