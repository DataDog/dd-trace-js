# Prompt Loading Reference

**File:** `anubis/core/resources/prompts.py`

Prompts are markdown templates loaded and rendered with variable substitution for agent steps.

---

## PromptLoader

```python
from anubis.core.resources import PromptLoader

loader = PromptLoader(
    prompts_dirs=[
        Path('my_app/prompts/domain'),   # Domain-specific first
        Path('my_app/prompts/shared'),    # Shared fallback
    ],
    include_builtin=True,  # Include anubis built-in templates (default)
    user='Custom guidance',  # Appended to all prompts
    skill_loader=skill_loader.get_summaries,  # Skill injection callback
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `prompts_dirs` | List[Path] | Required | Directories to search (priority order) |
| `include_builtin` | bool | True | Include anubis built-in templates as fallback |
| `user` | str | None | Custom guidance appended to all prompts |
| `skill_loader` | Callable | None | Callback for skill summary injection |
| `repo` | str | None | Repo identifier for resolving `{{include_repo:name}}` directives (e.g. `dd_trace_js`) |

---

## Loading Prompts

```python
prompt = loader.load(
    'analyze',                        # Template name (without .md)
    output_schema=AnalysisOutput,     # Auto-appends schema docs
    skills=['datadog-semantics'],       # Prepends skill summaries
    max_turns=50,                     # Appends turn limit guidance
    package_name='kafkajs',           # Custom variable
    custom_var='value',               # More custom variables
)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | str | Template name (without .md extension) |
| `output_schema` | Type[BaseModel] | Pydantic model - appends schema documentation |
| `skills` | List[str] | Skill names - prepends skill summaries |
| `max_turns` | int | Turn limit - appends completion strategy |
| `**variables` | Any | Custom variables for template substitution |

---

## Template Format

Templates use `{{variable}}` syntax:

```markdown
# Analyze {{package_name}}

Analyze the {{namespace}} integration and identify instrumentation targets.

## Output Location
Save results to: {{analysis_dir}}/{{output_file}}

## Instructions
- Follow existing patterns
- Document all findings
```

**Important:** Templates should NOT contain hardcoded JSON schemas. Use the `output_schema` parameter for dynamic schema injection.

---

## Auto-Injected Sections

The loader automatically appends/prepends sections based on parameters:

| Parameter | Section | Position |
|-----------|---------|----------|
| `skills` | `## Available Skills` | Prepended |
| `output_schema` | `## Expected Output Format` | Appended |
| `user` | `## User Guidance` | Appended |
| `max_turns` | `## Turn Limit` | Appended |

### Skills Section

When `skills` is provided, summaries are prepended with instructions:

```markdown
## Available Skills

**MANDATORY FIRST STEP:** You MUST read relevant skills before doing ANY other work.

1. Review each skill name and description below
2. For skills relevant to your task, read the full file at `./.claude/skills/{name}/SKILL.md`
3. Read skills ONE AT A TIME - do not load all at once
4. Only after reading relevant skills should you begin your actual task

### instrumentation
Guide for creating instrumentations...
```

### Output Schema Section

When `output_schema` is provided:

```markdown
## Expected Output Format

Output must conform to this schema:

**AnalysisOutput**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| targets | List[Target] | Yes | Identified targets |
| summary | str | Yes | Analysis summary |
...
```

### Turn Limit Section

When `max_turns` is provided:

```markdown
## Turn Limit

You have **50 turns maximum**.

**Strategy:** Do NOT exhaustively explore. Work in phases: Quick scan -> Focused analysis -> Output.
Aim to complete in ~25 turns. If you hit the limit without output, the task fails.
```

---

## Directory Search Order

Templates are searched in directory order (first match wins):

```python
loader = PromptLoader([
    Path('my_app/prompts'),      # Checked first
    Path('shared/prompts'),       # Fallback
])
# Built-in templates auto-added as final fallback
```

Built-in templates include:
- `lint-fixer` - Generic lint error fixing
- `test-fixer` - Generic test failure fixing
- `reviewer` - Generic code review

## Directives

Templates support three directives for composing prompts from multiple files:

### `{{include_repo:name}}`

Includes repo-specific fragments. Resolves to `repo/{repo}/name.md` **relative to the template file's directory** (not the prompts root). This is important for nested includes — if template A includes template B via `{{include:}}`, any `{{include_repo:}}` in B resolves relative to B's directory.

```markdown
# anubis_apm/prompts/shared/my-workflow/prompt.md
Generic instructions...

{{include_repo:patterns}}
# → anubis_apm/prompts/shared/my-workflow/repo/dd_trace_js/patterns.md (for JS tracer)
```

If the file doesn't exist for the current repo, the directive is silently removed. This is the key mechanism for multi-tracer support — add `repo/{new_repo}/` subdirectories without modifying shared prompts.

### `{{include:path}}`

Inlines another template (recursive, max depth 10). Path is relative to the prompts root directory:

```markdown
{{include:instrumentation/references/general-principles}}
# → anubis_apm/prompts/shared/instrumentation/references/general-principles.md
```

### `{{link:path|label}}`

Inserts a markdown reference link for on-demand reading by agents. The linked file is copied to a local `references/` directory:

```markdown
{{link:instrumentation/categories/database|Database and ORM}}
# → anubis_apm/prompts/shared/instrumentation/categories/database.md
```

### Prompt Directory Convention

```
anubis_apm/prompts/shared/{workflow}/
├── prompt.md              # Main template (language-agnostic)
├── categories/            # Optional: {{link:}} targets
├── references/            # Optional: {{include:}} or {{link:}} targets
└── repo/                  # Repo-specific fragments
    ├── dd_trace_js/       # JS-specific (included via {{include_repo:name}})
    └── dd_trace_py/       # Python-specific (when added)
```

---

## Methods

### load(name, **kwargs)

Load and render a template with variable substitution.

```python
prompt = loader.load('analyze', package_name='kafkajs')
```

Raises:
- `FileNotFoundError` - Template not found in any directory
- `ValueError` - Unsubstituted variables remain

### exists(name)

Check if a template exists.

```python
if loader.exists('custom-prompt'):
    prompt = loader.load('custom-prompt')
```

### get_path(name)

Get the path to a template file.

```python
path = loader.get_path('analyze')  # -> Path('my_app/prompts/analyze.md')
```

### clear_cache()

Clear the template cache (templates are cached on first load).

```python
loader.clear_cache()
```

---

## Integration with AgentStep

AgentStep automatically uses prompts via `ctx.prompts`:

```python
@agent_step(AgentStepConfig(
    name="analyze",
    prompt="analyze",           # Template name
    output_type=AnalysisOutput,
    skills=['datadog-semantics'],
))
class AnalyzeStep:
    def get_prompt_variables(self, input, ctx):
        """Add custom variables to prompt template."""
        return {
            'package_name': ctx.namespace,
            'custom_data': input.data,
        }
```

Variables automatically injected by AgentStep:
- `package_name` / `namespace` - From context
- `analysis_dir` - Workflow analysis directory
- `output_file` - From step configuration
- `{step_name}_error_prompt` - Validation errors on retry

---

## Global Configuration

Applications configure the prompts factory at startup:

```python
from anubis.core.resources import ResourceManager

def create_prompts(repository: str, user: Optional[str]) -> PromptLoader:
    return PromptLoader(
        prompts_dirs=[Path(f'my_app/prompts/{repository}')],
        user=user,
    )

set_prompts_factory(create_prompts)
```

Workflows then automatically use the configured factory.
