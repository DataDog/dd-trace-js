# Step API Reference

## Step Base Class

**File:** `anubis/core/steps/step.py`

### Class Attributes

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `name` | str | Auto from class name | Step identifier (snake_case) |
| `input_type` | Type[BaseModel] | None | Expected input Pydantic model |
| `output_type` | Type[BaseModel] | None | Output Pydantic model (enables validation) |
| `validators` | List[ValidatorFn] | [] | Custom validator functions |
| `fixer_prompt` | str | None | Prompt template for auto-fix |
| `fixer_model` | str | 'haiku' | Model for fixer agent |
| `max_fixer_iterations` | int | 3 | Max fix attempts |
| `validation_required` | bool | True | Raise ValidationError on failure |
| `batch_execute` | bool | False | Enable batch mode |
| `batch_size` | int | 1 | Parallel workers (1 = sequential) |
| `optional` | bool | False | Step failure doesn't fail workflow |

### Methods to Override

```python
def execute(self, input: I, ctx: Context) -> O:
    """Main step logic. Required."""
    pass

def before_execute(self, input: I, ctx: Context) -> I:
    """Transform input before execute. Optional."""
    return input

def after_execute(self, output: O, ctx: Context) -> O:
    """Transform output after execute. Optional."""
    return output

def prepare_batch(self, input: Any, ctx: Context) -> List[Any]:
    """Return items for batch execution. Override for batch steps."""
    return input if isinstance(input, list) else []

def aggregate_batch(self, results: list, ctx: Context) -> Any:
    """Combine batch results. Override to customize."""
    return results

def can_fix(self) -> bool:
    """Return True if step can fix validation errors."""
    return bool(self.fixer_prompt)

def fix_output(self, input: I, output: O, errors: List[str], ctx: Context) -> O:
    """Fix invalid output. Override for custom fix logic."""
    # Default spawns fixer agent with fixer_prompt
```

### Name Auto-Inference

Step names are auto-inferred from class names:
- `MyAnalysisStep` → `my_analysis_step`
- `ProcessDataStep` → `process_data_step`

Override by setting `name` explicitly.

---

## AgentStep

**File:** `anubis/core/steps/agent.py`

Extends Step with AI agent execution.

### Additional Attributes

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `prompt` | str | "" | Prompt template name (required) |
| `output_file` | str | None | Save output to file in analysis dir |
| `required_files` | List[str] | [] | Files agent must create |
| `skills` | List[str] | [] | Skills to load for agent |
| `timeout_minutes` | int | 30 | Agent timeout |
| `max_turns` | int | 100 | Max agent conversation turns |
| `model` | str | 'sonnet' | Model: sonnet, opus, haiku |
| `use_repo_root` | bool | False | Working dir: repo root vs analysis dir |
| `sandbox` | bool | True | Run agent in sandbox mode |
| `planning` | bool | False | Run read-only planning phase first |

### Methods to Override

```python
def get_prompt_variables(self, input: Any, ctx: Context) -> dict:
    """Add custom variables to prompt template."""
    return {
        "package": ctx.namespace,
        "custom_var": "value",
    }
```

### Prompt Template Loading

Prompts loaded via `ctx.prompts.load(template_name, **variables)`:

```python
# In anubis_apm/prompts/analyze.md
"""
Analyze the package {{ package_name }}.

Output schema:
{{ output_schema }}

{{ error_prompt }}  # Injected on validation failure
"""
```

Variables automatically injected:
- `output_schema` - JSON schema from `output_type`
- `package_name` - From `ctx.namespace`
- `{step_name}_error_prompt` - Validation errors on retry

---

## CompositeStep

**File:** `anubis/core/steps/composite.py`

Runs multiple stages with optional looping.

### Additional Attributes

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `stages` | List[Type[Step]] | [] | Steps to run in sequence |
| `max_iterations` | int | 1 | Max loop iterations |

### Methods to Override

```python
def before_iteration(self, iteration: int, input: I, ctx: Context) -> I:
    """Prepare input for each iteration."""
    return input

def after_iteration(self, iteration: int, output: Any, ctx: Context) -> Any:
    """Transform output between iterations."""
    return output

def after_stage_execute(self, stage_name: str, output: Any, ctx: Context) -> Any:
    """Transform output after each stage."""
    return output

def should_exit_early(self, stage_name: str, output: Any, ctx: Context) -> bool:
    """Exit pipeline early after a stage."""
    return False

def should_continue(self, output: Any, ctx: Context) -> bool:
    """Continue to next iteration? Default: False (single iteration)."""
    return False
```

### Iteration Context

During iteration, these context values are set:
- `ctx.get('current_iteration')` - Current iteration number
- `ctx.get('{step_name}_iteration')` - Step-specific iteration
- `ctx.current_attempt` - Same as iteration number

### Stage Checkpointing

Stages are checkpointed with composite keys:
```
{parent_step}:att{attempt}:iter{iteration}:{stage_name}
```

Example: `test_fixer:att1:iter3:diagnosis`

---

## Validator Functions

**File:** `anubis/core/validation/validators.py`

### Signature

```python
def my_validator(output: Any, ctx: Context, output_type: Type = None) -> bool | str | List[str]:
    """
    Args:
        output: Step output to validate
        ctx: Execution context
        output_type: The Pydantic model type (for schema access)

    Returns:
        True - Valid
        str - Single error message
        List[str] - Multiple error messages
    """
```

### Built-in Validators

```python
from anubis.core.validation import (
    pydantic_validator,  # Auto-added when output_type set
    has_field,           # has_field("targets")
    min_items,           # min_items("targets", 3)
    file_exists,         # file_exists("output_path")
    files_exist,         # files_exist("created_files")
)
```

### Custom Validator Example

```python
def validate_analysis(output, ctx, output_type=None):
    errors = []

    if not output.targets:
        errors.append("No targets found")

    for target in output.targets:
        if not target.method_name:
            errors.append(f"Target missing method_name: {target}")

    return errors if errors else True
```

---

## StepConfig / AgentStepConfig / CompositeStepConfig

Configuration classes for decorator API.

### StepConfig

```python
from anubis import StepConfig

config = StepConfig(
    name="my_step",
    output_type=MyOutput,
    input_type=MyInput,           # Optional
    validators=[my_validator],
    fixer_prompt="my-fixer",
    max_fixer_iterations=3,
    validation_required=True,
    batch_execute=False,
    batch_size=1,
)
```

### AgentStepConfig

```python
from anubis import AgentStepConfig

config = AgentStepConfig(
    name="analyze",
    prompt="analyze",              # Required
    output_type=AnalysisOutput,    # Required
    model="sonnet",
    max_turns=50,
    timeout_minutes=30,
    skills=["read-docs"],
    output_file="analysis.json",
    use_repo_root=False,
    sandbox=True,                  # Run in sandbox
    planning=False,                # Run planning phase first
    # All StepConfig options also available
)
```

---

## Runtime Configuration Overrides

Steps can have their attributes overridden at runtime via `step_configs` passed to the workflow.

### step_override_config Method

```python
def step_override_config(self, step_configs: dict) -> None:
    """Apply configuration overrides to this step instance.

    Looks up config for this step's name in step_configs and applies
    any attribute overrides found.

    Args:
        step_configs: Dictionary mapping step names to config dicts
                     e.g., {'diagnosis': {'sandbox': False}}
    """
```

### Usage from Workflow

```python
wf = MyWorkflow(
    namespace="kafkajs",
    step_configs={
        'analyze': {'model': 'opus', 'max_turns': 100},
        'diagnosis': {'sandbox': False, 'timeout_minutes': 60},
    },
)
```

### How It Works

1. Workflow stores `step_configs` in context as `_step_configs`
2. Before each step executes, `step.step_override_config(step_configs)` is called
3. Matching config dict attributes are applied via `setattr()`
4. CompositeStep stages also receive the same overrides

---

### CompositeStepConfig

```python
from anubis import CompositeStepConfig

config = CompositeStepConfig(
    name="test_fixer",
    output_type=TestResult,
    stages=[DiagnosisStage, FixerStage],
    max_iterations=10,
    # All StepConfig options also available
)
```
