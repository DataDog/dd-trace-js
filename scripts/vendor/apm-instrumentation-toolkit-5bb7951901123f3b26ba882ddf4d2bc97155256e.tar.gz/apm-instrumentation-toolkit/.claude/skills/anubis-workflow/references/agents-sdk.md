# Claude Agents SDK Integration

**Files:** `anubis/core/agents/spawn.py`, `anubis/core/agents/runners/claude_sdk/`

Anubis uses the Claude Agents SDK for programmatic agent execution within workflow steps.

---

## spawn_agent Function

**File:** `anubis/core/agents/spawn.py`

Main entry point for spawning Claude Code agents:

```python
from anubis.core.agents import spawn_agent

result = spawn_agent(
    task_description='Analyze integration',
    prompt='Full prompt text...',
    working_directory=Path('/analysis/kafkajs'),
    emitter=context,  # For logging/events

    # Agent configuration
    model='sonnet',           # 'sonnet', 'opus', 'haiku'
    max_turns=50,
    timeout_minutes=30,

    # Output validation
    output_schema=AnalysisOutput,  # Pydantic model for structured output
    required_files=['output.json'],  # Files agent must create

    # Skills
    skills=['datadog-semantics'],  # Skills to install (None=none, []=all)

    # Session management
    resume_session_id=None,   # Resume previous conversation

    # Security
    sandbox=True,             # OS-level bash isolation
    repo_root=Path('/repo'),  # Additional allowed path
)

if result.success:
    output = result.structured_output  # Validated Pydantic model
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `task_description` | str | Required | Brief description (for logging) |
| `prompt` | str | Required | Full task prompt |
| `working_directory` | Path | Required | Agent working directory |
| `emitter` | Any | Required | EventEmitter for logging |
| `model` | str | 'sonnet' | Model: 'sonnet', 'opus', 'haiku' |
| `max_turns` | int | 100 | Maximum agent turns |
| `timeout_minutes` | int | 30 | Timeout for agent completion |
| `output_schema` | Type[BaseModel] | None | Pydantic model for validation |
| `required_files` | List[str] | None | Files agent must create |
| `skills` | List[str] | None | Skills to install (None=none, []=all) |
| `resume_session_id` | str | None | Resume previous session |
| `sandbox` | bool | True | Enable OS-level isolation |
| `repo_root` | Path | None | Additional allowed path |
| `fixer_prompt` | str | None | Custom fixer prompt |
| `max_fixer_attempts` | int | 2 | Max fixer loop attempts |

---

## AgentResult

```python
class AgentResult(BaseModel):
    success: bool
    output: Optional[str]           # Final text output
    error: Optional[str]
    files_created: List[str]
    files_modified: List[str]
    structured_output: Optional[BaseModel]  # Validated Pydantic model
    raw_structured_output: Optional[dict]   # Raw dict before validation
    metrics: AgentMetrics
    session_id: Optional[str]       # For session resumption
```

### Usage

```python
result = spawn_agent(...)

if result.success:
    # Access validated output
    analysis = result.structured_output
    print(f"Found {len(analysis.targets)} targets")

    # Check metrics
    print(f"Cost: ${result.metrics.cost_usd:.4f}")
    print(f"Turns: {result.metrics.num_turns}")
else:
    print(f"Error: {result.error}")
```

---

## AgentMetrics

```python
class AgentMetrics(BaseModel):
    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    num_turns: int = 0
    is_error: bool = False
    error_subtype: Optional[str] = None  # 'max_turns', 'timeout', 'rate_limit'
    provider: Optional[str] = None       # 'claude_sdk'
    model: Optional[str] = None          # 'claude-sonnet-4', etc.
```

---

## Session Resumption

Agents can resume previous conversations for multi-phase work or fix attempts:

```python
# First run
result = spawn_agent(
    task_description='Analyze',
    prompt='...',
    ...
)

# Store session_id
session_id = result.session_id

# Resume later (e.g., for fixes)
result = spawn_agent(
    task_description='Fix analysis',
    prompt='Fix the issues...',
    resume_session_id=session_id,
    ...
)
```

---

## Structured Output

When `output_schema` is provided, the agent returns validated Pydantic models:

```python
from pydantic import BaseModel

class AnalysisOutput(BaseModel):
    targets: List[str]
    summary: str

result = spawn_agent(
    prompt='Analyze the code...',
    output_schema=AnalysisOutput,
    ...
)

if result.success:
    # Automatically validated
    analysis: AnalysisOutput = result.structured_output
```

### Validation Flow

1. Agent produces structured output via `--json-schema`
2. Output validated against Pydantic model
3. If invalid, fixer loop runs (same session)
4. Returns validated model or error

---

## Fixer Loop

When output validation fails, spawn_agent automatically runs a fixer loop:

1. Validate output against schema
2. If invalid, send follow-up query on same session
3. Re-validate fixer output
4. Repeat up to `max_fixer_attempts` times

```python
result = spawn_agent(
    output_schema=MyOutput,
    max_fixer_attempts=3,     # Try up to 3 fixes
    fixer_prompt='Custom fix instructions...',  # Optional
    ...
)
```

---

## ClaudeSDKRunner

**File:** `anubis/core/agents/runners/claude_sdk/runner.py`

Low-level runner that wraps the Claude Agents SDK:

```python
from anubis.core.agents.runners import ClaudeSDKRunner

runner = ClaudeSDKRunner(
    sandbox=True,                    # OS-level isolation
    permission_mode='acceptEdits',   # Auto-approve edits
    use_default_security=True,       # Block dangerous commands
    allowed_paths=[repo_root],       # Additional allowed paths
    allow_interrupt=True,            # Ctrl+C for guidance
)

# Initial execution
result = runner.run(
    prompt='...',
    working_directory=Path('/tmp/work'),
    model='sonnet',
    max_turns=50,
    output_schema=MyOutput,
)

# Follow-up query (same session)
if runner.has_active_session:
    fix_result = runner.query(
        prompt='Fix the validation errors...',
        output_schema=MyOutput,
    )

# Clean up
runner.close()
```

### Runner Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sandbox` | bool | True | Enable OS-level isolation |
| `permission_mode` | str | 'acceptEdits' | Permission handling mode |
| `use_default_security` | bool | True | Block dangerous commands |
| `allowed_paths` | List[Path] | [] | Paths to allow file access |
| `allow_interrupt` | bool | True | Allow Ctrl+C for guidance |

### Permission Modes

| Mode | Description |
|------|-------------|
| `default` | Prompt for each permission |
| `acceptEdits` | Auto-approve file edits |
| `bypassPermissions` | Skip all permission checks |

---

## Sandbox & Security

The SDK runner provides multiple security layers:

### OS-Level Sandbox

When `sandbox=True`:
- macOS: Uses seatbelt for isolation
- Linux: Uses bubblewrap for isolation
- Restricts file system access
- Limits network access

```python
runner = ClaudeSDKRunner(
    sandbox=True,
    # Node.js excluded from sandbox for toolkit scripts
)
```

### Permission Rules

Default security blocks dangerous commands:
- `rm`, `rmdir`, `chmod`, `chown`
- `sudo`, `su`
- System directory access

```python
runner = ClaudeSDKRunner(
    use_default_security=True,  # Block dangerous commands
    permission_deny=['Bash(rm *)'],  # Additional denies
    permission_allow=['Read(/specific/path)'],  # Additional allows
)
```

### Allowed Paths

Whitelist paths for file access:

```python
runner = ClaudeSDKRunner(
    allowed_paths=[
        repo_root,      # Repository root
        toolkit_root,   # Toolkit scripts
    ],
)
```

---

## Integration with AgentStep

AgentStep uses spawn_agent internally:

```python
@agent_step(AgentStepConfig(
    name="analyze",
    prompt="analyze",
    output_type=AnalysisOutput,
    model="sonnet",
    max_turns=50,
    sandbox=True,
))
class AnalyzeStep:
    pass
```

The step executor:
1. Builds prompt from template
2. Installs skills to working directory
3. Calls spawn_agent with configuration
4. Validates output
5. Cleans up skills

---

## Planning Phase

AgentStep supports a planning phase for complex tasks:

```python
@agent_step(AgentStepConfig(
    name="implement",
    prompt="implement",
    output_type=ImplementOutput,
    planning=True,  # Enable planning phase
))
class ImplementStep:
    pass
```

When `planning=True`:
1. First run: Read-only planning (all skills, no writes)
2. Agent outputs detailed plan
3. Second run: Implementation (uses same session)

---

## Event Emission

spawn_agent emits events for UI/logging:

| Event | Description |
|-------|-------------|
| `section` | Major phase start |
| `info` | Informational message |
| `warn` | Warning message |
| `agent_start` | Agent execution starting |
| `agent_complete` | Agent execution finished |

```python
# Events emitted to context
ctx.emit('agent_start', task='Analyze', model='sonnet')
ctx.emit('agent_complete', task='Analyze', success=True, cost=0.05)
```

---

## Global Configuration

Applications configure providers at startup:

```python
from anubis.core.config import set_base_dir_provider, set_toolkit_dir_provider

# Required: Base directory for workflow state
set_base_dir_provider(lambda: Path('/path/to/repo'))

# Optional: Toolkit directory for script access
set_toolkit_dir_provider(lambda: Path('/path/to/toolkit'))
```

These paths are automatically allowed for agent file access.
