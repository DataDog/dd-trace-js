# Workflow Configuration Reference

**File:** `anubis/core/workflow.py`

## WorkflowConfig (Decorator)

Configuration for the `@workflow` decorator.

```python
from anubis import workflow, WorkflowConfig

@workflow(WorkflowConfig(
    name="my_workflow",
    steps=[Step1, Step2, NestedWorkflow],
    prompt="optional_base_prompt",
))
class MyWorkflow:
    pass
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | str | Yes | Workflow identifier |
| `steps` | List[Type] | Yes | Steps/workflows to execute in order |
| `prompt` | str | No | Optional base prompt template |

---

## Workflow Constructor

```python
workflow = MyWorkflow(
    namespace="my-package",
    repository="dd_trace_js",
    user_prompt="Custom guidance",
    model="sonnet",
    headless=True,
    base_dir=Path("/custom/path"),
    config={...},
    step_configs={...},
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `namespace` | str | Required | Package/integration identifier |
| `repository` | str | 'dd_trace_js' | Target repository |
| `user_prompt` | str | None | Custom instructions for agents |
| `model` | str | None | Default model for agent steps |
| `headless` | bool | False | Disable interactive UI |
| `base_dir` | Path | None | Custom analysis directory |
| `config` | Dict | {} | Configuration passed to steps |
| `step_configs` | Dict | {} | Runtime step attribute overrides |

---

## config Dictionary

General configuration accessible via `ctx.config`.

### Standard Keys

| Key | Type | Description |
|-----|------|-------------|
| `skip_steps` | Set[str] | Step names to skip |
| `skip_review` | bool | Skip review workflow |
| `max_iterations` | int | Override composite max_iterations |
| `headless` | bool | Run without UI |

### Example

```python
workflow = MyWorkflow(
    namespace="kafkajs",
    config={
        'skip_steps': {'lint', 'review'},
        'skip_review': True,
        'custom_option': 'value',
    },
)
```

### Accessing in Steps

```python
def execute(self, input, ctx):
    skip_review = ctx.config.get('skip_review', False)
    custom = ctx.config.get('custom_option')
```

---

## step_configs Dictionary

Override step attributes at runtime. Keys are step names, values are attribute dicts.

### Example

```python
workflow = MyWorkflow(
    namespace="kafkajs",
    step_configs={
        # Override AgentStep settings
        'analyze': {
            'model': 'opus',
            'max_turns': 100,
            'sandbox': False,
        },
        # Override CompositeStep stage
        'diagnosis': {
            'sandbox': False,
            'timeout_minutes': 60,
        },
        # Disable validation for a step
        'compile': {
            'validation_required': False,
        },
    },
)
```

### Common Overrides

| Attribute | Type | Use Case |
|-----------|------|----------|
| `model` | str | Use different model for specific step |
| `max_turns` | int | Allow more agent turns |
| `sandbox` | bool | Disable sandbox for file writes |
| `timeout_minutes` | int | Extend timeout for slow steps |
| `validation_required` | bool | Skip validation |

---

## Workflow Hooks

### setup

```python
def setup(self, ctx: Context) -> Context:
    """Initialize context before steps run."""
    ctx.set('working_dir', Path('/my/project'))
    return ctx
```

### after_step

```python
def after_step(self, step_name: str, output: Any, ctx: Context) -> Any:
    """Called after each step completes."""
    if step_name == 'analyze' and not output.targets:
        raise ResetToStep('prepare', guidance="No targets found")
    return output
```

### on_workflow_complete

```python
def on_workflow_complete(self, success: bool, output: Optional[O]) -> None:
    """Called when workflow finishes."""
    pass
```

### validate_step_input

```python
def validate_step_input(self, input: Any, step: Step, ctx: Context) -> Any:
    """Custom input validation before each step."""
    return input
```

### create_emitter

```python
def create_emitter(self) -> EventEmitter:
    """Create custom event emitter for terminal UI."""
    emitter = EventEmitter()
    emitter.add_listener(CustomListener())
    return emitter
```

### create_prompts

```python
def create_prompts(self) -> Prompts:
    """Provide custom prompt loader."""
    return CustomPrompts(self.repository)
```

---

## Result Object

```python
class Result(Generic[O]):
    success: bool
    output: Optional[O]      # On success
    error: Optional[str]     # On failure
    duration_ms: float
```

### Usage

```python
result = workflow.run(MyInput(...))

if result.success:
    print(f"Output: {result.output}")
    print(f"Duration: {result.duration_ms}ms")
else:
    print(f"Error: {result.error}")
```

---

## Error Handling

### ResetToStep

Reset workflow to an earlier step:

```python
from anubis.core.errors import ResetToStep

def after_step(self, step_name, output, ctx):
    if needs_redo:
        raise ResetToStep('earlier_step', guidance="Please fix X")
    return output
```

### WorkflowError

Standard error for workflow failures:

```python
from anubis.core.errors import WorkflowError

raise WorkflowError("Configuration invalid")
```

### ValidationError

Raised when validation fails and cannot be fixed:

```python
from anubis.core.errors import ValidationError
# Raised automatically when validation_required=True
```

---

## State Persistence

Workflow state auto-persists to `.analysis/{namespace}/{workflow}/`.

### Directory Structure

```
.analysis/{namespace}/{workflow}/
├── state.json       # Checkpoints, metrics, data
├── input.json       # Workflow input
├── output.json      # Workflow output
├── artifacts/       # Named artifacts
└── steps/
    ├── {step}-{attempt}/
    │   ├── input.json
    │   ├── output.json
    │   └── logs/
    └── {composite}:att{N}:iter{M}:{stage}:iter{K}/
```

### Resume Behavior

- Completed steps skipped on re-run
- Cached outputs rehydrated with proper types
- `ctx.get()` restores Pydantic models automatically

### Manual State Operations

```python
from anubis.core.state import WorkflowState

# Load existing state
state = WorkflowState.load("my_workflow", "kafkajs", base_dir)

# Rollback to step
state.rollback("analyze", base_dir)
state.save(base_dir)

# Clear all state
state.clear()
state.save(base_dir)
```
