# Context API Reference

**File:** `anubis/core/context/context.py`

The Context object is passed to all steps and provides access to state, logging, artifacts, and configuration.

## Properties

| Property | Type | Description |
|----------|------|-------------|
| `workflow` | str | Current workflow name |
| `namespace` | str | Package/integration name |
| `repository` | str | Target repository identifier |
| `base_dir` | Path | Repository root directory |
| `config` | Dict | Workflow configuration dict |
| `state` | WorkflowState | State management object |
| `prompts` | Prompts | Prompt template loader |
| `headless` | bool | Running without UI |
| `current_step` | str | Current step name |
| `current_attempt` | int | Current attempt/iteration number |
| `parent_workflow` | str | Parent workflow name (if nested) |
| `artifacts_dir` | Path | Workflow artifacts directory |

## Data Storage

### set / get

```python
# Store value (persisted to state.json)
ctx.set('key', value)

# Retrieve value
value = ctx.get('key')
value = ctx.get('key', default='fallback')

# Pydantic models auto-registered for type preservation
ctx.set('analysis', AnalysisModel(targets=[...]))
analysis = ctx.get('analysis')  # Returns AnalysisModel instance on resume
```

### Type Registry

When storing Pydantic models, their types are automatically registered:

```python
ctx.set('my_model', MyPydanticModel(...))
# On resume, ctx.get('my_model') returns MyPydanticModel instance, not dict
```

To manually register types (e.g., for nested models):

```python
ctx.register_type(MyNestedModel)
```

## Artifacts

### save_artifact

```python
# Save dict/model as JSON
path = ctx.save_artifact('report', {'findings': [...]})
# Saves to: .analysis/{namespace}/{workflow}/artifacts/report.json

# Save Pydantic model
path = ctx.save_artifact('analysis', AnalysisModel(...))

# Custom extension
path = ctx.save_artifact('data', content, extension='.yaml')
```

### save_artifact_file

```python
# Copy existing file to artifacts
ctx.save_artifact_file(Path('output.json'))
# Copies to: artifacts/output.json

# With custom name
ctx.save_artifact_file(Path('/tmp/result.json'), name='final_result')
# Copies to: artifacts/final_result.json
```

### load_artifact

```python
# Load as dict
data = ctx.load_artifact('report')

# Load with type validation
model = ctx.load_artifact('analysis', AnalysisModel)
```

### artifact_path

```python
# Get path for artifact (may not exist yet)
path = ctx.artifact_path('my_file.json')
```

## Logging

### Log Methods

```python
ctx.info("Processing package...")
ctx.warn("Optional field missing")
ctx.error("Failed to process target")
ctx.success("Analysis complete")
```

### Event Emission

```python
# Emit custom event (picked up by terminal UI)
ctx.emit('custom_event', key='value', count=42)

# Standard events
ctx.emit('phase_start', phase='Analysis', number=1, total=5)
ctx.emit('phase_complete', phase='Analysis', success=True)
ctx.emit('batch_start', items=['a', 'b', 'c'])
ctx.emit('batch_item_complete', item_id='a', success=True)
```

## Paths

### Directory Methods

```python
# Current step's log directory
log_dir = ctx.step_logs()
# Returns: .analysis/{namespace}/{workflow}/steps/{step}-{attempt}/logs/

# Current step's data directory
step_dir = ctx.step_dir()
# Returns: .analysis/{namespace}/{workflow}/steps/{step}-{attempt}/

# Workflow artifacts directory
artifacts = ctx.artifacts_dir
# Returns: .analysis/{namespace}/{workflow}/artifacts/
```

## Configuration

### Accessing Config

```python
# Direct dict access
value = ctx.config.get('custom_key', 'default')

# Common patterns
skip_steps = ctx.config.get('skip_steps', set())
max_iterations = ctx.config.get('max_iterations', 10)
```

### Standard Config Keys

| Key | Type | Description |
|-----|------|-------------|
| `skip_steps` | Set[str] | Step names to skip |
| `skip_review` | bool | Skip review steps |
| `max_iterations` | int | Override max iterations |
| `headless` | bool | Run without UI |

## Metrics

### add_agent_metrics

```python
# Called automatically by AgentStep, but can be called manually
ctx.add_agent_metrics(
    metrics={
        'cost_usd': 0.05,
        'duration_seconds': 120,
        'num_turns': 15,
    },
    task_description='analyze_targets'
)
```

### get_total_cost

```python
total = ctx.get_total_cost()  # Returns float
```

### emit_cost_summary

```python
# Emits cost summary event for terminal display
ctx.emit_cost_summary()
```

### metric

```python
# Record custom metric
ctx.metric('targets_found', 15)
ctx.metric('processing_time_ms', 1234)
```

## State Access

### Direct State Access

```python
# Check if step completed
if ctx.state.is_completed('analyze'):
    output = ctx.state.get_output('analyze')

# Get all completed steps
completed = ctx.state.get_completed_steps()

# Checkpoint manually (usually automatic)
ctx.state.checkpoint('my_step', output)
ctx.state.save(ctx.base_dir)
```

### Rollback

```python
from anubis.core.errors import ResetToStep

# In workflow's after_step hook
def after_step(self, step_name, output, ctx):
    if needs_redo:
        raise ResetToStep('earlier_step', guidance="Please fix X")
    return output
```

## Isolated Context (Batch)

For parallel batch execution, contexts are isolated:

```python
# Create isolated copy (no shared state)
isolated = ctx.copy_isolated()

# Isolated context:
# - Has own data dict
# - Cannot modify parent state
# - Metrics collected separately
```

## Prompt Loading

### Via ctx.prompts

```python
# Load prompt template
prompt = ctx.prompts.load('analyze', package_name=ctx.namespace)

# Check if template exists
if ctx.prompts.exists('custom-prompt'):
    prompt = ctx.prompts.load('custom-prompt')

# Load with output schema
prompt = ctx.prompts.load(
    'generate',
    output_schema=GenerateOutput,
    package_name=ctx.namespace,
)
```

## Complete Example

```python
def execute(self, input: AnalyzeInput, ctx: Context) -> AnalyzeOutput:
    ctx.info(f"Analyzing {ctx.namespace}")

    # Access config
    max_targets = ctx.config.get('max_targets', 50)

    # Load previous data
    docs = ctx.get('collected_docs', [])

    # Process
    targets = analyze(input, docs, max_targets)

    # Save artifact
    ctx.save_artifact('raw_targets', {'targets': targets})

    # Store for next step
    ctx.set('target_count', len(targets))

    # Log progress
    ctx.success(f"Found {len(targets)} targets")

    return AnalyzeOutput(targets=targets)
```
