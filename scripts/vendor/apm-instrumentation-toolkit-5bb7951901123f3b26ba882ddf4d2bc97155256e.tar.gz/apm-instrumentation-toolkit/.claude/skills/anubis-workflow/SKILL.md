---
name: anubis-workflow
description: Guide for creating workflows using the anubis framework. Use when users ask to create a new workflow, step, or agent step in anubis or anubis_apm. Triggers include "create a workflow", "add a new step", "make an agent step", "how do I use anubis", or questions about batching, validation, CompositeStep, step_configs, or workflow configuration.
---

# Anubis Workflow Creation Guide

Create workflows that orchestrate AI agents and automation steps.

## Workflow Discovery Process

Before building a workflow, use the `AskUserQuestion` tool to gather requirements through collaborative consultation. Don't assume - ask clarifying questions when information is missing.

### Key Questions to Ask

**Goal & Outcome:**
- What is the workflow's purpose?
- What does success look like? What's the expected output?
- Can you show an example PR/change that represents the ideal outcome?

**Input & Context:**
- What triggers this workflow?
- What information is available at start? (package name, paths, config)
- Where does relevant code live? Which files/directories?

**Process & Steps:**
- What are the main phases?
- Which steps need AI agents vs simple automation?
- Should any steps loop until a condition is met?

**Validation & Quality:**
- How do we know output is correct?
- What errors should we catch and retry?

**Environment:**
- What tools/commands are needed? (lint, test, build)
- What files can be modified?

### Using AskUserQuestion

When requirements are unclear, use `AskUserQuestion` to gather information:

```
# Example: User says "I want to automate adding DSM support"

Use AskUserQuestion with questions like:
- "Which integration are you targeting?" with options for common packages
- "What does DSM support look like?" asking for example PR or file paths
- "What tests need to pass?" to understand validation criteria
```

### Information Checklist

Before implementing, ensure you have:
- [ ] Clear goal statement
- [ ] Example of desired output (if available)
- [ ] Input data sources identified
- [ ] Step sequence outlined
- [ ] Validation criteria defined
- [ ] Relevant file paths known

---

## Quick Start

### Workflow with Decorator API

```python
from anubis import workflow, step, agent_step, WorkflowConfig, StepConfig, AgentStepConfig
from pydantic import BaseModel

class AnalyzeOutput(BaseModel):
    targets: list[str]
    summary: str

@step(StepConfig(name="prepare", output_type=PrepareOutput))
def prepare_step(input, ctx):
    # Synchronous step logic
    return PrepareOutput(...)

@agent_step(AgentStepConfig(
    name="analyze",
    prompt="analyze",  # Template in prompts/
    output_type=AnalyzeOutput,
    model="sonnet",
    max_turns=50,
))
class AnalyzeStep:
    def get_prompt_variables(self, input, ctx):
        return {"package": ctx.namespace}

@workflow(WorkflowConfig(
    name="my_workflow",
    steps=[prepare_step, AnalyzeStep],
))
class MyWorkflow:
    def setup(self, ctx):
        ctx.set('config_key', 'value')
        return ctx
```

### Running a Workflow

```python
wf = MyWorkflow(
    namespace="my-package",
    repository="dd_trace_js",
    headless=True,
    base_branch="develop",  # Optional: branch from specific base (default: auto-detect)
    step_configs={
        'analyze': {'model': 'opus', 'max_turns': 100},
        'diagnosis': {'sandbox': False},
    },
)
result = wf.run(MyInput(package_name="my-package"))

if result.success:
    print(f"Output: {result.output}")
```

## Step Types

### Step (Base)

For synchronous logic without AI agents.

```python
from anubis import step, StepConfig

@step(StepConfig(
    name="process",
    output_type=ProcessOutput,
    validators=[my_validator],
))
def process_step(input, ctx):
    # Access context
    data = ctx.get('key')
    ctx.set('result', value)

    # Save artifacts
    ctx.save_artifact('report', {'findings': [...]})

    return ProcessOutput(result=data)
```

**Configuration:**
- `output_type` - Pydantic model for validation
- `validators` - List of validator functions
- `validation_required` - Raise on validation failure (default: True)
- `optional` - Step failure doesn't fail workflow (default: False)
- `fixer_prompt` - Prompt template for auto-fix on validation failure
- `fixer_model` - Model for fixer agent (default: 'sonnet')
- `max_fixer_iterations` - Max fix attempts (default: 3)

### AgentStep

Spawns an AI agent with structured output.

```python
from anubis import agent_step, AgentStepConfig

@agent_step(AgentStepConfig(
    name="analyze",
    prompt="analyze",           # Prompt template name
    output_type=AnalysisOutput, # Required - structured output schema
    model="sonnet",             # sonnet, opus, haiku
    max_turns=50,               # Max agent turns
    timeout_minutes=30,
    skills=["read-docs"],       # Skills to load for agent
    output_file="analysis.json",# Save output to file
    use_repo_root=False,        # Working dir: analysis dir vs repo root
    sandbox=True,               # Run in sandbox (default: True)
    planning=False,             # Run read-only planning phase first
))
class AnalyzeStep:
    def get_prompt_variables(self, input, ctx):
        """Add custom variables to prompt template."""
        return {
            "package": ctx.namespace,
            "targets": input.targets,
        }
```

**Key features:**
- Automatic prompt building with schema injection
- Output caching when step already completed
- Session resumption on fix attempts
- Validation with auto-fix loop

### CompositeStep

Runs multiple stages with optional looping.

```python
from anubis import composite_step, CompositeStepConfig

@composite_step(CompositeStepConfig(
    name="test_fixer",
    output_type=TestResult,
    stages=[DiagnosisStage, FixerStage],
    max_iterations=10,
))
class TestFixer:
    def should_continue(self, output, ctx):
        """Return True to continue looping."""
        return not output.tests_passing

    def before_iteration(self, iteration, input, ctx):
        """Transform input before each iteration."""
        ctx.info(f"Starting iteration {iteration}")
        return input

    def after_iteration(self, iteration, output, ctx):
        """Transform output between iterations."""
        return output

    def after_stage_execute(self, stage_name, output, ctx):
        """Called after each stage completes."""
        return output

    def should_exit_early(self, stage_name, output, ctx):
        """Exit pipeline early after a stage."""
        return stage_name == "diagnosis" and output.no_failures
```

## Batching

Process multiple items in parallel or sequentially.

### Parallel Batch (batch_size > 1)

```python
@agent_step(AgentStepConfig(
    name="review_checks",
    prompt="review",
    output_type=CheckResult,
    batch_execute=True,
    batch_size=4,  # Parallel workers
))
class BatchReviewStep:
    def prepare_batch(self, input, ctx):
        """Return list of items to process."""
        return input.checks  # Each check processed by separate agent

    def aggregate_batch(self, results, ctx):
        """Combine results from all items."""
        return BatchResult(
            checks=[r for r in results if r],
            total=len(results),
        )
```

**Parallel behavior:**
- Items processed in thread pool with isolated contexts
- No shared state between threads
- Metrics aggregated after completion
- Progress tracked via batch events

### Sequential Batch (batch_size = 1)

```python
@step(StepConfig(
    name="process_items",
    output_type=ItemResult,
    batch_execute=True,
    batch_size=1,  # Sequential
))
def process_items(input, ctx):
    # Called once per item, shared context
    return ItemResult(...)
```

**Sequential behavior:**
- Items processed one at a time
- Shared context with full state access
- Each item checkpointed individually

## Validation

### Validator Functions

```python
from anubis.core.validation import has_field, min_items

# Signature: (output, ctx, output_type) -> bool | str | List[str]
def validate_targets(output, ctx, output_type=None):
    if not output.targets:
        return "No targets found"
    if len(output.targets) < 2:
        return f"Need at least 2 targets, got {len(output.targets)}"
    return True  # Valid

@step(StepConfig(
    name="analyze",
    output_type=AnalysisOutput,
    validators=[
        has_field("targets"),
        min_items("targets", 2),
        validate_targets,
    ],
))
def analyze_step(input, ctx):
    ...
```

### Auto-Fix with Fixer Prompt

```python
@step(StepConfig(
    name="generate",
    output_type=GenerateOutput,
    validators=[validate_output],
    fixer_prompt="generate-fixer",  # Template for fix attempts
    max_fixer_iterations=3,
))
def generate_step(input, ctx):
    ...
```

AgentSteps auto-fix by re-running with validation errors appended to prompt.

## Context API

The context object (`ctx`) provides data storage, artifacts, logging, and paths. Key methods:

```python
ctx.set('key', value)              # Store data (persisted)
ctx.get('key', default)            # Retrieve data
ctx.save_artifact('name', data)    # Save artifact
ctx.info("message")                # Log info/warn/error/success
```

See **[references/context-api.md](references/context-api.md)** for full API.

## Step Configuration & Workflow Hooks

Override step attributes at runtime via `step_configs` parameter:

```python
wf = MyWorkflow(
    namespace="kafkajs",
    step_configs={
        'analyze': {'model': 'opus', 'max_turns': 100},
        'diagnosis': {'sandbox': False},
    },
)
```

Workflow hooks available: `setup()`, `after_step()`, `on_workflow_complete()`, `validate_step_input()`.

See **[references/workflow-config.md](references/workflow-config.md)** for details.

## Nested Workflows

Use workflows as steps in other workflows:

```python
from anubis_apm.workflows.analyze import AnalyzeWorkflow

@workflow(WorkflowConfig(
    name="full_integration",
    steps=[
        AnalyzeWorkflow,    # Nested workflow
        CompileStep,
        TestStep,
    ],
))
class FullIntegrationWorkflow:
    pass
```

Nested workflows:
- Share artifacts with parent (via `_parent_artifacts`)
- Aggregate metrics to parent
- Have separate state files

## State & Resume

State auto-persists to `.analysis/{namespace}/{workflow}/state.json`.

```
.analysis/my-package/my_workflow/
├── state.json       # Checkpoints, metrics, data
├── artifacts/       # Named artifacts
└── steps/
    ├── analyze-1/   # Step data
    │   ├── input.json
    │   ├── output.json
    │   └── logs/
    └── test:iter1:diagnosis:iter1/  # Composite stage
```

**Resume behavior:**
- Completed steps skipped on re-run
- Cached output rehydrated with proper types
- `ctx.get()` restores Pydantic models automatically

## Best Practices

### Step Design

1. **Single responsibility** - One step, one task
2. **Typed I/O** - Always use Pydantic models for input/output
3. **Validation** - Add validators for critical output fields
4. **Idempotency** - Steps should be safe to re-run

### Agent Steps

1. **Focused prompts** - Clear, specific instructions
2. **Reasonable max_turns** - Start with 50, adjust based on task
3. **Output files** - Save important outputs for debugging
4. **Skills** - Load relevant skills for the task

### Workflows

1. **Checkpointing** - Automatic, but consider step granularity
2. **Config over code** - Use `config` dict for customization
3. **Error handling** - Let framework handle retries
4. **Nested workflows** - Reuse existing workflows as steps

## Reference Files

See detailed API documentation in:

### Core Framework
- **[references/step-api.md](references/step-api.md)** - Step class attributes and methods
- **[references/context-api.md](references/context-api.md)** - Full context API
- **[references/workflow-config.md](references/workflow-config.md)** - Workflow configuration options

### Agent Infrastructure
- **[references/prompt-loading.md](references/prompt-loading.md)** - Prompt template loading and rendering
- **[references/skill-loading.md](references/skill-loading.md)** - Skill loading, installation, and creation
- **[references/agents-sdk.md](references/agents-sdk.md)** - Claude Agents SDK integration

### APM-Specific
- **[references/anubis-apm.md](references/anubis-apm.md)** - dd-trace adapter and APM workflows
