## Review

See [docs/REVIEW.md](docs/REVIEW.md) for the full review checklist. All PRs must be evaluated against it.

## Getting Started

**Setup:**
```bash
make dev   # creates .venv, installs deps, runs dd-apm setup
```
`bin/dd-apm` auto-detects `.venv` — no need to activate manually.

## Project Overview

APM Instrumentation Toolkit automates APM instrumentation for Datadog tracers using AI agents orchestrated through a workflow framework called **anubis**.

The toolkit ships a **Claude Code plugin** (`plugin/`) for driving workflows interactively. **To run toolkit workflows, use `/instrument <package>`** — this loads the `drive-toolkit` skill which handles setup verification, step-by-step execution, output review, and failure recovery. Do not call `dd-apm` commands directly; the skill manages the full lifecycle.

Plugin manifests: `.claude-plugin/marketplace.json` (marketplace) and `plugin/.claude-plugin/plugin.json` (plugin). When changing workflow steps, step descriptions, or the CLI surface, also update `plugin/skills/drive-toolkit/` so the driving agent stays in sync.

## Architecture

**Two-package design - this separation is critical:**

| Package | Purpose | Rule |
|---------|---------|------|
| `anubis/` | Generic workflow framework | Language-agnostic, reusable for any domain |
| `anubis_apm/` | dd-trace specific | All APM/tracer code goes here |

**If it could work for any workflow domain → `anubis/`**
**If it's APM/dd-trace specific → `anubis_apm/`**

### Key Directories

```
anubis/
├── _api.py              # Decorator API (@step, @agent_step, @workflow)
├── core/
│   ├── steps/           # Step, AgentStep, CompositeStep base classes
│   │   └── executors/   # Step execution logic
│   ├── workflow.py      # Workflow orchestration
│   ├── context/         # Context API (ctx.set, ctx.get, artifacts)
│   ├── validation/      # Validators, fixer loop
│   ├── config/          # ConfigLoader, get_config()
│   ├── resources/       # PromptLoader, SkillLoader, ResourceManager
│   └── agents/
│       ├── spawn.py     # spawn_agent() entry point
│       └── runners/     # Claude SDK runner

anubis_apm/
├── workflows/           # APM workflows (analyze, test, lint, feature)
├── steps/               # APM-specific steps
├── prompts/
│   └── shared/          # Shared prompt templates
│       ├── {workflow}/          # One dir per workflow
│       │   ├── prompt.md        # Generic prompt (uses {{include_repo:name}})
│       │   └── repo/{repo}/     # Repo-specific fragments (auto-included)
│       └── instrumentation/     # Example: categories/, references/, repo/dd_trace_js/
├── skills/
│   └── node/            # Domain skills for agents
└── repo_adapters/
    └── dd_trace_js.py   # DDTraceJsAdapter
```

## Code Style

### Required
- **No inline imports** - All imports at file top (ruff PLC0415)
- **No bare try/except** - Catch specific exceptions (`except ValueError:`)
- **Pydantic models** - All step I/O must be typed models
- **Type hints** - Use generics for `Step[I, O]`

### Import Ordering
```python
# stdlib
from pathlib import Path
from typing import List, Optional

# third-party
from pydantic import BaseModel

# local
from anubis import step, StepConfig
from anubis.core.context import Context
```

### Lint
```bash
ruff check anubis/ anubis_apm/       # Check
ruff check anubis/ anubis_apm/ --fix # Auto-fix
```

## Commands

### Development
```bash
pytest tests/                         # All tests
pytest tests/path/to/test.py         # Single file
pytest tests/path/to/test.py -k "name"  # Specific test

# Build docs (matches CI - no cache, warnings as errors)
sphinx-build -E -b html -W docs/sphinx/source docs/sphinx/build
```

### CLI (for testing workflows)
```bash
# Workflows
dd-apm analyze <pkg>                 # Analyze package, identify instrumentation targets
dd-apm create <pkg> --mode=agent     # Create integration (autonomous)
dd-apm create <pkg>                  # Create integration (guided, default)
dd-apm test <pkg>                    # Test diagnosis/fix
dd-apm lint <pkg> --fix              # Lint with auto-fix
dd-apm review <pkg>                  # Code review
dd-apm semantic <pkg>                # Semantic validation (evalya)
dd-apm execute <pkg> --spec <file-or-text>  # Spec-driven plan→review→implement (catch-all)
dd-apm execute <pkg> --source <issue-url>  # Same, seeded from GitHub issue/PR/Actions URL
dd-apm llm-obs <pkg>                 # Generate LLMObs layer (requires tracing plugin)
dd-apm feature add <pkg>             # Auto-detect and add features
dd-apm pr <pkg> --babysit            # Open PR and watch CI
dd-apm generate-sample-app --spec <file-or-text> --output-dir <path>

# PR auto-fix daemon (see .claude/babysit-prs/)
.claude/babysit-prs/start.sh         # Start daemon (auto-inits on first run)
.claude/babysit-prs/start.sh --once  # One scan and exit
pkill -f watch.py                    # Stop daemon (terminates running agents)

# Workflow control flags (shared by all workflow commands)
dd-apm create <pkg> --from compile   # Resume from a specific step
dd-apm create <pkg> --from compile --rollback-git  # Resume + reset repo to step's git snapshot
dd-apm create <pkg> --stop-after compile  # Run up to and including compile, then stop
dd-apm create <pkg> --skip test,lint # Skip specific steps

# State management
dd-apm status <pkg>                  # Check progress
dd-apm list                          # List all integrations
dd-apm clean <pkg>                   # Clean state
dd-apm clean <pkg> --workflow llmobs # Clean specific workflow
dd-apm diff <pkg>                    # View changes
dd-apm open <pkg>                    # Open in IDE
dd-apm claude <pkg>                  # Review with Claude Code
dd-apm steps <workflow>              # List steps for a workflow (auto-discovered)
dd-apm rollback <pkg> <step>         # Roll back to a previous checkpoint
dd-apm rollback <pkg> <step> --rollback-git  # Also reset repo files

# First-run setup & health check
dd-apm setup                         # Install deps, run auth flows, configure (first run)
dd-apm doctor                        # Health check: print status of all prerequisites
dd-apm doctor --required             # Only check required prerequisites
dd-apm doctor --json                 # Machine-readable output (for CI / agents)
dd-apm smoke                         # End-to-end smoke test: spawn agent, verify full stack
dd-apm update                        # Upgrade dogbrew formula + re-run doctor
dd-apm version                       # Show toolkit version

# Configuration
dd-apm config init                   # Interactive setup (detect, clone, configure repos)
dd-apm config list                   # List configured repositories
dd-apm config clone <repo>           # Clone and configure a known repo
dd-apm config clone <repo> --path ~  # Clone to specific directory
dd-apm config add-repo <name> <path> # Add repo manually
dd-apm config remove-repo <name>     # Remove a configured repo

# Eval
dd-apm eval run-matrix               # Score method-selection eval for all packages
dd-apm eval run-matrix --run         # Run + score (requires AI Gateway)
dd-apm eval run-matrix --model anthropic/claude-haiku-4-5-20251001  # Override model for all steps
dd-apm eval run-matrix --model openai/gpt-4o  # Non-Anthropic model (experimental — see note below)
dd-apm eval clean <pkg>              # Remove generated integration for re-eval

# Experience store
dd-apm sync setup                    # Check prerequisites and auth
dd-apm sync push <pkg>               # Push current run to S3
dd-apm sync pull [<pkg>]             # Pull latest runs from S3
dd-apm sync list [<pkg>]             # List stored runs
dd-apm sync inspect <run-id>         # Show run manifest
dd-apm sync refresh                  # Refresh local S3 index
```

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `DD_TRACER_REPO` | Path to dd-trace-js repository (required) |
| `ANTHROPIC_API_KEY` | Claude API key for agent steps |
| `ANTHROPIC_MODEL` | Override model for all agent steps (fully-qualified ID: `anthropic/claude-haiku-4-5-20251001`, `openai/gpt-4o`, etc.). Set automatically by `--model` flag. |
| `DD_APM_BASE_BRANCH` | Base branch in target repo (default: auto-detect main/master) |
| `DD_APM_DEBUG=1` | Enable debug output |
| `DD_TRACE_ENABLED=false` | Disable tracing (for tests) |
| `DD_APM_S3_UPLOAD_LOGS=1` | Include agent logs in S3 uploads (large, opt-in) |

> **Non-Anthropic models (e.g. `openai/gpt-4o`, `gemini/...`) are experimental.** Prompt format, tool use, and structured output behaviour differ across providers and may break workflows. If you hit issues, please [open a GitHub issue](https://github.com/DataDog/apm-instrumentation-toolkit/issues) on the toolkit board.

## Quick Reference

### Creating a Step
```python
from anubis import step, StepConfig
from pydantic import BaseModel

class MyOutput(BaseModel):
    result: str

@step(StepConfig(name="my_step", output_type=MyOutput))
def my_step(input, ctx):
    ctx.info("Processing...")
    return MyOutput(result="done")
```

### Creating an AgentStep
```python
from anubis import agent_step, AgentStepConfig

@agent_step(AgentStepConfig(
    name="analyze",
    prompt="analyze",           # Template in prompts/
    output_type=AnalysisOutput,
    model="sonnet",
    max_turns=50,
    skills=["datadog-semantics"],
))
class AnalyzeStep:
    def get_prompt_variables(self, input, ctx):
        return {"package": ctx.namespace}
```

### Creating a Workflow
```python
from anubis import workflow, WorkflowConfig

@workflow(WorkflowConfig(
    name="my_workflow",
    steps=[PrepareStep, AnalyzeStep],
))
class MyWorkflow:
    def setup(self, ctx):
        ctx.set('initialized', True)
        return ctx
```

## State & Debugging

Workflow state persists to `.analysis/{namespace}/{workflow}/`:
```
.analysis/kafkajs/new_integration/
├── state.json           # Checkpoints, metrics, run_id
├── artifacts/           # Named artifacts
└── steps/
    └── analyze-1/
        ├── input.json
        ├── output.json
        └── logs/agent.log  # Agent transcript
```

**Experience cache** (read-only, separate from active state):
```
.analysis/.experience/
├── index.json                                    # Cached S3 manifest index
└── dd_trace_js/kafkajs/new_integration/<run_id>/  # Selectively pulled step outputs
```

**Debug commands:**
```bash
cat .analysis/kafkajs/new_integration/state.json | jq .
cat .analysis/kafkajs/new_integration/steps/analyze-1/logs/agent.log
dd-apm clean kafkajs  # Reset state (does NOT touch .experience/ cache)
```

## Experience Store

S3-backed storage of workflow run artifacts, enabling cross-run learning. S3 sync (push/pull) is always on — workflows automatically push results and pull relevant past runs at startup. To inject past run experience into agent prompts, pass `--experience` (experimental).

Based on research showing agents reliably use raw experience (full trajectories, actual outputs) but ignore condensed experience (heuristics, summaries).

**Setup:** `dd-apm sync setup` checks all prerequisites. See [docs/experience-store.md](docs/experience-store.md) for details.

## Adding New Code

| Adding... | Location |
|-----------|----------|
| Core framework feature | `anubis/core/` |
| New workflow | `anubis_apm/workflows/` |
| New step | `anubis_apm/steps/` |
| Shared prompt template | `anubis_apm/prompts/shared/{workflow}/prompt.md` |
| Repo-specific prompt fragment | `anubis_apm/prompts/shared/{workflow}/repo/{repo}/` |
| Agent skill | `anubis_apm/skills/node/` |
| New tracer support | `anubis_apm/repo_adapters/` |
| Storage/experience feature | `anubis_apm/storage/` (S3, manifest, auth) |
| Experience scoring/cache | `anubis/core/experience/` (generic) |
| Generic eval plumbing | `anubis/eval/` (`EvalResult`, `MatrixRunner`, `EvalOrchestrator`, LLMObs submission) |
| APM eval (method selection) | `anubis_apm/eval/analyze/` (task, GT matching, orchestration, LLMObs with APM metrics) |
| Ground truths | `anubis_apm/eval/analyze/datasets/ground_truths/{repo}/{category}/{pkg}-targets.json` |

## Evals

Method-selection evals score how well the analyze workflow identifies instrumentation targets.

**CI:** Wired into `.gitlab-ci.yml` as the `eval-run-matrix` job (stage: `eval`). Runs on schedule (weekly) and manual dispatch. Currently covers `dd_trace_js`, `dd_trace_py`, `dd_trace_java`.

**Layer split:**
- `anubis/eval/` — generic: `EvalResult`, `MatrixRunner`, `EvalOrchestrator`, `submit_eval_results`. No APM concepts.
- `anubis_apm/eval/analyze/` — APM-specific: ground truth loading, target matching, precision/recall/F1 metrics, detail report.

**Ground truths** live under `anubis_apm/eval/analyze/datasets/ground_truths/{repo}/{category}/{pkg}-targets.json`. Each file has a `targets` list with `class`, `method`, `critical` (recall denominator), `acceptable` (skip penalty if missed), and `alternatives` (valid alternate hook points).

**Adding a new repo to evals:**
1. Add ground truth files under `datasets/ground_truths/{repo}/`
2. Implement `get_ground_truths_path()` in the repo adapter
3. Add the repo slug to the `EVAL_REPOSITORY` matrix in `.gitlab-ci.yml` and add its clone URL to the `case` block

## See Also

- `.claude/skills/` - Canonical detailed skills for workflows, contributing, debugging
- `.agents/skills` - Generic coding-agent bridge to the same skills
- `docs/ANUBIS-CORE.md` - Framework documentation
- `docs/ANUBIS-APM.md` - APM-specific documentation
- `docs/experience-store.md` - Experience store architecture and setup
- `docs/RELEASING.md` - How to cut a release

## Project Principles

- **No legacy/backward compatibility** - This project does not need to maintain backward compatibility. Clean breaks are preferred over compatibility shims.

## Git Commit Rules

- **NEVER use `--no-gpg-sign`** - All commits must be GPG signed. If GPG signing fails, fix the GPG issue rather than bypassing it.
