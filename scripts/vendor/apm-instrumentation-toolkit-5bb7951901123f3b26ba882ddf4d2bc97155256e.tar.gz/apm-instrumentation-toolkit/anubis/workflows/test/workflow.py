"""Test Workflow definition - iterates diagnosis → fixer until tests pass."""

from pathlib import Path
from typing import Dict, List, Optional

from ...core import Workflow
from .models import TestInput, TestResult
from .steps import TestStep


class TestWorkflow(Workflow[TestInput, TestResult]):
    """Run tests and fix failures iteratively.

    The workflow uses TestStep (CompositeStep) which handles
    the diagnosis → fixer loop internally.

    Example::

        workflow = TestWorkflow(
            test_command="npm test",
            working_dir=Path("/my/project"),
        )
        result = workflow.run(TestInput())

        if result.success:
            print(f"Tests passing after {result.output.iterations} iterations")

    """

    name = "test"
    steps = [TestStep]

    def __init__(
        self,
        working_dir: Path,
        test_command: str,
        paths: Optional[List[str]] = None,
        prompts: Optional[Dict[str, str]] = None,
        skills: Optional[List[str]] = None,
        prompt_variables: Optional[Dict[str, str]] = None,
        integration: str = "",
        repository: str = "dd_trace_js",
        **options,
    ):
        """
        Args:
            working_dir: Directory to run in
            test_command: Command to run tests
            paths: Paths to focus on (optional)
            prompts: Custom prompts dict, e.g. {"diagnosis": "custom-diagnosis"}
            skills: Skills to provide to agents
            prompt_variables: Extra variables to inject into prompt templates
            integration: Optional integration name (for logging)
            repository: Repository (default: dd_trace_js)
        """
        self.working_dir = Path(working_dir)
        options.setdefault("namespace", integration)
        options.setdefault("repository", repository)
        super().__init__(base_dir=self.working_dir, **options)
        self.test_command = test_command
        self.paths = paths or []
        self.custom_prompts = prompts or {}
        self.skills = skills or []
        self.prompt_variables = prompt_variables or {}

    def _setup(self):
        """Setup context with test configuration."""
        ctx = super()._setup()

        ctx.set("working_dir", self.working_dir)
        ctx.set("test_command", self.test_command)
        ctx.set("paths", self.paths)
        ctx.set("skills", self.skills)
        ctx.set("prompt_variables", self.prompt_variables)

        for step_name, prompt_name in self.custom_prompts.items():
            ctx.set(f"{step_name}_prompt", prompt_name)

        return ctx
