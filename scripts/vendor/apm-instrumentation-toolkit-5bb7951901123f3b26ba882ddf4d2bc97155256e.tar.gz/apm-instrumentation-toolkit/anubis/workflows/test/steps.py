"""Test workflow steps - DiagnosisStage and FixerStage.

Uses CompositeStep to handle the diagnosis → fixer loop.
Previous context is injected via before_iteration.
"""

from typing import TYPE_CHECKING, Any, Dict, List

from ...core.steps import AgentStep, CompositeStep

if TYPE_CHECKING:
    from ...core.context import Context

from .models import DiagnosisResult, FixerResult, TestInput, TestResult


class DiagnosisStage(AgentStep[TestInput, DiagnosisResult]):
    """Analyze test failures and return structured diagnosis."""

    name = "diagnosis"
    prompt = "test/diagnosis"
    output_type = DiagnosisResult
    timeout_minutes = 30
    model = "sonnet"
    use_repo_root = True

    def get_prompt_variables(self, input: Any, ctx: "Context") -> Dict[str, str]:
        """Return variables for test-diagnosis prompt template.

        Base variables are provided here. Domain-specific variables
        (e.g., failure_modes, available_skills) should be set in context
        via ctx.set('prompt_variables', {...}) in the workflow's _setup().
        """
        attempt_dir = ctx.step_logs()
        attempt_dir.mkdir(parents=True, exist_ok=True)
        base_test_command = ctx.get("test_command", "")
        log_file = attempt_dir / "test-output.log"
        test_command = f"{base_test_command} 2>&1 | tee {log_file}; exit ${{PIPESTATUS[0]}}"

        # Check if this is a final review (fixer reported tests passing)
        fixer_reports_passing = ctx.get("fixer_reports_passing", False)
        if fixer_reports_passing:
            review_mode = """
## FINAL REVIEW MODE

**The fixer has reported that tests are now passing.** This is a FINAL REVIEW to verify:

1. Tests actually pass (run them to confirm)
2. Tests call the REAL library (not internal helpers)
3. All traced methods from analysis have test coverage
4. No missing test cases remain
5. Tests have proper assertions (not weak/generic)

**If ALL conditions are met, set `integration_complete: true` to finish.**
**If ANY issues remain, set `integration_complete: false` and list what's missing.**

---
"""
            # Reset the flag after reading it
            ctx.set("fixer_reports_passing", False)
        else:
            review_mode = ""

        return {
            "test_command": test_command,
            "attempt_dir": str(attempt_dir),
            "review_mode": review_mode,
        }


class FixerStage(AgentStep[DiagnosisResult, FixerResult]):
    """Apply fixes based on diagnosis."""

    name = "fixer"
    prompt = "test/fixer"
    output_type = FixerResult
    timeout_minutes = 60
    max_turns = 200
    model = "opus"
    use_repo_root = True
    validation_required = False  # Structured output failure is advisory

    def get_prompt_variables(self, input: DiagnosisResult, ctx: "Context") -> Dict[str, str]:
        """Return variables for test-fixer prompt template."""
        iteration = ctx.get("iteration", 1)
        attempt_dir = ctx.step_logs()
        attempt_dir.mkdir(parents=True, exist_ok=True)
        base_test_command = ctx.get("test_command", "")
        log_file = attempt_dir / "test-output.log"
        test_command = f"{base_test_command} 2>&1 | tee {log_file}; exit ${{PIPESTATUS[0]}}"

        suggestions = (
            "\n".join(f"- {s}" for s in input.suggestions) if input.suggestions else "None"
        )
        files_to_check = (
            "\n".join(f"- {f}" for f in input.files_to_check)
            if input.files_to_check
            else "See relevant source files"
        )

        # Format missing test cases
        if input.missing_test_cases:
            missing_lines = []
            for tc in input.missing_test_cases:
                priority_marker = (
                    "🔴" if tc.priority == "high" else "🟡" if tc.priority == "medium" else "⚪"
                )
                missing_lines.append(f"- {priority_marker} **{tc.name}**: {tc.description}")
            missing_test_cases = "\n".join(missing_lines)
        else:
            missing_test_cases = "None identified"

        previous_attempts = self._build_attempts_table(ctx)

        variables = {
            "test_command": test_command,
            "attempt_dir": str(attempt_dir),
            "iteration": str(iteration).zfill(2),
            "failure_mode": input.failure_mode or "unknown",
            "failure_description": input.failure_mode or "Unknown failure",
            "suggestions": suggestions,
            "files_to_check": files_to_check,
            "test_output_summary": input.test_output_summary or "No output captured",
            "log_file": str(attempt_dir / f"test-output-{str(iteration).zfill(2)}.log"),
            "previous_attempts": previous_attempts,
            "missing_test_cases": missing_test_cases,
        }
        return variables

    def _build_attempts_table(self, ctx: "Context") -> str:
        """Build compact table: iteration | tests | failure mode | fix applied."""
        diagnosis_history: List[DiagnosisResult] = ctx.get("diagnosis_history", [])
        fixer_history: List[FixerResult] = ctx.get("fixer_history", [])

        if len(diagnosis_history) <= 1:
            return "First attempt."

        rows = ["| # | Tests | Mode | Fix Applied |", "|---|-------|------|-------------|"]
        for i, diag in enumerate(diagnosis_history[:-1], 1):
            tests = f"{diag.passing}✓/{diag.failing}✗"
            mode = (diag.failure_mode or "-")[:30]
            fix = "-"
            if i <= len(fixer_history):
                fixer = fixer_history[i - 1]
                if fixer.changes_made:
                    fix = (
                        fixer.changes_made[0][:200] + "..."
                        if len(fixer.changes_made[0]) > 200
                        else fixer.changes_made[0]
                    )
            rows.append(f"| {i} | {tests} | {mode} | {fix} |")

        return "\n".join(rows)


class TestStep(CompositeStep[TestInput, TestResult]):
    """Iterative diagnosis → fixer pipeline until tests pass.

    Uses CompositeStep which handles:
    - Running stages in sequence
    - Iteration with max_iterations limit
    - should_continue to check if we should keep iterating
    - before_iteration to inject previous context
    - after_stage_execute to accumulate history
    """

    name = "test"
    output_type = TestResult
    max_iterations = 10
    stages = [DiagnosisStage, FixerStage]

    def should_continue(self, output: Any, ctx: "Context") -> bool:
        """Check if we should continue iterating.

        Only diagnosis can end the loop by setting integration_complete=True.
        Fixer always continues to diagnosis for final review.
        """
        # Only diagnosis can end the loop
        if isinstance(output, DiagnosisResult):
            return not output.integration_complete

        # Fixer always continues to diagnosis for review
        if isinstance(output, FixerResult):
            if output.tests_deleted:
                ctx.warn("Fixer deleted tests - invalid fix, will re-diagnose")
            elif output.tests_passing:
                # Mark that fixer reported success - diagnosis will do final review
                ctx.set("fixer_reports_passing", True)
                ctx.info("Fixer reports tests passing - diagnosis will perform final review")
            return True  # Always continue to diagnosis

        return True

    def should_exit_early(self, stage_name: str, output: Any, ctx: "Context") -> bool:
        """Exit early if diagnosis shows integration is complete.

        Only diagnosis stage can trigger early exit.
        """
        if stage_name == "diagnosis" and isinstance(output, DiagnosisResult):
            if output.integration_complete:
                ctx.info("Integration complete - tests passing with comprehensive coverage!")
                return True
            elif output.success and not output.integration_complete:
                ctx.info("Tests passing but coverage incomplete - continuing to add missing tests")
        # Fixer never exits early - always continues to diagnosis
        return False

    def after_stage_execute(self, stage_name: str, output: Any, ctx: "Context") -> Any:
        """Accumulate stage outputs for history and next iteration."""
        ctx.set(f"{stage_name}_result", output)

        if stage_name == "diagnosis":
            diagnosis_history: List[DiagnosisResult] = ctx.get("diagnosis_history", [])
            diagnosis_history.append(output)
            ctx.set("diagnosis_history", diagnosis_history)
        elif stage_name == "fixer":
            fixer_history: List[FixerResult] = ctx.get("fixer_history", [])
            fixer_history.append(output)
            ctx.set("fixer_history", fixer_history)

        return output

    def before_iteration(self, iteration: int, input: TestInput, ctx: "Context") -> TestInput:
        """Inject previous results into context for next iteration."""
        ctx.set("previous_diagnosis", ctx.get("diagnosis_result"))
        ctx.set("previous_fixer", ctx.get("fixer_result"))
        ctx.set("iteration", iteration)

        ctx.set("diagnosis_result", None)
        ctx.set("fixer_result", None)

        prev_fixer = ctx.get("previous_fixer")
        if prev_fixer and prev_fixer.tests_deleted:
            ctx.set("previous_diagnosis", None)

        if hasattr(input, "max_iterations"):
            self.max_iterations = input.max_iterations

        return input

    def after_execute(self, output: Any, ctx: "Context") -> TestResult:
        """Build final TestResult from accumulated state."""
        diagnosis_history = ctx.get("diagnosis_history", [])
        final_diagnosis = ctx.get("diagnosis_result")
        iterations = ctx.get("current_iteration", 0)

        # Only diagnosis can confirm completion - fixer alone is not sufficient
        success = bool(final_diagnosis and final_diagnosis.integration_complete)

        return TestResult(
            success=success,
            iterations=iterations,
            diagnosis_history=diagnosis_history,
            final_diagnosis=final_diagnosis,
        )
