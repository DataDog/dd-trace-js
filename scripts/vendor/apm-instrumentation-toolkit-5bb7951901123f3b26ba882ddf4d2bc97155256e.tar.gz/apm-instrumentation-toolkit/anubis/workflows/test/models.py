"""Models for the Test workflow."""

from typing import List, Optional

from pydantic import BaseModel, Field


class TestInput(BaseModel):
    """Input for test workflow."""

    max_iterations: int = Field(default=10, description="Max diagnosis/fix iterations")


class MissingTestCase(BaseModel):
    """A test case that should be added."""

    name: str = Field(
        description="Short name for the test case (e.g., 'tool_calling', 'multi_turn')"
    )
    description: str = Field(description="What this test should verify")
    priority: str = Field(default="medium", description="Priority: high, medium, low")


class DiagnosisResult(BaseModel):
    """Output from diagnosis step."""

    success: bool = Field(description="True if all tests pass")
    integration_complete: bool = Field(
        default=False,
        description="True ONLY if tests pass AND coverage is comprehensive. "
        "Set to False if there are missing_test_cases or incomplete coverage, even if tests pass.",
    )
    failure_mode: Optional[str] = Field(default=None)
    suggestions: List[str] = Field(default_factory=list)
    files_to_check: List[str] = Field(default_factory=list)
    test_output_summary: Optional[str] = None
    passing: int = 0
    failing: int = 0
    skipped: int = 0
    missing_test_cases: List[MissingTestCase] = Field(
        default_factory=list, description="Test cases that should be added for better coverage"
    )


class FixerResult(BaseModel):
    """Output from fixer step."""

    tests_passing: bool = Field(description="True if tests now pass")
    tests_deleted: bool = Field(default=False, description="True if tests were deleted (invalid)")
    changes_made: List[str] = Field(default_factory=list)
    explanation: Optional[str] = None


class TestResult(BaseModel):
    """Final output from test workflow."""

    success: bool
    iterations: int
    diagnosis_history: List[DiagnosisResult] = Field(default_factory=list)
    final_diagnosis: Optional[DiagnosisResult] = None
