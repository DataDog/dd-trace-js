"""Test workflow - iterative test diagnosis and fixing.

Generic test workflow that:

1. Runs tests and diagnoses failures

2. Applies fixes based on diagnosis

3. Loops until tests pass or max iterations

Example::

    from anubis.workflows.test import TestWorkflow, TestInput

    workflow = TestWorkflow(
        test_command="npm test",
        working_dir=Path("/my/project"),
    )

    result = workflow.run(TestInput(max_iterations=10))

    if result.success:
        print(f"Tests passing after {result.output.iterations} iterations")

"""

from .models import DiagnosisResult, FixerResult, TestInput, TestResult
from .workflow import TestWorkflow

__all__ = [
    "TestWorkflow",
    "TestInput",
    "TestResult",
    "DiagnosisResult",
    "FixerResult",
]
