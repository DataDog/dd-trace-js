"""Utilities for lint workflow."""

import re
import subprocess
from pathlib import Path
from typing import Dict


def run_command(command: str, working_dir: Path, timeout: int = 120) -> Dict:
    """Run a shell command and return result."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=working_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "returncode": result.returncode,
            "output": result.stdout + result.stderr,
        }
    except subprocess.TimeoutExpired:
        return {
            "returncode": 1,
            "output": "Command timed out",
        }
    except Exception as e:
        return {
            "returncode": 1,
            "output": str(e),
        }


def count_errors(output: str) -> int:
    """Count errors in lint output (heuristic)."""
    # ESLint style: "X problems (Y errors, Z warnings)"
    match = re.search(r"(\d+)\s+errors?", output, re.IGNORECASE)
    if match:
        return int(match.group(1))

    # Fallback: count lines with "error"
    return len([l for l in output.split("\n") if "error" in l.lower()])
