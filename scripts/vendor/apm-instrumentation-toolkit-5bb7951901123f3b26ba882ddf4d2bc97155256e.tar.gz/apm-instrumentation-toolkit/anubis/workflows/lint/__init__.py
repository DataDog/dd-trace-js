"""Lint workflow - lint and fix code.

Generic lint workflow that works with any linter via a lint function.
Pass your lint function and paths, and it will:

1. Run linter to get errors

2. Use AI agent to fix errors

3. Verify fixes by re-running linter

4. Iterate until clean or max iterations reached

Example::

    from anubis.workflows.lint import LintWorkflow, LintInput

    # Define a lint function that matches the expected signature
    def my_lint(paths: List[str], fix: bool = False) -> Dict[str, Any]:
        # Run your linter and return results
        return {
            'success': error_count == 0,
            'error_count': error_count,
            'warning_count': warning_count,
            'raw_output': output_string,
        }

    workflow = LintWorkflow(
        lint_fn=my_lint,
        working_dir=Path("/my/project"),
    )

    result = workflow.run(LintInput(
        paths=["src/"],
        max_iterations=3,
    ))

"""

from .models import LintCheckResult, LintInput, LintResult
from .workflow import LintFn, LintWorkflow

__all__ = [
    "LintWorkflow",
    "LintFn",
    "LintInput",
    "LintCheckResult",
    "LintResult",
]
