"""Models for the Lint workflow."""

from typing import List, Optional

from pydantic import BaseModel, Field


class LintInput(BaseModel):
    """Input for lint workflow."""

    paths: List[str] = Field(description="Paths to lint")
    auto_fix: bool = Field(default=True, description="Run fix command first if available")
    max_iterations: int = Field(default=3, description="Max AI fix iterations")


class LintIssue(BaseModel):
    """Single lint issue."""

    file: str
    line: int
    column: Optional[int] = None
    rule: str
    message: str
    severity: str = Field(description="error or warning")


class LintCheckResult(BaseModel):
    """Output from running lint check."""

    success: bool
    error_count: int
    warning_count: int
    issues: List[LintIssue] = Field(default_factory=list)
    raw_output: str = ""


class LintResult(BaseModel):
    """Final output from lint workflow."""

    success: bool
    initial_errors: int
    final_errors: int
    errors_fixed: int
    iterations: int
    raw_output: str = ""
