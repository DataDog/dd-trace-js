"""Lint Workflow - generic lint and fix workflow."""

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from ...core import Workflow
from .models import LintInput, LintResult
from .steps import GetLintFailures, LintAndFix

# Type alias for lint function
# Takes (paths, fix) -> {'success': bool, 'error_count': int, 'warning_count': int, 'raw_output': str}
LintFn = Callable[[List[str], bool], Dict[str, Any]]

# Type alias for lint formatter function
# Takes lint result dict -> formatted string for AI prompt
LintFormatterFn = Callable[[Dict[str, Any]], str]


class LintWorkflow(Workflow[LintInput, LintResult]):
    """Generic lint and fix workflow.

    Steps:

    1. GetLintFailures - Run linter, optionally auto-fix, get errors

    2. LintAndFix - Iteratively fix with AI agent

    Example::

        # With a lint function (e.g., from language adapter)
        workflow = LintWorkflow(
            lint_fn=adapter.lint_paths,
            format_lint_fn=adapter.format_lint_errors_for_prompt,
            working_dir=Path("/my/project"),
        )
        result = workflow.run(LintInput(paths=["src/"]))

        # The lint function should have signature:
        # def lint_fn(paths: List[str], fix: bool = False) -> Dict[str, Any]
        # Returns: {'success': bool, 'error_count': int, 'warning_count': int, 'raw_output': str}

    """

    name = "lint"
    steps = [GetLintFailures, LintAndFix]

    def __init__(
        self,
        lint_fn: LintFn,
        working_dir: Path,
        format_lint_fn: Optional[LintFormatterFn] = None,
        integration: str = "",
        repository: str = "dd_trace_js",
        **options,
    ):
        """
        Args:
            lint_fn: Function to run linter. Takes (paths, fix) returns dict with
                     'success', 'error_count', 'warning_count', 'raw_output'
            working_dir: Directory to run commands in
            format_lint_fn: Optional function to format lint result for AI prompt.
                           If not provided, raw_output is used.
            integration: Optional integration name (for logging)
            repository: Repository (default: dd_trace_js)
            **options: Passed to Workflow (namespace, headless, model, etc.)
        """
        self.lint_fn = lint_fn
        self.format_lint_fn = format_lint_fn
        self.working_dir = Path(working_dir)
        options.setdefault("namespace", integration)
        options.setdefault("repository", repository)
        super().__init__(base_dir=self.working_dir, **options)

    def _setup(self):
        """Setup context with lint configuration."""
        ctx = super()._setup()

        # Store callables in config (not serialized) rather than state data
        ctx.config["lint_fn"] = self.lint_fn
        ctx.config["format_lint_fn"] = self.format_lint_fn
        ctx.config["working_dir"] = self.working_dir

        return ctx
