"""Steps for the Lint workflow."""

from typing import TYPE_CHECKING

from ...core.steps import AgentStep, CompositeStep, Step

if TYPE_CHECKING:
    from ...core.context import Context

from .models import LintCheckResult, LintInput, LintResult


class GetLintFailures(Step[LintInput, LintCheckResult]):
    """Run linter and get failures."""

    name = "get_lint_failures"
    output_type = LintCheckResult

    def execute(self, input: LintInput, ctx: "Context") -> LintCheckResult:
        lint_fn = ctx.get_config("lint_fn")
        format_lint_fn = ctx.get_config("format_lint_fn")

        # Run lint to get current state
        ctx.info("Running lint check")
        result = lint_fn(input.paths, fix=input.auto_fix or False)

        ctx.set("lint_input", input)
        ctx.set("initial_errors", result.get("error_count", 0))
        # Pre-format for prompt template — downstream FixLintErrors reads via fallback
        ctx.set("files_to_fix", "\n".join(f"- {p}" for p in input.paths) if input.paths else "")

        # Format output for AI prompt if formatter is available
        if format_lint_fn:
            formatted_output = format_lint_fn(result)
        else:
            formatted_output = result.get("raw_output", "")

        return LintCheckResult(
            success=result.get("success", False),
            error_count=result.get("error_count", 0),
            warning_count=result.get("warning_count", 0),
            issues=[],
            raw_output=formatted_output,
        )


class FixLintErrors(AgentStep[LintCheckResult, LintResult]):
    """Agent fixes lint errors."""

    name = "fix_lint_errors"
    output_type = LintResult
    prompt = "lint-fixer"
    timeout_minutes = 10
    max_turns = 100
    model = "haiku"
    use_repo_root = True


class LintAndFix(CompositeStep[LintCheckResult, LintResult]):
    """Iteratively fix lint errors."""

    name = "lint_and_fix"
    output_type = LintResult
    max_iterations = 3
    stages = [FixLintErrors]

    def should_continue(self, output: LintResult, ctx: "Context") -> bool:
        if output.final_errors == 0:
            return False
        # Stop early if the agent made no progress this iteration.
        # entering_errors is the real error count at the start of this iteration
        # (set by before_iteration from the real lint check, not the agent's claim).
        entering_errors = ctx.get("_lint_entering_errors")
        if (
            entering_errors is not None
            and output.errors_fixed == 0
            and output.final_errors >= entering_errors
        ):
            ctx.info(
                f"No progress this iteration ({output.final_errors} errors remain) — stopping early"
            )
            return False
        return True

    def before_iteration(
        self, iteration: int, input: LintCheckResult, ctx: "Context"
    ) -> LintCheckResult:
        lint_input: LintInput = ctx.get("lint_input")
        if lint_input:
            self.max_iterations = lint_input.max_iterations
        # Capture the real error count entering this iteration so should_continue
        # can detect zero-progress iterations without trusting the agent's output.
        entering = getattr(input, "final_errors", None) or getattr(input, "error_count", None)
        if entering is not None:
            ctx.set("_lint_entering_errors", entering)
        return input

    def after_iteration(self, iteration: int, output: LintResult, ctx: "Context") -> LintResult:
        """Re-check lint after each fix."""
        lint_fn = ctx.get_config("lint_fn")
        format_lint_fn = ctx.get_config("format_lint_fn")
        lint_input: LintInput = ctx.get("lint_input")
        initial_errors = ctx.get("initial_errors", 0)

        result = lint_fn(lint_input.paths, fix=False)
        new_errors = result.get("error_count", 0)
        fixed = initial_errors - new_errors

        if new_errors < output.final_errors:
            ctx.info(f"Progress: {output.final_errors} → {new_errors} errors")

        # Format output for AI prompt if formatter is available
        if format_lint_fn:
            formatted_output = format_lint_fn(result)
        else:
            formatted_output = result.get("raw_output", "")

        return LintResult(
            success=new_errors == 0,
            initial_errors=initial_errors,
            final_errors=new_errors,
            errors_fixed=max(0, fixed),
            iterations=iteration,
            raw_output=formatted_output,
        )
