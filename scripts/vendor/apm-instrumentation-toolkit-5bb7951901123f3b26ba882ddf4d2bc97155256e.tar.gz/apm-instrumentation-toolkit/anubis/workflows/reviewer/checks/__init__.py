"""Check loader for the Reviewer workflow.

Discovers check files from the checks directory and provides them
for parallel execution in the reviewer workflow.

Check file format:
    # Check Name

    ## Files
    `packages/datadog-plugin-*/src/**/*.js`

    ## What to Find
    ... issue patterns with BAD/GOOD examples ...

    ## How to Fix
    ... resolution guidance ...
"""

from pathlib import Path
from typing import List, Optional

from ..models import CheckConfig


def _get_checks_root() -> Path:
    """Get the root directory for checks."""
    return Path(__file__).parent


def load_checks_from_dir(checks_dir: Path, repository: str = "dd_trace_js") -> List[CheckConfig]:
    """Load checks from a directory structure.

    Loads checks from both general/ and repository-specific directories.
    Check files should be markdown with optional ## Files section for path hints.

    Args:
        checks_dir: Root directory containing general/ and repository dirs
        repository: Repository to load checks for (default: dd_trace_js)

    Returns:
        List of CheckConfig objects for reviewer workflow
    """
    configs = []

    for dir_name in ["general", repository]:
        check_dir = checks_dir / dir_name
        if check_dir.exists():
            for check_file in check_dir.glob("*.md"):
                content = check_file.read_text()
                # Prefix with dir name to avoid collisions between
                # general/ and repository-specific checks with the same filename
                check_name = f"{dir_name}/{check_file.stem}"
                configs.append(
                    CheckConfig(
                        name=check_name,
                        content=content,
                    )
                )

    return configs


def load_checks(
    repository: str = "dd_trace_js", additional_dirs: Optional[List[Path]] = None
) -> List[CheckConfig]:
    """Load checks from the default anubis checks directory.

    Args:
        repository: Repository to load checks for (default: dd_trace_js)
        additional_dirs: Optional list of additional directories to load checks from

    Returns:
        List of CheckConfig objects for reviewer workflow
    """
    configs = load_checks_from_dir(_get_checks_root(), repository)

    if additional_dirs:
        for extra_dir in additional_dirs:
            if extra_dir.exists():
                configs.extend(load_checks_from_dir(extra_dir, repository))

    return configs


__all__ = ["load_checks", "load_checks_from_dir", "CheckConfig"]
