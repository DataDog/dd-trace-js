"""Steps for the Reviewer workflow.

Batch-based review:
1. BatchReviewStep - Runs checks in parallel, each check is a batch item
2. BatchFixStep - Fixes todos grouped by check (sequential per group)
3. TestRepairStage - Runs test diagnosis/fix if tests are failing
4. HumanReviewStep - Human approval
5. FinalizeStep - Convert decision to ReviewResult
"""

import builtins
import os
import signal
from collections import defaultdict
from typing import TYPE_CHECKING, Any, List

from ...core.output import restore_terminal_for_input
from ...core.steps import AgentStep, CompositeStep, Step
from ..test.models import TestInput
from ..test.steps import TestStep

if TYPE_CHECKING:
    from ...core.context import Context

from .models import (
    CheckConfig,
    CheckResult,
    FixResult,
    HumanAction,
    HumanDecision,
    ReviewAnalysis,
    ReviewInput,
    ReviewResult,
    ReviewTodo,
    TodoFixResult,
    TodoPriority,
)

_REVIEW_TIMEOUT_SECONDS = 300  # 5 minutes — auto-approve if no human response


class _ReviewTimeout(Exception):
    """Raised by SIGALRM when the human-review window expires."""


class BatchReviewStep(AgentStep[ReviewInput, CheckResult]):
    """Run all checks in parallel.

    Each check is a batch item. The agent runs once per check with the
    check content injected into the prompt.
    """

    name = "batch_review"
    output_type = CheckResult
    prompt = "reviewer/check"
    timeout_minutes = 10
    max_turns = 100
    model = "sonnet"
    use_repo_root = True
    batch_execute = True
    batch_size = 10

    def prepare_batch(self, input: ReviewInput, ctx: "Context") -> List[dict]:
        checks: List[CheckConfig] = ctx.get("checks", [])
        review_paths = ctx.get("review_paths", [])

        if not checks:
            ctx.info("No checks configured")
            return []

        items = []
        for check in checks:
            if not check.enabled:
                continue

            paths = check.paths or review_paths
            paths_str = "\n".join(f"- {p}" for p in paths) if paths else "All files"

            items.append({
                "check_id": check.name,
                "check_name": check.name,
                "check_content": check.content,
                "plugin_path": paths_str,
                "custom_guidance": input.guidance or "",
            })

        ctx.info(f"Running {len(items)} checks: {[c['check_id'] for c in items]}")
        return items

    def aggregate_batch(self, results: List[CheckResult], ctx: "Context") -> ReviewAnalysis:
        all_todos: List[ReviewTodo] = []
        seen_ids = set()
        summaries = []
        failing_checks = set()

        for result in results:
            if result is None:
                continue

            if result.summary:
                summaries.append(f"[{result.check_id}] {result.summary}")

            if result.todos:
                failing_checks.add(result.check_id)

            for todo in result.todos:
                if todo.id not in seen_ids:
                    seen_ids.add(todo.id)
                    todo.check_id = result.check_id
                    all_todos.append(todo)

        ctx.set("_failing_check_ids", failing_checks)

        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        all_todos.sort(key=lambda t: priority_order.get(t.priority.value, 99))

        ctx.info(f"Found {len(all_todos)} issues across {len(results)} checks")

        summary = "\n".join(summaries) if summaries else f"Found {len(all_todos)} issues"
        # Pre-set for BatchFixStep prompt resolution via fallback
        ctx.set("summary", summary)

        return ReviewAnalysis(todos=all_todos, summary=summary)


class BatchFixStep(AgentStep[ReviewAnalysis, TodoFixResult]):
    """Fix todos grouped by check (batch_size=1 for sequential per group)."""

    name = "batch_fix"
    output_type = TodoFixResult
    prompt = "reviewer/fixer"
    timeout_minutes = 10
    max_turns = 100
    model = "opus"
    use_repo_root = True
    batch_execute = True
    batch_size = 1  # Sequential per check to avoid conflicts

    def prepare_batch(self, input: ReviewAnalysis, ctx: "Context") -> List[dict]:
        test_command = ctx.get("test_command", "")
        ctx.set("_review_analysis", input)

        fixable = [t for t in input.todos if t.fixable and t.priority != TodoPriority.LOW]
        if not fixable:
            ctx.info("No fixable todos (after filtering LOW priority)")
            return []

        by_check = defaultdict(list)
        for todo in fixable:
            by_check[todo.check_id or todo.id].append(todo)

        ctx.info(f"Fixing {len(fixable)} todos from {len(by_check)} checks")

        items = []
        for check_id, todos in by_check.items():
            todos_md = []
            for todo in todos:
                todos_md.append(f"### {todo.id}")
                todos_md.append(f"- **Priority**: {todo.priority.value}")
                todos_md.append(f"- **Description**: {todo.description}")
                todos_md.append(f"- **File**: {todo.file or 'Not specified'}")
                todos_md.append("")

            items.append({
                "id": check_id,
                "check_id": check_id,
                "todo_ids": [t.id for t in todos],
                "todos": "\n".join(todos_md),
                "test_command": test_command,
            })

        return items

    def aggregate_batch(self, results: List[TodoFixResult], ctx: "Context") -> FixResult:
        todos_fixed = []
        todos_failed = []
        changes_made = []
        tests_passing = True

        analysis: ReviewAnalysis = ctx.get("_review_analysis")
        todos_skipped = (
            [t.id for t in analysis.todos if not t.fixable or t.priority == TodoPriority.LOW]
            if analysis
            else []
        )

        for result in results:
            if result is None:
                continue

            todos_fixed.extend(result.todo_ids_fixed)
            todos_failed.extend(result.todo_ids_failed)
            changes_made.extend(result.changes)

            if not result.tests_passing:
                tests_passing = False

        ctx.info(f"Fixed {len(todos_fixed)} todos, {len(todos_failed)} failed")

        return FixResult(
            todos_fixed=todos_fixed,
            todos_failed=todos_failed,
            todos_skipped=todos_skipped,
            changes=changes_made,
            tests_passing=tests_passing,
        )


class TestRepairStage(Step[FixResult, FixResult]):
    """Conditionally runs TestStep when tests are failing."""

    name = "test_repair"
    output_type = FixResult

    def execute(self, input: FixResult, ctx: "Context") -> FixResult:
        if input.tests_passing:
            return input

        if not ctx.get("test_command"):
            ctx.warn("No test_command configured, skipping test repair")
            return input

        ctx.info("Tests failing - running TestStep")
        max_iterations = ctx.get("max_test_repair_iterations", 3)

        test_step = TestStep()
        test_step.max_iterations = max_iterations
        result = test_step.run(TestInput(max_iterations=max_iterations), ctx)

        return FixResult(
            todos_fixed=input.todos_fixed,
            todos_failed=input.todos_failed,
            todos_skipped=input.todos_skipped,
            changes=input.changes,
            tests_passing=result.success,
        )


class HumanReviewStep(Step[FixResult, HumanDecision]):
    """Human approval."""

    name = "human_review"
    output_type = HumanDecision

    def execute(self, input: FixResult, ctx: "Context") -> HumanDecision:
        ctx.set("_fix_result", input)

        if not input.tests_passing:
            ctx.emit(
                "review_summary",
                tests_passing=False,
                fixed=len(input.todos_fixed),
                failed=len(input.todos_failed),
                skipped=len(input.todos_skipped),
                changes_made=input.changes,
            )
            return HumanDecision(action=HumanAction.REQUEST_CHANGES, feedback="Auto: tests failing")

        # Headless or agentless mode: auto-approve if no failures
        _agentless = os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "").lower() in ("1", "true")
        if ctx.headless or ctx.get("headless", False) or _agentless:
            reason = "agentless" if _agentless else "headless"
            if not input.todos_failed:
                ctx.info(f"Auto-approving ({reason})")
                return HumanDecision(action=HumanAction.APPROVE)
            return HumanDecision(
                action=HumanAction.REQUEST_CHANGES, feedback=f"Auto: todos failed ({reason})"
            )

        # Interactive mode: prompt for user decision.
        # Auto-approves after _REVIEW_TIMEOUT_SECONDS if no response (SIGALRM).
        ctx.info(f"Fixed: {len(input.todos_fixed)} | Failed: {len(input.todos_failed)}")
        ctx.info("[a]pprove  [c]hanges  [q]uit")
        ctx.info(f"  (auto-approving in {_REVIEW_TIMEOUT_SECONDS // 60} min if no response)")

        # Use builtins.input() — the parameter `input` shadows the builtin in this scope.
        ctx.emit("pause_live")
        restore_terminal_for_input()

        def _alarm_handler(signum, frame):  # noqa: ARG001
            raise _ReviewTimeout()

        old_handler = signal.signal(signal.SIGALRM, _alarm_handler)
        signal.alarm(_REVIEW_TIMEOUT_SECONDS)
        try:
            while True:
                choice = builtins.input("> ").strip().lower()

                if choice in ("a", "approve"):
                    if builtins.input("Confirm? (yes): ").lower() == "yes":
                        return HumanDecision(action=HumanAction.APPROVE)
                elif choice in ("c", "changes"):
                    feedback = builtins.input("Feedback: ").strip()
                    if feedback:
                        return HumanDecision(action=HumanAction.REQUEST_CHANGES, feedback=feedback)
                elif choice in ("q", "quit"):
                    if builtins.input("Type 'abort': ").lower() == "abort":
                        return HumanDecision(action=HumanAction.ABORT)
                else:
                    ctx.warn(f"Unknown choice: {choice!r}")
        except _ReviewTimeout:
            ctx.info("Review timeout — auto-approving")
            return HumanDecision(action=HumanAction.APPROVE)
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)
            ctx.emit("resume_live")


class FinalizeStep(Step[HumanDecision, ReviewResult]):
    """Convert decision to ReviewResult."""

    name = "finalize"
    output_type = ReviewResult

    def execute(self, input: HumanDecision, ctx: "Context") -> ReviewResult:
        fix_result: FixResult = ctx.get("_fix_result")
        fixed = len(fix_result.todos_fixed) if fix_result else 0
        remaining = (
            (len(fix_result.todos_failed) + len(fix_result.todos_skipped)) if fix_result else 0
        )

        if input.action == HumanAction.APPROVE:
            return ReviewResult(approved=True, verdict="approved", todos_fixed=fixed)
        elif input.action == HumanAction.ABORT:
            return ReviewResult(
                approved=False, verdict="aborted", todos_fixed=fixed, todos_remaining=remaining
            )
        else:
            return ReviewResult(
                approved=False,
                verdict="needs_work",
                feedback=input.feedback,
                todos_fixed=fixed,
                todos_remaining=remaining,
            )


class ReviewCycleStep(CompositeStep[ReviewInput, ReviewResult]):
    """Loops batch review/fix/human until approved or aborted."""

    name = "review_cycle"
    output_type = ReviewResult
    max_iterations = 10
    stages = [BatchReviewStep, BatchFixStep, TestRepairStage, HumanReviewStep, FinalizeStep]

    def should_continue(self, output: ReviewResult, ctx: "Context") -> bool:  # noqa: ARG002
        return output.verdict == "needs_work"

    def before_iteration(self, iteration: int, input: ReviewInput, ctx: "Context") -> ReviewInput:
        if input is None:
            input = ReviewInput()
        # Store original input on first iteration (input becomes ReviewResult on iteration 2+)
        if iteration == 1:
            ctx.set("_original_review_input", input)

        if iteration > 1:
            prev: ReviewResult = ctx.get("_last_review_result")
            original: ReviewInput = ctx.get("_original_review_input")
            if prev and prev.feedback:
                ctx.info(f"Re-running with feedback: {prev.feedback[:100]}...")
                return ReviewInput(
                    guidance=prev.feedback,
                    max_iterations=original.max_iterations if original else 10,
                )
        return input

    def after_stage_execute(self, stage_name: str, output: Any, ctx: "Context") -> Any:
        if stage_name == "finalize":
            ctx.set("_last_review_result", output)
        return output

    def should_exit_early(self, stage_name: str, output: Any, ctx: "Context") -> bool:  # noqa: ARG002
        if stage_name == "finalize" and isinstance(output, ReviewResult):
            return output.verdict == "aborted"
        return False
