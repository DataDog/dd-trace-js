"""Models for the Reviewer workflow."""

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class TodoPriority(str, Enum):
    """Priority of todo item."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class ReviewTodo(BaseModel):
    """Single todo item identified during review."""

    id: str = Field(description="Unique identifier")
    check_id: str = Field(
        default="", description="Which check produced this todo (set by aggregate)"
    )
    priority: TodoPriority = Field(default=TodoPriority.MEDIUM)
    description: str = Field(description="What needs to be done")
    file: Optional[str] = Field(default=None, description="File path if applicable")
    line: Optional[int] = Field(default=None, description="Line number if applicable")
    fixable: bool = Field(default=True, description="Can be auto-fixed by agent")


class CheckConfig(BaseModel):
    """Configuration for a review check.

    Each check runs an agent with its content to find issues.
    Multiple checks run in batch (parallel) mode.
    """

    name: str = Field(description="Check identifier (e.g., 'security', 'style')")
    content: str = Field(description="The check content/rules (markdown)")
    paths: Optional[List[str]] = Field(default=None, description="Limit check to these paths")
    enabled: bool = Field(default=True, description="Whether this check is active")


class CheckResult(BaseModel):
    """Output from a single check (batch item)."""

    check_id: str = Field(description="Which check produced this")
    todos: List[ReviewTodo] = Field(default_factory=list)
    summary: str = Field(default="")


class ReviewInput(BaseModel):
    """Input for review workflow."""

    guidance: Optional[str] = Field(default=None, description="Custom guidance for reviewer")
    max_iterations: int = Field(default=5, description="Max review/fix iterations")


class ReviewAnalysis(BaseModel):
    """Aggregated output from batch review."""

    todos: List[ReviewTodo] = Field(default_factory=list)
    summary: str = Field(default="")


class TodoFixResult(BaseModel):
    """Output from fixing a single batch of todos."""

    todo_ids_fixed: List[str] = Field(default_factory=list)
    todo_ids_failed: List[str] = Field(default_factory=list)
    changes: List[str] = Field(default_factory=list)
    tests_passing: bool = Field(default=True)


class FixResult(BaseModel):
    """Aggregated output from fix step."""

    todos_fixed: List[str] = Field(default_factory=list)
    todos_failed: List[str] = Field(default_factory=list)
    todos_skipped: List[str] = Field(default_factory=list)
    changes: List[str] = Field(default_factory=list)
    tests_passing: bool = Field(default=True)


class HumanAction(str, Enum):
    """Human decision action."""

    APPROVE = "approve"
    REQUEST_CHANGES = "request_changes"
    ABORT = "abort"


class HumanDecision(BaseModel):
    """Output from human review."""

    action: HumanAction
    feedback: Optional[str] = None


class ReviewResult(BaseModel):
    """Final output from reviewer workflow."""

    approved: bool
    verdict: str = Field(description="approved, needs_work, aborted")
    todos_fixed: int = 0
    todos_remaining: int = 0
    feedback: Optional[str] = None
