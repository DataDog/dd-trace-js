"""Reviewer workflow - code review with human-in-the-loop.

Generic reviewer workflow that:

1. Runs checks in parallel (batch execution)

2. Fixes todos grouped by check

3. Human approves, requests changes, or aborts

4. Loops until approved or aborted


Example::

    from pathlib import Path
    from anubis.workflows.reviewer import ReviewerWorkflow, ReviewInput, CheckConfig, load_checks

    # Load checks and create workflow
    checks = load_checks(repository='dd_trace_js')
    workflow = ReviewerWorkflow(
        checks=checks,
        working_dir=Path("/my/project"),
        test_command="npm test",
        paths=["src/"],
    )
    result = workflow.run(ReviewInput())

"""

from .checks import load_checks, load_checks_from_dir
from .models import CheckConfig, HumanAction, ReviewInput, ReviewResult, ReviewTodo
from .workflow import ReviewerWorkflow

__all__ = [
    "ReviewerWorkflow",
    "CheckConfig",
    "ReviewInput",
    "ReviewTodo",
    "ReviewResult",
    "HumanAction",
    "load_checks",
    "load_checks_from_dir",
]
