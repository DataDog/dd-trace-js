"""Reviewer Workflow - code review with human-in-the-loop."""

import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from ...core import Workflow
from .checks import load_checks
from .models import CheckConfig, ReviewInput, ReviewResult
from .steps import ReviewCycleStep

DEFAULT_SQUASH_MESSAGE = "chore: apply reviewer workflow changes"


class ReviewerWorkflow(Workflow[ReviewInput, ReviewResult]):
    """Generic code review workflow with human-in-the-loop.

    Steps (via ReviewCycleStep):

    1. BatchReviewStep - Run checks in parallel, each check is a batch item

    2. BatchFixStep - Fix todos grouped by check

    3. HumanReviewStep - Human approves/requests changes/aborts

    4. FinalizeStep - Convert decision to result

    Loops until approved or aborted.

    Example::

        # Default: loads checks from anubis/workflows/reviewer/checks/
        workflow = ReviewerWorkflow(
            working_dir=Path("/my/project"),
            test_command="npm test",
        )
        result = workflow.run(ReviewInput())

        # Or with custom checks
        checks = [
            CheckConfig(name="security", content="Check for SQL injection..."),
            CheckConfig(name="style", content="Check for consistent naming..."),
        ]
        workflow = ReviewerWorkflow(
            checks=checks,
            working_dir=Path("/my/project"),
        )

    """

    name = "reviewer"
    steps = [ReviewCycleStep]

    def __init__(
        self,
        working_dir: Path,
        checks: Optional[List[CheckConfig]] = None,
        test_command: Optional[str] = None,
        paths: Optional[List[str]] = None,
        prompts: Optional[Dict[str, str]] = None,
        prompt_variables: Optional[Dict[str, str]] = None,
        integration: str = "",
        repository: str = "dd_trace_js",
        parent_workflow_start_commit: Optional[str] = None,
        **options,
    ):
        """
        Args:
            working_dir: Directory to run in
            checks: List of CheckConfig (loads from anubis checks if not provided)
            test_command: Command to run tests (optional)
            paths: Paths to review (optional, reviews all if not specified)
            prompts: Custom prompts dict, e.g. {"review": "custom-prompt"}
            prompt_variables: Extra variables for prompt templates (e.g., files_to_check)
            integration: Optional integration name (for logging)
            repository: Repository (default: dd_trace_js)
            parent_workflow_start_commit: If running as a child of another workflow,
                use this commit for squashing instead of marking a new start.
            **options: Passed to Workflow (namespace, headless, model, etc.)
        """
        self.working_dir = Path(working_dir)
        self.parent_workflow_start_commit = parent_workflow_start_commit
        options.setdefault("namespace", integration)
        options.setdefault("repository", repository)
        super().__init__(base_dir=self.working_dir, **options)
        # Load default checks from anubis if not provided
        self.checks = checks if checks is not None else load_checks(repository)
        self.test_command = test_command
        self.review_paths = paths or []
        self.custom_prompts = prompts or {}
        self.prompt_variables = prompt_variables or {}

    def _setup(self):
        """Setup context with reviewer configuration."""
        ctx = super()._setup()

        # If running as a child workflow, use parent's start commit for squashing.
        # This ensures all changes since the parent workflow started are included.
        # Validate the commit is an ancestor of HEAD to avoid squashing unrelated changes.
        if self.parent_workflow_start_commit and ctx.state:
            try:
                subprocess.run(
                    [
                        "git",
                        "merge-base",
                        "--is-ancestor",
                        self.parent_workflow_start_commit,
                        "HEAD",
                    ],
                    cwd=self.working_dir,
                    check=True,
                    capture_output=True,
                )
                ctx.state.workflow_start_commit = self.parent_workflow_start_commit
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass  # Not an ancestor or git unavailable — skip override

        ctx.set("working_dir", self.working_dir)
        ctx.set("checks", self.checks)
        ctx.set("test_command", self.test_command or "")
        ctx.set("review_paths", self.review_paths)
        ctx.set("headless", self.headless if hasattr(self, "headless") else False)
        ctx.set("prompt_variables", self.prompt_variables)
        # Pre-set shared prompt variables so steps can resolve them via fallback
        ctx.set("repository", ctx.repository)
        ctx.set("integration_name", ctx.namespace or "unknown")
        ctx.set("available_skills", "")
        plugin_path = (
            "\n".join(f"- {p}" for p in self.review_paths) if self.review_paths else "All files"
        )
        ctx.set("plugin_path", plugin_path)
        ctx.set("analysis_info", self.prompt_variables.get("analysis_info", ""))

        # Store custom prompts for steps to access
        for step_name, prompt_name in self.custom_prompts.items():
            ctx.set(f"{step_name}_prompt", prompt_name)

        return ctx

    def on_workflow_complete(self, success: bool, output: Optional[ReviewResult]) -> None:
        """Squash git commits when workflow completes with human approval."""
        if not success or not output or not output.approved:
            return

        if not self.ctx.state:
            return

        # Squash all workflow commits into a single signed commit
        message = self.ctx.get("squash_message", DEFAULT_SQUASH_MESSAGE)
        squashed = self.ctx.state.squash_commits(
            message=message,
            repo_path=self.ctx.base_dir,
        )
        if squashed:
            self.ctx.info(f"Squashed workflow commits: {message}")
