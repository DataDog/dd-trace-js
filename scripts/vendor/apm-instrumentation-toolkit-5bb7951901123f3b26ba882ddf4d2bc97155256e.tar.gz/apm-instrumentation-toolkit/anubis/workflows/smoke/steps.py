"""Steps for the smoke test workflow."""

from ...core.steps import AgentStep
from .models import SmokeInput, SmokeOutput


class SmokeStep(AgentStep[SmokeInput, SmokeOutput]):
    """Single-turn agent step — returns a valid result immediately."""

    name = "smoke"
    prompt = "smoke"
    output_type = SmokeOutput
    model = "haiku"
    max_turns = 3
    sandbox = False
    skills = None  # opt out: smoke test must not read skill files before responding
