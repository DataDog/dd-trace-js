"""Smoke test workflow."""

from .workflow import SmokeWorkflow

__all__ = ["SmokeWorkflow"]
