"""Models for the smoke test workflow."""

from pydantic import BaseModel


class SmokeInput(BaseModel):
    pass


class SmokeOutput(BaseModel):
    success: bool
    message: str
