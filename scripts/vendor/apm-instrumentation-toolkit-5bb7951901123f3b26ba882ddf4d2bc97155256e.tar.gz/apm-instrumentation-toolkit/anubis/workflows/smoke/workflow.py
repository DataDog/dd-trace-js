"""Smoke test workflow.

A minimal end-to-end test that proves the full APM stack is wired correctly:
CLI → setup.init() → workflow → AgentStep → API call → structured output parsing → state write.

Requires a configured repository (setup.init() must be called before running).
The prompt lives in anubis/core/resources/templates/smoke.md (builtin template).
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from ...core import Workflow
from .models import SmokeInput, SmokeOutput
from .steps import SmokeStep


class SmokeWorkflow(Workflow[SmokeInput, SmokeOutput]):
    """Minimal smoke test: one agent turn, structured output, exercises full APM stack."""

    name = "smoke"
    steps = [SmokeStep]
    # Exclude from repo-parametrized prompt snapshot tests — smoke is not
    # tied to any APM target repo.
    supported_repos: list[str] = []

    def __init__(self, **kwargs):
        kwargs.setdefault("namespace", "smoke")
        kwargs.setdefault("skip_git", True)
        kwargs.setdefault("headless", True)
        # Use a per-run tempdir so smoke tests never leave state behind
        self._smoke_tmpdir = tempfile.mkdtemp(prefix="anubis-smoke-")
        super().__init__(base_dir=Path(self._smoke_tmpdir), **kwargs)
