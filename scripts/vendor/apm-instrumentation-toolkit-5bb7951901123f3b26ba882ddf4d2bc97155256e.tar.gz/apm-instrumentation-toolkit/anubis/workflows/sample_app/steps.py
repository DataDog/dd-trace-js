"""Steps for the Sample App workflow."""

from pathlib import Path
from typing import TYPE_CHECKING, Any, List

from ...core.steps import AgentStep, Step

if TYPE_CHECKING:
    from ...core.context import Context

from .models import SampleAppGenerated, SampleAppInput, SampleAppResult


class GenerateAppStep(AgentStep[SampleAppInput, SampleAppGenerated]):
    """Generate sample app using AI agent.

    Uses the builtin 'sample-app-generator' prompt template.
    Subclasses should override get_prompt_variables to provide
    domain-specific context.
    """

    name = "generate_app"
    output_type = SampleAppGenerated
    prompt = "sample-app-generator"
    timeout_minutes = 15
    max_turns = 100
    model = "sonnet"


class ValidateAppStep(Step[SampleAppGenerated, SampleAppResult]):
    """Validate the generated sample app.

    Base implementation checks that the app file exists.
    Override _validate() for custom validation logic.
    """

    name = "validate_app"
    output_type = SampleAppResult

    def execute(self, input: SampleAppGenerated, ctx: "Context") -> SampleAppResult:
        """Validate the generated sample app."""
        errors: List[str] = []
        app_path = Path(input.app_path)

        if not app_path.exists():
            errors.append(f"Generated app not found: {app_path}")

        # Run custom validation if provided
        custom_errors = self._validate(input, ctx)
        errors.extend(custom_errors)

        return SampleAppResult(
            success=len(errors) == 0,
            app_path=str(app_path),
            services_required=input.services_required,
            validation_errors=errors,
        )

    def _validate(self, input: Any, ctx: "Context") -> List[str]:
        """Custom validation hook. Override in subclasses."""
        return []
