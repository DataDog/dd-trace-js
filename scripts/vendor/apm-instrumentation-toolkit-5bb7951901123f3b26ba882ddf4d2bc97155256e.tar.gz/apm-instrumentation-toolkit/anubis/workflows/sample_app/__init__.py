"""Sample App workflow for generating working sample applications.

This workflow generates a sample application that can be used for testing.
It provides a base implementation that can be extended for domain-specific
use cases (e.g., APM instrumentation testing).

Example:
    from anubis.workflows.sample_app import SampleAppWorkflow, SampleAppInput

    workflow = SampleAppWorkflow(output_dir=Path("./output"))
    result = workflow.run(SampleAppInput(output_dir="./output"))

    if result.success:
        print(f"Generated: {result.output.app_path}")
"""

from .models import SampleAppGenerated, SampleAppInput, SampleAppResult
from .steps import GenerateAppStep, ValidateAppStep
from .workflow import SampleAppWorkflow

__all__ = [
    # Workflow
    "SampleAppWorkflow",
    # Models
    "SampleAppInput",
    "SampleAppGenerated",
    "SampleAppResult",
    # Steps (for extension)
    "GenerateAppStep",
    "ValidateAppStep",
]
