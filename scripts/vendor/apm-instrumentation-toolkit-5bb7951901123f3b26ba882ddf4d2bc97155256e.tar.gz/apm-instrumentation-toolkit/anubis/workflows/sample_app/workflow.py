"""Sample App Workflow definition."""

from pathlib import Path
from typing import Optional

from ...core import Workflow
from .models import SampleAppInput, SampleAppResult
from .steps import GenerateAppStep, ValidateAppStep


class SampleAppWorkflow(Workflow[SampleAppInput, SampleAppResult]):
    """Generate a working sample application.

    This is a base workflow that can be extended for domain-specific
    sample app generation (e.g., for APM instrumentation testing).

    Usage::

        workflow = SampleAppWorkflow(
            output_dir=Path("/my/project/sample"),
        )
        result = workflow.run(SampleAppInput(output_dir="/my/project/sample"))

        if result.success:
            print(f"Generated: {result.output.app_path}")

    """

    name = "sample_app"
    steps = [GenerateAppStep, ValidateAppStep]

    def __init__(
        self,
        output_dir: Path,
        app_spec: Optional[str] = None,
        language: Optional[str] = None,
        user_prompt: Optional[str] = None,
        **options,
    ):
        """Initialize sample app workflow.

        Args:
            output_dir: Directory to write sample app
            app_spec: Optional app specification content (from --spec file)
            language: Optional target language (e.g., 'node', 'python')
            user_prompt: Optional inline guidance (auto-injected by executor)
            **options: Passed to Workflow (namespace, repository, headless, etc.)
        """
        super().__init__(**options)
        self.output_dir = Path(output_dir)
        self.app_spec = app_spec
        self.language = language
        self.user_prompt = user_prompt

    def _setup(self):
        """Setup context with configuration."""
        ctx = super()._setup()
        ctx.set("output_dir", str(self.output_dir))
        if self.app_spec:
            ctx.set("app_spec", self.app_spec)
        if self.language:
            ctx.set("language", self.language)
        return ctx
