"""Models for the Sample App workflow."""

from typing import List

from pydantic import BaseModel, Field


class SampleAppInput(BaseModel):
    """Input for sample app generation."""

    output_dir: str = Field(description="Directory to write sample app")


class SampleAppGenerated(BaseModel):
    """Output from generating sample app."""

    app_path: str = Field(description="Path to generated app file")
    services_required: List[str] = Field(default_factory=list)


class SampleAppResult(BaseModel):
    """Final output - validated sample app."""

    success: bool = True
    app_path: str
    services_required: List[str] = Field(default_factory=list)
    validation_errors: List[str] = Field(default_factory=list)
