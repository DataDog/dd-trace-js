"""Built-in workflows for common tasks.

These workflows use anubis core and provide generic patterns
that can be used directly or extended.

Available workflows:
- LintWorkflow: Lint and fix code
- ReviewerWorkflow: Code review with human-in-the-loop
- SampleAppWorkflow: Generate working sample applications
- TestWorkflow: Iterative test diagnosis and fixing
"""

from .lint import LintInput, LintResult, LintWorkflow
from .reviewer import CheckConfig, ReviewerWorkflow, ReviewInput, ReviewResult
from .sample_app import SampleAppInput, SampleAppResult, SampleAppWorkflow
from .test import TestInput, TestResult, TestWorkflow

__all__ = [
    # Lint
    "LintWorkflow",
    "LintInput",
    "LintResult",
    # Reviewer
    "ReviewerWorkflow",
    "ReviewInput",
    "ReviewResult",
    "CheckConfig",
    # Sample App
    "SampleAppWorkflow",
    "SampleAppInput",
    "SampleAppResult",
    # Test
    "TestWorkflow",
    "TestInput",
    "TestResult",
]
