"""Generic LLMObs experiment submission for workflow evaluations.

Any workflow eval can submit results without importing APM-specific types::

    from anubis.eval import EvalResult, submit_eval_results

    results = [
        EvalResult(name="issue-1234", metrics={"tests_passing": 1.0}),
        EvalResult(name="issue-1235", metrics={"tests_passing": 0.0}, status="failed"),
    ]
    submit_eval_results(results, experiment_name="my_eval__main", dataset_name="my_dataset")

Required environment variables:
    DD_API_KEY, DD_APP_KEY (and optionally DD_SITE, GIT_BRANCH)
"""

import logging
import os
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, cast

from ddtrace.llmobs import LLMObs
from ddtrace.llmobs._experiment import (
    BaseSummaryEvaluator,
    EvaluatorResult,
    SummaryEvaluatorContext,
)

from anubis.core.agents.eval_proxy import resolve_model_alias
from anubis.core.tracing.config import (
    _enable_llmobs_experiments,
    _get_branch,
    _get_project_name,
)
from anubis.core.version import get_toolkit_version
from anubis.eval.models import EvalResult

logger = logging.getLogger(__name__)


def _resolve_model(results: List[EvalResult]) -> str:
    """Extract the model used from result tags, falling back to env/default."""
    for r in results:
        model = r.tags.get("model")
        if model:
            return resolve_model_alias(model)
    return resolve_model_alias(os.environ.get("ANTHROPIC_MODEL", "sonnet"))


def _pull_or_create_dataset(
    dataset_name: str,
    project_name: str,
    description: str,
    records: List[Any],
    id_key: str = "name",
) -> Any:
    """Pull or create a dataset, syncing any new/updated records by id_key."""
    try:
        dataset = LLMObs.pull_dataset(dataset_name, project_name=project_name)
    except Exception:
        logger.info("Dataset '%s' not found, creating it", dataset_name)
        return LLMObs.create_dataset(
            dataset_name=dataset_name,
            description=description,
            records=records,
            project_name=project_name,
        )

    existing_by_id: Dict[str, int] = {}
    raw_records = getattr(dataset, "_records", None) or []
    for idx, record in enumerate(raw_records):
        if not isinstance(record, dict):
            continue
        input_data = record.get("input_data") or {}
        if isinstance(input_data, dict):
            val = str(input_data.get(id_key, ""))
            if val:
                existing_by_id[val] = idx

    added = updated = 0
    for new_record in records:
        key_val = str((new_record.get("input_data") or {}).get(id_key, ""))
        if not key_val:
            continue
        if key_val in existing_by_id:
            dataset.update(
                existing_by_id[key_val],
                cast(Any, {"input_data": new_record["input_data"]}),
            )
            updated += 1
        else:
            dataset.append(new_record)
            added += 1

    if added or updated:
        logger.info("Syncing dataset '%s': %d new, %d updated", dataset_name, added, updated)
        try:
            dataset.push()
        except Exception as e:
            logger.warning("Failed to push dataset updates: %s", e)

    return dataset


def _make_metric_evaluator(key: str) -> Any:
    """Return a named evaluator function for a single metric key."""

    def _eval(input_data: Any, output_data: Any, expected_output: Any) -> Any:
        val = (output_data or {}).get(key)
        if val is None:
            return None
        return EvaluatorResult(value=float(val))

    _eval.__name__ = key
    return _eval


def _make_summary_evaluator(metric_keys: List[str]) -> Any:
    """Return a summary evaluator that averages all metric keys across results."""

    class _SummaryEvaluator(BaseSummaryEvaluator):
        def __init__(self) -> None:
            super().__init__(name="aggregate")

        def evaluate(self, context: SummaryEvaluatorContext) -> Any:
            totals: Dict[str, List[float]] = defaultdict(list)
            for output in context.outputs:
                if not isinstance(output, dict):
                    continue
                for k in metric_keys:
                    val = output.get(k)
                    if isinstance(val, (int, float)):
                        totals[k].append(float(val))

            result: Dict[str, Any] = {
                k: round(sum(vs) / len(vs), 4) for k, vs in totals.items() if vs
            }
            result["evaluated"] = len([o for o in context.outputs if isinstance(o, dict)])
            return result

    return _SummaryEvaluator()


def submit_eval_results(
    results: List[EvalResult],
    experiment_name: str,
    dataset_name: str,
    project_name: Optional[str] = None,
    tags: Optional[Dict[str, str]] = None,
    summary_evaluator: Optional[Any] = None,
) -> bool:
    """Submit arbitrary eval results to LLMObs as an experiment run.

    Dynamically creates one evaluator per unique metric key across all results.
    The experiment name should be stable (no random IDs) so runs accumulate
    as a trend over time.

    Args:
        results: Eval results to submit; entries with no metrics are skipped.
        experiment_name: STABLE name — each call adds a new run for trend tracking.
        dataset_name: LLMObs dataset to pull-or-create.
        project_name: LLMObs project (default: auto-detected from CI env).
        tags: Additional string tags for querying in Datadog.
        summary_evaluator: Optional domain-specific summary evaluator. Defaults to
            a generic per-metric average. Pass a custom evaluator to compute
            domain-specific aggregates (e.g. micro-averaged precision/recall).

    Returns:
        True if submission succeeded.
    """
    project_name = project_name or _get_project_name()
    if not _enable_llmobs_experiments(project_name):
        return False

    # Include any result that produced metrics — failed outcomes are valid data points
    scored_results = [r for r in results if r.metrics]
    if not scored_results:
        logger.warning("No results with metrics to submit")
        return False

    # Collect ordered, deduplicated metric keys across all results
    seen: set = set()
    all_keys: List[str] = []
    for r in scored_results:
        for k in r.metrics:
            if k not in seen:
                all_keys.append(k)
                seen.add(k)

    dataset_records = [
        {
            "input_data": {
                "name": r.name,
                "status": r.status,
                **{k: v for k, v in r.metrics.items() if v is not None},
                "cost_usd": r.cost_usd,
                "duration_s": r.duration_s,
                **({"error": r.error[:2000]} if r.error else {}),
            },
            "expected_output": {},
            "metadata": {"name": r.name, **r.tags},
        }
        for r in scored_results
    ]

    try:
        # Sync records into the master dataset for longitudinal tracking.
        _pull_or_create_dataset(
            dataset_name=dataset_name,
            project_name=project_name,
            description=f"Eval dataset: {dataset_name}",
            records=dataset_records,
            id_key="name",
        )

        # Create a fresh in-memory dataset from current records for the experiment.
        # Pulled datasets store input_data/metadata as JSON strings; passing them
        # directly to LLMObs.experiment() causes TypeError in _prepare_summary_evaluator_data.
        run_dataset = LLMObs.create_dataset(
            dataset_name=dataset_name,
            description=f"Eval dataset: {dataset_name}",
            records=cast(Any, dataset_records),
            project_name=project_name,
        )

        def _task(input_data: Any, config: Optional[Any] = None) -> Any:
            return {k: (input_data or {}).get(k) for k in all_keys}

        all_tags: Dict[str, str] = {
            "env": "ci" if os.environ.get("CI") else "dev",
            "branch": _get_branch(),
            "evaluated": str(len(scored_results)),
            "toolkit.version": get_toolkit_version(),
        }
        status_counts = Counter(r.status for r in scored_results)
        all_tags.update({
            "eval.status.ok": str(status_counts.get("ok", 0)),
            "eval.status.fail": str(status_counts.get("fail", 0)),
            "eval.status.error": str(status_counts.get("error", 0)),
        })
        all_tags["model"] = _resolve_model(scored_results)
        if tags:
            all_tags.update(tags)

        exp = LLMObs.experiment(
            name=experiment_name,
            task=_task,
            dataset=run_dataset,
            evaluators=[_make_metric_evaluator(k) for k in all_keys],
            summary_evaluators=[summary_evaluator or _make_summary_evaluator(all_keys)],
            project_name=project_name,
            tags=all_tags,
        )
        run_result = exp.run(jobs=min(len(scored_results), 8))

        runs = run_result.get("runs", [])
        if runs:
            wrapper = runs[0].summary_evaluations.get("aggregate")
            agg = wrapper.get("value") if isinstance(wrapper, dict) else {}
            if isinstance(agg, dict):
                parts = [
                    f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}" for k, v in agg.items()
                ]
                if parts:
                    msg = "  ".join(parts)
                    logger.info("Aggregate: %s", msg)
                    print(f"  LLMObs aggregate: {msg}")

        print(f"  Records submitted: {len(scored_results)}")
        try:
            print(f"  View experiment: {exp.url}")
        except Exception as e:
            logger.debug("Experiment URL not available: %s", e)

        logger.info("Experiment '%s' submitted to project '%s'", experiment_name, project_name)
        return True

    except Exception as e:
        logger.error("LLMObs submission failed: %s", e)
        return False
