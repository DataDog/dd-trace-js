"""Content hashing for eval cache invalidation.

Hash the inputs that affect an eval's output — prompts, skills, reference
files — so that only items whose inputs changed need to be re-evaluated.

The hash is deterministic: same files in any order produce the same digest
(paths are sorted before hashing).

Example::

    from anubis.eval.hashing import hash_eval_inputs

    digest = hash_eval_inputs(
        prompts=[Path("prompts/analyze/prompt.md")],
        skills=[Path("skills/datadog-semantics/SKILL.md")],
        extras=[Path("prompts/analyze/references/general.md")],
    )
    # → "a1b2c3d4e5f6" (12-char hex)
"""

import hashlib
import re
from pathlib import Path
from typing import List, Optional


def _strip_template_directives(content: bytes) -> bytes:
    r"""Strip ``{{...}}`` template directive lines before hashing.

    Injected content (``{{link:...}}``, ``{{include:...}}``,
    ``{{include_repo:...}}``) is captured separately by hashing the
    referenced files. Only prose/instructional changes affect the hash.
    """
    text = content.decode()
    text = re.sub(r"^\s*(?:- )?\{\{[^}]+\}\}.*\n", "", text, flags=re.MULTILINE)
    return text.encode()


def hash_file_contents(
    paths: List[Path],
    *,
    strip_directives: bool = False,
) -> str:
    """Hash sorted file contents into a 12-char hex digest.

    Args:
        paths: Files to hash. Non-existent paths are silently skipped.
            Order does not matter — paths are sorted before hashing.
        strip_directives: When True, strip ``{{...}}`` template directive
            lines from file contents before hashing. Useful for prompt
            files where directive additions shouldn't invalidate the hash.

    Returns:
        12-character SHA-256 hex digest.
    """
    h = hashlib.sha256()
    for p in sorted(paths):
        if not p.exists():
            continue
        content = p.read_bytes()
        if strip_directives:
            content = _strip_template_directives(content)
        h.update(content)
    return h.hexdigest()[:12]


def hash_eval_inputs(
    prompts: List[Path],
    skills: Optional[List[Path]] = None,
    extras: Optional[List[Path]] = None,
    *,
    strip_directives: bool = True,
) -> str:
    """Hash all inputs that affect an eval's output.

    Prompts have ``{{...}}`` directives stripped by default (the referenced
    content is captured via ``extras``). Skills and extras are hashed as-is.

    Args:
        prompts: Prompt template files (directives stripped by default).
        skills: Skill files used by the agent.
        extras: Reference files, repo-specific fragments, category guides, etc.
        strip_directives: Strip ``{{...}}`` lines from prompts (default True).

    Returns:
        12-character SHA-256 hex digest.
    """
    h = hashlib.sha256()
    for p in sorted(prompts):
        if not p.exists():
            continue
        content = p.read_bytes()
        if strip_directives:
            content = _strip_template_directives(content)
        h.update(content)
    for p in sorted([*(skills or []), *(extras or [])]):
        if p.exists():
            h.update(p.read_bytes())
    return h.hexdigest()[:12]
