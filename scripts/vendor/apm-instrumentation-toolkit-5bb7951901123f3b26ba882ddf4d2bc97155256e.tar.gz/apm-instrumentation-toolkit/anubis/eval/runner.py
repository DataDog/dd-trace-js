"""Generic parallel eval runner.

Any workflow eval supplies an ``EvalSuite`` — the runner handles
parallelism, error isolation, and optional LLMObs submission.

Example::

    from anubis.eval import EvalResult, llmobs_ready
    from anubis.eval.base import EvalItem, EvalSuite
    from anubis.eval.runner import MatrixRunner

    class MyTask:
        def run(self, item: EvalItem) -> EvalResult:
            score = do_work(item.name)
            return EvalResult(name=item.name, metrics={"score": score})

    suite = EvalSuite(
        name="my_eval__main",
        items=[EvalItem(name="a"), EvalItem(name="b")],
        task=MyTask(),
        concurrency=4,
    )
    results = MatrixRunner().run(suite)
    # → submit separately or use run_and_submit()
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from types import TracebackType
from typing import List, Optional, Tuple

from ddtrace.llmobs import LLMObs

from anubis.core.tracing.config import is_llmobs_enabled
from anubis.eval.base import EvalSuite
from anubis.eval.llmobs import submit_eval_results
from anubis.eval.models import EvalResult

logger = logging.getLogger(__name__)


class MatrixRunner:
    """Parallel executor for any ``EvalSuite``.

    Calls ``suite.task.run(item)`` concurrently up to ``suite.concurrency``
    workers. Exceptions are caught per-item and returned as ``status="error"``
    results so a single failure never aborts the run.

    Results are returned in the same order as ``suite.items``.
    """

    def run(self, suite: EvalSuite) -> List[EvalResult]:
        """Execute all items in parallel and return scored results.

        Args:
            suite: The eval suite to run.

        Returns:
            One ``EvalResult`` per item, in input order. Items that raised
            exceptions have ``status="error"`` and their traceback in ``error``.
        """
        items = suite.items
        if not items:
            logger.warning("EvalSuite '%s' has no items", suite.name)
            return []

        results: dict[int, EvalResult] = {}

        workers = suite.concurrency or len(items)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(self._run_one, suite, i): i for i, _ in enumerate(items)}
            for future in as_completed(futures):
                idx = futures[future]
                results[idx] = future.result()

        return [results[i] for i in range(len(items))]

    def _run_one(self, suite: EvalSuite, idx: int) -> EvalResult:
        item = suite.items[idx]
        logger.info("EvalSuite '%s': starting %s (idx=%d)", suite.name, item.name, idx)
        span = self._open_item_span(suite, item.name)
        exc_info: tuple[type[BaseException] | None, BaseException | None, TracebackType | None] = (
            None,
            None,
            None,
        )
        result = EvalResult(name=item.name, status="error", error="Eval item did not complete")
        try:
            result = EvalResult.model_validate(suite.task.run(item))
            logger.info("EvalSuite '%s': %s done → status=%s", suite.name, item.name, result.status)
            return result
        except Exception as exc:
            exc_info = (type(exc), exc, exc.__traceback__)
            logger.error("EvalSuite '%s': %s raised %s", suite.name, item.name, exc)
            result = EvalResult(name=item.name, status="error", error=str(exc))
            return result
        finally:
            if span is not None:
                self._close_item_span(span, result, exc_info)

    def _open_item_span(self, suite: EvalSuite, item_name: str):
        if not is_llmobs_enabled():
            return None
        try:
            span = LLMObs.task(name=f"eval_item.{suite.name}.{item_name}").__enter__()
            LLMObs.annotate(
                span=span,
                input_data={"suite": suite.name, "item": item_name},
                tags={
                    "eval.suite": suite.name,
                    "eval.item": item_name,
                    **suite.tags,
                },
            )
            return span
        except Exception as exc:
            logger.debug("Failed to open LLMObs eval item span: %s", exc)
            return None

    def _close_item_span(
        self,
        span,
        result: EvalResult,
        exc_info: tuple[type[BaseException] | None, BaseException | None, TracebackType | None],
    ) -> None:
        try:
            LLMObs.annotate(
                span=span,
                output_data={
                    "status": result.status,
                    "metrics": result.metrics,
                    **({"error": result.error} if result.error else {}),
                },
                tags={
                    "eval.status": result.status,
                    "eval.error": "true" if result.status == "error" else "false",
                },
            )
        except Exception as exc:
            logger.debug("Failed to annotate LLMObs eval item span: %s", exc)

        try:
            if exc_info[0] is not None:
                span.__exit__(*exc_info)
            elif result.status == "error":
                error = RuntimeError(result.error or f"Eval item {result.name} errored")
                span.__exit__(RuntimeError, error, None)
            else:
                span.__exit__(None, None, None)
        except Exception as exc:
            logger.debug("Failed to close LLMObs eval item span: %s", exc)

    def run_and_submit(
        self,
        suite: EvalSuite,
        experiment_name: Optional[str] = None,
        dataset_name: Optional[str] = None,
        tags: Optional[dict] = None,
    ) -> Tuple[List[EvalResult], bool]:
        """Run the suite and submit results to LLMObs.

        Args:
            suite: The eval suite to run.
            experiment_name: Override experiment name (default: ``suite.name``).
            dataset_name: Override dataset name (default: ``suite.dataset_name or suite.name``).
            tags: Extra tags merged with ``suite.tags``.

        Returns:
            Tuple of (results, submitted) where ``submitted`` is True when
            LLMObs submission succeeded.
        """
        results = self.run(suite)

        exp_name = experiment_name or suite.name
        ds_name = dataset_name or suite.dataset_name or suite.name
        all_tags = {**suite.tags, **(tags or {})}

        submitted = submit_eval_results(
            results,
            experiment_name=exp_name,
            dataset_name=ds_name,
            project_name=suite.project_name,
            tags=all_tags or None,
        )
        return results, submitted
