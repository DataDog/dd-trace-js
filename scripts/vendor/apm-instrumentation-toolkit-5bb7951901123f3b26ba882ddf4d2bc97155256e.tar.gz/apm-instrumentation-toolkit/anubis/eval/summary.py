"""Generic eval result summary printer.

Works with any ``EvalResult`` list — auto-discovers metric columns or
accepts caller-specified column configuration.
"""

from typing import Dict, List, Optional

from anubis.eval.models import EvalResult

DEFAULT_FAILURE_DETAIL_CHARS = 6000


def _format_value(val: Optional[float], fmt: Optional[str] = None) -> str:
    """Format a single metric value for display."""
    if val is None:
        return "—"
    if fmt:
        return fmt.format(val)
    if 0 <= val <= 1:
        return f"{val:.0%}"
    if val == int(val):
        return str(int(val))
    return f"{val:.2f}"


def print_eval_summary(
    results: List[EvalResult],
    title: str = "",
    metric_columns: Optional[List[str]] = None,
    metric_labels: Optional[Dict[str, str]] = None,
    metric_formats: Optional[Dict[str, str]] = None,
    extra_columns: Optional[Dict[str, str]] = None,
    sum_columns: Optional[List[str]] = None,
) -> None:
    """Print a human-readable summary table of eval results.

    Args:
        results: Eval results to summarize.
        title: Optional title line above the table.
        metric_columns: Which metric keys to show as columns.
            Defaults to auto-discovery from results.
        metric_labels: Display names for metric columns
            (e.g. ``{"precision": "Prec"}``).
        metric_formats: Python format strings per column
            (e.g. ``{"cost_usd": "${:.4f}"}``). Default: 0-1 as ``%``,
            integers as-is, else 2 decimal places.
        extra_columns: Top-level EvalResult fields to show as additional columns,
            mapped to display labels (e.g. ``{"duration_s": "Time(s)", "cost_usd": "Cost($)"}``)
    """
    if not results:
        print("No results.")
        return

    if metric_columns is None:
        seen: list[str] = []
        for r in results:
            for k in r.metrics:
                if k not in seen:
                    seen.append(k)
        metric_columns = seen

    labels = metric_labels or {}
    formats = metric_formats or {}
    extra = extra_columns or {}

    # Extra columns read from top-level EvalResult fields, not metrics
    extra_keys = list(extra.keys())
    extra_headers = list(extra.values())

    name_width = max(max(len(r.name) for r in results), 7) + 2
    col_headers = [labels.get(c, c) for c in metric_columns]
    col_widths = [max(len(h) + 2, 9) for h in col_headers]
    extra_widths = [max(len(h) + 2, 9) for h in extra_headers]

    table_width = (
        name_width + sum(w + 1 for w in col_widths) + sum(w + 1 for w in extra_widths) + 10
    )
    sep = "=" * table_width
    dash = "-" * table_width

    lines: list[str] = []
    if title:
        lines.extend(["", sep, title, sep])

    header = f"{'Name':<{name_width}}"
    for h, w in zip(col_headers, col_widths):
        header += f" {h:>{w}}"
    for h, w in zip(extra_headers, extra_widths):
        header += f" {h:>{w}}"
    header += f"  {'Status':<8}"
    lines.extend([header, dash])

    ok_count = 0
    sums: dict[str, float] = {}
    counts: dict[str, int] = {}

    for r in results:
        row = f"{r.name:<{name_width}}"
        for col, w in zip(metric_columns, col_widths):
            val = r.metrics.get(col)
            row += f" {_format_value(val, formats.get(col)):>{w}}"
            if val is not None:
                sums[col] = sums.get(col, 0.0) + val
                counts[col] = counts.get(col, 0) + 1
        for col, w in zip(extra_keys, extra_widths):
            val = getattr(r, col, None)
            row += f" {_format_value(val, formats.get(col)):>{w}}"
            if val is not None:
                sums[col] = sums.get(col, 0.0) + val
                counts[col] = counts.get(col, 0) + 1
        row += f"  {r.status:<8}"
        if r.status == "ok":
            ok_count += 1
        lines.append(row)

    lines.append(dash)

    sum_cols: set[str] = set(sum_columns or [])

    if ok_count:
        avg_row = f"{'AVERAGE':<{name_width}}"
        for col, w in zip(metric_columns, col_widths):
            cnt = counts.get(col, 0)
            avg_row += f" {_format_value(sums[col] / cnt if cnt else None, formats.get(col)):>{w}}"
        for col, w in zip(extra_keys, extra_widths):
            cnt = counts.get(col, 0)
            avg_row += f" {_format_value(sums[col] / cnt if cnt else None, formats.get(col)):>{w}}"
        other = len(results) - ok_count
        avg_row += f"  ({ok_count} evaluated, {other} other)"
        lines.append(avg_row)

        if sum_cols:
            tot_row = f"{'TOTAL':<{name_width}}"
            for col, w in zip(metric_columns, col_widths):
                val = sums.get(col) if col in sum_cols else None
                tot_row += f" {_format_value(val, formats.get(col)):>{w}}"
            for col, w in zip(extra_keys, extra_widths):
                val = sums.get(col) if col in sum_cols else None
                tot_row += f" {_format_value(val, formats.get(col)):>{w}}"
            tot_row += f"  ({ok_count} evaluated)"
            lines.append(tot_row)
    else:
        lines.append(f"No items evaluated ({len(results)} total)")

    lines.append(sep)
    print("\n".join(lines))


def format_eval_failure_details(
    results: List[EvalResult], *, tail_chars: int = DEFAULT_FAILURE_DETAIL_CHARS
) -> str:
    """Return bounded error details for non-ok eval results.

    This keeps the CLI failure surface generic: individual eval tasks only need
    to put the actionable harness or oracle output into ``EvalResult.error``.
    """
    failed = [r for r in results if r.status != "ok" or r.error]
    if not failed:
        return ""

    lines = ["", "Failure details"]
    for result in failed:
        lines.append(f"{result.name} status={result.status}")
        if not result.error:
            continue
        error = result.error.strip()
        if len(error) > tail_chars:
            error = "... truncated; see detail artifact for full error ...\n" + error[-tail_chars:]
        lines.append(error)
    return "\n".join(lines)


def print_eval_failure_details(
    results: List[EvalResult], *, tail_chars: int = DEFAULT_FAILURE_DETAIL_CHARS
) -> None:
    """Print bounded details for non-ok eval results."""
    details = format_eval_failure_details(results, tail_chars=tail_chars)
    if details:
        print(details)
