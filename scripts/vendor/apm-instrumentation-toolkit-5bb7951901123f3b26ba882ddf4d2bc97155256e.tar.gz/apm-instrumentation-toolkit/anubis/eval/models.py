"""Generic eval result model for workflow evaluations."""

from typing import Dict, Optional

from pydantic import BaseModel


class EvalResult(BaseModel):
    """A single unit of eval output — package, issue ID, task ID, etc.

    The ``metrics`` dict accepts arbitrary named float scores so any workflow
    eval can submit results without importing APM-specific types::

        EvalResult(
            name="issue-1234",
            metrics={"tests_passing": 1.0, "lint_clean": 1.0},
        )
    """

    name: str
    metrics: Dict[str, Optional[float]] = {}
    tags: Dict[str, str] = {}
    status: str = "ok"
    cost_usd: float = 0.0
    duration_s: float = 0.0
    error: str = ""
