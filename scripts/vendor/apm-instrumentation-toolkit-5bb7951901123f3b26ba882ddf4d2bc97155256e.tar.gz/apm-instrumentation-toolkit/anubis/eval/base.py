"""Core eval abstractions: EvalItem, EvalTask, EvalSuite.

These are the three primitives any workflow eval must supply.
The MatrixRunner handles all the boilerplate: parallelism, error handling,
result collection, and LLMObs submission.

Example (method selection eval)::

    class MethodSelectionTask:
        def run(self, item: EvalItem) -> EvalResult:
            ...score analysis against ground truths...
            return EvalResult(name=item.name, metrics={"precision": 1.0})

    suite = EvalSuite(
        name="method_selection__dd_trace_js",
        items=[EvalItem(name="pg"), EvalItem(name="kafkajs")],
        task=MethodSelectionTask(...),
    )
    results = MatrixRunner().run(suite)

Example (GH issue fix eval)::

    class GHIssueFixTask:
        def run(self, item: EvalItem) -> EvalResult:
            ...checkout parent commit, run workflow, run tests...
            return EvalResult(name=item.name, metrics={"tests_passing": 1.0})
"""

from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

from pydantic import BaseModel

from anubis.eval.models import EvalResult


@runtime_checkable
class EvalTask(Protocol):
    """Run one eval unit and return a scored result.

    Implementations are responsible for all domain logic: loading inputs,
    running the workflow or oracle, and mapping outputs to named metrics.
    Thread-safety is required — the MatrixRunner calls ``run()`` concurrently.
    """

    def run(self, item: "EvalItem") -> EvalResult: ...


class EvalItem(BaseModel):
    """A single unit in the eval dataset."""

    name: str
    metadata: Dict[str, Any] = {}


class EvalSuite(BaseModel):
    """Bundles a dataset and a task with eval configuration.

    ``name`` doubles as the LLMObs experiment name base (``{name}__{branch}``).
    """

    name: str
    items: List[EvalItem]
    task: Any  # EvalTask — Any to avoid Protocol serialization issues
    concurrency: int = 0  # 0 = len(items) (one worker per item)
    dataset_name: str = ""  # defaults to suite.name
    project_name: Optional[str] = None
    tags: Dict[str, str] = {}

    model_config = {"arbitrary_types_allowed": True}
