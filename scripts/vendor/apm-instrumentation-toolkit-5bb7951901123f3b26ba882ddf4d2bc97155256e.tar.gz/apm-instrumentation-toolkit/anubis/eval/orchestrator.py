"""Eval lifecycle orchestrator with pre/post hooks.

``MatrixRunner`` handles parallel execution of individual eval items.
``EvalOrchestrator`` wraps the full lifecycle: suite preparation,
pre-eval work, execution, post-eval work, and LLMObs submission.

Subclass and override ``pre_eval()``/``post_eval()`` for domain-specific
setup and teardown::

    class AnalysisOrchestrator(EvalOrchestrator):
        def pre_eval(self, suite):
            # run missing analyses, prompt-hash gating, etc.
            return filtered_suite

        def post_eval(self, suite, results):
            # write detail reports, clean up worktrees, etc.
            pass

    orchestrator = AnalysisOrchestrator()
    results, submitted = orchestrator.run(suite, submit=True)
"""

import logging
from types import TracebackType
from typing import Dict, List, Optional, Tuple

from ddtrace.llmobs import LLMObs

from anubis.core.tracing.config import is_llmobs_enabled
from anubis.eval.base import EvalSuite
from anubis.eval.models import EvalResult
from anubis.eval.runner import MatrixRunner

logger = logging.getLogger(__name__)


class EvalOrchestrator:
    """Lifecycle orchestrator wrapping ``MatrixRunner`` with pre/post hooks.

    The ``run()`` method drives the standard flow::

        suite = pre_eval(suite)     # filter items, seed state, etc.
        results = MatrixRunner().run(suite)
        post_eval(suite, results)   # reports, cleanup, etc.
        submit to LLMObs (if requested)

    Subclasses override ``pre_eval``/``post_eval`` for domain-specific
    behavior. The base implementations are no-ops.
    """

    def pre_eval(self, suite: EvalSuite) -> EvalSuite:
        """Called before running the suite. Can modify or filter items.

        Override for setup work: running missing analyses, seeding state,
        creating worktrees, prompt-hash gating, etc.

        Args:
            suite: The eval suite about to run.

        Returns:
            The (possibly modified) suite to actually run.
        """
        return suite

    def post_eval(self, suite: EvalSuite, results: List[EvalResult]) -> None:
        """Called after running the suite with the collected results.

        Override for teardown: writing detail reports, cleaning up
        worktrees, collecting artifacts, etc.

        Args:
            suite: The suite that was run.
            results: One ``EvalResult`` per item, in input order.
        """

    def run(
        self,
        suite: EvalSuite,
        *,
        submit: bool = False,
        experiment_name: Optional[str] = None,
        dataset_name: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
    ) -> Tuple[List[EvalResult], bool]:
        """Execute the full eval lifecycle.

        Args:
            suite: The eval suite to run.
            submit: When True, submit results to LLMObs after execution.
            experiment_name: Override experiment name (default: suite.name).
            dataset_name: Override dataset name (default: suite.dataset_name).
            tags: Extra tags merged with suite.tags for LLMObs submission.

        Returns:
            Tuple of (results, submitted). ``submitted`` is False when
            ``submit=False`` or when LLMObs submission fails.
        """
        span_name = f"eval_run.{suite.name}"
        span = None
        if is_llmobs_enabled():
            try:
                span = LLMObs.task(name=span_name).__enter__()
                LLMObs.annotate(
                    span=span,
                    input_data={
                        "suite": suite.name,
                        "items": [item.name for item in suite.items],
                        "experiment": experiment_name or suite.name,
                    },
                    tags={
                        "eval.suite": suite.name,
                        "eval.experiment": experiment_name or suite.name,
                        **(tags or {}),
                    },
                )
            except Exception as e:
                logger.debug("Failed to open LLMObs eval span: %s", e)
                span = None

        results: List[EvalResult] = []
        submitted = False
        exc_info: tuple[type[BaseException] | None, BaseException | None, TracebackType | None] = (
            None,
            None,
            None,
        )
        try:
            suite = self.pre_eval(suite)

            runner = MatrixRunner()
            if submit:
                results, submitted = runner.run_and_submit(
                    suite,
                    experiment_name=experiment_name,
                    dataset_name=dataset_name,
                    tags=tags,
                )
            else:
                results = runner.run(suite)
                submitted = False

            self.post_eval(suite, results)
        except BaseException as exc:
            exc_info = (type(exc), exc, exc.__traceback__)
            raise
        finally:
            if span is not None:
                try:
                    passed = sum(1 for r in results if r.status == "ok")
                    errored = sum(1 for r in results if r.status == "error")
                    failed = len(results) - passed - errored
                    LLMObs.annotate(
                        span=span,
                        output_data={
                            "total": len(results),
                            "passed": passed,
                            "failed": failed,
                            "errored": errored,
                            "pass_rate": round(passed / len(results), 4) if results else 0.0,
                        },
                        tags={
                            "eval.passed": str(passed),
                            "eval.failed": str(failed),
                            "eval.errored": str(errored),
                        },
                    )
                except Exception as e:
                    logger.debug("Failed to annotate LLMObs eval span: %s", e)
                try:
                    if exc_info[0] is not None:
                        span.__exit__(*exc_info)
                    elif any(r.status == "error" for r in results):
                        error = RuntimeError(
                            "Eval run had errored results: "
                            + ", ".join(f"{r.name}=error" for r in results if r.status == "error")
                        )
                        span.__exit__(RuntimeError, error, None)
                    else:
                        span.__exit__(None, None, None)
                except Exception as e:
                    logger.debug("Failed to close LLMObs eval span: %s", e)

        return results, submitted
