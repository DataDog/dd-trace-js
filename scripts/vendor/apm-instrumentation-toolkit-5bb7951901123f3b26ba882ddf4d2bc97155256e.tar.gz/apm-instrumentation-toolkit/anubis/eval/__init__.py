"""Generic eval plumbing for any workflow evaluation.

Usage::

    from anubis.eval import EvalItem, EvalResult, EvalSuite, EvalTask, MatrixRunner
    from anubis.eval import submit_eval_results, llmobs_ready

    class MyTask:
        def run(self, item: EvalItem) -> EvalResult:
            return EvalResult(name=item.name, metrics={"score": 1.0})

    suite = EvalSuite(
        name="my_eval__main",
        items=[EvalItem(name="a"), EvalItem(name="b")],
        task=MyTask(),
    )
    results, submitted = MatrixRunner().run_and_submit(suite)
"""

from anubis.core.tracing.config import llmobs_ready

from .base import EvalItem, EvalSuite, EvalTask
from .hashing import hash_eval_inputs, hash_file_contents
from .llmobs import submit_eval_results
from .models import EvalResult
from .orchestrator import EvalOrchestrator
from .runner import MatrixRunner
from .summary import format_eval_failure_details, print_eval_failure_details, print_eval_summary

__all__ = [
    "EvalItem",
    "EvalOrchestrator",
    "EvalResult",
    "EvalSuite",
    "EvalTask",
    "MatrixRunner",
    "format_eval_failure_details",
    "hash_eval_inputs",
    "print_eval_failure_details",
    "print_eval_summary",
    "hash_file_contents",
    "llmobs_ready",
    "submit_eval_results",
]
