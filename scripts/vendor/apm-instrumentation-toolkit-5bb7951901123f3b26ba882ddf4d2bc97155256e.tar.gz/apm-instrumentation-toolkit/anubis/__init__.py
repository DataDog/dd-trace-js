"""Anubis - Workflow orchestration framework.

Example::

    # Simple decorator API
    from anubis import step, agent_step, workflow
    from anubis import StepConfig, AgentStepConfig, WorkflowConfig

    @step(StepConfig(name="process", output_type=MyOutput))
    def process(input, ctx):
        return MyOutput(...)

    # Full class-based API
    from anubis.core import Workflow, Step, AgentStep

"""

# Decorator API (simple)
from ._api import (  # noqa: E402
    AgentStepConfig,
    CompositeStepConfig,
    StepConfig,
    WorkflowConfig,
    agent_step,
    composite_step,
    step,
    workflow,
)
from .core.context import Context  # noqa: E402
from .core.steps import AgentStep, CompositeStep, Step  # noqa: E402
from .core.types import Result, Status  # noqa: E402

# Core classes (power users)
from .core.workflow import Workflow  # noqa: E402

__all__ = [
    # Decorator API
    "step",
    "agent_step",
    "composite_step",
    "workflow",
    "StepConfig",
    "AgentStepConfig",
    "CompositeStepConfig",
    "WorkflowConfig",
    # Core classes
    "Workflow",
    "Step",
    "AgentStep",
    "CompositeStep",
    "Context",
    "Result",
    "Status",
]
