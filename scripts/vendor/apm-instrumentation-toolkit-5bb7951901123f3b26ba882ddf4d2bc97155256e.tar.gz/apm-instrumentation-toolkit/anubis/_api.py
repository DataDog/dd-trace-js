"""Decorator API for anubis workflows.

Uses typed Pydantic config models for type safety and self-documentation.
Config models are the source of truth for step/workflow configuration.

Example::

    from anubis import step, agent_step, workflow
    from anubis import StepConfig, AgentStepConfig, WorkflowConfig

    @step(StepConfig(name="process", output_type=MyOutput))
    def process(input, ctx):
        return MyOutput(...)

    @agent_step(AgentStepConfig(
        name="analyze",
        prompt="analyze",
        output_type=AnalysisOutput,
        model="sonnet",
        max_turns=50,
    ))
    class AnalyzeStep:
        def get_prompt_variables(self, input, ctx):
            return {"package": ctx.namespace}

    @workflow(WorkflowConfig(
        name="my_workflow",
        steps=[process, AnalyzeStep],
    ))
    class MyWorkflow:
        pass

"""

from typing import Callable, Dict, List, Optional, Type, TypeVar, Union

from pydantic import BaseModel, Field

from .core.steps import AgentStep, CompositeStep, Step
from .core.types import ValidatorFn
from .core.workflow import Workflow

F = TypeVar("F", bound=Callable)
C = TypeVar("C", bound=type)


# =============================================================================
# Config Models - Source of truth for configuration
# =============================================================================


class StepConfig(BaseModel):
    """Configuration for a Step."""

    name: str
    description: str = ""
    notes: str = ""
    output_type: Optional[Type[BaseModel]] = None
    output_type_overrides: Dict[str, Type[BaseModel]] = Field(default_factory=dict)
    input_type: Optional[Type[BaseModel]] = None
    validators: List[ValidatorFn] = Field(default_factory=list)
    validation_required: bool = True
    batch_execute: bool = False
    batch_size: int = 1
    optional: bool = False  # If True, step failures don't fail the workflow

    # Fixer configuration - if fixer_prompt is set, validation failures spawn a fixer agent
    fixer_prompt: Optional[str] = None
    fixer_model: str = "sonnet"
    max_fixer_iterations: int = 3

    model_config = {"arbitrary_types_allowed": True}


class AgentStepConfig(BaseModel):
    """Configuration for an AgentStep."""

    name: str
    description: str = ""
    notes: str = ""
    prompt: str
    output_type: Type[BaseModel]
    output_type_overrides: Dict[str, Type[BaseModel]] = Field(default_factory=dict)
    model: str = "sonnet"
    max_turns: int = 50
    timeout_minutes: int = 30
    skills: List[str] = Field(default_factory=list)
    output_file: Optional[str] = None
    use_repo_root: bool = False
    required_files: List[str] = Field(default_factory=list)
    validators: List[ValidatorFn] = Field(default_factory=list)
    validation_required: bool = True
    batch_execute: bool = False
    batch_size: int = 1
    sandbox: bool = True
    planning: bool = False  # If True, run planning phase first (read-only, all skills)
    save_spec: bool = False  # If True, save rendered prompt as spec artifact for downstream steps

    model_config = {"arbitrary_types_allowed": True}


class CompositeStepConfig(BaseModel):
    """Configuration for a CompositeStep."""

    name: str
    description: str = ""
    notes: str = ""
    output_type: Type[BaseModel]
    output_type_overrides: Dict[str, Type[BaseModel]] = Field(default_factory=dict)
    stages: List[Type[Step]] = Field(default_factory=list)
    max_iterations: int = 1

    model_config = {"arbitrary_types_allowed": True}


class WorkflowConfig(BaseModel):
    """Configuration for a Workflow."""

    name: str
    description: str = ""
    notes: str = ""
    steps: List[Union[Type[Step], Type[Workflow]]] = Field(default_factory=list)
    prompt: Optional[str] = None
    model_config = {"arbitrary_types_allowed": True}


# =============================================================================
# Decorators
# =============================================================================


def step(config: StepConfig) -> Callable[[F], Type[Step]]:
    """Create a Step from a function.

    Example::

        @step(StepConfig(name="process", output_type=MyOutput))
        def process(input, ctx):
            return MyOutput(...)

    """

    def decorator(fn: F) -> Type[Step]:
        # Build class attributes from config
        attrs = config.model_dump(exclude_none=True)

        # Create execute method that calls the function
        def execute(self, input, ctx):
            return fn(input, ctx)

        attrs["execute"] = execute

        # Create the Step subclass
        cls = type(config.name, (Step,), attrs)
        cls.__module__ = fn.__module__
        cls.__qualname__ = fn.__qualname__
        setattr(cls, "_wrapped_fn", fn)

        return cls

    return decorator


def agent_step(config: AgentStepConfig) -> Callable[[C], Type[AgentStep]]:
    """Create an AgentStep from a class.

    The decorated class can optionally define:

    - get_prompt_variables(self, input, ctx) -> dict

    Example::

        @agent_step(AgentStepConfig(
            name="analyze",
            prompt="analyze",
            output_type=AnalysisOutput,
        ))
        class AnalyzeStep:
            def get_prompt_variables(self, input, ctx):
                return {"package": ctx.namespace}

    """

    def decorator(cls: C) -> Type[AgentStep]:
        # Build class attributes from config
        attrs = config.model_dump(exclude_none=True)

        # Copy methods from decorated class
        for attr_name in dir(cls):
            if not attr_name.startswith("_"):
                attr = getattr(cls, attr_name)
                if callable(attr) and not isinstance(attr, type):
                    attrs[attr_name] = attr

        # Create the AgentStep subclass
        new_cls = type(cls.__name__, (AgentStep,), attrs)
        new_cls.__module__ = cls.__module__
        new_cls.__qualname__ = cls.__qualname__
        new_cls.__doc__ = cls.__doc__

        return new_cls

    return decorator


def composite_step(config: CompositeStepConfig) -> Callable[[C], Type[CompositeStep]]:
    """Create a CompositeStep from a class.

    The decorated class can optionally define:

    - should_continue(self, output, ctx) -> bool

    - before_iteration(self, iteration, input, ctx) -> input

    - after_iteration(self, iteration, output, ctx) -> output

    - after_stage_execute(self, stage_name, output, ctx) -> output

    - should_exit_early(self, stage_name, output, ctx) -> bool

    Example::

        @composite_step(CompositeStepConfig(
            name="lint_and_fix",
            output_type=LintResult,
            stages=[FixLintErrors],
            max_iterations=3,
        ))
        class LintAndFix:
            def should_continue(self, output, ctx):
                return output.final_errors > 0

    """

    def decorator(cls: C) -> Type[CompositeStep]:
        # Build class attributes from config
        attrs = config.model_dump(exclude_none=True)

        # Copy methods from decorated class
        for attr_name in dir(cls):
            if not attr_name.startswith("_"):
                attr = getattr(cls, attr_name)
                if callable(attr) and not isinstance(attr, type):
                    attrs[attr_name] = attr

        # Create the CompositeStep subclass
        new_cls = type(cls.__name__, (CompositeStep,), attrs)
        new_cls.__module__ = cls.__module__
        new_cls.__qualname__ = cls.__qualname__

        return new_cls

    return decorator


def workflow(config: WorkflowConfig) -> Callable[[C], Type[Workflow]]:
    """Create a Workflow from a class.

    The decorated class can optionally define:

    - setup(self, ctx) -> ctx: Called during workflow setup to configure context

    - after_step(self, step_name, output, ctx) -> output

    Example::

        @workflow(WorkflowConfig(
            name="analyze",
            steps=[AnalyzeStep, ProcessStep],
        ))
        class AnalyzeWorkflow:
            def setup(self, ctx):
                ctx.set('my_config', 'value')
                return ctx

    """

    def decorator(cls: C) -> Type[Workflow]:
        # Build class attributes from config
        attrs = config.model_dump(exclude_none=True)

        # Check if decorated class has setup method
        user_setup = getattr(cls, "setup", None)

        # Copy methods and known class-level metadata from the decorated class
        for attr_name in dir(cls):
            if not attr_name.startswith("_") and attr_name != "setup":
                attr = getattr(cls, attr_name)
                if callable(attr) and not isinstance(attr, type):
                    attrs[attr_name] = attr

        if supported_repos := getattr(cls, "supported_repos", None):
            attrs["supported_repos"] = supported_repos

        # If user defined setup, wrap _setup to call it
        if user_setup:

            def _setup(self):
                ctx = super(type(self), self)._setup()
                return user_setup(self, ctx)

            attrs["_setup"] = _setup

        # Create the Workflow subclass
        new_cls = type(cls.__name__, (Workflow,), attrs)
        new_cls.__module__ = cls.__module__
        new_cls.__qualname__ = cls.__qualname__

        return new_cls

    return decorator
