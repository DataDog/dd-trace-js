"""Result and validation types."""

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Callable, Dict, Generic, List, Optional, TypeVar, Union

from pydantic import BaseModel

if TYPE_CHECKING:
    from .context import Context

# Type variables for generic input/output
I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)


class Status(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    RETRYING = "retrying"
    CACHED = "cached"
    SKIPPED = "skipped"


@dataclass
class Result(Generic[O]):
    """Unified result type for steps and workflows."""

    status: Status
    output: Optional[O] = None
    error: Optional[str] = None
    metrics: Dict[str, Any] = field(default_factory=dict)
    cached: bool = False
    duration_ms: float = 0

    @property
    def success(self) -> bool:
        return self.status in (Status.SUCCESS, Status.CACHED)

    @classmethod
    def ok(cls, output: O, **metrics) -> "Result[O]":
        return cls(Status.SUCCESS, output=output, metrics=metrics)

    @classmethod
    def fail(cls, error: str, **metrics) -> "Result[O]":
        return cls(Status.FAILED, error=error, metrics=metrics)

    @classmethod
    def from_cache(cls, output: O) -> "Result[O]":
        return cls(Status.CACHED, output=output, cached=True)


# Validator type - function that takes (output, ctx, output_type) returns bool/str/list
# output_type is optional - validators can ignore it if they don't need schema info
ValidatorFn = Callable[..., Union[bool, str, List[str]]]


def validator(fn: ValidatorFn) -> ValidatorFn:
    """Decorator to mark a function as a validator."""
    setattr(fn, "_is_validator", True)
    return fn


def run_validators(
    validators: List[ValidatorFn], output: Any, ctx: "Context", output_type: Optional[type] = None
) -> List[str]:
    """Run all validators, return list of error messages.

    Args:
        validators: List of validator functions
        output: The output to validate
        ctx: Execution context
        output_type: Optional Pydantic model type for schema validation
    """
    errors = []
    for v in validators:
        try:
            result = v(output, ctx, output_type)
        except TypeError:
            # Validator doesn't accept output_type, call with 2 args
            result = v(output, ctx)

        if result is True:
            continue
        elif result is False:
            errors.append(f"{v.__name__} failed")
        elif isinstance(result, str):
            errors.append(result)
        elif isinstance(result, list):
            errors.extend(result)
    return errors
