"""Configuration loader for anubis framework.

Loads configuration from .anubis/config.yaml with support for:
- Environment variable overrides
- First-run detection and guided setup
"""

import os
import sys
from pathlib import Path
from typing import Any, Callable, Dict, Optional

import yaml

from .models import AnubisConfig, RepositoryConfig

# Config file location relative to toolkit root
CONFIG_DIR = ".anubis"
CONFIG_FILE = "config.yaml"


class ConfigError(Exception):
    """Configuration error with helpful message."""

    pass


class ConfigLoader:
    """Loads and manages anubis configuration.

    Configuration is loaded from {toolkit_root}/.anubis/config.yaml.

    The toolkit root is discovered by (first match wins):
    1. ANUBIS_TOOLKIT_ROOT environment variable
    2. Walking up from CWD to find .anubis/config.yaml (local-first)
    3. Walking up from this file to find apm-instrumentation-toolkit/
    4. Checking ~/.dd-apm/ for bootstrap installations

    This supports multiple use cases:
    - Local development: run from project dir, uses local .anubis/config.yaml
    - Global install: uses ~/.dd-apm/ when no local config found
    - Explicit: set ANUBIS_TOOLKIT_ROOT to force a specific location

    Example usage::

        loader = ConfigLoader()
        config = loader.load()

        # Get default repository
        repo = config.get_repo()

        # Get specific repository
        repo = config.get_repo("dd_trace_py")
    """

    def __init__(self, toolkit_root: Optional[Path] = None):
        """Initialize loader.

        Args:
            toolkit_root: Override toolkit root discovery. If None, auto-discovers.
        """
        self._toolkit_root = toolkit_root
        self._config: Optional[AnubisConfig] = None

    @property
    def toolkit_root(self) -> Path:
        """Get toolkit root, discovering if needed."""
        if self._toolkit_root is None:
            self._toolkit_root = self._discover_toolkit_root()
        return self._toolkit_root

    @property
    def config_dir(self) -> Path:
        """Get config directory path."""
        return self.toolkit_root / CONFIG_DIR

    @property
    def config_file(self) -> Path:
        """Get config file path."""
        return self.config_dir / CONFIG_FILE

    def _is_toolkit_root(self, path: Path) -> bool:
        """Check if a path is the toolkit root by looking for marker files.

        A valid toolkit root has both anubis/ and anubis_apm/ directories,
        or anubis/ and a pyproject.toml file.
        """
        anubis_dir = path / "anubis"
        if not anubis_dir.is_dir():
            return False
        # Check for anubis_apm or pyproject.toml as secondary marker
        return (path / "anubis_apm").is_dir() or (path / "pyproject.toml").is_file()

    def _discover_toolkit_root(self) -> Path:
        """Discover the toolkit root directory.

        Discovery order (first match wins):
        1. ANUBIS_TOOLKIT_ROOT environment variable
        2. Walk up from CWD to find .anubis/config.yaml (local-first)
        3. Walk up from this file to find anubis/ directory (toolkit marker)
        4. Check ~/.dd-apm (bootstrap install location)

        Returns:
            Path to toolkit root.

        Raises:
            ConfigError: If toolkit root cannot be found.
        """
        # Strategy 1: Environment variable
        env_root = os.environ.get("ANUBIS_TOOLKIT_ROOT")
        if env_root:
            path = Path(env_root).expanduser().resolve()
            if path.exists():
                return path
            raise ConfigError(
                f"ANUBIS_TOOLKIT_ROOT is set to '{env_root}' but path does not exist."
            )

        # Strategy 2: Walk up from CWD to find .anubis/config.yaml (local-first)
        # This supports developers running from within their project directory
        cwd = Path.cwd().resolve()
        search_path = cwd
        while search_path.parent != search_path:
            config_file = search_path / CONFIG_DIR / CONFIG_FILE
            if config_file.exists():
                return search_path
            search_path = search_path.parent

        # Strategy 3: Walk up from this file to find toolkit root (has anubis/ directory)
        current = Path(__file__).resolve()
        search_path = current.parent
        while search_path.parent != search_path:
            if self._is_toolkit_root(search_path):
                return search_path
            search_path = search_path.parent

        # Strategy 4: Check ~/.dd-apm (bootstrap install location)
        dd_apm_home = Path.home() / ".dd-apm"
        if dd_apm_home.exists() and (dd_apm_home / "bin" / "dd-apm").exists():
            return dd_apm_home

        raise ConfigError(
            "Could not find toolkit root.\n"
            "Set ANUBIS_TOOLKIT_ROOT environment variable or ensure you're running "
            "from within a directory containing anubis/."
        )

    def exists(self) -> bool:
        """Check if config file exists.

        Returns False if toolkit root cannot be discovered or config file is missing.
        """
        try:
            return self.config_file.exists()
        except ConfigError:
            return False

    def needs_init(self) -> bool:
        """Check if config needs initialization."""
        if not self.exists():
            return True
        try:
            config = self.load()
            if len(config.repositories) == 0:
                return True
            if config.default_repository and config.default_repository not in config.repositories:
                return True
            return False
        except ConfigError:
            return True

    def load(self) -> AnubisConfig:
        """Load configuration from file.

        Returns:
            AnubisConfig instance.

        Raises:
            ConfigError: If config file is missing or invalid.
        """
        if self._config is not None:
            return self._config

        if not self.config_file.exists():
            raise ConfigError(
                f"Configuration file not found: {self.config_file}\n"
                f"Run 'dd-apm config init' to create one."
            )

        try:
            with open(self.config_file) as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ConfigError(f"Invalid YAML in {self.config_file}: {e}")

        # Transform repositories dict to include name in each config
        repos_data = data.get("repositories", {})
        for name, repo_config in repos_data.items():
            if isinstance(repo_config, dict):
                repo_config["name"] = name

        # Set toolkit_root
        data["toolkit_root"] = self.toolkit_root

        try:
            self._config = AnubisConfig.model_validate(data)
        except Exception as e:
            raise ConfigError(f"Invalid configuration: {e}")

        return self._config

    def save(self, config: AnubisConfig) -> None:
        """Save configuration to file.

        Args:
            config: Configuration to save.
        """
        self.config_dir.mkdir(parents=True, exist_ok=True)

        # Convert to dict for YAML serialization
        data = self._config_to_dict(config)

        with open(self.config_file, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

        self._config = config

    def _config_to_dict(self, config: AnubisConfig) -> Dict[str, Any]:
        """Convert config to dict for YAML serialization."""
        data: Dict[str, Any] = {
            "default_repository": config.default_repository,
            "repositories": {},
        }

        # Repositories (without name field, it's the key)
        for name, repo in config.repositories.items():
            repo_dict: Dict[str, Any] = {
                "path": str(repo.path),
                "language": repo.language,
            }
            if repo.adapter != name:
                repo_dict["adapter"] = repo.adapter
            data["repositories"][name] = repo_dict

        # Env overrides (only if non-empty — absence means "use DEFAULT_ENV")
        if config.env:
            data["env"] = dict(config.env)

        # Workflows (only if non-empty)
        if config.workflows:
            data["workflows"] = config.workflows

        # Steps (only if non-empty)
        if config.steps:
            data["steps"] = {
                name: step.model_dump(exclude_none=True)
                for name, step in config.steps.items()
                if step.model or step.max_turns
            }

        # Resources (only if non-empty)
        if config.resources.prompts or config.resources.skills or config.resources.hooks:
            resources: Dict[str, Any] = {}
            if config.resources.prompts:
                resources["prompts"] = [str(p) for p in config.resources.prompts]
            if config.resources.skills:
                resources["skills"] = [str(p) for p in config.resources.skills]
            if config.resources.hooks:
                resources["hooks"] = [str(p) for p in config.resources.hooks]
            data["resources"] = resources

        return data

    def add_repository(
        self,
        name: str,
        path: Path,
        language: str = "node",
        adapter: str = "",
        set_default: bool = False,
    ) -> AnubisConfig:
        """Add a repository to configuration.

        Args:
            name: Repository identifier (e.g., dd_trace_js)
            path: Path to repository root
            language: Language (node, python, etc.)
            adapter: Adapter name (defaults to name)
            set_default: Whether to set as default repository

        Returns:
            Updated AnubisConfig
        """
        config = self.load() if self.exists() else self._create_empty_config()

        # Create repository config
        repo = RepositoryConfig(
            name=name,
            path=path,
            language=language,
            adapter=adapter or name,
        )

        # Validate path exists and is a git repo
        if not repo.path.exists():
            raise ConfigError(f"Repository path does not exist: {repo.path}")
        if not (repo.path / ".git").exists():
            raise ConfigError(f"Repository path is not a git repository: {repo.path}")

        # Add to config
        config.repositories[name] = repo

        # Set as default if requested or if first repository
        if set_default or not config.default_repository:
            config.default_repository = name

        self.save(config)
        return config

    def remove_repository(self, name: str) -> AnubisConfig:
        """Remove a repository from configuration.

        Args:
            name: Repository identifier to remove.

        Returns:
            Updated AnubisConfig.

        Raises:
            ConfigError: If repository not found.
        """
        config = self.load()

        if name not in config.repositories:
            raise ConfigError(f"Repository '{name}' not found in configuration.")

        del config.repositories[name]

        # Update default if removed
        if config.default_repository == name:
            if config.repositories:
                config.default_repository = next(iter(config.repositories.keys()))
            else:
                config.default_repository = ""

        self.save(config)
        return config

    def _create_empty_config(self) -> AnubisConfig:
        """Create empty config for first-time setup."""
        return AnubisConfig(
            toolkit_root=self.toolkit_root,
            default_repository="",
            repositories={},
        )

    def init_interactive(
        self,
        setup_callback: Callable[["ConfigLoader"], "AnubisConfig"] | None = None,
    ) -> AnubisConfig:
        """Interactive configuration setup.

        Guides user through first-time configuration.

        Args:
            setup_callback: Optional domain-specific setup function. When provided,
                it handles the full interactive flow (detection, cloning, selection)
                and returns the built AnubisConfig. When None, falls back to the
                generic auto-detect flow scanning toolkit_root/repos/.

        Returns:
            Created AnubisConfig.
        """
        print("\n=== Anubis Configuration Setup ===\n")

        if self.exists():
            print(f"Config file exists: {self.config_file}")
            response = input("Overwrite? [y/N]: ").strip().lower() if sys.stdin.isatty() else ""
            if response != "y":
                return self.load()

        if setup_callback is not None:
            config = setup_callback(self)
            self.save(config)
            print(f"\nConfiguration saved to: {self.config_file}")
            return config

        config = self._create_empty_config()

        detected_repos = self._detect_repos()

        if detected_repos:
            print("Detected repositories:")
            for path in detected_repos:
                name = path.name.replace("-", "_")
                language = self._detect_language(path)
                print(f"  \u2713 {name} ({language}) - {path}")

                repo = RepositoryConfig(name=name, path=path, language=language)
                config.repositories[name] = repo
                if not config.default_repository:
                    config.default_repository = name

            if len(config.repositories) > 1:
                repo_names = list(config.repositories.keys())
                print("\nSelect default repository:")
                for i, name in enumerate(repo_names, 1):
                    print(f"  {i}) {name}")
                choice = (
                    input(f"Default [{config.default_repository}]: ").strip()
                    if sys.stdin.isatty()
                    else ""
                )
                if choice:
                    try:
                        idx = int(choice) - 1
                        if 0 <= idx < len(repo_names):
                            config.default_repository = repo_names[idx]
                    except ValueError:
                        if choice in repo_names:
                            config.default_repository = choice
        else:
            print("No repositories detected.")
            print("\nRepository Configuration")
            print("-" * 40)

            path_str = input("Path to tracer repository: ").strip() if sys.stdin.isatty() else ""

            if not path_str:
                raise ConfigError("Repository path is required.")

            path = Path(path_str).expanduser().resolve()
            if not path.exists():
                raise ConfigError(f"Path does not exist: {path}")
            if not (path / ".git").exists():
                raise ConfigError(f"Not a git repository: {path}")

            name = path.name.replace("-", "_")
            language = self._detect_language(path)

            print(f"\nDetected: {name} ({language})")

            repo = RepositoryConfig(name=name, path=path, language=language)
            config.repositories[name] = repo
            config.default_repository = name

        self.save(config)
        print(f"\nConfiguration saved to: {self.config_file}")

        return config

    def _detect_repos(self) -> list[Path]:
        """Detect repositories in toolkit_root/repos/.

        Generic fallback: scans for any subdirectory with a .git directory.
        Domain-specific detection (e.g., scanning ~/dd/) is handled by the
        setup_callback passed to init_interactive().
        """
        repos = []
        repos_dir = self.toolkit_root / "repos"
        if repos_dir.exists():
            for child in sorted(repos_dir.iterdir()):
                if child.is_dir() and (child / ".git").exists():
                    repos.append(child)
        return repos

    def _detect_language(self, path: Path) -> str:
        """Detect language from repository."""
        name = path.name.lower()
        if "js" in name or (path / "package.json").exists():
            return "node"
        if "py" in name or (path / "setup.py").exists() or (path / "pyproject.toml").exists():
            return "python"
        if "java" in name or (path / "gradlew").exists() or (path / "pom.xml").exists():
            return "java"
        if "rb" in name or (path / "Gemfile").exists():
            return "ruby"
        if "go" in name or (path / "go.mod").exists():
            return "go"
        return "node"  # Default


# Global loader instance (lazy initialization)
_loader: Optional[ConfigLoader] = None


def get_loader() -> ConfigLoader:
    """Get the global config loader instance."""
    global _loader
    if _loader is None:
        _loader = ConfigLoader()
    return _loader


def get_config() -> AnubisConfig:
    """Get the current configuration.

    Convenience function for quick access.

    Returns:
        AnubisConfig instance.

    Raises:
        ConfigError: If config not found or invalid.
    """
    return get_loader().load()


def reset_loader() -> None:
    """Reset the global loader (for testing)."""
    global _loader
    _loader = None
