"""Unified configuration for anubis framework.

Configuration is loaded from .anubis/config.yaml.

Example usage::

    from anubis.core.config import get_config, ConfigLoader

    # Quick access to current config
    config = get_config()
    repo = config.get_repo()

    # Full loader control
    loader = ConfigLoader()
    if loader.needs_init():
        config = loader.init_interactive()
    else:
        config = loader.load()

Configuration file format (.anubis/config.yaml)::

    default_repository: dd_trace_js

    repositories:
      dd_trace_js:
        path: ~/repos/dd-trace-js
        language: node

    workflows:
      defaults:
        model: sonnet
        max_turns: 50

    resources:
      prompts: [~/.anubis/prompts]
      skills: [~/.anubis/skills]
"""

from .loader import (
    ConfigError,
    ConfigLoader,
    get_config,
    get_loader,
    reset_loader,
)
from .models import (
    AnubisConfig,
    RepositoryConfig,
    RepositoryNotConfiguredError,
    ResourcePaths,
    StepDefaults,
    WorkflowDefaults,
    WorkflowRuntimeConfig,
)

__all__ = [
    # Loader
    "ConfigError",
    "ConfigLoader",
    "get_config",
    "get_loader",
    "reset_loader",
    # Models
    "AnubisConfig",
    "RepositoryConfig",
    "RepositoryNotConfiguredError",
    "ResourcePaths",
    "StepDefaults",
    "WorkflowDefaults",
    "WorkflowRuntimeConfig",
]
