"""Configuration models for anubis framework.

Defines the configuration structure loaded from .anubis/config.yaml.
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class RepositoryNotConfiguredError(KeyError):
    """Raised when a requested repository is not in the configuration.

    Subclasses KeyError so existing ``except KeyError`` handlers still work.
    """

    def __init__(self, repo_name: str, available: list[str]) -> None:
        self.repo_name = repo_name
        self.available = available
        super().__init__(repo_name)

    def __str__(self) -> str:
        avail = ", ".join(self.available) if self.available else "none"
        hyphen_name = self.repo_name.replace("_", "-")
        return (
            f"Repository '{self.repo_name}' is not configured.\n"
            f"\n"
            f"  Available: {avail}\n"
            f"\n"
            f"  To add it:\n"
            f"    dd-apm config add-repo {self.repo_name} /path/to/{hyphen_name}\n"
            f"\n"
            f"  Or clone and configure:\n"
            f"    dd-apm config clone {self.repo_name}"
        )


class WorkflowRuntimeConfig(BaseModel):
    """Runtime configuration for workflow execution.

    This model consolidates all runtime parameters for workflows, making it
    easy to add new features without changing method signatures.

    Example::

        # Option 1: Pass config object directly
        config = WorkflowRuntimeConfig(
            namespace='kafkajs',
            headless=True,
        )
        workflow = MyWorkflow(runtime_config=config)

        # Option 2: Pass kwargs (converted to config internally)
        workflow = MyWorkflow(
            namespace='kafkajs',
            headless=True,
        )

    """

    # Required
    namespace: str = Field(
        description="Unique identifier for this workflow run (e.g., package name)"
    )

    # Execution settings (all have defaults)
    repository: str = Field(default="dd_trace_js", description="Target repository")
    base_branch: Optional[str] = Field(
        default=None, description="Base branch in target repo to create workflow branches from"
    )
    headless: bool = Field(default=False, description="Run without interactive prompts")
    model: Optional[str] = Field(default=None, description="Model override for agent steps")
    user_prompt: Optional[str] = Field(default=None, description="Custom user guidance")
    base_dir: Optional[Path] = Field(default=None, description="Base directory for analysis output")

    # Step configuration
    step_configs: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict, description="Per-step configuration overrides"
    )
    skip_steps: Set[str] = Field(default_factory=set, description="Steps to skip by name")
    from_step: Optional[str] = Field(
        default=None, description="Roll back and restart from this step"
    )
    stop_after: Optional[str] = Field(
        default=None, description="Stop workflow after this step completes"
    )
    rollback_git: bool = Field(
        default=False, description="Also reset git files to checkpoint when using from_step"
    )

    # Git branch management
    skip_git: bool = Field(
        default=False,
        description="Skip git branch/commit operations. Use for eval workflows that share "
        "a repo across concurrent threads — avoids index.lock contention.",
    )

    # Experience injection
    inject_experience: bool = Field(
        default=False,
        description="Inject raw experience from past runs into agent prompts (experimental)",
    )

    # Domain-specific (extensible)
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Domain-specific configuration (skip_review, skip_features, etc.)",
    )

    # Future features can be added here without signature changes

    @field_validator("base_dir", mode="before")
    @classmethod
    def expand_base_dir(cls, v: Any) -> Optional[Path]:
        """Expand ~ and resolve path."""
        if v is None:
            return None
        if isinstance(v, str):
            return Path(v).expanduser().resolve()
        return Path(v).resolve()

    @field_validator("skip_steps", mode="before")
    @classmethod
    def convert_skip_steps(cls, v: Any) -> Set[str]:
        """Convert list/tuple to set."""
        if v is None:
            return set()
        if isinstance(v, set):
            return v
        if isinstance(v, (list, tuple)):
            return set(v)
        return {v}


class RepositoryConfig(BaseModel):
    """Configuration for a single repository."""

    name: str = Field(description="Repository identifier (e.g., dd_trace_js)")
    path: Path = Field(description="Path to the repository root")
    language: str = Field(default="node", description="Language (node, python, etc.)")
    adapter: str = Field(default="", description="Adapter name (defaults to name)")

    @field_validator("path", mode="before")
    @classmethod
    def expand_path(cls, v: Any) -> Path:
        """Expand ~ and resolve path."""
        if isinstance(v, str):
            return Path(v).expanduser().resolve()
        return Path(v).resolve()

    @model_validator(mode="after")
    def set_adapter_default(self) -> "RepositoryConfig":
        """Set adapter to name if not specified."""
        if not self.adapter:
            self.adapter = self.name
        return self


class WorkflowDefaults(BaseModel):
    """Default settings for workflows."""

    model: str = Field(default="sonnet", description="Default model to use")
    max_turns: int = Field(default=50, description="Default max turns for agents")


class StepDefaults(BaseModel):
    """Default settings for a specific step."""

    model: Optional[str] = Field(default=None, description="Model override")
    max_turns: Optional[int] = Field(default=None, description="Max turns override")


class ResourcePaths(BaseModel):
    """Custom resource search paths."""

    prompts: List[Path] = Field(default_factory=list, description="Additional prompt directories")
    skills: List[Path] = Field(default_factory=list, description="Additional skill directories")
    hooks: List[Path] = Field(default_factory=list, description="Additional hook directories")

    @field_validator("prompts", "skills", "hooks", mode="before")
    @classmethod
    def expand_paths(cls, v: Any) -> List[Path]:
        """Expand ~ in paths."""
        if not v:
            return []
        paths = []
        for p in v:
            if isinstance(p, str):
                paths.append(Path(p).expanduser())
            else:
                paths.append(Path(p))
        return paths


class AnubisConfig(BaseModel):
    """Main configuration model for anubis.

    Loaded from .anubis/config.yaml in the toolkit root.

    Example config::

        default_repository: dd_trace_js

        repositories:
          dd_trace_js:
            path: ~/repos/dd-trace-js
            language: node
          dd_trace_py:
            path: ~/repos/dd-trace-py
            language: python

        workflows:
          defaults:
            model: sonnet
            max_turns: 50
          new_integration:
            model: opus

        steps:
          analyze:
            model: opus
            max_turns: 100

        resources:
          prompts: [~/.anubis/prompts]
          skills: [~/.anubis/skills]

    """

    env: Dict[str, str] = Field(
        default_factory=dict,
        description="Environment variables applied at startup (single source of truth for DD_* vars)",
    )

    # Renamed from `toolkit_root` to make the install-vs-user-data split explicit.
    # The legacy name is accepted as an input alias so existing dict construction
    # (e.g. loader.py setting data["toolkit_root"]) continues to work during the
    # deprecation window. Code should prefer `toolkit_user_root` or
    # `toolkit_install_root` based on which root it actually needs.
    toolkit_user_root: Path = Field(
        description="Path to user data dir (writable: .env, repos/, .analysis/, .anubis/)",
        alias="toolkit_root",
    )
    default_repository: str = Field(description="Default repository to use")
    repositories: Dict[str, RepositoryConfig] = Field(
        default_factory=dict, description="Repository configurations"
    )
    workflows: Dict[str, Dict[str, Any]] = Field(
        default_factory=dict, description="Workflow overrides"
    )
    steps: Dict[str, StepDefaults] = Field(default_factory=dict, description="Step overrides")
    resources: ResourcePaths = Field(
        default_factory=ResourcePaths, description="Custom resource paths"
    )

    model_config = ConfigDict(populate_by_name=True)

    @field_validator("toolkit_user_root", mode="before")
    @classmethod
    def expand_toolkit_user_root(cls, v: Any) -> Path:
        """Expand ~ and resolve path."""
        if isinstance(v, str):
            return Path(v).expanduser().resolve()
        return Path(v).resolve()

    @property
    def toolkit_root(self) -> Path:
        """DEPRECATED: use `toolkit_user_root` (or `toolkit_install_root` for bundled resources).

        Kept as a property for backward compatibility with existing call sites.
        Returns the user data dir.
        """
        return self.toolkit_user_root

    @property
    def toolkit_install_root(self) -> Path:
        """Path to install location holding bundled read-only resources.

        For frozen binaries (PyInstaller), bundled resources live in sys._MEIPASS,
        exposed via ANUBIS_RESOURCES_ROOT by the frozen entry point.
        For source/dev installs, this collapses to `toolkit_user_root`.

        Use this for prompts, skills, hooks, adapter scripts, etc. — anything
        that ships with the toolkit and should never be written to.
        """
        resources_root = os.environ.get("ANUBIS_RESOURCES_ROOT")
        if resources_root:
            return Path(resources_root)
        return self.toolkit_user_root

    def get_repo(self, name: Optional[str] = None) -> RepositoryConfig:
        """Get repository configuration.

        Args:
            name: Repository name. If None, uses default_repository.

        Returns:
            RepositoryConfig for the specified repository.

        Raises:
            KeyError: If repository not found.
        """
        repo_name = name or self.default_repository
        if repo_name not in self.repositories:
            raise RepositoryNotConfiguredError(repo_name, list(self.repositories.keys()))
        return self.repositories[repo_name]

    def get_workflow_config(self, workflow_name: str) -> Dict[str, Any]:
        """Get merged workflow configuration.

        Merges defaults with workflow-specific overrides.

        Args:
            workflow_name: Name of the workflow.

        Returns:
            Merged configuration dict.
        """
        defaults = self.workflows.get("defaults", {})
        overrides = self.workflows.get(workflow_name, {})
        return {**defaults, **overrides}

    def get_step_config(self, step_name: str) -> StepDefaults:
        """Get step configuration.

        Args:
            step_name: Name of the step.

        Returns:
            StepDefaults (may have None values if no overrides).
        """
        return self.steps.get(step_name, StepDefaults())

    def get_analysis_root(self, repository: Optional[str] = None) -> Path:
        """Get the analysis directory path for a specific repository."""
        repo = self.get_repo(repository)
        return repo.path / ".analysis"

    def get_repo_root(self, repository: Optional[str] = None) -> Path:
        """Get the repository root path."""
        return self.get_repo(repository).path

    def get_docker_compose(self, repository: Optional[str] = None) -> Path:
        """Get docker-compose.yml path for a repository."""
        return self.get_repo_root(repository) / "docker-compose.yml"

    @property
    def prompts_dir(self) -> Path:
        """Get APM prompts directory (bundled read-only resource)."""
        return self.toolkit_install_root / "anubis_apm" / "prompts"
