"""Docker utilities for workflows.

Generic Docker service management for starting/stopping services from docker-compose.yml.
"""

import logging
import subprocess
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

import yaml

logger = logging.getLogger(__name__)


def read_docker_compose_services(docker_compose_path: Path) -> Dict[str, Any]:
    """Read available services from a docker-compose.yml file.

    Args:
        docker_compose_path: Path to docker-compose.yml

    Returns:
        Dict mapping service_name -> {'image': str, 'ports': list}
    """
    if not docker_compose_path.exists():
        return {}

    try:
        with open(docker_compose_path) as f:
            compose_config = yaml.safe_load(f)

        services = compose_config.get("services", {})
        return {
            name: {"image": config.get("image", "unknown"), "ports": config.get("ports", [])}
            for name, config in services.items()
        }
    except Exception as e:
        # Failed to parse docker compose - log and return empty dict
        logger.warning(f"Failed to parse docker compose file at {docker_compose_path}: {e}")
        return {}


def check_missing_services(services: List[str], docker_compose_path: Path) -> List[str]:
    """Check which services are missing from docker-compose.yml.

    Args:
        services: List of service names to check
        docker_compose_path: Path to docker-compose.yml

    Returns:
        List of service names not found in docker-compose.yml
    """
    available = read_docker_compose_services(docker_compose_path)
    return [s for s in services if s not in available]


def get_container_env_var(container_name: str, var_name: str) -> Optional[str]:
    """Return the value of an environment variable set in a running container.

    Uses ``docker inspect`` so it works regardless of compose project scope.
    Returns ``None`` if the container is not running or the variable is not set.
    """
    try:
        result = subprocess.run(
            ["docker", "inspect", "-f", "{{range .Config.Env}}{{.}}\n{{end}}", container_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        prefix = f"{var_name}="
        for line in result.stdout.splitlines():
            if line.startswith(prefix):
                return line[len(prefix) :]
    except Exception as e:
        logger.debug("Failed to inspect container %s for %s: %s", container_name, var_name, e)
    return None


def is_docker_running() -> bool:
    """Check if Docker daemon is running."""
    try:
        result = subprocess.run(["docker", "info"], capture_output=True, text=True, timeout=10)
        return result.returncode == 0
    except Exception as e:
        logger.debug(f"Docker daemon check failed: {e}")
        return False


def _is_container_healthy(container_name: str) -> bool:
    """Check if a container is running AND healthy (or has no health check).

    Returns True if:
    - Container is running and health status is "healthy", OR
    - Container is running and has no health check configured
    """
    try:
        # Use Go template conditional to handle containers without health checks
        fmt = "{{.State.Running}}|{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}"
        result = subprocess.run(
            ["docker", "inspect", "-f", fmt, container_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return False
        output = result.stdout.strip()
        # Format: "true|healthy", "true|starting", or "true|none" (no healthcheck)
        parts = output.split("|", 1)
        if parts[0] != "true":
            return False
        health = parts[1] if len(parts) > 1 else "none"
        return health in ("healthy", "none")
    except Exception as e:
        logger.debug(f"Health check failed for {container_name}: {e}")
        return False


def _resolve_container_names(services: List[str], working_dir: Path) -> Dict[str, str]:
    """Map service names to their container_name from docker-compose.yml.

    First checks for explicit ``container_name`` in the compose file. For services
    without one, falls back to ``docker compose ps`` to get the actual container
    name (which Docker Compose generates as ``<project>-<service>-<number>``).

    Returns:
        Dict mapping service_name -> container_name.
    """
    name_map: Dict[str, str] = {}
    unresolved: List[str] = []

    # First pass: check compose file for explicit container_name
    docker_compose_path = working_dir / "docker-compose.yml"
    if docker_compose_path.exists():
        try:
            with open(docker_compose_path) as f:
                compose_config = yaml.safe_load(f)
            svc_configs = compose_config.get("services", {})
            for s in services:
                explicit_name = svc_configs.get(s, {}).get("container_name")
                if explicit_name:
                    name_map[s] = explicit_name
                else:
                    unresolved.append(s)
        except Exception as e:
            logger.warning(f"Failed to parse {docker_compose_path}: {e}")
            unresolved = list(services)
    else:
        unresolved = list(services)

    # Second pass: ask docker compose for actual container names
    if unresolved:
        try:
            result = subprocess.run(
                ["docker", "compose", "ps", "--format", "json"] + unresolved,
                capture_output=True,
                text=True,
                cwd=str(working_dir),
                timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                import json  # noqa: PLC0415

                for line in result.stdout.strip().splitlines():
                    entry = json.loads(line)
                    svc = entry.get("Service", "")
                    container = entry.get("Name", "")
                    if svc in unresolved and container:
                        name_map[svc] = container
                        unresolved.remove(svc)
        except Exception as e:
            logger.debug(f"docker compose ps fallback failed: {e}")

    # Final fallback: use service name as-is
    for s in unresolved:
        name_map[s] = s

    return name_map


def _get_service_host_ports(services: List[str], working_dir: Path) -> Dict[str, Set[str]]:
    """Extract host ports from docker-compose.yml for each service.

    Returns:
        Dict mapping service_name -> set of host port strings (e.g. {"19127", "18080"}).
    """
    result: Dict[str, Set[str]] = {}
    docker_compose_path = working_dir / "docker-compose.yml"
    if not docker_compose_path.exists():
        return result

    try:
        with open(docker_compose_path) as f:
            compose_config = yaml.safe_load(f)
        svc_configs = compose_config.get("services", {})
        for svc in services:
            ports_cfg = svc_configs.get(svc, {}).get("ports", [])
            host_ports: Set[str] = set()
            for port_entry in ports_cfg:
                # Formats: "18127:8126", "0.0.0.0:18127:8126", just "8126"
                parts = str(port_entry).split(":")
                if len(parts) >= 2:
                    # host port is second-to-last (or first if only host:container)
                    host_ports.add(parts[-2])
            result[svc] = host_ports
    except Exception as e:
        logger.debug("Failed to parse ports from docker-compose.yml: %s", e)

    return result


def _get_containers_on_port(host_port: str) -> List[str]:
    """Return the names of running containers bound to *host_port*.

    ``docker ps --filter publish=<port>`` can return multiple lines when
    several containers publish the same host port.  We split the output so
    each container name is handled individually by the caller.
    """
    try:
        result = subprocess.run(
            ["docker", "ps", "--filter", f"publish={host_port}", "--format", "{{.Names}}"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return []
        return [name for name in result.stdout.strip().splitlines() if name]
    except Exception as e:
        logger.debug("Failed to check port %s: %s", host_port, e)
        return []


def are_services_running(services: List[str], working_dir: Path) -> bool:
    """Check if all specified services are currently running.

    Checks by container name. Does **not** treat foreign containers on the
    same ports as a match — an incompatible container must be replaced, not
    silently reused.

    Args:
        services: List of service names to check
        working_dir: Directory containing docker-compose.yml

    Returns:
        True if all services are running (by expected container name)
    """
    if not services:
        return True

    name_map = _resolve_container_names(services, working_dir)
    return all(_is_container_healthy(name_map[s]) for s in services)


def _remove_stale_containers(
    services: List[str],
    working_dir: Path,
    on_info: Optional[Callable[[str], None]] = None,
) -> None:
    """Remove containers that would conflict with ``docker compose up``.

    Handles two cases:
    1. Stopped containers with the same ``container_name`` (from a previous run
       or different compose project).
    2. **Running** foreign containers that hold ports our services need. These are
       incompatible (different config/env) and must be stopped to avoid silent
       misconfiguration.
    """
    name_map = _resolve_container_names(services, working_dir)
    port_map = _get_service_host_ports(services, working_dir)

    # 1. Remove stopped containers with matching names
    for container_name in name_map.values():
        try:
            result = subprocess.run(
                ["docker", "inspect", "-f", "{{.State.Running}}", container_name],
                capture_output=True,
                text=True,
                timeout=10,
            )
            # Container exists but is not running — remove it
            if result.returncode == 0 and result.stdout.strip() != "true":
                logger.debug("Removing stale container: %s", container_name)
                subprocess.run(
                    ["docker", "rm", container_name],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
        except Exception as e:
            logger.debug("Failed to check/remove container %s: %s", container_name, e)

    # 2. Stop + remove foreign containers occupying our ports
    expected_names = set(name_map.values())
    for svc in services:
        for port in port_map.get(svc, set()):
            for occupant in _get_containers_on_port(port):
                if occupant not in expected_names:
                    msg = (
                        f"Stopping foreign container '{occupant}' on port {port} "
                        f"(incompatible with service '{svc}')"
                    )
                    logger.info(msg)
                    if on_info:
                        on_info(msg)
                    try:
                        subprocess.run(
                            ["docker", "stop", occupant],
                            capture_output=True,
                            text=True,
                            timeout=30,
                        )
                        subprocess.run(
                            ["docker", "rm", occupant],
                            capture_output=True,
                            text=True,
                            timeout=10,
                        )
                    except Exception as e:
                        logger.debug("Failed to stop/remove %s: %s", occupant, e)


def start_services(
    services: List[str],
    working_dir: Path,
    wait_seconds: int = 30,
    on_info: Optional[Callable[[str], None]] = None,
    on_error: Optional[Callable[[str], None]] = None,
    on_success: Optional[Callable[[str], None]] = None,
    on_warn: Optional[Callable[[str], None]] = None,
) -> bool:
    """Start Docker services and wait for them to be ready.

    Args:
        services: List of service names to start
        working_dir: Directory containing docker-compose.yml
        wait_seconds: Seconds to wait for services to be ready
        on_info: Callback for info messages
        on_error: Callback for error messages
        on_success: Callback for success messages
        on_warn: Callback for warning messages

    Returns:
        True if services started successfully
    """
    if not services:
        return True

    docker_compose_path = working_dir / "docker-compose.yml"

    # Check for missing services
    missing = check_missing_services(services, docker_compose_path)
    if missing:
        if on_warn:
            on_warn(f"Missing services in docker-compose.yml: {', '.join(missing)}")
        return False

    # Remove stopped containers and foreign containers occupying our ports
    _remove_stale_containers(services, working_dir, on_info=on_info)

    if on_info:
        on_info(f"Starting docker services: {', '.join(services)}")

    try:
        cmd = ["docker", "compose", "up", "-d"] + services
        result = subprocess.run(
            cmd, cwd=str(working_dir), capture_output=True, text=True, timeout=120
        )

        if result.returncode != 0:
            if on_error:
                on_error(f"Error starting docker services: {result.stderr}")
            return False

        if on_success:
            on_success("Docker services started")

        # Poll until all containers are healthy (up to wait_seconds)
        name_map = _resolve_container_names(services, working_dir)
        deadline = time.monotonic() + wait_seconds
        while time.monotonic() < deadline:
            if all(_is_container_healthy(name_map[s]) for s in services):
                return True
            time.sleep(2)

        # Timed out — check what's not ready
        not_ready = [s for s in services if not _is_container_healthy(name_map[s])]
        if not_ready and on_info:
            on_info(f"Services still initializing: {', '.join(not_ready)}")
        return True

    except subprocess.TimeoutExpired:
        if on_error:
            on_error("docker compose up timed out")
        return False
    except Exception as e:
        if on_error:
            on_error(f"Error starting docker services: {e}")
        return False


def restart_service(
    service: str,
    working_dir: Path,
    wait_seconds: int = 30,
    on_info: Optional[Callable[[str], None]] = None,
    on_error: Optional[Callable[[str], None]] = None,
    on_success: Optional[Callable[[str], None]] = None,
) -> bool:
    """Tear down and restart a single Docker Compose service.

    Removes the running container and brings it back up so env var changes
    (e.g. a freshly-injected DD_API_KEY) are picked up by the new container.

    Args:
        service: Compose service name to restart.
        working_dir: Directory containing docker-compose.yml.
        wait_seconds: Seconds to wait for the container to become healthy.
        on_info: Callback for info messages.
        on_error: Callback for error messages.
        on_success: Callback for success messages.

    Returns:
        True if the service restarted successfully.
    """
    if on_info:
        on_info(f"Restarting {service} with updated credentials...")

    # docker compose rm only removes containers it owns. If the container was
    # started outside compose (e.g. docker run), compose rm is a no-op and the
    # subsequent `up` hits a name conflict. Resolve the container_name from the
    # compose file and force-remove by name first so compose can recreate it.
    try:
        compose_file = working_dir / "docker-compose.yml"
        if compose_file.exists():
            import yaml as _yaml  # noqa: PLC0415

            compose_data = _yaml.safe_load(compose_file.read_text()) or {}
            container_name = compose_data.get("services", {}).get(service, {}).get("container_name")
            if container_name:
                subprocess.run(
                    ["docker", "rm", "-f", container_name],
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
    except Exception as e:
        logger.debug("Could not force-remove container for %s: %s", service, e)

    try:
        subprocess.run(
            ["docker", "compose", "rm", "-sf", service],
            cwd=str(working_dir),
            capture_output=True,
            text=True,
            timeout=30,
        )
    except Exception as e:
        logger.debug("Failed to remove %s: %s", service, e)

    return start_services(
        [service],
        working_dir,
        wait_seconds=wait_seconds,
        on_info=on_info,
        on_error=on_error,
        on_success=on_success,
    )


def stop_services(services: List[str], working_dir: Path) -> None:
    """Stop Docker services.

    Args:
        services: List of service names to stop
        working_dir: Directory containing docker-compose.yml
    """
    if not services:
        return

    logger.info("Stopping docker services: %s", ", ".join(services))

    try:
        cmd = ["docker", "compose", "stop"] + services
        subprocess.run(cmd, cwd=str(working_dir), capture_output=True, text=True, timeout=30)
        logger.info("Docker services stopped")
    except Exception as e:
        logger.warning("Failed to stop docker services: %s", e)


def ensure_services_running(
    services: List[str],
    working_dir: Path,
    wait_seconds: int = 30,
    on_info: Optional[Callable[[str], None]] = None,
    on_error: Optional[Callable[[str], None]] = None,
    on_success: Optional[Callable[[str], None]] = None,
    on_warn: Optional[Callable[[str], None]] = None,
) -> bool:
    """Ensure Docker services are running, starting them if needed.

    This is the main function to use - it checks if Docker is running,
    then checks if services are already running, and starts them if necessary.

    Args:
        services: List of service names required
        working_dir: Directory containing docker-compose.yml
        wait_seconds: Seconds to wait for services to be ready (if starting)
        on_info: Callback for info messages
        on_error: Callback for error messages
        on_success: Callback for success messages
        on_warn: Callback for warning messages

    Returns:
        True if services are running (either already were or successfully started)
    """
    if not services:
        return True

    # Check Docker daemon is running
    if not is_docker_running():
        if on_error:
            on_error("Docker is not running. Please start Docker first.")
        return False

    # Check if services are already running
    if are_services_running(services, working_dir):
        if on_success:
            on_success(f"Docker services already running: {', '.join(services)}")
        return True

    # Start services
    return start_services(
        services,
        working_dir,
        wait_seconds,
        on_info=on_info,
        on_error=on_error,
        on_success=on_success,
        on_warn=on_warn,
    )
