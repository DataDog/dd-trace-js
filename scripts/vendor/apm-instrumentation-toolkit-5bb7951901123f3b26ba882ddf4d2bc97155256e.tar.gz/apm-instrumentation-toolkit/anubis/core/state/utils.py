"""State configuration utilities.

Provides configurable state root and name normalization for workflow state.
The actual state models are in models.py, and git-based checkpointing is in git.py.
"""

import re
from pathlib import Path
from typing import Callable, Optional

# Configurable state root - set by application
_state_root: Optional[Path] = None
_name_normalizer: Optional[Callable[[str], str]] = None


def set_state_root(path: Path) -> None:
    """Set the root directory for state files."""
    global _state_root
    _state_root = path


def get_state_root() -> Path:
    """Get the state root, defaulting to .analysis/ in cwd."""
    if _state_root:
        return _state_root
    return Path.cwd() / ".analysis"


def set_name_normalizer(normalizer: Callable[[str], str]) -> None:
    """Set the function used to normalize namespace names."""
    global _name_normalizer
    _name_normalizer = normalizer


def normalize_name(name: str) -> str:
    """Normalize a name using the configured normalizer or default.

    Default: @scope/pkg -> scope-pkg
    """
    if _name_normalizer:
        return _name_normalizer(name)
    return re.sub(r"[@/_]", "-", name).strip("-")


def safe_relative_path(path: Path, base: Optional[Path] = None) -> str:
    """Get path relative to base, falling back to absolute if not in subpath.

    Args:
        path: The path to make relative
        base: Base path (defaults to cwd)

    Returns:
        Relative path string, or absolute path if not under base
    """
    base = base or Path.cwd()
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)
