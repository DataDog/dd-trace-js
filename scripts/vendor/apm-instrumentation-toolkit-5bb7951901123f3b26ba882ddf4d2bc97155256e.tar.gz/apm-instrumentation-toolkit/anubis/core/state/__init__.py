"""State management for workflows.

Main classes:
- WorkflowState: Pydantic model for workflow state with checkpointing
- StepState: Pydantic model for step state
- GitState: Git-based checkpointing for file recovery

Utilities:
- set_state_root/get_state_root: Configure state file location
- set_name_normalizer/normalize_name: Configure namespace normalization
"""

from .git import GitState
from .models import (
    AgentRun,
    StepMetrics,
    StepState,
    WorkflowState,
)
from .utils import (
    get_state_root,
    normalize_name,
    safe_relative_path,
    set_name_normalizer,
    set_state_root,
)

__all__ = [
    # Pydantic models
    "AgentRun",
    "StepMetrics",
    "StepState",
    "WorkflowState",
    # Git-based checkpointing
    "GitState",
    # Configuration utilities
    "set_state_root",
    "get_state_root",
    "set_name_normalizer",
    "normalize_name",
    "safe_relative_path",
]
