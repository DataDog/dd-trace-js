"""State models - Pydantic data structures for step and workflow state.

Directory structure::

    .analysis/{namespace}/{workflow}/
    ├── state.json           # WorkflowState
    ├── input.json           # Workflow input
    ├── output.json          # Workflow output
    ├── artifacts/           # Named artifacts
    └── steps/
        ├── {step}-{attempt}/                     # Regular steps (e.g., analyze-1/)
        │   ├── input.json
        │   ├── output.json
        │   └── logs/
        └── {step}:att{N}:iter{M}:{stage}/        # Composite stages (e.g., test:att1:iter10:fixer/)
            ├── input.json
            ├── output.json
            └── logs/
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

from .git import GitState

logger = logging.getLogger(__name__)

# =============================================================================
# Step State - runtime state for a single step execution
# =============================================================================


class AgentRun(BaseModel):
    """Metrics from a single agent invocation."""

    task: str = ""
    model: str = ""
    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    num_turns: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    is_error: bool = False


class StepMetrics(BaseModel):
    """Aggregated metrics for a step."""

    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    num_turns: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    agent_runs: List[AgentRun] = Field(default_factory=list)

    def add_agent_run(self, run: AgentRun):
        """Add an agent run and update totals."""
        self.agent_runs.append(run)
        self.cost_usd += run.cost_usd
        self.duration_seconds += run.duration_seconds
        self.num_turns += run.num_turns
        self.input_tokens += run.input_tokens
        self.output_tokens += run.output_tokens
        self.cache_read_input_tokens += run.cache_read_input_tokens


class StepState(BaseModel):
    """Runtime state for a step execution.

    Attached to Step instances to track execution state, metrics, and output.
    When status == 'completed', this serves as the checkpoint for the step.
    """

    name: str
    status: Literal["pending", "running", "completed", "failed", "skipped"] = "pending"
    attempt: int = 1

    # Timing
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    # Data
    input: Any = None
    output: Any = None
    error: Optional[str] = None

    # Metrics
    metrics: StepMetrics = Field(default_factory=StepMetrics)

    # Git tracking
    git_commit: Optional[str] = None
    git_tag: Optional[str] = None
    files_changed: List[str] = Field(default_factory=list)

    # Location info
    workflow: Optional[str] = None
    parent_step: Optional[str] = None
    log_dir: Optional[str] = None

    @property
    def duration_seconds(self) -> Optional[float]:
        """Calculate duration from timestamps."""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    def start(self):
        """Mark step as running."""
        self.status = "running"
        self.started_at = datetime.now(timezone.utc)

    def complete(self, output: Any = None):
        """Mark step as completed."""
        self.status = "completed"
        self.completed_at = datetime.now(timezone.utc)
        if output is not None:
            self.output = output

    def fail(self, error: str):
        """Mark step as failed."""
        self.status = "failed"
        self.completed_at = datetime.now(timezone.utc)
        self.error = error

    def skip(self):
        """Mark step as skipped."""
        self.status = "skipped"


# =============================================================================
# Workflow State - all steps in a workflow run
# =============================================================================


class WorkflowState(BaseModel):
    """Complete state for a workflow run.

    Tracks all steps and their states. Completed steps (status == 'completed')
    serve as checkpoints with their output preserved.
    """

    workflow: str
    namespace: str
    status: Literal["pending", "running", "completed", "failed"] = "pending"

    # Stable identifier for this run instance — generated once, preserved across resume.
    # Format: "20260401-143022-a3f2b1" (timestamp + 6-char random suffix).
    # Used as the S3 key component and gen/ branch suffix.
    run_id: str = Field(
        default_factory=lambda: (
            datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + uuid4().hex[:6]
        )
    )

    # Timing
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = None

    # Step tracking - steps dict IS the checkpoint storage
    current_step: Optional[str] = None
    steps: Dict[str, StepState] = Field(default_factory=dict)

    # KV store - persisted data for ctx.set/get (survives resume)
    data: Dict[str, Any] = Field(default_factory=dict)

    # Artifacts - name -> relative path for debugging/inspection
    artifacts: Dict[str, str] = Field(default_factory=dict)

    # Workflow-level options (for resume)
    options: Dict[str, Any] = Field(default_factory=dict)

    # User guidance (persisted so it's remembered on resume)
    user_prompt: Optional[str] = None

    # Base branch (persisted so it's remembered on resume)
    base_branch: Optional[str] = None

    # Active branch in the target repo (set after ensure_branch())
    current_branch: Optional[str] = None

    # PR tracking (populated when open_pr step completes)
    pr_url: Optional[str] = None
    pr_number: Optional[int] = None

    # Observability — written once at workflow start, preserved on resume
    apm_trace_id: Optional[str] = None
    llmobs_trace_id: Optional[str] = None

    # Aggregated metrics
    total_cost_usd: float = 0.0
    total_duration_seconds: float = 0.0
    total_turns: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cache_read_input_tokens: int = 0

    # Nesting
    parent_workflow: Optional[str] = None

    # Git tracking for commit squashing
    workflow_start_commit: Optional[str] = None

    def get_step(self, name: str) -> StepState:
        """Get or create step state."""
        if name not in self.steps:
            self.steps[name] = StepState(name=name, workflow=self.workflow)
        return self.steps[name]

    def is_completed(self, step: str) -> bool:
        """Check if a step has completed (is checkpointed)."""
        return step in self.steps and self.steps[step].status == "completed"

    def get_output(self, step: str) -> Optional[Any]:
        """Get output from a completed step."""
        if step in self.steps:
            return self.steps[step].output
        return None

    def get_completed_steps(self) -> List[str]:
        """Get names of all completed steps."""
        return [name for name, state in self.steps.items() if state.status == "completed"]

    def update_totals(self):
        """Recalculate total metrics from all steps."""
        self.total_cost_usd = sum(s.metrics.cost_usd for s in self.steps.values())
        self.total_duration_seconds = sum(s.metrics.duration_seconds for s in self.steps.values())
        self.total_turns = sum(s.metrics.num_turns for s in self.steps.values())
        self.total_input_tokens = sum(s.metrics.input_tokens for s in self.steps.values())
        self.total_output_tokens = sum(s.metrics.output_tokens for s in self.steps.values())
        self.total_cache_read_input_tokens = sum(
            s.metrics.cache_read_input_tokens for s in self.steps.values()
        )
        self.updated_at = datetime.now(timezone.utc)

    def start(self):
        """Mark workflow as running."""
        self.status = "running"
        self.started_at = datetime.now(timezone.utc)

    def complete(self):
        """Mark workflow as completed."""
        self.status = "completed"
        self.completed_at = datetime.now(timezone.utc)
        self.update_totals()

    def fail(self):
        """Mark workflow as failed."""
        self.status = "failed"
        self.completed_at = datetime.now(timezone.utc)
        self.update_totals()

    def clear(self):
        """Clear all checkpoints and reset state."""
        self.steps.clear()
        self.data.clear()
        self.artifacts.clear()
        self.current_step = None
        self.status = "pending"
        self.completed_at = None
        self.total_cost_usd = 0.0
        self.total_duration_seconds = 0.0
        self.total_turns = 0
        self.pr_url = None
        self.pr_number = None
        self.updated_at = datetime.now(timezone.utc)

    # =========================================================================
    # Paths - computed from namespace/workflow
    # =========================================================================

    def root(self, base: Optional[Path] = None) -> Path:
        """Workflow root: .analysis/{namespace}/{workflow}/"""
        base = base or Path.cwd()
        return base / ".analysis" / self.namespace / self.workflow

    def state_file(self, base: Optional[Path] = None) -> Path:
        """State file path."""
        return self.root(base) / "state.json"

    def input_file(self, base: Optional[Path] = None) -> Path:
        """Workflow input file."""
        return self.root(base) / "input.json"

    def output_file(self, base: Optional[Path] = None) -> Path:
        """Workflow output file."""
        return self.root(base) / "output.json"

    def artifacts_dir(self, base: Optional[Path] = None) -> Path:
        """Artifacts directory."""
        return self.root(base) / "artifacts"

    def artifact_path(self, name: str, base: Optional[Path] = None) -> Path:
        """Path for a named artifact."""
        return self.artifacts_dir(base) / name

    def step_dir(self, step: str, attempt: int, base: Optional[Path] = None) -> Path:
        """Step directory.

        For regular steps: ``steps/{step}-{attempt}/``

        For composite stage keys (e.g., ``test:att1:iter10:fixer``):
        ``steps/{step}/`` (key already contains parent attempt, iteration, and stage)
        """
        # Composite stage key: test:att{N}:iter{M}:{stage} - already fully qualified
        if ":att" in step and ":iter" in step:
            return self.root(base) / "steps" / step
        return self.root(base) / "steps" / f"{step}-{attempt}"

    def step_input(self, step: str, attempt: int, base: Optional[Path] = None) -> Path:
        """Step input file."""
        return self.step_dir(step, attempt, base) / "input.json"

    def step_output(self, step: str, attempt: int, base: Optional[Path] = None) -> Path:
        """Step output file."""
        return self.step_dir(step, attempt, base) / "output.json"

    def step_logs(self, step: str, attempt: int, base: Optional[Path] = None) -> Path:
        """Step logs directory."""
        return self.step_dir(step, attempt, base) / "logs"

    def substep_dir(
        self,
        step: str,
        step_attempt: int,
        substep: str,
        sub_attempt: int,
        base: Optional[Path] = None,
    ) -> Path:
        """Substep directory: steps/{step}-{i}/{substep}-{j}/"""
        return self.step_dir(step, step_attempt, base) / f"{substep}-{sub_attempt}"

    def get_next_attempt(self, step: str, base: Optional[Path] = None) -> int:
        """Get next attempt number for a step.

        For regular steps only. Composite stage keys already encode iteration
        in the key name (test:att1:iter10:fixer) and don't need attempt suffixes.

        If the step has checkpointed stages (composite step in progress) but
        isn't marked complete, returns the current attempt to allow resumption.
        """
        steps_dir = self.root(base) / "steps"
        if not steps_dir.exists():
            return 1

        # Regular steps use -{attempt} suffix
        existing = [d for d in steps_dir.iterdir() if d.is_dir() and d.name.startswith(f"{step}-")]
        if not existing:
            return 1
        nums = []
        for d in existing:
            try:
                nums.append(int(d.name.split("-")[-1]))
            except (IndexError, ValueError):
                continue

        current_max = max(nums, default=0)

        # Check if the step has incomplete progress (stage checkpoints exist but step not complete)
        # This allows CompositeSteps to resume from where they left off
        if not self.is_completed(step):
            # Look for stage checkpoints from the current attempt
            stage_prefix = f"{step}:att{current_max}:"
            has_stage_checkpoints = any(k.startswith(stage_prefix) for k in self.steps.keys())
            if has_stage_checkpoints:
                # Reuse current attempt to match existing stage checkpoints
                return current_max

        return current_max + 1

    def relative(self, path: Path, base: Optional[Path] = None) -> str:
        """Get path relative to base, falling back to absolute if not in subpath."""
        base = base or Path.cwd()
        try:
            return str(path.relative_to(base))
        except ValueError:
            return str(path)

    # =========================================================================
    # Options - for resume
    # =========================================================================

    def save_options(self, new_options: Dict[str, Any]) -> None:
        """Save options for resume."""
        self.options = new_options

    def get_options(self) -> Dict[str, Any]:
        """Get saved options."""
        return self.options

    def get_option(self, key: str, default: Any = None) -> Any:
        """Get a single option value."""
        return self.options.get(key, default)

    # =========================================================================
    # Checkpointing
    # =========================================================================

    def checkpoint(
        self,
        step: str,
        output: Any,
        metrics: Optional[Dict[str, Any]] = None,
        attempt: int = 1,
        parent_step: Optional[str] = None,
        log_dir: Optional[str] = None,
        repo_path: Optional[Path] = None,
    ) -> None:
        """Create checkpoint for a completed step.

        Args:
            step: Step name
            output: Step output (will be serialized)
            metrics: Optional metrics dict (deprecated - use step state metrics)
            attempt: Attempt number (deprecated - use step state attempt)
            parent_step: Parent step name if this is a substage
            log_dir: Relative path to step logs
            repo_path: If provided, also creates a git commit for this checkpoint
        """
        step_state = self.get_step(step)
        step_state.status = "completed"
        step_state.completed_at = datetime.now(timezone.utc)
        step_state.attempt = attempt
        step_state.parent_step = parent_step
        step_state.log_dir = log_dir

        # Serialize Pydantic models to dict for storage
        if isinstance(output, BaseModel):
            step_state.output = output.model_dump()
        else:
            step_state.output = output

        # Extract files changed from output if available
        step_state.files_changed = self._extract_files_changed(output, step_state.output)

        # Capture PR info when open_pr step completes
        if isinstance(step_state.output, dict):
            if step_state.output.get("pr_url"):
                self.pr_url = step_state.output["pr_url"]
            if step_state.output.get("pr_number"):
                self.pr_number = step_state.output["pr_number"]

        self.current_step = step
        self.updated_at = datetime.now(timezone.utc)

        # Create git commit if repo_path provided (gracefully handle non-git dirs)
        if repo_path:
            try:
                self.commit_step(step, repo_path=repo_path)
            except Exception as e:
                # Best effort git operation - expected to fail in non-git directories or
                # under concurrent access (index.lock contention). Not actionable.
                logger.debug(f"Failed to create git commit for step '{step}': {e}")

    def git_checkpoint(
        self,
        step: str,
        commit_hash: str,
        files_changed: List[str],
        tag: Optional[str] = None,
    ) -> None:
        """Add git commit info to an existing step checkpoint.

        Call this after checkpoint() when files were modified and committed.
        """
        if step not in self.steps:
            return

        step_state = self.steps[step]
        step_state.git_commit = commit_hash
        step_state.git_tag = tag
        step_state.files_changed = files_changed

    def rollback(self, step: str, base_dir: Optional[Path] = None) -> None:
        """Rollback state to before a step (removes step and all after it).

        Also clears any stage checkpoints for composite steps (format: step:iter:stage).
        If base_dir is provided, also clears nested workflow states for the rolled-back step.

        Supports nested workflow steps with format: parent_step.nested_step
        e.g., "analyze.metadata_enrichment" to rollback within the analyze workflow.

        Raises:
            ValueError: If step is not found in this workflow or any nested workflow.
        """
        step_names = list(self.steps.keys())

        # Check for nested step format (parent.nested)
        if "." in step and base_dir:
            parent_step, nested_step = step.split(".", 1)
            # Find the parent step and rollback within its nested workflow
            if parent_step in step_names or any(
                k.startswith(f"{parent_step}:") for k in step_names
            ):
                nested_state_path = (
                    base_dir / ".analysis" / self.namespace / parent_step / "state.json"
                )
                if nested_state_path.exists():
                    nested_state = WorkflowState.model_validate_json(nested_state_path.read_text())
                    nested_state.rollback(nested_step, base_dir)
                    nested_state_path.write_text(nested_state.model_dump_json(indent=2))

                    # Also rollback parent step and all subsequent steps in main workflow
                    if parent_step in step_names:
                        idx = step_names.index(parent_step)
                        steps_to_rollback = step_names[idx:]

                        for s in steps_to_rollback:
                            del self.steps[s]

                        # Clear nested workflow states for rolled-back steps
                        for s in steps_to_rollback:
                            base_step = s.rsplit("_", 1)[0] if s.rsplit("_", 1)[-1].isdigit() else s
                            if (
                                base_step != parent_step
                            ):  # Don't delete the nested state we just modified
                                nested_path = (
                                    base_dir
                                    / ".analysis"
                                    / self.namespace
                                    / base_step
                                    / "state.json"
                                )
                                if nested_path.exists():
                                    nested_path.unlink()

                        if idx > 0:
                            self.current_step = step_names[idx - 1]
                        else:
                            self.current_step = None

                    self.pr_url = None
                    self.pr_number = None
                    for remaining in self.steps.values():
                        output = remaining.output
                        if isinstance(output, dict):
                            if output.get("pr_url"):
                                self.pr_url = output["pr_url"]
                            if output.get("pr_number"):
                                self.pr_number = output["pr_number"]

                    self.updated_at = datetime.now(timezone.utc)
                    return
                else:
                    raise ValueError(f"Nested workflow state not found for '{parent_step}'")
            else:
                raise ValueError(
                    f"Parent step '{parent_step}' not found. Available steps: {', '.join(step_names)}"
                )

        # Always clear nested workflow state for the target step (even if not checkpointed yet)
        if base_dir:
            base_step = step.rsplit("_", 1)[0] if step.rsplit("_", 1)[-1].isdigit() else step
            nested_state_path = base_dir / ".analysis" / self.namespace / base_step / "state.json"
            if nested_state_path.exists():
                nested_state_path.unlink()

        if step not in step_names:
            # Step not found directly - check for stage checkpoint prefix
            stage_keys = [k for k in step_names if k.startswith(f"{step}:")]
            if stage_keys:
                for k in stage_keys:
                    del self.steps[k]
                self.updated_at = datetime.now(timezone.utc)
                return

            # Check if step exists in any nested workflow and collect all nested steps
            nested_steps_info: List[str] = []
            if base_dir:
                for parent in step_names:
                    base_parent = (
                        parent.rsplit("_", 1)[0] if parent.rsplit("_", 1)[-1].isdigit() else parent
                    )
                    nested_state_path = (
                        base_dir / ".analysis" / self.namespace / base_parent / "state.json"
                    )
                    if nested_state_path.exists():
                        try:
                            nested_state = WorkflowState.model_validate_json(
                                nested_state_path.read_text()
                            )
                            if step in nested_state.steps:
                                raise ValueError(
                                    f"Step '{step}' is in nested workflow '{base_parent}'. "
                                    f"Use '{base_parent}.{step}' to rollback within the nested workflow."
                                )
                            # Collect nested steps for error message
                            for ns in nested_state.steps.keys():
                                nested_steps_info.append(f"{base_parent}.{ns}")
                        except ValueError:
                            raise  # Re-raise the "step is in nested workflow" error
                        except Exception as e:
                            # Nested state file exists but can't be parsed - continue checking other states
                            logger.warning(
                                f"Failed to parse nested workflow state at {nested_state_path}: {e}"
                            )

            # Build error message with nested steps
            all_steps = list(step_names)
            if nested_steps_info:
                all_steps.extend(nested_steps_info)
            raise ValueError(f"Step '{step}' not found. Available steps: {', '.join(all_steps)}")

        idx = step_names.index(step)

        # Collect steps being rolled back (for nested workflow cleanup)
        steps_to_rollback = step_names[idx:]

        for s in steps_to_rollback:
            del self.steps[s]

        # Also clear any stage checkpoints for the rolled-back step
        stage_keys = [k for k in self.steps.keys() if k.startswith(f"{step}:")]
        for k in stage_keys:
            del self.steps[k]

        # Clear nested workflow states for rolled-back steps
        if base_dir:
            for s in steps_to_rollback:
                # Strip unique suffix (_2, _3) to get base step name
                base_step = s.rsplit("_", 1)[0] if s.rsplit("_", 1)[-1].isdigit() else s
                nested_state_path = (
                    base_dir / ".analysis" / self.namespace / base_step / "state.json"
                )
                if nested_state_path.exists():
                    nested_state_path.unlink()

        # Recompute PR fields from remaining step outputs so rolled-back steps
        # don't leave stale pr_url/pr_number pointing at a now-removed checkpoint.
        self.pr_url = None
        self.pr_number = None
        for remaining in self.steps.values():
            output = remaining.output
            if isinstance(output, dict):
                if output.get("pr_url"):
                    self.pr_url = output["pr_url"]
                if output.get("pr_number"):
                    self.pr_number = output["pr_number"]

        if idx > 0:
            self.current_step = step_names[idx - 1]
        else:
            self.current_step = None
        self.updated_at = datetime.now(timezone.utc)

    def get_all_checkpoints(self) -> Dict[str, StepState]:
        """Get all step states (checkpoints) for display/CLI."""
        return dict(self.steps)

    def _extract_files_changed(self, output: Any, serialized: Any) -> List[str]:
        """Extract files_changed from step output if available."""
        files = []
        if isinstance(serialized, dict):
            files.extend(serialized.get("files_created", []))
            files.extend(serialized.get("files_modified", []))
        if hasattr(output, "files_created") and output.files_created:
            files.extend(output.files_created)
        if hasattr(output, "files_modified") and output.files_modified:
            files.extend(output.files_modified)

        # Deduplicate while preserving order
        seen = set()
        unique_files = []
        for f in files:
            if f not in seen:
                seen.add(f)
                unique_files.append(f)
        return unique_files

    # =========================================================================
    # Metrics management
    # =========================================================================

    def get_metrics(self) -> Dict[str, Any]:
        """Get aggregated metrics from all steps."""
        agent_runs = []
        for step_state in self.steps.values():
            for run in step_state.metrics.agent_runs:
                agent_runs.append(run.model_dump())
        return {
            "total_cost_usd": self.total_cost_usd,
            "total_duration_seconds": self.total_duration_seconds,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_cache_read_input_tokens": self.total_cache_read_input_tokens,
            "agent_runs": agent_runs,
        }

    def add_metrics(self, metrics: Dict[str, Any]) -> None:
        """Add metrics from nested workflow."""
        self.total_cost_usd += metrics.get("total_cost_usd", 0)
        self.total_duration_seconds += metrics.get("total_duration_seconds", 0)
        self.total_input_tokens += metrics.get("total_input_tokens", 0)
        self.total_output_tokens += metrics.get("total_output_tokens", 0)
        self.total_cache_read_input_tokens += metrics.get("total_cache_read_input_tokens", 0)

    def clear_metrics(self) -> None:
        """Clear all metrics."""
        self.total_cost_usd = 0.0
        self.total_duration_seconds = 0.0
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_cache_read_input_tokens = 0
        for step_state in self.steps.values():
            step_state.metrics = StepMetrics()

    # =========================================================================
    # Persistence
    # =========================================================================

    def save(self, base: Optional[Path] = None) -> None:
        """Save state to disk.

        Filters out non-serializable values from data dict before saving.
        """
        # Filter non-serializable values from data
        # Keys starting with _ are considered internal and excluded from disk,
        # EXCEPT _loaded_content_paths which must persist for config hashing.
        _PERSIST_UNDERSCORE_KEYS = {"_loaded_content_paths"}
        clean_data = {}
        for key, value in self.data.items():
            if key.startswith("_") and key not in _PERSIST_UNDERSCORE_KEYS:
                continue
            try:
                # Test without default=str to catch non-serializable objects
                json.dumps(value)
                clean_data[key] = value
            except (TypeError, ValueError):
                # Skip non-serializable values (functools.partial, complex objects, etc.)
                pass

        # Temporarily swap data for serialization
        original_data = self.data
        self.data = clean_data

        try:
            state_file = self.state_file(base)
            state_file.parent.mkdir(parents=True, exist_ok=True)
            state_file.write_text(self.model_dump_json(indent=2))
        finally:
            # Restore original data
            self.data = original_data

    @classmethod
    def load(
        cls, workflow: str, namespace: str, base: Optional[Path] = None
    ) -> Optional["WorkflowState"]:
        """Load state from disk if it exists."""
        base = base or Path.cwd()
        state_file = base / ".analysis" / namespace / workflow / "state.json"
        if not state_file.exists():
            return None
        try:
            data = json.loads(state_file.read_text())
            return cls.model_validate(data)
        except Exception as e:
            # State file exists but can't be parsed - treat as non-existent
            logger.warning(f"Failed to load workflow state from {state_file}: {e}")
            return None

    def ensure_dirs(self, base: Optional[Path] = None) -> None:
        """Ensure workflow directories exist."""
        self.root(base).mkdir(parents=True, exist_ok=True)
        self.artifacts_dir(base).mkdir(parents=True, exist_ok=True)

    def mark_workflow_start(self, repo_path: Optional[Path] = None) -> None:
        """Mark the current commit as the workflow start point for squashing.

        Call this after ensure_branch() to capture the starting commit before
        any workflow steps make changes. Saves to state for resume support.

        Args:
            repo_path: Path to git repo (default: cwd)
        """
        try:
            git = GitState(
                self.workflow,
                self.namespace,
                repo_path=repo_path,
                base_branch=self.base_branch,
            )
            # Only mark if not already set (preserve on resume)
            if not self.workflow_start_commit:
                commit = git.mark_workflow_start()
                if commit:
                    self.workflow_start_commit = commit
        except Exception as e:
            # Best effort git operation - expected to fail in non-git directories (e.g., tests)
            logger.debug(f"Failed to mark workflow start commit: {e}")

    # =========================================================================
    # Git Integration
    # =========================================================================

    def commit_step(
        self, step: str, repo_path: Optional[Path] = None, message: Optional[str] = None
    ) -> Optional[str]:
        """Commit changes for a step and record git info.

        Args:
            step: Step name (must already have a checkpoint)
            repo_path: Path to git repo (default: cwd)
            message: Optional commit message

        Returns:
            Commit hash if changes were committed, None otherwise
        """
        git = GitState(
            self.workflow,
            self.namespace,
            repo_path=repo_path,
            base_branch=self.base_branch,
        )

        git.checkpoint(step, message)
        commit_hash = git.get_commit(step)

        if commit_hash:
            files_changed = git.get_files_changed(step)
            self.git_checkpoint(
                step=step,
                commit_hash=commit_hash,
                files_changed=files_changed,
                tag=f"{git.tag_prefix}/{step}",
            )

        return commit_hash

    def rollback_files(self, step: str, repo_path: Optional[Path] = None) -> bool:
        """Roll back git files to before a step.

        Args:
            step: Step to roll back (removes this step and all after)
            repo_path: Path to git repo (default: cwd)

        Returns:
            True if rollback succeeded, False otherwise
        """
        try:
            git = GitState(
                self.workflow,
                self.namespace,
                repo_path=repo_path,
                base_branch=self.base_branch,
            )
            return git.rollback(step)
        except Exception as e:
            logger.error(f"Failed to rollback git files for step '{step}': {e}")
            return False

    def squash_commits(
        self, message: str, repo_path: Optional[Path] = None, base_branch: str = "main"
    ) -> bool:
        """Squash all workflow commits into a single signed commit.

        Call this at workflow completion after human approval to create a clean,
        signed commit ready for PR.

        Args:
            message: Final commit message for the squashed commit
            repo_path: Path to git repo (default: cwd)
            base_branch: Branch to squash from (default: 'main')

        Returns:
            True if squash succeeded, False otherwise
        """
        try:
            git = GitState(
                self.workflow,
                self.namespace,
                repo_path=repo_path,
                base_branch=self.base_branch,
            )
            return git.squash(message, base_branch)
        except Exception as e:
            # Git squash failed - log and return False
            logger.error(f"Failed to squash commits: {e}")
            return False

    def squash_and_unstage(self, repo_path: Optional[Path] = None) -> bool:
        """Squash all intermediate commits and present changes unstaged for review.

        Resets to the workflow start commit, keeping all changes as unstaged
        modifications. This allows the user to review all changes together before
        making a final commit.

        Args:
            repo_path: Path to git repo (default: cwd)

        Returns:
            True if squash succeeded, False otherwise
        """
        try:
            git = GitState(
                self.workflow,
                self.namespace,
                repo_path=repo_path,
                base_branch=self.base_branch,
            )
            # Pass stored workflow_start_commit for resume support
            return git.squash_and_unstage(self.workflow_start_commit)
        except Exception as e:
            # Git squash and unstage failed - log and return False
            logger.error(f"Failed to squash and unstage commits: {e}")
            return False

    # =========================================================================
    # Child workflow discovery
    # =========================================================================

    def get_child_states(self, base: Optional[Path] = None) -> List["WorkflowState"]:
        """Find all child workflow states that belong to this workflow.

        Scans the state directory for state.json files and returns those
        that have parent_workflow set to this workflow's name.

        Returns:
            List of WorkflowState objects for child workflows.
        """
        children: List["WorkflowState"] = []
        base = base or Path.cwd()
        namespace_dir = base / ".analysis" / self.namespace

        if not namespace_dir.exists():
            return children

        for workflow_dir in namespace_dir.iterdir():
            if not workflow_dir.is_dir() or workflow_dir.name == self.workflow:
                continue

            state_file = workflow_dir / "state.json"
            if not state_file.exists():
                continue

            try:
                data = json.loads(state_file.read_text())
                if data.get("parent_workflow") == self.workflow:
                    child = WorkflowState.model_validate(data)
                    children.append(child)
            except Exception as e:
                # Child state file exists but can't be parsed - skip it
                logger.warning(f"Failed to parse child workflow state at {state_file}: {e}")
                continue

        return children
