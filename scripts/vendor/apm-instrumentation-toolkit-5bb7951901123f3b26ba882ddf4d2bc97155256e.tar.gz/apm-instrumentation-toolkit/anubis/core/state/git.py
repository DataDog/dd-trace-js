"""Git-based state management for workflow checkpointing.

Benefits:
- Full history of all changes
- Diff between steps
- Rollback to any previous state
- Works across entire repo
"""

import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from .utils import normalize_name


class GitState:
    """State management using git commits for checkpointing.

    Intermediate commits are unsigned (--no-gpg-sign) for automation.
    Call squash() at the end to create a single signed commit.

    Usage:
        state = GitState('sample_app', 'kafkajs', repo_path='/path/to/repo')

        # Ensure on workflow branch (creates if needed)
        state.ensure_branch()

        # After successful step, checkpoint (unsigned)
        state.checkpoint('generate')

        # On failure, rollback
        state.rollback('generate')

        # At workflow end, squash to single signed commit
        state.squash('feat(kafkajs): add sample app')
    """

    def __init__(
        self,
        workflow: str,
        namespace: str,
        repo_path: Optional[Path] = None,
        branch_prefix: str = "apm-ai-toolkit",
        base_branch: Optional[str] = None,
    ):
        self.workflow = workflow
        self.namespace = normalize_name(namespace)
        self.repo_path = Path(repo_path) if repo_path else Path.cwd()
        self.branch_prefix = branch_prefix
        self._base_branch = base_branch

        # Branch naming: apm-ai-toolkit/workflow/namespace/YYYYMMDD-HHMMSS
        # Set lazily in ensure_branch() to include timestamp or detect existing
        self.branch: Optional[str] = None
        self.tag_prefix: Optional[str] = None

        self._checkpoints: Dict[str, str] = {}
        self._step_start_commit: Optional[str] = (
            None  # Track commit at step start for accurate diffs
        )
        self._workflow_start_commit: Optional[str] = (
            None  # Track commit at workflow start for squashing
        )

        # If already on a matching branch, load its checkpoints
        current = self.get_current_branch()
        prefix = f"{self.branch_prefix}/{self.workflow}/{self.namespace}/"
        if current.startswith(prefix):
            self.branch = current
            self.tag_prefix = current
            self._load_checkpoints()

    # =========================================================================
    # Branch Management
    # =========================================================================

    def ensure_branch(self) -> List[str]:
        """Ensure we're on the workflow branch, creating it if needed.

        - If already on a matching branch for this workflow/namespace, stay on it
          (resume case).
        - Otherwise, pull the default branch and create a new timestamped branch.

        Returns:
            List of log messages describing actions taken
        """
        logs: List[str] = []
        current = self.get_current_branch()
        prefix = f"{self.branch_prefix}/{self.workflow}/{self.namespace}/"

        # Already on a matching branch — keep it, unless it was created from
        # the wrong base (e.g. a previous run used a different --base-branch).
        if current.startswith(prefix):
            if self._base_branch and not self._branch_descends_from(current, self._base_branch):
                logs.append(
                    f"Branch {current} does not descend from {self._base_branch} — recreating"
                )
                self._git("checkout", self._base_branch, check=False)
                self._git("branch", "-D", current, check=False)
            else:
                self.branch = current
                self.tag_prefix = current
                logs.append(f"Already on branch: {self.branch}")
                return logs

        # New branch: pull default branch first, then create
        default_branch = self._get_default_branch()
        if current != default_branch:
            logs.append(f"Checking out {default_branch}")
            self._git("checkout", default_branch)

        logs.append(f"Pulling latest from origin/{default_branch}")
        pull_result = self._git("pull", "origin", default_branch, check=False, timeout=30)
        pull_ok = pull_result.returncode == 0
        if not pull_ok:
            logs.append(
                f"Warning: git pull failed (returncode={pull_result.returncode}), proceeding on local {default_branch}"
            )

        # Log any uncommitted changes before wiping them
        status_result = self._git("status", "--porcelain", check=False)
        if status_result.returncode == 0 and status_result.stdout.strip():
            logs.append(
                f"Discarding uncommitted changes on {default_branch}:\n{status_result.stdout.strip()}"
            )

        # Reset to the remote ref when pull succeeded — this is critical for branches
        # that are created after a long-running session where the local default branch
        # drifted behind origin. Using HEAD would silently carry stale upstream commits
        # onto the new branch, producing 500+ unrelated files in the PR diff.
        # Fall back to HEAD only when pull failed (no network / no remote).
        reset_target = f"origin/{default_branch}" if pull_ok else "HEAD"
        reset_result = self._git("reset", "--hard", reset_target, check=False)
        if reset_result.returncode != 0:
            logs.append(
                f"Warning: reset --hard {reset_target} failed (returncode={reset_result.returncode}), branch may start from dirty state"
            )

        # Exclude .analysis/ in case the target repo doesn't gitignore it
        clean_result = self._git("clean", "-fd", "-e", ".analysis", check=False)
        if clean_result.returncode != 0:
            logs.append(
                f"Warning: git clean failed (returncode={clean_result.returncode}), untracked files may persist"
            )

        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d-%H%M%S")
        self.branch = f"{prefix}{timestamp}"
        self.tag_prefix = self.branch

        self._git("checkout", "-b", self.branch)
        logs.append(f"Created branch: {self.branch}")
        return logs

    def _get_default_branch(self) -> str:
        """Return the base branch to create workflow branches from.

        If base_branch was provided at init, use that. Otherwise detect
        whether the repo uses 'main' or 'master'.

        Returns:
            Branch name string
        """
        if self._base_branch:
            return self._base_branch
        result = self._git("rev-parse", "--verify", "main", check=False)
        if result.returncode == 0:
            return "main"
        return "master"

    def _branch_descends_from(self, branch: str, base: str) -> bool:
        """Return True if *branch* has *base* as an ancestor.

        Fetches the base ref first so the check works on fresh clones where
        only the default branch exists locally.
        """
        self._git("fetch", "origin", base, check=False, timeout=15)
        result = self._git("merge-base", "--is-ancestor", f"origin/{base}", branch, check=False)
        return result.returncode == 0

    def get_current_branch(self) -> str:
        """Get current git branch name."""
        result = self._git("rev-parse", "--abbrev-ref", "HEAD", check=False)
        return result.stdout.strip() if result.returncode == 0 else ""

    def get_current_commit(self) -> Optional[str]:
        """Get current HEAD commit hash."""
        result = self._git("rev-parse", "HEAD", check=False)
        return result.stdout.strip() if result.returncode == 0 else None

    def is_on_workflow_branch(self) -> bool:
        """Check if currently on the workflow branch."""
        return self.get_current_branch() == self.branch

    # =========================================================================
    # Checkpointing
    # =========================================================================

    def is_completed(self, step: str) -> bool:
        """Check if step has a checkpoint."""
        return step in self._checkpoints

    def get_commit(self, step: str) -> Optional[str]:
        """Get commit hash for a step."""
        return self._checkpoints.get(step)

    def checkpoint(
        self, step: str, message: Optional[str] = None, files: Optional[List[str]] = None
    ):
        """Create checkpoint commit for a step.

        Args:
            step: Step name
            message: Commit message (default: "workflow: {step}")
            files: Files to stage (default: stage all changes)
        """
        if files:
            for f in files:
                self._git("add", f)
        else:
            self._git("add", "-A")

        status = self._git("status", "--porcelain")
        if status.stdout.strip():
            msg = message or f"workflow({self.namespace}): {step}"
            # --no-gpg-sign: skip signing for intermediate commits (squash later)
            # --no-verify: skip pre-commit hooks to avoid hangs
            self._git("commit", "--no-gpg-sign", "--no-verify", "-m", msg)

        result = self._git("rev-parse", "HEAD")
        commit_hash = result.stdout.strip()

        # Sanitize step name to avoid nested slash issues in git tags
        safe_step = step.replace("/", "-")
        tag = f"{self.tag_prefix}/{safe_step}"
        self._git(
            "tag", "-f", tag, commit_hash, check=False
        )  # Best effort - don't fail on tag issues
        self._checkpoints[step] = commit_hash

    def rollback(self, step: str) -> bool:
        """Rollback to the state before a step.

        Returns:
            True if rollback was performed, False if no checkpoint found.
        """
        if step not in self._checkpoints:
            return False

        steps = list(self._checkpoints.keys())
        idx = steps.index(step)

        if idx == 0:
            first_commit = self._checkpoints[step]
            result = self._git("reset", "--hard", f"{first_commit}^", check=False)
            if result.returncode != 0:
                return False
        else:
            prev_step = steps[idx - 1]
            prev_commit = self._checkpoints[prev_step]
            result = self._git("reset", "--hard", prev_commit, check=False)
            if result.returncode != 0:
                return False

        for s in steps[idx:]:
            tag = f"{self.tag_prefix}/{s}"
            self._git("tag", "-d", tag, check=False)
            del self._checkpoints[s]

        return True

    def diff(self, from_step: str, to_step: str) -> str:
        """Get diff between two checkpoints."""
        from_commit = self._checkpoints.get(from_step)
        to_commit = self._checkpoints.get(to_step)

        if not from_commit or not to_commit:
            return ""

        result = self._git("diff", from_commit, to_commit, check=False)
        return str(result.stdout)

    def get_files_changed(self, step: str) -> List[str]:
        """Get list of files changed in a step."""
        commit = self._checkpoints.get(step)
        if not commit:
            return []

        result = self._git("diff-tree", "--no-commit-id", "--name-only", "-r", commit, check=False)
        return [f for f in result.stdout.strip().split("\n") if f]

    def mark_workflow_start(self) -> Optional[str]:
        """Record current HEAD as the workflow start point.

        Call this when workflow starts (after ensure_branch) to capture the
        starting commit for squashing intermediate commits at completion.

        Returns:
            The workflow start commit SHA, or None if already set
        """
        if not self._workflow_start_commit:
            self._workflow_start_commit = self.get_current_commit()
            return self._workflow_start_commit
        return None

    def mark_step_start(self) -> None:
        """Record current HEAD as the step start point.

        Call this before a step/item executes so that last_step_diff()
        shows only changes made by the current step, not cumulative changes.
        """
        self._step_start_commit = self.get_current_commit()

    def clear_step_start(self) -> None:
        """Clear the step start marker after step completes."""
        self._step_start_commit = None

    def last_step_diff(self, stat: bool = False) -> str:
        """Get diff showing changes made by the current step.

        Uses step start commit if set (via mark_step_start()), otherwise
        falls back to the last completed checkpoint.

        Args:
            stat: If True, return --stat summary instead of full diff

        Returns:
            Diff output, or empty string if no reference point
        """
        # Prefer step start commit (set before current step ran)
        base_commit = self._step_start_commit

        # Fall back to last completed checkpoint
        if not base_commit:
            completed = list(self._checkpoints.keys())
            if completed:
                base_commit = self._checkpoints.get(completed[-1])

        if not base_commit:
            return ""

        args = ["diff", base_commit, "HEAD"]
        if stat:
            # Use wide stat format to avoid truncating long paths
            args.insert(1, "--stat=200")

        result = self._git(*args, check=False)
        return str(result.stdout) if result.returncode == 0 else ""

    def get_completed_steps(self) -> List[str]:
        """Get list of completed steps."""
        return list(self._checkpoints.keys())

    def clear(self):
        """Clear all checkpoints for this workflow."""
        for step in list(self._checkpoints.keys()):
            tag = f"{self.tag_prefix}/{step}"
            self._git("tag", "-d", tag, check=False)
        self._checkpoints.clear()

    def squash(self, message: str, base_branch: str = "main") -> bool:
        """Squash all workflow commits into a single signed commit.

        Call this at the end of a successful workflow to create a clean,
        signed commit for the PR.

        Args:
            message: Final commit message
            base_branch: Branch to squash from (default: 'main')

        Returns:
            True if squash succeeded, False if no commits to squash
        """
        if not self._checkpoints:
            return False

        # Find merge base with target branch
        result = self._git("merge-base", base_branch, "HEAD", check=False)
        if result.returncode != 0:
            return False
        merge_base = result.stdout.strip()

        # Soft reset to merge base (keeps changes staged)
        self._git("reset", "--soft", merge_base)

        # Create single signed commit with all changes
        self._git("commit", "-m", message)

        # Clean up tags
        self.clear()

        return True

    def squash_and_unstage(self, workflow_start_commit: Optional[str] = None) -> bool:
        """Squash all intermediate commits and present changes unstaged for review.

        Resets to the workflow start commit, keeping all changes as unstaged
        modifications. This allows the user to review all changes together before
        making a final commit.

        Args:
            workflow_start_commit: Workflow start commit SHA (from state on resume),
                                  falls back to internal tracking if not provided

        Returns:
            True if squash succeeded, False if no commits to squash or no workflow start
        """
        # Use provided commit (from state) or fall back to internal tracking
        start_commit = workflow_start_commit or self._workflow_start_commit
        if not start_commit:
            return False

        # Check if there are any commits since workflow start
        result = self._git("rev-list", "--count", f"{start_commit}..HEAD", check=False)
        if result.returncode != 0:
            return False

        try:
            commit_count = int(result.stdout.strip())
            if commit_count == 0:
                return False
        except ValueError:
            return False

        # Reset to workflow start commit, keeping changes
        self._git("reset", "--soft", start_commit, check=False)

        # Unstage all changes so user can review
        self._git("reset", "HEAD", check=False)

        # Clean up tags
        self.clear()

        return True

    # =========================================================================
    # Internal
    # =========================================================================

    def _git(self, *args, check: bool = True, timeout: int = 15) -> subprocess.CompletedProcess:
        """Run git command with timeout to prevent hangs."""
        return subprocess.run(
            ["git", *args],
            cwd=self.repo_path,
            capture_output=True,
            text=True,
            check=check,
            timeout=timeout,
        )

    def _load_checkpoints(self):
        """Load existing checkpoints from git tags."""
        if not self.tag_prefix:
            return
        result = self._git("tag", "-l", f"{self.tag_prefix}/*", check=False)
        if result.returncode == 0:
            for tag in result.stdout.strip().split("\n"):
                if tag:
                    step = tag.split("/")[-1]
                    hash_result = self._git("rev-parse", tag, check=False)
                    if hash_result.returncode == 0:
                        self._checkpoints[step] = hash_result.stdout.strip()
