"""Python repo adapter - generic operations only."""

import json
import logging
import site
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import RepoAdapter

logger = logging.getLogger(__name__)


class PythonRepoAdapter(RepoAdapter):
    """Repo adapter for Python.

    Contains only generic repo operations. APM-specific methods
    are in anubis_apm.repo_adapters.
    """

    def get_agent_allowed_paths(self) -> List[Path]:
        """Get site-packages paths so agents can read installed packages.

        This allows agents to inspect packages found via ``pip show``
        (the fallback in get_package_path) without granting write access
        to the repo root.
        """
        paths = []
        for site_pkg in site.getsitepackages():
            site_path = Path(site_pkg)
            if site_path.exists():
                paths.append(site_path)
        user_site = site.getusersitepackages()
        if isinstance(user_site, str):
            user_path = Path(user_site)
            if user_path.exists():
                paths.append(user_path)
        return paths

    def get_runtime_command(self, script: Path, *args: str) -> List[str]:
        """Get Python runtime command."""
        return ["python", str(script)] + list(args)

    def install_package(
        self, package_name: str, install_dir: Path, target_version: Optional[str] = None
    ) -> Optional[Path]:
        """Install a Python package using pip.

        Installs into install_dir/site-packages/ to isolate packages from
        other files and make dependency locating straightforward.
        """
        try:
            target_dir = self.get_package_install_dir(install_dir)
            target_dir.mkdir(parents=True, exist_ok=True)

            # Append version specifier without affecting path resolution.
            # "psycopg2==2.9.9" installs to site-packages/psycopg2/, not site-packages/psycopg2==2.9.9/.
            install_spec = f"{package_name}=={target_version}" if target_version else package_name

            result = subprocess.run(
                ["pip", "install", "--target", str(target_dir), install_spec],
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode != 0:
                logger.warning(
                    f"pip install failed for {install_spec} (rc={result.returncode}):\n"
                    f"  stdout: {result.stdout.strip()}\n"
                    f"  stderr: {result.stderr.strip()}"
                )
                return None

            return self.get_package_path(package_name, install_dir)

        except Exception as e:
            logger.debug(f"Failed to install package {package_name}: {e}")
            return None

    def get_package_install_dir(self, install_dir: Path) -> Path:
        """Get Python package installation directory (install_dir/site-packages/)."""
        return install_dir / "site-packages"

    def get_package_path(self, package_name: str, install_dir: Path) -> Optional[Path]:
        """Get path to an already-installed package.

        First checks the ``--target`` install dir (used by install_package).
        Falls back to system site-packages via ``pip show`` for packages
        installed globally or in a virtualenv.
        """
        # Check --target install dir first
        package_dir = self.get_package_install_dir(install_dir)
        if package_dir.exists():
            path = self._find_package_in_dir(package_name, package_dir)
            if path:
                return path

        # Fall back to pip show for system/venv-installed packages
        return self._find_package_via_pip(package_name)

    def _find_package_in_dir(self, package_name: str, directory: Path) -> Optional[Path]:
        """Find a package directory by name, handling name normalization."""
        normalized_name = package_name.replace("-", "_").lower()
        for path in directory.iterdir():
            if path.is_dir() and path.name.lower().replace("-", "_") == normalized_name:
                return path.absolute()

        package_path = directory / package_name
        if package_path.exists():
            return package_path.absolute()

        return None

    def _find_package_via_pip(self, package_name: str) -> Optional[Path]:
        """Find an installed package location using pip show."""
        try:
            result = subprocess.run(
                ["pip", "show", package_name],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
            if result.returncode != 0:
                return None

            # Parse Location: line from pip show output
            for line in result.stdout.splitlines():
                if line.startswith("Location:"):
                    site_dir = Path(line.split(":", 1)[1].strip())
                    return self._find_package_in_dir(package_name, site_dir)
        except Exception as e:
            logger.debug(f"pip show failed for {package_name}: {e}")

        return None

    def get_package_version(self, package_name: str) -> Optional[str]:
        """Get the latest version of a PyPI package."""
        try:
            result = subprocess.run(
                ["pip", "index", "versions", package_name],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
            if result.returncode == 0 and result.stdout.strip():
                # Output format: "package_name (x.y.z)"
                output = result.stdout.strip()
                if "(" in output and ")" in output:
                    return output.split("(")[1].split(")")[0]
            return None
        except Exception as e:
            logger.debug(f"Failed to get package version for {package_name}: {e}")
            return None

    # =========================================================================
    # Linting
    # =========================================================================

    def lint_file(self, file_path: Path, repo_root: Path) -> bool:
        """Run ruff on a Python file."""
        try:
            result = subprocess.run(
                ["ruff", "check", "--fix", str(file_path)],
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.returncode == 0
        except Exception:
            return False

    def lint_paths(self, paths: List[str], repo_root: Path, fix: bool = False) -> Dict[str, Any]:
        """Run ruff on multiple paths."""
        cmd = ["ruff", "check", "--output-format", "json"]
        if fix:
            cmd.append("--fix")
        cmd.extend(paths)

        try:
            result = subprocess.run(
                cmd,
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                timeout=300,
            )

            raw_output = result.stdout or result.stderr

            try:
                ruff_output = json.loads(result.stdout) if result.stdout else []
            except json.JSONDecodeError:
                return {
                    "success": result.returncode == 0,
                    "error_count": 0,
                    "warning_count": 0,
                    "fixable_count": 0,
                    "errors": [],
                    "raw_output": raw_output,
                }

            errors = []
            total_errors = 0
            total_fixable = 0

            for issue in ruff_output:
                total_errors += 1
                if issue.get("fix"):
                    total_fixable += 1

                errors.append({
                    "file_path": issue.get("filename", ""),
                    "line": issue.get("location", {}).get("row", 0),
                    "column": issue.get("location", {}).get("column", 0),
                    "rule_id": issue.get("code", "unknown"),
                    "message": issue.get("message", ""),
                    "severity": "error",
                })

            return {
                "success": total_errors == 0,
                "error_count": total_errors,
                "warning_count": 0,
                "fixable_count": total_fixable,
                "errors": errors,
                "raw_output": raw_output,
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": "Ruff timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": f"Ruff failed: {e}",
            }

    def format_lint_errors_for_prompt(
        self, lint_result: Dict[str, Any], max_errors: int = 50
    ) -> str:
        """Format ruff errors for AI agent prompts."""
        if lint_result.get("success") and lint_result.get("error_count", 0) == 0:
            return "No linting errors."

        lines = [
            "## Ruff Summary",
            f"- Errors: {lint_result.get('error_count', 0)}",
            f"- Auto-fixable: {lint_result.get('fixable_count', 0)}",
            "",
            "## Errors by File",
            "",
        ]

        errors_by_file: Dict[str, List[Dict]] = {}
        for error in lint_result.get("errors", [])[:max_errors]:
            file_path = error.get("file_path", "unknown")
            if file_path not in errors_by_file:
                errors_by_file[file_path] = []
            errors_by_file[file_path].append(error)

        for file_path, file_errors in errors_by_file.items():
            lines.append(f"### `{file_path}`")
            lines.append("")
            for error in file_errors:
                lines.append(
                    f"- Line {error.get('line', 0)}:{error.get('column', 0)} "
                    f"- `{error.get('rule_id', 'unknown')}`: {error.get('message', '')}"
                )
            lines.append("")

        return "\n".join(lines)
