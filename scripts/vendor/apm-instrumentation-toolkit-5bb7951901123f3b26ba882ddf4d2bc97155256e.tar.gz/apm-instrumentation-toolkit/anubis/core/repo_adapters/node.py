"""Node.js repo adapter - generic operations only."""

import json
import logging
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import RepoAdapter

logger = logging.getLogger(__name__)


class NodeRepoAdapter(RepoAdapter):
    """Repo adapter for Node.js/JavaScript/TypeScript.

    Contains only generic repo operations. APM-specific methods
    are in integrations.repo_adapters.NodeAPMAdapter.
    """

    def get_runtime_command(self, script: Path, *args: str) -> List[str]:
        """Get Node.js runtime command."""
        return ["node", str(script)] + list(args)

    def install_package(
        self, package_name: str, install_dir: Path, target_version: Optional[str] = None
    ) -> Optional[Path]:
        """Install a Node.js package using npm."""
        try:
            install_dir.mkdir(parents=True, exist_ok=True)

            # Create package.json to prevent npm from searching upward
            package_json = install_dir / "package.json"
            if not package_json.exists():
                with open(package_json, "w") as f:
                    json.dump(
                        {"name": "analysis-temp", "version": "1.0.0", "private": True}, f, indent=2
                    )

            # Append version to install spec without affecting path resolution.
            # "express@4.19.2" installs to node_modules/express/, not node_modules/express@4.19.2/.
            install_spec = f"{package_name}@{target_version}" if target_version else package_name

            result = subprocess.run(
                ["npm", "install", "--legacy-peer-deps", install_spec],
                cwd=install_dir,
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode != 0:
                logger.warning(
                    f"npm install failed for {install_spec} (rc={result.returncode}):\n"
                    f"  stdout: {result.stdout.strip()}\n"
                    f"  stderr: {result.stderr.strip()}"
                )
                return None

            node_modules = install_dir / "node_modules"
            if package_name.startswith("@"):
                scope, name = package_name.split("/", 1)
                package_path = node_modules / scope / name
            else:
                package_path = node_modules / package_name

            if not package_path.exists():
                logger.warning(f"npm install succeeded but package not found at {package_path}")
                return None
            return package_path

        except Exception as e:
            # Failed to locate package - log and return None
            logger.debug(f"Failed to get installed package path for {package_name}: {e}")
            return None

    def get_package_install_dir(self, install_dir: Path) -> Path:
        """Get Node.js package installation directory."""
        return install_dir / "node_modules"

    def get_package_path(self, package_name: str, install_dir: Path) -> Optional[Path]:
        """Get path to an already-installed package."""
        node_modules = self.get_package_install_dir(install_dir)

        if package_name.startswith("@"):
            scope, name = package_name.split("/", 1)
            package_path = node_modules / scope / name
        else:
            package_path = node_modules / package_name

        return package_path.absolute() if package_path.exists() else None

    def get_package_version(self, package_name: str) -> Optional[str]:
        """Get the latest version of an npm package."""
        try:
            result = subprocess.run(
                ["npm", "view", package_name, "version"],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
            return None
        except Exception as e:
            # Failed to get npm bin path - log and return None
            logger.debug(f"Failed to get npm bin path: {e}")
            return None

    # =========================================================================
    # Linting
    # =========================================================================

    def lint_file(self, file_path: Path, repo_root: Path) -> bool:
        """Run ESLint on a JavaScript/TypeScript file."""
        try:
            result = subprocess.run(
                ["npx", "eslint", str(file_path), "--fix"],
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,  # Prevent hanging on npx prompts
                timeout=30,
            )
            return result.returncode in [0, 1]  # 1 = warnings only
        except Exception:
            return False

    def lint_paths(self, paths: List[str], repo_root: Path, fix: bool = False) -> Dict[str, Any]:
        """Run ESLint on multiple paths."""
        cmd = ["npx", "eslint", "--format", "json"]
        if fix:
            cmd.append("--fix")
        cmd.extend(paths)

        try:
            result = subprocess.run(
                cmd,
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,  # Prevent hanging on npx prompts
                timeout=300,
            )

            raw_output = result.stdout or result.stderr

            try:
                eslint_output = json.loads(result.stdout) if result.stdout else []
            except json.JSONDecodeError:
                return {
                    "success": result.returncode == 0,
                    "error_count": 0,
                    "warning_count": 0,
                    "fixable_count": 0,
                    "errors": [],
                    "raw_output": raw_output,
                }

            errors = []
            total_errors = 0
            total_warnings = 0
            total_fixable = 0

            for file_result in eslint_output:
                file_path = file_result.get("filePath", "")
                total_errors += file_result.get("errorCount", 0)
                total_warnings += file_result.get("warningCount", 0)
                total_fixable += file_result.get("fixableErrorCount", 0)
                total_fixable += file_result.get("fixableWarningCount", 0)

                for msg in file_result.get("messages", []):
                    errors.append({
                        "file_path": file_path,
                        "line": msg.get("line", 0),
                        "column": msg.get("column", 0),
                        "rule_id": msg.get("ruleId", "unknown"),
                        "message": msg.get("message", ""),
                        "severity": "error" if msg.get("severity", 1) == 2 else "warning",
                    })

            return {
                "success": total_errors == 0,
                "error_count": total_errors,
                "warning_count": total_warnings,
                "fixable_count": total_fixable,
                "errors": errors,
                "raw_output": raw_output,
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": "ESLint timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": f"ESLint failed: {e}",
            }

    def format_lint_errors_for_prompt(
        self, lint_result: Dict[str, Any], max_errors: int = 50
    ) -> str:
        """Format ESLint errors for AI agent prompts."""
        if lint_result.get("success") and lint_result.get("error_count", 0) == 0:
            warning_count = lint_result.get("warning_count", 0)
            if warning_count > 0:
                return f"No linting errors. {warning_count} warnings (acceptable)."
            return "No linting errors."

        lines = [
            "## ESLint Summary",
            f"- Errors: {lint_result.get('error_count', 0)}",
            f"- Warnings: {lint_result.get('warning_count', 0)}",
            f"- Auto-fixable: {lint_result.get('fixable_count', 0)}",
            "",
            "## Errors by File",
            "",
        ]

        errors_by_file: Dict[str, List[Dict]] = {}
        for error in lint_result.get("errors", [])[:max_errors]:
            file_path = error.get("file_path", "unknown")
            if file_path not in errors_by_file:
                errors_by_file[file_path] = []
            errors_by_file[file_path].append(error)

        for file_path, file_errors in errors_by_file.items():
            lines.append(f"### `{file_path}`")
            lines.append("")
            for error in file_errors:
                icon = "❌" if error.get("severity") == "error" else "⚠️"
                lines.append(
                    f"- {icon} Line {error.get('line', 0)}:{error.get('column', 0)} "
                    f"- `{error.get('rule_id', 'unknown')}`: {error.get('message', '')}"
                )
            lines.append("")

        return "\n".join(lines)
