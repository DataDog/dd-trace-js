"""Java repo adapter - generic operations only."""

import json
import logging
import subprocess
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, cast

from .base import RepoAdapter

logger = logging.getLogger(__name__)


class JavaRepoAdapter(RepoAdapter):
    """Repo adapter for Java/Gradle/Maven.

    Contains only generic repo operations. APM-specific methods
    are in anubis_apm.repo_adapters.DDTraceJavaAdapter.
    """

    def get_runtime_command(self, script: Path, *args: str) -> List[str]:
        """Get runtime command for executing scripts.

        Auto-detects script type:
        - .py files: Run with Python
        - .jar files: Run with Java
        - Others: Assume executable shell script

        Args:
            script: Path to the script to execute
            *args: Arguments to pass to the script

        Returns:
            Command list ready for subprocess.run()
        """
        if script.suffix == ".py":
            return ["python", str(script)] + list(args)
        elif script.suffix == ".jar":
            return ["java", "-jar", str(script)] + list(args)
        else:
            # Assume executable script (shell, etc.)
            return [str(script)] + list(args)

    def install_package(
        self, package_name: str, install_dir: Path, target_version: Optional[str] = None
    ) -> Optional[Path]:
        """Install a Java package using Maven.

        Downloads the compiled JAR from Maven Central for analysis with javap.
        Unlike Node/Python adapters, this returns the JAR file path directly
        rather than extracting sources, since Java analysis tools work with .class files.

        Accepts Maven coordinates (group:artifact:version format).
        Plain integration names (e.g., 'jedis') are not supported and return None.

        Args:
            package_name: Maven coordinates (e.g., 'redis.clients:jedis:3.0.0')
                         or plain name (not supported, returns None)
            install_dir: Base directory for installation

        Returns:
            Path to downloaded JAR file (e.g., install_dir/lib/jedis-3.0.0.jar)
            or None if installation fails
        """
        try:
            # Ensure lib directory exists
            lib_dir = install_dir / "lib"
            lib_dir.mkdir(parents=True, exist_ok=True)

            # Parse group:artifact:version format
            parts = package_name.split(":")
            if len(parts) != 3:
                # Plain integration name (e.g. 'jedis'): no JAR to download.
                # Return None so downstream steps (all_methods, enrichment) skip
                # library analysis and work from the tracer repo source directly.
                logger.info(
                    "Plain package name '%s': Java workflow will use tracer repo source directly",
                    package_name,
                )
                return None

            group_id, artifact_id, version = parts
            jar_file = lib_dir / f"{artifact_id}-{version}.jar"

            # If already downloaded, return it
            if jar_file.exists():
                logger.debug(f"Package {package_name} already installed at {jar_file}")
                return jar_file

            # Download JAR to install_dir using Maven dependency:copy
            result = subprocess.run(
                [
                    "mvn",
                    "dependency:copy",
                    f"-Dartifact={package_name}",
                    f"-DoutputDirectory={lib_dir}",
                ],
                cwd=lib_dir,
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode != 0:
                logger.warning(
                    f"Maven download failed for {package_name} (rc={result.returncode}):\n"
                    f"  stdout: {result.stdout.strip()}\n"
                    f"  stderr: {result.stderr.strip()}"
                )
                raise RuntimeError(
                    f"Failed to install package '{package_name}': Maven returned exit code "
                    f"{result.returncode}. Check that the coordinates are correct and Maven "
                    f"Central is reachable."
                )

            if not jar_file.exists():
                logger.warning(f"Maven download succeeded but JAR not found at {jar_file}")
                raise RuntimeError(
                    f"Failed to install package '{package_name}': Maven reported success but "
                    f"JAR not found at {jar_file}."
                )

            logger.debug(f"Installed {package_name} to {jar_file}")

            # Best-effort: also fetch and unpack the -sources.jar so enrichment can
            # read real source (accurate file paths + line numbers). Most libraries
            # publish a sources jar; when none exists, analysis falls back to the
            # compiled bytecode. Never fatal — a missing sources jar must not fail
            # the install.
            self._download_sources(package_name, lib_dir, install_dir / "sources")

            return jar_file

        except RuntimeError:
            raise
        except Exception as e:
            logger.debug(f"Failed to install package {package_name}: {e}")
            return None

    def _download_sources(
        self, package_name: str, lib_dir: Path, sources_dir: Path
    ) -> Optional[Path]:
        """Download and unpack the ``-sources.jar`` for a Maven artifact (best-effort).

        Many libraries publish a sources jar alongside the binary, giving the
        enrichment step real ``.java`` files with accurate line numbers instead of
        only bytecode. This is best-effort: if no sources jar is published (or the
        download/unpack fails), it logs and returns ``None`` so the caller continues
        with bytecode-only analysis.

        Args:
            package_name: Maven coordinates ``group:artifact:version``.
            lib_dir: Directory the sources jar is downloaded into.
            sources_dir: Directory the sources jar is unpacked into.

        Returns:
            The ``sources_dir`` if sources were unpacked, else ``None``.
        """
        parts = package_name.split(":")
        if len(parts) != 3:
            return None
        _, artifact_id, version = parts
        sources_jar = lib_dir / f"{artifact_id}-{version}-sources.jar"

        if not sources_jar.exists():
            # `:jar:sources` is the classifier form Maven uses for the sources artifact.
            result = subprocess.run(
                [
                    "mvn",
                    "dependency:copy",
                    f"-Dartifact={package_name}:jar:sources",
                    f"-DoutputDirectory={lib_dir}",
                ],
                cwd=lib_dir,
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode != 0 or not sources_jar.exists():
                logger.info(
                    "No sources jar for %s — enrichment will use bytecode only.", package_name
                )
                return None

        try:
            sources_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(sources_jar) as zf:
                # Only extract .java files; skip META-INF and resources.
                members = [n for n in zf.namelist() if n.endswith(".java")]
                zf.extractall(sources_dir, members=members)
            logger.debug("Unpacked %d source files to %s", len(members), sources_dir)
            return sources_dir
        except (zipfile.BadZipFile, OSError) as e:
            logger.info("Failed to unpack sources jar for %s: %s", package_name, e)
            return None

    def get_package_install_dir(self, install_dir: Path) -> Path:
        """Get Java package installation directory (typically ~/.m2/repository)."""
        # For Java, we'll use a local directory rather than the global Maven cache
        return install_dir / "lib"

    def get_package_path(self, package_name: str, install_dir: Path) -> Optional[Path]:
        """Return path to the installed JAR for a package.

        Accepts either Maven coordinates (group:artifact:version or group:artifact)
        or a plain artifact name (e.g., 'jedis'). Plain names are matched by glob
        against ``lib/{name}-*.jar``, which covers the common case where ctx.namespace
        has been normalised to the artifact ID after prepare_maven_install().

        Args:
            package_name: Maven coordinates or plain artifact name
            install_dir: Base installation directory

        Returns:
            Path to JAR file or None if not found
        """
        lib_dir = self.get_package_install_dir(install_dir)

        parts = package_name.split(":")
        if len(parts) == 1:
            # Plain artifact name — glob for any version
            artifact_id = parts[0]
            version = "*"
        else:
            artifact_id = parts[1]
            version = parts[2] if len(parts) > 2 else "*"

        pattern = f"{artifact_id}-{version}.jar" if version != "*" else f"{artifact_id}-*.jar"
        # Exclude Maven classifier jars: the method extractor runs javap, which needs
        # the binary (.class) jar, not the -sources.jar (.java) or -javadoc.jar that
        # install_package also downloads. The broad "artifact-*.jar" glob would
        # otherwise return a sources jar first on some directory orderings, yielding
        # zero extracted methods.
        jars = [
            f
            for f in lib_dir.glob(pattern)
            if f.is_file() and not f.name.endswith(("-sources.jar", "-javadoc.jar"))
        ]

        return jars[0].absolute() if jars else None

    def get_package_version(self, package_name: str) -> Optional[str]:
        """Get the latest version of a Maven package."""
        try:
            # Parse group:artifact format
            parts = package_name.split(":")
            if len(parts) < 2:
                return None

            group_id, artifact_id = parts[0], parts[1]

            # Query Maven Central API using stdlib urllib
            url = f"https://search.maven.org/solrsearch/select?q=g:{group_id}+AND+a:{artifact_id}&rows=1&wt=json"
            with urllib.request.urlopen(url, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
                docs = data.get("response", {}).get("docs", [])
                if docs:
                    latest_version = docs[0].get("latestVersion")
                    if latest_version and isinstance(latest_version, str):
                        return cast(str, latest_version)
            return None
        except Exception as e:
            logger.debug(f"Failed to get package version: {e}")
            return None

    # =========================================================================
    # Linting
    # =========================================================================

    def lint_file(self, file_path: Path, repo_root: Path) -> bool:
        """Run Spotless on a Java file."""
        try:
            result = subprocess.run(
                ["./gradlew", "spotlessApply"],
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                timeout=120,
            )
            return result.returncode == 0
        except Exception:
            return False

    def lint_paths(self, paths: List[str], repo_root: Path, fix: bool = False) -> Dict[str, Any]:
        """Run Spotless/Checkstyle on multiple paths."""
        if fix:
            cmd = ["./gradlew", "spotlessApply"]
        else:
            cmd = ["./gradlew", "spotlessCheck"]

        try:
            result = subprocess.run(
                cmd,
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                timeout=300,
            )

            raw_output = result.stdout + result.stderr

            # Parse Gradle output for errors
            errors = []
            total_errors = 0

            # Spotless outputs files with format violations like:
            # "The following files had format violations:"
            # "    path/to/File.java"
            if "spotless" in raw_output.lower() and result.returncode != 0:
                # Look for file paths in Spotless output (indented .java files)
                # Spotless typically lists files with violations after "format violations" message
                in_violation_list = False
                for line in raw_output.split("\n"):
                    # Detect start of violation list
                    if "format violation" in line.lower() or "needs formatting" in line.lower():
                        in_violation_list = True
                        continue

                    # Stop if we hit a new section
                    if in_violation_list and line and not line.startswith((" ", "\t")):
                        in_violation_list = False

                    # Parse file paths (usually indented)
                    if in_violation_list and line.strip().endswith(".java"):
                        file_path = line.strip()
                        errors.append({
                            "file_path": file_path,
                            "line": 0,  # Spotless doesn't provide line numbers
                            "column": 0,
                            "rule_id": "spotless-format",
                            "message": "File needs formatting (run spotlessApply to fix)",
                            "severity": "error",
                        })
                        total_errors += 1

            return {
                "success": result.returncode == 0,
                "error_count": total_errors,
                "warning_count": 0,
                "fixable_count": total_errors if not fix else 0,
                "errors": errors,
                "raw_output": raw_output,
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": "Spotless timed out",
            }
        except Exception as e:
            return {
                "success": False,
                "error_count": 0,
                "warning_count": 0,
                "fixable_count": 0,
                "errors": [],
                "raw_output": f"Spotless failed: {e}",
            }

    def format_lint_errors_for_prompt(
        self, lint_result: Dict[str, Any], max_errors: int = 50
    ) -> str:
        """Format Spotless errors for AI agent prompts."""
        if lint_result.get("success") and lint_result.get("error_count", 0) == 0:
            warning_count = lint_result.get("warning_count", 0)
            if warning_count > 0:
                return f"No linting errors. {warning_count} warnings (acceptable)."
            return "No linting errors."

        lines = [
            "## Spotless Summary",
            f"- Errors: {lint_result.get('error_count', 0)}",
            f"- Warnings: {lint_result.get('warning_count', 0)}",
            f"- Auto-fixable: {lint_result.get('fixable_count', 0)}",
            "",
            "## Errors by File",
            "",
        ]

        errors_by_file: Dict[str, List[Dict[str, Any]]] = {}
        for error in lint_result.get("errors", [])[:max_errors]:
            file_path = error.get("file_path", "unknown")
            if file_path not in errors_by_file:
                errors_by_file[file_path] = []
            errors_by_file[file_path].append(error)

        for file_path, file_errors in errors_by_file.items():
            lines.append(f"### `{file_path}`")
            lines.append("")
            for error in file_errors:
                icon = "❌" if error.get("severity") == "error" else "⚠️"
                lines.append(
                    f"- {icon} Line {error.get('line', 0)}:{error.get('column', 0)} "
                    f"- `{error.get('rule_id', 'unknown')}`: {error.get('message', '')}"
                )
            lines.append("")

        return "\n".join(lines)
