"""Abstract base class for repo-specific functionality."""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional


class RepoAdapter(ABC):
    """
    Abstract base class for repo/language-specific operations.

    This adapter pattern allows the framework to remain repo-agnostic
    while delegating repo-specific operations to concrete implementations.
    """

    @property
    @abstractmethod
    def adapter_dir(self) -> Path:
        """Get the adapter directory containing language-specific scripts and tools."""
        pass

    @abstractmethod
    def get_runtime_command(self, script: Path, *args: str) -> List[str]:
        """Get command to execute a script in this language's runtime.

        Returns:
            Command array suitable for subprocess.run()
            e.g., ['node', '/path/to/script.js', 'arg1']
        """
        pass

    def get_static_analyzer_scripts(self) -> Dict[str, Path]:
        """Get language-specific static analyzer scripts.

        Override in language-specific adapters to provide paths to scripts
        like method extractors, AST analyzers, etc.

        Returns:
            Dictionary mapping script names to their file paths.
        """
        return {}

    def get_agent_allowed_paths(self) -> List[Path]:
        """Get additional paths agents should have access to.

        Override in language-specific adapters to grant read access to
        paths outside the repo root (e.g., system package directories).

        Returns:
            List of paths to add to the agent sandbox allowed list.
        """
        return []

    @abstractmethod
    def install_package(
        self, package_name: str, install_dir: Path, target_version: Optional[str] = None
    ) -> Optional[Path]:
        """Install a package locally.

        Args:
            package_name: The package to install (e.g. ``"express"``).
            install_dir: Directory to install into.
            target_version: Pin to this exact version (e.g. ``"4.19.2"``).
                The adapter appends the version to the install command;
                path resolution always uses ``package_name`` without the specifier.

        Returns:
            Path to the installed package, or None if installation failed
        """
        pass

    @abstractmethod
    def get_package_install_dir(self, install_dir: Path) -> Path:
        """Get the directory where packages are installed (e.g., node_modules)."""
        pass

    def get_package_path(self, package_name: str, install_dir: Path) -> Optional[Path]:
        """Get path to an already-installed package."""
        package_dir = self.get_package_install_dir(install_dir)
        package_path = package_dir / package_name
        if package_path.exists():
            return package_path.absolute()
        return None

    @abstractmethod
    def get_package_version(self, package_name: str) -> Optional[str]:
        """Get the latest version of a package from the registry."""
        pass

    # =========================================================================
    # Linting
    # =========================================================================

    @abstractmethod
    def lint_file(self, file_path: Path, repo_root: Path) -> bool:
        """Run linter/formatter on a file. Returns True if succeeded."""
        pass

    @abstractmethod
    def lint_paths(self, paths: List[str], repo_root: Path, fix: bool = False) -> Dict[str, Any]:
        """Run linter on multiple paths and return structured results.

        Returns:
            Dictionary with 'success', 'error_count', 'warning_count',
            'fixable_count', 'errors', 'raw_output'
        """
        pass

    @abstractmethod
    def format_lint_errors_for_prompt(
        self, lint_result: Dict[str, Any], max_errors: int = 50
    ) -> str:
        """Format lint errors into a string suitable for AI agent prompts."""
        pass
