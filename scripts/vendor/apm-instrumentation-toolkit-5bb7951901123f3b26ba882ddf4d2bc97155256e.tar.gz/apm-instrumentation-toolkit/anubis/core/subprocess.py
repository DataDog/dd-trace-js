"""Subprocess execution utilities for external tools.

Provides clean environment management and consistent error handling.
"""

import json
import os
import subprocess
import sys
from typing import Any, Dict, List, Optional


def get_clean_env() -> Dict[str, str]:
    """Get clean environment without Node.js debug flags.

    Removes --inspect and --debug flags from NODE_OPTIONS to prevent
    conflicts when spawning child Node.js processes.
    """
    clean_env = os.environ.copy()

    if "NODE_OPTIONS" in clean_env:
        node_opts = clean_env["NODE_OPTIONS"]
        cleaned_opts = []

        for opt in node_opts.split():
            if not (opt.startswith("--inspect") or opt.startswith("--debug")):
                cleaned_opts.append(opt)

        if cleaned_opts:
            clean_env["NODE_OPTIONS"] = " ".join(cleaned_opts)
        else:
            del clean_env["NODE_OPTIONS"]

    return clean_env


def run_subprocess_json(
    cmd: List[str],
    timeout: int = 30,
    error_context: str = "subprocess",
    emitter: Any = None,
) -> Optional[Dict[str, Any]]:
    """Run subprocess with clean environment and parse JSON output.

    Args:
        cmd: Command and arguments to execute
        timeout: Timeout in seconds
        error_context: Context string for error messages
        emitter: Optional emitter for logging (uses print to stderr if None)

    Returns:
        Parsed JSON dict from stdout, or None if execution failed
    """

    def warn(msg: str) -> None:
        if emitter:
            emitter.emit("warn", message=msg)
        else:
            print(f"Warning: {msg}", file=sys.stderr)

    clean_env = get_clean_env()

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=clean_env)

        if result.returncode == 0:
            parsed: Any = json.loads(result.stdout)
            if isinstance(parsed, list):
                return dict(parsed[0]) if parsed else None
            return dict(parsed)
        else:
            warn(f"{error_context} failed")
            return None

    except subprocess.TimeoutExpired:
        warn(f"{error_context} timed out after {timeout}s")
        return None

    except json.JSONDecodeError as e:
        warn(f"{error_context} returned invalid JSON: {e}")
        return None

    except Exception as e:
        warn(f"{error_context} exception: {e}")
        return None
