"""Git worktree helpers for workflows that need an isolated repo copy.

Workflows that run agents or evals against a clean copy of the repo (without
touching the developer's checked-out state) should create a worktree via
:func:`create_worktree` and tear it down via :func:`cleanup_worktree`.

A worktree shares the parent repo's object store, so creating one is cheap
(no full checkout copy). Named worktrees live under ``{repo_root}/.worktrees/``
by convention so they're easy to discover and ``.gitignore``'d.  Pass
``suffix=None`` to create a throwaway worktree in the OS temp dir instead.
"""

import logging
import os
import shutil
import tempfile
from pathlib import Path
from typing import Optional

# Suppress GitPython's ImportError at import time when git is not on PATH
# (e.g. in smoke-test containers).  Actual git calls will still raise
# git.exc.GitCommandNotFound if git is absent when the functions are invoked.
os.environ.setdefault("GIT_PYTHON_REFRESH", "quiet")

import git
import git.exc
from git import Actor

logger = logging.getLogger(__name__)


def create_worktree(
    repo_root: Path,
    suffix: Optional[str] = None,
    *,
    prefix: str = "anubis-wt-",
    base_subdir: str = ".worktrees",
    from_ref: str = "HEAD",
    branch: Optional[str] = None,
) -> Path:
    """Create an isolated git worktree.

    When *suffix* is given the worktree is placed at
    ``{repo_root}/{base_subdir}/{suffix}`` (named, idempotent — re-creates if
    the path already exists).  When *suffix* is ``None`` a throwaway directory
    is created in the OS temp dir (``tempfile.mkdtemp(prefix=prefix)``).

    Args:
        repo_root: Path to the parent git repository.
        suffix: Directory name under ``base_subdir``.  ``None`` creates a temp
            worktree outside the repo tree.
        prefix: ``mkdtemp`` prefix used when ``suffix`` is ``None``.
        base_subdir: Subdirectory under ``repo_root`` for named worktrees.
        from_ref: Git ref to check out (default: ``HEAD``).
        branch: If provided, create the worktree on a new branch with this
            name (``git worktree add -b``).  Only valid with a named worktree.

    Returns:
        Absolute path to the created worktree.

    Raises:
        RuntimeError: If ``git worktree add`` fails.
    """
    repo = git.Repo(str(repo_root))

    if suffix is None:
        worktree_path = Path(tempfile.mkdtemp(prefix=prefix))
        worktree_path.rmdir()  # git worktree add requires the path to not exist
    else:
        worktree_path = repo_root / base_subdir / suffix
        try:
            repo.git.worktree("prune")
        except git.exc.GitCommandError as exc:
            logger.debug("git worktree prune failed (non-fatal): %s", exc)
        if worktree_path.exists():
            try:
                repo.git.worktree("remove", "--force", str(worktree_path))
            except git.exc.GitCommandError:
                shutil.rmtree(str(worktree_path), ignore_errors=True)
        worktree_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        if branch:
            repo.git.worktree("add", "-b", branch, str(worktree_path), from_ref)
        else:
            repo.git.worktree("add", "--detach", str(worktree_path), from_ref)
    except git.exc.GitCommandError as exc:
        raise RuntimeError(f"Failed to create worktree at {worktree_path}: {exc.stderr}") from exc

    logger.info("Created worktree at %s (from %s)", worktree_path, from_ref)
    return worktree_path


def cleanup_worktree(repo_root: Path, worktree_path: Path) -> None:
    """Remove a worktree and prune stale entries.

    Uses ``git worktree remove --force`` to drop the worktree cleanly. Falls
    back to a recursive ``rmtree`` if the git command can't tear it down
    (e.g. if the parent repo has gone away). Always runs ``git worktree
    prune`` afterwards so the parent repo's worktree list stays in sync.
    """
    if not worktree_path.exists():
        return

    repo = git.Repo(str(repo_root))
    try:
        repo.git.worktree("remove", "--force", str(worktree_path))
    except git.exc.GitCommandError as exc:
        logger.warning(
            "git worktree remove failed (%s) — falling back to rmtree",
            str(exc.stderr).strip(),
        )
        shutil.rmtree(str(worktree_path), ignore_errors=True)

    try:
        repo.git.worktree("prune")
    except git.exc.GitCommandError as exc:
        logger.debug("git worktree prune failed (non-fatal): %s", exc)

    logger.info("Removed worktree %s", worktree_path)


def seal_worktree(worktree: Path) -> None:
    """Commit all tracked-file deletions/changes in a worktree, updating HEAD.

    Call this after removing integration files from a worktree so that
    ``git show HEAD:<path>`` reflects the cleaned state and cannot retrieve
    deleted files. Uses unsigned interim commits scoped to a detached eval
    worktree.
    """
    worktree_repo = git.Repo(str(worktree))
    worktree_repo.git.add("-u")
    author = Actor("anubis-eval", "eval@anubis")
    worktree_repo.index.commit("eval: seal worktree", author=author, committer=author)
