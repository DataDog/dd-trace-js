"""GitHub context fetchers — used by TaskSpec.from_dynamic_source (--source).

Two transports, split by what each call needs:

* Issue/PR bodies hit ``api.github.com`` directly via ``httpx``. This is a
  one-shot REST call to a documented endpoint, so the ``gh`` CLI buys us
  nothing here and pulling it out removes a subprocess hop.
* GitHub Actions logs still go through the ``gh`` CLI. ``gh run view
  --log-failed`` does server-side filtering by ``##[group]`` markers that
  the REST API doesn't expose — re-implementing it would be its own change.

Auth note (private-repo regression risk): ``gh`` reads tokens from its
local keychain, which works transparently for the user running ``dd-apm``.
``httpx`` does not — it only sees what's in env. We fall back to
``GITHUB_TOKEN`` then ``GH_TOKEN`` (the same names ``gh`` itself respects),
so an unauthenticated call against a private repo will 404 unless one of
those is exported. Public repos work either way. If a user reports
``--source`` failing on a private issue URL, this is the first thing to
check.
"""

import os
import re
import shutil
import subprocess
from collections.abc import Callable

import httpx

# Shared prefix for any github.com URL: optional protocol, then
# ``github.com/owner/repo``. Anchored at start but with no end-anchor so
# trailing path / query / hash doesn't have to be modeled. Protocol is
# optional so a user pasting ``github.com/...`` (no scheme) still hits
# the fetcher.
_GITHUB_REPO_PREFIX = r"^(?:https?://)?github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)"

# GitHub web-UI URL for an issue or PR.
_GITHUB_ISSUE_RE = re.compile(rf"{_GITHUB_REPO_PREFIX}/(?:issues|pull)/(?P<number>\d+)")

# GitHub Actions failed-job URL. Matches both ``/job/N`` (singular, clicked
# from PR checks tab) and ``/jobs/N`` (plural, check-run URL form).
_GITHUB_ACTIONS_JOB_RE = re.compile(
    rf"{_GITHUB_REPO_PREFIX}/actions/runs/(?P<run_id>\d+)/jobs?/(?P<job_id>\d+)"
)

# URL-shape detector for raising on unrecognized http(s) URLs.
_URL_LIKE_RE = re.compile(r"^https?://")

_ACTIONS_LOG_TAIL_CHARS = 4000
_HTTP_TIMEOUT_SECS = 15.0


def _auth_headers() -> dict[str, str]:
    """Build request headers, attaching a bearer token if one is in env.

    Mirrors ``gh``'s own env-var precedence (``GITHUB_TOKEN`` then
    ``GH_TOKEN``) so users who already export either get private-repo
    access without extra setup.
    """
    headers = {"Accept": "application/vnd.github+json"}
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _require_gh(url: str) -> None:
    """Raise ``ValueError`` if the ``gh`` CLI is not installed."""
    if shutil.which("gh") is None:
        raise ValueError(
            "gh CLI is required to fetch GitHub Actions logs but is not installed. "
            "Install it from https://cli.github.com/ or pass a file instead."
        )


def fetch_github_issue(url: str) -> str:
    """Fetch a GitHub issue or PR body via the REST API.

    Returns ``"<title>\\n\\n<body>"``.
    """
    match = _GITHUB_ISSUE_RE.match(url)
    if not match:
        raise ValueError(f"Not a recognized GitHub issue or PR URL: {url}")

    api_url = (
        f"https://api.github.com/repos/{match['owner']}/{match['repo']}/issues/{match['number']}"
    )
    try:
        response = httpx.get(api_url, headers=_auth_headers(), timeout=_HTTP_TIMEOUT_SECS)
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise ValueError(
            f"GitHub API failed to fetch {url}: {exc.response.status_code} "
            f"{exc.response.reason_phrase}"
        ) from exc
    except httpx.RequestError as exc:
        raise ValueError(f"GitHub API request failed for {url}: {exc}") from exc

    payload = response.json()
    title = payload.get("title") or ""
    body = payload.get("body") or ""
    return f"{title}\n\n{body}".strip()


def fetch_github_actions_job(url: str) -> str:
    """Fetch a failed GitHub Actions job's log via the ``gh`` CLI.

    Returns a markdown-formatted body: job metadata header + failure log tail.
    """
    match = _GITHUB_ACTIONS_JOB_RE.match(url)
    if not match:
        raise ValueError(f"Not a recognized GitHub Actions job URL: {url}")

    _require_gh(url)

    repo = f"{match['owner']}/{match['repo']}"
    run_id = match["run_id"]
    job_id = match["job_id"]

    try:
        meta = subprocess.run(
            [
                "gh",
                "api",
                f"repos/{repo}/actions/jobs/{job_id}",
                "--jq",
                '"job: " + .name + "\\n"'
                '+ "conclusion: " + (.conclusion // "in_progress") + "\\n"'
                '+ "run_url: " + .html_url',
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )
    except subprocess.TimeoutExpired as exc:
        raise ValueError(f"gh api timed out fetching job metadata for {url}") from exc

    if meta.returncode != 0:
        stderr = meta.stderr.strip() or "unknown error"
        raise ValueError(f"gh api failed to fetch job metadata for {url}: {stderr}")

    try:
        log = subprocess.run(
            ["gh", "run", "view", run_id, "--repo", repo, "--job", job_id, "--log-failed"],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired as exc:
        raise ValueError(f"gh run view timed out fetching log for {url}") from exc

    if log.returncode != 0 or not log.stdout.strip():
        try:
            log = subprocess.run(
                ["gh", "run", "view", run_id, "--repo", repo, "--job", job_id, "--log"],
                capture_output=True,
                text=True,
                timeout=30,
            )
        except subprocess.TimeoutExpired as exc:
            raise ValueError(f"gh run view timed out fetching full log for {url}") from exc
        if log.returncode != 0:
            stderr = log.stderr.strip() or "unknown error"
            raise ValueError(f"gh run view failed for {url}: {stderr}")

    log_tail = log.stdout.strip()
    if len(log_tail) > _ACTIONS_LOG_TAIL_CHARS:
        log_tail = "…(log truncated to last %d chars)…\n%s" % (
            _ACTIONS_LOG_TAIL_CHARS,
            log_tail[-_ACTIONS_LOG_TAIL_CHARS:],
        )

    return (
        f"# GitHub Actions failed job\n\n"
        f"source: {url}\n"
        f"{meta.stdout.strip()}\n\n"
        f"## Failure log\n\n```\n{log_tail}\n```\n"
    )


def format_supported_github_sources() -> str:
    """Human-readable list of URL forms the GitHub fetchers handle."""
    return (
        "  - github.com — issue/PR (/issues/N, /pull/N), Actions job\n"
        "                (/actions/runs/N/job(s)/M)"
    )


# Registry of (pattern, fetcher) pairs. First match wins. Extend to add new
# source types (GitLab CI, Datadog traces, Linear, Jira, …).
GITHUB_URL_FETCHERS: list[tuple[re.Pattern[str], Callable[[str], str]]] = [
    (_GITHUB_ACTIONS_JOB_RE, fetch_github_actions_job),
    (_GITHUB_ISSUE_RE, fetch_github_issue),
]
