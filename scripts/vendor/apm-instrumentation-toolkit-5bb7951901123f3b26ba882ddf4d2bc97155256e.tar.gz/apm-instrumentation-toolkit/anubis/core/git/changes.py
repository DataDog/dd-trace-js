"""Git helpers for tracking file changes across workflow steps.

Provides functions for capturing git status snapshots and computing
diffs between them — used by workflows to detect what an agent changed.
"""

import logging
import os
import subprocess
from pathlib import Path
from typing import List, Optional, Set, Tuple

# Suppress GitPython's ImportError at import time when git is not on PATH
# (e.g. in smoke-test containers). Actual git calls will still raise
# git.exc.GitCommandNotFound if git is absent when the functions are invoked.
os.environ.setdefault("GIT_PYTHON_REFRESH", "quiet")

import git
import git.exc

logger = logging.getLogger(__name__)


def capture_git_status(repo_root: Path) -> Optional[Set[str]]:
    """Capture current git status as a set of status lines.

    Args:
        repo_root: Path to git repository root

    Returns:
        Set of git status lines, or None if git command fails
    """
    try:
        repo = git.Repo(str(repo_root))
        output = repo.git.status("--short")
        return set(output.strip().split("\n")) if output.strip() else set()
    except Exception as exc:
        logger.debug("Failed to get git status: %s", exc)
        return None


def get_git_changes(
    before: Optional[Set[str]], after: Optional[Set[str]], repo_root: Optional[Path] = None
) -> Tuple[List[str], List[str]]:
    """Compare git status snapshots and extract added/modified files.

    Args:
        before: Git status before operation
        after: Git status after operation
        repo_root: Repository root for expanding directories

    Returns:
        Tuple of (added_files, modified_files)
    """
    if before is None or after is None:
        return ([], [])

    new_changes = after - before
    added = []
    modified = []

    for line in sorted(new_changes):
        if not line.strip():
            continue
        status = line[:2].strip()
        filepath = line[3:].strip()

        if status in ["A", "??"]:
            added.append(filepath)
        elif status == "M":
            modified.append(filepath)

    if repo_root:
        added = _expand_directories(added, repo_root)
        modified = _expand_directories(modified, repo_root)

    return (added, modified)


def _expand_directories(entries: List[str], repo_root: Path) -> List[str]:
    """Expand directory entries to individual files."""
    repo = git.Repo(str(repo_root))
    expanded = []
    for entry in entries:
        if entry.endswith("/"):
            try:
                output = repo.git.ls_files("--others", "--exclude-standard", entry)
                if output.strip():
                    expanded.extend(output.strip().split("\n"))
                else:
                    expanded.append(entry)
            except Exception:
                expanded.append(entry)
        else:
            expanded.append(entry)
    return expanded


def revert_tracked_files(
    tracked_files: List[str],
    repo_root: Path,
    git_source_root: Optional[Path] = None,
) -> List[str]:
    """Revert a list of tracked files to their HEAD state.

    In a normal git worktree uses ``git checkout``; in a plain directory copy
    (no ``.git``) reads HEAD content from ``git_source_root`` via the blob
    object and overwrites the copy.

    Returns the list of relative paths that were actually reverted.
    """
    reverted: List[str] = []
    has_git = (repo_root / ".git").exists()
    repo = git.Repo(str(repo_root)) if has_git else None
    src_repo = git.Repo(str(git_source_root)) if git_source_root else None

    for rel_path in tracked_files:
        full_path = repo_root / rel_path
        if not full_path.exists():
            continue
        if repo is not None:
            try:
                repo.git.diff("--quiet", rel_path)
            except git.exc.GitCommandError:
                # non-zero exit means the file has uncommitted changes
                repo.git.checkout("--", rel_path)
                reverted.append(f"{rel_path} (reverted)")
        elif src_repo is not None:
            try:
                blob = src_repo.head.commit.tree[rel_path]
                full_path.write_bytes(blob.data_stream.read())
                reverted.append(f"{rel_path} (restored from HEAD)")
            except KeyError:
                logger.debug("revert_tracked_files: %s not found in HEAD, skipping", rel_path)
    return reverted


def get_git_branch() -> str:
    """Return the active git branch name.

    Checks CI env vars first (GitHub Actions, GitLab CI), then falls back to
    GitPython. Returns ``"unknown"`` if none of these succeed (e.g. detached HEAD).
    """
    for env_var in ("GITHUB_HEAD_REF", "GITHUB_REF_NAME", "CI_COMMIT_REF_NAME"):
        val = os.environ.get(env_var, "").strip()
        if val:
            return val
    try:
        repo = git.Repo(search_parent_directories=True)
        branch = str(repo.active_branch.name)
        if branch:
            return branch
    except (git.exc.InvalidGitRepositoryError, git.exc.GitCommandNotFound, TypeError) as exc:
        logger.debug("get_git_branch: GitPython lookup failed: %s", exc)
    return "unknown"


def filter_noise(files: List[str], patterns: Optional[List[str]] = None) -> List[str]:
    """Filter out noisy files like node_modules.

    Args:
        files: List of file paths
        patterns: Additional patterns to filter (default: ['node_modules'])

    Returns:
        Filtered list of files
    """
    noise = patterns or ["node_modules"]
    return [f for f in files if not any(p in f.split("/") for p in noise)]


def detect_default_branch(repo_root: Path) -> str:
    """Detect whether the repo uses ``main`` or ``master`` as its default.

    Mirrors ``GitState._get_default_branch``: prefer ``main`` if it exists
    locally, otherwise fall back to ``master``. Used when callers don't pass
    an explicit base branch — several tracer repos (e.g. dd_trace_js) still
    default to ``master``.
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--verify", "main"],
            cwd=str(repo_root),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return "main"
    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        logger.debug("rev-parse --verify main failed, falling back to master: %s", exc)
    return "master"


def get_diff_from_base_branch(
    repo_root: Path,
    base_branch: Optional[str] = None,
    *,
    stat: bool = False,
) -> str:
    """Return the diff of a repo against a base branch.

    Tries three strategies in order and returns the first that produces
    non-empty output:

    1. ``git diff <base_branch>...HEAD`` — committed changes on the current
       branch vs ``base_branch`` (the common workflow-branch case where
       prior steps have already checkpoint-committed)
    2. ``git diff HEAD`` — unstaged/staged changes vs the last commit
    3. ``git diff`` — any remaining working-tree differences

    Args:
        repo_root: Path to the git repository root.
        base_branch: Branch to diff against. Pass ``None`` to auto-detect
            (``main`` if it exists locally, otherwise ``master``) —
            convenient for callers forwarding ``ctx.state.base_branch``
            directly, which may itself be unset.
        stat: If ``True``, return a ``git diff --stat`` summary instead of
            the full diff. Stat output is stripped of trailing whitespace;
            full diffs are returned verbatim to preserve patch-format
            trailing newlines.

    Returns:
        The diff as a string, or ``""`` if no changes are detected or every
        strategy failed.
    """
    if base_branch is None:
        base_branch = detect_default_branch(repo_root)

    base_cmd = ["git", "diff"]
    if stat:
        base_cmd.append("--stat")

    for ref_args in ([f"{base_branch}...HEAD"], ["HEAD"], []):
        cmd = [*base_cmd, *ref_args]
        try:
            result = subprocess.run(
                cmd,
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip() if stat else result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
            logger.debug("diff command %s failed, trying next: %s", cmd, exc)
            continue

    return ""
