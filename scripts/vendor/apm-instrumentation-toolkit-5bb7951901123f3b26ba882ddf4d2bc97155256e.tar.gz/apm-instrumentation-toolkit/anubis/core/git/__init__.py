"""Git utilities for the anubis workflow framework.

Submodules:
- ``changes`` — status capture, diff helpers, revert helpers
- ``worktree`` — creating and cleaning up isolated git worktrees
- ``github`` — GitHub context fetchers (issues, PRs, Actions jobs via gh CLI)
"""

from .changes import (
    capture_git_status,
    detect_default_branch,
    filter_noise,
    get_diff_from_base_branch,
    get_git_branch,
    get_git_changes,
    revert_tracked_files,
)
from .github import (
    _URL_LIKE_RE,
    GITHUB_URL_FETCHERS,
    fetch_github_actions_job,
    fetch_github_issue,
    format_supported_github_sources,
)
from .worktree import (
    cleanup_worktree,
    create_worktree,
    seal_worktree,
)

__all__ = [
    "GITHUB_URL_FETCHERS",
    "_URL_LIKE_RE",
    "capture_git_status",
    "cleanup_worktree",
    "create_worktree",
    "detect_default_branch",
    "fetch_github_actions_job",
    "fetch_github_issue",
    "filter_noise",
    "format_supported_github_sources",
    "get_diff_from_base_branch",
    "get_git_branch",
    "get_git_changes",
    "revert_tracked_files",
    "seal_worktree",
]
