"""Pydantic validation for steps."""

from typing import TYPE_CHECKING, Any, List, Type, Union

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

if TYPE_CHECKING:
    from ..context import Context


def pydantic_validator(
    output: Any, ctx: "Context", output_type: Type[BaseModel]
) -> Union[bool, List[str]]:
    """Validate output against a Pydantic schema.

    Args:
        output: The output to validate (dict or BaseModel)
        ctx: Execution context
        output_type: Pydantic model class to validate against

    Returns:
        True if valid, or list of error messages
    """
    if output_type is None:
        return True

    try:
        if isinstance(output, dict):
            output_type.model_validate(output)
        elif isinstance(output, BaseModel):
            output_type.model_validate(output.model_dump())
        return True
    except PydanticValidationError as e:
        errors = []
        for err in e.errors():
            loc = ".".join(str(x) for x in err["loc"])
            errors.append(f"{loc}: {err['msg']}")
        return errors
