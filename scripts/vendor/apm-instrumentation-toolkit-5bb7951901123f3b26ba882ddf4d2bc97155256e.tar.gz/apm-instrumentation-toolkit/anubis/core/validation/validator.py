"""Validator class - orchestrates validation for steps."""

from typing import TYPE_CHECKING, Any, List, Type

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from ..errors import ValidationError
from ..types import run_validators

if TYPE_CHECKING:
    from ..context import Context
    from ..steps import Step


class Validator:
    """Orchestrates input/output validation for steps.

    Handles:
    - Pydantic model validation (schema, types, constraints)
    - Custom validators (quality, shape, etc.)
    - Conversion between dict/model types

    Usage:
        validator = Validator()
        input = validator.validate_input(input, step, ctx)
        output = validator.validate_output(output, step, ctx)
    """

    def validate_input(self, input: Any, step: "Step", ctx: "Context") -> Any:
        """Validate and convert input for a step.

        1. Run Pydantic validation (if step.input_type defined)
        2. Run custom input validators (if step.input_validators defined)

        Returns validated input (converted to model if needed).
        Raises ValidationError on failure.
        """
        # Pydantic validation
        if step.input_type:
            input = self._validate_pydantic(input, step.input_type, "Input")

        # Custom validators
        input_validators = getattr(step, "input_validators", [])
        if input_validators:
            errors = run_validators(input_validators, input, ctx)
            if errors:
                raise ValidationError(f"Input validation failed: {errors}", errors)

        return input

    def validate_output(self, output: Any, step: "Step", ctx: "Context") -> Any:
        """Validate and convert output from a step.

        1. Run Pydantic validation (if step.output_type defined)
        2. Run custom validators (step.validators)

        Returns validated output (converted to model if needed).
        Raises ValidationError on failure.
        """
        # Pydantic validation
        output_type = step.output_type
        if output_type:
            output = self._validate_pydantic(output, output_type, "Output")

        # Custom validators
        if step.validators:
            errors = run_validators(step.validators, output, ctx, output_type)
            if errors:
                raise ValidationError(f"Output validation failed: {errors}", errors)

        return output

    def _validate_pydantic(self, value: Any, model_type: Type[BaseModel], label: str) -> BaseModel:
        """Validate and convert value to Pydantic model.

        Args:
            value: Value to validate (None, dict, or BaseModel)
            model_type: Expected Pydantic model type
            label: "Input" or "Output" for error messages

        Returns:
            Validated model instance

        Raises:
            ValidationError on failure
        """
        if value is None:
            try:
                return model_type()
            except PydanticValidationError as e:
                errors = self._format_pydantic_errors(e)
                raise ValidationError(f"{label} validation failed: {errors}", errors)

        try:
            if isinstance(value, dict):
                return model_type.model_validate(value)
            elif isinstance(value, model_type):
                return model_type.model_validate(value.model_dump())
            elif isinstance(value, BaseModel):
                return model_type.model_validate(value.model_dump())
            else:
                raise ValidationError(
                    f"{label} type mismatch: expected {model_type.__name__}, "
                    f"got {type(value).__name__}"
                )
        except PydanticValidationError as e:
            errors = self._format_pydantic_errors(e)
            raise ValidationError(f"{label} validation failed: {errors}", errors)

    def _format_pydantic_errors(self, e: PydanticValidationError) -> List[str]:
        """Format Pydantic validation errors into readable strings."""
        return [f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors()]
