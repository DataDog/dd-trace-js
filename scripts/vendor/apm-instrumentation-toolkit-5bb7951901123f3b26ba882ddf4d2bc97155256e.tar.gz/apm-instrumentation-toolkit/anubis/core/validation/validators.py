"""Built-in validators for shape and quality checking.

Validators are functions with signature: (output, ctx, output_type) -> bool | str | List[str]
- True: valid
- str: invalid with error message
- List[str]: invalid with multiple errors

The output_type parameter is optional - validators can ignore it if not needed.
"""

from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, List, Optional, Type, Union

from pydantic import BaseModel

if TYPE_CHECKING:
    from ..context import Context

ValidatorFn = Callable[..., Union[bool, str, List[str]]]


# =============================================================================
# Shape Validators - Check structure
# =============================================================================


def has_field(field_name: str, error: Optional[str] = None) -> ValidatorFn:
    """Validate that output has a non-empty field."""

    def check(
        output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
    ) -> Union[bool, str]:
        value = getattr(output, field_name, None)
        if value is None:
            return error or f"Missing required field: {field_name}"
        if isinstance(value, (list, dict, str)) and len(value) == 0:
            return error or f"Field '{field_name}' is empty"
        return True

    check.__name__ = f"has_{field_name}"
    return check


def min_items(field_name: str, minimum: int, error: Optional[str] = None) -> ValidatorFn:
    """Validate that a list field has minimum items."""

    def check(
        output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
    ) -> Union[bool, str]:
        value = getattr(output, field_name, None)
        if value is None:
            return error or f"Missing required field: {field_name}"
        if not isinstance(value, list):
            return error or f"Field '{field_name}' is not a list"
        if len(value) < minimum:
            return error or f"Field '{field_name}' needs at least {minimum} items, got {len(value)}"
        return True

    check.__name__ = f"min_{field_name}_{minimum}"
    return check


def file_exists(path_field: str, error: Optional[str] = None) -> ValidatorFn:
    """Validate that a path field points to an existing file."""

    def check(
        output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
    ) -> Union[bool, str]:
        path_str = getattr(output, path_field, None)
        if path_str is None:
            return error or f"Missing path field: {path_field}"
        path = Path(path_str)
        if not path.exists():
            return error or f"File not found: {path}"
        return True

    check.__name__ = f"file_exists_{path_field}"
    return check


def files_exist(*path_fields: str) -> ValidatorFn:
    """Validate that multiple path fields point to existing files."""

    def check(
        output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
    ) -> Union[bool, List[str]]:
        errors = []
        for field in path_fields:
            path_str = getattr(output, field, None)
            if path_str and not Path(path_str).exists():
                errors.append(f"File not found: {path_str}")
        return errors if errors else True

    check.__name__ = "files_exist"
    return check


# =============================================================================
# Composite Validators
# =============================================================================


def all_of(*validators: ValidatorFn) -> ValidatorFn:
    """All validators must pass."""

    def check(
        output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
    ) -> Union[bool, List[str]]:
        errors = []
        for v in validators:
            try:
                result = v(output, ctx, output_type)
            except TypeError:
                result = v(output, ctx)
            if result is not True:
                if isinstance(result, str):
                    errors.append(result)
                elif isinstance(result, list):
                    errors.extend(result)
                else:
                    errors.append(f"{v.__name__} failed")
        return errors if errors else True

    check.__name__ = "all_of"
    return check


def any_of(*validators: ValidatorFn) -> ValidatorFn:
    """At least one validator must pass."""

    def check(
        output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
    ) -> Union[bool, str]:
        for v in validators:
            try:
                result = v(output, ctx, output_type)
            except TypeError:
                result = v(output, ctx)
            if result is True:
                return True
        return f"None of the validators passed: {[v.__name__ for v in validators]}"

    check.__name__ = "any_of"
    return check


# =============================================================================
# Common Pre-built Validators
# =============================================================================


def no_errors(
    output: Any, ctx: "Context", output_type: Optional[Type[BaseModel]] = None
) -> Union[bool, List[str]]:
    """Validate output has no error field or empty errors list."""
    errors = getattr(output, "errors", None)
    if errors:
        if isinstance(errors, list) and len(errors) > 0:
            return errors
        elif isinstance(errors, str):
            return [errors]
    return True
