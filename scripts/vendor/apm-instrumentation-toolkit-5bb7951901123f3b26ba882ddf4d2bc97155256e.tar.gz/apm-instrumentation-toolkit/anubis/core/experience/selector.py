"""RunSelector — rule-based relevance scoring for experience retrieval.

Scores past runs by relevance to the current task. The paper (arxiv:2601.22436)
shows that raw experience from *unrelated* tasks hurts agent performance, so
runs with a score <= 0 are excluded entirely.
"""

from datetime import datetime, timezone
from typing import List, Optional

from pydantic import BaseModel


class RunFilter(BaseModel):
    """Filter criteria for listing runs from the experience store."""

    repository: Optional[str] = None
    workflow: Optional[str] = None
    integration: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    min_completed_steps: int = 0


class RunScoreInput(BaseModel):
    """Minimal run info needed for scoring. Populated from RunManifest."""

    run_id: str
    integration: str
    category: Optional[str] = None
    status: str = "completed"
    environment: str = "dev"
    steps_completed: int = 0
    completed_at: Optional[datetime] = None


class RunSelector:
    """Scores and selects relevant past runs for experience injection.

    Scoring heuristics:
    - Same category: +10 (strongest relevance signal)
    - Same namespace (different run): +5 (same integration, prior attempt)
    - Completed successfully: +3
    - Failed run: +1 (useful negative example)
    - Recent (< 30 days, linear decay): +0–2
    - Different category (known): -5 (paper: irrelevant experience hurts)

    Runs scoring <= 0 are excluded entirely.
    """

    def __init__(
        self,
        current_integration: str,
        current_category: Optional[str] = None,
        required_environment: Optional[str] = "prod",
    ) -> None:
        self.integration = current_integration
        self.category = current_category
        self.required_environment = required_environment

    def select(self, runs: List[RunScoreInput], max_runs: int = 5) -> List[RunScoreInput]:
        """Return up to max_runs most relevant runs, excluding irrelevant ones.

        If required_environment is set, only runs matching that environment are considered.
        """
        candidates = runs
        if self.required_environment:
            candidates = [r for r in runs if r.environment == self.required_environment]

        scored = [(self._score(r), r) for r in candidates]
        scored.sort(key=lambda x: x[0], reverse=True)
        relevant = [(s, r) for s, r in scored if s > 0]
        return [r for _, r in relevant[:max_runs]]

    def _score(self, run: RunScoreInput) -> float:
        score = 0.0

        if self.category and run.category == self.category:
            score += 10.0

        if run.integration == self.integration:
            score += 5.0

        if run.status == "completed":
            score += 3.0
        elif run.status == "failed":
            score += 1.0

        if run.completed_at:
            age_days = (datetime.now(timezone.utc) - run.completed_at).days
            score += max(0.0, 2.0 - (age_days / 30.0))

        if self.category and run.category and run.category != self.category:
            score -= 5.0

        return score
