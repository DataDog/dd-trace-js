"""Experience data models — generic, domain-agnostic."""

from pydantic import BaseModel


class ExperiencePointer(BaseModel):
    """Points to a raw file from a past run in the local experience cache.

    Used to inject concrete file references into agent prompts. The agent reads
    the raw file directly — we never summarize its contents.
    """

    run_id: str
    integration: str
    step_name: str
    local_path: str
    relevance: str
    status: str = "completed"
