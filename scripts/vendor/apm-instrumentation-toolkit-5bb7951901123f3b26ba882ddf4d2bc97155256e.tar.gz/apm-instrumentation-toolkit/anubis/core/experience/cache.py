"""ExperienceCache — local disk cache for pulled experience data.

Stores selectively-downloaded files from S3 under .analysis/.experience/
so they survive across workflow runs without re-downloading.
"""

import json
import logging
import shutil
from pathlib import Path
from typing import Any, List, Optional

logger = logging.getLogger(__name__)

_CACHE_SUBDIR = ".experience"
_INDEX_FILE = "index.json"


class ExperienceCache:
    """Local LRU cache for pulled experience run data.

    Structure::

        {base_dir}/.analysis/.experience/
        ├── index.json                   # cached copy of S3 manifest index
        └── {repository}/{namespace}/{workflow}/{run_id}/
            └── (selectively pulled files from S3)

    The .experience/ directory is gitignored — it is a read-only local cache.
    """

    def __init__(self, base_dir: Path, max_cached_runs: int = 50) -> None:
        self.cache_dir = base_dir / ".analysis" / _CACHE_SUBDIR
        self.max_cached_runs = max_cached_runs

    def ensure_dirs(self) -> None:
        """Create cache directory structure if needed."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def run_dir(self, repository: str, namespace: str, workflow: str, run_id: str) -> Path:
        """Return local path for a cached run."""
        return self.cache_dir / repository / namespace / workflow / run_id

    def has_run(self, repository: str, namespace: str, workflow: str, run_id: str) -> bool:
        """Check if a run's data is already cached locally."""
        d = self.run_dir(repository, namespace, workflow, run_id)
        return d.exists() and any(d.iterdir())

    def store_run(
        self,
        repository: str,
        namespace: str,
        workflow: str,
        run_id: str,
        source: Path,
    ) -> Path:
        """Copy a run's directory tree into the cache. Returns the cached path."""
        dest = self.run_dir(repository, namespace, workflow, run_id)
        dest.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, dest, dirs_exist_ok=True)
        return dest

    def load_index(self) -> List[Any]:
        """Load the cached S3 manifest index, or return empty list."""
        index_path = self.cache_dir / _INDEX_FILE
        if not index_path.exists():
            return []
        try:
            data = json.loads(index_path.read_text())
            return data if isinstance(data, list) else []
        except (json.JSONDecodeError, OSError) as exc:
            logger.debug("Failed to load experience index: %s", exc)
            return []

    def save_index(self, manifests: List[dict]) -> None:
        """Persist a manifest list as the local index."""
        self.ensure_dirs()
        index_path = self.cache_dir / _INDEX_FILE
        index_path.write_text(json.dumps(manifests, indent=2, default=str))

    def evict_old(self) -> None:
        """Remove least-recently-accessed runs when cache exceeds max_cached_runs."""
        if not self.cache_dir.exists():
            return

        # Collect all run dirs: .experience/{repo}/{ns}/{wf}/{run_id}/
        run_dirs: List[Path] = []
        for run_dir in self.cache_dir.glob("*/*/*/*/"):
            if run_dir.is_dir():
                run_dirs.append(run_dir)

        if len(run_dirs) <= self.max_cached_runs:
            return

        # Sort by access time (oldest first)
        run_dirs.sort(key=lambda p: p.stat().st_atime)
        to_remove = run_dirs[: len(run_dirs) - self.max_cached_runs]
        for path in to_remove:
            shutil.rmtree(path, ignore_errors=True)
            logger.debug("Evicted cached experience run: %s", path)

    def get_run_path(
        self,
        repository: str,
        namespace: str,
        workflow: str,
        run_id: str,
    ) -> Optional[Path]:
        """Return the cached run path if it exists, else None."""
        d = self.run_dir(repository, namespace, workflow, run_id)
        return d if d.exists() else None
