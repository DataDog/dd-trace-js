"""Workflow orchestrator - runs steps with validation and state."""

import contextvars
import logging
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, Generic, List, Optional, Set, Type, TypeVar, cast

from pydantic import BaseModel

from .config import WorkflowRuntimeConfig, get_config
from .context import Context
from .errors import ResetToStep, WorkflowError
from .feedback import FeedbackStore, HaltSignal, StructuredHalt
from .output import EventEmitter, FileListener, TerminalListener, restore_terminal_for_input
from .resources import flush_tracked_paths, get_global_resources
from .state.git import GitState
from .state.models import AgentRun, WorkflowState
from .steps import Step
from .tracing import (
    llmobs_agent,
    llmobs_annotate,
    llmobs_task,
    serialize_for_llmobs,
    tag_step_span,
    traced_workflow,
    tracer,
)
from .types import Result

logger = logging.getLogger(__name__)

I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)

# Track the active workflow for auto-detecting nested execution.
# Any workflow created while another is running is automatically nested.
_active_workflow: contextvars.ContextVar[Optional["Workflow"]] = contextvars.ContextVar(
    "_active_workflow", default=None
)


def _inject_model_into_ctx(model: Any, ctx: Context) -> None:
    """Inject Pydantic model fields as individual ctx keys.

    After each step the workflow calls this for both input and output so that
    prompt templates can reference any field directly (e.g. ``{{targets}}``)
    without a ``get_prompt_variables`` override.  Later steps overwrite earlier
    values — this is intentional; each iteration always reflects the latest run.

    Uses ``model_dump()`` for Pydantic models to ensure complex nested objects
    (e.g. List[SomeModel]) are converted to JSON-safe dicts/lists before being
    stored in state.data.  Raw Pydantic instances would be serialised as opaque
    strings by the state's ``json.dumps(..., default=str)`` fallback and would
    corrupt the stored value on resume.
    """
    if isinstance(model, BaseModel):
        for field_name, value in model.model_dump().items():
            ctx.set(field_name, value)
    elif isinstance(model, dict):
        for key, value in model.items():
            ctx.set(key, value)


class Workflow(Generic[I, O]):
    """Workflow orchestrates steps with validation and state.

    Features:
    - Input-based caching
    - Structured logging and artifacts
    - Resume from checkpoint
    - Nested workflows (workflow as step)
    - Step-level fixer pattern for validation failures

    Subclass and override:
    - name: Workflow identifier
    - steps: List of Step classes to execute
    - create_emitter(): Override to provide custom event emitter
    - create_prompts(): Override to provide custom prompt layer
    - setup_environment(): Override for custom environment setup
    """

    # Override in subclass
    name: str = "workflow"
    steps: List[Type[Step]] = []
    prompt: Optional[str] = None

    @classmethod
    def get_step_names(cls, include_nested: bool = False) -> List[str]:
        """Get all step names in this workflow.

        Args:
            include_nested: If True, include steps from nested workflows
                           (prefixed with parent workflow name)

        Returns:
            List of step names in execution order
        """
        names = []
        for step_cls in cls.steps:
            step_name = getattr(
                step_cls,
                "name",
                step_cls.__name__.lower().replace("workflow", "").replace("step", ""),
            )

            if include_nested and isinstance(step_cls, type) and issubclass(step_cls, Workflow):
                nested_names = step_cls.get_step_names(include_nested=True)
                for nested in nested_names:
                    names.append(f"{step_name}:{nested}")
            else:
                names.append(step_name)

        return names

    def __init__(
        self,
        runtime_config: Optional[WorkflowRuntimeConfig] = None,
        # Internal (not part of config)
        _is_nested: bool = False,
        _parent_workflow: Optional[str] = None,
        _parent_artifacts: Optional[Dict[str, Any]] = None,
        _parent_prompts: Optional[Any] = None,
        _parent_runtime_config: Optional[WorkflowRuntimeConfig] = None,
        _parent_context: Optional[Context] = None,
        _state_name: Optional[str] = None,
        **kwargs: Any,
    ):
        """Initialize workflow with runtime configuration.

        Args:
            runtime_config: WorkflowRuntimeConfig object with all settings.
                           If not provided, kwargs are used to build config.
            _is_nested: Internal flag for nested workflow execution.
            _parent_workflow: Internal parent workflow name.
            _parent_artifacts: Internal parent artifacts.
            _parent_prompts: Internal parent prompts (for nested workflows).
            _parent_runtime_config: Parent workflow's runtime config for inheritance.
                                   Nested workflows automatically inherit settings like
                                   headless, model, repository, etc.
                                   Explicit kwargs override inherited values.
            _parent_context: Parent workflow's context for automatic inheritance.
            **kwargs: All WorkflowRuntimeConfig fields accepted as kwargs.
                     Common kwargs: namespace, repository, headless, model,
                     user_prompt, base_dir, step_configs, skip_steps, config.

        Example::

            # Option 1: Pass config object directly
            config = WorkflowRuntimeConfig(
                namespace='kafkajs',
                headless=True,
            )
            workflow = MyWorkflow(runtime_config=config)

            # Option 2: Pass kwargs (converted to config internally)
            workflow = MyWorkflow(
                namespace='kafkajs',
                headless=True,
            )

            # Option 3: Nested workflow inheriting parent config
            child = ChildWorkflow(
                namespace='child',
                _parent_runtime_config=parent._runtime_config,
            )
        """
        # Build config: explicit object OR kwargs → WorkflowRuntimeConfig
        if runtime_config is not None:
            self._runtime_config = runtime_config
        else:
            # Handle skip_steps in config dict (migrate to top-level)
            config_dict = kwargs.pop("config", None) or {}
            if "skip_steps" in config_dict and "skip_steps" not in kwargs:
                kwargs["skip_steps"] = config_dict.pop("skip_steps")
            if config_dict:
                kwargs["config"] = config_dict

            # Inherit from parent config if provided (explicit kwargs override)
            if _parent_runtime_config is not None:
                parent_data = _parent_runtime_config.model_dump()
                # Fields to inherit from parent (execution settings)
                inheritable_fields = {
                    "headless",
                    "model",
                    "repository",
                    "base_branch",
                    "skip_git",
                    "stop_after",
                    "from_step",
                    "rollback_git",
                }
                for field in inheritable_fields:
                    if field not in kwargs and field in parent_data:
                        kwargs[field] = parent_data[field]

            self._runtime_config = WorkflowRuntimeConfig(**kwargs)

        # Internal state (not config)
        # Auto-detect nesting: if a workflow is already running, we're nested
        if not _is_nested and _active_workflow.get() is not None:
            _is_nested = True
        self._is_nested = _is_nested
        # Parent ref for auto-aggregation is resolved at run() time, not here,
        # so pre-instantiated workflows pick up the correct active parent.
        self._parent_workflow = _parent_workflow
        self._parent_artifacts = _parent_artifacts or {}
        self._state_name = _state_name  # Override workflow name for state path
        self._parent_prompts = _parent_prompts
        self._parent_context = _parent_context
        self._stopped_early: bool = False
        self.start_time: Optional[float] = None

        # Initialized on run()
        self._ctx: Optional[Context] = None

    # =========================================================================
    # Properties for backward compatibility (delegate to _runtime_config)
    # =========================================================================

    @property
    def namespace(self) -> str:
        """Unique identifier for this workflow run."""
        return self._runtime_config.namespace

    @property
    def repository(self) -> str:
        """Target repository."""
        return self._runtime_config.repository

    @property
    def base_branch(self) -> Optional[str]:
        """Base branch in target repo to create workflow branches from."""
        return self._runtime_config.base_branch

    @property
    def user_prompt(self) -> Optional[str]:
        """Custom user guidance."""
        return self._runtime_config.user_prompt

    @user_prompt.setter
    def user_prompt(self, value: Optional[str]) -> None:
        """Set user prompt (for state restoration on resume)."""
        # Create a new config with updated user_prompt
        # This is needed for resume functionality
        data = self._runtime_config.model_dump()
        data["user_prompt"] = value
        self._runtime_config = WorkflowRuntimeConfig(**data)

    @property
    def model(self) -> Optional[str]:
        """Model override for agent steps."""
        return self._runtime_config.model

    @property
    def headless(self) -> bool:
        """Run without interactive prompts."""
        return self._runtime_config.headless

    @property
    def config(self) -> Dict[str, Any]:
        """Domain-specific configuration."""
        return self._runtime_config.config

    @property
    def step_configs(self) -> Dict[str, Dict[str, Any]]:
        """Per-step configuration overrides."""
        return self._runtime_config.step_configs

    @property
    def base_dir(self) -> Optional[Path]:
        """Base directory for analysis output."""
        return self._runtime_config.base_dir

    @property
    def skip_steps(self) -> Set[str]:
        """Steps to skip by name."""
        return self._runtime_config.skip_steps

    @property
    def from_step(self) -> Optional[str]:
        """Step to roll back and restart from."""
        return self._runtime_config.from_step

    @property
    def stop_after(self) -> Optional[str]:
        """Stop workflow after this step completes."""
        return self._runtime_config.stop_after

    # =========================================================================
    # Override these for customization
    # =========================================================================

    def create_emitter(self, headless: bool = False, log_dir: Optional[Path] = None):
        """Create event emitter with terminal and file output.

        Adds terminal listener for interactive (non-headless) mode.
        Always adds file listener when log_dir is provided, so headless
        runs (e.g. eval matrix) produce debuggable JSONL logs.

        Args:
            headless: If True, skip terminal output
            log_dir: Directory for log files (workflow.log.jsonl)

        Returns:
            Event emitter instance with appropriate listeners
        """
        emitter = EventEmitter()

        # Add terminal output for interactive mode
        if not headless:
            emitter.add_listener(TerminalListener())

        # Always log to file when a log directory is available
        if log_dir:
            emitter.add_listener(FileListener(log_dir))

        return emitter

    def create_prompts(self) -> "Optional[Any]":
        """Override to provide custom prompt layer.

        Returns:
            Prompt layer instance for loading prompt templates, or None
        """
        return None

    def setup_environment(self) -> None:
        """Override to perform custom environment setup before workflow runs."""
        pass

    def on_workflow_complete(self, success: bool, output: Optional[O]) -> None:
        """Override to perform actions after workflow completes."""
        pass

    def on_workflow_actions(self, output: Optional[O]) -> None:
        """Override to show post-workflow actions (e.g., interactive menu).

        Called after successful non-nested, non-headless workflow completion.
        """
        pass

    def validate_step_input(self, input: Any, step: Step, ctx: Context) -> Any:
        """Override to add custom input validation.

        Returns validated/transformed input.
        """
        return input

    # =========================================================================
    # Internal Methods handling Workflow Lifecycle
    # =========================================================================

    def _emit_pr_hint(self) -> None:
        """Emit a PR creation hint if the target repo has modified tracked files."""
        if not self.ctx.base_dir:
            return
        try:
            repo_path = str(self.ctx.base_dir)
            status_result = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True,
                cwd=repo_path,
            )
            if status_result.returncode == 0 and status_result.stdout.strip():
                self.ctx.emit("blank")
                self.ctx.emit(
                    "info",
                    message="To open a PR, use the /pr skill once you've reviewed the changes.",
                )
                self.ctx.emit(
                    "info",
                    message="Note: Engineers are responsible for PRs they open and maintaining the resulting code.",
                )
        except (FileNotFoundError, OSError) as e:
            self.ctx.emit("warn", message=f"Failed to check git status for PR hint: {e}")

    def _start_run(self) -> None:
        self.start_time = time.time()
        self.ctx = self._setup()

        # Handle from_step rollback if specified
        self._handle_from_step_rollback()

        # Clear metrics if starting fresh (not resuming)
        if self.ctx.state and not self.ctx.state.get_completed_steps():
            self.ctx.state.clear_metrics()

        # Persist trace IDs set by the traced_workflow decorator so they're
        # available in state.json before any steps execute.
        if self.ctx.state:
            apm_id = getattr(self, "_pending_apm_trace_id", None)
            llmobs_id = getattr(self, "_pending_llmobs_trace_id", None)
            if apm_id and not self.ctx.state.apm_trace_id:
                self.ctx.state.apm_trace_id = apm_id
            if llmobs_id and not self.ctx.state.llmobs_trace_id:
                self.ctx.state.llmobs_trace_id = llmobs_id

        # Write state.json immediately so it exists even if the process is killed
        # before the finally block in run() executes (e.g. SIGKILL in CI).
        if self.ctx.state:
            self.ctx.state.save(self.ctx.base_dir)

        # Only emit workflow header for top-level workflows (not nested)
        if not self._is_nested:
            self.ctx.emit("workflow_start", name=f"{self.name}: {self.namespace}")

    def _handle_from_step_rollback(self) -> None:
        """Handle rolling back to from_step if specified in config."""
        from_step = self._runtime_config.from_step
        if not from_step or not self.ctx.state:
            return

        completed_steps = self.ctx.state.get_completed_steps()
        all_steps = self._build_unique_step_names()

        if not completed_steps:
            logger.info(f"No completed steps, ignoring from_step='{from_step}'")
            return

        # Resolve step name: exact match, then prefix match
        resolved = from_step if from_step in all_steps else None
        if not resolved:
            matches = [s for s in all_steps if s.startswith(from_step) or from_step.startswith(s)]
            if len(matches) == 1:
                resolved = matches[0]

        if not resolved:
            self.ctx.warn(f"Unknown step '{from_step}'. Available: {', '.join(all_steps)}")
            return

        # Allow --from on completed steps (re-run) and failed steps (retry)
        known_steps = {
            name
            for name, state in self.ctx.state.steps.items()
            if state.status in ("completed", "failed")
        }
        if resolved not in known_steps:
            self.ctx.warn(f"Step '{resolved}' not yet completed, resuming from last checkpoint")
            return

        try:
            # Optionally reset git files to checkpoint before state rollback
            # TODO: rename base_dir -> repo_root for clarity (base_dir is the repo path)
            if self._runtime_config.rollback_git:
                if self.ctx.state.rollback_files(resolved, self.ctx.base_dir):
                    self.ctx.info(f"Git files reset to checkpoint before '{resolved}'")
                else:
                    self.ctx.warn(
                        f"Git rollback failed for '{resolved}', continuing with state rollback"
                    )

            self.ctx.state.rollback(resolved, self.ctx.base_dir)
            self.ctx.state.save(self.ctx.base_dir)
            self.ctx.info(f"Rolling back to step '{resolved}'")
        except ValueError as e:
            self.ctx.warn(f"Failed to rollback to '{resolved}': {e}")

    def _finish_run(
        self, output: Optional[O], success: bool, error: Optional[Exception] = None
    ) -> Result[O]:
        duration = (time.time() - (self.start_time or time.time())) * 1000

        # Call hook for custom completion logic
        self.on_workflow_complete(success, output)

        # Squash intermediate commits and present changes unstaged for review.
        # Skip when stopped early via --stop-after to preserve checkpoint tags
        # needed for later --from resume; also skip when skip_git is set.
        if (
            success
            and not self._is_nested
            and not self._stopped_early
            and not self._runtime_config.skip_git
            and self.ctx.state
        ):
            if self.ctx.state.squash_and_unstage(repo_path=self.ctx.base_dir):
                self.ctx.success("\nAll intermediate commits squashed - changes are unstaged")
                self.ctx.info("Run 'git diff' to review changes, then commit when ready")

        # Log PR creation hint if workflow produced code changes in the target repo
        if (
            success
            and not self._is_nested
            and not self._stopped_early
            and not self.headless
            and not self._runtime_config.skip_git
        ):
            self._emit_pr_hint()

        if success:
            if not self._is_nested:
                self.ctx.emit_cost_summary()
                self.ctx.emit("workflow_complete", success=True)
            return Result.ok(cast(O, output), duration_ms=duration)
        else:
            if not self._is_nested:
                self.ctx.emit_cost_summary()
                self.ctx.emit("workflow_complete", success=False, message=str(error))
            self.ctx.error(f"Unexpected error: {error}")
            return Result.fail(str(error), duration_ms=duration)

    def _setup(self) -> Context:
        """Initialize context with all components."""
        # Call environment setup hook
        self.setup_environment()

        # Try to load existing state or create fresh
        # base_dir comes from config if not provided
        if self.base_dir:
            base_dir = self.base_dir
        else:
            config = get_config()
            base_dir = config.get_repo(self.repository).path
        # Use _state_name if provided (for unique state per nested workflow instance)
        state_workflow_name = self._state_name or self.name
        state = WorkflowState.load(state_workflow_name, self.namespace, base_dir)
        if state is None:
            state = WorkflowState(
                workflow=state_workflow_name,
                namespace=self.namespace,
                parent_workflow=self._parent_workflow,
            )

        # Handle user_prompt persistence for resume
        if self.user_prompt:
            # New prompt provided - use it and save to state
            state.user_prompt = self.user_prompt
        elif state.user_prompt:
            # No new prompt but state has one from previous run - restore it
            self.user_prompt = state.user_prompt

        # Handle base_branch persistence for resume
        if self.base_branch:
            state.base_branch = self.base_branch
        elif state.base_branch:
            data = self._runtime_config.model_dump()
            data["base_branch"] = state.base_branch
            self._runtime_config = WorkflowRuntimeConfig(**data)

        state.ensure_dirs(base_dir)

        # Ensure on dedicated workflow branch and mark start (only for top-level workflows).
        # skip_git=True disables all git operations (branch, commit, squash) — use for
        # eval workflows where concurrent threads share the same repo and would fight
        # over git index.lock.
        _branch_logs: List[str] = []
        if not self._is_nested and not self._runtime_config.skip_git:
            try:
                git = GitState(
                    state_workflow_name,
                    self.namespace,
                    repo_path=base_dir,
                    base_branch=self.base_branch,
                )
                _branch_logs = git.ensure_branch()
                state.current_branch = git.get_current_branch()
            except (subprocess.CalledProcessError, FileNotFoundError, OSError) as e:
                if self.base_branch:
                    logger.error("Branch checkout from base '%s' failed: %s", self.base_branch, e)
                    raise WorkflowError(
                        f"Failed to create branch from base '{self.base_branch}'. "
                        "Verify the branch exists in the target repository."
                    )
                logger.debug("Skipping branch management (not a git repo or git unavailable)")
            state.mark_workflow_start(repo_path=base_dir)

        # Inject parent artifacts into nested workflow state
        if self._parent_artifacts:
            for name, value in self._parent_artifacts.items():
                state.artifacts[name] = value

        # Get prompts: own create_prompts() OR inherited from parent OR global registry
        prompts = self.create_prompts()
        if prompts is None and self._parent_prompts is not None:
            prompts = self._parent_prompts
        if prompts is None:
            # Try global resource registry as final fallback
            bundle = get_global_resources(self.repository)
            if bundle is not None:
                prompts = bundle.prompts

        ctx = Context(
            workflow=self.name,
            namespace=self.namespace,
            repository=self.repository,
            parent_workflow=self._parent_workflow,
            config=self.config,
            state=state,
            prompts=prompts,
            base_dir=base_dir,
            headless=self.headless,
            _parent_context=self._parent_context,
        )

        # Restore type registry for Pydantic model rehydration on resume
        ctx.restore_type_registry()

        # Always create emitter with file logging (use state workflow name for eval isolation)
        workflow_log_dir = (
            base_dir / ".analysis" / self.namespace / state_workflow_name if base_dir else None
        )
        # Stored on self so run()'s finally can detach the tracer log handler
        # without re-deriving the path.
        self._workflow_log_dir = workflow_log_dir
        ctx.emitter = self.create_emitter(headless=self.headless, log_dir=workflow_log_dir)

        # Attach a per-workflow tracer log next to workflow.log.jsonl so tracer
        # diagnostics live in the same analysis dir as the run they belong to.
        # The global ~/.dd-apm/tracer.log keeps receiving the same records too;
        # this is purely an additional sink scoped to this run.
        if workflow_log_dir is not None:
            from anubis.core.tracing import (  # noqa: PLC0415
                attach_workflow_tracer_log,
                get_workflow_tracer_log_file,
            )

            attach_workflow_tracer_log(workflow_log_dir)
            # Surface the per-workflow log file paths so users know where to
            # tail for tracer / emitter diagnostics.
            try:
                ctx.emit("section", name="Workflow Logs")
                ctx.emit("detail", label="Analysis dir", value=str(workflow_log_dir))
                ctx.emit(
                    "detail",
                    label="Workflow log",
                    value=str(workflow_log_dir / "workflow.log.jsonl"),
                )
                ctx.emit(
                    "detail",
                    label="Tracer log",
                    value=str(get_workflow_tracer_log_file(workflow_log_dir)),
                )
                ctx.emit("blank")
            except Exception as e:
                logger.debug("Failed to emit workflow log paths: %s", e)

        # Store step_configs and model override in context so CompositeStep stages can access them
        ctx.set("_step_configs", self.step_configs)
        ctx.set("_model_override", self.model)
        ctx.set("_inject_experience", self._runtime_config.inject_experience)

        # Store runtime config for nested workflows to inherit
        ctx.set("_parent_runtime_config", self._runtime_config)

        # Auto-inject task spec fields for any workflow that has a TaskSpec in
        # its config. Prompts resolve ``{{spec_body}}``/``{{spec_path}}``/etc.
        # via ``fallback=ctx.get`` in ``PromptLoader.load``, so every spec-driven
        # workflow gets this for free without repeating ``ctx.set`` in setup().
        # Duck-typed: any object with an ``inject_into(ctx)`` method works,
        # so this stays generic over future spec-like resources.
        task_spec = self.config.get("task_spec") if self.config else None
        if task_spec is not None and hasattr(task_spec, "inject_into"):
            task_spec.inject_into(ctx)

        # Apply any ctx_overrides from config (key/value pairs pre-seeded into ctx state).
        # Used by eval runners to inject flags like agent_eval_account without subclassing.
        ctx_overrides = self.config.get("ctx_overrides") if self.config else None
        if ctx_overrides:
            for key, value in ctx_overrides.items():
                ctx.set(key, value)

        for msg in _branch_logs:
            ctx.info(msg)

        self._ctx = ctx
        return ctx

    # =========================================================================
    # Main workflow orchestration methods
    # =========================================================================

    @traced_workflow
    def run(self, input: Optional[I] = None) -> Result[O]:
        """Run the workflow. All orchestration handled automatically."""
        self._start_run()

        # Resolve the parent context at run() time. Workflows can be nested
        # either through a parent workflow's steps list or by a step function
        # constructing and running a child workflow directly. Both need the
        # child's agent metrics aggregated back into the active parent step.
        nested_parent_ctx: Optional[Context] = None
        if self._is_nested and self._parent_context is not None:
            nested_parent_ctx = self._parent_context
        elif self._is_nested and self._parent_workflow is None:
            auto_nested_parent = _active_workflow.get()
            if auto_nested_parent is not None:
                nested_parent_ctx = auto_nested_parent._ctx

        token = _active_workflow.set(self)

        # Snapshot nested state's run count so we only aggregate the delta
        # (new runs from this invocation), avoiding double-counting on resume.
        nested_runs_before = 0
        if nested_parent_ctx is not None and self._ctx and self._ctx.state:
            existing_metrics = self._ctx.state.get_metrics()
            if existing_metrics:
                nested_runs_before = len(existing_metrics.get("agent_runs", []))

        try:
            output = self._execute_steps(input)
            return self._finish_run(output, True)
        except (WorkflowError, Exception) as e:
            return self._finish_run(None, False, e)
        finally:
            _active_workflow.reset(token)
            # Detach the per-workflow tracer log handler so it doesn't leak
            # into a subsequent workflow run in the same process. The global
            # ~/.dd-apm/tracer.log keeps capturing across runs.
            wf_log_dir = getattr(self, "_workflow_log_dir", None)
            if wf_log_dir is not None:
                from anubis.core.tracing import detach_workflow_tracer_log  # noqa: PLC0415

                detach_workflow_tracer_log(wf_log_dir)
            # Aggregate nested metrics into the parent step. This covers both
            # workflows declared in a parent's steps list and workflows created
            # directly inside a step function.
            # Wrapped in try/except to avoid suppressing original exceptions or
            # preventing state save and terminal restore below.
            if nested_parent_ctx is not None:
                try:
                    self._aggregate_nested_metrics_delta(nested_parent_ctx, nested_runs_before)
                except Exception as e:
                    logger.warning("Failed to auto-aggregate nested metrics: %s", e)
            # Save state on completion
            if self.ctx.state:
                self.ctx.state.save(self.ctx.base_dir)
            # Always restore terminal to normal state (handles errors/interrupts)
            restore_terminal_for_input()

    def _execute_steps(self, input: Any) -> O:
        """Execute all steps with validation and reset handling."""
        current = input
        step_index = 0
        # Build unique step names (append _2, _3, etc. for duplicates)
        step_names = self._build_unique_step_names()
        total_steps = len(self.steps)

        while step_index < len(self.steps):
            StepClass = self.steps[step_index]
            is_workflow = isinstance(StepClass, type) and issubclass(StepClass, Workflow)

            # Create step instance and apply config overrides if present
            if not is_workflow:
                step_instance = StepClass()
                step_instance.step_override_config(self.step_configs)
                # Apply workflow-level model override (per-step config takes precedence)
                if (
                    self.model
                    and hasattr(step_instance, "model")
                    and "model" not in self.step_configs.get(step_instance.name, {})
                ):
                    step_instance.model = self.model
            else:
                step_instance = None

            step_num = step_index + 1
            step_name = step_names[step_index]  # Use unique name from pre-built list
            base_name = getattr(
                StepClass,
                "name",
                StepClass.__name__.lower().replace("workflow", "").replace("step", ""),
            )
            display_name = base_name.replace("_", " ").title()

            # Auto-inject step input into ctx (namespaced + flat fields)
            self.ctx.set(f"{step_name}_input", current)
            _inject_model_into_ctx(current, self.ctx)

            try:
                result = self._check_skip_step(
                    step_instance if not is_workflow else StepClass,
                    step_name,
                    step_num,
                    total_steps,
                    current,
                )

                if result["completed"] or result["user_skipped"]:
                    output = result["output"]
                else:
                    if not self._is_nested:
                        self.ctx.emit(
                            "phase_start", phase=display_name, number=step_num, total=total_steps
                        )
                    if is_workflow:
                        output = self._run_nested_step(StepClass, step_name, current)
                    else:
                        assert step_instance is not None
                        output = self._run_step(step_instance, step_name, current)

                    if not self._is_nested:
                        self.ctx.emit(
                            "phase_complete", phase=display_name, success=True, output=output
                        )

                output = self.after_step(step_name, output, self.ctx)

                # Auto-inject step output into ctx (namespaced + flat fields)
                if output is not None:
                    self.ctx.set(f"{step_name}_output", output)
                    _inject_model_into_ctx(output, self.ctx)

                current = output
                step_index += 1

                if self.stop_after and step_name == self.stop_after:
                    self._stopped_early = True
                if self._stopped_early:
                    break

            except ResetToStep as reset:
                step_index = self._reset_to_step(step_names, reset)
            except HaltSignal as halt_signal:
                self._handle_halt(halt_signal.halt, step_name)
            except WorkflowError:
                raise
            except Exception as e:
                self.ctx.error(f"Step failed: {e}")
                raise WorkflowError(f"Step '{step_name}' failed: {e}")

        return cast(O, current)

    def _run_nested_step(self, StepClass: type, step_name: str, input: Any) -> O:
        """Run a nested workflow as a step."""
        # Set current_step so metrics can be tracked (same as _run_step)
        self.ctx.current_step = step_name
        if self.ctx.state:
            self.ctx.state.current_step = step_name
            self.ctx.state.save(self.ctx.base_dir)

        try:
            # Pass parent artifacts to nested workflow so it can access them
            parent_artifacts = self.ctx.state.artifacts if self.ctx.state else {}

            nested = StepClass(
                namespace=self.namespace,
                repository=self.repository,
                headless=self.headless,
                model=self.model,
                user_prompt=self.user_prompt,
                config=self.config,
                base_dir=self.ctx.base_dir,
                step_configs=self.step_configs,
                skip_steps=self.skip_steps,
                stop_after=self._runtime_config.stop_after,
                from_step=self._runtime_config.from_step,
                rollback_git=self._runtime_config.rollback_git,
                _is_nested=True,
                _parent_workflow=self.name,
                _parent_artifacts=parent_artifacts,
                _parent_prompts=self.ctx.prompts,
                _parent_context=self.ctx,  # Enable artifact inheritance
                _state_name=step_name,  # Use unique step name for state path
            )
            result = nested.run(input)

            if nested._stopped_early:
                self._stopped_early = True

            self._aggregate_nested_artifacts(nested, self.ctx)

            if not result.success:
                raise WorkflowError(f"Nested workflow '{step_name}' failed: {result.error}")

            output = result.output

            flush_tracked_paths(self.ctx)
            if self.ctx.state:
                git_repo = None if self._runtime_config.skip_git else self.ctx.base_dir
                self.ctx.state.checkpoint(step_name, output, repo_path=git_repo)
                self.ctx.state.save(self.ctx.base_dir)

            return cast(O, output)

        except WorkflowError:
            raise
        except Exception as e:
            raise WorkflowError(f"Nested workflow '{step_name}' failed: {e}")

    def _run_step(self, step: Step, unique_step_name: str, input: Any) -> O:
        """Run a single step with checkpointing.

        Args:
            step: Step instance to run
            unique_step_name: Unique step name (with _2, _3 suffix for duplicates)
            input: Input to the step
        """
        self.ctx.current_step = unique_step_name
        # Update state with current step and persist
        if self.ctx.state:
            self.ctx.state.current_step = unique_step_name
            self.ctx.state.save(self.ctx.base_dir)

        # Determine if this is an agent step or regular task based on step_type
        is_agent_step = getattr(step, "step_type", "task") == "agent"
        llmobs_span = llmobs_agent if is_agent_step else llmobs_task

        # LLMObs span (agent or task based on step type)
        with llmobs_span(unique_step_name, input_data=serialize_for_llmobs(input)) as span:
            # Add step tags
            if span:
                model = getattr(step, "model", None)
                tag_step_span(
                    span,
                    step_name=unique_step_name,
                    workflow_name=self.name,
                    namespace=self.namespace,
                    parent_workflow=self._parent_workflow,
                    model=model,
                    repository=self.repository,
                )

            try:
                input = self.validate_step_input(input, step, self.ctx)
                input = step.before_execute(input, self.ctx)
                output = step.run(input, self.ctx)
                output = step.after_execute(output, self.ctx)
                flush_tracked_paths(self.ctx)
                if self.ctx.state:
                    git_repo = None if self._runtime_config.skip_git else self.ctx.base_dir
                    self.ctx.state.checkpoint(unique_step_name, output, repo_path=git_repo)
                    self.ctx.state.save(self.ctx.base_dir)

                llmobs_annotate(output_data=serialize_for_llmobs(output))
                return cast(O, output)

            except HaltSignal:
                raise
            except Exception as e:
                self.ctx.error(f"Step failed: {e}")
                raise WorkflowError(f"Step '{unique_step_name}' failed: {e}")

    def _check_skip_step(
        self, step: Any, unique_step_name: str, step_num: int, total_steps: int, current: Any
    ) -> dict:
        """Check if a step should be skipped (user-specified or already completed).

        Args:
            step: Step instance or class
            unique_step_name: Unique step name (with _2, _3 suffix for duplicates)
            step_num: Step number (1-indexed)
            total_steps: Total steps in workflow
            current: Current input value
        """
        base_name = step.name
        display_name = base_name.replace("_", " ").title()
        skip_steps = self.skip_steps
        result = {
            "user_skipped": False,
            "completed": False,
            "output": current,
        }
        if hasattr(step, "_bind_contextual_output_type"):
            step._bind_contextual_output_type(self.ctx)
        # Check skip by base name (user specifies base names)
        if base_name in skip_steps:
            result["user_skipped"] = True
            self.ctx.info(f"Skipping step: {base_name} (user specified)")
        # Check completion by unique name (state tracks unique names)
        elif self.ctx.state and self.ctx.state.is_completed(unique_step_name):
            result["completed"] = True
            saved_output = self.ctx.state.get_output(unique_step_name)
            output_type = getattr(step, "output_type", None)
            if output_type and isinstance(saved_output, dict):
                try:
                    result["output"] = output_type.model_validate(saved_output)
                except Exception:
                    result["output"] = saved_output
            else:
                result["output"] = saved_output
        if not self._is_nested and (result["user_skipped"] or result["completed"]):
            reason = "user_skipped" if result["user_skipped"] else "completed"
            self.ctx.emit(
                "phase_skip", phase=display_name, number=step_num, total=total_steps, reason=reason
            )
            span = tracer.current_span()
            if span:
                span.set_tag(f"step.{unique_step_name}.skipped", "True")
                span.set_tag(f"step.{unique_step_name}.skip_reason", reason)
        return result

    def _build_unique_step_names(self) -> List[str]:
        """Build list of unique step names, appending _2, _3, etc. for duplicates."""
        names: List[str] = []
        seen: Dict[str, int] = {}
        for step_cls in self.steps:
            base_name = getattr(
                step_cls,
                "name",
                step_cls.__name__.lower().replace("workflow", "").replace("step", ""),
            )
            if base_name in seen:
                seen[base_name] += 1
                unique_name = f"{base_name}_{seen[base_name]}"
            else:
                seen[base_name] = 1
                unique_name = base_name
            names.append(unique_name)
        return names

    # =========================================================================
    # Reset to step support
    # =========================================================================

    def _reset_to_step(self, step_names: List[str], reset: ResetToStep) -> int:
        """Reset the workflow to a specific step."""
        if reset.step_name not in step_names:
            raise WorkflowError(f"Cannot reset to unknown step: {reset.step_name}")

        reset_index = step_names.index(reset.step_name)
        self.ctx.info(f"Resetting to step: {reset.step_name}")
        self.ctx.emit("workflow_reset", to_step=reset.step_name, guidance=reset.guidance)

        if reset.guidance:
            self.ctx.set("reviewer_guidance", reset.guidance)

        if self.ctx.state:
            reset_step = step_names[reset_index]
            self.ctx.state.rollback(reset_step, self.ctx.base_dir)
        return reset_index

    # =========================================================================
    # Structured halt support (manual mode — PR1)
    # =========================================================================

    def _handle_halt(self, halt: StructuredHalt, step_name: str) -> None:
        """Persist a structured halt and raise ``WorkflowError`` with the artifact.

        Manual recovery: the workflow exits non-zero; the engineer reads the
        printed artifact and reruns from the consuming step. Auto-recovery
        (``ResetToStep`` to ``consumable_by[0]`` under ``--headless``) is a
        future PR — when it lands, this method gets a branch on ``ctx.headless``
        and the manual path stays as the fallback.
        """
        log_dir = getattr(self, "_workflow_log_dir", None) or self.ctx.base_dir
        feedback_path: Optional[Path] = log_dir / "feedback.jsonl" if log_dir is not None else None
        run_id = getattr(self.ctx.state, "run_id", None) if self.ctx.state else None
        if feedback_path is not None:
            store = FeedbackStore(feedback_path)
            try:
                store.append(halt, run_id=run_id)
            except OSError as exc:
                # Persistence is best-effort — we still want to surface the halt
                # to the engineer even if the disk is misbehaving.
                self.ctx.warn(f"Could not persist halt to {feedback_path}: {exc}")

        self.ctx.emit(
            "halt",
            step=halt.step,
            reason=halt.reason,
            consumable_by=halt.consumable_by,
            artifact_path=str(feedback_path) if feedback_path is not None else "",
        )

        rerun_target = halt.consumable_by[0] if halt.consumable_by else step_name
        lines = [
            f"⛔ {halt.step} halted: {halt.reason}",
            f"   detail: {halt.detail}",
            f"   needs:  {halt.needs}",
        ]
        if halt.suggestion:
            lines.append(f"   suggestion: {halt.suggestion}")
        lines.append(f"   to rerun: restart workflow from step '{rerun_target}'")
        if feedback_path is not None:
            lines.append(f"   artifact: {feedback_path}")
        raise WorkflowError("\n".join(lines))

    # =========================================================================
    # Nested workflow support
    # =========================================================================

    def _aggregate_nested_metrics_delta(self, parent_ctx: Context, runs_before: int) -> None:
        """Aggregate only new metrics from this run into the parent workflow.

        Nested workflow state can already contain prior runs when a workflow
        resumes. Only aggregating the delta keeps parent step metrics accurate
        without double-counting previously checkpointed child agent runs.

        Args:
            parent_ctx: The parent context to aggregate into.
            runs_before: Number of agent_runs in this workflow's state before
                        this invocation started.
        """
        if not self._ctx or not self._ctx.state:
            return

        nested_metrics = self._ctx.state.get_metrics()
        if not nested_metrics:
            return

        all_runs = nested_metrics.get("agent_runs", [])
        # Only aggregate runs added during this invocation
        new_runs = all_runs[runs_before:]
        if not new_runs:
            return

        new_cost = sum(r.get("cost_usd", 0) for r in new_runs)

        if parent_ctx.state and parent_ctx.current_step:
            step_state = parent_ctx.state.get_step(parent_ctx.current_step)
            for run_dict in new_runs:
                run = AgentRun.model_validate(run_dict)
                step_state.metrics.add_agent_run(run)
            parent_ctx.state.update_totals()
        elif parent_ctx.state:
            parent_ctx.state.add_metrics({
                "total_cost_usd": new_cost,
                "total_duration_seconds": sum(r.get("duration_seconds", 0) for r in new_runs),
                "total_input_tokens": sum(r.get("input_tokens", 0) for r in new_runs),
                "total_output_tokens": sum(r.get("output_tokens", 0) for r in new_runs),
                "total_cache_read_input_tokens": sum(
                    r.get("cache_read_input_tokens", 0) for r in new_runs
                ),
            })

        if new_cost > 0 or len(new_runs) > 0:
            parent_ctx.info(
                f"Aggregated {len(new_runs)} new agent runs (${new_cost:.4f}) from {self.name}"
            )

    def _aggregate_nested_artifacts(self, nested: "Workflow", parent_ctx: Context) -> None:
        """Aggregate artifacts from a nested workflow into the parent context."""
        if not nested._ctx or not nested._ctx.state:
            return

        nested_artifacts = nested._ctx.state.artifacts
        if not nested_artifacts:
            return

        # Copy artifacts from nested workflow to parent workflow state
        if parent_ctx.state:
            for name, path in nested_artifacts.items():
                parent_ctx.state.artifacts[name] = path

    # =========================================================================
    # Review hooks (override as needed)
    # =========================================================================

    def after_step(self, step_name: str, output: Any, ctx: Context) -> Any:
        """Called after each step completes. Override to add review logic.

        Can modify output or raise ResetToStep to reset workflow.
        """
        return output

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def ctx(self) -> Context:
        """Get the workflow context."""
        if not self._ctx:
            raise RuntimeError("Workflow context not initialized - call run() first")
        return self._ctx

    @ctx.setter
    def ctx(self, value: Context):
        self._ctx = value
