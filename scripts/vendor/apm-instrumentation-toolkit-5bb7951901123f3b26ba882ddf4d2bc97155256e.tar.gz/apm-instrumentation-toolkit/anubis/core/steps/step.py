"""Step - base class for workflow steps."""

import json
import re
from abc import abstractmethod
from typing import TYPE_CHECKING, Any, List, Optional, Type, TypeVar, cast

from pydantic import BaseModel

from ..agents import spawn_agent
from ..tracing import llmobs_agent
from ..validation import pydantic_validator
from .executors import StepExecutor

if TYPE_CHECKING:
    from ..context import Context
    from ..types import ValidatorFn

I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)


def _camel_to_snake(name: str) -> str:
    """Convert CamelCase to snake_case."""
    # Insert underscore before uppercase letters and lowercase the result
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


class Step(StepExecutor[I, O]):
    """A unit of work in a workflow: Input -> Output.

    Basic Usage:
        class MyStep(Step):
            name = "my_step"
            output_type = MyOutput

            def execute(self, input, ctx):
                return MyOutput(...)

    With Validation:
        class MyStep(Step):
            name = "my_step"
            output_type = MyOutput
            fixer_prompt = "my-fixer"  # Enable auto-fix on validation failure

    Batch Execution:
        class MyBatchStep(Step):
            name = "my_batch"
            batch_execute = True
            batch_size = 4  # Parallel workers (1 = sequential)

            def prepare_batch(self, input, ctx):
                return [item1, item2, ...]  # Items to process
    """

    # Required: Override in subclass
    name: str = "step"
    step_type: str = "task"  # "task" or "agent" - used for LLMObs span type

    # Optional: Type hints for input/output
    input_type: Optional[Type[I]] = None
    output_type: Optional[Type[O]] = None

    # Optional: Validation
    validators: List["ValidatorFn"] = []
    fixer_prompt: Optional[str] = None
    fixer_model: str = "haiku"
    max_fixer_iterations: int = 3
    validation_required: bool = True

    # Optional: Batch execution
    batch_execute: bool = False
    batch_size: int = 1

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Auto-infer name from class name if not explicitly set
        if "name" not in cls.__dict__:
            cls.name = _camel_to_snake(cls.__name__)
        # Add pydantic_validator as default if output_type is defined
        if cls.output_type and pydantic_validator not in cls.validators:
            cls.validators = [pydantic_validator] + list(cls.validators)

    # -------------------------------------------------------------------------
    # Override these
    # -------------------------------------------------------------------------

    @abstractmethod
    def execute(self, input: I, ctx: "Context") -> O:
        """Execute the step. Return output or raise exception."""
        pass

    def before_execute(self, input: I, ctx: "Context") -> I:
        """Hook: Transform input before execute."""
        return input

    def after_execute(self, output: O, ctx: "Context") -> O:
        """Hook: Transform output after execute."""
        return output

    def prepare_batch(self, input: Any, ctx: "Context") -> Optional[List[Any]]:
        """Hook: Return list of items for batch execution."""
        return input if isinstance(input, list) else None

    def aggregate_batch(self, results: list, ctx: "Context") -> Any:
        """Hook: Combine batch results. Default returns list."""
        return results

    def can_fix(self) -> bool:
        """Return True if this step can fix validation errors."""
        return bool(self.fixer_prompt)

    def step_override_config(self, step_configs: dict) -> None:
        """Apply configuration overrides to this step instance.

        Looks up config for this step's name in step_configs and applies
        any attribute overrides found.

        Args:
            step_configs: Dictionary mapping step names to config dicts
                         e.g., {'diagnosis': {'sandbox': False}}
        """
        if not step_configs or self.name not in step_configs:
            return

        config_overrides = step_configs[self.name]
        for attr_name, attr_value in config_overrides.items():
            setattr(self, attr_name, attr_value)

    def fix_output(self, input: I, output: O, errors: List[str], ctx: "Context") -> O:
        """Fix invalid output. Default spawns fixer agent.

        Uses ctx.prompts for prompt loading (must be injected by application).
        """
        if not ctx.prompts:
            raise RuntimeError("Context.prompts not configured - required for fixer")

        if not ctx.prompts.exists(self.fixer_prompt):
            raise RuntimeError(f"Fixer prompt not found: {self.fixer_prompt}")

        # Format validation errors and current output for template
        error_text = "\n".join(f"- {e}" for e in errors)
        if isinstance(output, BaseModel):
            current_output = output.model_dump_json(indent=2)
        else:
            current_output = json.dumps(output, indent=2, default=str)

        prompt = ctx.prompts.load(
            self.fixer_prompt,
            output_schema=self.output_type,
            package_name=ctx.namespace,
            validation_errors=error_text,
            current_output=current_output,
        )

        # Get working directory from state
        working_dir = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir

        # Wrap with LLMObs agent span for observability
        with llmobs_agent(
            name=f"{self.name}_fixer",
            session_id=f"{ctx.namespace}:{self.name}:fixer"
            if ctx.namespace
            else f"{self.name}:fixer",
            input_data={"step": self.name, "phase": "fixer", "namespace": ctx.namespace},
        ):
            result = spawn_agent(
                task_description=f"{self.name}_fixer",
                prompt=prompt,
                working_directory=working_dir,
                emitter=ctx,
                timeout_minutes=30,
                model=self.fixer_model,
                output_schema=self.output_type,
                log_dir=self._get_fixer_log_dir(ctx),
                extra_env=getattr(ctx, "_agent_extra_env", {}),
                permission_deny=ctx.get("agent_permission_deny") or [],
                repository=ctx.repository,
                repo_adapter=getattr(ctx, "repo_adapter", None),
            )

        if not result.success:
            raise RuntimeError(result.error or "Fixer agent failed")
        return cast(O, result.structured_output)

    # -------------------------------------------------------------------------
    # Entry point (don't override)
    # -------------------------------------------------------------------------

    def run(self, input: I, ctx: "Context") -> O:
        """Execute the step. Routes to batch or single execution."""
        self._bind_contextual_output_type(ctx)
        if self.batch_execute:
            return cast(O, self._run_batch(input, ctx))
        return cast(O, self._run_one(input, ctx))
