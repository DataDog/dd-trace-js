"""CompositeStep - runs multiple steps in sequence with optional looping."""

from typing import TYPE_CHECKING, Any, List, Type, TypeVar, cast

from pydantic import BaseModel

from ..resources import flush_tracked_paths
from .step import Step

if TYPE_CHECKING:
    from ..context import Context

I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)


class CompositeStep(Step[I, O]):
    """Step that runs multiple stages in sequence, with optional looping.

    Basic Usage:
        class MyPipeline(CompositeStep):
            name = "my_pipeline"
            stages = [StageA, StageB, StageC]

    With Looping:
        class TestFixer(CompositeStep):
            name = "test_fixer"
            max_iterations = 10
            stages = [DiagnosisStage, FixerStage]

            def should_continue(self, output, ctx):
                return not output.tests_passing

    Without Multi Stages, just custom iteration logic:
        class CustomLoop(CompositeStep):
            name = "custom_loop"
            max_iterations = 5
            stages = [my-single-stage-I-want-to-loop]
    """

    # Configuration
    stages: List[Type[Step]] = []
    max_iterations: int = 1

    # -------------------------------------------------------------------------
    # Override these
    # -------------------------------------------------------------------------

    def before_iteration(self, iteration: int, input: I, ctx: "Context") -> I:
        """Hook: Prepare input for each iteration."""
        return input

    def after_stage_execute(self, stage_name: str, output: Any, ctx: "Context") -> Any:
        """Hook: Transform output after each stage step executes."""
        return output

    def after_iteration(self, iteration: int, output: Any, ctx: "Context") -> Any:
        """Hook: Transform output between iterations."""
        return output

    def should_exit_early(self, stage_name: str, output: Any, ctx: "Context") -> bool:
        """Hook: Check if pipeline should exit early after a stage."""
        return False

    def should_continue(self, output: Any, ctx: "Context") -> bool:
        """Hook: Check if we should continue to next iteration."""
        return False

    # -------------------------------------------------------------------------
    # Implementation (don't override)
    # -------------------------------------------------------------------------

    def execute(self, input: I, ctx: "Context") -> O:
        """Execute stages with optional looping."""
        # Capture parent attempt before we start (used in stage_key)
        parent_attempt = ctx.current_attempt

        # Reset iteration state (important for batch execution where
        # multiple items share context in sequential mode)
        ctx.set(f"{self.name}_iteration", 0)
        ctx.set(f"{self.name}_parent_attempt", parent_attempt)

        # Allow input to override max_iterations before the range is computed.
        # before_iteration does this too but runs after range() is evaluated.
        if hasattr(input, "max_iterations") and isinstance(input.max_iterations, int):
            self.max_iterations = input.max_iterations

        output = None
        for iteration in range(1, self.max_iterations + 1):
            self._set_iteration(ctx, iteration)

            if self.max_iterations > 1:
                ctx.info(f"Iteration {iteration}/{self.max_iterations}")

            input = self.before_iteration(iteration, input, ctx)
            output = self._run_stages(input, ctx)
            if output is None:  # Early exit
                return cast(O, output)

            if not self.should_continue(output, ctx):
                break

            output = self.after_iteration(iteration, output, ctx)
            input = output  # Pass output to next iteration's before_iteration

        if self.max_iterations > 1:
            ctx.metric(f"{self.name}_iterations", iteration)

        return cast(O, output)  # Don't call after_execute here - StepExecutor._run_one handles it

    def _run_stages(self, input: Any, ctx: "Context") -> Any:
        """Run all stages in sequence with checkpoint-based resumption."""
        current = input
        iteration = ctx.get(f"{self.name}_iteration", 1)
        parent_attempt = ctx.get(f"{self.name}_parent_attempt", 1)

        for StageClass in self.stages:
            stage = StageClass()
            # Apply step configs from context (set by workflow)
            step_configs = ctx.get("_step_configs", {})
            stage.step_override_config(step_configs)
            # Apply workflow-level model override (per-step config takes precedence)
            model_override = ctx.get("_model_override")
            if (
                model_override
                and hasattr(stage, "model")
                and "model" not in step_configs.get(stage.name, {})
            ):
                stage.model = model_override
            # Include parent attempt to avoid cache collision across attempts
            stage_key = f"{self.name}:att{parent_attempt}:iter{iteration}:{stage.name}"

            # Resume: skip if stage already completed
            if ctx.state and ctx.state.is_completed(stage_key):
                ctx.info(f"Resuming: {stage.name} (cached)")
                cached = ctx.state.get_output(stage_key)
                stage._bind_contextual_output_type(ctx)

                # Rehydrate cached dicts back to Pydantic models
                if (
                    isinstance(cached, dict)
                    and stage.output_type
                    and hasattr(stage.output_type, "model_validate")
                ):
                    try:
                        cached = stage.output_type.model_validate(cached)
                    except Exception as e:
                        ctx.emit(
                            "warn",
                            message=f"Cached output rehydration failed for {stage.name}: {e}",
                        )

                # Only check exit condition for cached outputs.
                # Skip after_stage_execute() — it already ran before checkpoint
                # and replaying it would duplicate side effects (e.g., appending
                # to diagnosis_history on resume).
                if self.should_exit_early(stage.name, cached, ctx):
                    return cached

                current = cached
                continue

            ctx.emit("stage_start", stage=stage.name)

            # Update current step in state and persist
            ctx.current_step = stage_key
            if ctx.state:
                ctx.state.current_step = stage_key
                ctx.state.save(ctx.base_dir)

            # Validate dict inputs against stage's expected input type
            current = self._validate_stage_input(current, stage, ctx)

            try:
                output = stage.run(current, ctx)
                ctx.emit("stage_complete", stage=stage.name, success=True)

                # Flush prompt tracked paths before checkpoint so config
                # hashing has complete data when manifest is built.
                flush_tracked_paths(ctx)

                # Checkpoint stage and persist to disk
                if ctx.state:
                    ctx.state.checkpoint(stage_key, output, repo_path=ctx.base_dir)
                    ctx.state.save(ctx.base_dir)

            except Exception:
                ctx.emit("stage_complete", stage=stage.name, success=False)
                raise

            output = self.after_stage_execute(stage.name, output, ctx)

            if self.should_exit_early(stage.name, output, ctx):
                return output  # Don't call after_execute here - StepExecutor._run_one handles it

            current = output

        return current

    def _set_iteration(self, ctx: "Context", iteration: int) -> None:
        """Update context with current iteration info."""
        ctx.set(f"{self.name}_iteration", iteration)
        ctx.set("current_iteration", iteration)
        ctx.set("iteration", iteration)  # For backwards compatibility
        ctx.current_attempt = iteration
        ctx.set("_parent_step", self.name)

    def _validate_stage_input(self, input: Any, stage: Step, ctx: "Context") -> Any:
        """Convert dict input to model if stage declares input_type."""
        if not isinstance(input, dict):
            return input

        # Try input_type attribute first
        input_type = getattr(stage, "input_type", None)

        # Fall back to first generic arg (e.g., AgentStep[ReviewAnalysis, ...])
        if not input_type:
            orig_bases = getattr(type(stage), "__orig_bases__", ())
            for base in orig_bases:
                args = getattr(base, "__args__", None)
                if args and len(args) >= 1:
                    candidate = args[0]
                    if isinstance(candidate, type) and issubclass(candidate, BaseModel):
                        input_type = candidate
                        break

        if input_type and hasattr(input_type, "model_validate"):
            try:
                return input_type.model_validate(input)
            except Exception as e:
                # Validation failed - keep as dict and continue (agent may accept dict input)
                ctx.emit("warn", message=f"Stage input validation failed for {stage.name}: {e}")

        return input
