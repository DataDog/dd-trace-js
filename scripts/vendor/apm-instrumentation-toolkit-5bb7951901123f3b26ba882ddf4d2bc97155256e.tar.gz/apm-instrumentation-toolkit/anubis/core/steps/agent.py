"""AgentStep - step that runs an AI agent."""

from typing import TYPE_CHECKING, Any, List, Optional, TypeVar

from pydantic import BaseModel

from .executors import AgentStepExecutor
from .step import Step

if TYPE_CHECKING:
    from ..context import Context

I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)


class AgentStep(AgentStepExecutor[I, O], Step[I, O]):
    """Step that runs an AI agent.

    Usage:
        class MyAgentStep(AgentStep):
            name = "my_agent"
            prompt = "my-prompt"      # Prompt template name (loaded via ctx.prompts)
            output_type = MyOutput    # Pydantic model
            output_file = "out.json"  # Where to save result

    With custom variables:
        def get_prompt_variables(self, input, ctx):
            return {'custom_var': 'value'}
    """

    # Required
    prompt: str = ""
    step_type: str = "agent"  # Override: agent steps are traced as LLMObs agent spans

    # Optional: Output persistence
    output_file: Optional[str] = None
    required_files: List[str] = []

    # Optional: Agent configuration
    skills: Optional[List[str]] = []
    timeout_minutes: int = 30
    max_turns: int = 100
    model: str = "sonnet"
    use_repo_root: bool = False
    sandbox: bool = True
    planning: bool = False  # If True, run planning phase first (read-only, all skills)
    save_spec: bool = False  # If True, save rendered prompt as a spec artifact for downstream steps

    # -------------------------------------------------------------------------
    # Override these
    # -------------------------------------------------------------------------

    def get_prompt_variables(self, input: Any, ctx: "Context") -> dict:
        """Override to add custom prompt variables."""
        return {}

    # -------------------------------------------------------------------------
    # Implementation (don't override)
    # -------------------------------------------------------------------------

    def can_fix(self) -> bool:
        """AgentSteps can fix by re-running with error context."""
        return bool(self.prompt)

    def execute(self, input: I, ctx: "Context") -> O:
        """Run agent, optionally save output, return result."""
        cached = self._load_cached_output(ctx)
        if cached:
            return cached

        # Phase 1: Planning (if enabled)
        if self.planning:
            plan = self._run_planning_phase(input, ctx)
            ctx.set("plan", plan)
            ctx.info(f"Planning phase complete ({len(plan)} chars)")

        # Phase 2: Implementation
        prompt = self._build_prompt(input, ctx)
        if self.save_spec:
            batch_id = ctx.get("_batch_item_id", "")
            suffix = f"-{batch_id}" if batch_id else ""
            ctx.save_artifact(f"{self.name}-spec{suffix}", prompt)
        output = self._spawn_agent(prompt, ctx)
        self._save_output(output, ctx)

        # Clear retry-related context after successful execution
        # This prevents guidance from affecting subsequent steps/runs
        ctx.set("previous_output", None)

        return output

    def fix_output(self, input: I, output: O, errors: List[str], ctx: "Context") -> O:
        """Re-run agent with validation errors in context."""
        ctx.set(f"{self.name}_error_prompt", self._format_validation_errors(errors, output))

        output_file = ctx.get("_output_file") or self.output_file
        if output_file:
            root_path = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir
            if root_path:
                output_path = root_path / output_file
                if output_path.exists():
                    output_path.unlink()

        # Check if we have a session to resume
        session_id = ctx.get(f"{self.name}_session_id")
        if session_id:
            ctx.info(
                f"Re-running agent with validation feedback (resuming session {session_id[:8]}...)"
            )
        else:
            ctx.info("Re-running agent with validation feedback (new session)")
        return self.execute(input, ctx)
