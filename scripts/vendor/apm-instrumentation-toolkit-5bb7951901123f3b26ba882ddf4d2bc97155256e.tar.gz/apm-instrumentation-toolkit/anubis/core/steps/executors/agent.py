"""Agent step executor - internal mechanics for AI agent steps."""

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, TypeVar, cast

from pydantic import BaseModel

from ...agents import spawn_agent
from ...agents.eval_proxy import ensure_eval_proxy_running, resolve_model_alias
from ...errors import StructuredOutputError
from ...resources.skills import SkillLoader
from ...tracing import llmobs_annotate
from .base import StepExecutor

if TYPE_CHECKING:
    from ...context import Context

I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)


# Planning phase prefix - prepended to prompt when planning=True
PLANNING_PREFIX = """
## PLANNING PHASE (Read-Only)

Before implementing, create a detailed plan.

### Step 1: Read Skills
Read ALL relevant skills in `.claude/skills/` to understand patterns and best practices.
These skills contain critical implementation guidance - DO NOT skip this step.

### Step 2: Read Reference Files
Read reference implementations and existing code mentioned in the prompt to understand patterns.

### Step 3: Create Plan
Based on skills and references, outline:
- Files to create/modify (with full paths)
- Implementation steps in order
- Key patterns to follow from references
- Potential challenges and how to address them

Output your detailed plan, then STOP. Do not write any code yet.

---

"""


class AgentStepExecutor(StepExecutor[I, O]):
    """Internal mechanics for AgentStep.

    Handles:
    - Loading cached output
    - Building prompts with variables
    - Spawning agents
    - Saving output
    """

    # Agent-specific attributes (defined in AgentStep subclass, defaults here for type checking)
    output_file: Optional[str] = None
    prompt: str = ""
    max_turns: int = 25
    use_repo_root: bool = False
    required_files: Optional[List[str]] = None
    timeout_minutes: int = 30
    model: str = "sonnet"

    def _load_cached_output(self, ctx: "Context") -> Optional[O]:
        """Load output from file if it exists.

        This allows resuming from human review or other validators without
        re-running the agent. If the output file exists (even if step isn't
        marked complete), we load it and skip the agent execution.

        Does NOT load cached output if:
        - reviewer_guidance is set (user requested retry with guidance)
        """
        # Skip cache if user requested retry with guidance
        if ctx.get("reviewer_guidance"):
            return None

        output_file = ctx.get("_output_file") or self.output_file
        if not output_file:
            return None

        root_path = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir
        if not root_path:
            return None
        output_path = root_path / output_file
        if not output_path.exists():
            return None

        # Output file exists - load it (could be from completed step or interrupted validation)
        step_completed = ctx.state and ctx.state.is_completed(self.name) if ctx.state else False
        if step_completed:
            ctx.info(
                f"Output already exists: {ctx.state.relative(output_path, ctx.base_dir) if ctx.state else output_file}"
            )
        else:
            ctx.info(
                f"Resuming from saved output: {ctx.state.relative(output_path, ctx.base_dir) if ctx.state else output_file}"
            )

        try:
            with open(output_path) as f:
                output_type = self.output_type
                if output_type is None:
                    return None
                output_cls = cast("type[BaseModel]", output_type)
                return cast(O, output_cls.model_validate(json.load(f)))
        except Exception as e:
            ctx.warn(f"Could not load existing output, re-running agent: {e}")
            return None

    def _build_prompt(self, input: I, ctx: "Context") -> str:
        """Build complete prompt with all sections.

        Uses ctx.prompts for prompt loading (must be injected by application).
        Also copies any linked reference files to the working directory.
        """
        self._bind_contextual_output_type(ctx)
        if not ctx.prompts:
            raise RuntimeError("Context.prompts not configured - required for AgentStep")

        output_file = ctx.get("_output_file") or self.output_file

        # Compute working directory (same logic as _spawn_agent)
        root_path = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir
        working_dir = ctx.base_dir if self.use_repo_root else root_path

        variables = {
            "package_name": ctx.namespace,
            "namespace": ctx.namespace,
            "output_file": output_file or "",
            **self._build_prompt_variables(input, ctx),
        }

        # Clear linked files tracking before loading new prompt
        ctx.prompts.clear_linked_files()

        # Extract LLMObs params before passing to load() to avoid duplicate keyword args
        ns = variables.pop("namespace", ctx.namespace)
        iteration = variables.pop("iteration", ctx.current_attempt)

        # Resolve experience pointers (only if --experience flag enabled)
        exp_pointers = None
        exp_cache_dir = None
        if ctx.get("_inject_experience"):
            raw = ctx.get("_experience_pointers")
            if isinstance(raw, list) and raw:
                exp_pointers = raw
                exp_cache_dir = ctx.get("_experience_cache_dir")

        skills = SkillLoader.resolve_for_step(self, ctx)
        prompt: str = ctx.prompts.load(
            self.prompt,
            output_schema=self.output_type,
            skills=skills,
            max_turns=self.max_turns,
            working_directory=working_dir,
            fallback=ctx.get,
            workflow_name=ctx.workflow,
            step_name=self.name,
            namespace=ns,
            iteration=iteration,
            experience_pointers=exp_pointers,
            experience_cache_dir=exp_cache_dir,
            **variables,
        )

        # Read directly from backing store to avoid snapshot-test interference:
        # ctx.get() is monkey-patched in snapshot tests to return "<key>"
        # placeholder strings, which would incorrectly activate this block.
        _store = ctx.state.data if ctx.state is not None else {}
        prompt_prefix = _store.get("agent_prompt_prefix")
        if prompt_prefix:
            prompt = f"{prompt_prefix}\n\n{prompt}"

        # Copy any linked reference files to the working directory
        linked_files = ctx.prompts.get_linked_files()
        if linked_files and working_dir:
            ctx.prompts.copy_linked_files(Path(working_dir))

        error_prompt = ctx.get(f"{self.name}_error_prompt")
        if error_prompt:
            prompt += error_prompt

        # Append user guidance from --prompt CLI flag
        user_prompt = ctx.state.user_prompt if ctx.state else None
        if user_prompt:
            prompt += f"\n\n## User Guidance\n\n{user_prompt}\n"

        # Append prior step artifacts for diagnostic context (Meta-Harness pattern)
        prior_section = self._build_prior_steps_section(ctx)
        if prior_section:
            prompt += prior_section

        return prompt

    @staticmethod
    def _find_latest_step_dir(state: Any, step_name: str, base: Path) -> Optional[Path]:
        """Find the highest-numbered attempt directory that exists on disk.

        The checkpoint's ``attempt`` field can lag behind on reruns — scanning
        the filesystem ensures we always point agents at the freshest data.
        """
        # Composite stage keys (e.g. test:att1:iter2:fixer) are already fully
        # qualified — step_dir() ignores the attempt arg for these, so looping
        # would spin forever on the same path.  Return directly instead.
        if ":att" in step_name and ":iter" in step_name:
            path = state.step_dir(step_name, 1, base)
            return path if path.exists() else None

        attempt = 1
        last_existing: Optional[Path] = None
        while True:
            candidate = state.step_dir(step_name, attempt, base)
            if not candidate.exists():
                break
            last_existing = candidate
            attempt += 1
        return last_existing

    @staticmethod
    def _build_workflow_block(state: Any, base: Path, label: str) -> Optional[str]:
        """Build a compact treemap block for one workflow's completed steps.

        Returns None if no step directories exist on disk (nothing to show).
        """
        completed = state.get_completed_steps()
        if not completed:
            return None

        workflow_root = state.root(base)

        # Collect step dirs to confirm they exist on disk
        step_dirs = {}
        for step_name in completed:
            step_dir = AgentStepExecutor._find_latest_step_dir(state, step_name, base)
            if step_dir is not None:
                step_dirs[step_name] = step_dir.name  # e.g. "analyze-1"

        if not step_dirs:
            return None

        block = [f"**{label}** — root: `{workflow_root}`"]

        # Compact step listing with explicit path prefixes so agents don't guess
        # `{root}/{step}/output.json` instead of `{root}/steps/{step}/output.json`.
        block.append("Steps: " + "  ".join(f"`steps/{d}/`" for d in step_dirs.values()))
        block.append(
            "  → read `steps/<step-dir>/output.json` first; "
            "`steps/<step-dir>/input.json`; grep `steps/<step-dir>/logs/`"
        )

        # Named artifacts if any
        wf_artifacts = workflow_root / "artifacts"
        if wf_artifacts.exists():
            artifact_names = [f.name for f in sorted(wf_artifacts.iterdir()) if f.is_file()]
            if artifact_names:
                block.append("Artifacts: " + "  ".join(f"`artifacts/{n}`" for n in artifact_names))

        return "\n".join(block)

    @staticmethod
    def _build_prior_steps_section(ctx: "Context") -> str:
        """Build a compact section summarising prior completed steps.

        Uses a treemap-style layout: one line of step names + the root path.
        Agents construct file paths from the pattern rather than reading a
        verbose per-file listing — same information, far fewer tokens.

        Pattern: ``{root}/steps/{step}-{attempt}/output.json`` (start here)
                 ``{root}/steps/{step}-{attempt}/input.json``
                 ``{root}/steps/{step}-{attempt}/logs/`` (use grep, files are large)
                 ``{root}/artifacts/{name}``  (named workflow artifacts)

        Walks up the parent context chain so nested workflows also see their
        parent's completed steps.
        """
        sections: List[str] = []

        current: "Context | None" = ctx
        while current is not None:
            state = current.state
            base = current.base_dir
            if state and base:
                label = state.workflow if current is ctx else f"{state.workflow} (parent)"
                block = AgentStepExecutor._build_workflow_block(state, base, label)
                if block is not None:
                    sections.append(block)
            current = getattr(current, "_parent_context", None)

        if not sections:
            return ""

        header = (
            "\n\n## Prior Step Artifacts\n"
            "\n"
            f"**Workflow**: `{ctx.workflow}` · **Package**: `{ctx.namespace}`\n"
            "\n"
            "Previous steps and artifacts on disk. Paths below are relative to each workflow "
            "root; keep the `steps/` and `artifacts/` prefixes when reading files.\n"
        )
        return header + "\n\n".join(sections)

    def _spawn_agent(self, prompt: str, ctx: "Context") -> O:
        """Spawn agent and return structured output."""
        # Get working directory from state or base_dir
        root_path = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir
        # use_repo_root uses base_dir (repo root), otherwise use analysis root
        working_dir = ctx.base_dir if self.use_repo_root else root_path
        log_dir = self._get_agent_log_dir(ctx)

        # Check if we should resume a previous session (e.g., fix attempt)
        resume_session_id = ctx.get(f"{self.name}_session_id")

        # Build required_files list
        # NOTE: Don't include output_file when using output_schema - structured output
        # is returned via --json-schema, and the file is written by _save_output() AFTER
        # the agent returns. Only include output_file if there's no output_schema.
        output_file = ctx.get("_output_file") or self.output_file
        required_files = list(self.required_files) if self.required_files else []
        output_type = self.output_type
        if output_file and not output_type and output_file not in required_files:
            required_files.append(output_file)

        # Allow ctx_overrides to redirect the agent to an alternate repo root
        # (e.g. a temporary worktree for blind eval with integration deleted)
        repo_root_override = ctx.get("_repo_root")
        repo_root_kwarg = {"repo_root": Path(repo_root_override)} if repo_root_override else {}

        # When the repo root is overridden (blind eval worktree), suppress the
        # adapter's allowed_paths so the original repo never reaches allowed_paths.
        # The pre-tool-use hook approves reads from allowed_paths before deny rules
        # fire, so the adapter adding the original repo would silently bypass any
        # Read deny rule we set for the original path.
        repo_adapter = None if repo_root_override else getattr(ctx, "repo_adapter", None)

        deny_paths = ctx.get("agent_permission_deny")
        allow_paths = ctx.get("agent_permission_allow")
        extra_env = _build_extra_env(ctx)

        # Steps that need MCP servers or extra SDK hooks set them on ctx in
        # their ``get_prompt_variables`` (or workflow ``setup``). Keeping
        # these on ctx — instead of static AgentStepConfig fields — lets
        # steps wire up runtime-dependent values (e.g. a PostToolUse hook
        # that closes over the per-step log directory).
        mcp_servers = ctx.get("agent_mcp_servers")
        sdk_hooks_override = ctx.get("agent_sdk_hooks")

        # Context.emit() handles relay for batch items automatically
        # Always watch both the analysis dir (root_path) and the agent CWD (working_dir).
        # For use_repo_root steps these differ — root_path is .analysis/<pkg>/<workflow>/
        # and working_dir is the repo root. Dedup so we don't check the same dir twice.
        signal_dirs = list(dict.fromkeys(p for p in [root_path, working_dir] if p is not None))

        result = spawn_agent(
            task_description=self.name,
            prompt=prompt,
            working_directory=working_dir,
            emitter=ctx,
            timeout_minutes=self.timeout_minutes,
            max_turns=self.max_turns,
            model=self.model,
            output_schema=output_type,
            required_files=required_files or None,
            log_dir=log_dir,
            skills=SkillLoader.resolve_for_step(self, ctx),
            resume_session_id=resume_session_id,
            # TODO: default to True once we have better sandboxing that doesn't block workflows
            sandbox=getattr(self, "sandbox", False),
            repository=getattr(ctx, "repository", None),
            repo_adapter=repo_adapter,
            permission_allow=allow_paths or None,
            permission_deny=deny_paths or [],
            extra_env=extra_env,
            mcp_servers=mcp_servers,
            sdk_hooks=sdk_hooks_override,
            max_cost_usd=ctx.get_config("max_cost_usd"),
            signal_dirs=signal_dirs,
            **repo_root_kwarg,
        )

        # Store session_id for potential resume (e.g., fix_output re-run)
        if result.session_id:
            ctx.set(f"{self.name}_session_id", result.session_id)

        # Resolve the effective model (shortname → fully-qualified when in AI Gateway mode).
        resolved_model = (
            resolve_model_alias(self.model) if os.environ.get("ANTHROPIC_MODEL") else self.model
        )
        ctx.info(f"Agent model: {resolved_model}")

        # Annotate the active LLMObs span with native token/cost metrics + resolved model.
        if result.metrics:
            m = result.metrics
            llmobs_annotate(
                metrics={
                    "input_tokens": m.input_tokens,
                    "output_tokens": m.output_tokens,
                    "total_tokens": m.input_tokens + m.output_tokens,
                    "cache_read_input_tokens": m.cache_read_input_tokens,
                    "cost_usd": m.cost_usd,
                },
                metadata={"model_resolved": resolved_model},
            )

        if not result.success:
            msg = result.error or "Agent failed to produce structured output"
            if result.metrics:
                parts = []
                if result.metrics.error_subtype:
                    parts.append(result.metrics.error_subtype)
                if result.metrics.num_turns:
                    parts.append(f"{result.metrics.num_turns} turns")
                if parts:
                    msg = f"{msg} ({', '.join(parts)})"
            raise StructuredOutputError(msg, step_name=self.name)
        if not result.structured_output:
            raise StructuredOutputError(
                f"Agent did not return structured output for {self.name}",
                step_name=self.name,
            )
        return cast(O, result.structured_output)

    def _save_output(self, output: O, ctx: "Context") -> None:
        """Save output to file if configured."""
        output_file = ctx.get("_output_file") or self.output_file
        if not output_file:
            return

        root_path = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir
        if not root_path:
            return
        output_path = root_path / output_file
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            if isinstance(output, BaseModel):
                f.write(output.model_dump_json(indent=2))
            else:
                json.dump(output, f, indent=2)
        ctx.info(
            f"Saved output to: {ctx.state.relative(output_path, ctx.base_dir) if ctx.state else output_file}"
        )

    def _get_agent_log_dir(self, ctx: "Context"):
        """Get log directory for this agent.

        Uses ctx.step_logs() to consolidate all logs for a step in one directory.
        For composite steps, ctx.current_step is set to the stage key
        (e.g., test:iter1:diagnosis), so logs go to test:iter1:diagnosis:iter1/logs/.
        """
        # For batch items in isolated contexts, use pre-computed path from main context
        batch_log_dir = ctx.get("_batch_log_dir")
        if batch_log_dir:
            log_dir = Path(batch_log_dir)
            log_dir.mkdir(parents=True, exist_ok=True)
            return log_dir

        if not ctx.state:
            return Path.cwd() / "logs"

        # ctx.step_logs() uses ctx.current_step and ctx.current_attempt
        log_dir = ctx.step_logs()

        batch_item_id = ctx.get("current_feature_id") or ctx.get("_batch_item_id")
        if batch_item_id:
            log_dir = log_dir / batch_item_id

        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir

    def get_prompt_variables(self, input: Any, ctx: "Context") -> dict:
        """Get additional prompt variables. Override in subclass."""
        return {}

    def _build_prompt_variables(self, input: Any, ctx: "Context") -> dict:
        """Build prompt variables including validation context."""
        # Inject current input fields into ctx so templates resolve them via fallback.
        # Covers batch AgentSteps where _execute_steps injects the overall step input
        # but not the individual per-item dicts from prepare_batch().
        # - Use model_dump() so nested Pydantic objects become JSON-safe dicts (avoids
        #   state corruption when complex objects are serialised via default=str).
        # - Skip None and empty containers so snapshot placeholder inputs (empty lists,
        #   None fields) don't overwrite <key> fallback strings in snapshot tests.
        if isinstance(input, BaseModel):
            for field_name, value in input.model_dump().items():
                if value is not None and value != [] and value != {}:
                    ctx.set(field_name, value)
        elif isinstance(input, dict):
            for key, value in input.items():
                if value is not None and value != [] and value != {}:
                    ctx.set(key, value)

        variables: dict = {}
        errors = ctx.get(f"{self.name}_validation_errors")
        if errors:
            variables["validation_errors"] = "\n".join(f"- {e}" for e in errors)
            variables["previous_output"] = ctx.get("previous_output")

        # Include plan if available (from planning phase)
        plan = ctx.get("plan")
        if plan:
            variables["plan"] = plan

        variables.update(self.get_prompt_variables(input, ctx))

        # Merge context-level prompt variables (e.g., analysis_info, package_name).
        # These are set by workflows via ctx.set("prompt_variables", {...}) and
        # automatically available to all agent steps without manual merging.
        # Step-specific variables take precedence (already in variables).
        ctx_vars = ctx.get("prompt_variables", {})
        for key, value in ctx_vars.items():
            if key not in variables:
                variables[key] = value

        return variables

    def _run_planning_phase(self, input: Any, ctx: "Context") -> str:
        """Run planning phase before implementation.

        The planning phase:
        1. Uses the same prompt but with PLANNING_PREFIX prepended
        2. Loads ALL skills (empty list = all skills)
        3. Returns the plan as raw text (no structured output)
        4. Stores session_id so main agent can resume the same session
        """
        ctx.emit("section", name=f"{self.name} - Planning Phase")
        ctx.info("Running planning phase (read-only, all skills)")

        # Build prompt with planning prefix
        prompt = self._build_prompt(input, ctx)
        planning_prompt = PLANNING_PREFIX + prompt

        # Get working directory and log dir
        root_path = ctx.state.root(ctx.base_dir) if ctx.state else ctx.base_dir
        working_dir = ctx.base_dir if self.use_repo_root else root_path
        log_dir = self._get_agent_log_dir(ctx) / "planning"
        log_dir.mkdir(parents=True, exist_ok=True)

        # Check if we should resume a previous session (e.g., from prior iteration)
        resume_session_id = ctx.get(f"{self.name}_session_id")

        # Run planning agent with ALL skills (empty list = all)
        result = spawn_agent(
            task_description=f"{self.name} - Planning",
            prompt=planning_prompt,
            working_directory=working_dir,
            emitter=ctx,
            timeout_minutes=15,  # Planning should be faster
            max_turns=50,  # Fewer turns for planning
            model=self.model,
            output_schema=None,  # No structured output for planning
            log_dir=log_dir,
            skills=[],  # Empty list = ALL skills
            sandbox=True,  # Planning is read-only
            resume_session_id=resume_session_id,
            repository=getattr(ctx, "repository", None),
            repo_adapter=getattr(ctx, "repo_adapter", None),
            permission_deny=ctx.get("agent_permission_deny") or [],
        )

        # Store session_id so main agent resumes the same session
        if result.session_id:
            ctx.set(f"{self.name}_session_id", result.session_id)

        if not result.success:
            ctx.warn(f"Planning phase failed: {result.error}")
            return f"Planning failed: {result.error}"

        # Return the raw output as the plan
        return result.output or "No plan generated"


def _build_extra_env(ctx: "Context") -> Dict[str, str]:
    """Return extra env vars to inject into the agent subprocess.

    Starts the eval MITM proxy (see anubis/core/agents/eval_proxy.py) when either:
    - ``agent_eval_account`` is set in ctx (eval account header routing), or
    - the model is non-Anthropic (e.g. ``openai/gpt-5.5``, ``bedrock/moonshotai.kimi-k2.5``),
      which requires the proxy for request-format conversion and accurate cost tracking.

    The model is checked from both ``ANTHROPIC_MODEL`` env var (eval CLI) and the
    workflow-level ``--model`` flag (stored in ctx as ``_model_override``).

    Returns HTTPS_PROXY + NODE_EXTRA_CA_CERTS so the Claude binary's requests are
    intercepted. Result is cached on ``ctx._agent_extra_env`` so step fixers can
    pick it up without re-deriving it.
    """
    model_override = os.environ.get("ANTHROPIC_MODEL", "") or ctx.get("_model_override") or ""

    def _is_non_anthropic_model(model: str) -> bool:
        return bool(model) and "/" in model and not model.startswith("anthropic/")

    is_non_anthropic = _is_non_anthropic_model(model_override)

    if is_non_anthropic and not os.environ.get("ANTHROPIC_MODEL"):
        os.environ["ANTHROPIC_MODEL"] = model_override

    if not ctx.get("agent_eval_account") and not is_non_anthropic:
        return {}

    proxy_env = ensure_eval_proxy_running()
    if proxy_env:
        ctx._agent_extra_env = proxy_env  # type: ignore[attr-defined]
        return proxy_env

    print("[eval] proxy unavailable — running without eval account routing", flush=True)
    return {}
