"""Base step executor - internal execution mechanics."""

import inspect
import json
import logging
import time
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING, Any, Generic, List, Optional, TypeVar, cast

from pydantic import BaseModel

from ...errors import StructuredOutputError, ValidationError
from ...state.models import AgentRun
from ...tracing import (
    llmobs_annotate,
    llmobs_task,
    serialize_for_llmobs,
    tag_batch_span,
    tracer,
)
from ...types import run_validators

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from ...context import Context

I = TypeVar("I", bound=BaseModel)
O = TypeVar("O", bound=BaseModel)


class StepExecutor(ABC, Generic[I, O]):
    """Internal execution mechanics. Users should not override these methods.

    Handles:
    - Single item execution with hooks
    - Validation with fixer loop
    - Batch execution (parallel/sequential)
    - Metrics aggregation
    - Data logging

    Subclasses must define:
    - name: str - step identifier
    - execute(input, ctx) -> output
    - validators: List - validation functions
    - max_fixer_iterations: int - max fix attempts
    - validation_required: bool - raise on validation failure
    """

    # Required attributes (defined in Step subclass)
    name: str = "step"
    validators: List = []
    max_fixer_iterations: int = 3
    validation_required: bool = True
    batch_size: int = 1
    output_type: Optional[type] = None
    item_output_type: Optional[type] = None  # For batch steps: type of each item's output
    output_type_overrides: dict[str, type[BaseModel]] = {}

    def _bind_contextual_output_type(self, ctx: "Context") -> None:
        """Bind repository/language-specific output schema for this context."""
        if not hasattr(self, "_base_output_type"):
            self._base_output_type = self.output_type
        if not self.output_type_overrides:
            return

        keys = []
        repository = getattr(ctx, "repository", None)
        if isinstance(repository, str) and repository:
            keys.append(repository)
        try:
            language = getattr(ctx.repo_adapter, "language", None)
        except Exception:
            language = None
        if isinstance(language, str) and language and language not in keys:
            keys.append(language)

        for key in keys:
            output_type = self.output_type_overrides.get(key)
            if output_type is not None:
                self.output_type = output_type
                return
        self.output_type = self._base_output_type

    # -------------------------------------------------------------------------
    # Abstract methods - must be implemented by Step subclass
    # -------------------------------------------------------------------------

    @abstractmethod
    def execute(self, input: I, ctx: "Context") -> O:
        """Execute the step. Must be implemented by subclass."""
        pass

    def before_execute(self, input: I, ctx: "Context") -> I:
        """Hook: Transform input before execute. Override in subclass."""
        return input

    def after_execute(self, output: O, ctx: "Context") -> O:
        """Hook: Transform output after execute. Override in subclass."""
        return output

    def can_fix(self) -> bool:
        """Return True if this step can fix validation errors."""
        return False

    def fix_output(self, input: I, output: O, errors: List[str], ctx: "Context") -> O:
        """Fix invalid output. Override in subclass if can_fix() returns True."""
        raise NotImplementedError("fix_output not implemented")

    # -------------------------------------------------------------------------
    # Batch hooks - override in subclass if batch_execute = True
    # -------------------------------------------------------------------------

    def prepare_batch(self, input: Any, ctx: "Context") -> Optional[List[Any]]:
        """Prepare items for batch execution. Override for batch steps."""
        return input if isinstance(input, list) else []

    def aggregate_batch(self, results: list, ctx: "Context") -> Any:
        """Combine batch results. Override to customize aggregation."""
        return results

    # -------------------------------------------------------------------------
    # Internal execution methods
    # -------------------------------------------------------------------------

    def _run_one(self, input: I, ctx: "Context") -> O:
        """Execute single item with hooks and validation."""
        # Mark step start for accurate diff in human review
        # Only mark if not already set (batch sequential sets it before calling us)
        if ctx.git._step_start_commit is None:
            ctx.git.mark_step_start()

        # Set attempt number at start for standalone (non-batch) execution
        # This ensures consistent attempt numbers across logging and agent spawning
        if not ctx.get("_batch_attempt") and not ctx.get("_parent_step") and ctx.state:
            ctx.current_attempt = ctx.state.get_next_attempt(self.name, ctx.base_dir)
        self._log_data(input, "input.json", ctx)
        input = self.before_execute(input, ctx)
        try:
            output = self.execute(input, ctx)
        except StructuredOutputError as e:
            if not self.can_fix():
                raise
            output = self._recover_structured_output(input, e, ctx)
        output = self.after_execute(output, ctx)
        self._log_data(output, "output.json", ctx)
        result = self._validate_with_fixes(input, output, ctx)
        self._log_step_files(ctx)
        return result

    def _recover_structured_output(
        self, input: I, error: StructuredOutputError, ctx: "Context"
    ) -> O:
        """Recover from structured output failure using the step-level fixer.

        When an agent fails to produce structured output (e.g., hit max_turns,
        confused state), the spawn_agent-level fixer may not be enough since it
        only nudges the same session. This method invokes the step-level fixer
        which re-runs the agent with full error context — a much stronger recovery.
        """
        errors = [str(error)]
        last_error: Exception = error

        for attempt in range(1, self.max_fixer_iterations + 1):
            ctx.warn(
                f"Structured output recovery (attempt {attempt}/{self.max_fixer_iterations}): {error}"
            )
            ctx.set(f"{self.name}_validation_errors", errors)
            try:
                return self.fix_output(input, cast(O, None), errors, ctx)
            except StructuredOutputError as retry_error:
                errors = [str(retry_error)]
                last_error = retry_error
                ctx.warn(f"Recovery attempt {attempt} failed: {retry_error}")

        raise last_error

    def _validate_with_fixes(self, input: I, output: O, ctx: "Context") -> O:
        """Run validation loop with optional fixer."""
        for attempt in range(1, self.max_fixer_iterations + 1):
            errors = self._validate(output, ctx)
            if not errors:
                self._log_data(
                    {"passed": True, "attempt": attempt}, f"validation_{attempt}.json", ctx
                )
                self._tag_validation_result(passed=True, attempts=attempt)
                return output

            self._log_data(
                {"passed": False, "errors": errors, "attempt": attempt},
                f"validation_{attempt}.json",
                ctx,
            )
            ctx.warn(f"Validation failed (attempt {attempt}/{self.max_fixer_iterations}): {errors}")

            if not self.can_fix():
                self._tag_validation_result(passed=False, attempts=attempt, errors=errors)
                return self._handle_unfixable(output, errors, ctx)

            ctx.set(f"{self.name}_validation_errors", errors)
            output = self.fix_output(input, output, errors, ctx)

        errors = self._validate(output, ctx)
        if errors:
            self._tag_validation_result(
                passed=False,
                attempts=self.max_fixer_iterations,
                errors=errors,
            )
            return self._handle_unfixable(output, errors, ctx)
        self._tag_validation_result(passed=True, attempts=self.max_fixer_iterations)
        return output

    def _tag_validation_result(
        self,
        passed: bool,
        attempts: int,
        errors: Optional[List[str]] = None,
    ) -> None:
        """Tag the active span with validation outcome."""
        span = tracer.current_span()
        if not span:
            return
        span.set_tag("validation.passed", str(passed))
        span.set_tag("validation.required", str(self.validation_required))
        span.set_tag("validation.attempts", str(attempts))
        if errors:
            span.set_tag("validation.errors", "; ".join(str(e)[:100] for e in errors[:5]))

    def _handle_unfixable(self, output: O, errors: List[str], ctx: "Context") -> O:
        """Handle validation errors when fixing is not possible."""
        if self.validation_required:
            raise ValidationError(f"Validation failed: {errors}")
        ctx.warn(f"Validation failed (no fixer, continuing anyway): {errors}")
        return output

    def _run_batch(self, input: Any, ctx: "Context") -> Any:
        """Execute batch with parallel or sequential processing."""
        batch = self.prepare_batch(input, ctx)
        if not batch:
            # Still call aggregate_batch to produce proper output type
            return self.aggregate_batch([], ctx)

        # Use parent's iteration if running as substage, otherwise calculate from filesystem
        parent_step = ctx.get("_parent_step")
        if parent_step and parent_step != self.name:
            batch_attempt = ctx.current_attempt
        elif ctx.state:
            batch_attempt = ctx.state.get_next_attempt(self.name, ctx.base_dir)
            ctx.current_attempt = batch_attempt
        else:
            batch_attempt = 1
            ctx.current_attempt = batch_attempt
        ctx.set("_batch_attempt", batch_attempt)

        if self.batch_size > 1:
            results = self._run_parallel(batch, ctx)
        else:
            results = self._run_sequential(batch, ctx)

        return self.aggregate_batch(results, ctx)

    def _run_parallel(self, batch: list, ctx: "Context") -> list:
        """Run batch items in parallel with isolated contexts."""
        item_ids = [self._get_item_id(item) for item in batch]

        # Start batch display
        ctx.emit("batch_start", items=item_ids)

        batch_attempt = ctx.get("_batch_attempt")
        results, contexts = {}, []
        start_times = {}

        # Pre-compute log directory in main context (which has state)
        # Use ctx.current_step (set by composite) to include iteration in path
        if ctx.state:
            base_log_dir = ctx.step_logs()
        else:
            base_log_dir = (ctx.base_dir or Path.cwd()) / "logs" / self.name

        # Capture parent trace context BEFORE spawning threads
        # ThreadPoolExecutor doesn't automatically propagate ddtrace context
        parent_trace_ctx = tracer.current_trace_context()

        def run_isolated(idx: int, item: Any):
            item_id = item_ids[idx]
            start_times[item_id] = time.time()

            # Mark as running
            ctx.emit("batch_item_update", item_id=item_id, status="running", message="Starting...")

            isolated = ctx.copy_isolated()
            isolated.set("_batch_attempt", batch_attempt)
            isolated.set("_batch_item_id", item_id)
            isolated.set("_batch_log_dir", str(base_log_dir / item_id))  # Pre-computed log dir
            isolated.current_attempt = ctx.current_attempt  # Copy for _get_agent_log_dir

            # Set up relay for agent output to main context
            isolated.set("_batch_relay_ctx", ctx)
            isolated.set("_batch_relay_item_id", item_id)

            # Activate parent trace context in this thread
            # This ensures child spans are properly linked to the parent workflow/step
            if parent_trace_ctx:
                tracer.context_provider.activate(parent_trace_ctx)

            # LLMObs task span for batch item
            with llmobs_task(
                f"{self.name}[{idx}]",
                input_data=serialize_for_llmobs(item),
            ) as span:
                # Add batch tags
                if span:
                    tag_batch_span(
                        span,
                        item_id=item_id,
                        index=idx,
                        step_name=self.name,
                        total_items=len(batch),
                        attempt=batch_attempt,
                    )

                try:
                    result = self._run_one(item, isolated)
                    llmobs_annotate(output_data=serialize_for_llmobs(result))
                    return result, isolated
                except Exception:
                    raise

        errors_by_item = {}
        with ThreadPoolExecutor(max_workers=self.batch_size) as executor:
            futures = {executor.submit(run_isolated, i, item): i for i, item in enumerate(batch)}
            for future in as_completed(futures):
                idx = futures[future]
                item_id = item_ids[idx]
                duration = time.time() - start_times.get(item_id, time.time())

                try:
                    result, isolated = future.result()
                    results[idx] = result
                    contexts.append(isolated)
                    ctx.emit(
                        "batch_item_complete", item_id=item_id, success=True, duration=duration
                    )
                except Exception as e:
                    error_msg = f"{type(e).__name__}: {e}"
                    errors_by_item[item_id] = error_msg
                    ctx.emit(
                        "batch_item_complete",
                        item_id=item_id,
                        success=False,
                        duration=duration,
                        error=str(e),
                    )
                    results[idx] = None

        # End batch display
        ctx.emit("batch_complete")

        # Surface batch errors - log each failed item
        if errors_by_item:
            ctx.error(f"Batch failures ({len(errors_by_item)}/{len(batch)} items):")
            for item_id, error_msg in errors_by_item.items():
                ctx.error(f"  [{item_id}] {error_msg}")

        self._aggregate_metrics(contexts, ctx)
        return [results.get(i) for i in range(len(batch))]

    def _run_sequential(self, batch: list, ctx: "Context") -> list:
        """Run batch items sequentially with shared context."""
        item_ids = [self._get_item_id(item) for item in batch]
        total = len(batch)

        # Show log directory before starting batch display
        if ctx.state:
            log_dir = ctx.step_logs()
            ctx.info(f"Logs: {ctx.state.relative(log_dir, ctx.base_dir)}")

        # Start sequential batch display
        ctx.emit(
            "seq_batch_start", step=self.name, total=total, model=getattr(self, "model", "unknown")
        )

        batch_attempt = ctx.get("_batch_attempt")
        results = []
        for i, item in enumerate(batch):
            item_id = item_ids[i]
            ctx.set("_batch_item_id", item_id)
            ctx.emit("seq_batch_item_start", item_id=item_id, index=i, total=total)

            # Mark step start for accurate diff in human review
            # This ensures each batch item's diff shows only its changes
            ctx.git.mark_step_start()

            # LLMObs task span for sequential batch item
            with llmobs_task(
                f"{self.name}[{i}]",
                input_data=serialize_for_llmobs(item),
            ) as span:
                if span:
                    tag_batch_span(
                        span,
                        item_id=item_id,
                        index=i,
                        step_name=self.name,
                        total_items=total,
                        attempt=batch_attempt,
                    )

                try:
                    result = self._run_one(item, ctx)
                    llmobs_annotate(output_data=serialize_for_llmobs(result))
                    results.append(result)
                    ctx.emit("seq_batch_item_complete", item_id=item_id, success=True)
                except Exception as e:
                    ctx.error(f"Failed: {item_id} - {e}")
                    results.append(cast(O, None))
                    ctx.emit("seq_batch_item_complete", item_id=item_id, success=False)

        ctx.emit("seq_batch_complete")
        return results

    def _aggregate_metrics(self, contexts: list, ctx: "Context") -> None:
        """Aggregate metrics from isolated batch contexts into parent state."""
        total_cost, total_duration = 0.0, 0.0
        for isolated in contexts:
            for metrics_dict in isolated._pending_metrics:
                total_cost += metrics_dict.get("cost_usd", 0)
                total_duration += metrics_dict.get("duration_seconds", 0)
                # Propagate to parent state (was missing - only logged before)
                if ctx.state and ctx.current_step:
                    run = AgentRun.model_validate(metrics_dict)
                    step_state = ctx.state.get_step(ctx.current_step)
                    step_state.metrics.add_agent_run(run)
        if ctx.state:
            ctx.state.update_totals()
        if total_cost > 0:
            ctx.info(
                f"Batch complete: {len(contexts)} agents | ${total_cost:.4f} | {total_duration:.1f}s"
            )

    @staticmethod
    def _get_item_id(item: Any) -> str:
        """Get identifier for batch item."""
        if isinstance(item, dict):
            return (
                item.get("check_id")
                or item.get("todo_id")
                or item.get("feature_id")
                or item.get("id")
                or item.get("name")
                or str(item)[:20]
            )
        return str(item)[:20]

    def _validate(self, output: O, ctx: "Context") -> List[str]:
        """Run model.verify() then step.validators."""
        errors = []
        # Model's own verify() method
        if hasattr(output, "verify") and callable(output.verify):
            verify_result = output.verify()
            if verify_result:
                errors.extend(verify_result)

        # Run validators (pydantic + custom), passing output_type
        # For batch items, use item_output_type if set; otherwise use output_type
        if ctx.get("_batch_item_id"):
            # In batch mode: use item_output_type for per-item validation
            output_type = getattr(self, "item_output_type", None)
        else:
            # Non-batch mode: use output_type
            output_type = self.output_type
        validator_errors = run_validators(self.validators, output, ctx, output_type)
        errors.extend(validator_errors)

        return errors

    def _format_validation_errors(self, errors: List[str], output: Optional[O] = None) -> str:
        """Format validation errors as a prompt section.

        Includes validator source code to help the agent understand what's being checked.
        """
        errors_formatted = "\n".join(f"- {e}" for e in errors)
        output_section = ""
        if output is not None:
            try:
                if isinstance(output, BaseModel):
                    output_json = output.model_dump_json(indent=2)
                else:
                    output_json = json.dumps(output, indent=2, default=str)
                output_section = f"\n### Previous Output\n\n```json\n{output_json}\n```\n"
            except (TypeError, ValueError) as e:
                # Output not JSON-serializable - skip including in error message (not critical)
                logger.debug(f"Could not serialize output for error message: {e}")
                pass

        # Include validator source code so the agent knows what's being checked
        validators_section = self._get_validators_source()

        return f"""
## VALIDATION ERRORS - FIX REQUIRED

**Your previous attempt failed validation. You MUST fix these issues:**

{errors_formatted}
{output_section}{validators_section}
**Instructions:**
1. Read the error messages carefully
2. Review the validator functions to understand exactly what is being checked
3. Fix the specific issues mentioned
4. Do NOT repeat the same approach that failed"""

    def _get_validators_source(self) -> str:
        """Get source code of custom validators for the fixer prompt."""
        if not self.validators:
            return ""

        sources = []
        for v in self.validators:
            if not callable(v):
                continue
            # Skip built-in validators (from anubis.core.validation.validators)
            module = getattr(v, "__module__", "")
            if "anubis.core.validation" in module:
                continue
            try:
                source = inspect.getsource(v)
                sources.append(f"### {v.__name__}\n```python\n{source.strip()}\n```")
            except (TypeError, OSError):
                # Can't get source for built-in functions or lambdas
                pass

        if not sources:
            return ""

        return (
            "\n### Validator Functions\n\nThese are the custom validation functions your output must pass:\n\n"
            + "\n\n".join(sources)
            + "\n"
        )

    def _get_fixer_log_dir(self, ctx: "Context") -> Path:
        """Get log directory for fixer agent."""
        if not ctx.state:
            return Path.cwd() / "logs"
        iteration = ctx.get("iteration") or ctx.get("current_iteration") or ctx.current_attempt
        parent_step = ctx.get("_parent_step")
        if parent_step:
            log_dir = (
                ctx.state.step_logs(parent_step, iteration, ctx.base_dir) / f"{self.name}_fixer"
            )
        else:
            log_dir = ctx.state.step_logs(f"{self.name}_fixer", iteration, ctx.base_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir

    def _log_data(self, data: Any, filename: str, ctx: "Context") -> None:
        """Save step data to step directory."""
        if not ctx.state:
            return
        try:
            step_dir = ctx.step_dir()
            batch_item_id = ctx.get("_batch_item_id")
            if batch_item_id:
                step_dir = step_dir / batch_item_id
            step_dir.mkdir(parents=True, exist_ok=True)
            path = step_dir / filename
            if isinstance(data, BaseModel):
                path.write_text(data.model_dump_json(indent=2))
            elif data is None:
                path.write_text("null")
            else:
                path.write_text(json.dumps(data, indent=2, default=str))
        except Exception as e:
            msg = f"ERROR: _log_data failed for {filename}: {e}"
            print(msg, flush=True)
            ctx.warn(f"Failed to log step data to {filename}: {e}")

    def _log_step_files(self, ctx: "Context") -> None:
        """Log saved step files for user reference."""
        if not ctx.state or ctx.get("_batch_item_id"):
            return  # Skip for batch items (too noisy)
        try:
            step_dir = ctx.step_dir()
            rel_dir = ctx.state.relative(step_dir, ctx.base_dir)
            ctx.info(f"Step data: {rel_dir}/")
        except Exception as e:
            # Non-critical - just skip logging step directory on error
            logger.debug("Failed to log step directory: %s", e)
