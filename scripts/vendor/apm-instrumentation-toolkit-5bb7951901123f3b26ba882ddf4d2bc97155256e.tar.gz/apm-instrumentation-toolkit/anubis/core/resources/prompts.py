"""Prompt loader - loads and renders prompt templates.

Supports three composition directives:

- ``{{include:path}}`` -- Inline another template (recursive, max depth 10)
- ``{{include_repo:name}}`` -- Include repo-specific fragment from
  ``repo/{repo}/name.md`` relative to the template directory. Silently skipped if missing.
  Supports ``{{include_repo:name,excluded_repos=r1,r2}}`` to skip specific repos.
- ``{{link:path}}`` -- Insert a markdown link for on-demand reading

IMPORTANT: Templates should NOT contain hardcoded JSON schemas or output types.
Output schemas are injected dynamically via the `output_schema` parameter.

Good template:
    Analyze the {{package}} integration.
    <!-- Schema appended automatically -->

Bad template:
    Analyze the {{package}} integration.
    Output this JSON:
    ```json
    {"field": "hardcoded"}
    ```
"""

import os
import re
import shutil
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Type

from pydantic import BaseModel

from .schema import schema_to_doc

# Patterns that suggest hardcoded schemas
_HARDCODED_SCHEMA_PATTERNS = [
    r"```json\s*\n\s*\{(?!\{)",  # JSON code blocks with objects (not template vars)
    r'"type":\s*"object"',  # JSON schema type definitions
    r'"properties":\s*\{',  # JSON schema properties
    r"Output.*JSON.*:",  # "Output this JSON:" style instructions
    r"Return.*schema.*:",  # "Return this schema:" style instructions
]

# Include/link directive patterns
_INCLUDE_PATTERN = re.compile(r"\{\{include:([^}]+)\}\}")
_INCLUDE_REPO_PATTERN = re.compile(r"\{\{include_repo:([^}]+)\}\}")
_LINK_PATTERN = re.compile(r"\{\{link:([^}|]+)(?:\|([^}]+))?\}\}")
_MAX_INCLUDE_DEPTH = 10

# Token that marks the start of excluded repos in a repo include directive
_EXCLUDED_REPOS_TOKEN = "excluded_repos="


def _parse_repo_directive(raw: str) -> tuple[str, set[str]]:
    """Parse a repo include directive value into fragment name and excluded repos.

    Supports two forms:
    - ``"name"`` → ``("name", set())``
    - ``"name,excluded_repos=r1,r2"`` → ``("name", {"r1", "r2"})``

    Args:
        raw: The raw captured group from the ``{{include_repo:...}}`` pattern.

    Returns:
        Tuple of (fragment_name, excluded_repos).
    """
    parts = [p.strip() for p in raw.split(",")]
    name = parts[0]
    excluded: set[str] = set()
    collecting = False
    for part in parts[1:]:
        if part.startswith(_EXCLUDED_REPOS_TOKEN):
            collecting = True
            repo = part[len(_EXCLUDED_REPOS_TOKEN) :]
            if repo:
                excluded.add(repo)
        elif collecting:
            excluded.add(part)
    return name, excluded


# Built-in templates directory
_BUILTIN_TEMPLATES_DIR = Path(__file__).parent / "templates"


# Type for skill loader callback
SkillLoaderFn = Optional[Callable[..., str]]


class PromptLoader:
    """Loads and renders prompt templates.

    Searches directories in priority order (first match wins).
    Built-in anubis templates are automatically included as final fallback.
    Supports {{variable}} substitution and optional schema appending.

    Built-in templates:

    - lint-fixer: Generic lint error fixing
    - test-fixer: Generic test failure fixing
    - reviewer: Generic code review

    Example::

        loader = PromptLoader(
            prompts_dirs=[
                Path('my_domain/prompts'),  # Domain-specific first
                Path('prompts/shared'),      # Shared fallback
            ]
            # Built-in templates auto-included as final fallback
        )

        # Basic usage
        prompt = loader.load('analyze', package='kafkajs')

        # With output schema documentation
        prompt = loader.load('analyze', output_schema=AnalysisOutput, package='kafkajs')

    """

    def __init__(
        self,
        prompts_dirs: List[Path],
        include_builtin: bool = True,
        user: Optional[str] = None,
        skill_loader: SkillLoaderFn = None,
        repo: Optional[str] = None,
    ):
        """
        Args:
            prompts_dirs: Directories to search for templates, in priority order
            include_builtin: Whether to include built-in anubis templates as fallback (default True)
            user: Optional user guidance to append to prompts
            skill_loader: Optional callback to load skill summaries: (skill_names) -> str
            repo: Optional repo identifier for resolving {{include_repo:name}} directives
        """
        self.prompts_dirs = [Path(d) for d in prompts_dirs]
        if include_builtin and _BUILTIN_TEMPLATES_DIR.exists():
            self.prompts_dirs.append(_BUILTIN_TEMPLATES_DIR)
        self.user = user
        self.skill_loader = skill_loader
        self.repo = repo
        self.annotate_includes = False  # Debug flag for wrapping includes/links with HTML comments
        # Cache stores (content, linked_files) tuples so linked files work on cache hits
        self._cache: Dict[str, tuple[str, Dict[str, Path]]] = {}
        self._linked_files: Dict[str, Path] = {}  # link_path -> source_file_path
        # Config hash tracking — records every file opened during template loading.
        # Keys: "prompts" (top-level templates), "includes" ({{include:}} + {{include_repo:}}),
        # "links" ({{link:}} targets). Used by config_hash.py to compute run_config_hash.
        self._tracked_files: Dict[str, List[Path]] = {"prompts": [], "includes": [], "links": []}

    def load(
        self,
        name: str,
        output_schema: Optional[Type[BaseModel]] = None,
        skills: Optional[List[str]] = None,
        max_turns: Optional[int] = None,
        workflow_name: Optional[str] = None,
        step_name: Optional[str] = None,
        namespace: Optional[str] = None,
        iteration: Optional[int] = None,
        working_directory: Optional[Path] = None,
        fallback: Optional[Callable[[str], Any]] = None,
        experience_pointers: Optional[List[dict]] = None,
        experience_cache_dir: Optional[str] = None,
        **variables,
    ) -> str:
        """Load and render a prompt template.

        Args:
            name: Template name (without .md extension)
            output_schema: Optional Pydantic model - appends schema docs
            skills: Optional list of skill names to prepend to prompt
            max_turns: Optional turn limit - appends turn limit guidance
            workflow_name: Optional workflow name for LLMObs visibility
            step_name: Optional step name for LLMObs visibility
            namespace: Optional namespace (integration) for LLMObs visibility
            iteration: Optional iteration number for LLMObs visibility
            working_directory: Agent's working directory (defaults to cwd if not provided)
            fallback: Optional callable to get values for missing variables (e.g., ctx.get)
            experience_pointers: Optional list of experience pointer dicts from past runs
            experience_cache_dir: Optional path to experience cache root
            **variables: Variables to substitute in template

        Returns:
            Rendered prompt string

        Raises:
            FileNotFoundError: If template doesn't exist in any directory
            ValueError: If template has unsubstituted variables
        """
        template = self._load_template(name)
        # Include explicit params as template variables so {{namespace}}, {{iteration}} etc. still resolve
        if namespace is not None:
            variables.setdefault("namespace", namespace)
        if iteration is not None:
            variables.setdefault("iteration", iteration)
        rendered = self._render(template, variables, fallback=fallback)

        # Prepend skills section if skill_loader is configured
        # skills=[] (empty list) means ALL skills
        # skills=None means NO skills
        # skills=['x', 'y'] means specific skills
        if skills is not None and self.skill_loader:
            skill_section = self.skill_loader(skills, working_directory=working_directory)
            if skill_section:
                rendered = f"{skill_section}\n\n---\n\n{rendered}"

        # Prepend LLMObs identifier for span visibility
        if workflow_name or step_name or namespace:
            parts = []
            if workflow_name:
                parts.append(f"Workflow: {workflow_name}")
            if namespace:
                parts.append(f"Namespace: {namespace}")
            if step_name:
                parts.append(f"Step: {step_name}")
            if iteration is not None:
                parts.append(f"Iteration: {iteration}")
            identifier = ", ".join(parts)
            rendered = f"<!-- {identifier} -->\n\n{rendered}"

        # Append schema documentation (schema_to_doc already includes format instructions)
        if output_schema:
            schema_doc = schema_to_doc(output_schema)
            rendered += f"\n\n## Expected Output Format\n\n{schema_doc}"

        # Append user guidance if provided
        if self.user:
            rendered += f"\n\n## User Guidance\n\n{self.user}"

        # Append turn limit guidance if provided
        if max_turns is not None:
            rendered += f"""

## Turn Limit

You have **{max_turns} turns maximum**.

**Strategy:** Do NOT exhaustively explore. Work in phases: Quick scan -> Focused analysis -> Output.
Aim to complete in ~{max_turns // 2} turns. If you hit the limit without output, the task fails."""

        # Append raw experience from past runs (cross-run, when available)
        if experience_pointers:
            rendered += self._build_experience_section(experience_pointers, experience_cache_dir)

        # Always append environment section with working directory
        cwd = str(working_directory) if working_directory else os.getcwd()
        rendered += f"""

## Environment

Your current working directory is: `{cwd}`"""

        return rendered

    @staticmethod
    def _build_experience_section(pointers: List[dict], cache_dir: Optional[str] = None) -> str:
        """Build a prompt section pointing to raw files from past runs.

        Agents receive file pointers, not summaries — they read what they need.
        """
        lines: List[str] = [
            "\n\n## Experience from Previous Runs",
            "",
            "These are outputs from similar past integrations stored in the experience",
            "store. Read `output.json` files for concrete examples of what worked.",
            "Generated code (via `git show`) is the most directly useful for coding steps.",
            "",
        ]

        by_run: dict = {}
        for p in pointers:
            run_id = p.get("run_id", "unknown")
            by_run.setdefault(run_id, []).append(p)

        for run_id, pts in by_run.items():
            first = pts[0]
            ns = first.get("integration", "unknown")
            status = first.get("status", "completed")
            status_label = "" if status == "completed" else f" · {status}"
            lines.append(f"**{ns}** (run `{run_id}`{status_label}):")
            for p in pts:
                local_path = p.get("local_path", "")
                relevance = p.get("relevance", "")
                lines.append(f"  - `{local_path}` — {relevance}")
            lines.append("")

        if cache_dir:
            lines.append(f"Cache root: `{cache_dir}` — use `grep` on large log files.")

        return "\n".join(lines)

    def exists(self, name: str) -> bool:
        """Check if a template exists."""
        return self._get_template_path(name) is not None

    def get_path(self, name: str) -> Optional[Path]:
        """Get path to a template file."""
        return self._get_template_path(name)

    def _get_template_path(self, name: str) -> Optional[Path]:
        """Find template file in search directories."""
        for prompts_dir in self.prompts_dirs:
            path = prompts_dir / f"{name}.md"
            if path.exists():
                return path
        return None

    def _load_raw_template(self, name: str) -> str:
        """Load template content without include resolution.

        Args:
            name: Template name (without .md extension)

        Returns:
            Raw template content

        Raises:
            FileNotFoundError: If template doesn't exist
        """
        path = self._get_template_path(name)
        if not path:
            searched = [str(d) for d in self.prompts_dirs]
            raise FileNotFoundError(f"Template '{name}' not found in: {', '.join(searched)}")
        if path not in self._tracked_files["includes"]:
            self._tracked_files["includes"].append(path)
        return path.read_text()

    def _resolve_includes(self, content: str, include_stack: Optional[List[str]] = None) -> str:
        """Resolve all {{include:path}} directives recursively.

        Args:
            content: Template content with potential includes
            include_stack: Stack of included paths for cycle detection

        Returns:
            Content with all includes resolved

        Raises:
            ValueError: If circular include or depth limit exceeded
            FileNotFoundError: If included template not found
        """
        if include_stack is None:
            include_stack = []

        def replace_include(match: re.Match) -> str:
            include_path = match.group(1).strip()

            # Cycle detection
            if include_path in include_stack:
                cycle = " -> ".join(include_stack + [include_path])
                raise ValueError(f"Circular include detected: {cycle}")

            # Depth limit (stack includes root template, so check > not >=)
            if len(include_stack) > _MAX_INCLUDE_DEPTH:
                raise ValueError(f"Include depth exceeded {_MAX_INCLUDE_DEPTH}")

            # Load and recursively resolve
            included_content = self._load_raw_template(include_path)
            # Resolve repo includes using the included file's own path so that
            # {{include_repo:name}} resolves relative to the included template,
            # not the top-level template that triggered the include.
            resolved_path = self._get_template_path(include_path)
            if resolved_path:
                included_content = self._resolve_repo_includes(included_content, resolved_path)
            resolved = self._resolve_includes(included_content, include_stack + [include_path])

            if self.annotate_includes and resolved_path:
                resolved = (
                    f"<!-- begin include:{include_path} ({resolved_path}) -->\n"
                    f"{resolved}\n"
                    f"<!-- end include:{include_path} -->"
                )
            return resolved

        return _INCLUDE_PATTERN.sub(replace_include, content)

    def _resolve_repo_includes(self, content: str, template_path: Path, _depth: int = 0) -> str:
        """Resolve all {{include_repo:name}} directives.

        Repo includes resolve to files at ``<prompt_dir>/repo/<repo>/<name>.md`` where
        ``<prompt_dir>`` is the directory containing the original template. For nested
        repo includes, the same repo directory is used consistently.

        If ``self.repo`` is not set, all directives are silently stripped.
        Missing files are silently skipped (graceful degradation for new tracers).

        Args:
            content: Template content with potential repo includes
            template_path: Path of the original template file (used to find the repo dir)
            _depth: Current recursion depth

        Returns:
            Content with repo includes resolved or stripped
        """
        if not _INCLUDE_REPO_PATTERN.search(content):
            return content

        if _depth >= _MAX_INCLUDE_DEPTH:
            raise ValueError(f"Repo include depth exceeded {_MAX_INCLUDE_DEPTH}")

        # Repo dir is always relative to the original template's parent
        repo_dir = template_path.parent / "repo" / self.repo if self.repo else None

        def replace_repo_include(match: re.Match) -> str:
            name, excluded_repos = _parse_repo_directive(match.group(1))

            # Repo explicitly excluded by the directive — intentional opt-out
            if self.repo and self.repo in excluded_repos:
                return ""

            # No repo configured — error: every prompt with include_repo must be run with a repo
            if not repo_dir:
                raise ValueError(
                    f"include_repo directive used but no repo is configured "
                    f"(directive: {{{{include_repo:{name}}}}}). "
                    f"Set a repo on the PromptLoader, or exclude repos explicitly with "
                    f"{{{{include_repo:{name},excluded_repos=<repo>}}}}."
                )

            repo_file = repo_dir / f"{name}.md"
            if not repo_file.exists():
                raise FileNotFoundError(
                    f"include_repo fragment missing: {repo_file}\n"
                    f"  Directive: {{{{include_repo:{name}}}}}\n"
                    f"  Repo: {self.repo}\n"
                    f"  To skip this repo, use: {{{{include_repo:{name},excluded_repos={self.repo}}}}}"
                )

            if repo_file not in self._tracked_files["includes"]:
                self._tracked_files["includes"].append(repo_file)
            included = repo_file.read_text()

            if self.annotate_includes:
                included = (
                    f"<!-- begin include_repo:{name} ({repo_file}) -->\n"
                    f"{included}\n"
                    f"<!-- end include_repo:{name} -->"
                )

            # Recurse — pass original template_path to keep repo dir consistent
            return self._resolve_repo_includes(included, template_path, _depth + 1)

        return _INCLUDE_REPO_PATTERN.sub(replace_repo_include, content)

    def _resolve_links(self, content: str) -> str:
        """Resolve all {{link:path}} directives to reference text.

        Validates that linked files exist and tracks them for copying.
        Links are resolved to reference a local `references/` directory
        where the files will be copied by copy_linked_files().

        Args:
            content: Template content with potential links

        Returns:
            Content with links replaced by reference text

        Raises:
            FileNotFoundError: If linked template not found
        """

        def replace_link(match: re.Match) -> str:
            link_path = match.group(1).strip()
            description = match.group(2)

            # Validate the linked file exists
            source_path = self._get_template_path(link_path)
            if not source_path:
                raise FileNotFoundError(
                    f"Linked template '{link_path}' not found in prompt directories"
                )

            # Track the linked file for later copying and config hashing
            self._linked_files[link_path] = source_path
            if source_path not in self._tracked_files["links"]:
                self._tracked_files["links"].append(source_path)

            # Generate reference text pointing to local references/ directory
            local_path = f"references/{link_path}.md"
            if description:
                text = f"**{description.strip()}** - Read `{local_path}` for detailed guidance"
            else:
                text = f"**Reference:** Read `{local_path}` for relevant guidance"

            if self.annotate_includes:
                text = (
                    f"<!-- begin link:{link_path} ({source_path}) -->\n"
                    f"{text}\n"
                    f"<!-- end link:{link_path} -->"
                )
            return text

        return _LINK_PATTERN.sub(replace_link, content)

    def get_linked_files(self) -> Dict[str, Path]:
        """Get all linked files discovered during template loading.

        Returns:
            Dict mapping link_path -> source_file_path
        """
        return dict(self._linked_files)

    def copy_linked_files(self, destination: Path) -> List[Path]:
        """Copy all linked files to a destination directory.

        Creates a references/ subdirectory structure matching the link paths.

        Args:
            destination: Directory to copy files to (references/ subdir will be created)

        Returns:
            List of copied file paths
        """
        copied = []
        refs_dir = destination / "references"

        for link_path, source_path in self._linked_files.items():
            dest_path = refs_dir / f"{link_path}.md"
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, dest_path)
            copied.append(dest_path)

        return copied

    def clear_linked_files(self) -> None:
        """Clear tracked linked files (call before loading a new prompt)."""
        self._linked_files.clear()

    def get_tracked_files(self) -> Dict[str, List[Path]]:
        """Return all files opened during template loading, organised by category.

        Categories:
            prompts:  Top-level template files (one per load() call).
            includes: Files inlined via {{include:}} or {{include_repo:}} directives.
            links:    Files referenced via {{link:}} directives (agent reads on demand).

        These categories feed into ``config_hash.compute_run_config_hash()`` so that
        the run_config_hash changes whenever any content affecting agent behaviour
        changes, even if the top-level template itself is unchanged.
        """
        return {k: list(v) for k, v in self._tracked_files.items()}

    def _load_template(self, name: str) -> str:
        """Load template content, with caching.

        Resolves {{include:path}}, {{include_repo:name}}, and {{link:path}} directives
        before caching. Also caches linked files so they're available on cache hits.
        """
        cache_key = f"{name}:{self.repo or ''}:{self.annotate_includes}"
        if cache_key in self._cache:
            # Restore linked files from cache so get_linked_files() works after clear
            content, cached_links = self._cache[cache_key]
            self._linked_files.update(cached_links)
            return content

        path = self._get_template_path(name)
        if not path:
            searched = [str(d) for d in self.prompts_dirs]
            raise FileNotFoundError(f"Prompt template '{name}' not found in: {', '.join(searched)}")

        # Track top-level template file (separate from {{include:}} fragments)
        if path not in self._tracked_files["prompts"]:
            self._tracked_files["prompts"].append(path)

        content = path.read_text()
        self._check_hardcoded_schemas(name, content)

        # Track linked files discovered during this template's resolution
        links_before = set(self._linked_files.keys())

        # Resolve includes (recursive), then repo includes, then links.
        # A second include pass handles {{include:}} directives inside repo fragments.
        content = self._resolve_includes(content, include_stack=[name])
        content = self._resolve_repo_includes(content, path)
        content = self._resolve_includes(content, include_stack=[name])
        content = self._resolve_links(content)

        # Capture only the new links discovered for this template
        new_links = {k: v for k, v in self._linked_files.items() if k not in links_before}

        # Cache both content and its linked files
        self._cache[cache_key] = (content, new_links)
        return content

    def _check_hardcoded_schemas(self, name: str, content: str) -> None:
        """Warn if template appears to contain hardcoded JSON schemas.

        Templates should use output_schema parameter for dynamic schema injection,
        not hardcoded JSON in the template itself.
        """
        for pattern in _HARDCODED_SCHEMA_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE):
                warnings.warn(
                    f"Prompt template '{name}' may contain hardcoded JSON schema. "
                    f"Use output_schema parameter instead for dynamic schema injection.",
                    UserWarning,
                    stacklevel=4,
                )
                break  # One warning per template is enough

    def _render(
        self,
        template: str,
        variables: Dict[str, Any],
        fallback: Optional[Callable[[str], Any]] = None,
    ) -> str:
        """Render template with variable substitution.

        Uses {{variable}} syntax. For missing variables, tries the fallback callable
        if provided. Raises if any variables remain unsubstituted after fallback.
        """
        result = template

        for key, value in variables.items():
            result = result.replace(f"{{{{{key}}}}}", str(value))

        # Check for unreplaced placeholders and try fallback
        remaining = re.findall(r"\{\{(\w+)\}\}", result)
        if remaining and fallback:
            for var in remaining:
                value = fallback(var)
                if value is not None:
                    result = result.replace(f"{{{{{var}}}}}", str(value))
            remaining = re.findall(r"\{\{(\w+)\}\}", result)

        if remaining:
            raise ValueError(f"Missing prompt variables: {', '.join(remaining)}")

        return result

    def clear_cache(self) -> None:
        """Clear the template cache."""
        self._cache.clear()

    def validate_references(self) -> List[str]:
        """Validate all prompts in search directories for broken includes/links.

        Scans all .md files in the prompt directories and checks that any
        ``{{include:path}}``, ``{{include_repo:name}}``, and ``{{link:path}}``
        references point to existing files. Repo include fragments inside
        ``repo/`` subdirectories are skipped (they are not standalone templates).

        Returns:
            List of error messages for broken references (empty if all valid)
        """
        errors = []
        for prompts_dir in self.prompts_dirs:
            if not prompts_dir.exists():
                continue
            for prompt_file in prompts_dir.rglob("*.md"):
                # Skip repo include fragments — they are not standalone templates
                try:
                    rel = prompt_file.relative_to(prompts_dir)
                except ValueError:
                    rel = None
                if rel and "repo" in rel.parts:
                    continue

                # Get relative name for error messages
                try:
                    name = prompt_file.relative_to(prompts_dir).with_suffix("").as_posix()
                except ValueError:
                    name = prompt_file.stem

                content = prompt_file.read_text()

                # Check includes
                for match in _INCLUDE_PATTERN.finditer(content):
                    include_path = match.group(1).strip()
                    if not self._get_template_path(include_path):
                        errors.append(f"{name}: broken include '{{{{include:{include_path}}}}}'")

                # Check links
                for match in _LINK_PATTERN.finditer(content):
                    link_path = match.group(1).strip()
                    if not self._get_template_path(link_path):
                        errors.append(f"{name}: broken link '{{{{link:{link_path}}}}}'")

                # Check repo includes (only when repo is set)
                if self.repo:
                    for match in _INCLUDE_REPO_PATTERN.finditer(content):
                        include_name, excluded_repos = _parse_repo_directive(match.group(1))
                        if self.repo in excluded_repos:
                            continue
                        repo_file = prompt_file.parent / "repo" / self.repo / f"{include_name}.md"
                        if not repo_file.exists():
                            errors.append(
                                f"{name}: broken repo include "
                                f"'{{{{include_repo:{include_name}}}}}' "
                                f"for repo '{self.repo}'"
                            )

        return errors
