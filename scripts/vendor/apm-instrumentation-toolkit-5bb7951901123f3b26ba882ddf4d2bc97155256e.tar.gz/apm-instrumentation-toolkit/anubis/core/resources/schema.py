"""Schema documentation utilities."""

from typing import Type, get_args, get_origin

from pydantic import BaseModel

_PRIMITIVES = {
    "str": "string",
    "int": "number",
    "float": "number",
    "bool": "boolean",
    "None": "null",
}


def _format_type(annotation, indent: int = 2) -> str:
    """Recursively format a type annotation as TypeScript-like syntax."""
    if annotation is None or annotation is type(None):
        return "null"

    origin = get_origin(annotation)
    args = get_args(annotation)

    # Handle Union (including Optional)
    if origin is not None and str(origin).startswith("typing.Union"):
        formatted = [_format_type(arg, indent) for arg in args]
        return " | ".join(formatted)

    # Handle List[X]
    if origin is list:
        inner = _format_type(args[0], indent) if args else "any"
        # Wrap multi-line types in parens
        if "\n" in inner:
            return f"({inner})[]"
        return f"{inner}[]"

    # Handle Dict[K, V]
    if origin is dict:
        if len(args) >= 2:
            key_type = _format_type(args[0], indent)
            val_type = _format_type(args[1], indent)
            return f"Record<{key_type}, {val_type}>"
        return "Record<string, any>"

    # Handle nested Pydantic models - expand inline
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        return _format_model(annotation, indent)

    # Handle primitives
    name = getattr(annotation, "__name__", str(annotation))
    return _PRIMITIVES.get(name, name)


def _format_model(model: Type[BaseModel], indent: int = 2) -> str:
    """Format a Pydantic model as inline TypeScript object."""
    pad = " " * indent
    lines = ["{"]

    for name, field in model.model_fields.items():
        ts_type = _format_type(field.annotation, indent + 2)
        opt = "" if field.is_required() else "?"
        comment = f"  // {field.description}" if field.description else ""

        # Handle multi-line nested types
        if "\n" in ts_type:
            nested_lines = ts_type.split("\n")
            lines.append(f"{pad}{name}{opt}: {nested_lines[0]}")
            for nested_line in nested_lines[1:-1]:
                lines.append(f"{pad}{nested_line}")
            # Last line gets the comma and comment
            lines.append(f"{pad}{nested_lines[-1]},{comment}")
        else:
            lines.append(f"{pad}{name}{opt}: {ts_type},{comment}")

    lines.append("}")
    return "\n".join(lines)


def schema_to_doc(model: Type[BaseModel]) -> str:
    """Convert Pydantic model to TypeScript-like documentation string."""
    formatted = _format_model(model)

    return f"""Output must be valid JSON matching this format:

```typescript
{formatted}
```

**CRITICAL**: Return valid JSON at the top level. Do NOT wrap in `{{"output": ...}}` or other root level keys."""
