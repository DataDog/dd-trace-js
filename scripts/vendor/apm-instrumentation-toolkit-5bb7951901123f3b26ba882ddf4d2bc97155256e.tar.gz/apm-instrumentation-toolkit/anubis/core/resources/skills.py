"""Skill loader - loads and installs skill files."""

import logging
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any, List, Optional

from .registry import SkillRegistry

if TYPE_CHECKING:
    from anubis.core.context import Context

logger = logging.getLogger(__name__)


class SkillLoader:
    """Loads skill files and installs them for agents.

    Searches directories in priority order (first match wins).
    Resolves groups via SkillRegistry before loading.

    Example::

        loader = SkillLoader(
            skills_dirs=[
                Path('my_app/skills/domain'),   # Domain-specific first
                Path('my_app/skills/shared'),   # Fallback
            ],
            registry=SkillRegistry({'debugging': ['debug-1', 'debug-2']})
        )

        # Get formatted summaries for prompt injection
        summaries = loader.get_summaries(['debugging', 'test-runner'])

        # Install skill files to agent working directory
        loader.install(['debugging'], working_dir=Path('/tmp/agent'))

    """

    def __init__(
        self,
        skills_dirs: List[Path],
        registry: Optional[SkillRegistry] = None,
    ):
        """
        Args:
            skills_dirs: Directories to search for skill files, in priority order
            registry: Optional SkillRegistry for resolving groups
        """
        self.skills_dirs = [Path(d) for d in skills_dirs]
        self.registry = registry or SkillRegistry()

    @staticmethod
    def resolve_for_step(step: Any, ctx: Optional["Context"]) -> Optional[List[str]]:
        """Return the active skill list for an agent step.

        Combines the step's class-level ``skills`` declaration with any
        spec-level skills override from ``ctx["_spec_skills_override"]``
        (set by :meth:`anubis.core.resources.spec.TaskSpec.inject_into`).

        **Append, not replace.** When both lists are non-empty the spec
        skills are appended to the step's skills (deduplicated, order
        preserved). Specs are additive context — they cannot silently
        strip skills the step author considered necessary.

        Special cases:

        - Steps with **no** ``skills`` attribute (the common default) receive
          ``[]``, which means "all available skills".
        - Steps with ``skills = None`` explicitly opt out — ``None`` is returned,
          and no skills are installed or injected into the prompt. Spec overrides
          are also suppressed in this case.
        - Empty list ``[]`` from the spec is treated as "not set"; the spec
          channel is only honored when it's a non-empty list.
        - Non-list values (e.g. test-fixture placeholder strings) are ignored
          defensively.

        This method is a ``@staticmethod`` rather than instance-bound
        because resolution depends only on the step config and ``ctx`` —
        no SkillLoader filesystem state is read.
        """
        if not hasattr(step, "skills"):
            step_skills: List[str] = []  # no attribute → all available skills
        elif step.skills is None:
            return None  # explicit opt-out: skip skill installation entirely
        else:
            step_skills = list(step.skills)

        if ctx is None:
            return step_skills

        override = ctx.get("_spec_skills_override")
        if not isinstance(override, list) or not override:
            return step_skills

        seen = set(step_skills)
        merged = list(step_skills)
        for s in override:
            if s not in seen:
                merged.append(s)
                seen.add(s)
        return merged

    def list_all(self) -> List[str]:
        """List all available skill names.

        Scans all skill directories for skill files in both layouts:
        - Flat: {name}.md
        - Directory: {name}/SKILL.md

        Returns:
            List of unique skill names (without duplicates across directories)
        """
        skills: set = set()
        for skills_dir in self.skills_dirs:
            if not skills_dir.exists():
                continue

            # Flat layout: *.md files
            for path in skills_dir.glob("*.md"):
                skills.add(path.stem)

            # Directory layout: */SKILL.md
            for path in skills_dir.glob("*/SKILL.md"):
                skills.add(path.parent.name)

        return sorted(skills)

    def get_skill_path(self, name: str) -> Optional[Path]:
        """Find skill file by name.

        Args:
            name: Skill name (without .md extension)

        Returns:
            Path to skill file, or None if not found

        Supports two layouts:
        1. Flat: skills_dir/{name}.md
        2. Directory: skills_dir/{name}/SKILL.md
        """
        for skills_dir in self.skills_dirs:
            # Try flat layout first: {name}.md
            flat_path = skills_dir / f"{name}.md"
            if flat_path.exists():
                return flat_path

            # Try directory layout: {name}/SKILL.md
            dir_path = skills_dir / name / "SKILL.md"
            if dir_path.exists():
                return dir_path
        return None

    def get_summary(self, name: str, max_length: int = 0) -> Optional[str]:
        """Get summary for a single skill.

        Extracts the first paragraph or description section from the skill file.

        Args:
            name: Skill name
            max_length: Truncate summary to this many characters (0 = no limit).
                        Truncation strips "Triggers: ..." suffixes first, then
                        hard-truncates with "..." if still over limit.

        Returns:
            Summary string, or None if skill not found
        """
        path = self.get_skill_path(name)
        if not path:
            return None

        content = path.read_text()
        summary = self._extract_summary(name, content)

        if max_length > 0:
            summary = self._truncate_summary(summary, max_length)

        return summary

    def get_summaries(
        self, skills: Optional[List[str]] = None, working_directory: Optional[Path] = None
    ) -> str:
        """Get formatted summaries for multiple skills.

        Resolves groups and formats for prompt injection.

        Args:
            skills: List of skill names or group names.
                    Empty list [] means ALL skills.
                    None means NO skills.
            working_directory: Agent working directory (for absolute skill paths)

        Returns:
            Formatted markdown string with skill summaries
        """
        # None means no skills
        if skills is None:
            return ""

        # Empty list means all skills
        if len(skills) == 0:
            skills = self.list_all()

        if not skills:
            return ""

        resolved = sorted(self.registry.resolve(skills))

        if not resolved:
            return ""

        # Build skills path (absolute if working_directory provided, relative otherwise)
        if working_directory:
            skills_base = str(Path(working_directory) / ".claude" / "skills")
        else:
            skills_base = "./.claude/skills"

        lines = [
            "## Available Skills",
            "",
            f"Skills contain critical domain knowledge. Read the full skill file at `{skills_base}/{{name}}/SKILL.md`",
            "",
        ]

        for name in resolved:
            summary = self.get_summary(name, max_length=300)
            if summary:
                lines.append(f"### {name}")
                lines.append(summary)
                lines.append("")

        # Add skill evaluation instruction at the end
        lines.extend([
            "---",
            "",
            "## ⛔ MANDATORY: Read Skills Before ANY Action",
            "",
            "**DO NOT start working until you have read the relevant skills.**",
            "",
            "1. Read each skill name and description above",
            f"2. For EACH skill that could be relevant to your task, read the full `{skills_base}/{{name}}/SKILL.md` file",
            "3. In your first response, list which skills you read and why they're relevant",
            "4. Only then begin your actual task",
            "",
            "**Example:** If writing tests, read any testing-related skills first.",
            "**Example:** If writing integrations, read integration-related skills first.",
            "",
            "Skills contain CRITICAL patterns you cannot guess. Read them or fail.",
        ])

        return "\n".join(lines)

    def get_skill_dir(self, name: str) -> Optional[Path]:
        """Find skill directory by name.

        For directory layout skills, returns the directory containing SKILL.md.
        For flat layout skills, returns None.

        Args:
            name: Skill name

        Returns:
            Path to skill directory, or None if flat layout or not found
        """
        for skills_dir in self.skills_dirs:
            # Check directory layout: {name}/SKILL.md
            dir_path = skills_dir / name
            if (dir_path / "SKILL.md").exists():
                return dir_path
        return None

    def install(
        self, skills: Optional[List[str]] = None, working_dir: Optional[Path] = None
    ) -> List[tuple[Path, bool]]:
        """Install skill files to agent working directory.

        Copies skill files to .claude/skills/ in the working directory.
        For directory layout skills, copies the entire directory including
        references/, scripts/, and other subdirectories.

        Args:
            skills: List of skill names or group names.
                    Empty list [] means ALL skills.
                    None means NO skills.
            working_dir: Agent working directory

        Returns:
            List of (path, pre_existing) tuples. pre_existing is True if the
            skill directory already existed before installation (e.g. a repo's
            own skill), so cleanup can skip it.
        """
        # None means no skills
        if skills is None:
            return []

        # Empty list means all skills
        if len(skills) == 0:
            skills = self.list_all()

        if not skills:
            return []

        resolved = self.registry.resolve(skills)

        if not resolved:
            return []

        if working_dir is None:
            return []
        target_dir = Path(working_dir) / ".claude" / "skills"
        target_dir.mkdir(parents=True, exist_ok=True)

        # Prevent git from tracking installed skills. A .gitignore with "*"
        # ignores all contents including itself, so git add / git commit never
        # picks up skill files even when the agent runs from the repo root.
        gitignore = target_dir / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*\n")

        installed = []
        for name in resolved:
            skill_src_dir = self.get_skill_dir(name)
            skill_dst_dir = target_dir / name
            # Track whether the directory existed before we installed, so cleanup
            # only removes skills we created (not pre-existing repo skills).
            pre_existing = skill_dst_dir.exists()

            try:
                if pre_existing:
                    # Pre-existing skill directory (e.g. repo's own skill) — do not
                    # overwrite its contents, just record it for the agent to use.
                    installed.append((skill_dst_dir / "SKILL.md", True))
                elif skill_src_dir:
                    # Directory layout: copy entire directory (SKILL.md + references/ + scripts/)
                    # dirs_exist_ok=True handles the race where parallel batch agents
                    # all see pre_existing=False then try to copy simultaneously.
                    shutil.copytree(skill_src_dir, skill_dst_dir, dirs_exist_ok=True)
                    installed.append((skill_dst_dir / "SKILL.md", False))
                else:
                    # Flat layout: copy single .md file into directory structure
                    src = self.get_skill_path(name)
                    if src:
                        skill_dst_dir.mkdir(parents=True, exist_ok=True)
                        dst = skill_dst_dir / "SKILL.md"
                        shutil.copy(src, dst)
                        installed.append((dst, False))
            except OSError as e:
                logger.warning(f"Failed to install skill '{name}': {e}")
                continue

        return installed

    @staticmethod
    def _truncate_summary(summary: str, max_length: int) -> str:
        """Truncate a skill summary for prompt injection.

        Strips ``Triggers: ...`` suffixes first (these are for routing, not
        agents), then hard-truncates with ``...`` if still over *max_length*.

        Args:
            summary: Raw summary text
            max_length: Maximum character length

        Returns:
            Truncated summary
        """
        # Strip "Triggers: ..." suffix (routing metadata, not useful for agents)
        triggers_idx = summary.find("Triggers:")
        if triggers_idx > 0:
            summary = summary[:triggers_idx].rstrip().rstrip(".")
            # Re-add period if the trimmed text doesn't end with punctuation
            if summary and summary[-1] not in ".!?":
                summary += "."

        # Hard truncate if still over limit
        if len(summary) > max_length:
            summary = summary[: max_length - 3].rstrip() + "..."

        return summary

    def _extract_summary(self, name: str, content: str) -> str:
        """Extract summary from skill file content.

        Looks for:
        1. YAML front matter 'description' field (single or multi-line)
        2. A "## Summary" or "## Description" section
        3. Falls back to first non-header paragraph (after front matter)

        Args:
            name: Skill name (for fallback)
            content: Full skill file content

        Returns:
            Summary string
        """
        lines = content.strip().split("\n")

        # Check for YAML front matter and extract description
        if lines and lines[0].strip() == "---":
            front_matter_end = None
            for i, line in enumerate(lines[1:], 1):
                if line.strip() == "---":
                    front_matter_end = i
                    break
                # Look for description field in front matter
                if line.strip().startswith("description:"):
                    desc = line.split(":", 1)[1].strip()
                    # Handle single-line description
                    if desc and desc != "|" and desc != ">":
                        return desc
                    # Handle multi-line YAML block scalar (| or >)
                    if desc in ("|", ">"):
                        multi_lines = []
                        for j in range(i + 1, len(lines)):
                            next_line = lines[j]
                            # End of block: closing --- or non-indented line
                            if next_line.strip() == "---":
                                break
                            # Multi-line content is indented
                            if next_line.startswith("  ") or next_line.startswith("\t"):
                                multi_lines.append(next_line.strip())
                            elif next_line.strip() == "":
                                continue  # Skip empty lines within block
                            else:
                                break  # Non-indented line ends block
                        if multi_lines:
                            return " ".join(multi_lines)

            # Skip past front matter for further processing
            if front_matter_end is not None:
                lines = lines[front_matter_end + 1 :]

        # Look for summary/description section
        in_summary = False
        summary_lines = []

        for line in lines:
            lower = line.lower().strip()

            # Check for summary section header
            if lower.startswith("## summary") or lower.startswith("## description"):
                in_summary = True
                continue

            # End summary section on next header
            if in_summary and line.startswith("#"):
                break

            if in_summary:
                summary_lines.append(line)

        if summary_lines:
            return "\n".join(summary_lines).strip()

        # Fallback: first non-empty, non-header paragraph
        for line in lines:
            line = line.strip()
            if line and not line.startswith("#"):
                return line

        return f"Skill: {name}"
