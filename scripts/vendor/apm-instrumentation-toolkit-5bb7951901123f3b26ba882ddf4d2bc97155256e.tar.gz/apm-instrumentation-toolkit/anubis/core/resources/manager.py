"""Resource manager - unified access to prompts, skills, and hooks.

Provides a single interface for loading all resource types with:
- Configuration-based paths
- Caching per repository
- Easy bundle access
"""

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Optional

from .prompts import PromptLoader
from .registry import SkillRegistry
from .sdk_hooks import SDKHookLoader
from .skills import SkillLoader

if TYPE_CHECKING:
    from ..config import AnubisConfig


@dataclass
class ResourceBundle:
    """Bundle of resource loaders for a repository.

    Provides access to prompts, skills, and hooks for a specific
    repository context.

    Example::

        bundle = resource_manager.get_bundle('dd_trace_js')
        prompt = bundle.prompts.load('analyze', package='kafkajs')
        bundle.skills.install(['debugging'], working_dir)
    """

    prompts: PromptLoader
    skills: SkillLoader
    hooks: SDKHookLoader

    @property
    def skill_loader(self) -> SkillLoader:
        """Alias for skills (backward compatibility)."""
        return self.skills


class ResourceManager:
    """Manages resource loading across repositories.

    Coordinates prompts, skills, and hooks loading based on configuration.
    Caches bundles per repository for efficiency.

    Example::

        from anubis.core.config import get_config
        from anubis.core.resources import ResourceManager

        config = get_config()
        manager = ResourceManager(config)

        # Get bundle for default repository
        bundle = manager.get_bundle()

        # Get bundle for specific repository
        bundle = manager.get_bundle('dd_trace_py')

        # Access loaders
        prompt = bundle.prompts.load('analyze', package='kafkajs')
        bundle.skills.install(['debugging'], working_dir)

    """

    def __init__(
        self,
        config: "AnubisConfig",
        prompts_root: Optional[Path] = None,
        skills_root: Optional[Path] = None,
        hooks_root: Optional[Path] = None,
        skill_registry: Optional[SkillRegistry] = None,
        system_prompt: Optional[str] = None,
    ):
        """
        Args:
            config: AnubisConfig instance
            prompts_root: Override prompts root directory
            skills_root: Override skills root directory
            hooks_root: Override hooks root directory
            skill_registry: Shared skill registry for group resolution
            system_prompt: Global system prompt for all agents
        """
        self.config = config
        self.system_prompt = system_prompt

        # Default to toolkit_root/anubis_apm/{prompts,agent/skills,hooks}
        apm_root = config.toolkit_root / "anubis_apm"
        self.prompts_root = prompts_root or (apm_root / "prompts")
        self.skills_root = skills_root or (apm_root / "agent" / "skills")
        self.hooks_root = hooks_root or (apm_root / "agent" / "hooks")

        self.skill_registry = skill_registry or SkillRegistry()
        self._bundles: Dict[str, ResourceBundle] = {}

    def get_bundle(
        self,
        repository: Optional[str] = None,
        user: Optional[str] = None,
    ) -> ResourceBundle:
        """Get resource bundle for a repository.

        Args:
            repository: Repository name (uses default if None)
            user: Optional user guidance for prompts

        Returns:
            ResourceBundle with configured loaders
        """
        repo_name = repository or self.config.default_repository

        # Check cache (only if no user prompt, as that affects PromptLoader)
        cache_key = f"{repo_name}:{user or ''}"
        if cache_key in self._bundles:
            return self._bundles[cache_key]

        # Get repository config
        repo_config = self.config.get_repo(repo_name)

        # Build search paths for each resource type
        prompts_dirs = self._get_prompts_dirs(repo_config.name)
        skills_dirs = self._get_skills_dirs(repo_config.name)
        hooks_dirs = self._get_hooks_dirs(repo_config.name)

        # Create skill loader first (needed for prompt loader)
        skills = SkillLoader(skills_dirs=skills_dirs, registry=self.skill_registry)

        # Create prompt loader with skill integration
        prompts = PromptLoader(
            prompts_dirs=prompts_dirs,
            user=user,
            skill_loader=skills.get_summaries,
            repo=repo_name,
        )

        # Create SDK hook loader
        hooks = SDKHookLoader(hooks_dirs=hooks_dirs)

        bundle = ResourceBundle(prompts=prompts, skills=skills, hooks=hooks)
        self._bundles[cache_key] = bundle
        return bundle

    def _get_prompts_dirs(self, repo_name: str) -> List[Path]:
        """Get prompt directories for a repository."""
        dirs: List[Path] = []

        # Repository-specific prompts
        if self.prompts_root:
            dirs.append(self.prompts_root / repo_name)
            dirs.append(self.prompts_root / "shared")

        # User-configured additional paths
        dirs.extend(self.config.resources.prompts)

        return [d for d in dirs if d.exists()]

    def _get_skills_dirs(self, repo_name: str) -> List[Path]:
        """Get skill directories for a repository.

        Search order (first match wins):
          1. Toolkit-shipped, repo-specific: ``anubis_apm/agent/skills/{repo_name}/``
          2. Toolkit-shipped, cross-repo: ``anubis_apm/agent/skills/shared/``
          3. Target repo's bundled skills: ``{repo_path}/.agents/skills/`` and
             ``{repo_path}/.claude/skills/`` — repo-curated skills travel with
             the tracer codebase. Loading these here means ``use_repo_root``
             agents pick them up alongside the toolkit-shipped set.
          4. User-configured additional paths from ``config.resources.skills``.
        """
        dirs: List[Path] = []

        if self.skills_root:
            dirs.append(self.skills_root / repo_name)
            dirs.append(self.skills_root / "shared")

        try:
            repo_config = self.config.get_repo(repo_name)
        except (KeyError, ValueError):
            repo_config = None
        if repo_config is not None and repo_config.path:
            for convention in (".agents/skills", ".claude/skills"):
                dirs.append(Path(repo_config.path) / convention)

        dirs.extend(self.config.resources.skills)

        return [d for d in dirs if d.exists()]

    def _get_hooks_dirs(self, repo_name: str) -> List[Path]:
        """Get hook directories for a repository."""
        dirs: List[Path] = []

        # Repository-specific hooks
        if self.hooks_root:
            dirs.append(self.hooks_root / repo_name)
            dirs.append(self.hooks_root / "shared")

        # User-configured additional paths
        dirs.extend(self.config.resources.hooks)

        return [d for d in dirs if d.exists()]

    def clear_cache(self) -> None:
        """Clear all cached bundles."""
        self._bundles.clear()

    def create_prompts(
        self,
        repository: Optional[str] = None,
        user: Optional[str] = None,
    ) -> PromptLoader:
        """Create a PromptLoader for a repository.

        Convenience method for direct PromptLoader access.

        Args:
            repository: Repository name (uses default if None)
            user: Optional user guidance

        Returns:
            Configured PromptLoader
        """
        return self.get_bundle(repository, user).prompts

    def create_skill_loader(self, repository: Optional[str] = None) -> SkillLoader:
        """Create a SkillLoader for a repository.

        Convenience method for direct SkillLoader access.

        Args:
            repository: Repository name (uses default if None)

        Returns:
            Configured SkillLoader
        """
        return self.get_bundle(repository).skills
