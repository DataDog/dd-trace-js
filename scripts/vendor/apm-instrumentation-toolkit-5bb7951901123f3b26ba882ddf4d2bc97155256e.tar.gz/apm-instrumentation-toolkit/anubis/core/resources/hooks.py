"""Hook loader - loads hook configurations for workflows.

Hooks allow customizing workflow behavior at specific points:
- pre_step: Before a step executes
- post_step: After a step completes
- on_error: When a step fails

This is a minimal implementation for future expansion.
"""

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


# Hook type definition
HookFn = Callable[[str, Any], Optional[Any]]


class HookLoader:
    """Loads and manages workflow hooks.

    Hooks are defined in YAML files and can be loaded from multiple directories.

    Example hook file (hooks/validation.yaml)::

        pre_step:
          analyze:
            - validate_input
            - check_permissions

        post_step:
          analyze:
            - log_metrics

    Example usage::

        loader = HookLoader(hooks_dirs=[Path('my_app/hooks')])

        # Get hooks for a step
        pre_hooks = loader.get_hooks('pre_step', 'analyze')

    """

    def __init__(self, hooks_dirs: Optional[List[Path]] = None):
        """
        Args:
            hooks_dirs: Directories to search for hook files, in priority order
        """
        self.hooks_dirs = [Path(d) for d in hooks_dirs] if hooks_dirs else []
        self._hooks: Dict[str, Dict[str, List[str]]] = {}
        self._loaded = False

    def _load_hooks(self) -> None:
        """Load all hook configurations from directories."""
        if self._loaded:
            return

        for hooks_dir in self.hooks_dirs:
            if not hooks_dir.exists():
                continue

            for hook_file in hooks_dir.glob("*.yaml"):
                try:
                    with open(hook_file) as f:
                        data = yaml.safe_load(f) or {}

                    for hook_type, steps in data.items():
                        if hook_type not in self._hooks:
                            self._hooks[hook_type] = {}

                        if isinstance(steps, dict):
                            for step_name, hook_names in steps.items():
                                if step_name not in self._hooks[hook_type]:
                                    self._hooks[hook_type][step_name] = []
                                if isinstance(hook_names, list):
                                    self._hooks[hook_type][step_name].extend(hook_names)
                                elif hook_names:
                                    self._hooks[hook_type][step_name].append(str(hook_names))

                except (yaml.YAMLError, OSError) as e:
                    logger.warning(f"Failed to load hooks from {hook_file}: {e}")

        self._loaded = True

    def get_hooks(self, hook_type: str, step_name: str) -> List[str]:
        """Get hook names for a specific type and step.

        Args:
            hook_type: Type of hook (pre_step, post_step, on_error)
            step_name: Name of the step

        Returns:
            List of hook names to execute
        """
        self._load_hooks()
        return self._hooks.get(hook_type, {}).get(step_name, [])

    def has_hooks(self, hook_type: str, step_name: str) -> bool:
        """Check if any hooks are registered for a step.

        Args:
            hook_type: Type of hook
            step_name: Name of the step

        Returns:
            True if hooks exist
        """
        return len(self.get_hooks(hook_type, step_name)) > 0

    def list_all_hooks(self) -> Dict[str, Dict[str, List[str]]]:
        """Get all registered hooks.

        Returns:
            Dict mapping hook_type -> step_name -> [hook_names]
        """
        self._load_hooks()
        return dict(self._hooks)

    def clear_cache(self) -> None:
        """Clear the loaded hooks cache."""
        self._hooks.clear()
        self._loaded = False
