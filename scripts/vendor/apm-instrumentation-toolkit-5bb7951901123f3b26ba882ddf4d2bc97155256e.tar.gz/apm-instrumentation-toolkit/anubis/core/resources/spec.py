"""TaskSpec — parsed task specification with optional YAML frontmatter overrides.

``from_source`` resolves ``--spec`` input (file/stdin/inline-text) and is
the single entry point for spec input — unchanged.

``from_dynamic_source`` resolves ``--source`` input. It dispatches based
on a pluggable registry (``anubis.core.git.GITHUB_URL_FETCHERS``) — currently
GitHub issue/PR URLs and GitHub Actions failed-job URLs (fetched via the
``gh`` CLI), and intended to grow to GitLab CI, Datadog traces, Linear,
Jira, and other sources. Non-URL inputs (file, stdin, inline text) delegate
to ``from_source``; URL-shaped inputs that no fetcher claims raise so a
typo can't silently become a useless inline-text spec body. When both
flags are passed the CLI calls ``spec.merge(dynamic)`` to combine them.
"""

import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

import yaml
from pydantic import BaseModel, Field

from anubis.core.git import _URL_LIKE_RE, GITHUB_URL_FETCHERS, format_supported_github_sources

if TYPE_CHECKING:
    from anubis.core.context import Context


def _split_frontmatter(text: str) -> tuple[str, dict[str, Any]]:
    """Return ``(body, frontmatter)`` for a spec string.

    The leading ``---\\n...\\n---`` block is treated as frontmatter only when it
    is either empty or parses as a YAML mapping. Anything else (plain text, a
    YAML list, a bare horizontal rule) leaves ``body`` untouched so the leading
    section isn't silently dropped.
    """
    if not text.startswith("---"):
        return text, {}

    parts = text.split("---", 2)
    # parts[0] is the empty string before the first ---.
    if len(parts) < 3:
        return text, {}

    fm_text = parts[1].strip()
    rest = parts[2].strip()

    if not fm_text:
        # Empty frontmatter block (``---\n---\nbody``) — valid, no fields.
        return rest, {}

    parsed = yaml.safe_load(fm_text)
    if isinstance(parsed, dict):
        return rest, parsed

    return text, {}


class TaskSpec(BaseModel):
    """Parsed task specification with optional YAML frontmatter overrides."""

    body: str
    test_command: Optional[str] = None
    skills: list[str] = Field(default_factory=list)
    scope: Optional[str] = None
    max_test_iterations: int = 10
    extra: dict[str, Any] = Field(default_factory=dict)
    source_path: Optional[str] = Field(
        default=None,
        description=(
            "Absolute path to the spec file, when parsed from disk via "
            "``from_source``. ``None`` for inline text or stdin input. "
            "Surfaced in prompt templates as ``{{spec_path}}``."
        ),
    )

    @classmethod
    def parse(cls, raw: str) -> "TaskSpec":
        """Parse markdown with optional YAML frontmatter (--- delimited).

        Frontmatter is extracted from the leading ``---`` block. Known fields
        (``test_command``, ``skills``, ``scope``, ``max_test_iterations``) are
        mapped directly; everything else lands in ``extra``.
        """
        body, frontmatter = _split_frontmatter(raw.strip())

        known_fields = {"test_command", "skills", "scope", "max_test_iterations"}
        known = {k: v for k, v in frontmatter.items() if k in known_fields}
        extra = {k: v for k, v in frontmatter.items() if k not in known_fields}

        return cls(body=body, **known, extra=extra)

    @classmethod
    def from_source(cls, source: str) -> "TaskSpec":
        """Resolve source to raw text, then parse.

        - File path -> read file contents, record absolute path on ``source_path``
        - ``-`` -> read from stdin (``source_path`` is ``None``)
        - Anything else -> treat as inline text (``source_path`` is ``None``)
        """
        source_path: Optional[str] = None
        if source == "-":
            raw = sys.stdin.read()
        else:
            path = Path(source)
            if path.is_file():
                raw = path.read_text()
                source_path = str(path.resolve())
            else:
                raw = source

        spec = cls.parse(raw)
        if source_path is not None:
            spec.source_path = source_path
        return spec

    @classmethod
    def from_dynamic_source(cls, source: str) -> "TaskSpec":
        """Resolve a ``--source`` input — superset of ``from_source``.

        Dispatch is registry-driven (``_URL_FETCHERS``). Each entry is a
        ``(regex, fetcher)`` tuple; first match wins. Adding a new source
        type (GitLab, Datadog, Linear, …) is one tuple, no edit here.

        Behavior:

        - URL that matches a registered fetcher -> fetched and parsed.
        - URL-shaped (``http(s)://...``) but no fetcher claims it ->
          ``ValueError`` with a diagnostic listing supported sources.
          Silently treating an unrecognized URL as inline text gives
          the planner a useless URL string instead of the context the
          user expected to fetch — failing loud is safer.
        - Anything else -> delegate to ``from_source`` (file / stdin /
          inline text). ``from_source`` itself is unchanged.
        """
        for pattern, fetcher in GITHUB_URL_FETCHERS:
            if pattern.match(source):
                return cls.parse(fetcher(source))
        if _URL_LIKE_RE.match(source):
            raise ValueError(
                f"--source URL not recognized: {source!r}\n\n"
                f"Supported URL sources:\n{format_supported_github_sources()}\n\n"
                "If you meant this URL as literal text, write it into a "
                "file and pass --source <file>, or wrap it in a sentence "
                'so it\'s not URL-shaped (e.g. "see <url> for context").'
            )
        return cls.from_source(source)

    def merge(self, other: "TaskSpec") -> "TaskSpec":
        """Combine ``self`` (the ``--spec`` framing) with ``other`` (``--source``).

        Body: ``self.body`` first, then ``other.body`` under a separator
        section header — framing precedes specifics so constraints are
        established before the agent reads the concrete context.

        Frontmatter precedence: ``self`` wins on per-field conflicts;
        ``other`` fills gaps. The spec is the source of truth for task
        framing (``test_command``, ``scope``, etc.); ``--source`` content
        is contextual and shouldn't overwrite it.

        ``source_path`` takes ``self.source_path`` (the spec file) so
        prompt templates referencing ``{{spec_path}}`` resolve correctly.

        ``skills`` are unioned, preserving order with ``self``'s first.
        """
        merged_body = f"{self.body}\n\n## Concrete context from --source\n\n{other.body}"
        return TaskSpec(
            body=merged_body,
            test_command=self.test_command or other.test_command,
            scope=self.scope or other.scope,
            max_test_iterations=self.max_test_iterations,
            skills=list(dict.fromkeys([*self.skills, *other.skills])),
            extra={**other.extra, **self.extra},
            source_path=self.source_path,
        )

    def inject_into(self, ctx: "Context") -> None:
        """Publish this spec's fields to ``ctx`` for downstream prompt/agent use.

        Keys set (only when the value is non-``None`` / non-empty):

        - ``spec_body``, ``spec_scope``, ``spec_test_command``, ``spec_max_test_iterations``
        - ``spec_path`` — absolute path to the spec file when parsed from disk
        - ``spec_<extra>`` for each entry in ``self.extra``
        - ``_spec_skills_override`` — replaces the step's class-level ``skills``
          at runtime when the spec declares any. ``AgentStepExecutor`` reads
          this before calling the SDK. Empty list is treated as "not set"
          (the step default already means "all available skills").
        """
        ctx.set("spec_body", self.body)
        for attr in ("scope", "test_command", "max_test_iterations", "source_path"):
            value = getattr(self, attr, None)
            if value is not None:
                ctx.set(f"spec_{'path' if attr == 'source_path' else attr}", value)

        for key, value in (self.extra or {}).items():
            ctx.set(f"spec_{key}", value)

        if self.skills:
            ctx.set("_spec_skills_override", list(self.skills))
