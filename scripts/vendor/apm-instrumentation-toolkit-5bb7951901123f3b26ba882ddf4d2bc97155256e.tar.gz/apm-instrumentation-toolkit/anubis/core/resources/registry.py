"""Skill registry - resolves skill groups to individual skills."""

from typing import Dict, List, Optional


class SkillRegistry:
    """Resolves skill groups to individual skill names.

    Groups can reference other groups for nesting.

    Example::

        registry = SkillRegistry({
            'debugging': ['instrumentation-debug', 'log-analyzer'],
            'testing': ['test-runner', 'test-debug'],
            'all': ['debugging', 'testing'],  # References other groups
        })

        # Resolves to flat list
        skills = registry.resolve(['debugging', 'test-runner'])
        # -> ['instrumentation-debug', 'log-analyzer', 'test-runner']

    """

    def __init__(self, groups: Optional[Dict[str, List[str]]] = None):
        """
        Args:
            groups: Mapping of group names to skill/group names.
                    Groups can reference other groups.
        """
        self.groups = groups or {}

    def resolve(self, skills: List[str]) -> List[str]:
        """Resolve skill names and groups to flat deduplicated list.

        Args:
            skills: List of skill names or group names

        Returns:
            Flat list of individual skill names, deduplicated, order preserved
        """
        result: List[str] = []
        seen: set = set()

        def _resolve_one(name: str) -> None:
            if name in self.groups:
                for item in self.groups[name]:
                    _resolve_one(item)
            else:
                if name not in seen:
                    seen.add(name)
                    result.append(name)

        for skill in skills:
            _resolve_one(skill)

        return result

    def add_group(self, name: str, skills: List[str]) -> None:
        """Add or update a skill group."""
        self.groups[name] = skills

    def get_groups(self) -> Dict[str, List[str]]:
        """Get all registered groups."""
        return dict(self.groups)
