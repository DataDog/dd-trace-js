"""Unified resource management for anubis framework.

This module provides loading for prompts, skills, and hooks with:
- Directory fallback (priority-ordered search)
- Built-in templates as fallback
- Skill group resolution
- Resource bundles for easy access

Example usage::

    from anubis.core.config import get_config
    from anubis.core.resources import ResourceManager, ResourceBundle

    # With config-based setup
    config = get_config()
    manager = ResourceManager(config, prompts_root=Path('prompts'))
    bundle = manager.get_bundle('dd_trace_js')

    # Load a prompt
    prompt = bundle.prompts.load('analyze', package='kafkajs')

    # Install skills
    bundle.skills.install(['debugging'], working_dir)

Direct loader usage::

    from anubis.core.resources import PromptLoader, SkillLoader

    # Direct prompt loading
    loader = PromptLoader(prompts_dirs=[Path('prompts/node')])
    prompt = loader.load('analyze', package='kafkajs')

    # Direct skill loading
    skills = SkillLoader(skills_dirs=[Path('skills/node')])
    skills.install(['debugging'], working_dir)

Global resource registry::

    from anubis.core.resources import set_global_resource_manager, get_global_resources

    # Register global manager (called during app setup)
    set_global_resource_manager(manager)

    # Access from anywhere (workflows, steps, etc.)
    bundle = get_global_resources()
    prompt = bundle.prompts.load('analyze')
"""

from typing import TYPE_CHECKING, Optional

from .manager import ResourceBundle, ResourceManager
from .prompts import PromptLoader
from .registry import SkillRegistry
from .schema import schema_to_doc
from .sdk_hooks import SDKHookLoader
from .skills import SkillLoader

if TYPE_CHECKING:
    from ..context import Context

# Global resource manager registry
_global_resource_manager: Optional[ResourceManager] = None


def set_global_resource_manager(manager: ResourceManager) -> None:
    """Register a global ResourceManager.

    This should be called once during application initialization
    (e.g., in anubis_apm.setup.init()).

    Args:
        manager: ResourceManager instance to use globally
    """
    global _global_resource_manager
    _global_resource_manager = manager


def get_global_resource_manager() -> Optional[ResourceManager]:
    """Get the global ResourceManager if registered.

    Returns:
        ResourceManager instance, or None if not registered
    """
    return _global_resource_manager


def get_global_resources(repository: Optional[str] = None) -> Optional[ResourceBundle]:
    """Get resource bundle from global manager.

    Convenience function for workflows/steps to access resources
    without needing to know about the specific setup.

    Args:
        repository: Repository name (uses default if None)

    Returns:
        ResourceBundle if global manager is registered, None otherwise
    """
    if _global_resource_manager is None:
        return None
    return _global_resource_manager.get_bundle(repository)


def reset_global_resources() -> None:
    """Reset global resource manager (primarily for testing)."""
    global _global_resource_manager
    _global_resource_manager = None


_LOADED_PATHS_KEY = "_loaded_content_paths"


def flush_tracked_paths(ctx: "Context") -> None:
    """Copy PromptLoader tracked file paths into WorkflowState.data.

    Ensures ``state.data["_loaded_content_paths"]`` accumulates every file
    opened during template resolution so that config hashing can produce a
    meaningful ``run_config_hash`` at manifest build time.

    Called after each step/stage checkpoint in both Workflow and CompositeStep.
    """
    if not ctx.prompts or not ctx.state:
        return
    tracked = ctx.prompts.get_tracked_files()
    for category, paths in tracked.items():
        for path in paths:
            if _LOADED_PATHS_KEY not in ctx.state.data:
                ctx.state.data[_LOADED_PATHS_KEY] = {
                    "prompts": [],
                    "includes": [],
                    "links": [],
                    "skills": [],
                }
            paths_list = ctx.state.data[_LOADED_PATHS_KEY].setdefault(category, [])
            path_str = str(path)
            if path_str not in paths_list:
                paths_list.append(path_str)


__all__ = [
    # Manager
    "ResourceBundle",
    "ResourceManager",
    # Loaders
    "SDKHookLoader",
    "PromptLoader",
    "SkillLoader",
    # Registry
    "SkillRegistry",
    # Utilities
    "schema_to_doc",
    # Global registry
    "set_global_resource_manager",
    "get_global_resource_manager",
    "get_global_resources",
    "reset_global_resources",
    # Utilities
    "flush_tracked_paths",
]
