"""SDK hook loader - discovers and builds agent SDK hooks from directories.

Loads hook modules from shared + repository-specific directories,
discovers build_*_hook() functions, and builds hook callables
compatible with the Claude Agent SDK.

Hook builders are functions named ``build_*_hook()`` that return a
``HookCallback``. Builders may declare:

- An ``events`` attribute on the *module* (or *function*) listing the
  Claude Agent SDK event names this hook should run for. Defaults to
  ``["PreToolUse"]`` for backward compatibility. Examples: ``["Stop"]``,
  ``["Stop", "SubagentStop"]``, ``["PreToolUse"]``.

- An ``adapter`` parameter, which the loader fills in with the current
  repo adapter when invoking the builder. Builders that don't need the
  adapter omit the parameter entirely.

Example::

    # anubis_apm/agent/hooks/dd_trace_java/build.py
    events = ["Stop"]  # Module-level: applies to all build_*_hook in this file

    def build_java_build_hook(adapter):
        async def hook(input_data, tool_use_id, context):
            ...
        return hook
"""

import importlib.util
import inspect
import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Default event registration if a hook module/function declares no `events`.
# Matches pre-event-routing behavior so existing PreToolUse hooks keep working.
_DEFAULT_EVENTS: List[str] = ["PreToolUse"]


class SDKHookLoader:
    """Discovers and builds SDK hooks from Python modules in hook directories.

    Hook modules are Python files containing ``build_*_hook()`` functions.
    Each builder is called to produce a hook callable compatible with the
    Claude Agent SDK's ``HookCallback`` type.

    Directories are searched in order: repo-specific first, then shared.

    Hooks are returned as a dict keyed by SDK event name (e.g. ``"Stop"``,
    ``"PreToolUse"``) so the runner can register each one against the right
    ``hooks={...}`` entry in ``ClaudeAgentOptions``. Hook builders declare
    their target events via an ``events`` attribute on the module or
    function (defaults to ``["PreToolUse"]``).

    Example directory layout::

        anubis_apm/agent/hooks/
        ├── shared/
        │   └── test_quality.py      # build_test_quality_hook() — PreToolUse
        └── dd_trace_js/
            └── instrumentation.py   # build_instrumentation_hook() — PreToolUse

    Example usage::

        loader = SDKHookLoader(hooks_dirs=[
            Path('anubis_apm/agent/hooks/dd_trace_js'),
            Path('anubis_apm/agent/hooks/shared'),
        ])
        hooks_by_event = loader.load(adapter=repo_adapter)
        # {"PreToolUse": [hook1, hook2], "Stop": [hook3], ...}
    """

    def __init__(self, hooks_dirs: Optional[List[Path]] = None):
        """
        Args:
            hooks_dirs: Directories to search for hook modules, in priority order.
        """
        self.hooks_dirs = [Path(d) for d in hooks_dirs] if hooks_dirs else []
        self._builders: Optional[List[_BuilderEntry]] = None

    def load(self, adapter: Optional[Any] = None) -> Dict[str, List[Any]]:
        """Load and build fresh SDK hooks from configured directories.

        Discovers Python modules, finds ``build_*_hook()`` functions, calls
        them to produce hook callables, and groups them by SDK event name.
        Builders are cached but hooks are built fresh each call to avoid
        leaking closure state across agent runs.

        Builders that declare an ``adapter`` parameter receive the current
        repo adapter; others are called with no arguments. If a builder
        declares ``adapter`` but ``adapter=None``, the builder is skipped
        with a warning (it has no way to do its work without one).

        Args:
            adapter: Repo adapter instance (e.g. ``DDTraceJavaAdapter``).
                Passed to builders that declare an ``adapter`` parameter.

        Returns:
            Dict mapping SDK event name (e.g. ``"PreToolUse"``, ``"Stop"``)
            to a list of hook callables. Builders that fail to build are
            skipped with a warning.
        """
        builders = self._get_builders()
        hooks_by_event: Dict[str, List[Any]] = {}

        for entry in builders:
            try:
                if entry.wants_adapter:
                    if adapter is None:
                        logger.warning(
                            "Hook %s requires an adapter but none was provided; skipping. "
                            "Ensure repo_adapter is passed to spawn_agent() — "
                            "typically via ctx.repo_adapter in AgentStep or Step.fix_output().",
                            entry.builder.__name__,
                        )
                        continue
                    hook = entry.builder(adapter=adapter)
                else:
                    hook = entry.builder()
            except Exception as e:
                logger.warning("Failed to build hook from %s: %s", entry.builder.__name__, e)
                continue

            for event in entry.events:
                hooks_by_event.setdefault(event, []).append(hook)

        return hooks_by_event

    def _get_builders(self) -> List["_BuilderEntry"]:
        """Get cached list of builder entries (builder + metadata)."""
        if self._builders is not None:
            return self._builders

        builders: List[_BuilderEntry] = []
        for hooks_dir in self.hooks_dirs:
            if not hooks_dir.exists():
                continue

            for py_file in sorted(hooks_dir.glob("*.py")):
                if py_file.name.startswith("_"):
                    continue

                builders.extend(self._discover_builders(py_file))

        self._builders = builders
        return builders

    def _discover_builders(self, py_file: Path) -> List["_BuilderEntry"]:
        """Discover build_*_hook() functions in a Python module.

        Reads optional ``events`` metadata from the module level (or from
        the builder function itself, which takes precedence).

        Args:
            py_file: Path to Python file to inspect.

        Returns:
            List of builder entries found in the module.
        """
        entries: List[_BuilderEntry] = []
        try:
            spec = importlib.util.spec_from_file_location(py_file.stem, py_file)
            if spec is None or spec.loader is None:
                return entries

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            module_events = getattr(module, "events", None)

            for name in dir(module):
                if not (name.startswith("build_") and name.endswith("_hook")):
                    continue
                fn = getattr(module, name)
                if not callable(fn):
                    continue

                # Function-level `events` overrides module-level
                fn_events = getattr(fn, "events", None)
                events = list(fn_events or module_events or _DEFAULT_EVENTS)

                wants_adapter = "adapter" in inspect.signature(fn).parameters

                entries.append(
                    _BuilderEntry(builder=fn, events=events, wants_adapter=wants_adapter)
                )

        except Exception as e:
            logger.warning("Failed to load hook module %s: %s", py_file, e)

        return entries

    def clear_cache(self) -> None:
        """Clear the cached builders."""
        self._builders = None


class _BuilderEntry:
    """A discovered hook builder plus its metadata."""

    __slots__ = ("builder", "events", "wants_adapter")

    def __init__(self, builder: Callable, events: List[str], wants_adapter: bool):
        self.builder = builder
        self.events = events
        self.wants_adapter = wants_adapter
