"""Structured halt signal for the per-step halt-with-feedback mechanism.

A step that cannot proceed (plan contradicts code, file missing, ambiguous
instruction, etc.) raises ``HaltSignal(StructuredHalt(...))`` instead of
silently failing or returning a partial result. The workflow framework
catches the signal, persists the halt artifact to ``feedback.jsonl``, and
surfaces it to the engineer via ``WorkflowError``.

The halt's ``consumable_by`` field names which upstream step(s) should
re-run with the halt content injected as feedback. Today the workflow
halts and the engineer restarts manually; a future PR adds auto-recovery
via ``ResetToStep`` when ``--headless`` is set.
"""

from typing import Optional

from pydantic import BaseModel, Field


class StructuredHalt(BaseModel):
    """A structured failure declared by a step that cannot proceed.

    Designed for re-injection: an engineer (or a future auto-recovery
    layer) can read the artifact and rerun the consuming step with the
    halt content as guidance, without translation.
    """

    step: str = Field(
        ...,
        description="Which step is halting (e.g. 'implement', 'fixer', 'diagnose').",
    )
    reason: str = Field(
        ...,
        description=(
            "Machine-readable category. Pick the most specific that fits — "
            "e.g. 'file_not_found', 'plan_contradicts_code', 'ambiguous_instruction', "
            "'missing_context', 'dependency_missing', 'no_work_produced'."
        ),
    )
    detail: str = Field(
        ...,
        description=(
            "Concrete description of what blocked the step. Quote file paths, "
            "method names, and any specifics from the plan that don't match the code."
        ),
    )
    needs: str = Field(
        ...,
        description=(
            "What the consuming step needs to know to address this on rerun. "
            "Should be readable as planner-input — e.g. 'Planner should verify "
            "file paths against actual file structure before listing them in files_in_scope.'"
        ),
    )
    suggestion: Optional[str] = Field(
        default=None,
        description="Optional concrete recommendation for the rerun (e.g. 'Drop task 3, it duplicates task 1').",
    )
    consumable_by: list[str] = Field(
        default_factory=list,
        description=(
            "Step name(s) that should re-run with this halt as feedback. "
            "For implement halts this is usually ['plan']. For fixer halts it might "
            "be ['fixer'] (retry) or ['plan'] (escalate). Empty list means the halt "
            "is informational only — the engineer decides where to rerun."
        ),
    )
    artifact_refs: list[str] = Field(
        default_factory=list,
        description=(
            "Optional paths or ctx keys that hold supporting context "
            "(a failing test, a diff, an error log) the consuming step should read."
        ),
    )


class HaltSignal(Exception):
    """Exception carrying a ``StructuredHalt``.

    Steps raise this when they cannot proceed. The workflow framework
    catches it in the step-execution loop, persists the halt, and
    converts to a user-facing ``WorkflowError`` (manual mode) or a
    ``ResetToStep`` to the consuming step (auto mode, future).
    """

    def __init__(self, halt: StructuredHalt) -> None:
        self.halt = halt
        super().__init__(f"{halt.step} halted: {halt.reason} — {halt.detail}")
