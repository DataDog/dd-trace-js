"""Structured halt + feedback channel for workflow steps.

TODO: rename this module (e.g. ``anubis.core.halt``) — "feedback" conflicts
with the existing ``feedback`` workflow name in anubis_apm.
"""

from .halt import HaltSignal, StructuredHalt
from .store import FeedbackStore

__all__ = ["FeedbackStore", "HaltSignal", "StructuredHalt"]
