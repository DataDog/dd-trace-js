"""Append-only JSONL store for ``StructuredHalt`` artifacts.

One file per (namespace, workflow): ``.analysis/<ns>/<wf>/feedback.jsonl``.
Each line is a JSON object: halt fields + ``timestamp`` + ``run_id``.

The store is read on workflow rerun so steps named in prior halts'
``consumable_by`` can pick up the unaddressed feedback. ``dd-apm clean``
clears the store alongside the rest of workflow state.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from pydantic import ValidationError

from .halt import StructuredHalt

logger = logging.getLogger(__name__)


class FeedbackStore:
    """Append-only JSONL persistence for structured halts."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def append(self, halt: StructuredHalt, run_id: Optional[str] = None) -> None:
        """Append one halt entry. Creates the file (and parents) on first write."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        entry: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "run_id": run_id,
            **halt.model_dump(),
        }
        with self.path.open("a") as f:
            f.write(json.dumps(entry) + "\n")

    def read_all(self) -> list[dict[str, Any]]:
        """Return every entry as a raw dict. Skips malformed lines silently."""
        if not self.path.exists():
            return []
        entries: list[dict[str, Any]] = []
        for line in self.path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError as exc:
                logger.debug("Skipping malformed feedback.jsonl line: %s", exc)
                continue
        return entries

    def read_for_step(self, step_name: str) -> list[StructuredHalt]:
        """Return halts whose ``consumable_by`` includes ``step_name``.

        TODO: wire this into the workflow runner so that when a step is about
        to execute on a rerun, any halts that named it in ``consumable_by``
        are automatically injected into its prompt context (e.g. via a
        ``ctx.set("prior_halts", ...)`` variable that prompt templates can
        reference with ``{{prior_halts}}``).  The store already persists the
        right data; the missing piece is the runner calling this method and
        passing the result to the step's prompt-variable resolver before
        ``spawn_agent`` is invoked.
        """
        result: list[StructuredHalt] = []
        for entry in self.read_all():
            data = {k: v for k, v in entry.items() if k not in ("timestamp", "run_id")}
            try:
                halt = StructuredHalt(**data)
            except ValidationError as exc:
                logger.debug("Skipping undeserializable feedback entry: %s", exc)
                continue
            if step_name in halt.consumable_by:
                result.append(halt)
        return result
