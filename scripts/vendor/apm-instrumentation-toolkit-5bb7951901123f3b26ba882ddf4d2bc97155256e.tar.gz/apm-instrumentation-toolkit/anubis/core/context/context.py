"""Execution context for workflows and steps.

Context is a thin runtime wrapper that:
- Holds reference to WorkflowState (owns all persisted data)
- Provides convenience methods for emit/prompt
- Delegates data access to state
"""

import copy
import importlib
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Type

from pydantic import BaseModel

from ..state.git import GitState
from ..state.models import AgentRun

if TYPE_CHECKING:
    from ..agents import AgentMetrics
    from ..state.models import WorkflowState

# Repo adapter factory - set by application to provide repo-type adapters
_repo_adapter_factory: Optional[Callable[[str], Any]] = None


def set_repo_adapter_factory(factory: Callable[[str], Any]) -> None:
    """Set the repo adapter factory function."""
    global _repo_adapter_factory
    _repo_adapter_factory = factory


@dataclass
class Context:
    """Thin execution context - delegates to WorkflowState.

    WorkflowState owns:
    - data: Dict[str, Any]     - KV store (ctx.set/get)
    - artifacts: Dict[str, str] - artifact registry
    - steps: Dict[str, StepState] - step states/checkpoints
    - All path computation

    Context provides:
    - Convenience methods (emit, info, warn, error)
    - Current step/attempt tracking
    - Prompt loading
    - Adapter access
    """

    # Identity
    workflow: str
    namespace: str
    repository: str = "dd_trace_js"
    parent_workflow: Optional[str] = None  # For nested workflows

    # Current execution (set by runner)
    current_step: Optional[str] = None
    current_attempt: int = 1

    # Injected dependencies
    state: Optional["WorkflowState"] = None  # Owns data, artifacts, steps, paths
    emitter: Any = None  # Terminal output
    prompts: Any = None  # Prompt loading
    base_dir: Optional[Path] = None  # Base directory for paths

    # Config (read-only, set at workflow start)
    config: Dict[str, Any] = field(default_factory=dict)

    # Execution mode
    headless: bool = False  # If True, skip interactive prompts

    # For isolated contexts in batch execution
    _pending_metrics: List[Dict[str, Any]] = field(default_factory=list)
    _data: Dict[str, Any] = field(default_factory=dict)  # Local data storage when state is None

    # Type registry for automatic rehydration of Pydantic models on resume
    _type_registry: Dict[str, Type[BaseModel]] = field(default_factory=dict)

    # Parent context for nested workflows (enables inheritance of internal state)
    _parent_context: Optional["Context"] = None

    def __post_init__(self):
        if self.base_dir is None:
            self.base_dir = Path.cwd()

    def register_type(self, key: str, model_class: Type[BaseModel]) -> None:
        """Register a Pydantic model type for a data key.

        After registration, ctx.get(key) will automatically validate
        and rehydrate dicts into proper Pydantic model instances.

        Args:
            key: Data key (e.g., 'diagnosis_history')
            model_class: Pydantic model class to use for validation
        """
        self._type_registry[key] = model_class

    # =========================================================================
    # Data access - delegates to state.data
    # =========================================================================

    def get(self, key: str, default: Any = None) -> Any:
        """Get data from state or local storage.

        If the key is registered with a type, automatically rehydrates
        dicts to proper Pydantic model instances.

        For internal keys (starting with _), falls back to parent context
        if not found locally. This enables nested workflows to automatically
        inherit internal state from their parent.
        """
        if self.state:
            data = self.state.data.get(key)
        else:
            # Use local storage for isolated contexts (no state)
            data = self._data.get(key)

        # Fall back to parent context for internal keys (start with _)
        if data is None and key.startswith("_") and self._parent_context is not None:
            return self._parent_context.get(key, default)

        # Return default if still None
        if data is None:
            return default

        # Automatic rehydration if type is registered
        if key in self._type_registry:
            model_class = self._type_registry[key]
            if isinstance(data, list):
                return [
                    model_class.model_validate(item) if isinstance(item, dict) else item
                    for item in data
                ]
            elif isinstance(data, dict):
                return model_class.model_validate(data)
        return data

    def set(self, key: str, value: Any):
        """Set data in state or local storage.

        Automatically registers type for Pydantic models so they
        can be rehydrated properly on resume.
        """
        # Auto-register type for Pydantic models
        if isinstance(value, BaseModel):
            model_class = type(value)
            self._type_registry[key] = model_class
            self._persist_type_registry(key, model_class)
        elif isinstance(value, list) and value and isinstance(value[0], BaseModel):
            model_class = type(value[0])
            self._type_registry[key] = model_class
            self._persist_type_registry(key, model_class)

        if self.state:
            self.state.data[key] = value
        else:
            # Use local storage for isolated contexts (no state)
            self._data[key] = value

    def _persist_type_registry(self, key: str, model_class: Type[BaseModel]) -> None:
        """Persist type registry to state for resume."""
        if not self.state:
            return
        # Store as module.ClassName for lookup on resume
        type_name = f"{model_class.__module__}.{model_class.__name__}"
        registry = self.state.data.get("_type_registry", {})
        registry[key] = type_name
        self.state.data["_type_registry"] = registry

    def restore_type_registry(self) -> None:
        """Restore type registry from state on resume."""
        if not self.state:
            return
        registry = self.state.data.get("_type_registry", {})
        for key, type_name in registry.items():
            try:
                # Import and resolve the class
                module_name, class_name = type_name.rsplit(".", 1)
                module = importlib.import_module(module_name)
                model_class = getattr(module, class_name)
                self._type_registry[key] = model_class
            except (ImportError, AttributeError, ValueError):
                # If we can't resolve the type, skip it
                pass

    def get_config(self, key: str, default: Any = None) -> Any:
        """Get config value."""
        return self.config.get(key, default)

    # =========================================================================
    # Artifacts - saves file + registers in state.artifacts
    # =========================================================================

    def save_artifact(self, name: str, data: Any) -> Path:
        """Save artifact and register in state.

        If data is a Pydantic BaseModel, the type is registered so that
        load_artifact() can automatically rehydrate it.
        """
        if not self.state:
            raise RuntimeError("No state - cannot save artifact")

        # Determine path and extension
        ext = ".json" if isinstance(data, (dict, list, BaseModel)) else ".txt"
        path = self.state.artifact_path(f"{name}{ext}", self.base_dir)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Write file
        if isinstance(data, BaseModel):
            path.write_text(data.model_dump_json(indent=2))
            # Register type for automatic rehydration on load
            model_class = type(data)
            self._type_registry[f"artifact:{name}"] = model_class
            self._persist_type_registry(f"artifact:{name}", model_class)
        elif isinstance(data, (dict, list)):
            path.write_text(json.dumps(data, indent=2, default=str))
        else:
            path.write_text(str(data))

        # Register in state
        self.state.artifacts[name] = self.state.relative(path, self.base_dir)
        return path

    def save_artifact_file(self, source: Path, name: Optional[str] = None) -> Path:
        """Copy a file to artifacts directory and register it.

        Args:
            source: Path to source file
            name: Artifact name (defaults to filename without extension)

        Returns:
            Path to the artifact file
        """
        if not self.state:
            raise RuntimeError("No state - cannot save artifact")

        source = Path(source)
        if not source.exists():
            raise FileNotFoundError(f"Source file not found: {source}")

        # Use filename as artifact name if not provided
        artifact_name = name or source.stem

        # Preserve original extension
        dest = self.state.artifact_path(source.name, self.base_dir)
        dest.parent.mkdir(parents=True, exist_ok=True)

        # Skip copy if source and dest resolve to the same file (symlinks)
        if source.resolve() != dest.resolve():
            shutil.copy2(source, dest)

        # Register in state
        self.state.artifacts[artifact_name] = self.state.relative(dest, self.base_dir)
        return dest

    def get_artifact_path(self, name: str) -> Optional[Path]:
        """Get the path to a registered artifact file.

        Checks current context's artifact registry, then walks up parent contexts
        for nested workflows.

        Args:
            name: Artifact name

        Returns:
            Path to the artifact file if found and exists, None otherwise
        """
        # Check current state
        if self.state and self.base_dir and name in self.state.artifacts:
            path = self.base_dir / self.state.artifacts[name]
            if path.exists():
                return path

        # Check parent context (for nested workflows)
        if self._parent_context:
            return self._parent_context.get_artifact_path(name)

        return None

    def load_artifact(self, name: str, model_type: Optional[Type[BaseModel]] = None) -> Any:
        """Load artifact by name, optionally validating as a Pydantic model.

        First checks the artifact registry, then falls back to looking for
        files directly in the artifacts directory. This allows agents to
        save artifacts directly without going through ctx.save_artifact().

        If model_type is provided, validates and returns a Pydantic model instance.
        If not provided but the artifact was saved with save_artifact() using a
        BaseModel, the type is automatically retrieved from the registry.

        Args:
            name: Artifact name
            model_type: Optional Pydantic BaseModel class to validate against

        Returns:
            For JSON files: validated Pydantic model (if type available) or dict/list
            For other files: string content
        """
        if not self.state:
            raise KeyError(f"Artifact not found: {name}")

        # Ensure base_dir is set (should be set by __post_init__)
        assert self.base_dir is not None, "base_dir must be set"

        # Check registry first
        if name in self.state.artifacts:
            rel_path = self.state.artifacts[name]
            path = self.base_dir / rel_path
        else:
            # Fallback: look for file directly in artifacts directory
            artifacts_dir = self.state.artifacts_dir(self.base_dir)
            # Try common extensions
            for ext in [".json", ".txt", ""]:
                candidate = artifacts_dir / f"{name}{ext}"
                if candidate.exists():
                    path = candidate
                    # Register it for future lookups
                    self.state.artifacts[name] = self.state.relative(path, self.base_dir)
                    break
            else:
                raise KeyError(f"Artifact not found: {name}")

        if path.suffix == ".json":
            data = json.loads(path.read_text())

            # Determine the model type to use for validation
            effective_type = model_type or self._type_registry.get(f"artifact:{name}")

            if effective_type is not None:
                # Validate and rehydrate as Pydantic model
                return effective_type.model_validate(data)

            return data
        return path.read_text()

    # =========================================================================
    # Paths - delegates to state
    # =========================================================================

    def step_logs(self) -> Path:
        """Get logs directory for current step."""
        if not self.state:
            raise RuntimeError("No state - cannot get paths")
        if not self.current_step:
            raise RuntimeError("No current step set - cannot get paths")
        return self.state.step_logs(self.current_step, self.current_attempt, self.base_dir)

    def step_dir(self) -> Path:
        """Get directory for current step."""
        if not self.state:
            raise RuntimeError("No state - cannot get paths")
        if not self.current_step:
            raise RuntimeError("No current step set - cannot get paths")
        return self.state.step_dir(self.current_step, self.current_attempt, self.base_dir)

    @property
    def artifacts_dir(self) -> Path:
        """Get artifacts directory. Works in isolated contexts (no state required)."""
        assert self.base_dir is not None, "base_dir must be set"
        return self.base_dir / ".analysis" / self.namespace / self.workflow / "artifacts"

    # =========================================================================
    # Logging (via emitter)
    # =========================================================================

    def emit(self, event: str, **kwargs):
        """Emit event to listener.

        For isolated contexts (parallel batch), relays to parent context.
        Suppresses events that create live displays (not supported in parallel).
        """
        if self.emitter:
            self.emitter.emit(event, **kwargs)
        else:
            # Check for relay (parallel batch execution)
            relay_ctx = self._data.get("_batch_relay_ctx")
            item_id = self._data.get("_batch_relay_item_id")
            if relay_ctx and item_id:
                # Suppress events that conflict with batch display:
                # - agent_start/complete: create Rich Live displays
                # - info/success/section/warn: verbose logs clutter the batch table
                if event in ("agent_start", "agent_complete", "info", "success", "section", "warn"):
                    return
                # Route agent_output to batch display with item_id
                if event == "agent_output":
                    kwargs["batch_item_id"] = item_id
                elif event.startswith("batch_item"):
                    kwargs["batch_item_id"] = item_id
                relay_ctx.emit(event, **kwargs)

    def info(self, message: str):
        """Emit info message."""
        self.emit("info", message=message)

    def warn(self, message: str):
        """Emit warning message."""
        self.emit("warn", message=message)

    def error(self, message: str):
        """Emit error message."""
        self.emit("error", message=message)

    def success(self, message: str):
        """Emit success message."""
        self.emit("success", message=message)

    # =========================================================================
    # Prompts
    # =========================================================================

    def prompt(self, name: Optional[str] = None, **variables: Any) -> str:
        """Get composed prompt for current step."""
        if self.prompts:
            return str(self.prompts.compose(variables=variables, step_prompt=name))
        return ""

    # =========================================================================
    # Metrics - delegates to current step state
    # =========================================================================

    def add_agent_metrics(self, metrics: "AgentMetrics", task_description: str = "") -> None:
        """Add metrics from an agent run."""
        run = AgentRun(
            task=task_description,
            model=metrics.model or "",
            cost_usd=metrics.cost_usd,
            duration_seconds=metrics.duration_seconds,
            num_turns=metrics.num_turns,
            input_tokens=metrics.input_tokens,
            output_tokens=metrics.output_tokens,
            cache_read_input_tokens=metrics.cache_read_input_tokens,
            is_error=metrics.is_error,
        )

        if self.state and self.current_step:
            step_state = self.state.get_step(self.current_step)
            step_state.metrics.add_agent_run(run)
            self.state.update_totals()
        else:
            # Isolated context - store for later aggregation
            self._pending_metrics.append(run.model_dump())

    def get_total_cost(self) -> float:
        """Get total cost across all steps."""
        if not self.state:
            return 0.0
        return self.state.total_cost_usd

    def metric(self, name: str, value: Any) -> None:
        """Record a metric to state.

        Args:
            name: Metric name (e.g., 'test_iterations')
            value: Metric value
        """
        if self.state:
            self.state.data[name] = value

    def get_agent_runs(self) -> List[Dict[str, Any]]:
        """Get all agent runs from state metrics."""
        if not self.state:
            return []
        metrics = self.state.get_metrics()
        return list(metrics.get("agent_runs", []))

    def emit_cost_summary(self, show_breakdown: bool = False) -> None:
        """Emit cost summary event for terminal display.

        Args:
            show_breakdown: If True, emit breakdown by agent run
        """
        if not self.state:
            return

        runs = self.get_agent_runs()
        if not runs:
            return  # No agent runs to report

        self.state.update_totals()
        total_cost = self.state.total_cost_usd
        total_duration = self.state.total_duration_seconds
        total_turns = sum(r.get("num_turns", 0) for r in runs)

        self.emit(
            "cost_summary",
            total_cost=total_cost,
            total_duration=total_duration,
            total_turns=total_turns,
            agent_runs=runs,
            show_breakdown=show_breakdown,
        )

    # =========================================================================
    # Resources
    # =========================================================================

    @property
    def repo_adapter(self) -> Any:
        """Get repo adapter for current repo type (e.g., dd_trace_js).

        Raises:
            RuntimeError: If repo adapter factory not configured. Call setup.init() first.
        """
        if not _repo_adapter_factory:
            raise RuntimeError(
                "Repo adapter factory not configured. "
                "Call anubis_apm.setup.init() before running workflows."
            )
        return _repo_adapter_factory(self.repository)

    @property
    def console(self) -> Any:
        """Get Rich console if available."""
        if self.emitter and hasattr(self.emitter, "_terminal"):
            terminal = self.emitter._terminal
            if terminal and hasattr(terminal, "console"):
                return terminal.console
        return None

    @property
    def git(self) -> GitState:
        """Get GitState for workflow checkpointing and diffs.

        Cached in _data to avoid recreating on each access.
        """
        if "_git" not in self._data:
            base_branch = self.state.base_branch if self.state else None
            self._data["_git"] = GitState(
                workflow=self.workflow,
                namespace=self.namespace,
                repo_path=self.base_dir,
                base_branch=base_branch,
            )
        git_state: GitState = self._data["_git"]
        return git_state

    # =========================================================================
    # Isolation for batch execution
    # =========================================================================

    def copy_isolated(self) -> "Context":
        """Create isolated copy for parallel batch execution.

        Sets emitter=None so that emit() uses the relay logic to route
        events to the parent context with batch_item_id attached.

        Snapshots the parent's non-internal data (e.g. workflow setup variables
        like ``language``, ``integration_name``) into the isolated context's
        local ``_data`` so batch items can resolve them via ``ctx.get`` / prompt
        fallback.  Writes in the isolated copy go to ``_data`` only and never
        race with the parent.
        """
        isolated = Context(
            workflow=self.workflow,
            namespace=self.namespace,
            repository=self.repository,
            parent_workflow=self.parent_workflow,
            current_step=self.current_step,
            current_attempt=self.current_attempt,
            state=None,  # No state in isolated context
            emitter=None,  # None triggers relay to _batch_relay_ctx in emit()
            prompts=self.prompts,
            base_dir=self.base_dir,
            config=dict(self.config),
            headless=self.headless,
        )
        # Deep-copy public (non-internal) workflow variables so isolated contexts
        # can read values set during workflow setup (e.g. language, integration_name).
        # Deep copy prevents mutable values (dicts, lists) from being shared by
        # reference between parallel items, preserving isolation guarantees.
        parent_data = self.state.data if self.state else self._data
        isolated._data.update({
            k: copy.deepcopy(v) for k, v in parent_data.items() if not k.startswith("_")
        })
        return isolated
