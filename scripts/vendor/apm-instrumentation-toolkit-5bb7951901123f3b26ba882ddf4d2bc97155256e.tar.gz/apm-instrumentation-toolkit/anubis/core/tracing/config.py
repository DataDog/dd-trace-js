"""Tracing configuration and initialization.

Handles Datadog APM and LLMObs initialization and shutdown.
"""

import atexit
import logging
import os
import signal
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

import httpx

from anubis.core.tracing.dd_auth import has_dd_api_key_in_env

# init_env() in anubis_apm/cli/env.py must be called before this module is
# imported. It sets all DD_* vars from config.yaml so ddtrace initializes
# against the correct agent URL and credentials.
_service_name = os.environ.get("DD_SERVICE", "apm-ai-integration-toolkit")

# Import ddtrace — it reads DD_* env vars set by init_env()
from ddtrace.llmobs import LLMObs  # noqa: E402
from ddtrace.trace import tracer  # noqa: E402

logger = logging.getLogger(__name__)

# Track whether shutdown has been called to avoid double-shutdown
_shutdown_called: bool = False

# LLMObs enabled flag - set by init_llmobs
_llmobs_enabled: bool = False

_ML_APP = "apm-ai-integration-toolkit"


def _get_project_name() -> str:
    """Return the LLMObs project/ml_app name based on environment."""
    is_ci = os.environ.get("CI") or os.environ.get("BUILDKITE")
    return _ML_APP if is_ci else f"{_ML_APP}-dev"


def _get_branch() -> str:
    """Return 'ci' in any CI environment, 'local' otherwise.

    Experiment names use this as a stable scope — actual branch names are
    noisy, change per PR, and contain slashes that break naming conventions.
    """
    if os.environ.get("CI") or os.environ.get("BUILDKITE") or os.environ.get("GITLAB_CI"):
        return "ci"
    return "local"


def llmobs_ready() -> bool:
    """Return True if DD_API_KEY and DD_APP_KEY are both set."""
    missing = [k for k in ("DD_API_KEY", "DD_APP_KEY") if not os.environ.get(k)]
    if missing:
        logger.warning("LLMObs submission skipped — not set: %s", ", ".join(missing))
        return False
    return True


def _enable_llmobs_experiments(project_name: str) -> bool:
    """Initialize the LLMObs client for experiment submission."""
    api_key = os.environ.get("DD_API_KEY", "")
    app_key = os.environ.get("DD_APP_KEY", "")

    if not api_key or not app_key:
        missing = ", ".join(k for k in ("DD_API_KEY", "DD_APP_KEY") if not os.environ.get(k))
        logger.warning("LLMObs experiment submission skipped — not set: %s", missing)
        return False

    try:
        if not LLMObs.enabled:
            LLMObs.enable(ml_app=project_name, api_key=api_key, app_key=app_key)

        instance = LLMObs._instance
        if instance and hasattr(instance, "_dne_client"):
            client = instance._dne_client
            if app_key:
                client._app_key = app_key
            if api_key:
                client._api_key = api_key
            client._default_project = {"name": project_name, "_id": ""}
    except Exception as e:
        logger.error("Failed to configure LLMObs experiments client: %s", e)
        return False

    return True


def set_service_name(name: str) -> None:
    """Set the service name for traces."""
    global _service_name
    _service_name = name


def get_service_name() -> str:
    """Get the current service name."""
    return _service_name


def is_llmobs_enabled() -> bool:
    """Check if LLMObs is enabled."""
    return _llmobs_enabled


_TRACER_LOG_FILE = Path.home() / ".dd-apm" / "tracer.log"

# Tracks per-workflow tracer log handlers so attach/detach pair up cleanly across
# sequential workflow runs in the same process (CI batches, dd-apm matrix evals).
_WORKFLOW_TRACER_HANDLERS: dict[str, logging.Handler] = {}


def get_tracer_log_file() -> Path:
    """Return the always-on global tracer log file path. Stable for users to tail."""
    return _TRACER_LOG_FILE


def get_workflow_tracer_log_file(workflow_log_dir: Path) -> Path:
    """Return the per-workflow tracer log path under the analysis dir."""
    return workflow_log_dir / "tracer.log"


def attach_workflow_tracer_log(workflow_log_dir: Path) -> Optional[Path]:
    """Add an additional FileHandler that captures tracer DEBUG to the
    workflow's analysis dir, alongside the always-on global ~/.dd-apm/tracer.log.

    Idempotent per workflow_log_dir (re-runs/resumes don't double-attach).
    Returns the path on success, None if attachment failed.
    """
    log_file = get_workflow_tracer_log_file(workflow_log_dir)
    key = str(log_file.resolve()) if workflow_log_dir.exists() else str(log_file)
    if key in _WORKFLOW_TRACER_HANDLERS:
        return log_file
    try:
        workflow_log_dir.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(log_file)
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        logging.getLogger("ddtrace").addHandler(handler)
        _WORKFLOW_TRACER_HANDLERS[key] = handler
        return log_file
    except Exception as e:
        logger.warning("Could not attach workflow tracer log at %s: %s", log_file, e)
        return None


def detach_workflow_tracer_log(workflow_log_dir: Path) -> None:
    """Detach the per-workflow tracer log handler. Call at workflow end so the
    handler doesn't leak into subsequent workflows in the same process.
    """
    log_file = get_workflow_tracer_log_file(workflow_log_dir)
    key = str(log_file.resolve()) if log_file.exists() else str(log_file)
    handler = _WORKFLOW_TRACER_HANDLERS.pop(key, None)
    if handler is None:
        return
    try:
        logging.getLogger("ddtrace").removeHandler(handler)
        handler.close()
    except Exception as e:
        logger.debug("Failed to detach workflow tracer log handler: %s", e)


def _setup_tracer_log_file() -> None:
    """Quiet the ddtrace console handler, stop log propagation, and enable file DEBUG.

    DD_TRACE_LOG_FILE is set in init_env() before ddtrace initializes, so
    ddtrace's native RotatingFileHandler is already attached by the time this runs.
    DD_TRACE_LOG_LEVEL is intentionally NOT set pre-import (setting it would make
    ddtrace start at DEBUG level, causing startup noise on stderr).  This function:

      - Sets propagate=False so records don't double-emit via the root logger.
      - Bumps ddtrace's pre-installed StreamHandler to WARNING (console quiet).
      - Sets the logger level to DEBUG so file handlers capture full detail.

    DD_TRACE_DEBUG=true users keep DEBUG on stderr as expected.
    """
    try:
        ddtrace_logger = logging.getLogger("ddtrace")
        ddtrace_logger.propagate = False

        debug_requested = os.environ.get("DD_TRACE_DEBUG", "").lower() in ("1", "true", "yes")
        if not debug_requested:
            for h in ddtrace_logger.handlers:
                if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler):
                    if h.level < logging.WARNING:
                        h.setLevel(logging.WARNING)

        # Set logger to DEBUG after bumping StreamHandler — file handlers capture full detail,
        # console stays quiet (StreamHandler is now at WARNING).
        ddtrace_logger.setLevel(logging.DEBUG)
    except Exception as e:
        logger.warning("Could not configure tracer console handler: %s", e)


def init_tracing() -> None:
    """Initialize Datadog tracing and LLM Observability.

    Configuration is loaded from the environment, which must be bootstrapped
    by init_env() before this function is called.
    """
    global _llmobs_enabled
    if os.environ.get("DD_TRACE_ENABLED", "").lower() in ("0", "false"):
        # Tracing explicitly disabled (DD_TRACE_ENABLED=false). Mark as
        # initialized so traced_workflow doesn't raise — LLMObs calls
        # become no-ops via ddtrace's own disabled path.
        _llmobs_enabled = True
        return

    tracer.configure()

    # Quiet the ddtrace StreamHandler so console only gets WARNING+, and set the logger
    # to DEBUG so file handlers (DD_TRACE_LOG_FILE RotatingFileHandler + per-workflow
    # handlers) capture full detail.  DD_TRACE_LOG_LEVEL is NOT pre-set in the env to
    # avoid ddtrace starting at DEBUG and flooding stderr with startup messages.
    _setup_tracer_log_file()

    # The CLI module silences ddtrace.internal.writer.writer to CRITICAL so management
    # commands (config, status, sync) don't spray "dropping N traces" errors when the
    # agent isn't running.  Once init_tracing() runs, the agent has been confirmed
    # (or will be confirmed via preflight), so writer failures here are real problems
    # that should surface.  Reset to WARNING so flush errors are visible.
    _writer_logger = logging.getLogger("ddtrace.internal.writer.writer")
    if _writer_logger.level >= logging.CRITICAL:
        _writer_logger.setLevel(logging.WARNING)

    # Surface the resolved tracer URL at INFO so misroutes are visible in logs
    # without needing DD_TRACE_DEBUG. If the URL can't be introspected (ddtrace
    # internals shifted), log a warning rather than crashing — the preflight
    # check will hard-fail later.
    try:
        logger.info("Tracer configured for agent: %s", get_resolved_agent_url())
    except TracingPreflightError as e:
        logger.warning("Could not verify tracer agent URL at init: %s", e)

    init_llmobs(ml_app=_service_name)

    from .running_spans import register_span_processor  # noqa: PLC0415

    register_span_processor()


def init_llmobs(
    ml_app: Optional[str] = None,
) -> None:
    """Initialize Datadog LLM Observability.

    LLMObs is a constitutive requirement of the toolkit — all workflows emit
    LLMObs spans for observability. Raises RuntimeError if it cannot be enabled.

    Args:
        ml_app: Name of the ML application (defaults to service name)
    """
    global _llmobs_enabled

    agentless = os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "true").lower() not in ("0", "false")
    LLMObs.enable(
        ml_app=ml_app or _service_name,
        agentless_enabled=agentless,
    )
    _llmobs_enabled = True
    mode = "agentless" if agentless else "agent-proxy"
    logger.info("LLMObs enabled for app: %s (mode: %s)", ml_app or _service_name, mode)


class TracingPreflightError(Exception):
    """Raised when tracing preflight checks fail."""

    pass


def get_resolved_agent_url() -> str:
    """Return the tracer's actual configured agent URL.

    This is the source of truth — what the writer is *actually* going to send
    to. Reading os.environ['DD_TRACE_AGENT_URL'] is unreliable: if ddtrace was
    imported (even transitively) before init_env() force-overrode the env, the
    tracer is locked onto whatever URL it captured at import time, regardless
    of what the env var says now.

    Raises TracingPreflightError if the URL can't be introspected. We never
    silently fall back to env-var guessing — that's the silent-misroute bug
    this function exists to catch.
    """
    try:
        aggregator = getattr(tracer, "_span_aggregator", None)
        writer = getattr(aggregator, "writer", None) if aggregator else None
        for attr in ("intake_url", "agent_url", "_agent_endpoint"):
            value = getattr(writer, attr, None)
            if isinstance(value, str) and value.startswith("http"):
                return value
    except Exception as e:
        raise TracingPreflightError(
            f"Could not introspect ddtrace tracer for the resolved agent URL: {e}. "
            "ddtrace internals likely changed — update get_resolved_agent_url() in "
            "anubis/core/tracing/config.py to use the new writer attribute path."
        ) from e
    raise TracingPreflightError(
        "Could not determine the tracer's resolved agent URL: none of "
        "(intake_url, agent_url, _agent_endpoint) was a valid URL on the writer. "
        "ddtrace internals may have shifted; update get_resolved_agent_url()."
    )


def _check_agent_reachable(url: str, timeout: float = 2.0) -> bool:
    """Check if an agent is reachable via HTTP."""
    try:
        response = httpx.get(url, timeout=timeout)
        return bool(response.status_code < 500)
    except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPError):
        return False


def check_tracing_requirements(raise_on_error: bool = True) -> bool:
    """Check that tracing infrastructure is properly configured.

    Verifies infrastructure only — call this before init_tracing() (e.g. in preflight).
    In-process state (LLMObs enabled, tracer initialized) is enforced by init_tracing()
    itself and by traced_workflow(), not here.

    Verifies:
    1. DD_API_KEY is set in the environment (provided by dd-auth or CI injection)
    2. Test agent is reachable on port 19127
    3. Datadog agent is reachable on port 18127
    4. Tracer is configured to write to port 18127 (toolkit Org 2 agent)

    Args:
        raise_on_error: If True, raise TracingPreflightError on failure.
                       If False, log warnings and return False.

    Returns:
        True if all checks pass, False otherwise.

    Raises:
        TracingPreflightError: If raise_on_error=True and checks fail.
    """
    errors = []

    # Agentless mode (the default) submits spans straight to the public intake — the
    # local Docker agents on 18127/19127 are never used, and the tracer writer points
    # at the intake rather than port 18127. Checks 2-4 are docker/agent-specific and
    # must be skipped in this mode, or they false-positive on every fresh install that
    # hasn't run `docker compose up`. Mirrors the same agentless guard in
    # anubis_apm/cli/preflight.py::_preflight_local_agents and prereqs._check_trace_routing.
    #
    # Prefer _DD_APM_TRACING_AGENTLESS_ENABLED (set by init_env after all processing);
    # fall back to DD_LLMOBS_AGENTLESS_ENABLED for callers that skip init_env.
    agentless = os.environ.get("_DD_APM_TRACING_AGENTLESS_ENABLED", "").lower() == "true" or (
        "_DD_APM_TRACING_AGENTLESS_ENABLED" not in os.environ
        and os.environ.get("DD_LLMOBS_AGENTLESS_ENABLED", "true").lower() not in ("0", "false")
    )

    # Check 1: DD_API_KEY must be in the environment (provided by dd-auth or CI injection).
    # Required in both modes — agentless authenticates to the public intake with it.
    if not has_dd_api_key_in_env():
        errors.append("DD_API_KEY not found. Install dd-auth: brew install datadog/tap/dd-auth")

    if not agentless:
        # Check 2: Test agent reachable on port 19127
        test_agent_url = "http://localhost:19127/info"
        if not _check_agent_reachable(test_agent_url):
            errors.append(
                "Test agent not reachable on port 19127. Start it with: docker compose up -d"
            )

        # Check 3: Datadog agent reachable on port 18127
        datadog_agent_url = "http://localhost:18127/info"
        if not _check_agent_reachable(datadog_agent_url):
            errors.append(
                "Datadog agent not reachable on port 18127. Start it with: docker compose up -d"
            )

        # Check 4: tracer must actually be writing to the toolkit's Org 2 agent (port 18127).
        # Read the live tracer's resolved URL — not os.environ — because if ddtrace was
        # imported before init_env ran, the writer is locked onto a stale value regardless
        # of what the env var says now.
        try:
            agent_url = get_resolved_agent_url()
            parsed = urlparse(agent_url)
            if parsed.port != 18127:
                errors.append(
                    f"Tracer is writing to {agent_url} — expected port 18127 (toolkit Org 2 agent).\n"
                    "    Likely cause: ddtrace was imported before init_env() ran, or you're invoking\n"
                    "    a stale dd-apm binary that doesn't force-override DD_TRACE_AGENT_URL.\n"
                    "    Fix: ensure `which dd-apm` resolves to a checkout on `main` (or newer) and\n"
                    "    that no inherited DD_TRACE_AGENT_URL/DD_TRACE_AGENT_PORT/DD_AGENT_HOST shell\n"
                    "    var is bypassing the override."
                )
        except TracingPreflightError as e:
            errors.append(str(e))

    if errors:
        error_msg = "Tracing preflight checks failed:\n" + "\n".join(f"  - {e}" for e in errors)
        if raise_on_error:
            raise TracingPreflightError(error_msg)
        else:
            logger.warning(error_msg)
            return False

    logger.info("Tracing preflight checks passed")
    return True


def _finish_open_spans() -> None:
    """Finish all unfinished spans in the tracer's internal storage."""
    aggregator = getattr(tracer, "_span_aggregator", None)
    traces = getattr(aggregator, "_traces", None)
    if traces is None:
        return
    for _, trace_obj in list(traces.items()):
        for span in reversed(getattr(trace_obj, "spans", [])):
            if not span.finished:
                try:
                    span.finish()
                except Exception as e:
                    logger.debug("Failed to finish span during shutdown: %s", e)


def shutdown_tracing(timeout: float = 15.0) -> None:
    """Shutdown tracing and flush all pending spans.

    This should be called before process exit to ensure all traces are sent.
    Safe to call multiple times - will only execute once.

    Suppresses KeyboardInterrupt during flush so a second Ctrl+C doesn't
    kill the process before traces are sent.

    Args:
        timeout: Maximum time to wait for flush in seconds (default: 15.0)
    """
    global _shutdown_called

    if _shutdown_called:
        return

    _shutdown_called = True

    if os.environ.get("DD_TRACE_ENABLED", "").lower() in ("0", "false"):
        return

    # Suppress SIGINT during flush — a second Ctrl+C would raise
    # KeyboardInterrupt inside tracer.flush()/shutdown() and lose traces.
    prev_handler = signal.getsignal(signal.SIGINT)
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    try:
        from .running_spans import shutdown_running_spans  # noqa: PLC0415

        shutdown_running_spans()
        _finish_open_spans()
        tracer.flush()

        if _llmobs_enabled and LLMObs.enabled:
            try:
                LLMObs.flush()
            except Exception as e:
                logger.debug("Failed to flush LLMObs during shutdown: %s", e)

        tracer.shutdown(timeout=timeout)
    except Exception as e:
        logger.debug("Error during tracer shutdown: %s", e)
    finally:
        signal.signal(signal.SIGINT, prev_handler)


# Register shutdown handler for normal exit
atexit.register(shutdown_tracing)
