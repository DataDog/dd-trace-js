"""Long-running span support via periodic partial flushes.

Adapted from dd-trace-py's Ray integration (ddtrace/contrib/internal/ray/span_manager.py)
which uses the same _dd.partial_version / _dd.was_long_running protocol.

A partial span carries ``_dd.partial_version`` (a timestamp). When the real
span finishes, ``_dd.partial_version`` is removed and ``_dd.was_long_running``
is set to 1 — the backend uses these to stitch the partials together.

IMPORTANT: This module must NOT import ddtrace at the top level. It is
imported by config.py which runs before init_env() sets DD_* env vars.
Importing ddtrace early locks the tracer onto the wrong agent URL.

NOTE: ddtrace 4.10+ stores span tags/metrics in Rust-backed C storage.
The ``_meta`` / ``_metrics`` Python dicts no longer exist. All tag access
MUST go through the public API (``get_tags``, ``set_tag``, ``get_metric``,
``set_metric``), and these calls are only safe from the thread that owns
the span. We snapshot tags at watch-time (main thread) and use the
snapshot at flush-time (timer thread).
"""

import logging
import os
import threading
import time
from itertools import chain
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from ddtrace._trace.span import Span

logger = logging.getLogger(__name__)

PARTIAL_VERSION = "_dd.partial_version"
WAS_LONG_RUNNING = "_dd.was_long_running"

_DEFAULT_FLUSH_INTERVAL = 10


def _get_flush_interval() -> float:
    raw = os.environ.get("DD_APM_LONG_RUNNING_FLUSH_INTERVAL", "")
    if raw:
        try:
            return float(raw)
        except ValueError:
            logger.debug("Invalid DD_APM_LONG_RUNNING_FLUSH_INTERVAL=%r, using default", raw)
    return float(_DEFAULT_FLUSH_INTERVAL)


def _get_tracer() -> Any:
    from ddtrace.trace import tracer  # noqa: PLC0415

    return tracer


def _make_span(*, name: str, **kwargs: Any) -> "Span":
    from ddtrace._trace.span import Span  # noqa: PLC0415

    return Span(name=name, **kwargs)


def _get_llmobs_instance() -> Any:
    from ddtrace.llmobs import LLMObs  # noqa: PLC0415

    return getattr(LLMObs, "_instance", None)


# Integration spans (e.g. claude_agent_sdk) get _llmobs data at start
# (name, parent_id, trace_id, ml_app) but NOT the kind — that's set at
# finish by the integration's _llmobs_set_tags. Without a kind,
# _prepare_llmobs_span_data rejects the partial. We infer the kind from
# the span name so partials can appear in LLMObs before the span finishes.
_SPAN_NAME_TO_KIND: dict[str, str] = {
    "claude_agent_sdk.ClaudeSDKClient.query": "agent",
    "claude_agent_sdk.query": "agent",
    "claude_agent_sdk.step": "step",
    "claude_agent_sdk.llm": "llm",
    "claude_agent_sdk.tool": "tool",
}


def _infer_llmobs_kind(name: str) -> str:
    """Infer LLMObs span kind from span name."""
    kind = _SPAN_NAME_TO_KIND.get(name, "")
    if not kind:
        for prefix, k in _SPAN_NAME_TO_KIND.items():
            if name.startswith(prefix):
                return k
    return kind


def _ensure_llmobs_kind(span: "Span") -> None:
    """Inject a kind into the _llmobs struct if missing (integration spans)."""
    try:
        llmobs_data = span._get_struct_tag("_llmobs")
        if not llmobs_data:
            return
        meta = llmobs_data.get("meta", {})
        span_field = meta.get("span", {})
        if span_field.get("kind"):
            return
        kind = _infer_llmobs_kind(span.name)
        if not kind:
            return
        span_field["kind"] = kind
        meta["span"] = span_field
        llmobs_data["meta"] = meta
        span._set_struct_tag("_llmobs", llmobs_data)
    except Exception:
        logger.debug("Failed to ensure LLMObs kind for span %s", span.name)


class _WatchedSpan:
    """A watched span with a tag snapshot taken at watch-time (main thread).

    ddtrace 4.10+ stores span data in Rust-backed C storage that is not
    thread-safe for reads. We snapshot everything we need while still on
    the owning thread and use the snapshot from the timer thread.
    """

    __slots__ = ("span", "tags", "metrics", "meta_structs", "had_partial")

    def __init__(self, span: "Span") -> None:
        self.span = span
        self.had_partial: bool = False
        try:
            self.tags: dict[str, str] = span.get_tags()
        except Exception:
            self.tags = {}
        try:
            self.metrics: dict[str, Any] = span.get_metrics()
        except Exception:
            self.metrics = {}
        try:
            self.meta_structs: dict[str, Any] = span._get_meta_structs()
        except Exception:
            self.meta_structs = {}

    def refresh(self, span: "Span") -> None:
        """Re-snapshot tags from the span. Call from the owning thread."""
        try:
            self.tags = span.get_tags()
        except Exception:
            logger.debug("Failed to refresh tags for span %s", span.span_id)
        try:
            self.metrics = span.get_metrics()
        except Exception:
            logger.debug("Failed to refresh metrics for span %s", span.span_id)
        try:
            self.meta_structs = span._get_meta_structs()
        except Exception:
            logger.debug("Failed to refresh meta_structs for span %s", span.span_id)


class RunningSpanManager:
    def __init__(self) -> None:
        self._timer: Optional[threading.Timer] = None
        self._spans: dict[tuple[int, int], _WatchedSpan] = {}
        self._lock = threading.Lock()
        self._shutting_down: bool = False

    def watch(self, span: "Span") -> None:
        watched = _WatchedSpan(span)
        with self._lock:
            if not self._spans:
                self._arm_timer()
            self._spans[(span.trace_id, span.span_id)] = watched
            logger.debug(
                "Watching span %s (name=%s, tags=%d, metrics=%d), flush every %.0fs",
                span.span_id,
                span.name,
                len(watched.tags),
                len(watched.metrics),
                _get_flush_interval(),
            )

    def unwatch(self, span: "Span") -> None:
        key = (span.trace_id, span.span_id)
        watched: Optional[_WatchedSpan] = None
        with self._lock:
            watched = self._spans.pop(key, None)
            if not self._spans and self._timer:
                self._timer.cancel()
                self._timer = None

        had_partial = watched.had_partial if watched else False
        if watched:
            watched.refresh(span)
            logger.debug("Unwatching span %s (name=%s)", span.span_id, span.name)
        self._finish_span(span, had_partial)

    def shutdown(self) -> None:
        with self._lock:
            self._shutting_down = True
            if self._timer:
                self._timer.cancel()
                self._timer = None
            remaining = list(self._spans.values())
            self._spans.clear()

        if remaining:
            logger.debug("Shutting down RunningSpanManager, finishing %d span(s)", len(remaining))
        for watched in remaining:
            self._finish_span(watched.span, watched.had_partial)

    def _arm_timer(self) -> None:
        if self._shutting_down:
            return
        if self._timer:
            self._timer.cancel()
        interval = _get_flush_interval()
        timer = threading.Timer(interval, self._flush)
        timer.daemon = True
        self._timer = timer
        timer.start()

    def _flush(self) -> None:
        if self._shutting_down:
            return
        with self._lock:
            if not self._spans:
                return
            self._arm_timer()
            to_flush = list(self._spans.values())

        logger.debug("Flushing %d long-running span(s)", len(to_flush))
        for watched in to_flush:
            try:
                self._emit_partial(watched)
            except Exception:
                logger.warning(
                    "Failed to emit partial span %s",
                    watched.span.span_id,
                    exc_info=True,
                )

    def _emit_partial(self, watched: _WatchedSpan) -> None:
        span = watched.span
        partial_version = time.time_ns()
        with self._lock:
            key = (span.trace_id, span.span_id)
            if key not in self._spans or span.finished:
                return

        watched.had_partial = True

        partial = self._clone_span(watched)
        partial.set_metric(PARTIAL_VERSION, partial_version)
        partial.finish()

        if getattr(span, "span_type", None) == "llm":
            try:
                llmobs = _get_llmobs_instance()
                llmobs_data = partial._get_struct_tag("_llmobs") if llmobs else None
                if llmobs is not None and llmobs_data:
                    _ensure_llmobs_kind(partial)
                    llmobs._on_span_finish(partial)
            except Exception:
                logger.debug(
                    "Failed to emit LLMObs partial for span %s", span.span_id, exc_info=True
                )

        tracer = _get_tracer()
        aggregator = tracer._span_aggregator
        finished_children: list = []
        with aggregator._lock:
            if span.trace_id in aggregator._traces:
                trace = aggregator._traces[span.trace_id]
                remaining = []
                for s in trace.spans:
                    if s.finished and s.span_id != span.span_id:
                        finished_children.append(s)
                    else:
                        remaining.append(s)
                trace.spans[:] = remaining
                trace.num_finished -= len(finished_children)

        spans_to_write = [partial] + finished_children
        try:
            processed = spans_to_write
            for tp in chain(
                aggregator.dd_processors,
                aggregator.user_processors,
                [
                    aggregator.sampling_processor,
                    aggregator.tags_processor,
                    aggregator.service_name_processor,
                ],
            ):
                try:
                    processed = tp.process_trace(processed) or []
                    if not processed:
                        logger.warning("Partial spans dropped by processor %r", tp)
                        return
                except Exception:
                    logger.debug(
                        "Error in processor %r for trace %d", tp, span.trace_id, exc_info=True
                    )
                    raise
        except Exception:
            processed = spans_to_write

        writer = aggregator.writer
        logger.debug(
            "Writing %d span(s) via %s (children=%d, tags=%d)",
            len(processed),
            type(writer).__name__,
            len(finished_children),
            len(watched.tags),
        )
        writer.write(processed)

    def _clone_span(self, watched: _WatchedSpan) -> "Span":
        span = watched.span
        partial = _make_span(
            name=span.name,
            resource=getattr(span, "resource", None),
            service=getattr(span, "service", None),
            span_type=getattr(span, "span_type", None),
            trace_id=span.trace_id,
            span_id=span.span_id,
            parent_id=getattr(span, "parent_id", None),
            context=getattr(span, "context", None),
        )
        partial.start_ns = span.start_ns

        # Try live reads first (data may have been added after watch-time),
        # fall back to the watch-time snapshot on failure.
        try:
            tags = span.get_tags() or watched.tags
        except Exception:
            tags = watched.tags
            logger.debug("Live tag read failed for span %s, using snapshot", span.span_id)
        for tag_key, tag_val in tags.items():
            partial.set_tag(tag_key, tag_val)

        try:
            metrics = span.get_metrics() or watched.metrics
        except Exception:
            metrics = watched.metrics
            logger.debug("Live metric read failed for span %s, using snapshot", span.span_id)
        for metric_key, metric_val in metrics.items():
            partial.set_metric(metric_key, metric_val)

        partial.error = getattr(span, "error", 0)

        # Meta structs (e.g. _llmobs) are populated after span start, so the
        # watch-time snapshot is almost always empty. Read live from the span.
        try:
            meta_structs = span._get_meta_structs() or watched.meta_structs
        except Exception:
            meta_structs = watched.meta_structs
            logger.debug("Live meta_structs read failed for span %s, using snapshot", span.span_id)
        for key, value in meta_structs.items():
            partial._set_struct_tag(key, value)

        return partial

    def _finish_span(self, span: "Span", had_partial: bool) -> None:
        if had_partial:
            try:
                span.set_metric(WAS_LONG_RUNNING, 1)
            except Exception:
                logger.debug("Failed to set %s on span %s", WAS_LONG_RUNNING, span.span_id)
        if not span.finished:
            span.finish()


_manager: Optional[RunningSpanManager] = None
_manager_lock = threading.Lock()


def get_running_span_manager() -> RunningSpanManager:
    global _manager
    with _manager_lock:
        if _manager is None:
            _manager = RunningSpanManager()
    return _manager


def watch_span(span: "Span") -> None:
    get_running_span_manager().watch(span)


def unwatch_span(span: "Span") -> None:
    get_running_span_manager().unwatch(span)


def shutdown_running_spans() -> None:
    global _manager
    with _manager_lock:
        if _manager is not None:
            _manager.shutdown()
            _manager = None


class LongRunningSpanProcessor:
    """SpanProcessor that auto-watches ALL spans for partial flush.

    Registered globally via ``SpanProcessor.__processors__`` so it catches
    every span — including auto-instrumented ones from ddtrace integrations.
    Short-lived spans that finish before the first flush interval simply get
    unwatched with no partial emitted — the cost is negligible.
    """

    def on_span_start(self, span: "Span") -> None:
        watch_span(span)

    def on_span_finish(self, span: "Span") -> None:
        unwatch_span(span)

    def shutdown(self, timeout: Any = None) -> None:  # noqa: ARG002
        shutdown_running_spans()


_processor: Optional[LongRunningSpanProcessor] = None


def register_span_processor() -> None:
    """Register the long-running span processor globally.

    Call once after ``init_tracing()``. Idempotent.
    """
    global _processor
    if _processor is not None:
        return

    from ddtrace._trace.processor import SpanProcessor  # noqa: PLC0415

    _processor = LongRunningSpanProcessor()
    getattr(SpanProcessor, "__processors__").append(_processor)
    logger.debug("Registered LongRunningSpanProcessor")
