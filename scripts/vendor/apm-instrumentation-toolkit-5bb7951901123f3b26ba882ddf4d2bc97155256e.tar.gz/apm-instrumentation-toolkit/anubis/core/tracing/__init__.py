"""Datadog tracing and LLM Observability.

Provides:
- traced_workflow: Decorator for workflow run methods (LLMObs workflow span)
- traced_agent: Decorator for agent spawn functions (APM span)
- llmobs_task: Context manager for step spans (LLMObs task span)
- llmobs_agent: Context manager for agent steps (LLMObs agent span)
"""

from ddtrace import tracer
from ddtrace.llmobs import LLMObs

from .config import (
    TracingPreflightError,
    attach_workflow_tracer_log,
    check_tracing_requirements,
    detach_workflow_tracer_log,
    get_resolved_agent_url,
    get_service_name,
    get_tracer_log_file,
    get_workflow_tracer_log_file,
    init_llmobs,
    init_tracing,
    is_llmobs_enabled,
    set_service_name,
    shutdown_tracing,
)
from .context import (
    add_span_link,
    clear_last_step_context,
    export_span_context,
    get_current_span_context,
    get_last_step_context,
    set_current_span_context,
    set_last_step_context,
)
from .decorators import traced_agent, traced_workflow
from .llmobs import llmobs_agent, llmobs_annotate, llmobs_task
from .running_spans import register_span_processor, shutdown_running_spans, unwatch_span, watch_span
from .tags import (
    tag_agent_result,
    tag_agent_span,
    tag_batch_span,
    tag_error,
    tag_step_span,
    tag_workflow_cost,
)
from .utils import get_trace_env, serialize_for_llmobs

__all__ = [
    # Core objects
    "tracer",
    "LLMObs",
    # Configuration
    "init_tracing",
    "shutdown_tracing",
    "init_llmobs",
    "set_service_name",
    "get_service_name",
    "is_llmobs_enabled",
    "check_tracing_requirements",
    "get_resolved_agent_url",
    "get_tracer_log_file",
    "get_workflow_tracer_log_file",
    "attach_workflow_tracer_log",
    "detach_workflow_tracer_log",
    "TracingPreflightError",
    # Decorators
    "traced_workflow",
    "traced_agent",
    # LLMObs context managers
    "llmobs_task",
    "llmobs_agent",
    "llmobs_annotate",
    # Span linking
    "get_current_span_context",
    "set_current_span_context",
    "get_last_step_context",
    "set_last_step_context",
    "clear_last_step_context",
    "add_span_link",
    "export_span_context",
    # Span tagging
    "tag_step_span",
    "tag_batch_span",
    "tag_agent_span",
    "tag_agent_result",
    "tag_error",
    "tag_workflow_cost",
    # Running spans
    "watch_span",
    "unwatch_span",
    "shutdown_running_spans",
    "register_span_processor",
    # Utilities
    "get_trace_env",
    "serialize_for_llmobs",
]
