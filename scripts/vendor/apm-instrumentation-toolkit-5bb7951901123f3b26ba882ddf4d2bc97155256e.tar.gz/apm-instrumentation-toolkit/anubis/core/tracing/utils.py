"""Tracing utility functions.

Provides helper functions for trace context propagation.
"""

from typing import Any

from ddtrace import tracer

from .config import get_service_name


def serialize_for_llmobs(data: Any, max_length: int = 10000) -> Any:
    """Serialize data for LLMObs annotation.

    Converts Pydantic models to dicts, other objects to truncated strings.
    """
    if data is None:
        return None
    if hasattr(data, "model_dump"):
        return data.model_dump()
    return str(data)[:max_length]


def get_trace_env() -> dict:
    """Get environment variables for propagating trace context to subprocesses."""
    trace_env = {}

    span = tracer.current_span()
    if span:
        ctx = span.context
        if ctx:
            trace_env["DD_TRACE_ID"] = str(ctx.trace_id)
            trace_env["DD_SPAN_ID"] = str(ctx.span_id)
            if ctx.sampling_priority is not None:
                trace_env["DD_TRACE_SAMPLING_PRIORITY"] = str(ctx.sampling_priority)
            trace_env["X_DATADOG_TRACE_ID"] = str(ctx.trace_id)
            trace_env["X_DATADOG_PARENT_ID"] = str(ctx.span_id)
            if ctx.sampling_priority is not None:
                trace_env["X_DATADOG_SAMPLING_PRIORITY"] = str(ctx.sampling_priority)

    trace_env["DD_SERVICE"] = get_service_name()
    return trace_env
