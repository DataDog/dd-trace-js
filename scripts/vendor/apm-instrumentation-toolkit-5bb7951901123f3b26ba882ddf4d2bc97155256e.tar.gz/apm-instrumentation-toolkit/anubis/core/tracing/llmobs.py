"""LLMObs context managers for step and agent spans.

Provides context managers for LLMObs instrumentation:
- llmobs_task(): Task/step span with linking
- llmobs_agent(): Agent span with linking
- llmobs_annotate(): Annotate current span
"""

import logging
from contextlib import contextmanager
from typing import Any, Generator, Optional

from ddtrace.llmobs import LLMObs

from .config import is_llmobs_enabled
from .context import (
    add_span_link,
    export_span_context,
    get_current_span_context,
    get_last_step_context,
    set_last_step_context,
)
from .tags import tag_error

logger = logging.getLogger(__name__)

SUCCESS_TAGS = {"task": "step.success", "agent": "agent.success"}


def _link_to_previous(span: Any) -> None:
    """Link span to previous step (sequential) or parent workflow (first child)."""
    link_target = get_last_step_context() or get_current_span_context()
    if link_target:
        add_span_link(span, link_target["span_id"], link_target["trace_id"], "output", "input")


def _update_last_step(span_ctx: Optional[dict]) -> None:
    """Set this span as last_step so next sibling links to it."""
    if span_ctx:
        set_last_step_context(span_ctx["span_id"], span_ctx["trace_id"])


@contextmanager
def llmobs_task(
    name: str,
    session_id: Optional[str] = None,
    input_data: Optional[Any] = None,
) -> Generator[Any, None, None]:
    """Context manager for LLMObs task spans.

    Creates a task span, links to parent workflow or previous step.
    Automatically tags errors on exception.
    """
    if not is_llmobs_enabled():
        yield None
        return

    span = None
    span_ctx = None
    try:
        span = LLMObs.task(name=name, session_id=session_id).__enter__()
        span_ctx = export_span_context(span)
        _link_to_previous(span)

        if input_data is not None:
            LLMObs.annotate(input_data=input_data)
    except Exception as e:
        logger.debug(f"Failed to create LLMObs task span: {e}")
        yield None
        return

    try:
        yield span
    except Exception as e:
        tag_error(span, e, success_tag=SUCCESS_TAGS["task"])
        raise
    finally:
        _update_last_step(span_ctx)
        try:
            span.__exit__(None, None, None)
        except Exception as e:
            logger.debug(f"Failed to close LLMObs task span: {e}")


@contextmanager
def llmobs_agent(
    name: str,
    session_id: Optional[str] = None,
    input_data: Optional[Any] = None,
) -> Generator[Any, None, None]:
    """Context manager for LLMObs agent spans.

    Creates an agent span, links to parent. Agent spans are leaf nodes.
    Automatically tags errors on exception.
    """
    if not is_llmobs_enabled():
        yield None
        return

    span = None
    span_ctx = None
    try:
        span = LLMObs.agent(name=name, session_id=session_id).__enter__()
        span_ctx = export_span_context(span)
        _link_to_previous(span)

        if input_data is not None:
            LLMObs.annotate(input_data=input_data)
    except Exception as e:
        logger.debug(f"Failed to create LLMObs agent span: {e}")
        yield None
        return

    try:
        yield span
    except Exception as e:
        tag_error(span, e, success_tag=SUCCESS_TAGS["agent"])
        raise
    finally:
        _update_last_step(span_ctx)
        try:
            span.__exit__(None, None, None)
        except Exception as e:
            logger.debug(f"Failed to close LLMObs agent span: {e}")


def llmobs_annotate(
    input_data: Optional[Any] = None,
    output_data: Optional[Any] = None,
    metadata: Optional[dict] = None,
    tags: Optional[dict] = None,
    metrics: Optional[dict] = None,
) -> None:
    """Annotate the current LLMObs span with data. No-op if disabled."""
    if not is_llmobs_enabled():
        return

    try:
        LLMObs.annotate(
            input_data=input_data,
            output_data=output_data,
            metadata=metadata,
            tags=tags,
            metrics=metrics,
        )
    except Exception as e:
        logger.debug(f"Failed to annotate LLMObs span: {e}")
