"""Span linking context management.

Provides context variables for sequential span linking:
- _current_llmobs_span_context: Track current workflow (for parent-child linking)
- _last_step_span_context: Track last completed step (for sequential linking)

Linking Logic:
- First step in workflow: links to parent workflow (child relationship)
- Subsequent steps: links to previous step/workflow (sequential flow)
- Workflows update "last step" on exit so siblings link to them
"""

import contextvars
import logging
from typing import Any, Dict, Optional, TypedDict

from ddtrace.internal.utils.formats import format_trace_id
from ddtrace.llmobs._utils import add_span_link as _ddtrace_add_span_link
from ddtrace.llmobs._utils import get_llmobs_trace_id as _get_llmobs_trace_id

from .config import is_llmobs_enabled

logger = logging.getLogger(__name__)


class SpanLink(TypedDict):
    """Span link structure for LLMObs."""

    span_id: str
    trace_id: str
    attributes: Dict[str, str]


# Context var to track the current workflow span for parent-child linking
_current_llmobs_span_context: contextvars.ContextVar[Optional[Dict[str, str]]] = (
    contextvars.ContextVar("_current_llmobs_span_context", default=None)
)

# Context var to track the last completed step/workflow for sequential linking
# This enables: first step -> link to workflow, subsequent steps -> link to previous step
_last_step_span_context: contextvars.ContextVar[Optional[Dict[str, str]]] = contextvars.ContextVar(
    "_last_step_span_context", default=None
)


def get_current_span_context() -> Optional[Dict[str, str]]:
    """Get the current workflow span context for parent-child linking.

    Returns:
        Dict with span_id and trace_id, or None if no context is set.
    """
    return _current_llmobs_span_context.get()


def set_current_span_context(span_id: str, trace_id: str) -> contextvars.Token:
    """Set the current workflow span context for child spans to link to.

    Args:
        span_id: The span ID to link to
        trace_id: The trace ID to link to

    Returns:
        Token to reset the context later
    """
    return _current_llmobs_span_context.set({"span_id": span_id, "trace_id": trace_id})


def get_last_step_context() -> Optional[Dict[str, str]]:
    """Get the last completed step/workflow context for sequential linking.

    Returns:
        Dict with span_id and trace_id, or None if no previous step.
    """
    return _last_step_span_context.get()


def set_last_step_context(span_id: str, trace_id: str) -> contextvars.Token:
    """Set the last completed step context for sequential linking.

    Args:
        span_id: The span ID of the completed step
        trace_id: The trace ID of the completed step

    Returns:
        Token to reset the context later
    """
    return _last_step_span_context.set({"span_id": span_id, "trace_id": trace_id})


def clear_last_step_context() -> contextvars.Token:
    """Clear the last step context (for entering a new workflow scope).

    Returns:
        Token to reset the context later
    """
    return _last_step_span_context.set(None)


def add_span_link(
    span: Any, span_id: str, trace_id: str, from_io: str = "output", to_io: str = "input"
) -> None:
    """Add a span link to an LLMObs span.

    This creates a link from the current span to another span, enabling
    navigation in Datadog LLM Observability.

    Args:
        span: The span to add the link to
        span_id: Target span ID to link to
        trace_id: Target trace ID to link to
        from_io: Source end of the link ("input" or "output")
        to_io: Target end of the link ("input" or "output")
    """
    if not is_llmobs_enabled():
        return

    try:
        _ddtrace_add_span_link(
            span, span_id=span_id, trace_id=trace_id, from_io=from_io, to_io=to_io
        )
    except Exception as e:
        logger.debug("Failed to add span link: %s", e)


def export_span_context(span: Any) -> Optional[Dict[str, str]]:
    """Export span context for linking purposes.

    Args:
        span: The LLMObs span to export

    Returns:
        Dict with span_id and trace_id (LLMObs trace_id, not APM trace_id)
    """
    try:
        llmobs_trace_id = _get_llmobs_trace_id(span)
        trace_id = str(llmobs_trace_id) if llmobs_trace_id else format_trace_id(span.trace_id)
        return {
            "span_id": str(span.span_id),
            "trace_id": trace_id,
        }
    except Exception as e:
        logger.debug("Failed to export span context: %s", e)
        return None
