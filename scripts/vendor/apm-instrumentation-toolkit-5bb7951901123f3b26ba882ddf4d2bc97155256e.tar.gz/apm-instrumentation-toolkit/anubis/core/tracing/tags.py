"""Centralized span tagging helpers.

Provides consistent tag formatting for all span types:
- tag_step_span(): Tag step spans with standard attributes
- tag_batch_span(): Tag batch item spans with standard attributes
- tag_agent_span(): Tag agent spans with standard attributes

All helpers tag both APM spans (via span.set_tag) and the active LLMObs span
(via LLMObs.annotate) so every attribute is visible in both observability views.
"""

import getpass
import logging
import os
import subprocess
import sys
from typing import Any, Optional

from ddtrace.llmobs import LLMObs

from .config import is_llmobs_enabled

logger = logging.getLogger(__name__)

_CI_USER_VARS = (
    "GITHUB_ACTOR",
    "GITHUB_TRIGGERING_ACTOR",
    "GITLAB_USER_LOGIN",
)

_CI_PROVIDERS = {
    "GITHUB_ACTIONS": "github-actions",
    "GITLAB_CI": "gitlab-ci",
}


def _get_username() -> str:
    """Resolve the human who triggered this run.

    CI: check provider-specific env vars for the actor.
    Local/workspace: OS login (e.g. william.conti).
    """
    for var in _CI_USER_VARS:
        val = os.environ.get(var, "").strip()
        if val:
            return val

    try:
        result = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        name = result.stdout.strip()
        if name:
            return name
    except Exception:
        pass

    try:
        return os.environ.get("DD_APM_USER") or getpass.getuser()
    except Exception as e:
        logger.debug("Could not determine username: %s", e)
        return "unknown"


def _is_prod_install() -> bool:
    """Check if running from a production install (dogbrew) vs dev source."""
    return sys.prefix.startswith("/opt/dogbrew") or "/opt/dogbrew/" in (sys.executable or "")


def _get_origin() -> str:
    """Detect where this run is executing.

    Returns one of: github-actions, gitlab-ci, local-prod, local-dev.
    """
    for env_var, provider in _CI_PROVIDERS.items():
        if os.environ.get(env_var):
            return provider
    return "local-prod" if _is_prod_install() else "local-dev"


_USERNAME: str = _get_username()
_ORIGIN: str = _get_origin()


def tag_step_span(
    span: Any,
    step_name: str,
    workflow_name: str,
    namespace: str,
    parent_workflow: Optional[str] = None,
    model: Optional[str] = None,
    repository: Optional[str] = None,
) -> None:
    """Tag a step span with standard attributes.

    Args:
        span: The span to tag
        step_name: Name of the step (unique name with _2, _3 suffix if duplicated)
        workflow_name: Name of the containing workflow
        namespace: Workflow namespace
        parent_workflow: Parent workflow name (if nested)
        model: Model used by the step (for agent steps)
        repository: Target repository slug (e.g. dd_trace_js)
    """
    span.set_tag("step.name", step_name)
    span.set_tag("workflow.name", workflow_name)
    span.set_tag("workflow.namespace", namespace)
    span.set_tag("workflow.user", _USERNAME)
    span.set_tag("workflow.origin", _ORIGIN)
    if parent_workflow:
        span.set_tag("workflow.parent", parent_workflow)
    if model:
        span.set_tag("step.model", model)
    if repository:
        span.set_tag("workflow.repository", repository)

    if is_llmobs_enabled():
        metadata: dict = {
            "step.name": step_name,
            "workflow.name": workflow_name,
            "workflow.namespace": namespace,
            "workflow.user": _USERNAME,
            "workflow.origin": _ORIGIN,
        }
        if parent_workflow:
            metadata["workflow.parent"] = parent_workflow
        if model:
            metadata["step.model"] = model
        if repository:
            metadata["workflow.repository"] = repository
        try:
            LLMObs.annotate(metadata=metadata)
        except Exception as e:
            logger.debug("Failed to annotate LLMObs step span: %s", e)


def tag_batch_span(
    span: Any,
    item_id: str,
    index: int,
    step_name: str,
    total_items: Optional[int] = None,
    attempt: Optional[int] = None,
) -> None:
    """Tag a batch item span with standard attributes.

    Args:
        span: The span to tag
        item_id: Unique identifier for the batch item
        index: Index of the item in the batch (0-indexed)
        step_name: Name of the step processing this batch
        total_items: Total number of items in the batch
        attempt: Attempt number for retries
    """
    span.set_tag("batch.item_id", item_id)
    span.set_tag("batch.index", str(index))
    span.set_tag("batch.step", step_name)
    if total_items is not None:
        span.set_tag("batch.total_items", str(total_items))
    if attempt is not None:
        span.set_tag("batch.attempt", str(attempt))

    if is_llmobs_enabled():
        metadata: dict = {
            "batch.item_id": item_id,
            "batch.index": index,
            "batch.step": step_name,
        }
        if total_items is not None:
            metadata["batch.total_items"] = total_items
        if attempt is not None:
            metadata["batch.attempt"] = attempt
        try:
            LLMObs.annotate(metadata=metadata)
        except Exception as e:
            logger.debug("Failed to annotate LLMObs batch span: %s", e)


def tag_agent_span(
    span: Any,
    task: str,
    model: str,
    workflow_name: Optional[str] = None,
    step_name: Optional[str] = None,
    namespace: Optional[str] = None,
    repository: Optional[str] = None,
) -> None:
    """Tag an agent span with standard attributes.

    Args:
        span: The span to tag
        task: Task description (truncated to 200 chars)
        model: Model used by the agent
        workflow_name: Name of the containing workflow
        step_name: Name of the containing step
        namespace: Workflow namespace
        repository: Target repository slug (e.g. dd_trace_js)
    """
    span.set_tag("agent.task", str(task)[:200])
    span.set_tag("agent.model", model)
    if workflow_name:
        span.set_tag("agent.workflow", workflow_name)
    if step_name:
        span.set_tag("agent.step", step_name)
    if namespace:
        span.set_tag("agent.namespace", namespace)
    if repository:
        span.set_tag("workflow.repository", repository)

    if is_llmobs_enabled():
        metadata: dict = {
            "agent.task": str(task)[:200],
            "agent.model": model,
        }
        if workflow_name:
            metadata["agent.workflow"] = workflow_name
        if step_name:
            metadata["agent.step"] = step_name
        if namespace:
            metadata["agent.namespace"] = namespace
        if repository:
            metadata["workflow.repository"] = repository
        try:
            LLMObs.annotate(metadata=metadata)
        except Exception as e:
            logger.debug("Failed to annotate LLMObs agent span: %s", e)


def tag_agent_result(
    span: Any,
    success: bool,
    error: Optional[str] = None,
    cost_usd: Optional[float] = None,
    duration_seconds: Optional[float] = None,
    num_turns: Optional[int] = None,
    max_turns: Optional[int] = None,
    session_id: Optional[str] = None,
) -> None:
    """Tag an agent span with result metrics.

    Args:
        span: The span to tag
        success: Whether the agent completed successfully
        error: Error message if failed
        cost_usd: Total cost in USD
        duration_seconds: Duration in seconds
        num_turns: Number of conversation turns
        max_turns: Maximum turns allowed (for exhaustion detection)
        session_id: Claude session ID (can be used to resume the conversation)
    """
    span.set_tag("agent.success", str(success))
    if error:
        span.set_tag("agent.error", str(error)[:500])
    if cost_usd is not None:
        span.set_tag("agent.cost_usd", str(cost_usd))
    if duration_seconds is not None:
        span.set_tag("agent.duration_seconds", str(duration_seconds))
    if num_turns is not None:
        span.set_tag("agent.num_turns", str(num_turns))
    if max_turns is not None:
        span.set_tag("agent.max_turns", str(max_turns))
    if num_turns is not None and max_turns is not None:
        hit_max = num_turns >= max_turns
        span.set_tag("agent.hit_max_turns", str(hit_max))
    if session_id:
        span.set_tag("agent.session_id", session_id)

    if is_llmobs_enabled():
        # `metrics` is reserved for token/cost tracking with specific keys
        # (input_tokens, output_cost, etc.); the LLMObs intake silently drops
        # spans whose metric keys contain dots. Custom agent stats go in metadata.
        metadata: dict = {"agent.success": str(success)}
        if error:
            metadata["agent.error"] = str(error)[:500]
        if cost_usd is not None:
            metadata["agent.cost_usd"] = cost_usd
        if duration_seconds is not None:
            metadata["agent.duration_seconds"] = duration_seconds
        if num_turns is not None:
            metadata["agent.num_turns"] = num_turns
        if max_turns is not None:
            metadata["agent.max_turns"] = max_turns
        if num_turns is not None and max_turns is not None:
            metadata["agent.hit_max_turns"] = str(num_turns >= max_turns)
        if session_id:
            metadata["agent.session_id"] = session_id
        try:
            LLMObs.annotate(metadata=metadata)
        except Exception as e:
            logger.debug("Failed to annotate LLMObs agent result: %s", e)


def tag_error(
    span: Any,
    error: Exception,
    success_tag: Optional[str] = None,
) -> None:
    """Tag a span with error information.

    Args:
        span: The span to tag
        error: The exception that occurred
        success_tag: Optional success tag to set (e.g., "workflow.success", "step.success")
    """
    if success_tag:
        span.set_tag(success_tag, "False")
    span.error = 1
    span.set_tag("error.message", str(error)[:500])
    span.set_tag("error.type", type(error).__name__)


def tag_workflow_cost(
    span: Any,
    cost_usd: Optional[float] = None,
    num_turns: Optional[int] = None,
    agent_runs: Optional[int] = None,
) -> None:
    """Tag a workflow span with cost metrics.

    Args:
        span: The span to tag
        cost_usd: Total cost in USD
        num_turns: Total number of turns across all agents
        agent_runs: Number of agent runs
    """
    if cost_usd is not None:
        span.set_tag("workflow.cost_usd", cost_usd)
    if num_turns is not None:
        span.set_tag("workflow.num_turns", num_turns)
    if agent_runs is not None:
        span.set_tag("workflow.agent_runs", agent_runs)

    if is_llmobs_enabled():
        # `metrics` is reserved for token/cost tracking with specific keys
        # (input_tokens, output_cost, etc.); the LLMObs intake silently drops
        # spans whose metric keys contain dots. Custom workflow stats go in metadata.
        metadata: dict = {}
        if cost_usd is not None:
            metadata["workflow.cost_usd"] = cost_usd
        if num_turns is not None:
            metadata["workflow.num_turns"] = num_turns
        if agent_runs is not None:
            metadata["workflow.agent_runs"] = agent_runs
        if metadata:
            try:
                LLMObs.annotate(metadata=metadata)
            except Exception as e:
                logger.debug("Failed to annotate LLMObs workflow stats: %s", e)
