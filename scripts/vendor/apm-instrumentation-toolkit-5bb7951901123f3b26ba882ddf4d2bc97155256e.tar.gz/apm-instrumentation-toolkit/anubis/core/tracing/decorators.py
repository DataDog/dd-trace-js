"""Tracing decorators for workflows and agents.

Provides decorators that add LLMObs instrumentation:
- traced_workflow(): Workflow run method tracing with context management
- traced_agent(): Agent spawn function tracing (APM)
"""

import logging
from functools import wraps
from inspect import signature
from typing import Any, Callable, Optional

from ddtrace.internal.utils.formats import format_trace_id
from ddtrace.llmobs import LLMObs
from ddtrace.trace import tracer

from .config import get_service_name, is_llmobs_enabled
from .context import (
    _current_llmobs_span_context,
    _last_step_span_context,
    add_span_link,
    clear_last_step_context,
    export_span_context,
    get_current_span_context,
    get_last_step_context,
    set_current_span_context,
    set_last_step_context,
)
from .tags import _ORIGIN, _USERNAME, tag_agent_result, tag_agent_span, tag_error

logger = logging.getLogger(__name__)

_DD_SITE = "app.datadoghq.com"


def _emit_trace_links(workflow: Any, span: Any) -> None:
    """Emit trace links via the workflow emitter.

    Args:
        workflow: The workflow instance (has _ctx with emitter)
        span: The workflow span (still open) with span_id and trace_id
    """
    ctx = getattr(workflow, "_ctx", None)
    if not ctx:
        return

    apm_url: Optional[str] = None
    apm_trace_id: Optional[str] = None
    llmobs_url: Optional[str] = None
    llmobs_trace_id: Optional[str] = None
    exported = None

    # APM URL — always available from span.trace_id directly.
    try:
        apm_trace_id = format_trace_id(span.trace_id)
        apm_url = f"https://{_DD_SITE}/apm/trace/{apm_trace_id}"
    except Exception as e:
        logger.warning("Could not build APM trace URL: %s", e)

    # LLMObs URL — requires LLMObs.export_span() to return a trace ID.
    try:
        exported = LLMObs.export_span(span)
        if exported and exported.get("trace_id"):
            llmobs_trace_id = str(exported["trace_id"])
            llmobs_url = f"https://{_DD_SITE}/llm/traces/trace/{llmobs_trace_id}"
    except Exception as e:
        logger.debug("Could not build LLMObs trace URL: %s", e)

    if not apm_url and not llmobs_url:
        return

    from .running_spans import _get_flush_interval  # noqa: PLC0415

    flush_secs = int(_get_flush_interval())

    ctx.emit("section", name="Trace Links")
    ctx.emit(
        "info",
        message=f"Spans are partially flushed every {flush_secs}s — refresh the page to see in-flight data",
    )
    if llmobs_url:
        ctx.emit("detail", label="LLM Observability", value=llmobs_url)
    if apm_url:
        ctx.emit("detail", label="APM Trace", value=apm_url)
    ctx.emit("detail", label="Test Agent UI", value="http://localhost:18080")
    ctx.emit("blank")

    # Store in context for downstream use (e.g., PR descriptions, smoke output).
    if apm_url:
        ctx.set("apm_trace_url", apm_url)
    if apm_trace_id:
        ctx.set("apm_trace_id", apm_trace_id)
    if llmobs_url:
        ctx.set("llmobs_trace_url", llmobs_url)
    if llmobs_trace_id:
        ctx.set("llmobs_trace_id", llmobs_trace_id)


def _extract_success(result: Any) -> bool:
    """Extract success from various result types.

    Returns False when the result carries an error field — catches workflows
    that encode failures in output.error rather than output.success=False
    (e.g. eval workflows where status:ok but error/pass_rate encode the real result).
    """
    if result is None:
        return True
    if isinstance(result, bool):
        return result
    # A non-empty error field means failure even if success is True or absent.
    if getattr(result, "error", None):
        return False
    if hasattr(result, "success"):
        return bool(result.success)
    return True


def _tag_workflow_cost_from_ctx(workflow: Any, span: Any) -> None:
    """Extract and tag workflow cost metrics from state."""
    try:
        if hasattr(workflow, "_ctx") and workflow._ctx:
            ctx = workflow._ctx
            if hasattr(ctx, "state") and ctx.state:
                metrics = ctx.state.get_metrics()
                if metrics:
                    cost_usd = metrics.get("total_cost_usd", 0)
                    num_turns = metrics.get("total_turns", 0)
                    agent_runs = len(metrics.get("agent_runs", []))
                    input_tokens = metrics.get("total_input_tokens", 0)
                    output_tokens = metrics.get("total_output_tokens", 0)
                    span.set_tag("workflow.cost_usd", cost_usd)
                    span.set_tag("workflow.num_turns", num_turns)
                    span.set_tag("workflow.agent_runs", agent_runs)
                    if is_llmobs_enabled():
                        try:
                            # `metrics` is reserved for token/cost tracking with
                            # specific keys (input_tokens, output_cost, etc.); the
                            # intake silently drops spans whose metric keys contain
                            # dots. Custom workflow stats belong in metadata.
                            LLMObs.annotate(
                                metadata={
                                    "workflow.cost_usd": cost_usd,
                                    "workflow.num_turns": num_turns,
                                    "workflow.agent_runs": agent_runs,
                                }
                            )
                        except Exception as e:
                            logger.debug("Failed to annotate LLMObs workflow stats: %s", e)
                        try:
                            # Write aggregate token and cost totals as LLMObs metrics
                            # so the root workflow span carries non-zero values for
                            # @metrics.input_tokens, @metrics.output_tokens,
                            # @metrics.total_tokens, and @metrics.cost_usd — matching
                            # the keys written on each child agent/task span by
                            # executors/agent.py. This ensures the root span is
                            # queryable by cost/token even when child spans are not
                            # individually accessible (e.g., killed runs).
                            LLMObs.annotate(
                                metrics={
                                    "input_tokens": input_tokens,
                                    "output_tokens": output_tokens,
                                    "total_tokens": input_tokens + output_tokens,
                                    "cost_usd": cost_usd,
                                }
                            )
                        except Exception as e:
                            logger.debug("Failed to annotate LLMObs workflow token metrics: %s", e)
    except Exception as e:
        logger.debug(f"Failed to tag workflow cost metrics: {e}")


def traced_workflow(func: Callable) -> Callable:
    """Decorator for workflow run methods.

    Creates LLMObs workflow span with:
    - workflow.name, workflow.namespace tags
    - Input/output annotations
    - Sequential span linking
    - Context management for child spans
    """

    @wraps(func)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        workflow_name = getattr(self, "name", "unknown")
        namespace = getattr(self, "namespace", "unknown")
        is_nested = getattr(self, "_is_nested", False)
        parent_workflow = getattr(self, "_parent_workflow", None)

        if not is_llmobs_enabled():
            raise RuntimeError(
                "LLMObs is not enabled — all workflow runs require observability. "
                "Ensure init_tracing() succeeded before running a workflow."
            )

        # Capture parent contexts for linking
        workflow_ctx = get_current_span_context()
        last_step_ctx = get_last_step_context()
        session_id = f"{workflow_name}:{namespace}"

        try:
            with LLMObs.workflow(name=workflow_name, session_id=session_id) as span:
                span_ctx = export_span_context(span)

                # Set up context for children
                workflow_token = None
                last_step_token = None
                if span_ctx:
                    workflow_token = set_current_span_context(
                        span_ctx["span_id"], span_ctx["trace_id"]
                    )
                    last_step_token = clear_last_step_context()

                # Link nested workflows to parent/previous
                if is_nested:
                    link_target = last_step_ctx or workflow_ctx
                    if link_target:
                        add_span_link(
                            span, link_target["span_id"], link_target["trace_id"], "output", "input"
                        )

                # Add tags
                span.set_tag("workflow.name", workflow_name)
                span.set_tag("workflow.namespace", namespace)
                span.set_tag("workflow.user", _USERNAME)
                span.set_tag("workflow.origin", _ORIGIN)
                span.set_tag("workflow.is_nested", str(is_nested))
                if parent_workflow:
                    span.set_tag("workflow.parent", parent_workflow)
                if repository := getattr(self, "repository", None):
                    span.set_tag("workflow.repository", repository)
                if model := getattr(self, "model", None):
                    span.set_tag("workflow.model", model)

                wf_metadata: dict = {
                    "is_nested": is_nested,
                    "parent": parent_workflow,
                    "workflow.user": _USERNAME,
                    "workflow.origin": _ORIGIN,
                }
                _wf_repository = getattr(self, "repository", None)
                _wf_model = getattr(self, "model", None)
                if _wf_repository:
                    wf_metadata["workflow.repository"] = _wf_repository
                if _wf_model:
                    wf_metadata["workflow.model"] = _wf_model
                LLMObs.annotate(
                    input_data={"namespace": namespace, "workflow": workflow_name},
                    metadata=wf_metadata,
                )

                # Store trace IDs on the workflow instance so _start_run() can
                # persist them to state.json before any steps execute.
                try:
                    self._pending_apm_trace_id = format_trace_id(span.trace_id)
                except Exception as e:
                    logger.warning("Failed to extract APM trace ID: %s", e)
                try:
                    _exported = LLMObs.export_span(span)
                    if _exported and _exported.get("trace_id"):
                        self._pending_llmobs_trace_id = str(_exported["trace_id"])
                except Exception as e:
                    logger.warning("Failed to extract LLMObs trace ID: %s", e)

                # Emit trace links early so URLs are visible while workflow runs
                if not is_nested:
                    _emit_trace_links(self, span)

                try:
                    result = func(self, *args, **kwargs)
                    _tag_workflow_cost_from_ctx(self, span)

                    if _extract_success(result):
                        try:
                            output_data = None
                            if hasattr(result, "output") and result.output is not None:
                                if hasattr(result.output, "model_dump"):
                                    output_data = result.output.model_dump()
                                else:
                                    output_data = str(result.output)[:25000]
                            LLMObs.annotate(output_data=output_data)
                        except Exception as e:
                            logger.debug(f"Failed to annotate output: {e}")
                    else:
                        # Workflow returned a failure result (not an exception).
                        # Propagate the error status to this span so dashboards
                        # surface it instead of reporting status=ok.
                        error_msg = getattr(result, "error", None) or "workflow failed"
                        span.set_tag("workflow.success", "False")
                        span.error = 1
                        span.set_tag("error.message", str(error_msg)[:500])
                        span.set_tag("error.type", "WorkflowError")

                    return result
                except Exception as e:
                    tag_error(span, e, success_tag="workflow.success")
                    raise
                finally:
                    # Always emit trace links (success, error, or interrupt)
                    if not is_nested:
                        _emit_trace_links(self, span)
                    if last_step_token:
                        _last_step_span_context.reset(last_step_token)
                    if workflow_token:
                        _current_llmobs_span_context.reset(workflow_token)
                    if span_ctx:
                        set_last_step_context(span_ctx["span_id"], span_ctx["trace_id"])

        except Exception as e:
            logger.debug(f"LLMObs workflow span failed: {e}")
            return func(self, *args, **kwargs)

    return wrapper


def traced_agent(func: Callable) -> Callable:
    """Decorator for agent spawn functions. Creates APM span with metrics."""
    func_signature = signature(func)

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            bound_args = func_signature.bind_partial(*args, **kwargs)
            bound_args.apply_defaults()
            call_args: dict[str, Any] = dict(bound_args.arguments)
        except TypeError:
            call_args = {}

        task = call_args.get("task_description") or kwargs.get(
            "task_description", args[0] if args else "agent"
        )
        model = call_args.get("model") or kwargs.get("model", "unknown")
        workflow_name = call_args.get("workflow_name") or kwargs.get("workflow_name")
        step_name = call_args.get("step_name") or kwargs.get("step_name")
        namespace = call_args.get("namespace") or kwargs.get("namespace")
        repository = call_args.get("repository") or kwargs.get("repository")

        # Try to extract context from emitter
        if emitter := call_args.get("emitter") or kwargs.get("emitter"):
            workflow_name = (
                workflow_name
                or getattr(emitter, "parent_workflow", None)
                or getattr(emitter, "workflow", None)
            )
            step_name = step_name or getattr(emitter, "current_step", None)
            namespace = namespace or getattr(emitter, "namespace", None)
            repository = repository or getattr(emitter, "repository", None)

        resource_parts = [p for p in [workflow_name, str(task)[:50], namespace] if p]
        resource = ":".join(resource_parts) or str(task)[:50]

        with tracer.trace("agent.run", service=get_service_name(), resource=resource) as span:
            tag_agent_span(
                span,
                task=task,
                model=model,
                workflow_name=workflow_name,
                step_name=step_name,
                namespace=namespace,
                repository=repository,
            )

            try:
                result = func(*args, **kwargs)

                success = getattr(result, "success", True)
                error = getattr(result, "error", None) if hasattr(result, "error") else None
                metrics = getattr(result, "metrics", None)
                session_id = getattr(result, "session_id", None)
                max_turns = call_args.get("max_turns")

                tag_agent_result(
                    span,
                    success=success,
                    error=str(error) if error else None,
                    cost_usd=getattr(metrics, "cost_usd", None) if metrics else None,
                    duration_seconds=getattr(metrics, "duration_seconds", None)
                    if metrics
                    else None,
                    num_turns=getattr(metrics, "num_turns", None) if metrics else None,
                    max_turns=max_turns,
                    session_id=session_id,
                )
                return result
            except Exception as e:
                tag_error(span, e, success_tag="agent.success")
                raise

    return wrapper
