"""dd-auth integration for automatic Datadog credential provisioning.

Uses the internal Datadog Authentication CLI (dd-auth) to provision
ephemeral API/APP keys via OAuth, removing the need for manual key management.
"""

import logging
import os
import shutil
import subprocess
import urllib.error
import urllib.request
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)

# Default domain for dd-auth (Org 2 prod)
DD_AUTH_DEFAULT_DOMAIN = "app.datadoghq.com"

# Internal endpoint only reachable via Appgate VPN
_APPGATE_CHECK_URL = "https://datadoghq.atlassian.net/wiki"
_APPGATE_CHECK_TIMEOUT = 5


def is_appgate_connected() -> bool:
    """Check if Appgate VPN is connected by probing an internal endpoint."""
    try:
        req = urllib.request.Request(_APPGATE_CHECK_URL, method="HEAD")
        urllib.request.urlopen(req, timeout=_APPGATE_CHECK_TIMEOUT)  # noqa: S310
        return True
    except (urllib.error.URLError, OSError):
        return False


def is_dd_auth_available() -> bool:
    """Check if dd-auth CLI is installed and available on PATH."""
    return shutil.which("dd-auth") is not None


def get_credentials_from_dd_auth(
    domain: str = DD_AUTH_DEFAULT_DOMAIN,
    no_cache: bool = False,
) -> dict[str, str]:
    """Invoke dd-auth --output to get credentials as env vars.

    Args:
        domain: Datadog org domain (default: app.datadoghq.com for Org 2).
        no_cache: Bypass credential cache to force new key provisioning.

    Returns:
        Dict with DD_API_KEY, DD_APP_KEY, and DD_SITE values.

    Raises:
        DdAuthError: If dd-auth invocation fails.
    """
    cmd = ["dd-auth", "--domain", domain, "--force-app-key", "--output"]
    if no_cache:
        cmd.append("--no-cache")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except FileNotFoundError as exc:
        raise DdAuthError(
            "dd-auth is not installed. Install with: brew install datadog/tap/dd-auth"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise DdAuthError(
            "dd-auth timed out (120s). Check your network and browser for OAuth prompt."
        ) from exc

    if result.returncode != 0:
        stderr = result.stderr.strip()
        raise DdAuthError(f"dd-auth failed (exit {result.returncode}): {stderr}")

    credentials: dict[str, str] = {}
    for line in result.stdout.strip().splitlines():
        if "=" in line:
            key, _, value = line.partition("=")
            key = key.strip()
            if key in ("DD_API_KEY", "DD_APP_KEY", "DD_SITE"):
                credentials[key] = value.strip()

    if "DD_API_KEY" not in credentials:
        raise DdAuthError("dd-auth did not return DD_API_KEY. Output:\n" + result.stdout)

    return credentials


def has_dd_api_key_in_env() -> bool:
    """Check if DD_API_KEY is already set in the process environment."""
    value = os.environ.get("DD_API_KEY", "").strip()
    return bool(value) and value != "<your-org2-api-key-here>"


def get_org2_credentials(no_cache: bool = False) -> dict[str, str]:
    """Get credentials verified for Org 2 via dd-auth.

    dd-auth is always the source of credentials — no escape hatch.
    Use CI environment injection (CI=true + DD_API_KEY in env) for
    non-interactive automation contexts instead.

    Args:
        no_cache: Bypass dd-auth credential cache to force a fresh OAuth token.

    Returns:
        Dict with DD_API_KEY, DD_APP_KEY, and DD_SITE verified for Org 2.

    Raises:
        DdAuthError: If dd-auth is unavailable, invocation fails, credentials
                     are for the wrong org, or org identity cannot be verified.
    """
    if not is_dd_auth_available():
        raise DdAuthError(
            "dd-auth is not installed — required to authenticate to Org 2.\n"
            "  Install with: brew install datadog/tap/dd-auth"
        )

    credentials = get_credentials_from_dd_auth(domain=DD_AUTH_DEFAULT_DOMAIN, no_cache=no_cache)
    api_key = credentials.get("DD_API_KEY", "")
    app_key = credentials.get("DD_APP_KEY", "")
    site = credentials.get("DD_SITE", "datadoghq.com")

    org_info = get_org_info(api_key, app_key=app_key, site=site)

    if org_info is None and not no_cache:
        # Cached credential is stale (dead key → 401). Force a fresh OAuth exchange.
        # This re-prompts in the browser once, then the new key is cached for next time.
        logger.info("dd-auth cached key rejected by Datadog — retrying with --no-cache")
        credentials = get_credentials_from_dd_auth(domain=DD_AUTH_DEFAULT_DOMAIN, no_cache=True)
        api_key = credentials.get("DD_API_KEY", "")
        app_key = credentials.get("DD_APP_KEY", "")
        site = credentials.get("DD_SITE", "datadoghq.com")
        org_info = get_org_info(api_key, app_key=app_key, site=site)

    if org_info is None:
        raise DdAuthError(
            "Could not verify Datadog org for dd-auth credentials — "
            "check network connectivity and that the credentials are valid."
        )

    org_id = org_info.get("id", "")
    if org_id.lower() != DATADOG_ORG2_ID.lower():
        org_name = org_info.get("name", org_id)
        raise DdAuthError(
            f"dd-auth returned credentials for '{org_name}' (id={org_id}), not Org 2.\n"
            "  Re-run 'dd-auth' and authenticate to the Datadog internal org."
        )

    logger.debug("Verified dd-auth credentials are for Org 2")
    return credentials


# Stable UUID for the Datadog internal org (Org 2).
DATADOG_ORG2_ID = "8dee7c38-00cb-11ea-a77b-8b5a08d3b091"


def get_org_info(
    api_key: str,
    app_key: str = "",
    site: str = "datadoghq.com",
    timeout: float = 5.0,
) -> Optional[dict[str, Any]]:
    """Return org info dict for the given credentials, or ``None`` on failure.

    Uses ``GET /api/v2/current_user`` (lower privilege than /api/v1/org) to
    extract the org ID from the authenticated user's relationships.  Returns a
    dict with:
      - ``id``   — stable org UUID
      - ``name`` — human-readable label ("Org 2 (Datadog internal)" for the
                   known internal org, otherwise the raw UUID)

    Requires both api_key and app_key — returns ``None`` if either is empty.
    """
    if not api_key or not app_key:
        return None
    try:
        url = f"https://api.{site}/api/v2/current_user"
        headers = {"DD-API-KEY": api_key, "DD-APPLICATION-KEY": app_key}
        resp = httpx.get(url, headers=headers, timeout=timeout)
        if resp.status_code == 200:
            data: dict[str, Any] = resp.json()
            org_id: str = (
                data.get("data", {})
                .get("relationships", {})
                .get("org", {})
                .get("data", {})
                .get("id", "")
            )
            if org_id:
                label = "Org 2 (Datadog internal)" if org_id == DATADOG_ORG2_ID else org_id
                return {"id": org_id, "name": label}
        logger.debug("current_user API returned %d", resp.status_code)
    except Exception as e:
        logger.debug("Org info lookup failed: %s", e)
    return None


class DdAuthError(Exception):
    """Raised when dd-auth invocation fails."""
