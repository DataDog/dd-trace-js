"""Workflow error types."""

from typing import List, Optional


class WorkflowError(Exception):
    """Raised when workflow execution fails."""

    pass


class ValidationError(Exception):
    """Raised when validation fails."""

    def __init__(self, message: str, errors: Optional[List[str]] = None):
        super().__init__(message)
        self.errors = errors or [message]


class TimeoutError(Exception):
    """Raised when step times out."""

    pass


class StructuredOutputError(WorkflowError):
    """Raised when an agent fails to produce valid structured output.

    This is a recoverable error — the step-level fixer loop can catch it
    and re-run the agent with error context to obtain proper structured output.
    """

    def __init__(self, message: str, step_name: str = ""):
        super().__init__(message)
        self.step_name = step_name


class ResetToStep(Exception):
    # TODO: This should be changed to have a better way to reset to a previous step without throwing an exception.
    """Raised by after_step to reset workflow to a previous step.

    Usage in after_step:
        if review.verdict == 'needs_reset':
            ctx.set('reviewer_guidance', review.guidance)
            raise ResetToStep(review.reset_to_step)
    """

    def __init__(self, step_name: str, guidance: Optional[str] = None):
        self.step_name = step_name
        self.guidance = guidance
        super().__init__(f"Reset to step: {step_name}")


class UserAbortError(KeyboardInterrupt):
    """Raised when user aborts via Ctrl+C.

    Inherits from KeyboardInterrupt so it propagates through the entire
    workflow stack without being caught by generic Exception handlers.
    """

    pass
