"""Agent spawning orchestration.

Main entry point for spawning Claude Code agents.

This module provides high-level orchestration for agent execution:
- Skill installation and cleanup
- Output validation against schemas
- Fixer agent loops for error recovery
- Event emission for progress tracking

The actual agent execution is delegated to AgentRunner implementations
(ClaudeCliRunner, ClaudeSDKRunner) which handle the low-level details.
"""

import json
import logging
import os
import shutil
import tempfile
import time
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Type, cast

from anthropic import transform_schema
from pydantic import BaseModel

from ..config import get_config
from ..resources import get_global_resource_manager, get_global_resources, schema_to_doc
from ..state.utils import safe_relative_path
from ..tracing import traced_agent
from .models import AgentResult
from .runners import AgentRunner, ClaudeSDKRunner, MockAgentRunner

logger = logging.getLogger(__name__)

# Suppress SDK async generator cleanup warnings (may happen during GC in threads).
# The Claude SDK's internal async generators may not be fully cleaned up when
# asyncio.run() ends, causing "coroutine never awaited" warnings.
# This is a cosmetic issue that doesn't affect functionality.
warnings.filterwarnings(
    "ignore",
    message=r"coroutine.*aclose.*never awaited",
    category=RuntimeWarning,
)


@traced_agent
def spawn_agent(
    task_description: str,
    prompt: str,
    working_directory: Path,
    emitter: Any,
    timeout_minutes: int = 30,
    max_turns: int = 100,
    required_files: Optional[List[str]] = None,
    log_dir: Optional[Path] = None,
    output_schema: Optional[Type[BaseModel]] = None,
    model: str = "sonnet",
    fixer_prompt: Optional[str] = None,
    max_fixer_attempts: int = 2,
    skills: Optional[List[str]] = None,
    repository: Optional[str] = None,
    resume_session_id: Optional[str] = None,
    repo_root: Optional[Path] = None,
    sandbox: bool = True,
    system_prompt: Optional[str] = None,
    sdk_hooks: Optional[Dict[str, List[Any]]] = None,
    repo_adapter: Optional[Any] = None,
    permission_allow: Optional[List[str]] = None,
    permission_deny: Optional[List[str]] = None,
    extra_env: Optional[Dict[str, str]] = None,
    mcp_servers: Optional[Dict[str, Any]] = None,
    signal_dirs: Optional[List[Path]] = None,
    max_cost_usd: Optional[float] = None,
) -> AgentResult:
    """Spawn a Claude Code agent.

    Args:
        task_description: Brief description (for logging)
        prompt: Full task prompt for the agent
        working_directory: Where agent should work
        emitter: EventEmitter for logging (required)
        timeout_minutes: Max time for agent to complete
        max_turns: Maximum agent turns
        required_files: Files the agent should create
        log_dir: Directory for agent logs
        output_schema: Pydantic model for output validation
        model: Model to use ('sonnet', 'haiku', 'opus')
        fixer_prompt: Custom prompt for fixer agent (uses default if None)
        max_fixer_attempts: Max attempts for fixer agent (default 2)
        skills: List of skill names to install and enforce
        enforce_skills: If True, block code changes until skills are read (default True)
        repository: Target repository for skills (default 'dd_trace_js')
        resume_session_id: Optional session ID to resume a previous conversation
        repo_root: Optional repo root path to allow file access to (in addition to working_directory)
        sandbox: Enable sandbox mode for bash isolation (default True)
        system_prompt: Optional system prompt to set agent identity/context
        sdk_hooks: Optional dict of SDK hook callbacks keyed by event name
            (e.g. ``{"PreToolUse": [...], "Stop": [...]}``). When None,
            hooks are loaded from global resources for ``repository``.
        permission_deny: Optional list of permission deny rules (e.g. ``Read(/path/**)``)

    Returns:
        AgentResult with success, output, error, and structured_output
    """
    if log_dir is None:
        raise ValueError("log_dir is required for spawn_agent")

    # Try to get config for resource loading and paths
    try:
        config = get_config()
    except Exception:
        # Config not available - agent will have limited functionality
        config = None

    # Resolve repository from config if not provided
    if repository is None and config is not None:
        repository = config.default_repository
    if repository is None:
        repository = "dd_trace_js"

    # Use configured base_dir (repo root) if repo_root not explicitly provided
    if repo_root is None and config is not None:
        repo_root = config.get_repo_root(repository)

    # Setup
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = int(time.time())

    # Set up skill enforcement
    # skills=[] (empty list) -> load ALL skills
    # skills=None -> load NO skills
    # skills=['specific', 'skills'] -> load only those skills
    installed_skills: List[Tuple[Path, bool]] = []
    if skills is not None:  # None means no skills, empty list means all skills
        # Use global resource bundle (initialized at app startup)
        bundle = get_global_resources(repository)
        if bundle and bundle.skills:
            # Install skills to agent working directory
            installed_skills = bundle.skills.install(skills, working_directory)
            if installed_skills:
                # Skills are installed as {name}/SKILL.md, so get parent dir name
                skill_names = [p.parent.name for p, _ in installed_skills]
                emitter.emit(
                    "info",
                    message=f"Installed {len(installed_skills)} skills to {working_directory / '.claude/skills'}: {', '.join(skill_names)}",
                )
            else:
                emitter.emit(
                    "warn", message=f"No skills found to install (requested: {skills or 'ALL'})"
                )
        else:
            emitter.emit("warn", message="Global resources not configured - no skills installed")

    # Save prompt
    prompt_file = log_dir / f"agent-prompt-{timestamp}.md"
    prompt_file.write_text(f"# Agent Task: {task_description}\n\n{prompt}")

    # Stream output file for real-time monitoring
    stream_file = log_dir / f"agent-stream-{timestamp}.json"

    # Get relative paths for display
    log_path = safe_relative_path(stream_file.with_suffix(".log"))
    prompt_path = safe_relative_path(prompt_file)
    cwd_path = safe_relative_path(working_directory)
    schema_name = output_schema.__name__ if output_schema else None

    # Log info BEFORE starting live panel (live panel suppresses other output)
    # NOTE: These may be suppressed in batch context, so key info is also passed to agent_start
    emitter.emit("section", name="Agent starting")
    emitter.emit("info", message=f"Spawning agent: {task_description}")
    emitter.emit(
        "info", message=f"Model: {model}, max_turns: {max_turns}, schema: {schema_name or 'None'}"
    )
    model_override = os.environ.get("ANTHROPIC_MODEL", "")
    if model_override:
        emitter.emit(
            "info",
            message=f"Model override active: {model_override} (overrides step config: {model})",
        )
    emitter.emit("info", message=f"CWD: {cwd_path}")
    emitter.emit("info", message=f"Prompt: {prompt_path}")
    emitter.emit("info", message=f"Log: {log_path}")
    if resume_session_id:
        emitter.emit("info", message=f"Resuming session: {resume_session_id}")
    emitter.emit("info", message="Press Ctrl+C to interrupt and provide guidance")

    # Create runner with allowed paths for file access
    # Include repo_root and toolkit_root so agents can run toolkit scripts
    # Also include ~/.claude for shell initialization (sandbox needs access to shell snapshots)
    allowed_paths = []
    if repo_root:
        allowed_paths.append(repo_root)
    toolkit_root = config.toolkit_root if config else None
    if toolkit_root:
        allowed_paths.append(toolkit_root)
    # Add ~/.claude for shell initialization (required for sandbox to work properly)
    claude_config = Path.home() / ".claude"
    if claude_config.exists():
        allowed_paths.append(claude_config)

    # Add temp directory for temporary file operations (needed by various tools and test frameworks)
    # Use tempfile.gettempdir() for cross-platform support (macOS symlinks /tmp -> /private/tmp)
    tmp_path = Path(tempfile.gettempdir())
    allowed_paths.append(tmp_path)
    # Also add /tmp if it differs (e.g., macOS symlink) so both forms are allowed
    tmp_fallback = Path("/tmp")
    if tmp_fallback.resolve() != tmp_path.resolve() and tmp_fallback.exists():
        allowed_paths.append(tmp_fallback)

    # Add language-specific paths from the repo adapter (e.g., site-packages for Python)
    if repo_adapter is not None:
        allowed_paths.extend(repo_adapter.get_agent_allowed_paths())

    # Fall back to global system prompt if none explicitly provided
    if system_prompt is None:
        manager = get_global_resource_manager()
        if manager and manager.system_prompt:
            system_prompt = manager.system_prompt

    # Load SDK hooks from global resources if not explicitly provided.
    # Returned shape is dict keyed by SDK event name (e.g. "PreToolUse", "Stop").
    # The adapter is passed through so hook builders that declare an `adapter`
    # parameter (e.g. the shared lint hook) receive the active repo adapter.
    if sdk_hooks is None:
        bundle = get_global_resources(repository=repository)
        if bundle:
            sdk_hooks = bundle.hooks.load(adapter=repo_adapter)

    # Enable web access for all agents (WebFetch, WebSearch). Callers can
    # extend the allow list with extra entries — used by read-only reviewers
    # to whitelist specific inspection commands while a broad deny is in place
    # (e.g. allow ``Bash(git status*)`` / ``Bash(git diff*)`` while denying
    # ``Bash(git:*)``).
    #
    # CI smoke tests (DD_APM_MOCK_AGENTS=1) substitute a no-LLM runner that
    # returns a default-constructed output_schema. All upstream wiring
    # (config, skills, hooks, prompt assembly, allowed_paths) still
    # executes — only the LLM round-trip is skipped. See runners/mock.py.
    base_allow = ["WebFetch", "WebSearch"]
    final_allow = base_allow + [r for r in (permission_allow or []) if r not in base_allow]
    runner: AgentRunner
    if os.environ.get("DD_APM_MOCK_AGENTS", "").lower() in ("1", "true", "yes"):
        runner = MockAgentRunner()
    else:
        runner = ClaudeSDKRunner(
            allowed_paths=allowed_paths,
            sandbox=sandbox,
            permission_allow=final_allow,
            permission_deny=permission_deny or [],
            system_prompt=system_prompt,
            sdk_hooks=sdk_hooks,
            extra_env=extra_env or {},
            mcp_servers=mcp_servers or {},
            # In workspace mode Ctrl+C kills (default SIGINT); guidance uses SIGUSR1
            # via the Ctrl+G tmux keybinding set up by the workspace executor.
            allow_interrupt=not bool(os.environ.get("DD_APM_REMOTE")),
            signal_dirs=signal_dirs,
        )

    # Start live terminal panel (suppresses other output while active)
    # Pass key metadata so it's displayed in the panel even if info messages were suppressed
    emitter.emit(
        "agent_start",
        task=task_description,
        log_path=str(log_path),
        prompt_path=str(prompt_path),
        cwd=str(cwd_path),
        model=model,
        max_turns=max_turns,
        schema=schema_name,
    )

    try:
        # Run agent via runner
        result = runner.run(
            prompt=prompt,
            working_directory=working_directory,
            model=model,
            max_turns=max_turns,
            timeout_minutes=timeout_minutes,
            output_schema=output_schema,
            emitter=emitter,
            log_dir=log_dir,
            resume_session_id=resume_session_id,
        )

        # Emit agent_complete for live terminal panel
        cost = result.metrics.cost_usd if result.metrics else 0
        emitter.emit("agent_complete", task=task_description, success=result.success, cost=cost)

        if result.success:
            emitter.emit("section", name="Agent completed")

        if not result.success:
            return result

        # Mock mode: accept the synthesized output as-is. Skipping validation
        # and the fixer loop is intentional — mocked output may have required
        # fields unset (PydanticUndefined), and the fixer can't repair an
        # already-mocked agent. Real validation is exercised in non-mock CI runs.
        if isinstance(runner, MockAgentRunner):
            return result

        # Validate output (required files + schema)
        if required_files or output_schema:
            files_created, missing_files, schema_errors = _validate_output(
                required_files=required_files or [],
                working_directory=working_directory,
                output_schema=output_schema,
                raw_structured_output=result.raw_structured_output,
                emitter=emitter,
            )

            # If validation errors, run fixer loop (same session)
            if missing_files or schema_errors:
                # Skip fixer if agent hit max turns - session is exhausted
                hit_max_turns = result.metrics and result.metrics.error_subtype == "error_max_turns"
                if hit_max_turns:
                    emitter.emit(
                        "warn", message="Agent hit max turns - skipping fixer (session exhausted)"
                    )
                    return AgentResult(
                        success=False,
                        output=result.output,
                        files_created=files_created,
                        error="Agent hit max turns without producing valid output",
                        metrics=result.metrics,
                        session_id=result.session_id,
                    )

                # Fixable validation errors - try fixer loop using same session.
                # Cast: MockAgentRunner early-returned above, so runner here is
                # guaranteed to be a ClaudeSDKRunner. Mypy can't narrow through
                # the negative isinstance check on the broader AgentRunner type.
                result = _run_fixer_loop(
                    runner=cast(ClaudeSDKRunner, runner),
                    original_result=result,
                    files_created=files_created,
                    missing_files=missing_files,
                    schema_errors=schema_errors,
                    required_files=required_files or [],
                    working_directory=working_directory,
                    output_schema=output_schema,
                    log_dir=log_dir,
                    emitter=emitter,
                    fixer_prompt=fixer_prompt,
                    max_attempts=max_fixer_attempts,
                )
            else:
                # Validation passed
                result = AgentResult(
                    success=True,
                    output=result.output,
                    files_created=files_created,
                    files_modified=result.files_modified,
                    structured_output=_get_structured_output(
                        files_created, output_schema, result.raw_structured_output
                    ),
                    metrics=result.metrics,
                    session_id=result.session_id,
                )

        # Auto-track metrics if emitter supports it (e.g., Workflow base class)
        if hasattr(emitter, "add_agent_metrics") and result.metrics:
            emitter.add_agent_metrics(result.metrics, task_description)

        return result
    finally:
        # Clean up runner session
        runner.close()
        # Clean up installed skills (always runs, even on early returns)
        _cleanup_skills(installed_skills)


def _cleanup_skills(installed_skills: List[Tuple[Path, bool]]) -> None:
    """Remove installed skill directories after agent completes.

    Skills are installed as {name}/SKILL.md with optional subdirs
    (references/, scripts/). Remove the entire skill directory tree,
    but only if the directory didn't exist before we installed it.
    Pre-existing skills (e.g. a repo's own run-tests skill) are left intact.
    """
    for skill_path, pre_existing in installed_skills:
        if pre_existing:
            continue
        try:
            # Remove the entire skill directory (parent of SKILL.md)
            skill_dir = skill_path.parent
            if skill_dir.exists() and skill_dir.name != "skills":
                shutil.rmtree(skill_dir)
        except Exception as e:
            logger.warning(f"Failed to cleanup skill at {skill_path}: {e}")


def _validate_output(
    required_files: List[str],
    working_directory: Path,
    output_schema: Optional[Type[BaseModel]],
    raw_structured_output: Optional[Dict] = None,
    emitter: Any = None,
) -> tuple[List[str], List[str], List[str]]:
    """Validate required files exist and schema is valid.

    Args:
        required_files: Files that should exist
        working_directory: Directory to check for files
        output_schema: Pydantic model for structured output validation
        raw_structured_output: Raw structured output from agent (preferred for validation)
        emitter: EventEmitter for logging

    Returns:
        Tuple of (files_created, missing_files, schema_errors)
    """
    files_created = []
    missing_files = []

    for pattern in required_files:
        path = working_directory / pattern
        if path.exists():
            files_created.append(str(path))
        else:
            missing_files.append(pattern)

    schema_errors = []
    if output_schema is not None:
        # Prefer raw_structured_output from agent result
        if raw_structured_output:
            if emitter:
                emitter.emit(
                    "info", message=f"Validating structured output against {output_schema.__name__}"
                )
            try:
                output_schema.model_validate(raw_structured_output)
            except Exception as e:
                if emitter:
                    emitter.emit("warn", message=f"Structured output validation failed: {e}")
                schema_errors = [f"Structured output: {str(e)}"]
        elif files_created:
            # Fallback: validate first file as JSON (legacy behavior)
            first_file = Path(files_created[0])
            if emitter:
                emitter.emit(
                    "info",
                    message=f"No structured output from agent, validating file: {first_file.name}",
                )
            try:
                output_schema.model_validate_json(first_file.read_text())
            except Exception as e:
                schema_errors = [f"File validation: {str(e)}"]
        else:
            if emitter:
                emitter.emit("warn", message="No structured output and no files to validate")
            schema_errors = ["No structured output returned by agent"]

    return files_created, missing_files, schema_errors


def _get_structured_output(
    files_created: List[str],
    output_schema: Optional[Type[BaseModel]],
    raw_structured_output: Optional[Dict] = None,
) -> Optional[BaseModel]:
    """Parse structured output into a validated Pydantic model.

    Tries in order:
    1. raw_structured_output from agent result block (if available)
    2. First file in files_created

    Args:
        files_created: List of files created by agent
        output_schema: Pydantic model class to validate against
        raw_structured_output: Raw dict from agent result block (if present)

    Returns:
        Validated Pydantic model or None
    """
    if not output_schema:
        return None

    # Try raw_structured_output first (from agent result)
    if raw_structured_output:
        try:
            return output_schema.model_validate(raw_structured_output)
        except Exception as e:
            # Validation failed - fall through to file-based validation
            logger.debug(f"Raw structured output validation failed: {e}")

    # Fall back to file-based validation
    if not files_created:
        return None
    try:
        return output_schema.model_validate_json(Path(files_created[0]).read_text())
    except Exception as e:
        # File-based validation also failed - log and return None
        logger.debug(f"File-based structured output validation failed: {e}")
        return None


def _run_fixer_loop(
    runner: ClaudeSDKRunner,
    original_result: AgentResult,
    files_created: List[str],
    missing_files: List[str],
    schema_errors: List[str],
    required_files: List[str],
    working_directory: Path,
    output_schema: Optional[Type[BaseModel]],
    log_dir: Path,
    emitter: Any,
    fixer_prompt: Optional[str],
    max_attempts: int,
) -> AgentResult:
    """Run fixer queries on the same session to fix validation errors.

    Uses runner.query() to send follow-up prompts on the same session,
    avoiding the overhead of creating new sessions for each fixer attempt.
    """
    for attempt in range(max_attempts):
        # Log errors
        emitter.emit(
            "warn",
            message=f"Structured output validation failed, running fixer (attempt {attempt + 1}/{max_attempts})",
        )
        for f in missing_files:
            emitter.emit("warn", message=f"  Missing: {f}")
        for err in schema_errors:
            emitter.emit("warn", message=f"  {err}")

        # Build fixer prompt
        prompt = fixer_prompt or _build_default_fixer_prompt(
            missing_files=missing_files,
            schema_errors=schema_errors,
            files_created=files_created,
            output_schema=output_schema,
        )

        # Log fixer prompt
        fix_log_dir = log_dir / f"fixer-attempt-{attempt + 1}"
        fix_log_dir.mkdir(parents=True, exist_ok=True)
        (fix_log_dir / "fixer-prompt.md").write_text(prompt)

        # Pass output_schema to fixer when fixing structured output errors
        fixer_output_schema = output_schema if schema_errors and not files_created else None

        # Use runner.query() to send follow-up on the same session
        # This avoids creating a new session and preserves full context
        emitter.emit("agent_start", task="Fix validation errors", log_path=str(fix_log_dir))
        fix_result = runner.query(
            prompt=prompt,
            output_schema=fixer_output_schema,
            timeout_minutes=10,
            log_dir=fix_log_dir,
        )
        cost = fix_result.metrics.cost_usd if fix_result.metrics else 0
        emitter.emit(
            "agent_complete", task="Fix validation errors", success=fix_result.success, cost=cost
        )

        if not fix_result.success:
            emitter.emit("warn", message=f"Fixer failed: {fix_result.error}")
            continue

        # Re-validate - pass fixer's structured output if it produced one
        files_created, missing_files, schema_errors = _validate_output(
            required_files=required_files,
            working_directory=working_directory,
            output_schema=output_schema,
            raw_structured_output=fix_result.raw_structured_output,
            emitter=emitter,
        )

        if not missing_files and not schema_errors:
            emitter.emit("success", message="Structured output fixed by fixer")
            return AgentResult(
                success=True,
                output=original_result.output,
                files_created=files_created,
                files_modified=original_result.files_modified,
                structured_output=_get_structured_output(
                    files_created, output_schema, fix_result.raw_structured_output
                ),
                metrics=original_result.metrics,
                session_id=runner.session_id,
            )

    # All attempts failed
    error_parts = []
    if missing_files:
        error_parts.append(f"Missing files: {missing_files}")
    if schema_errors:
        error_parts.append(f"Schema errors: {schema_errors}")
    return AgentResult(
        success=False,
        output=original_result.output,
        files_created=files_created,
        error="; ".join(error_parts),
        metrics=original_result.metrics,
        session_id=runner.session_id,
    )


def _build_default_fixer_prompt(
    missing_files: List[str],
    schema_errors: List[str],
    files_created: List[str],
    output_schema: Optional[Type[BaseModel]],
) -> str:
    """Build default prompt for fixing validation errors."""
    parts = ["Fix the following validation errors:\n"]

    if missing_files:
        parts.append("MISSING FILES:")
        for f in missing_files:
            parts.append(f"  - {f}")
        parts.append("")

    if schema_errors and files_created:
        # Schema errors in existing file
        file_path = files_created[0]
        parts.append(f"SCHEMA ERRORS in {file_path}:")
        for err in schema_errors:
            parts.append(f"  - {err}")
        parts.append("")

        if output_schema:
            parts.append("EXPECTED SCHEMA:")
            parts.append(f"```json\n{json.dumps(transform_schema(output_schema), indent=2)}\n```")
            parts.append("")

        parts.append("Read the file(s), understand the errors, and fix them.")
        parts.append("Only fix what's necessary - preserve all valid data.")
    elif schema_errors and not files_created:
        # No structured output was produced - agent needs to provide it
        parts.append("NO STRUCTURED OUTPUT:")
        parts.append("The previous agent run did not produce valid structured output.")
        parts.append("")
        for err in schema_errors:
            parts.append(f"  - {err}")
        parts.append("")

        if output_schema:
            parts.append("You MUST provide structured output matching this schema:")
            parts.append(schema_to_doc(output_schema))
            parts.append("")

        parts.append("Review your previous work and provide the required structured output.")
    else:
        parts.append("Read the file(s), understand the errors, and fix them.")
        parts.append("Only fix what's necessary - preserve all valid data.")

    return "\n".join(parts)
