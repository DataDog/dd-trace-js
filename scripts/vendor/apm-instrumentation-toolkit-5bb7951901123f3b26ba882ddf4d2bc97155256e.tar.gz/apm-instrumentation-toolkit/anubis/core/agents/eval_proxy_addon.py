"""Mitmproxy addon for eval-mode header injection and protocol translation.

Loaded by mitmdump via ``-s eval_proxy_addon.py``. Runs in the mitmdump process,
not the main Python process — only stdlib + mitmproxy imports are available.

Configuration via environment variables (set by the manager before spawning):
  EVAL_PROXY_HEADERS        JSON dict of headers to inject into every request
  EVAL_PROXY_COST_FILE      Path where accumulated cost is written as JSON
  EVAL_PROXY_MODEL_PRICING  JSON dict of pricing for cost tracking (model-prefix → [in, out, cache]/M tokens)
  ANTHROPIC_MODEL           Non-Anthropic model override (e.g. bedrock/...)
  EVAL_PROXY_DEBUG          Set to "1" to enable verbose stderr logging
"""

import json
import os
import sys

from mitmproxy import http

# ---------------------------------------------------------------------------
# Configuration (read once at addon load time)
# ---------------------------------------------------------------------------

_DEBUG = os.environ.get("EVAL_PROXY_DEBUG", "") in ("1", "true")
_COST_FILE = os.environ.get("EVAL_PROXY_COST_FILE", "")
_OVERRIDE_MODEL = os.environ.get("ANTHROPIC_MODEL", "")

try:
    _HEADERS: dict = json.loads(os.environ.get("EVAL_PROXY_HEADERS", "{}"))
except (json.JSONDecodeError, ValueError) as e:
    print(
        f"[eval-proxy] WARN: failed to parse EVAL_PROXY_HEADERS, header injection disabled: {e}",
        flush=True,
        file=sys.stderr,
    )
    _HEADERS = {}

try:
    _raw = os.environ.get("EVAL_PROXY_MODEL_PRICING", "")
    _PRICING: dict = {k: tuple(v) for k, v in json.loads(_raw).items()} if _raw else {}
except (json.JSONDecodeError, ValueError, TypeError) as e:
    print(
        f"[eval-proxy] WARN: failed to parse EVAL_PROXY_MODEL_PRICING, cost tracking disabled: {e}",
        flush=True,
        file=sys.stderr,
    )
    _PRICING = {}


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def _log(msg: str) -> None:
    if _DEBUG:
        print(msg, flush=True, file=sys.stderr)


def _warn(msg: str) -> None:
    print(msg, flush=True, file=sys.stderr)


def _is_non_anthropic(model: str) -> bool:
    return "/" in model and not model.startswith("anthropic/")


def _finish_reason_to_stop_reason(reason: str) -> str:
    return {"tool_calls": "tool_use", "length": "max_tokens"}.get(reason, "end_turn")


def _extract_cost(usage: dict, model: str) -> float:
    """Return cost from usage dict; falls back to token-based calculation."""
    cost = float(usage.get("cost_usd") or usage.get("total_cost_usd") or usage.get("cost") or 0.0)
    if cost:
        return cost
    rate = _PRICING.get(model)
    if not rate:
        for key, r in _PRICING.items():
            if model.startswith(key):
                rate = r
                break
    if not rate:
        return 0.0
    details = usage.get("prompt_tokens_details") or {}
    cached = int(details.get("cached_tokens", 0))
    fresh = max(0, int(usage.get("prompt_tokens", 0)) - cached)
    output = int(usage.get("completion_tokens", 0))
    r0, r1, r2 = float(rate[0]), float(rate[1]), float(rate[2])
    return float(fresh * r0 + cached * r2 + output * r1) / 1_000_000


def _write_cost(cost: float, model: str) -> None:
    if not _COST_FILE or cost <= 0:
        return
    try:
        existing = 0.0
        try:
            with open(_COST_FILE) as f:
                existing = float(json.loads(f.read()).get("cost_usd", 0))
        except FileNotFoundError:
            _log("[eval-proxy] cost file not yet created, starting from 0")
        except Exception as e:
            _warn(f"[eval-proxy] cost file unreadable, starting from 0: {e}")
        with open(_COST_FILE, "w") as f:
            f.write(json.dumps({"cost_usd": existing + cost, "model": model}))
    except Exception as e:
        _warn(f"[eval-proxy] failed to write cost file: {e}")


# ---------------------------------------------------------------------------
# Request conversion: Anthropic /v1/messages → OpenAI /v1/chat/completions
# ---------------------------------------------------------------------------


def _convert_request(body: dict) -> dict:
    messages = []

    system = body.get("system")
    if isinstance(system, str) and system:
        messages.append({"role": "system", "content": system})
    elif isinstance(system, list):
        text = "\n".join(b.get("text", "") for b in system if b.get("type") == "text")
        if text:
            messages.append({"role": "system", "content": text})

    for msg in body.get("messages", []):
        role = msg["role"]
        content = msg.get("content", "")

        if isinstance(content, str):
            messages.append({"role": role, "content": content})
            continue

        if role == "user":
            tool_results = [b for b in content if b.get("type") == "tool_result"]
            text_blocks = [b for b in content if b.get("type") == "text"]
            dropped = [
                b.get("type") for b in content if b.get("type") not in ("text", "tool_result")
            ]
            if dropped:
                _log(f"[eval-proxy] dropping unsupported user content types: {dropped}")
            if tool_results:
                for tr in tool_results:
                    tc_content = tr.get("content", "")
                    if isinstance(tc_content, list):
                        tc_dropped = [b.get("type") for b in tc_content if b.get("type") != "text"]
                        if tc_dropped:
                            _log(
                                f"[eval-proxy] dropping unsupported tool_result content types: {tc_dropped}"
                            )
                        tc_content = "\n".join(
                            b.get("text", "") for b in tc_content if b.get("type") == "text"
                        )
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tr.get("tool_use_id", ""),
                        "content": str(tc_content),
                    })
                if text_blocks:
                    messages.append({
                        "role": "user",
                        "content": "\n".join(b.get("text", "") for b in text_blocks),
                    })
            else:
                messages.append({
                    "role": "user",
                    "content": "\n".join(b.get("text", "") for b in text_blocks),
                })

        elif role == "assistant":
            text_parts, tool_calls = [], []
            for b in content:
                if b.get("type") == "text":
                    text_parts.append(b.get("text", ""))
                elif b.get("type") == "tool_use":
                    name = b.get("name") or "_proxy_unknown"
                    tool_calls.append({
                        "id": b.get("id", ""),
                        "type": "function",
                        "function": {
                            "name": name,
                            "arguments": json.dumps(b.get("input", {})),
                        },
                    })
            m: dict = {"role": "assistant", "content": "\n".join(text_parts) or None}
            if tool_calls:
                m["tool_calls"] = tool_calls
            messages.append(m)

    out: dict = {
        "model": body.get("model"),
        "messages": messages,
        "stream": body.get("stream", False),
    }
    if body.get("temperature") is not None:
        out["temperature"] = body["temperature"]
    if body.get("tools"):
        out["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": t.get("name"),
                    "description": t.get("description", ""),
                    "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
                },
            }
            for t in body["tools"]
        ]
    tc = body.get("tool_choice")
    if tc:
        tc_type = tc.get("type", "auto")
        if tc_type == "any":
            out["tool_choice"] = "required"
        elif tc_type == "tool":
            out["tool_choice"] = {"type": "function", "function": {"name": tc.get("name")}}
        else:
            out["tool_choice"] = "auto"
    return out


# ---------------------------------------------------------------------------
# Response conversion: OpenAI /v1/chat/completions → Anthropic /v1/messages
# ---------------------------------------------------------------------------


def _convert_json_response(resp: dict, model: str) -> str:
    choice = (resp.get("choices") or [{}])[0]
    message = choice.get("message", {})
    content = []
    if text := message.get("content") or "":
        content.append({"type": "text", "text": text})
    for tc in message.get("tool_calls") or []:
        try:
            args = json.loads(tc["function"].get("arguments") or "{}")
        except Exception as e:
            _warn(f"[eval-proxy] failed to parse tool call args: {e}")
            args = {}
        name = (tc.get("function") or {}).get("name") or "_proxy_unknown"
        content.append({
            "type": "tool_use",
            "id": tc.get("id", ""),
            "name": name,
            "input": args,
        })
    usage = resp.get("usage", {})
    return json.dumps({
        "id": resp.get("id", "msg_converted"),
        "type": "message",
        "role": "assistant",
        "content": content,
        "model": model,
        "stop_reason": _finish_reason_to_stop_reason(choice.get("finish_reason") or "stop"),
        "stop_sequence": None,
        "usage": {
            "input_tokens": usage.get("prompt_tokens", 0),
            "output_tokens": usage.get("completion_tokens", 0),
        },
    })


def _convert_stream_response(raw_sse: str, model: str) -> str:
    chunks = []
    for line in raw_sse.splitlines():
        line = line.strip()
        if line.startswith("data:") and line[5:].strip() not in ("[DONE]", ""):
            try:
                chunks.append(json.loads(line[5:].strip()))
            except Exception as e:
                _warn(f"[eval-proxy] failed to parse SSE chunk: {e}")

    text_parts: list = []
    tool_calls: dict = {}
    finish_reason, usage, msg_id = "stop", {}, "msg_converted"
    for chunk in chunks:
        if chunk.get("id"):
            msg_id = chunk["id"]
        if u := chunk.get("usage"):
            usage = u
        for choice in chunk.get("choices", []):
            delta = choice.get("delta", {})
            if fr := choice.get("finish_reason"):
                finish_reason = fr
            if delta.get("content"):
                text_parts.append(delta["content"])
            for tc in delta.get("tool_calls") or []:
                idx = tc.get("index", 0)
                if idx not in tool_calls:
                    tool_calls[idx] = {"id": "", "name": "", "args": []}
                if tc.get("id"):
                    tool_calls[idx]["id"] = tc["id"]
                fn = tc.get("function", {})
                if fn.get("name"):
                    tool_calls[idx]["name"] = fn["name"]
                if fn.get("arguments"):
                    tool_calls[idx]["args"].append(fn["arguments"])

    full_text = "".join(text_parts)
    stop_reason = _finish_reason_to_stop_reason(finish_reason)
    input_tokens = usage.get("prompt_tokens", 0)
    output_tokens = usage.get("completion_tokens", 0)

    def evt(name: str, data: dict) -> str:
        return f"event: {name}\ndata: {json.dumps(data)}\n\n"

    block_index = 0
    events = [
        evt(
            "message_start",
            {
                "type": "message_start",
                "message": {
                    "id": msg_id,
                    "type": "message",
                    "role": "assistant",
                    "content": [],
                    "model": model,
                    "stop_reason": None,
                    "usage": {"input_tokens": input_tokens, "output_tokens": 1},
                },
            },
        )
    ]

    if full_text:
        events += [
            evt(
                "content_block_start",
                {
                    "type": "content_block_start",
                    "index": block_index,
                    "content_block": {"type": "text", "text": ""},
                },
            ),
            evt(
                "content_block_delta",
                {
                    "type": "content_block_delta",
                    "index": block_index,
                    "delta": {"type": "text_delta", "text": full_text},
                },
            ),
            evt("content_block_stop", {"type": "content_block_stop", "index": block_index}),
        ]
        block_index += 1

    for idx in sorted(tool_calls):
        tc = tool_calls[idx]
        name = tc["name"] or "_proxy_unknown"
        try:
            args = json.loads("".join(tc["args"]) or "{}")
        except Exception as e:
            _warn(f"[eval-proxy] failed to parse tool call args: {e}")
            args = {}
        events += [
            evt(
                "content_block_start",
                {
                    "type": "content_block_start",
                    "index": block_index,
                    "content_block": {
                        "type": "tool_use",
                        "id": tc["id"],
                        "name": name,
                        "input": {},
                    },
                },
            ),
            evt(
                "content_block_delta",
                {
                    "type": "content_block_delta",
                    "index": block_index,
                    "delta": {"type": "input_json_delta", "partial_json": json.dumps(args)},
                },
            ),
            evt("content_block_stop", {"type": "content_block_stop", "index": block_index}),
        ]
        block_index += 1

    events += [
        evt(
            "message_delta",
            {
                "type": "message_delta",
                "delta": {"stop_reason": stop_reason, "stop_sequence": None},
                "usage": {"output_tokens": output_tokens},
            },
        ),
        evt("message_stop", {"type": "message_stop"}),
    ]
    return "".join(events)


# ---------------------------------------------------------------------------
# mitmproxy addon
# ---------------------------------------------------------------------------


class EvalProxyAddon:
    def request(self, flow: http.HTTPFlow) -> None:
        host = flow.request.pretty_host
        if "ai-gateway" not in host and "anthropic.com" not in host:
            return
        for k, v in _HEADERS.items():
            flow.request.headers[k] = v

        ct = flow.request.headers.get("content-type", "")
        if "json" not in ct:
            _log(f"[eval-proxy] REQ {flow.request.path} (non-json, skipping)")
            return
        if not flow.request.content:
            _log(f"[eval-proxy] REQ {flow.request.path} (empty body, skipping)")
            return

        try:
            body = json.loads(flow.request.content)
            original_model = body.get("model", "")

            if _is_non_anthropic(_OVERRIDE_MODEL):
                body["model"] = _OVERRIDE_MODEL
                flow.request.content = json.dumps(body).encode()

            model = body.get("model", "<no model field>")
            _log(f"[eval-proxy] REQ {flow.request.path} model={model}")

            # count_tokens: let it pass without a provider header. The gateway routes
            # /v1/messages on the provider header, but has no compliance rule for
            # count_tokens under an explicit provider — it worked before we added the
            # provider header. Auth headers (_HEADERS) are already injected above.
            if "count_tokens" in flow.request.path:
                _log(f"[eval-proxy] count_tokens passthrough (no provider header)")
                return

            # Always set provider header — AI Gateway routes on this, not the model
            # prefix. Without it the gateway defaults to OpenAI. Unqualified model
            # names (no "/") are assumed to be Anthropic.
            provider = str(model).split("/")[0] if "/" in str(model) else "anthropic"
            flow.request.headers["provider"] = provider

            if "messages" in flow.request.path and _is_non_anthropic(str(model)):
                converted = _convert_request(body)
                flow.request.path = "/v1/chat/completions"
                flow.request.content = json.dumps(converted).encode()
                to_strip = [k for k in flow.request.headers if "anthropic" in k.lower()]
                for k in ("claude-code", "user-agent", "provider"):
                    if k in flow.request.headers:
                        to_strip.append(k)
                for k in to_strip:
                    del flow.request.headers[k]
                flow.request.headers["provider"] = str(model).split("/")[0]
                flow.metadata["convert_response"] = str(model)
                flow.metadata["original_model"] = original_model
                _log(
                    f"[eval-proxy] rewritten /v1/messages → /v1/chat/completions "
                    f"model={model} masked_as={original_model}"
                )
        except Exception as e:
            _warn(
                f"[eval-proxy] REQ error (model override/header injection may not have applied): {e}"
            )

    def response(self, flow: http.HTTPFlow) -> None:
        host = flow.request.pretty_host
        if "ai-gateway" not in host and "anthropic.com" not in host:
            return
        if flow.response is None:
            return

        status = flow.response.status_code
        model = flow.metadata.get("convert_response", "")

        if model:
            if status >= 400:
                try:
                    err_body = (flow.response.text or "")[:500]
                except Exception:
                    err_body = ""
                _warn(f"[eval-proxy] model error status={status} model={model} body={err_body}")
                # Rewrite the error as Anthropic format so the Claude SDK surfaces a readable
                # message instead of failing silently on an unconverted OpenAI error body.
                anthropic_error = json.dumps({
                    "type": "error",
                    "error": {
                        "type": "invalid_request_error",
                        "message": f"Model '{model}' returned error {status} from AI Gateway: {err_body}",
                    },
                })
                flow.response.headers["content-type"] = "application/json"
                flow.response.text = anthropic_error
                return

            response_model = flow.metadata.get("original_model") or model
            try:
                ct = flow.response.headers.get("content-type", "")
                is_stream = "event-stream" in ct
                raw: str = flow.response.text or ""
                _log(f"[eval-proxy] RES raw ({'stream' if is_stream else 'json'}): {raw[:800]}")

                if is_stream:
                    last_usage: dict = {}
                    for line in raw.splitlines():
                        line = line.strip()
                        if line.startswith("data:") and line[5:].strip() not in ("[DONE]", ""):
                            try:
                                chunk = json.loads(line[5:].strip())
                                if u := chunk.get("usage"):
                                    last_usage = u
                            except Exception as e:
                                _warn(f"[eval-proxy] failed to parse stream chunk: {e}")
                    cost = _extract_cost(last_usage, model) if last_usage else 0.0
                    _write_cost(cost, model)
                    converted = _convert_stream_response(raw, response_model)
                    flow.response.headers["content-type"] = "text/event-stream; charset=utf-8"
                else:
                    openai_resp = json.loads(raw)
                    usage = openai_resp.get("usage", {}) or {}
                    cost = _extract_cost(usage, model)
                    _write_cost(cost, model)
                    converted = _convert_json_response(openai_resp, response_model)
                    flow.response.headers["content-type"] = "application/json"

                flow.response.text = converted
                _log(f"[eval-proxy] converted OpenAI→Anthropic stream={is_stream} status={status}")
            except Exception as e:
                _warn(
                    f"[eval-proxy] RES conversion error (SDK received unconverted OpenAI response): {e}"
                )
            return

        # Normal Anthropic response — always surface errors, log model in debug mode
        try:
            ct = flow.response.headers.get("content-type", "")
            if (
                status >= 400
                and "messages" in flow.request.path
                and "count_tokens" not in flow.request.path
            ):
                err_body = (flow.response.text or "")[:500]
                _warn(
                    f"[eval-proxy] anthropic error path={flow.request.path} status={status} body={err_body}"
                )
            elif status >= 400:
                _log(f"[eval-proxy] non-message 4xx path={flow.request.path} status={status}")
            elif "event-stream" in ct:
                for line in (flow.response.text or "").splitlines():
                    if line.startswith("data:") and "model" in line:
                        chunk = json.loads(line[5:].strip())
                        _log(
                            f"[eval-proxy] RES {flow.request.path} "
                            f"status={status} model={chunk.get('model', '?')}"
                        )
                        break
            else:
                body = json.loads(flow.response.content or b"")
                _log(
                    f"[eval-proxy] RES {flow.request.path} "
                    f"status={status} model={body.get('model', '?')}"
                )
        except Exception as e:
            _log(f"[eval-proxy] RES log error: {e}")


addons = [EvalProxyAddon()]
