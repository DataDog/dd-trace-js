"""Agent models - provider-agnostic results and metrics.

These models are designed to work with multiple AI providers:
- Claude CLI (current)
- Claude Agent SDK (planned)
- OpenAI (potential)
- Other providers

Keep fields generic - avoid provider-specific terminology.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AgentMetrics(BaseModel):
    """Metrics from an agent run (provider-agnostic)."""

    cost_usd: float = 0.0
    duration_seconds: float = 0.0
    num_turns: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    is_error: bool = False
    error_subtype: Optional[str] = None  # e.g., 'max_turns', 'timeout', 'rate_limit'
    # Provider info
    provider: Optional[str] = None  # 'claude_cli', 'claude_sdk', 'openai', etc.
    model: Optional[str] = None  # 'claude-sonnet-4', 'gpt-4', etc.

    # Sonnet pricing via AI Gateway ($/M tokens): input, output, cache_read
    _SONNET_PRICING = (3.0, 15.0, 0.30)

    def estimate_cost_from_tokens(self) -> None:
        """Estimate cost_usd from token counts when the SDK result is unavailable.

        On timeout/interrupt the SDK never sends a ResultMessage with
        total_cost_usd, so cost_usd stays 0. This estimates from accumulated
        per-turn token counts using Sonnet pricing (the most common model).
        Only fills in cost_usd if it's still 0 and we have token data.
        """
        if self.cost_usd > 0:
            return
        if not (self.input_tokens or self.output_tokens):
            return
        inp, out, cache = self._SONNET_PRICING
        self.cost_usd = (
            self.input_tokens * inp / 1_000_000
            + self.output_tokens * out / 1_000_000
            + self.cache_read_input_tokens * cache / 1_000_000
        )


class AgentResult(BaseModel):
    """Result of an agent run (provider-agnostic)."""

    success: bool
    output: Optional[str] = None  # Final text output
    error: Optional[str] = None
    # File operations
    files_created: List[str] = Field(default_factory=list)
    files_modified: List[str] = Field(default_factory=list)
    # Structured output (for schema-constrained responses)
    structured_output: Optional[Any] = None  # Validated Pydantic model
    raw_structured_output: Optional[Dict[str, Any]] = None  # Raw dict before validation
    # Metrics
    metrics: AgentMetrics = Field(default_factory=AgentMetrics)
    # Session management (for conversation resumption)
    session_id: Optional[str] = None
