"""MockAgentRunner — no-LLM runner for CI smoke tests.

Activated when DD_APM_MOCK_AGENTS=1 is set. The runner returns a synthesized
successful AgentResult with an instance of the step's output_schema, so the
rest of the workflow (validators, hooks, step-to-step context wiring, file
persistence, downstream adapter invocations) still exercises real code paths.

This is intended for catching packaging / wiring bugs — missing bundled
resources, wrong path resolution, broken hook discovery, schema mismatches.
It is NOT intended for catching prompt quality or tool-use bugs; those need
a real LLM and are covered by integration evals.

Output synthesis priority:
    1. ``<DD_APM_MOCK_FIXTURES_DIR>/<schema_name>.json`` — explicit fixture.
       Use this for schemas with required fields whose structural content
       downstream code depends on (e.g. AgentAnalysis.analysis.summary).
    2. ``output_schema()`` — validating constructor. Succeeds when every
       field has a default (or is Optional). The common case.
    3. Type-inferred defaults — builds a dict with minimal valid values for
       every required field (str->"", int->0, bool->False, list->[], etc.)
       then validates. Covers schemas with required primitive fields.
    4. ``output_schema.model_construct()`` — last resort, bypasses validation.
       Fields that cannot be inferred will be PydanticUndefined. Add a
       fixture (step 1) if downstream code needs structural content from them.
"""

import enum
import json
import logging
import os
import typing
from pathlib import Path
from typing import Any, Dict, Optional, Type

from pydantic import BaseModel

from ..models import AgentMetrics, AgentResult
from .base import AgentRunner, EventEmitter

logger = logging.getLogger(__name__)

_MOCK_OUTPUT_TEXT = "<mocked agent output — DD_APM_MOCK_AGENTS=1>"
_FIXTURES_DIR_ENV = "DD_APM_MOCK_FIXTURES_DIR"


class MockAgentRunner(AgentRunner):
    """Agent runner that skips the LLM round-trip and synthesizes output.

    Use via ``DD_APM_MOCK_AGENTS=1``. See module docstring for the synthesis
    contract.
    """

    @property
    def provider_name(self) -> str:
        return "mock"

    def run(
        self,
        prompt: str,
        working_directory: Path,
        model: str = "sonnet",
        max_turns: int = 100,
        timeout_minutes: int = 30,
        output_schema: Optional[Type[BaseModel]] = None,
        emitter: Optional[EventEmitter] = None,
        log_dir: Optional[Path] = None,
        resume_session_id: Optional[str] = None,
    ) -> AgentResult:
        if emitter is not None:
            schema_name = output_schema.__name__ if output_schema else "None"
            emitter.emit(
                "info",
                message=f"MockAgentRunner: synthesizing output, skipping LLM (schema={schema_name})",
            )

        structured, raw = _synthesize_output(output_schema)

        if emitter is not None:
            emitter.emit("agent_complete", task="mocked", success=True, cost=0.0)
            emitter.emit("section", name="Agent completed (mocked)")

        return AgentResult(
            success=True,
            output=_MOCK_OUTPUT_TEXT,
            structured_output=structured,
            raw_structured_output=raw,
            metrics=AgentMetrics(provider=self.provider_name, model=model),
        )

    def get_config(self) -> Dict[str, Any]:
        return {"provider": self.provider_name, "note": "DD_APM_MOCK_AGENTS=1"}


def _load_fixture(output_schema: Type[BaseModel]) -> Optional[Dict[str, Any]]:
    """Look for a fixture JSON for this schema in DD_APM_MOCK_FIXTURES_DIR.

    Fixture filename is ``<schema_name>.json``. Returns the parsed JSON dict
    if found, else None.
    """
    fixtures_dir = os.environ.get(_FIXTURES_DIR_ENV)
    if not fixtures_dir:
        return None
    fixture_path = Path(fixtures_dir) / f"{output_schema.__name__}.json"
    if not fixture_path.exists():
        return None
    try:
        data: Dict[str, Any] = json.loads(fixture_path.read_text())
        return data
    except (OSError, json.JSONDecodeError) as e:
        logger.warning("MockAgentRunner: failed reading fixture %s: %s", fixture_path, e)
        return None


def _default_for_annotation(annotation: Any, depth: int = 0) -> Any:
    """Return a minimal valid value for a type annotation.

    Handles primitives, common generics (list, dict), Optional/Union,
    enums, and nested Pydantic models (capped at depth 5 to avoid cycles).
    """
    if annotation is None or annotation is type(None):
        return None

    origin = getattr(annotation, "__origin__", None)

    # Optional[X] / Union[X, None] — None satisfies the None branch
    if origin is typing.Union:
        args = getattr(annotation, "__args__", ())
        if type(None) in args:
            return None
        return _default_for_annotation(args[0], depth) if args else None

    if origin is list:
        return []
    if origin is dict:
        return {}
    if origin is tuple:
        return ()

    if annotation is str:
        return ""
    if annotation is int:
        return 0
    if annotation is float:
        return 0.0
    if annotation is bool:
        return False
    if annotation is bytes:
        return b""

    if isinstance(annotation, type):
        if issubclass(annotation, BaseModel) and depth < 5:
            return _build_defaults_dict(annotation, depth + 1)
        if issubclass(annotation, enum.Enum):
            members = list(annotation)
            return members[0].value if members else None

    return None


def _build_defaults_dict(schema: Type[BaseModel], depth: int = 0) -> Dict[str, Any]:
    """Build a dict with type-inferred defaults for every required field."""
    defaults: Dict[str, Any] = {}
    for name, field_info in schema.model_fields.items():
        if not field_info.is_required():
            continue
        defaults[name] = _default_for_annotation(field_info.annotation, depth)
    return defaults


def _synthesize_output(
    output_schema: Optional[Type[BaseModel]],
) -> tuple[Optional[BaseModel], Dict[str, Any]]:
    """Build a mock instance of output_schema.

    Priority: fixture -> validating constructor -> type-inferred defaults -> model_construct.
    See module docstring for the contract.
    """
    if output_schema is None:
        return None, {}

    # Priority 1: explicit fixture file for this schema.
    fixture = _load_fixture(output_schema)
    if fixture is not None:
        try:
            instance = output_schema.model_validate(fixture)
            return instance, instance.model_dump()
        except Exception as e:
            logger.warning(
                "MockAgentRunner: fixture for %s failed validation, falling back: %s",
                output_schema.__name__,
                e,
            )

    # Priority 2: validating constructor (works when every field has a default).
    try:
        instance = output_schema()
        return instance, instance.model_dump()
    except Exception as e:
        logger.debug(
            "MockAgentRunner: %s() failed (%s); trying type-inferred defaults",
            output_schema.__name__,
            e,
        )

    # Priority 3: synthesize minimal valid values for required fields, then validate.
    try:
        defaults = _build_defaults_dict(output_schema)
        instance = output_schema.model_validate(defaults)
        return instance, instance.model_dump()
    except Exception as e:
        logger.debug(
            "MockAgentRunner: type-inferred defaults for %s failed (%s); using model_construct",
            output_schema.__name__,
            e,
        )

    # Priority 4: model_construct() last resort. Fields that cannot be inferred
    # will be PydanticUndefined — add a fixture if downstream needs them.
    try:
        instance = output_schema.model_construct()
        return instance, instance.model_dump()
    except Exception as e:
        logger.warning("MockAgentRunner: could not synthesize %s: %s", output_schema.__name__, e)
        return None, {}
