"""Security configuration for Claude Agent SDK.

This module provides:
1. SDK-level permission rules (DEFAULT_DENY_RULES) - used by runner settings
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    PreToolUseHookInput,
    SyncHookJSONOutput,
)

# =============================================================================
# SDK Permission Rules
# These are used by ClaudeAgentOptions settings for SDK-level enforcement
# =============================================================================

# Default deny rules for security
# These block dangerous bash commands only. File access is controlled by
# allowed_paths and the sandbox excludedCommands setting.
DEFAULT_DENY_RULES = [
    # Block dangerous bash commands that can delete/modify files
    "Bash(rm:*)",
    "Bash(rm -rf:*)",
    "Bash(rm -r:*)",
    "Bash(rmdir:*)",
    "Bash(unlink:*)",
    "Bash(shred:*)",
    "Bash(chmod:*)",
    "Bash(chown:*)",
    "Bash(mv:*)",  # Can overwrite files
    "Bash(dd:*)",  # Disk operations
    "Bash(mkfs:*)",  # Filesystem creation
    "Bash(fdisk:*)",  # Disk partitioning
    "Bash(kill:*)",  # Process killing
    "Bash(killall:*)",
    "Bash(pkill:*)",
    "Bash(sudo:*)",  # Privilege escalation
    "Bash(su:*)",
    # Block test runners - use yarn test:plugin instead
    "Bash(mocha:*)",
    "Bash(./node_modules/.bin/mocha:*)",
    "Bash(npx mocha:*)",
    "Bash(yarn mocha:*)",
    "Bash(node_modules/.bin/mocha:*)",
]


def build_path_allow_rules(path: Path) -> List[str]:
    """Build allow rules for a specific path."""
    resolved = str(path.resolve())
    return [
        f"Read({resolved}/**)",
        f"Write({resolved}/**)",
        f"Edit({resolved}/**)",
        f"Glob({resolved}/**)",
        f"Bash({resolved}/**)",
    ]


def build_pre_tool_use_hook(allowed_paths: List[Path]) -> HookCallback:
    """Build a PreToolUse hook that allows access to specific paths.

    This hook runs BEFORE deny rules are evaluated, allowing it to override
    blanket deny rules like 'Read(/Users/**)' for specific allowed directories.

    Args:
        allowed_paths: List of paths that should be allowed access.

    Returns:
        HookCallback compatible with Claude Agent SDK HookMatcher.
    """
    # Resolve all paths to absolute paths for consistent matching
    resolved_paths = [str(p.resolve()) for p in allowed_paths]

    async def pre_tool_use_hook(
        input_data: HookInput,
        tool_use_id: Optional[str],
        context: HookContext,
    ) -> HookJSONOutput:
        """PreToolUse hook that allows access to specific paths before deny rules."""
        if input_data.get("hook_event_name") != "PreToolUse":
            return SyncHookJSONOutput()

        data = cast(PreToolUseHookInput, input_data)
        tool_name = data["tool_name"]
        tool_input = data["tool_input"]

        # Extract the path from the tool input based on tool type
        path_to_check = None

        if tool_name in ("Read", "Write", "Edit"):
            path_to_check = tool_input.get("file_path", "")
        elif tool_name == "Glob":
            path_to_check = tool_input.get("path", "")
        elif tool_name == "Bash":
            # For Bash, check if the command references any allowed path
            command = tool_input.get("command", "")
            for allowed_path in resolved_paths:
                if allowed_path in command:
                    return SyncHookJSONOutput(
                        hookSpecificOutput={
                            "hookEventName": "PreToolUse",
                            "permissionDecision": "allow",
                            "permissionDecisionReason": f"Command references allowed path: {allowed_path}",
                        }
                    )
            return SyncHookJSONOutput()

        # Check if the path is within any allowed directory
        if path_to_check:
            for allowed_path in resolved_paths:
                if path_to_check.startswith(allowed_path):
                    return SyncHookJSONOutput(
                        hookSpecificOutput={
                            "hookEventName": "PreToolUse",
                            "permissionDecision": "allow",
                            "permissionDecisionReason": f"Path is within allowed directory: {allowed_path}",
                        }
                    )

        # Return empty to continue to deny rules
        return SyncHookJSONOutput()

    return pre_tool_use_hook


def build_permission_settings(
    working_directory: Path,
    allowed_paths: Optional[List[Path]] = None,
    use_default_security: bool = True,
    custom_allow: Optional[List[str]] = None,
    custom_deny: Optional[List[str]] = None,
) -> Optional[Dict[str, Any]]:
    """Build settings dict with permission rules for ClaudeAgentOptions.

    See https://code.claude.com/docs/en/settings#permission-settings

    Args:
        working_directory: The working directory to allow access to.
        allowed_paths: Additional paths to allow access to (e.g., repo root).
        use_default_security: If True, applies DEFAULT_DENY_RULES.
        custom_allow: Additional allow rules.
        custom_deny: Additional deny rules.

    Returns:
        Settings dict with 'permissions' key, or None if no rules configured.
    """
    deny_rules: List[str] = []
    allow_rules: List[str] = []

    if use_default_security:
        deny_rules.extend(DEFAULT_DENY_RULES)

        # Allow access to the working directory (overrides deny rules)
        allow_rules.extend(build_path_allow_rules(working_directory))

        # Allow access to additional paths (e.g., repo root)
        for path in allowed_paths or []:
            allow_rules.extend(build_path_allow_rules(path))

        # Allow all bash commands globally - deny rules block dangerous ones
        # This enables complex operations like heredocs, pipes, etc.
        allow_rules.append("Bash")

        # Allow skill execution - skills are loaded from .claude/skills/ in working dir
        allow_rules.append("Skill")

    # Add custom rules
    if custom_deny:
        deny_rules.extend(custom_deny)
    if custom_allow:
        allow_rules.extend(custom_allow)

    if not allow_rules and not deny_rules:
        return None

    permissions: Dict[str, List[str]] = {}
    if allow_rules:
        permissions["allow"] = allow_rules
    if deny_rules:
        permissions["deny"] = deny_rules

    return {"permissions": permissions}
