"""PreToolUse hook for signal file injection.

External processes write <working_dir>/signal.md to send guidance to a running
agent. The hook checks for the file before each tool call. If found, it denies
the call with the signal content as the reason and deletes the file. The agent
must re-attempt the same tool to continue, ensuring the signal is processed.

This gives the supervising drive-toolkit agent a deterministic injection channel:
no kill-and-relaunch required for mid-run guidance.
"""

import logging
from pathlib import Path
from typing import Optional

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    SyncHookJSONOutput,
)

from anubis.core.tracing import LLMObs, is_llmobs_enabled

logger = logging.getLogger(__name__)

_SIGNAL_FILENAME = "signal.md"


def _trace_signal(content: str, signal_path: Path) -> None:
    """Create an LLMObs span for a signal injection.

    The span is a child of the currently active agent span, making signal
    injections visible in the trace waterfall alongside tool calls.
    """
    if not is_llmobs_enabled():
        return
    try:
        with LLMObs.tool(name="agent.signal_injection") as span:
            span.set_tag("signal.source", str(signal_path))
            span.set_tag("signal.length", str(len(content)))
            LLMObs.annotate(
                input_data=str(signal_path),
                output_data=content[:2000],
            )
    except Exception as e:
        logger.debug("Failed to create signal injection span: %s", e)


def build_signal_hook(signal_dirs: list[Path]) -> HookCallback:
    """Build a PreToolUse hook that injects signal file content.

    Checks `signal.md` in each of `signal_dirs` before every tool call,
    stopping at the first one found. If found, denies the current tool call
    with the file's content as the reason and deletes the file. The agent
    must re-attempt the denied call to proceed, ensuring the signal is read
    before execution continues.

    Multiple directories are checked so the hook fires correctly regardless
    of whether the step runs from the repo root (use_repo_root=True) or the
    analysis directory. Both paths are watched; whichever has signal.md wins.

    The deny-then-allow pattern is intentional: it forces a read of the
    guidance before any tool executes. On the re-attempt the file is gone,
    so the hook allows through normally.

    Args:
        signal_dirs: Directories to watch for signal.md, checked in order.
            Typically [root_path, working_dir] where root_path is the
            analysis dir (.analysis/<pkg>/<workflow>/) and working_dir is
            the agent CWD (may equal root_path, or repo root for repo-root steps).

    Returns:
        HookCallback compatible with Claude Agent SDK HookMatcher.
    """
    signal_files = [d / _SIGNAL_FILENAME for d in signal_dirs]

    async def signal_hook(
        input_data: HookInput,
        _tool_use_id: Optional[str],
        _context: HookContext,
    ) -> HookJSONOutput:
        if input_data.get("hook_event_name") != "PreToolUse":
            return SyncHookJSONOutput()

        active = next((f for f in signal_files if f.exists()), None)
        if active is None:
            return SyncHookJSONOutput()

        try:
            content = active.read_text().strip()
            active.unlink()
        except OSError:
            return SyncHookJSONOutput()

        if not content:
            return SyncHookJSONOutput()

        _trace_signal(content, active)

        message = (
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║  SIGNAL FROM SUPERVISOR                                      ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
            "\n"
            f"{content}\n"
            "\n"
            "══════════════════════════════════════════════════════════════\n"
            "Acknowledge this signal, incorporate it into your plan, then\n"
            "re-run the command you were about to execute to continue.\n"
            "══════════════════════════════════════════════════════════════"
        )

        return SyncHookJSONOutput(
            hookSpecificOutput={
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": message,
            }
        )

    return signal_hook
