"""Message handling for Claude Agent SDK.

This module processes SDK messages and converts them to common trace format.
"""

from typing import Any, Dict, List, Optional, Tuple

from ...models import AgentMetrics
from ..utils import AgentLogger


class MessageHandler:
    """Handles processing of SDK messages during agent execution.

    Extracts session info, structured output, file modifications, and metrics
    from SDK message stream.
    """

    def __init__(self, logger: Optional[AgentLogger] = None):
        self._logger = logger

        # State tracking
        self.session_id: Optional[str] = None
        self.files_modified: List[str] = []
        self.final_output: Optional[str] = None
        self.raw_structured_output: Optional[Dict[str, Any]] = None
        self._structured_output_captured = False

    def process(self, message: Any, metrics: AgentMetrics) -> None:
        """Process a single message from the SDK.

        Args:
            message: SDK message object
            metrics: AgentMetrics to update with final results
        """
        # Convert to trace format and log
        trace_msg, extracted_output = self._to_trace_format(message)
        if trace_msg and self._logger:
            self._logger.log_message(trace_msg)

        # Capture structured output.
        # Result message structured_output always wins (it's the SDK's final validated
        # output, which may have been corrected by PreToolUse hooks or retries).
        # For tool_input captures, take the first one as a fallback.
        msg_type_name = type(message).__name__
        is_result = "Result" in msg_type_name and hasattr(message, "duration_ms")
        if extracted_output is not None:
            if is_result or not self._structured_output_captured:
                self.raw_structured_output = extracted_output
                self._structured_output_captured = True

        # Extract session ID
        if hasattr(message, "session_id") and message.session_id:
            self.session_id = message.session_id

        # Extract text and file modifications from assistant messages
        if hasattr(message, "content"):
            for block in message.content:
                if hasattr(block, "text"):
                    self.final_output = block.text
                elif hasattr(block, "name"):
                    self._process_tool_block(block)

        # Accumulate per-turn usage from AssistantMessages so metrics are
        # available even on timeout (when the ResultMessage never arrives).
        if "Assistant" in msg_type_name and hasattr(message, "content"):
            metrics.num_turns += 1
            usage = getattr(message, "usage", None) or {}
            metrics.input_tokens += usage.get("input_tokens", 0) or 0
            metrics.output_tokens += usage.get("output_tokens", 0) or 0
            metrics.cache_read_input_tokens += usage.get("cache_read_input_tokens", 0) or 0

        # Extract final metrics from result message — authoritative totals
        # that replace the incrementally accumulated values above.
        if hasattr(message, "duration_ms"):
            metrics.duration_seconds = message.duration_ms / 1000.0
            metrics.num_turns = getattr(message, "num_turns", 0)
            metrics.cost_usd = getattr(message, "total_cost_usd", 0.0) or 0.0
            metrics.is_error = getattr(message, "is_error", False)
            usage = getattr(message, "usage", None) or {}
            metrics.input_tokens = usage.get("input_tokens", 0) or 0
            metrics.output_tokens = usage.get("output_tokens", 0) or 0
            metrics.cache_read_input_tokens = usage.get("cache_read_input_tokens", 0) or 0

    def reset(self) -> None:
        """Reset state for a new query (keeps session_id)."""
        self.files_modified = []
        self.final_output = None
        self.raw_structured_output = None
        self._structured_output_captured = False

    def _process_tool_block(self, block: Any) -> None:
        """Process a tool use block and track file modifications.

        Args:
            block: Tool use block from SDK message
        """
        # Track file modifications from Write/Edit tools
        if block.name not in ("Write", "Edit"):
            return

        file_path = getattr(block, "input", {}).get("file_path", "")
        if file_path and file_path not in self.files_modified:
            self.files_modified.append(file_path)

    def _to_trace_format(
        self, message: Any
    ) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
        """Convert SDK message to common trace format.

        Returns:
            Tuple of (trace_dict, structured_output_if_found)
        """
        msg_type_name = type(message).__name__
        structured_output = None

        # Result message (final message with metrics)
        if "Result" in msg_type_name and hasattr(message, "duration_ms"):
            if hasattr(message, "structured_output") and message.structured_output:
                structured_output = message.structured_output
            return {
                "type": "result",
                "duration_ms": message.duration_ms,
                "num_turns": getattr(message, "num_turns", 0),
                "total_cost_usd": getattr(message, "total_cost_usd", 0.0),
                "is_error": getattr(message, "is_error", False),
                "subtype": getattr(message, "subtype", None),
                "structured_output": structured_output,
            }, structured_output

        # Assistant message (with content blocks)
        if "Assistant" in msg_type_name and hasattr(message, "content"):
            content_blocks = []
            for block in message.content:
                if hasattr(block, "text"):
                    content_blocks.append({
                        "type": "text",
                        "text": block.text,
                    })
                elif hasattr(block, "name"):
                    tool_input = getattr(block, "input", {})
                    tool_block: dict[str, Any] = {
                        "type": "tool_use",
                        "name": block.name,
                        "input": tool_input,
                    }
                    tool_id = getattr(block, "id", None)
                    if tool_id:
                        tool_block["id"] = tool_id
                    content_blocks.append(tool_block)
                    if block.name == "StructuredOutput":
                        structured_output = tool_input
            if content_blocks:
                return {
                    "type": "assistant",
                    "message": {"content": content_blocks},
                }, structured_output

        # Tool result message (UserMessage with tool_result blocks)
        if "User" in msg_type_name and hasattr(message, "content"):
            content_blocks = []
            for block in message.content:
                if hasattr(block, "tool_use_id"):
                    content_blocks.append({
                        "type": "tool_result",
                        "tool_use_id": block.tool_use_id,
                        "content": getattr(block, "content", ""),
                        "is_error": getattr(block, "is_error", False),
                    })
            if content_blocks:
                return {
                    "type": "user",
                    "message": {"content": content_blocks},
                }, None

        # System message (init with session info)
        if "System" in msg_type_name and hasattr(message, "session_id"):
            return {
                "type": "system",
                "session_id": message.session_id,
                "subtype": getattr(message, "subtype", None),
            }, None

        return None, None
