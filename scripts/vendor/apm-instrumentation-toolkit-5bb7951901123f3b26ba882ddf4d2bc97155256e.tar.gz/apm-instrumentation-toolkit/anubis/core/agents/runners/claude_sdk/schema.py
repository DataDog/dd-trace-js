"""Output schema utilities for Claude Agent SDK.

Handles JSON schema transformation and fixing for structured outputs.
"""

from typing import Any, Dict, Type

from anthropic import transform_schema
from pydantic import BaseModel


def _fix_dict_schemas(schema: Any) -> Any:
    """Fix Dict[str, X] schemas corrupted by transform_schema.

    The anthropic SDK's transform_schema incorrectly converts Dict[str, str] from:
        {"additionalProperties": {"type": "string"}, "type": "object"}
    to:
        {"type": "object", "properties": {}, "additionalProperties": false}

    This recursively fixes such schemas by allowing additional properties
    on objects with empty properties dict. Accepts Any type for recursive calls.
    """
    if not isinstance(schema, dict):
        return schema

    result: Dict[str, Any] = {}
    for key, value in schema.items():
        if isinstance(value, dict):
            result[key] = _fix_dict_schemas(value)
        elif isinstance(value, list):
            result[key] = [
                _fix_dict_schemas(item) if isinstance(item, dict) else item for item in value
            ]
        else:
            result[key] = value

    # Fix corrupted Dict schemas: object with empty properties and additionalProperties: false
    # These are Dict[str, X] fields that transform_schema incorrectly converted
    if (
        result.get("type") == "object"
        and result.get("properties") == {}
        and result.get("additionalProperties") is False
    ):
        # Allow any additional properties (Pydantic will validate the actual types)
        result["additionalProperties"] = True

    return result


def make_flexible_schema(output_schema: Type[BaseModel]) -> Dict[str, Any]:
    """Create a flexible JSON schema that tolerates wrapped outputs.

    Claude sometimes wraps structured output in an extra key like:
        {"output": {...actual data...}}

    This modifies the schema to be permissive at the SDK level:
        1. Fix Dict[str, X] schemas corrupted by transform_schema
        2. Allow additional properties (so "output" wrapper doesn't fail)
        3. Remove required constraint (so wrapped outputs pass)
        4. Add "output" as optional property containing the strict schema

    Real validation happens in unwrap_structured_output() using Pydantic
    after extracting the actual data.

    Args:
        output_schema: Pydantic model class for the expected output

    Returns:
        JSON schema dict that's permissive for SDK validation
    """
    base_schema = transform_schema(output_schema)

    # Fix Dict schemas corrupted by transform_schema (e.g., Dict[str, str])
    base_schema = _fix_dict_schemas(base_schema)

    # Make schema permissive for SDK validation
    # Real validation happens post-unwrap with Pydantic
    schema = dict(base_schema)
    schema["additionalProperties"] = True

    # Remove required - allows wrapped output to pass SDK validation
    # Pydantic validates required fields after unwrapping
    schema.pop("required", None)

    # Add "output" as optional property with the strict schema
    # This guides Claude to use either direct or wrapped format
    if "properties" in schema:
        schema["properties"] = dict(schema["properties"])
        schema["properties"]["output"] = base_schema

    return schema
