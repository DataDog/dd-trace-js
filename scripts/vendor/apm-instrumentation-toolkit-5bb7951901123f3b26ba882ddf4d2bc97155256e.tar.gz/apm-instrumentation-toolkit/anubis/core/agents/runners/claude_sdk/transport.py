"""Custom transport with process group isolation.

This module provides IsolatedSubprocessTransport - a transport that spawns
the Claude CLI subprocess in its own process group (session), isolating it
from SIGINT sent to the foreground process group.

This enables proper interrupt handling: when Ctrl+C is pressed, only our
Python process receives SIGINT. We can then gracefully interrupt the agent
and prompt the user for guidance, rather than having the subprocess die
immediately.
"""

import anyio
from claude_agent_sdk._internal.transport.subprocess_cli import SubprocessCLITransport


class IsolatedSubprocessTransport(SubprocessCLITransport):
    """Transport that spawns subprocess in isolated process group.

    When Ctrl+C is pressed in a terminal, the terminal driver sends SIGINT
    to all processes in the foreground process group. By spawning the Claude
    CLI subprocess with `start_new_session=True`, it gets its own process
    group and won't receive SIGINT from the terminal.

    This allows us to:
    1. Catch SIGINT in our Python process
    2. Prompt the user for guidance or abort
    3. Send interrupt command to the subprocess if continuing
    4. The subprocess stays alive throughout this process
    """

    async def connect(self) -> None:
        """Connect with subprocess in isolated process group.

        Patches anyio.open_process temporarily to add start_new_session=True,
        then delegates to parent connect() implementation.
        """
        original_open_process = anyio.open_process

        async def patched_open_process(*args, **kwargs):
            # Force subprocess into its own process group/session
            kwargs["start_new_session"] = True
            return await original_open_process(*args, **kwargs)

        # Temporarily patch anyio.open_process
        anyio.open_process = patched_open_process
        try:
            await super().connect()
        finally:
            # Restore original function
            anyio.open_process = original_open_process
