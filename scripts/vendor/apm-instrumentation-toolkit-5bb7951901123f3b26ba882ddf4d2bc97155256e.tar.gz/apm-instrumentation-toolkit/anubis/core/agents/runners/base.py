"""Agent runner interface - provider-agnostic abstraction.

This module defines the interface for agent runners, allowing
different providers (Claude CLI, Claude SDK, OpenAI, etc.) to
be swapped without changing calling code.
"""

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional, Protocol, Type

from pydantic import BaseModel

from ..models import AgentResult


class EventEmitter(Protocol):
    """Protocol for event emitters used by agent runners.

    Implementations must provide an emit() method for logging events.
    """

    def emit(self, event: str, **kwargs: Any) -> None:
        """Emit an event with optional keyword arguments."""
        ...


class AgentRunner(ABC):
    """Abstract base class for agent runners.

    Implement this interface to add new AI providers. The runner is responsible
    for executing the agent and returning structured results. Higher-level
    orchestration (validation, retries, skill management) is handled separately.

    Example usage::

        runner = ClaudeCliRunner()
        result = runner.run(
            prompt="Write a hello world function",
            working_directory=Path("/tmp/work"),
            model="sonnet",
            output_schema=MyOutputSchema,
        )
        if result.success:
            print(result.structured_output)
    """

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name (e.g., 'claude_cli', 'claude_sdk')."""
        ...

    @abstractmethod
    def run(
        self,
        prompt: str,
        working_directory: Path,
        model: str = "sonnet",
        max_turns: int = 100,
        timeout_minutes: int = 30,
        output_schema: Optional[Type[BaseModel]] = None,
        emitter: Optional[EventEmitter] = None,
        log_dir: Optional[Path] = None,
        resume_session_id: Optional[str] = None,
    ) -> AgentResult:
        """Run an agent with the given prompt.

        Args:
            prompt: The task prompt for the agent.
            working_directory: Directory where agent should work.
            model: Model identifier ('sonnet', 'haiku', 'opus').
            max_turns: Maximum conversation turns before stopping.
            timeout_minutes: Timeout for the entire run.
            output_schema: Optional Pydantic model for structured output validation.
            emitter: Optional event emitter for progress updates and logging.
            log_dir: Optional directory for saving execution logs.
            resume_session_id: Optional session ID to resume a previous conversation.

        Returns:
            AgentResult containing success status, output, metrics, and session_id.
        """
        ...

    def supports_resume(self) -> bool:
        """Return True if this provider supports session resumption.

        When True, the runner can accept resume_session_id to continue
        a previous conversation with full context preserved.
        """
        return False

    def supports_structured_output(self) -> bool:
        """Return True if this provider supports schema-constrained output.

        When True, the runner can accept output_schema to enforce
        structured JSON output matching a Pydantic model.
        """
        return True

    def is_available(self) -> bool:
        """Return True if this runner's backend is available.

        Override to check for CLI availability, API keys, etc.
        """
        return True

    def get_config(self) -> Dict[str, Any]:
        """Return the runner's configuration for logging.

        Override to return provider-specific configuration details.
        This is called after run() to capture the actual configuration used.

        Returns:
            Dict with configuration keys like model, max_turns, sandbox settings, etc.
        """
        return {"provider": self.provider_name}

    def log_config(self, log_dir: Path) -> None:
        """Save the agent configuration to a JSON file in the log directory.

        Args:
            log_dir: Directory where logs are stored.
        """
        config = self.get_config()
        config_file = log_dir / "agent-config.json"
        config_file.write_text(json.dumps(config, indent=2))

    def close(self) -> None:
        """Release any resources held by the runner.

        Default is a no-op. Override in subclasses that hold connections,
        subprocesses, or long-lived clients.
        """
        return None
