"""Runner utilities - extraction, logging, and formatting.

Shared utilities for agent runners including:
- Output extraction and unwrapping
- Agent execution logging
- Message formatting for files and terminal
"""

import json
import os
import re
import time
from pathlib import Path
from typing import IO, TYPE_CHECKING, Any, Dict, List, Optional, Type

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError
from rich.markup import escape

if TYPE_CHECKING:
    from ..models import AgentResult
    from .base import EventEmitter


# =============================================================================
# Output Extraction
# =============================================================================


def unwrap_structured_output(
    data: Optional[Dict],
    output_schema: Optional[Type[BaseModel]] = None,
    emitter: Optional["EventEmitter"] = None,
) -> Optional[Dict]:
    """Unwrap structured output if nested one level down.

    The agent sometimes wraps output in an extra key (e.g., {'output': {...}}).
    We iterate all keys and validate against the schema to find the correct
    nested output.

    Args:
        data: Raw structured output dict from agent
        output_schema: Pydantic model to validate against
        emitter: Optional event emitter for logging

    Returns:
        Unwrapped dict if nested, otherwise original data
    """
    if not isinstance(data, dict) or not output_schema:
        return data

    # Try validating as-is first
    try:
        output_schema.model_validate(data)
        return data
    except PydanticValidationError as e:
        # Expected: data might be wrapped, try unwrapping below
        if emitter:
            emitter.emit("debug", message=f"Direct validation failed, attempting to unwrap: {e}")

    # Try each key's value to find one that validates
    last_error = None
    for key, value in data.items():
        if isinstance(value, dict):
            try:
                output_schema.model_validate(value)
                return value
            except PydanticValidationError as e:
                # Expected: this key doesn't contain valid output, try next
                last_error = e
                if emitter:
                    emitter.emit("debug", message=f'Key "{key}" validation failed: {e}')
                continue

    # No keys validated - log warning with actual error and return original data
    if emitter:
        error_detail = f" Last error: {last_error}" if last_error else ""
        emitter.emit(
            "warn",
            message=f"Could not unwrap structured output - no keys validated successfully. "
            f"Available keys: {list(data.keys())}.{error_detail}",
        )
    return data


# =============================================================================
# File Formatting
# =============================================================================


class FileFormatter:
    """Formats trace messages for log files."""

    def __init__(self) -> None:
        self._turn_stack: List[int] = [0]
        self._agent_stack: List[Dict[str, str]] = []

    @property
    def _subagent_depth(self) -> int:
        return len(self._agent_stack)

    def _w(self, f: IO[str], text: str) -> None:
        """Write a line with the current depth prefix."""
        prefix = "│  " * self._subagent_depth if self._agent_stack else ""
        f.write(f"{prefix}{text}\n")

    @property
    def _turn_label(self) -> str:
        return "Subagent Turn" if self._agent_stack else "Turn"

    def _pop_agent(self, tool_use_id: str) -> Optional[Dict[str, str]]:
        """Pop an agent entry matching tool_use_id. Returns the entry or None."""
        for i, entry in enumerate(self._agent_stack):
            if entry.get("tool_id") == tool_use_id:
                self._agent_stack.pop(i)
                if len(self._turn_stack) > 1:
                    self._turn_stack.pop()
                return entry
        return None

    def format_message(self, f: IO[str], message: Dict[str, Any]) -> None:
        """Format a single message to file."""
        msg_type = message.get("type")

        if msg_type == "system":
            self._format_system(f, message)
        elif msg_type == "assistant":
            self._format_assistant(f, message)
        elif msg_type == "user":
            self._format_user(f, message)
        elif msg_type == "result":
            self._format_result(f, message)
        elif msg_type == "hook":
            self._format_hook(f, message)

    def format_trace(self, f: IO[str], trace_data: List[Dict[str, Any]]) -> None:
        """Format complete trace data to file."""
        for item in trace_data:
            if isinstance(item, dict):
                self.format_message(f, item)

    def _format_system(self, f: IO[str], item: Dict) -> None:
        """Format system block."""
        f.write("━━━ Session Started ━━━\n")
        f.write(f"Model: {item.get('model', 'unknown')}\n")
        f.write(f"Session ID: {item.get('session_id', 'unknown')}\n")
        tools = item.get("tools", [])
        f.write(f"Tools: {', '.join(tools[:10])}")
        if len(tools) > 10:
            f.write(f" ... +{len(tools) - 10} more")
        f.write("\n\n")

    def _format_assistant(self, f: IO[str], item: Dict) -> None:
        """Format assistant block."""
        self._turn_stack[-1] += 1
        turn = self._turn_stack[-1]
        has_text = False

        for block in item.get("message", {}).get("content", []):
            if not isinstance(block, dict):
                continue

            if block.get("type") == "text":
                text = block.get("text", "").strip()
                if text:
                    has_text = True
                    self._w(f, f"[{self._turn_label} {turn}] Agent: {text}")
                    self._w(f, "")

            elif block.get("type") == "tool_use":
                if block.get("name") == "Agent":
                    tool_id = block.get("id", f"_auto_{turn}")
                    desc = block.get("input", {}).get("description", "subagent")
                    self._w(f, "")
                    self._w(f, f"┌── Subagent: {desc}")
                    self._agent_stack.append({"tool_id": tool_id, "description": desc})
                    self._turn_stack.append(0)
                else:
                    self._format_tool_use(f, block, turn if not has_text else None)
                has_text = True

    def _format_tool_use(self, f: IO[str], block: Dict, turn: Optional[int] = None) -> None:
        """Format a tool_use block."""
        name = block.get("name", "unknown")
        inp = block.get("input", {})

        if turn is not None:
            self._w(f, f"[{self._turn_label} {turn}] 🔧 Tool: {name}")
        else:
            self._w(f, f"🔧 Tool: {name}")

        if name == "Read":
            self._w(f, f"   Reading: {inp.get('file_path', '?')}")
        elif name == "Write":
            self._w(f, f"   Writing: {inp.get('file_path', '?')}")
            self._w(f, f"   Content: {len(inp.get('content', ''))} chars")
        elif name == "Edit":
            self._w(f, f"   File: {inp.get('file_path', '?')}")
            self._w(
                f,
                f"   Replacing: {len(inp.get('old_string', ''))} -> {len(inp.get('new_string', ''))} chars",
            )
        elif name == "Bash":
            if desc := inp.get("description"):
                self._w(f, f"   {desc}")
            self._w(f, f"   $ {inp.get('command', '?')}")
        elif name == "StructuredOutput":
            self._w(f, "   ─── Structured Output ───")
            for line in json.dumps(inp, indent=2).split("\n"):
                self._w(f, f"   {line}")
            self._w(f, "   ─────────────────────────")
        elif name == "TodoWrite":
            todos = inp.get("todos", [])
            self._w(f, f"   ─── Todo List ({len(todos)} items) ───")
            for i, todo in enumerate(todos, 1):
                status = todo.get("status", "?")
                content = todo.get("content", "?")
                icon = {"pending": "○", "in_progress": "◐", "completed": "●"}.get(status, "?")
                self._w(f, f"   {i}. [{icon}] {content}")
            self._w(f, "   ──────────────────────────────")
        else:
            for k, v in inp.items():
                v_str = str(v)
                self._w(f, f"   {k}: {v_str[:100]}{'...' if len(v_str) > 100 else ''}")

        self._w(f, "")

    def _format_user(self, f: IO[str], item: Dict) -> None:
        """Format user block (tool results)."""
        for block in item.get("message", {}).get("content", []):
            if not isinstance(block, dict) or block.get("type") != "tool_result":
                continue

            tool_use_id = block.get("tool_use_id", "")

            # Check if this result closes a subagent
            matching_entry = None
            for entry in self._agent_stack:
                if entry.get("tool_id") == tool_use_id:
                    matching_entry = entry
                    break

            if matching_entry:
                desc = matching_entry.get("description", "subagent")
                turns_used = self._turn_stack[-1] if len(self._turn_stack) > 1 else 0
                parent_depth = self._subagent_depth - 1
                close_prefix = "│  " * parent_depth
                self._pop_agent(tool_use_id)
                is_error = block.get("is_error", False)
                if is_error:
                    error_content = block.get("content", "")
                    if isinstance(error_content, str):
                        error_content = error_content[:200]
                    f.write(
                        f"{close_prefix}└── Subagent FAILED: {desc}"
                        f" ({turns_used} turns) — {error_content}\n\n"
                    )
                else:
                    f.write(f"{close_prefix}└── Subagent complete: {desc} ({turns_used} turns)\n\n")
                continue

            # Normal tool result
            is_error = block.get("is_error", False)
            self._w(f, "Error" if is_error else "Success")

            content = block.get("content", "")
            if isinstance(content, str):
                lines = content.split("\n")
                if len(lines) > 10:
                    for line in lines[:10]:
                        self._w(f, line)
                    self._w(f, f"... ({len(lines) - 10} more lines)")
                else:
                    for line in lines:
                        self._w(f, line)
            else:
                self._w(f, str(content)[:500])
            self._w(f, "")

    def _format_result(self, f: IO[str], item: Dict) -> None:
        """Format result block (session end)."""
        f.write("━━━ Session Ended ━━━\n")
        f.write(f"Duration: {item.get('duration_ms', 0) / 1000:.1f}s\n")
        f.write(f"Turns: {item.get('num_turns', 0)}\n")
        f.write(f"Cost: ${item.get('total_cost_usd', 0):.4f}\n")

        subtype = item.get("subtype")
        if subtype == "error_max_turns":
            f.write("Status: Hit max turns limit\n")
        elif subtype == "error_max_structured_output_retries":
            f.write("Status: Failed structured output validation\n")
        elif item.get("is_error"):
            f.write("Status: Failed\n")
        else:
            f.write("Status: Success\n")

        if item.get("structured_output"):
            f.write("\n━━━ Structured Output ━━━\n")
            f.write(json.dumps(item.get("structured_output"), indent=2))
            f.write("\n")

        f.write("\n")

    def _format_hook(self, f: IO[str], item: Dict) -> None:
        """Format hook event."""
        hook_name = item.get("hook_name", "unknown")
        action = item.get("action", "")
        tool_name = item.get("tool_name", "")
        detail = item.get("detail", "")
        tool_input = item.get("tool_input")
        hook_result = item.get("hook_result")

        f.write(f"🪝 Hook: {hook_name}")
        if tool_name:
            f.write(f" ({tool_name})")
        if action:
            f.write(f" → {action}")
        f.write("\n")
        if detail:
            f.write(f"   {detail}\n")
        if tool_input:
            f.write("   ─── Tool Input ───\n")
            f.write(json.dumps(tool_input, indent=2))
            f.write("\n   ──────────────────\n")
        if hook_result:
            f.write("   ─── Hook Result ──\n")
            f.write(json.dumps(hook_result, indent=2))
            f.write("\n   ──────────────────\n")
        f.write("\n")


# =============================================================================
# Terminal Formatting
# =============================================================================


class TerminalFormatter:
    """Formats trace messages for terminal display."""

    def __init__(self) -> None:
        self._agent_stack: List[Dict[str, str]] = []
        self._turn_stack: List[int] = [0]
        try:
            self._max_width = os.get_terminal_size().columns - 6
        except OSError:
            self._max_width = 160

    @property
    def _subagent_depth(self) -> int:
        return len(self._agent_stack)

    @property
    def _depth_prefix(self) -> str:
        """Rich markup prefix indicating subagent nesting."""
        if not self._agent_stack:
            return ""
        return "[dim]│ [/]" * self._subagent_depth

    def _prefix_lines(self, text: str) -> str:
        """Prepend depth prefix to every line of a multi-line string."""
        prefix = self._depth_prefix
        if not prefix:
            return text
        return "\n".join(f"{prefix}{line}" for line in text.split("\n"))

    def _cap(self, line: str) -> str:
        """Cap a single line to terminal width, accounting for Rich markup."""
        visible = re.sub(r"\[/?[^\]]*\]", "", line)
        if len(visible) <= self._max_width:
            return line
        excess = len(visible) - self._max_width + 3
        return line[: len(line) - excess] + "..."

    def format_message(self, message: Dict[str, Any]) -> Optional[str]:
        """Format a message for terminal display.

        Returns formatted string or None if shouldn't be displayed.
        """
        result = self._format_message(message)
        if result is None:
            return None
        capped_lines = [self._cap(line) for line in result.split("\n")]
        return "\n".join(capped_lines)

    def _format_message(self, message: Dict[str, Any]) -> Optional[str]:
        """Internal: format without line capping."""
        msg_type = message.get("type")

        # Check for Agent tool_result to pop subagent stack + turn counter
        if msg_type == "user":
            for block in message.get("message", {}).get("content", []):
                if not isinstance(block, dict) or block.get("type") != "tool_result":
                    continue
                tool_use_id = block.get("tool_use_id", "")
                for entry in self._agent_stack:
                    if entry.get("tool_id") == tool_use_id:
                        desc = escape(entry.get("description", "subagent"))
                        turns_used = self._turn_stack[-1] if len(self._turn_stack) > 1 else 0
                        parent_depth = self._subagent_depth - 1
                        close_prefix = "[dim]│ [/]" * parent_depth
                        self._agent_stack.remove(entry)
                        if len(self._turn_stack) > 1:
                            self._turn_stack.pop()
                        is_error = block.get("is_error", False)
                        status = "[red]FAILED[/]" if is_error else "complete"
                        return (
                            f"{close_prefix}"
                            f"[dim]└── Subagent {status}: {desc} ({turns_used} turns)[/]"
                        )

        if msg_type == "assistant":
            self._turn_stack[-1] += 1
            turn = self._turn_stack[-1]
            # Process ALL content blocks — messages can contain mixed text + tool_use.
            # Collecting outputs avoids early return that would skip tool_use after text.
            parts: list[str] = []
            for block in message.get("message", {}).get("content", []):
                if not isinstance(block, dict):
                    continue

                if block.get("type") == "text":
                    text = block.get("text", "").strip()
                    if text:
                        text = self._truncate(text, max_lines=8, max_chars=800)
                        label = (
                            "[cyan]💭 Agent:[/]"
                            if not self._agent_stack
                            else "[cyan]💭 Subagent:[/]"
                        )
                        parts.append(self._prefix_lines(f"{label}\n{escape(text)}"))

                elif block.get("type") == "tool_use":
                    if block.get("name") == "Agent":
                        tool_id = block.get("id", f"_auto_{turn}")
                        desc = block.get("input", {}).get("description", "subagent")
                        self._agent_stack.append({"tool_id": tool_id, "description": desc})
                        self._turn_stack.append(0)
                        parts.append(
                            self._prefix_lines(f"[magenta]┌── Subagent: {escape(desc)}[/]")
                        )
                    else:
                        parts.append(self._prefix_lines(self._format_tool(block)))
            if parts:
                return "\n".join(parts)

        elif msg_type == "user":
            for block in message.get("message", {}).get("content", []):
                if block.get("type") == "tool_result" and block.get("is_error"):
                    return self._prefix_lines(self._format_error(block.get("content", "")))

        elif msg_type == "hook":
            hook_name = escape(message.get("hook_name", "unknown"))
            action = escape(message.get("action", ""))
            tool_name = escape(message.get("tool_name", ""))
            detail = escape(message.get("detail", ""))
            tool_input = message.get("tool_input")
            parts = [f"[dim]🪝 {hook_name}[/]"]
            if tool_name:
                parts[0] += f" [dim]({tool_name})[/]"
            if action:
                parts[0] += f" [dim]→ {action}[/]"
            if detail:
                parts.append(f"   [dim]{detail}[/]")
            if tool_input:
                input_str = json.dumps(tool_input, indent=2)
                # Truncate for terminal
                lines = input_str.split("\n")
                preview = "\n".join(f"   {escape(l)}" for l in lines[:10])
                parts.append(preview)
                if len(lines) > 10:
                    parts.append(f"   [dim]... (+{len(lines) - 10} more lines)[/]")
            return "\n".join(parts)

        return None

    def _truncate(self, text: str, max_lines: int = 8, max_chars: int = 800) -> str:
        """Truncate text for display."""
        lines = text.split("\n")
        if len(lines) > max_lines:
            return (
                "\n".join(lines[:max_lines])
                + f"\n[dim]... (+{len(lines) - max_lines} more lines)[/]"
            )
        if len(text) > max_chars:
            return text[:max_chars] + "..."
        return text

    def _format_error(self, content: Any) -> str:
        """Format error content."""
        if not isinstance(content, str):
            return "[red]✗ Error[/]"

        lines = content.split("\n")
        preview = escape("\n".join(lines[:5]))
        if len(lines) > 5:
            preview += "\n[dim]...[/]"
        return f"[red]✗ Error:[/]\n{preview}"

    def _format_tool(self, block: Dict) -> str:
        """Format a tool_use block for terminal."""
        name = block.get("name", "?")
        inp = block.get("input", {})

        if name == "Read":
            path = escape(inp.get("file_path", "?"))
            lines = ["[green]📖 Read[/]", f"   [dim]File:[/] {path}"]
            if inp.get("offset"):
                lines.append(f"   [dim]Offset:[/] {inp.get('offset')} lines")
            if inp.get("limit"):
                lines.append(f"   [dim]Limit:[/] {inp.get('limit')} lines")
            return "\n".join(lines)

        elif name == "Write":
            path = escape(inp.get("file_path", "?"))
            content = inp.get("content", "")
            content_lines = content.split("\n")
            preview = "\n".join(f"   {escape(l[:80])}" for l in content_lines[:6])
            lines = [
                "[yellow]✏️  Write[/]",
                f"   [dim]File:[/] {path}",
                f"   [dim]Size:[/] {len(content)} chars, {len(content_lines)} lines",
                "   [dim]Preview:[/]",
                preview,
            ]
            if len(content_lines) > 6:
                lines.append(f"   [dim]... (+{len(content_lines) - 6} more lines)[/]")
            return "\n".join(lines)

        elif name == "Edit":
            path = escape(inp.get("file_path", "?"))
            old_str = inp.get("old_string", "")
            new_str = inp.get("new_string", "")
            old_lines = old_str.split("\n")
            new_lines = new_str.split("\n")
            lines = [
                "[yellow]📝 Edit[/]",
                f"   [dim]File:[/] {path}",
                f"   [dim]Replacing:[/] {len(old_lines)} lines → {len(new_lines)} lines",
            ]
            max_preview = 5
            for line in old_lines[:max_preview]:
                lines.append(f"   [red]-[/] {escape(line[:80])}{'...' if len(line) > 80 else ''}")
            if len(old_lines) > max_preview:
                lines.append(
                    f"   [dim]  ... ({len(old_lines) - max_preview} more lines removed)[/]"
                )
            for line in new_lines[:max_preview]:
                lines.append(f"   [green]+[/] {escape(line[:80])}{'...' if len(line) > 80 else ''}")
            if len(new_lines) > max_preview:
                lines.append(f"   [dim]  ... ({len(new_lines) - max_preview} more lines added)[/]")
            return "\n".join(lines)

        elif name == "Bash":
            desc = escape(inp.get("description", ""))
            cmd = inp.get("command", "?")
            cmd_lines = cmd.split("\n") if "\n" in cmd else [cmd]
            lines = ["[magenta]$ Bash[/]"]
            if desc:
                lines.append(f"   [dim]{desc}[/]")
            for i, cmd_line in enumerate(cmd_lines[:5]):
                prefix = "   $ " if i == 0 else "     "
                lines.append(f"{prefix}{escape(cmd_line)}")
            if len(cmd_lines) > 5:
                lines.append(f"   [dim]... (+{len(cmd_lines) - 5} more lines)[/]")
            return "\n".join(lines)

        elif name == "Grep":
            pattern = escape(inp.get("pattern", "?")[:80])
            path = escape(inp.get("path", "."))
            glob_filter = escape(inp.get("glob", ""))
            output_mode = inp.get("output_mode", "files_with_matches")
            lines = [
                "[blue]🔍 Grep[/]",
                f"   [dim]Pattern:[/] {pattern}{'...' if len(inp.get('pattern', '')) > 80 else ''}",
                f"   [dim]Path:[/] {path}",
            ]
            if glob_filter:
                lines.append(f"   [dim]Glob:[/] {glob_filter}")
            lines.append(f"   [dim]Mode:[/] {output_mode}")
            return "\n".join(lines)

        elif name == "Glob":
            pattern = escape(inp.get("pattern", "?"))
            path = escape(inp.get("path", "."))
            return "\n".join([
                "[blue]📁 Glob[/]",
                f"   [dim]Pattern:[/] {pattern}",
                f"   [dim]Path:[/] {path}",
            ])

        elif name == "TodoWrite":
            todos = inp.get("todos", [])
            pending = sum(1 for t in todos if t.get("status") == "pending")
            in_prog = sum(1 for t in todos if t.get("status") == "in_progress")
            done = sum(1 for t in todos if t.get("status") == "completed")
            lines = [f"[cyan]📋 TodoWrite[/] ({len(todos)} items: {done}✓ {in_prog}◐ {pending}○)"]
            for todo in todos[:8]:
                status = todo.get("status", "?")
                content = escape(todo.get("content", "?")[:60])
                icon = {
                    "pending": "○",
                    "in_progress": "[yellow]◐[/]",
                    "completed": "[green]●[/]",
                }.get(status, "?")
                lines.append(
                    f"   {icon} {content}{'...' if len(todo.get('content', '')) > 60 else ''}"
                )
            if len(todos) > 8:
                lines.append(f"   [dim]... (+{len(todos) - 8} more)[/]")
            return "\n".join(lines)

        elif name == "Task":
            desc = escape(inp.get("description", "?"))
            prompt = escape(inp.get("prompt", "")[:200])
            subagent = escape(inp.get("subagent_type", "?"))
            return "\n".join([
                f"[magenta]🤖 Task[/] ({subagent})",
                f"   [dim]Description:[/] {desc}",
                f"   [dim]Prompt:[/] {prompt}{'...' if len(inp.get('prompt', '')) > 200 else ''}",
            ])

        else:
            lines = [f"[blue]🔧 {escape(name)}[/]"]
            for k, v in list(inp.items())[:5]:
                v_str = escape(str(v)[:80])
                lines.append(f"   [dim]{escape(k)}:[/] {v_str}{'...' if len(str(v)) > 80 else ''}")
            if len(inp) > 5:
                lines.append(f"   [dim]... (+{len(inp) - 5} more params)[/]")
            return "\n".join(lines)


# =============================================================================
# Agent Logger
# =============================================================================


class AgentLogger:
    """Shared logging interface for agent runners.

    Handles both file logging and terminal output in a consistent format.
    """

    def __init__(
        self,
        log_dir: Optional[Path] = None,
        emitter: Optional["EventEmitter"] = None,
        task_description: str = "",
    ) -> None:
        """Initialize the logger.

        Args:
            log_dir: Directory for log files. If None, no files are written.
            emitter: Event emitter for terminal output.
            task_description: Description of the task for log headers.
        """
        self._log_dir = log_dir
        self._emitter = emitter
        self._task_description = task_description
        self._timestamp = int(time.time())
        self._trace_data: List[Dict[str, Any]] = []

        # Formatters
        self._file_formatter = FileFormatter()
        self._terminal_formatter = TerminalFormatter()

        # Open log files if log_dir provided
        self._stream_file: Optional[IO[str]] = None
        self._formatted_file: Optional[IO[str]] = None
        if log_dir:
            log_dir.mkdir(parents=True, exist_ok=True)
            stream_path = log_dir / f"agent-stream-{self._timestamp}.json"
            formatted_path = log_dir / f"agent-stream-{self._timestamp}.log"
            self._stream_file = open(stream_path, "w")
            self._formatted_file = open(formatted_path, "w")

    def log_message(self, message: Dict[str, Any]) -> None:
        """Log a message in the common trace format.

        Args:
            message: Dict with 'type' key ('system', 'assistant', 'user', 'result').
        """
        self._trace_data.append(message)

        # Write raw JSON to stream file
        if self._stream_file:
            self._stream_file.write(json.dumps(message) + "\n")
            self._stream_file.flush()

        # Write formatted to log file
        if self._formatted_file:
            self._file_formatter.format_message(self._formatted_file, message)
            self._formatted_file.flush()

        # Emit to terminal
        if self._emitter:
            formatted = self._terminal_formatter.format_message(message)
            if formatted:
                self._emitter.emit("agent_output", line=formatted)

    def save_execution_log(
        self,
        result: "AgentResult",
        working_directory: Optional[Path] = None,
    ) -> None:
        """Save final execution log to disk.

        Args:
            result: The agent result.
            working_directory: Working directory for the agent.
        """
        if not self._log_dir:
            return

        log_file = self._log_dir / f"agent-execution-{self._timestamp}.log"
        try:
            with open(log_file, "w") as f:
                f.write(f"=== Agent Task: {self._task_description} ===\n")
                f.write(f"Timestamp: {self._timestamp}\n")
                if working_directory:
                    f.write(f"Working Directory: {working_directory}\n")
                f.write(f"Success: {result.success}\n")
                if result.error:
                    f.write(f"Error: {result.error}\n")
                f.write("\n=== Agent Execution Trace ===\n\n")

                if self._trace_data:
                    formatter = FileFormatter()
                    formatter.format_trace(f, self._trace_data)
                else:
                    f.write(result.output if result.output else "(no output captured)")
        except Exception as e:
            if self._emitter:
                self._emitter.emit("warn", message=f"Could not save log: {e}")

    def close(self) -> None:
        """Close log file handles."""
        if self._stream_file:
            self._stream_file.close()
            self._stream_file = None
        if self._formatted_file:
            self._formatted_file.close()
            self._formatted_file = None

    def __enter__(self) -> "AgentLogger":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @property
    def trace_data(self) -> List[Dict[str, Any]]:
        """Return collected trace data."""
        return self._trace_data
