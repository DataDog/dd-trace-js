"""PreToolUse hook for unwrapping nested structured output.

Claude agents frequently wrap structured output in a nested key
(e.g. {"output": {...actual_data...}}), which fails the SDK's JSON schema
validation. This hook intercepts the StructuredOutput tool call and unwraps
the nested output before validation, avoiding wasted retry attempts.
"""

from typing import Any, Callable, Dict, Optional, Type, cast

from claude_agent_sdk.types import (
    HookCallback,
    HookContext,
    HookInput,
    HookJSONOutput,
    PreToolUseHookInput,
    SyncHookJSONOutput,
)
from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

# Callback: (hook_name, tool_name, action, detail, tool_input, hook_result) -> None
HookEventLogger = Callable[..., None]


def _validates(schema: Type[BaseModel], data: Dict[str, Any]) -> bool:
    """Check if data validates against a Pydantic schema."""
    try:
        schema.model_validate(data)
        return True
    except PydanticValidationError:
        return False


def build_structured_output_hook(
    output_schema: Type[BaseModel],
    emitter_callback: Optional[HookEventLogger] = None,
) -> HookCallback:
    """Build a PreToolUse hook that unwraps nested structured output.

    Args:
        output_schema: Pydantic model to validate against.
        emitter_callback: Optional callback for logging hook events.
            Signature: (hook_name, tool_name, action, detail, tool_input, hook_result).

    Returns:
        HookCallback compatible with Claude Agent SDK HookMatcher.
    """

    def _log(
        action: str,
        detail: str = "",
        tool_input: Optional[Dict[str, Any]] = None,
        hook_result: Optional[Dict[str, Any]] = None,
    ) -> None:
        if emitter_callback:
            emitter_callback(
                "structured_output_unwrap",
                "StructuredOutput",
                action,
                detail,
                tool_input=tool_input,
                hook_result=hook_result,
            )

    async def structured_output_pre_tool_hook(
        input_data: HookInput,
        tool_use_id: Optional[str],
        context: HookContext,
    ) -> HookJSONOutput:
        """PreToolUse hook that unwraps nested StructuredOutput before SDK validation."""
        if input_data.get("hook_event_name") != "PreToolUse":
            return SyncHookJSONOutput()

        data = cast(PreToolUseHookInput, input_data)
        if data["tool_name"] != "StructuredOutput":
            return SyncHookJSONOutput()

        tool_input = data["tool_input"]
        if not isinstance(tool_input, dict):
            return SyncHookJSONOutput()

        # Try validating as-is first — if valid, no change needed.
        # But watch for the "false positive" case: all fields have defaults,
        # so {"output": {...actual data...}} validates at top level with empty
        # defaults while the real data is nested. If "output" key also validates,
        # prefer the unwrapped form.
        if _validates(output_schema, tool_input):
            output_value = tool_input.get("output")
            if isinstance(output_value, dict) and _validates(output_schema, output_value):
                _log(
                    "unwrapped",
                    'Top-level valid but "output" key also valid — preferring unwrapped',
                    tool_input=tool_input,
                    hook_result=output_value,
                )
                return SyncHookJSONOutput(
                    hookSpecificOutput={
                        "hookEventName": "PreToolUse",
                        "updatedInput": output_value,
                    }
                )
            _log(
                "valid", f"Output matches {output_schema.__name__} directly", tool_input=tool_input
            )
            return SyncHookJSONOutput()

        # Try each key's value to find one that validates
        for key, value in tool_input.items():
            if not isinstance(value, dict):
                continue
            if _validates(output_schema, value):
                _log(
                    "unwrapped",
                    f'Unwrapped from nested key "{key}" (keys: {list(tool_input.keys())})',
                    tool_input=tool_input,
                    hook_result=value,
                )
                return SyncHookJSONOutput(
                    hookSpecificOutput={
                        "hookEventName": "PreToolUse",
                        "updatedInput": value,
                    }
                )

        # No keys validated — let SDK handle the error normally
        _log(
            "failed",
            f"No nested key matched {output_schema.__name__}. Keys: {list(tool_input.keys())}",
            tool_input=tool_input,
        )
        return SyncHookJSONOutput()

    return structured_output_pre_tool_hook
