"""Claude Agent SDK integration.

This module provides the ClaudeSDKRunner for running Claude agents
programmatically using the claude-agent-sdk package.

Structure:
- runner.py: Main ClaudeSDKRunner class
- session.py: Session management with ClaudeSDKClient
- security.py: Permission rules and security hooks
- message_handler.py: SDK message processing
- transport.py: Custom transport with process group isolation
"""

from .runner import ClaudeSDKRunner
from .security import DEFAULT_DENY_RULES
from .session import Session
from .transport import IsolatedSubprocessTransport

__all__ = [
    "ClaudeSDKRunner",
    "Session",
    "IsolatedSubprocessTransport",
    "DEFAULT_DENY_RULES",
]
