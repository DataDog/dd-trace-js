"""Session management for Claude Agent SDK.

This module provides the Session class that wraps ClaudeSDKClient,
handling:
- Client lifecycle (connect, query, close)
- Interrupt handling with user guidance injection
- Follow-up queries on the same session (for fixer loops)
"""

import asyncio
import logging
import os
import signal
import sys
import threading
from contextlib import contextmanager
from types import FrameType
from typing import Any, Callable, Optional, Union

from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient

from ....errors import UserAbortError
from ...models import AgentMetrics
from ..base import EventEmitter
from ..utils import AgentLogger
from .message_handler import MessageHandler
from .transport import IsolatedSubprocessTransport

logger = logging.getLogger(__name__)


@contextmanager
def _suppress_sdk_stderr():
    """Suppress stderr from SDK file watcher errors.

    The Claude SDK emits EOPNOTSUPP errors when trying to watch socket files
    on macOS. These errors don't affect functionality but clutter output.
    We redirect stderr at the file descriptor level to catch subprocess output.
    """
    original_stderr_fd = os.dup(2)
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, 2)
    try:
        yield
    finally:
        os.dup2(original_stderr_fd, 2)
        os.close(devnull)
        os.close(original_stderr_fd)


class Session:
    """Manages a ClaudeSDKClient session with interrupt and follow-up support.

    Usage:
        session = Session(options, logger, emitter)
        await session.connect()

        # Initial query
        result = await session.query(prompt, metrics, timeout_minutes=30)

        # Follow-up query (same session)
        result = await session.query(followup_prompt, metrics, timeout_minutes=10)

        # Clean up
        await session.close()

    Interrupt Handling:
        Press Ctrl+C to interrupt the agent. The subprocess runs in an isolated
        process group (via start_new_session=True) so it doesn't receive SIGINT.
        After interrupt, you can enter guidance to redirect the agent, or press
        Enter to abort.
    """

    def __init__(
        self,
        options: ClaudeAgentOptions,
        logger: Optional[AgentLogger] = None,
        emitter: Optional[EventEmitter] = None,
        allow_interrupt: bool = True,
    ):
        self._options = options
        self._logger = logger
        self._emitter = emitter
        self._allow_interrupt = allow_interrupt

        # Client state
        self._client: Optional[ClaudeSDKClient] = None
        self._handler: Optional[MessageHandler] = None

        # Interrupt handling - uses asyncio Event for thread-safe signaling
        self._interrupted = False
        self._subprocess_dead = False  # True if subprocess died (can't recover)
        self._interrupt_event: Optional[asyncio.Event] = None
        # Type matches signal.getsignal return type: handler function, SIG_IGN/SIG_DFL (int), or None
        self._original_sigint_handler: Union[
            Callable[[int, Optional[FrameType]], Any], int, None
        ] = None

    @property
    def session_id(self) -> Optional[str]:
        """Get the session ID (available after first query)."""
        return self._handler.session_id if self._handler else None

    @property
    def is_connected(self) -> bool:
        """Check if the session is connected."""
        return self._client is not None

    async def connect(self) -> None:
        """Connect the client (enter async context)."""
        if self._client:
            return

        # Create custom transport that spawns subprocess in isolated process group.
        # This prevents the subprocess from receiving SIGINT when Ctrl+C is pressed,
        # allowing us to gracefully interrupt and prompt for user guidance.
        async def _empty_stream():
            """Empty async generator for streaming mode initialization."""
            return
            yield {}  # Makes this an async generator

        transport = IsolatedSubprocessTransport(
            prompt=_empty_stream(),
            options=self._options,
        )

        # Suppress stderr during SDK initialization to avoid EOPNOTSUPP errors
        with _suppress_sdk_stderr():
            self._client = ClaudeSDKClient(
                options=self._options,
                transport=transport,
            )
            await self._client.__aenter__()

        self._handler = MessageHandler(logger=self._logger)

    async def reconnect(self) -> None:
        """Reconnect the session, resuming the previous conversation.

        Use this when the async connection is stale (e.g., after asyncio.run()
        closed the event loop) but you want to continue the same conversation.
        """
        # Save session_id before closing
        session_id = self.session_id

        # Close the old client (best effort, may already be dead)
        if self._client:
            try:
                await self._client.__aexit__(None, None, None)
            except Exception as e:
                # Best effort cleanup - client may be in bad state after interrupt
                if self._emitter:
                    self._emitter.emit(
                        "warn", message=f"Error closing old client during reconnect: {e}"
                    )
            finally:
                self._client = None

        # Update options to resume the conversation
        if session_id:
            self._options.resume = session_id

        # Create fresh connection
        await self.connect()

    async def close(self) -> None:
        """Close the session and clean up resources."""
        self._restore_sigint_handler()

        if self._client:
            try:
                await self._client.__aexit__(None, None, None)
            except RuntimeError as e:
                # Ignore cancel scope errors during cleanup (can happen after SIGINT)
                if "cancel scope" not in str(e).lower():
                    raise
            except Exception as e:
                # Best effort cleanup - log unexpected errors but don't fail
                if self._emitter:
                    self._emitter.emit("warn", message=f"Error during session cleanup: {e}")
            finally:
                self._client = None

        if self._logger:
            self._logger.close()

    async def query(
        self,
        prompt: str,
        metrics: AgentMetrics,
        timeout_minutes: int = 30,
    ) -> bool:
        """Send a query and process responses.

        Args:
            prompt: The prompt to send
            metrics: AgentMetrics to update with results
            timeout_minutes: Timeout for this query

        Returns:
            True if completed successfully, False if interrupted/aborted
        """
        if not self._client:
            raise RuntimeError("Session not connected. Call connect() first.")

        # Reset handler state for new query (but keep session_id)
        if self._handler:
            self._handler.reset()

        # Setup interrupt handling
        self._setup_sigint_handler()
        self._interrupted = False
        self._subprocess_dead = False

        try:
            await self._client.query(prompt)

            async with asyncio.timeout(timeout_minutes * 60):
                # Process response stream
                success = await self._receive_responses(metrics)

                # Handle interrupt - prompt user for guidance (if subprocess still alive)
                while self._interrupted and self._can_prompt_user():
                    self._interrupted = False

                    # If subprocess died, abort
                    if self._subprocess_dead:
                        break

                    guidance = await self._get_user_guidance()

                    if not guidance:
                        # User aborted - need to actually interrupt the agent
                        try:
                            await self._client.interrupt()
                        except Exception as e:
                            # Best effort - log but don't fail
                            if self._emitter:
                                self._emitter.emit(
                                    "warn", message=f"Failed to interrupt agent cleanly: {e}"
                                )
                        # Raise to propagate abort through entire workflow
                        # (abort message already emitted in _get_user_guidance)
                        raise UserAbortError("User aborted agent execution")

                    # Send guidance as follow-up message
                    # The agent subprocess was already interrupted in _receive_responses,
                    # and the response stream was fully consumed, so we can send new guidance
                    try:
                        if self._emitter:
                            self._emitter.emit(
                                "info", message=f"Sending guidance: {guidance[:50]}..."
                            )
                        await self._client.query(guidance)
                        success = await self._receive_responses(metrics)
                    except Exception as e:
                        error_str = str(e).lower()
                        if "terminated" in error_str or "exit code" in error_str:
                            self._subprocess_dead = True
                            break
                        raise

                # If subprocess died from SIGINT, abort entire workflow
                if self._subprocess_dead:
                    if self._emitter:
                        self._emitter.emit(
                            "info", message="Agent subprocess is dead - aborting workflow"
                        )
                    raise UserAbortError("Agent subprocess terminated")

                return success

        except TimeoutError:
            metrics.is_error = True
            metrics.error_subtype = "timeout"
            return False
        except RuntimeError as e:
            # Handle anyio cancel scope errors from signal interruption
            if "cancel scope" in str(e).lower():
                if self._emitter:
                    self._emitter.emit("info", message="Agent interrupted")
                raise UserAbortError("Agent interrupted")
            raise
        finally:
            self._restore_sigint_handler()

    async def interrupt(self) -> None:
        """Interrupt the running agent."""
        if self._client:
            await self._client.interrupt()

    async def _receive_responses(self, metrics: AgentMetrics) -> bool:
        """Receive and process responses from the client.

        When interrupted, calls client.interrupt() and continues consuming messages
        until the stream ends naturally. This ensures clean state for follow-up queries.

        Uses periodic timeout checks to detect Ctrl+C even during long-running commands.
        We use asyncio.wait() instead of asyncio.wait_for() because wait_for() cancels
        the underlying coroutine on timeout, which corrupts the async iterator state.

        Returns True if completed normally, False if interrupted.
        """
        if not self._client or not self._handler:
            return False

        was_interrupted = False
        response_iter = self._client.receive_response().__aiter__()

        async def _get_next_message():
            """Get next message, returns None on StopAsyncIteration."""
            try:
                return await response_iter.__anext__()
            except StopAsyncIteration:
                return None

        # Create a single task for getting messages to avoid iterator corruption.
        # asyncio.wait_for cancels the task on timeout, which corrupts the async
        # iterator state. Instead, we create one task and reuse it across timeouts.
        pending_task: asyncio.Task | None = None

        try:
            while True:
                # Use short timeout to periodically check for interrupts
                # This allows Ctrl+C to be detected even during long-running commands
                try:
                    # Only create a new task if we don't have a pending one
                    if pending_task is None:
                        pending_task = asyncio.create_task(_get_next_message())

                    done, _ = await asyncio.wait({pending_task}, timeout=0.5)
                    if done:
                        message = pending_task.result()
                        pending_task = None  # Allow new task creation
                    else:
                        # Timeout - task still pending, check for interrupt
                        if self._interrupted and not was_interrupted:
                            was_interrupted = True
                            try:
                                await self._client.interrupt()
                            except Exception as e:
                                error_str = str(e).lower()
                                if "terminated" in error_str or "exit code" in error_str:
                                    self._subprocess_dead = True
                                    return False
                        continue
                except asyncio.CancelledError:
                    raise

                # Stream ended
                if message is None:
                    break

                # When interrupted, send interrupt signal and continue draining
                if self._interrupted and not was_interrupted:
                    was_interrupted = True
                    try:
                        await self._client.interrupt()
                    except Exception as e:
                        # Check if process already terminated
                        error_str = str(e).lower()
                        if "terminated" in error_str or "exit code" in error_str:
                            self._subprocess_dead = True
                            return False
                        # Other interrupt errors are ok - continue draining

                self._handler.process(message, metrics)

            # Return based on whether we were interrupted
            return not was_interrupted
        except RuntimeError as e:
            # Handle anyio cancel scope errors from SIGINT killing the subprocess
            # When Ctrl+C is pressed, the Claude CLI subprocess receives SIGINT and dies,
            # causing the SDK to throw a cancel scope error during iteration
            if "cancel scope" in str(e).lower():
                self._interrupted = True
                self._subprocess_dead = True  # Can't recover from subprocess death
                return False
            raise
        except Exception as e:
            # Handle other subprocess errors (exit code -2 from SIGINT, etc.)
            error_str = str(e).lower()
            if "exit code" in error_str or "command failed" in error_str:
                self._interrupted = True
                self._subprocess_dead = True  # Can't recover from subprocess death
                return False
            raise
        finally:
            # Cancel any pending task to avoid "coroutine never awaited" warnings
            if pending_task is not None and not pending_task.done():
                pending_task.cancel()
                try:
                    await pending_task
                except (asyncio.CancelledError, Exception) as e:
                    logger.debug("Pending task cancelled during cleanup: %s", e)

            # Properly close the async iterator
            if hasattr(response_iter, "aclose"):
                try:
                    await response_iter.aclose()
                except Exception as e:
                    logger.debug("Failed to close response iterator: %s", e)

    def _setup_sigint_handler(self) -> None:
        """Setup signal handler for Ctrl+C.

        Uses asyncio.Event for thread-safe signaling between the signal handler
        (which runs in a different context) and the async code. The signal handler
        uses loop.call_soon_threadsafe() to safely set the event from any context.

        Note: Signal handlers can only be registered from the main thread.
        When running in worker threads (e.g., batch parallel agents), interrupt
        handling is disabled.
        """
        if not self._allow_interrupt:
            return

        # Signal handlers can only be registered from the main thread.
        # When running in parallel worker threads (batch agents), skip signal setup.
        if threading.current_thread() is not threading.main_thread():
            return

        # Create event for this query
        self._interrupt_event = asyncio.Event()

        # Save original handler
        self._original_sigint_handler = signal.getsignal(signal.SIGINT)

        # Get the event loop for thread-safe callback scheduling
        loop = asyncio.get_event_loop()

        def sigint_handler(signum, frame):
            """Signal handler that safely signals the async code."""
            # Use call_soon_threadsafe to safely set the event from signal context
            try:
                loop.call_soon_threadsafe(self._on_interrupt)
            except RuntimeError:
                # Loop might be closed, fall back to direct flag set
                self._interrupted = True

        signal.signal(signal.SIGINT, sigint_handler)

    def _restore_sigint_handler(self) -> None:
        """Restore original signal handler."""
        if self._original_sigint_handler is not None:
            # Only restore if in main thread (signal handlers are main-thread-only)
            if threading.current_thread() is threading.main_thread():
                signal.signal(signal.SIGINT, self._original_sigint_handler)
            self._original_sigint_handler = None

    def _on_interrupt(self) -> None:
        """Called from event loop when interrupt signal received.

        This runs in the event loop context (via call_soon_threadsafe),
        so it's safe to interact with asyncio primitives.
        """
        self._interrupted = True
        if self._interrupt_event:
            self._interrupt_event.set()
        if self._emitter:
            self._emitter.emit("info", message="Ctrl+C received - interrupting agent...")

    def _can_prompt_user(self) -> bool:
        """Check if we can prompt the user for input.

        Returns False if:
        - Interrupts are disabled
        - Not running in a TTY
        - Subprocess died (can't recover, must abort)
        """
        if self._subprocess_dead:
            # Subprocess died from SIGINT - can't recover or prompt for guidance
            if self._emitter:
                self._emitter.emit("info", message="Agent subprocess terminated - aborting")
            return False
        return self._allow_interrupt and sys.stdin.isatty()

    async def _get_user_guidance(self) -> Optional[str]:
        """Get guidance from user after interrupt.

        Returns the guidance string, or None if user wants to abort.
        """
        try:
            # Pause the live panel to allow user input
            # This stops the Live refresh and restores terminal echo
            if self._emitter:
                self._emitter.emit("pause_live")

            print()  # New line after interrupt
            # Use asyncio to not block the event loop
            loop = asyncio.get_event_loop()
            raw_input = await loop.run_in_executor(
                None,
                lambda: input(
                    "[Interrupted] Type guidance and press Enter to continue, or just Enter to abort: "
                ),
            )
            guidance = raw_input.strip() if raw_input.strip() else None
            if not guidance and self._emitter:
                self._emitter.emit("warn", message="User aborted agent execution")
                self._emitter.emit("stop_live")  # Stop panels and restore terminal
            elif self._emitter:
                self._emitter.emit("resume_live")  # Restart panels
            return guidance
        except EOFError:
            if self._emitter:
                self._emitter.emit("stop_live")
            return None

    # Properties to access handler state
    @property
    def files_modified(self) -> list:
        """Get list of files modified during session."""
        return self._handler.files_modified if self._handler else []

    @property
    def final_output(self) -> Optional[str]:
        """Get final text output from agent."""
        return self._handler.final_output if self._handler else None

    @property
    def raw_structured_output(self) -> Optional[dict]:
        """Get raw structured output from agent."""
        return self._handler.raw_structured_output if self._handler else None
