"""Claude Agent SDK runner implementation.

This module provides ClaudeSDKRunner - an AgentRunner implementation using
the Claude Agent SDK for programmatic agent execution.

Features:
- Persistent session support via ClaudeSDKClient
- Keyboard interrupt handling with user guidance injection
- Same-session follow-up queries (for fixer loops)
"""

import asyncio
import io
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, cast

from claude_agent_sdk import ClaudeAgentOptions, HookMatcher, PermissionMode
from claude_agent_sdk.types import HookCallback, SandboxSettings
from pydantic import BaseModel

from ...eval_proxy import get_proxy_stats, reset_proxy_stats, resolve_model_alias
from ...models import AgentMetrics, AgentResult
from ..base import AgentRunner, EventEmitter
from ..utils import AgentLogger, unwrap_structured_output
from .schema import make_flexible_schema
from .security import build_permission_settings, build_pre_tool_use_hook
from .session import Session
from .signal_hook import build_signal_hook
from .structured_output_hook import build_structured_output_hook

logger = logging.getLogger(__name__)


def _apply_proxy_cost_override(metrics: "AgentMetrics") -> None:
    """Replace SDK cost/model with real values from the eval proxy.

    The SDK reports Anthropic pricing even when the request was routed through
    a non-Anthropic backend via the MITM proxy. Read the proxy's cost file
    and update metrics in-place when a non-Anthropic model override is active.
    """
    override = os.environ.get("ANTHROPIC_MODEL", "")
    if not (override and "/" in override and not override.startswith("anthropic/")):
        return
    stats = get_proxy_stats()
    sdk_cost = metrics.cost_usd
    if stats.get("cost_usd"):
        metrics.cost_usd = stats["cost_usd"]
        print(
            f"[eval-proxy] cost: SDK ${sdk_cost:.4f} → proxy ${metrics.cost_usd:.4f}"
            f" (model: {stats.get('model', '?')})",
            flush=True,
        )
    else:
        print(
            f"[eval-proxy] cost: proxy stats empty — keeping SDK cost ${sdk_cost:.4f}"
            f" (check EVAL_PROXY_COST_FILE / EVAL_PROXY_DEBUG=1)",
            flush=True,
        )
    if stats.get("model"):
        metrics.model = stats["model"]


class ClaudeSDKRunner(AgentRunner):
    """Agent runner using the Claude Agent SDK.

    This runner maintains a session after run() completes, allowing follow-up
    queries via query() method. This is useful for fixer loops that need to
    continue the conversation. Call close() when done to clean up.

    Security:
        By default, applies security rules to:
        - Block dangerous bash commands (rm, rmdir, chmod, sudo, etc.)
        - Restrict file access to the working directory only
        - Block reading/writing to system directories

    Args:
        sandbox: Enable sandbox mode for OS-level bash isolation.
        permission_mode: Permission mode ('default', 'acceptEdits', 'bypassPermissions').
        permission_allow: List of additional permission rules to pre-approve.
        permission_deny: List of additional permission rules to block.
        system_prompt: Optional custom system prompt.
        use_default_security: If True (default), applies DEFAULT_DENY_RULES.
        allowed_paths: Additional paths to allow file access to (e.g., repo root).
        allow_interrupt: If True (default), Ctrl+C pauses agent for user guidance.
    """

    _permission_mode: PermissionMode  # Class-level type hint for mypy

    def __init__(
        self,
        sandbox: bool = True,
        permission_mode: PermissionMode = "acceptEdits",
        permission_allow: Optional[List[str]] = None,
        permission_deny: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        use_default_security: bool = True,
        allowed_paths: Optional[List[Path]] = None,
        allow_interrupt: bool = True,
        mcp_servers: Optional[Dict[str, Any]] = None,
        sdk_hooks: Optional[Dict[str, List[HookCallback]]] = None,
        extra_env: Optional[Dict[str, str]] = None,
        signal_dirs: Optional[List[Path]] = None,
    ):
        self._sandbox = sandbox
        self._permission_mode: PermissionMode = permission_mode
        self._permission_allow = permission_allow or []
        self._permission_deny = permission_deny or []
        self._system_prompt = system_prompt
        self._use_default_security = use_default_security
        self._allowed_paths = allowed_paths or []
        self._allow_interrupt = allow_interrupt
        self._mcp_servers = mcp_servers or {}
        # Hooks keyed by SDK event name (e.g. "PreToolUse", "Stop"). The
        # SDKHookLoader returns this shape based on each builder's declared
        # `events` metadata.
        self._sdk_hooks: Dict[str, List[HookCallback]] = sdk_hooks or {}
        self._extra_env = extra_env or {}
        self._signal_dirs = signal_dirs or []

        # Session state (created during run, reused for query)
        self._session: Optional[Session] = None
        self._logger: Optional[AgentLogger] = None
        self._emitter: Optional[EventEmitter] = None
        self._model: str = "sonnet"

        # Store last options for logging via get_config()
        self._last_options: Optional[ClaudeAgentOptions] = None
        self._last_working_dir: Optional[Path] = None

    @property
    def provider_name(self) -> str:
        return "claude_sdk"

    @property
    def session_id(self) -> Optional[str]:
        """Get the current session ID (available after run())."""
        return self._session.session_id if self._session else None

    @property
    def has_active_session(self) -> bool:
        """Check if there's an active session for follow-up queries."""
        return self._session is not None and self._session.is_connected

    def supports_resume(self) -> bool:
        return True

    def supports_structured_output(self) -> bool:
        return True

    def run(
        self,
        prompt: str,
        working_directory: Path,
        model: str = "sonnet",
        max_turns: int = 100,
        timeout_minutes: int = 30,
        output_schema: Optional[Type[BaseModel]] = None,
        emitter: Optional[EventEmitter] = None,
        log_dir: Optional[Path] = None,
        resume_session_id: Optional[str] = None,
    ) -> AgentResult:
        """Run an agent using the Claude Agent SDK.

        Creates a new session. The session remains open after this call,
        allowing follow-up queries via query(). Call close() when done.

        Returns:
            AgentResult with success status, output, and metrics.
        """
        return asyncio.run(
            self._run_async(
                prompt=prompt,
                working_directory=working_directory,
                model=model,
                max_turns=max_turns,
                timeout_minutes=timeout_minutes,
                output_schema=output_schema,
                emitter=emitter,
                log_dir=log_dir,
                resume_session_id=resume_session_id,
            )
        )

    def query(
        self,
        prompt: str,
        output_schema: Optional[Type[BaseModel]] = None,
        timeout_minutes: int = 10,
        log_dir: Optional[Path] = None,
    ) -> AgentResult:
        """Send a follow-up query to the same session.

        Must be called after run() while the session is still active.
        Useful for fixer loops that need to continue the conversation.

        Raises:
            RuntimeError: If no active session exists.
        """
        if not self._session or not self._session.is_connected:
            raise RuntimeError("No active session. Call run() first.")

        return asyncio.run(
            self._query_async(
                prompt=prompt,
                output_schema=output_schema,
                timeout_minutes=timeout_minutes,
                log_dir=log_dir,
            )
        )

    def close(self) -> None:
        """Close the session and clean up resources."""
        if self._session:
            try:
                asyncio.run(self._session.close())
            except RuntimeError:
                # asyncio.run() fails if there is already a running loop (e.g.
                # ddtrace asyncio instrumentation). Fall back to the existing loop.
                # If there is no current event loop (e.g. ThreadPoolExecutor threads
                # in Python 3.10+), create a temporary one just for cleanup.
                try:
                    loop = asyncio.get_event_loop()
                    if not loop.is_closed():
                        loop.run_until_complete(self._session.close())
                except RuntimeError:
                    # No current event loop in this thread — create one for cleanup.
                    try:
                        loop = asyncio.new_event_loop()
                        try:
                            loop.run_until_complete(self._session.close())
                        finally:
                            loop.close()
                    except Exception as e:
                        logger.warning("Session close failed, resources may be leaked: %s", e)
                except Exception as e:
                    logger.warning("Session close failed, resources may be leaked: %s", e)
            self._session = None
        if self._logger:
            self._logger.close()
            self._logger = None

    async def _run_async(
        self,
        prompt: str,
        working_directory: Path,
        model: str = "sonnet",
        max_turns: int = 100,
        timeout_minutes: int = 30,
        output_schema: Optional[Type[BaseModel]] = None,
        emitter: Optional[EventEmitter] = None,
        log_dir: Optional[Path] = None,
        resume_session_id: Optional[str] = None,
    ) -> AgentResult:
        """Async implementation of run()."""
        working_directory.mkdir(parents=True, exist_ok=True)

        # Store for follow-up queries
        self._model = model
        self._emitter = emitter
        self._logger = AgentLogger(log_dir=log_dir, emitter=emitter)

        # Build SDK options
        options = self._build_options(
            model=model,
            max_turns=max_turns,
            working_directory=working_directory,
            output_schema=output_schema,
            resume_session_id=resume_session_id,
        )

        # Log config BEFORE running (helps debug failures)
        if log_dir:
            self.log_config(log_dir)

        # Create and connect session
        self._session = Session(
            options=options,
            logger=self._logger,
            emitter=emitter,
            allow_interrupt=self._allow_interrupt,
        )
        await self._session.connect()

        # Reset proxy cost accumulator so this run gets a clean slate.
        reset_proxy_stats()

        # Execute query
        metrics = AgentMetrics(provider="claude_sdk", model=model)
        success = await self._session.query(prompt, metrics, timeout_minutes)

        # If routing through a non-Anthropic backend via the eval proxy, read the
        # real gateway cost and model — the SDK reports Anthropic pricing which is wrong.
        _apply_proxy_cost_override(metrics)

        # Build result
        return self._build_result(success, metrics, output_schema)

    async def _query_async(
        self,
        prompt: str,
        output_schema: Optional[Type[BaseModel]] = None,
        timeout_minutes: int = 10,
        log_dir: Optional[Path] = None,
    ) -> AgentResult:
        """Async implementation of query()."""
        if not self._session:
            raise RuntimeError("No active session.")

        # Update logger if new log_dir provided
        if log_dir and self._logger:
            self._logger.close()
            self._logger = AgentLogger(log_dir=log_dir, emitter=self._emitter)
            # Update session's logger reference
            self._session._logger = self._logger

        # Reconnect the session - needed because asyncio.run() in run() closed
        # the event loop, making the old async connection stale. This creates
        # a fresh connection while resuming the same conversation.
        await self._session.reconnect()

        reset_proxy_stats()

        metrics = AgentMetrics(provider="claude_sdk", model=self._model)
        success = await self._session.query(prompt, metrics, timeout_minutes)

        _apply_proxy_cost_override(metrics)

        return self._build_result(success, metrics, output_schema)

    def _build_result(
        self,
        success: bool,
        metrics: AgentMetrics,
        output_schema: Optional[Type[BaseModel]] = None,
    ) -> AgentResult:
        """Build AgentResult from session state."""
        if not self._session:
            return AgentResult(success=False, error="No session", metrics=metrics)

        raw_output = self._session.raw_structured_output
        structured_output = None

        if output_schema and raw_output:
            raw_output = unwrap_structured_output(raw_output, output_schema, self._emitter)
            try:
                structured_output = output_schema.model_validate(raw_output)
            except Exception as e:
                # Expected: agent may not have produced valid structured output
                # structured_output remains None and will be handled by caller
                if self._emitter:
                    error_msg = str(e)[:200]  # Truncate long error messages
                    self._emitter.emit(
                        "warn",
                        message=f"Agent did not produce valid structured output. "
                        f"Expected schema: {output_schema.__name__}, Error: {error_msg}",
                    )
                pass

        # On timeout/error the SDK never sends a ResultMessage with
        # total_cost_usd — estimate from the per-turn token counts we accumulated.
        metrics.estimate_cost_from_tokens()

        error = None
        if not success:
            if metrics.error_subtype == "timeout":
                error = "Timed out"
            elif metrics.is_error:
                error = "Agent error"

        return AgentResult(
            success=success and not metrics.is_error,
            output=self._session.final_output,
            error=error,
            files_modified=self._session.files_modified,
            structured_output=structured_output,
            raw_structured_output=raw_output,
            metrics=metrics,
            session_id=self._session.session_id,
        )

    def _build_options(
        self,
        model: str,
        max_turns: int,
        working_directory: Path,
        output_schema: Optional[Type[BaseModel]] = None,
        resume_session_id: Optional[str] = None,
    ) -> ClaudeAgentOptions:
        """Build ClaudeAgentOptions for the SDK."""
        # When ANTHROPIC_MODEL is set (AI Gateway mode), resolve shortnames to fully-qualified
        # model IDs by querying /v1/models. Already-qualified IDs pass through unchanged.
        if os.environ.get("ANTHROPIC_MODEL"):
            model = resolve_model_alias(model)

        # Explicitly typed to satisfy ClaudeAgentOptions which expects list[str | Path]
        add_dirs: list[str | Path] = [str(p.resolve()) for p in self._allowed_paths]

        # Build PreToolUse hook to allow access to specific paths before deny rules.
        # This is necessary because deny rules like 'Read(/Users/**)' are evaluated
        # before allow rules, so we need a hook to override them for allowed paths.
        all_allowed_paths = [working_directory] + self._allowed_paths
        pre_tool_hook = build_pre_tool_use_hook(all_allowed_paths)

        # Build sandbox settings.
        # The sandbox provides OS-level isolation (macOS seatbelt/Linux bubblewrap).
        # SDK-level settings like add_dirs and ignoreViolations don't affect the
        # OS-level sandbox restrictions. To run toolkit scripts (dd-debug.js, etc.)
        # that live outside the working directory, we exclude node from the sandbox.
        # Package installation (npm install, yarn add) should be done OUTSIDE the agent
        # using repo_adapter.install_test_package() before running sandboxed agents.
        if self._sandbox:
            sandbox_settings = SandboxSettings(
                enabled=True,
                # Exclude runtime commands from sandbox to allow:
                # - Toolkit scripts (dd-debug.js, etc.) outside cwd
                # - Network access for npm registry queries (npm info, npm view)
                # - Python test runners (scripts/ddtest, riot) that need full env access
                # Note: Package installation should be done outside the agent
                excludedCommands=["node", "npm", "yarn", "bun", "python", "scripts/ddtest", "riot"],
                # Allow binding to localhost ports (macOS only).
                # Needed for dd-debug.js which starts a debug listener.
                network={"allowLocalBinding": True},
            )
        else:
            sandbox_settings = SandboxSettings(enabled=False)

        # Signal injection hook — checks signal.md in each of signal_dirs before each tool call.
        # Fires first so supervisor guidance is surfaced before any security check runs.
        # Falls back to [working_directory] when no explicit dirs are configured, ensuring
        # the hook always has at least one location to watch.
        effective_signal_dirs = self._signal_dirs if self._signal_dirs else [working_directory]
        signal_hook = build_signal_hook(effective_signal_dirs)

        # Built-in PreToolUse hook + any user PreToolUse hooks from SDKHookLoader.
        # Other event categories (Stop, SubagentStop, etc.) come from self._sdk_hooks
        # and get attached below.
        pre_tool_user_hooks = list(self._sdk_hooks.get("PreToolUse", []))
        pre_tool_use_hooks = [
            HookMatcher(
                matcher="Read|Write|Edit|Bash|Glob",
                hooks=[signal_hook, pre_tool_hook] + pre_tool_user_hooks,
            )
        ]

        # Add structured output unwrap hook when output_schema is provided
        if output_schema is not None:
            so_hook = build_structured_output_hook(
                output_schema,
                emitter_callback=self._log_hook_event,
            )
            pre_tool_use_hooks.append(
                HookMatcher(
                    matcher="StructuredOutput",
                    hooks=[so_hook],
                )
            )

        # Build the full hooks dict, registering each event group from sdk_hooks
        # against its matching ClaudeAgentOptions.hooks key. PreToolUse is already
        # built above (with the built-in hook prepended); other events pass through.
        sdk_hooks_dict: Dict[str, List[HookMatcher]] = {
            "PreToolUse": pre_tool_use_hooks,
        }
        for event, hooks in self._sdk_hooks.items():
            if event == "PreToolUse":
                continue  # already wired in above
            if not hooks:
                continue
            sdk_hooks_dict[event] = [HookMatcher(hooks=list(hooks))]

        options = ClaudeAgentOptions(
            model=model,
            max_turns=max_turns,
            cwd=str(working_directory.resolve()),
            add_dirs=add_dirs,
            permission_mode=self._permission_mode,
            sandbox=sandbox_settings,
            # 'local' loads .claude/ from cwd (where skills are installed)
            # 'project' loads .claude/ from project root (for CLAUDE.md, settings)
            setting_sources=["local", "project"],
            # SDK types the `hooks` kwarg with a Literal-keyed dict, but the
            # SDKHookLoader returns a generic str→hooks mapping so new SDK
            # event types can be added without changing the loader. Cast here
            # — runtime validates the event names against ClaudeAgentOptions.
            hooks=cast(Any, sdk_hooks_dict),
            mcp_servers=self._mcp_servers if self._mcp_servers else {},
            # SDK default (1MB) is too small for orchestrator steps whose stream
            # messages bundle subagent summaries and large tool outputs.
            max_buffer_size=10 * 1024 * 1024,
        )

        # Add permission settings
        settings = build_permission_settings(
            working_directory=working_directory,
            allowed_paths=self._allowed_paths,
            use_default_security=self._use_default_security,
            custom_allow=self._permission_allow,
            custom_deny=self._permission_deny,
        )
        if settings:
            options.settings = json.dumps(settings)

        if self._system_prompt:
            options.system_prompt = self._system_prompt

        if output_schema is not None:
            options.output_format = {
                "type": "json_schema",
                "schema": make_flexible_schema(output_schema),
            }

        if resume_session_id:
            options.resume = resume_session_id

        env = {"CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1"}
        if self._extra_env:
            env.update(self._extra_env)
        options.env = env

        # Store for get_config()
        self._last_options = options
        self._last_working_dir = working_directory

        return options

    def _log_hook_event(
        self,
        hook_name: str,
        tool_name: str = "",
        action: str = "",
        detail: str = "",
        tool_input: Optional[Dict] = None,
        hook_result: Optional[Dict] = None,
    ) -> None:
        """Log a hook event to the agent trace log.

        Args:
            hook_name: Name of the hook (e.g. "structured_output_unwrap").
            tool_name: Tool that triggered the hook.
            action: What the hook did (e.g. "unwrapped", "denied", "allowed").
            detail: Additional detail string.
            tool_input: The tool_input that triggered the hook.
            hook_result: The hook's return value (e.g. updatedInput).
        """
        if self._logger:
            self._logger.log_message({
                "type": "hook",
                "hook_name": hook_name,
                "tool_name": tool_name,
                "action": action,
                "detail": detail,
                "tool_input": tool_input,
                "hook_result": hook_result,
            })

    def get_config(self) -> dict:
        """Return the runner's configuration for logging.

        Returns all SDK configuration including sandbox settings,
        permission rules, and allowed paths.
        """
        config: dict = {
            "provider": self.provider_name,
            # Runner constructor args
            "runner": {
                "sandbox": self._sandbox,
                "permission_mode": self._permission_mode,
                "permission_allow": self._permission_allow,
                "permission_deny": self._permission_deny,
                "system_prompt": bool(self._system_prompt),  # Don't log full prompt
                "use_default_security": self._use_default_security,
                "allowed_paths": [str(p) for p in self._allowed_paths],
                "allow_interrupt": self._allow_interrupt,
            },
        }

        if self._last_working_dir:
            config["working_directory"] = str(self._last_working_dir.resolve())

        if self._last_options:
            config["sdk_options"] = self._serialize_options(self._last_options)

        return config

    def _serialize_options(self, opts: ClaudeAgentOptions) -> Dict[str, Any]:
        """Serialize ClaudeAgentOptions to a JSON-compatible dict."""
        result: Dict[str, Any] = {}

        # Iterate through all annotated fields
        for key in opts.__annotations__:
            if not hasattr(opts, key):
                continue

            val = getattr(opts, key)
            if val is None:
                continue

            # Skip callables (hooks, callbacks, stderr handler)
            if callable(val) and not isinstance(val, dict):
                continue

            # Skip file-like objects (stderr, debug_stderr)
            if isinstance(val, io.IOBase):
                result[key] = f"<{type(val).__name__}>"
                continue

            # Handle special types
            if key == "hooks":
                # Just show which hooks are configured with counts
                result[key] = {k: len(v) for k, v in val.items()} if val else None
            elif key == "settings" and isinstance(val, str):
                try:
                    result[key] = json.loads(val)
                except json.JSONDecodeError:
                    result[key] = val
            elif key == "sandbox" and val:
                result[key] = dict(val)
            elif isinstance(val, Path):
                result[key] = str(val)
            elif isinstance(val, list):
                result[key] = [str(v) if isinstance(v, Path) else v for v in val]
            elif isinstance(val, dict):
                # Handle nested dicts (env, extra_args, etc.)
                result[key] = {k: str(v) if isinstance(v, Path) else v for k, v in val.items()}
            else:
                # Try to serialize, fall back to string representation
                try:
                    json.dumps(val)  # Test if serializable
                    result[key] = val
                except (TypeError, ValueError):
                    result[key] = f"<{type(val).__name__}>"

        return result
