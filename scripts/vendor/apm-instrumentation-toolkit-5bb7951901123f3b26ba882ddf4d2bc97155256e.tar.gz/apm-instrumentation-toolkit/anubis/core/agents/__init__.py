"""Agent utilities - provider-agnostic agent interface.

Structure:
- models.py: Core models (AgentResult, AgentMetrics)
- spawn.py: Main entry point for spawning agents
- runners/: Runner infrastructure (base class, utils, provider implementations)
"""

from .models import AgentMetrics, AgentResult
from .runners import AgentRunner
from .spawn import spawn_agent

__all__ = [
    "AgentMetrics",
    "AgentResult",
    "AgentRunner",
    "spawn_agent",
]
