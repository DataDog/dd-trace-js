"""Eval-mode MITM proxy manager.

Starts a local mitmproxy instance (eval_proxy_addon.py) to intercept Claude
binary requests and inject AI Gateway routing headers. For non-Anthropic model
overrides, the addon also translates between Anthropic and OpenAI wire formats.

The Claude binary ignores ANTHROPIC_CUSTOM_HEADERS for non-auth headers but
respects HTTPS_PROXY + NODE_EXTRA_CA_CERTS, so MITM injection is the only path.

Delete this file, eval_proxy_addon.py, and the call in agent.py::_build_extra_env()
to remove all proxy functionality.
"""

import atexit
import json
import logging
import os
import socket
import ssl
import subprocess
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_INJECT_HEADERS: Dict[str, str] = {
    "x-target-account": "eval",
    "source": "apm-ai-integration-toolkit-evals",
    "org-id": "2",
}

# AWS Bedrock US East (N. Virginia) on-demand pricing, $/M tokens: [input, output, cache_read].
# Source: https://aws.amazon.com/bedrock/pricing/ — these are the actual rates Datadog AI Gateway
# uses via its Bedrock integration. Anthropic models are NOT listed here; their cost is tracked
# automatically by AI Gateway's LLMObs integration, not by the proxy cost file.
# Model IDs are exact AI Gateway IDs (verified via /v1/models endpoint, April 2026).
# Prefix matching in the addon covers minor variant suffixes.
# Override at runtime with EVAL_PROXY_MODEL_PRICING (JSON) env var.
# Note: Kimi K2.6 and DeepSeek not yet routed through Datadog AI Gateway as of April 2026.
_MODEL_PRICING: Dict[str, list] = {
    # Moonshot AI (Kimi) — strong coding/agentic MoE models
    "bedrock/moonshotai.kimi-k2.5": [0.60, 3.00, 0.0],
    "bedrock/moonshotai.kimi-k2-thinking": [0.60, 2.50, 0.0],
    # Z.AI / Zhipu (GLM) — provider prefix is "zai" not "z-ai"
    "bedrock/zai.glm-5": [1.00, 3.20, 0.0],
    "bedrock/zai.glm-4.7": [0.60, 2.20, 0.0],
    "bedrock/zai.glm-4.7-flash": [0.07, 0.40, 0.0],
    # Qwen (Alibaba) — exact AI Gateway IDs include full spec suffix
    "bedrock/qwen.qwen3-coder-480b-a35b-instruct": [0.22, 1.80, 0.0],
    "bedrock/qwen.qwen3-coder-next": [0.50, 1.20, 0.0],
    "bedrock/qwen.qwen3-coder-30b-a3b-instruct": [0.15, 1.20, 0.0],
    "bedrock/qwen.qwen3-vl-235b-a22b-instruct": [0.53, 2.66, 0.0],
    "bedrock/qwen.qwen3-235b-a22b-2507": [0.53, 2.66, 0.0],
    "bedrock/qwen.qwen3-next-80b-a3b-instruct": [0.15, 1.20, 0.0],
    "bedrock/qwen.qwen3-32b": [0.15, 1.20, 0.0],
    # Mistral — Devstral/Magistral for coding, Large for general, Ministral for edge
    "bedrock/mistral.mistral-large-3-675b-instruct": [0.50, 1.50, 0.0],
    "bedrock/mistral.devstral-2-123b": [0.40, 2.00, 0.0],
    "bedrock/mistral.magistral-small-2509": [0.50, 1.50, 0.0],
    "bedrock/mistral.ministral-3-14b-instruct": [0.20, 0.20, 0.0],
    "bedrock/mistral.ministral-3-8b-instruct": [0.15, 0.15, 0.0],
    "bedrock/mistral.ministral-3-3b-instruct": [0.10, 0.10, 0.0],
    # Google Gemma (open weights, low cost) — IDs include -it (instruction-tuned) suffix
    "bedrock/google.gemma-3-27b-it": [0.23, 0.38, 0.0],
    "bedrock/google.gemma-3-12b-it": [0.09, 0.29, 0.0],
    "bedrock/google.gemma-3-4b-it": [0.04, 0.08, 0.0],
    # NVIDIA Nemotron — note: provider prefix order is nemotron-{type}-{gen}, not nemotron-{gen}-{type}
    "bedrock/nvidia.nemotron-super-3-120b": [0.15, 0.65, 0.0],
    "bedrock/nvidia.nemotron-nano-3-30b": [0.06, 0.24, 0.0],
    "bedrock/nvidia.nemotron-nano-9b-v2": [0.06, 0.23, 0.0],
    # MiniMax — provider prefix is minimax.minimax-m2* (double "minimax")
    "bedrock/minimax.minimax-m2.5": [0.30, 1.20, 0.0],
    "bedrock/minimax.minimax-m2.1": [0.30, 1.20, 0.0],
    "bedrock/minimax.minimax-m2": [0.30, 1.20, 0.0],
    # OpenAI open-source models on Bedrock (o-series open weights)
    "bedrock/openai.gpt-oss-120b": [0.15, 0.60, 0.0],
    "bedrock/openai.gpt-oss-20b": [0.07, 0.20, 0.0],
    # OpenAI (via AI Gateway direct routing, not Bedrock)
    # Prices shown for ≤272K tokens; doubles above that threshold. Source: openai.com/api/pricing
    "openai/gpt-5.5": [5.00, 30.00, 0.0],
    "openai/gpt-5.5-pro": [30.00, 180.00, 0.0],
    "openai/gpt-5.4": [2.50, 15.00, 0.0],
    "openai/gpt-5.4-pro": [30.00, 180.00, 0.0],
    "openai/gpt-5.4-mini": [0.75, 4.50, 0.0],
    "openai/gpt-5.4-nano": [0.20, 1.25, 0.0],
    "openai/o3": [2.00, 8.00, 0.0],
    "openai/o3-pro": [20.00, 80.00, 0.0],
    "openai/o4-mini": [1.10, 4.40, 0.0],
    # Google Gemini (via AI Gateway Vertex AI routing)
    # Prices shown for ≤200K tokens; rises 2x input / 1.5x output above that. Source: ai.google.dev/gemini-api/docs/pricing
    "gemini/gemini-3.1-pro-preview": [2.00, 12.00, 0.0],
    "gemini/gemini-3.1-flash-lite-preview": [0.25, 1.50, 0.0],
    "gemini/gemini-3-pro-preview": [2.00, 12.00, 0.0],
    "gemini/gemini-3-flash-preview": [0.50, 3.00, 0.0],
    "gemini/gemini-2.5-pro": [1.25, 10.00, 0.0],
    "gemini/gemini-2.5-flash": [0.30, 2.50, 0.0],
    "gemini/gemini-2.5-flash-lite": [0.10, 0.40, 0.0],
}

_ADDON_PATH = Path(__file__).parent / "eval_proxy_addon.py"

_proxy_proc: Optional[subprocess.Popen] = None
_proxy_port: Optional[int] = None
_proxy_cost_file: Optional[str] = None
_proxy_start_lock = threading.Lock()  # serializes proxy startup across concurrent threads
_cost_file_lock = threading.Lock()  # serializes reset/read across concurrent agent runs

# Pinned fallbacks — used when the models endpoint is unreachable.
_FALLBACK_ALIASES: Dict[str, str] = {
    "sonnet": "anthropic/claude-sonnet-4-6",
    "opus": "anthropic/claude-opus-4-7",
    "haiku": "anthropic/claude-haiku-4-5-20251001",
}
_resolved_aliases: Optional[Dict[str, str]] = None


def resolve_model_alias(shortname: str) -> str:
    """Resolve a shortname (sonnet/opus/haiku) to a fully-qualified AI Gateway model ID.

    If ANTHROPIC_MODEL is set to any fully-qualified model ID (contains '/'), that value
    overrides all shortnames — useful for testing a specific model end-to-end without
    changing step configs (e.g. anthropic/claude-haiku-4-5-20251001 or gemini/...).

    Otherwise queries /v1/models on the first call and caches the result.
    Falls back to pinned defaults if the gateway is unreachable.  Fully-qualified IDs
    (already containing '/') and unknown strings pass through unchanged.
    """
    if "/" in shortname:
        return shortname  # already fully-qualified
    env_model = os.environ.get("ANTHROPIC_MODEL", "")
    if env_model and "/" in env_model:
        return env_model  # explicit model override — use for all shortnames
    global _resolved_aliases
    if _resolved_aliases is None:
        _resolved_aliases = _fetch_model_aliases()
    return _resolved_aliases.get(shortname, shortname)


def _fetch_model_aliases() -> Dict[str, str]:
    """Query AI Gateway /v1/models and build family-shortname → newest-model-ID table.

    Routes through the local mitmproxy (HTTPS_PROXY) so authanywhere injects auth.
    Sorts model IDs lexicographically — newer versions are alphabetically greater.
    Falls back to _FALLBACK_ALIASES on any error.
    """
    base_url = os.environ.get("ANTHROPIC_BASE_URL", "").rstrip("/")
    proxy_url = os.environ.get("HTTPS_PROXY", "")
    if not base_url or not proxy_url:
        logger.debug("model alias fetch skipped (no ANTHROPIC_BASE_URL / HTTPS_PROXY)")
        return dict(_FALLBACK_ALIASES)

    ca_cert = _ca_cert_path()
    ssl_ctx = ssl.create_default_context()
    if ca_cert.exists():
        ssl_ctx.load_verify_locations(str(ca_cert))

    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({"https": proxy_url, "http": proxy_url}),
        urllib.request.HTTPSHandler(context=ssl_ctx),
    )
    try:
        req = urllib.request.Request(
            f"{base_url}/v1/models",
            headers={"x-api-key": "proxy-injected", "anthropic-version": "2023-06-01"},
        )
        with opener.open(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())

        model_ids = [m["id"] for m in data.get("data", [])]
        aliases: Dict[str, str] = {}
        for family in ("sonnet", "opus", "haiku"):
            matches = sorted(m for m in model_ids if family in m.lower())
            if matches:
                aliases[family] = matches[-1]  # lexicographically newest
        for k, v in _FALLBACK_ALIASES.items():
            aliases.setdefault(k, v)

        logger.debug("model aliases: %s", ", ".join(f"{k}→{v}" for k, v in sorted(aliases.items())))
        return aliases
    except Exception as exc:
        logger.debug("model alias fetch failed (%s) — using pinned fallbacks", exc)
        return dict(_FALLBACK_ALIASES)


def get_proxy_stats() -> Dict[str, Any]:
    """Return accumulated cost/model stats from the proxy, or empty dict if unavailable."""
    with _cost_file_lock:
        if not _proxy_cost_file:
            return {}
        try:
            with open(_proxy_cost_file) as f:
                data: Dict[str, Any] = json.load(f)
                return data
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}


def reset_proxy_stats() -> None:
    """Delete the proxy cost file to start fresh before a new agent run."""
    with _cost_file_lock:
        if _proxy_cost_file:
            try:
                os.unlink(_proxy_cost_file)
            except OSError as e:
                logger.debug("Failed to reset proxy cost file: %s", e)


def _stop_proxy() -> None:
    global _proxy_proc, _proxy_port, _proxy_cost_file
    if _proxy_proc is not None:
        try:
            _proxy_proc.terminate()
            _proxy_proc.wait(timeout=5)
        except Exception as e:
            logger.debug("Failed to stop proxy process: %s", e)
        _proxy_proc = None
        _proxy_port = None
    if _proxy_cost_file:
        try:
            os.unlink(_proxy_cost_file)
        except OSError as e:
            logger.debug("Failed to remove proxy cost file: %s", e)
        _proxy_cost_file = None


def ensure_eval_proxy_running() -> Optional[Dict[str, str]]:
    """Start the eval MITM proxy if not already running.

    Idempotent — safe to call for every agent spawn. Returns env vars to inject
    into the subprocess (HTTPS_PROXY, NODE_EXTRA_CA_CERTS), or None if mitmdump
    is unavailable or startup fails.

    Thread-safe: concurrent callers (e.g. 10 eval workers) serialize through
    _proxy_start_lock so only one mitmproxy instance starts. Without the lock,
    each thread races to start its own mitmproxy, and each instance regenerates
    the CA cert at ~/.mitmproxy/ — the last writer wins, causing SSL verification
    failures for agents connected to earlier proxies.
    """
    global _proxy_proc, _proxy_port, _proxy_cost_file

    # Fast path (no lock): proxy already running — return immediately.
    if _proxy_proc is not None and _proxy_proc.poll() is None and _proxy_port is not None:
        return _proxy_env(_proxy_port)

    with _proxy_start_lock:
        # Re-check under lock: another thread may have started the proxy while we waited.
        if _proxy_proc is not None and _proxy_proc.poll() is None and _proxy_port is not None:
            return _proxy_env(_proxy_port)

        if not _mitmdump_available():
            print(
                "[eval-proxy] mitmdump not found — header injection disabled\n"
                "             Install with: brew install mitmproxy",
                flush=True,
            )
            return None

        port = _free_port()
        print("  Starting eval proxy (mitmproxy)...", flush=True)

        fd, cost_file = tempfile.mkstemp(suffix=".json", prefix="anubis_eval_proxy_cost_")
        os.close(fd)
        os.unlink(cost_file)  # reserve path; addon creates it when there's data
        _proxy_cost_file = cost_file

        proc = subprocess.Popen(
            ["mitmdump", "--listen-port", str(port), "--quiet", "-s", str(_ADDON_PATH)],
            stdout=subprocess.DEVNULL,
            stderr=None,  # inherit parent stderr so addon logs are visible
            env={
                **os.environ,
                "EVAL_PROXY_COST_FILE": cost_file,
                "EVAL_PROXY_HEADERS": json.dumps(_INJECT_HEADERS),
                "EVAL_PROXY_MODEL_PRICING": os.environ.get("EVAL_PROXY_MODEL_PRICING")
                or json.dumps(_MODEL_PRICING),
            },
        )
        _proxy_proc = proc
        _proxy_port = port
        atexit.register(_stop_proxy)

        if not _wait_port_open(port):
            print("  ✗ eval proxy failed to start", flush=True)
            _stop_proxy()
            return None

        if not _wait_ca_cert():
            print("  ✗ eval proxy CA cert not generated", flush=True)
            _stop_proxy()
            return None

        # Install the CA into the system trust store as a safety net for any
        # subprocess that doesn't honor our per-language env vars (REQUESTS_CA_BUNDLE,
        # NODE_EXTRA_CA_CERTS, etc.). Best-effort: requires root + update-ca-trust.
        _install_ca_system_wide(_ca_cert_path())

        injected = ", ".join(f"{k}: {v}" for k, v in _INJECT_HEADERS.items())
        print(f"  ✓ eval proxy :{port}  [{injected}]", flush=True)
        return _proxy_env(port)


def _proxy_env(port: int) -> Dict[str, str]:
    """Env vars that route HTTPS through mitmproxy AND make every tool trust its CA.

    The mitmproxy CA must be advertised through several per-language env vars
    because each tool has its own trust store:
      - Node.js / Claude Code: NODE_EXTRA_CA_CERTS
      - Python (requests): REQUESTS_CA_BUNDLE
      - Python (ssl module): SSL_CERT_FILE
      - Go binaries (evalya, gh, gitleaks, etc.): SSL_CERT_FILE
      - curl: CURL_CA_BUNDLE
      - git: GIT_SSL_CAINFO

    Without all of these, agents that shell out to (say) git clone or
    evalya run hit "unable to get local issuer certificate" because
    mitmproxy is presenting its own self-signed cert and the tool's
    trust store hasn't seen it before. Anything still missing should
    fall back to system trust (set up at proxy start via update-ca-certificates
    when running as root in CI containers).
    """
    ca_cert = str(_ca_cert_path())
    return {
        "HTTPS_PROXY": f"http://127.0.0.1:{port}",
        "HTTP_PROXY": f"http://127.0.0.1:{port}",
        "NODE_EXTRA_CA_CERTS": ca_cert,
        "REQUESTS_CA_BUNDLE": ca_cert,
        "SSL_CERT_FILE": ca_cert,
        "CURL_CA_BUNDLE": ca_cert,
        "GIT_SSL_CAINFO": ca_cert,
    }


def _ca_cert_path() -> Path:
    return Path.home() / ".mitmproxy" / "mitmproxy-ca-cert.pem"


def _install_ca_system_wide(ca_cert: Path) -> None:
    """Install the mitmproxy CA into the system trust store (best-effort).

    Catches all the edge cases the per-language env vars miss:
    subprocesses that strip the env, tools that hardcode /etc/ssl paths,
    etc. Requires root and update-ca-certificates / trust-anchor — both
    available in our Ubuntu eval-runner image. Silent no-op everywhere else.
    """
    if not ca_cert.exists():
        return
    if os.geteuid() != 0:
        return
    targets = [
        Path("/usr/local/share/ca-certificates/mitmproxy.crt"),  # Debian/Ubuntu
        Path("/etc/pki/ca-trust/source/anchors/mitmproxy.pem"),  # RHEL/Fedora
    ]
    installed = False
    for target in targets:
        if not target.parent.exists():
            continue
        try:
            target.write_bytes(ca_cert.read_bytes())
            installed = True
        except OSError as e:
            logger.debug("Skipping CA cert install to %s: %s", target, e)
            continue
    if not installed:
        return
    for cmd in (["update-ca-certificates"], ["update-ca-trust", "extract"]):
        try:
            subprocess.run(cmd, check=False, capture_output=True, timeout=30)
            return
        except FileNotFoundError:
            logger.debug("CA trust update command not found: %s", cmd[0])
            continue


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _mitmdump_available() -> bool:
    try:
        subprocess.run(["mitmdump", "--version"], capture_output=True, check=True, timeout=5)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return False


def _wait_port_open(port: int, timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.25)
    return False


def _wait_ca_cert(timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    path = _ca_cert_path()
    while time.monotonic() < deadline:
        if path.exists():
            return True
        time.sleep(0.25)
    return False
