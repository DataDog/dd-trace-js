"""Output system with event emitter pattern.

This module provides:

- EventEmitter: Mixin for workflows to emit events
- TerminalListener: Rich console output (default)
- restore_terminal_for_input: Restore terminal to usable state
- terminal_guard: Context manager for scoped terminal protection
"""

from .emitter import EventEmitter, Listener
from .file_listener import FileListener
from .terminal import TerminalListener
from .terminal_state import restore_terminal_for_input, terminal_guard

__all__ = [
    "EventEmitter",
    "FileListener",
    "Listener",
    "TerminalListener",
    "restore_terminal_for_input",
    "terminal_guard",
]
