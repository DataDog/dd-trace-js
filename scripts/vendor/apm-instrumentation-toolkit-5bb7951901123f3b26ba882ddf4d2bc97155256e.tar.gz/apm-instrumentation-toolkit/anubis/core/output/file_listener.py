"""File-based event listener for headless/CI workflows.

Writes all emitted events as JSONL to a log file so that headless runs
(e.g. eval matrix with headless=True) produce debuggable output instead
of silently discarding ctx.info()/ctx.warn()/ctx.error() calls.
"""

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class FileListener:
    """Writes workflow events as JSONL to a file.

    Each event becomes one JSON line with timestamp, event name, and payload.
    Thread-safe — multiple steps in the same workflow can emit concurrently.
    """

    def __init__(self, log_dir: Path):
        self._log_path = log_dir / "workflow.log.jsonl"
        self._lock = threading.Lock()
        log_dir.mkdir(parents=True, exist_ok=True)

    def _write(self, event: str, **kwargs: Any) -> None:
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event": event,
            **{k: _safe_serialize(v) for k, v in kwargs.items()},
        }
        line = json.dumps(record, default=str)
        with self._lock:
            with open(self._log_path, "a") as f:
                f.write(line + "\n")

    # Flow events
    def on_workflow_start(self, name: str, **kw: Any) -> None:
        self._write("workflow_start", name=name, **kw)

    def on_workflow_complete(self, success: bool, message: Optional[str] = None, **kw: Any) -> None:
        self._write("workflow_complete", success=success, message=message, **kw)

    def on_phase_start(
        self, phase: str, number: Optional[int] = None, total: Optional[int] = None, **kw: Any
    ) -> None:
        self._write("phase_start", phase=phase, number=number, total=total, **kw)

    def on_phase_complete(self, phase: str, success: bool = True, **kw: Any) -> None:
        self._write("phase_complete", phase=phase, success=success, **kw)

    def on_phase_skip(
        self,
        phase: str,
        number: Optional[int] = None,
        total: Optional[int] = None,
        reason: Optional[str] = None,
        **kw: Any,
    ) -> None:
        self._write("phase_skip", phase=phase, number=number, total=total, reason=reason, **kw)

    def on_step_start(self, step: str, **kw: Any) -> None:
        self._write("step_start", step=step, **kw)

    def on_stage_start(self, stage: str, **kw: Any) -> None:
        self._write("stage_start", stage=stage, **kw)

    def on_stage_complete(self, stage: str, success: bool = True, **kw: Any) -> None:
        self._write("stage_complete", stage=stage, success=success, **kw)

    # Message events
    def on_info(self, message: str, **kw: Any) -> None:
        self._write("info", message=message, **kw)

    def on_success(self, message: str, **kw: Any) -> None:
        self._write("success", message=message, **kw)

    def on_warn(self, message: str, **kw: Any) -> None:
        self._write("warn", message=message, **kw)

    def on_error(self, message: str, exception: Optional[Exception] = None, **kw: Any) -> None:
        self._write("error", message=message, exception=str(exception) if exception else None, **kw)

    # Data events
    def on_detail(self, label: str, value: str, **kw: Any) -> None:
        self._write("detail", label=label, value=value, **kw)

    # Agent events
    def on_agent_start(self, task: str, **kw: Any) -> None:
        self._write("agent_start", task=task, **kw)

    def on_agent_complete(self, task: str, success: bool, cost: float = 0, **kw: Any) -> None:
        self._write("agent_complete", task=task, success=success, cost=cost, **kw)

    # Cost events
    def on_cost_summary(
        self, total_cost: float, total_duration: float, total_turns: int, **kw: Any
    ) -> None:
        self._write(
            "cost_summary",
            total_cost=total_cost,
            total_duration=total_duration,
            total_turns=total_turns,
            **kw,
        )


def _safe_serialize(v: Any) -> Any:
    """Convert value to JSON-safe form."""
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, (list, tuple)):
        return [_safe_serialize(i) for i in v]
    if isinstance(v, dict):
        return {str(k): _safe_serialize(val) for k, val in v.items()}
    return str(v)
