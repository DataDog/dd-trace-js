"""Event emitter mixin for workflows.

Provides a simple event system that decouples workflow logic from presentation.
Workflows emit events, listeners handle display/logging/etc.

Event Categories:
    1. Flow events - workflow/phase/step lifecycle
    2. Message events - info/success/warn/error
    3. Data events - structured output (files, tests, etc.)
"""

import inspect
import logging
from typing import Any, Dict, List, Optional, Protocol

logger = logging.getLogger(__name__)


class Listener(Protocol):
    """Protocol for event listeners.

    Listeners implement on_* methods for events they care about.
    Unknown events are silently ignored.
    """

    pass


def _filter_kwargs(handler: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Return only the kwargs that *handler* accepts.

    If the handler accepts **kwargs (VAR_KEYWORD), all kwargs are forwarded.
    Otherwise only named parameters present in the signature are kept.
    """
    try:
        sig = inspect.signature(handler)
    except (ValueError, TypeError):
        return kwargs

    if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
        return kwargs

    accepted = set(sig.parameters.keys()) - {"self"}
    return {k: v for k, v in kwargs.items() if k in accepted}


class EventEmitter:
    """Mixin that allows classes to emit events to listeners.

    Usage:
        class MyWorkflow(EventEmitter):
            def run(self):
                self.emit('workflow_start', name='kafkajs')
                self.emit('phase_start', phase='Analyze')
                # ... work ...
                self.emit('files_created', files=['plugin.js'])
                self.emit('phase_complete', phase='Analyze')
                self.emit('workflow_complete', success=True)

    Event Types:

        Flow Events (lifecycle):
            workflow_start(name)
            workflow_complete(success)
            phase_start(phase, number=None, total=None)
            phase_complete(phase, success=True)
            step_start(step)
            step_complete(step, success=True)

        Message Events:
            info(message)
            success(message)
            warn(message)
            error(message, exception=None)

        Data Events (structured output):
            files_created(files: List[str])
            files_modified(files: List[str])
            files_deleted(files: List[str])
            tests_result(passed: int, failed: int, skipped: int = 0)
            lint_result(errors: int, warnings: int, fixed: int = 0)
            targets_found(count: int, targets: List[dict] = None)
            table(headers: List[str], rows: List[List[str]])
            json(data: dict, title: str = None)

        Progress Events:
            progress_start(task: str, total: int)
            progress_update(task: str, current: int, message: str = None)
            progress_complete(task: str)

        Interactive Events:
            detail(label: str, value: str) - key/value pair
            steps(title: str, items: List[str]) - numbered list of steps
            prompt(message: str) - simple prompt text
    """

    def __init__(self):
        self._listeners: List[Listener] = []

    def add_listener(self, listener: Listener):
        """Add a listener that will receive events."""
        self._listeners.append(listener)

    def emit(self, event: str, **kwargs):
        """Emit an event to all listeners.

        Keyword arguments are filtered to match each handler's signature so
        that adding new fields to an event does not break existing listeners
        that have not yet been updated.

        Args:
            event: Event name (e.g., 'phase_start')
            **kwargs: Event data passed to listener
        """
        method_name = f"on_{event}"
        for listener in self._listeners:
            handler = getattr(listener, method_name, None)
            if handler and callable(handler):
                handler(**_filter_kwargs(handler, kwargs))

    # ============================================================
    # Convenience methods for common events
    # ============================================================

    def info(self, message: str):
        """Emit info message."""
        self.emit("info", message=message)

    def success(self, message: str):
        """Emit success message."""
        self.emit("success", message=message)

    def warn(self, message: str):
        """Emit warning message."""
        self.emit("warn", message=message)

    def error(self, message: str, exception: Optional[Exception] = None):
        """Emit error message."""
        self.emit("error", message=message, exception=exception)

    def detail(self, label: str, value: str):
        """Emit a key/value detail."""
        self.emit("detail", label=label, value=value)

    def steps(self, title: str, items: list):
        """Emit numbered steps."""
        self.emit("steps", title=title, items=items)

    def prompt(self, message: str):
        """Emit prompt text."""
        self.emit("prompt", message=message)
