"""Terminal state management — echo control, cursor, and restoration.

Ensures the terminal is always left in a usable state, even after crashes,
interrupts, or signals. All terminal manipulation should go through this module.

Key design:
- `_disable_terminal_echo()` captures pristine settings on first call
- `restore_terminal_for_input()` is the single authoritative restore function
- atexit + SIGTERM/SIGHUP handlers ensure restoration on process death
- `terminal_guard()` context manager for scoped protection
"""

import atexit
import logging
import os
import select
import signal
import subprocess
import sys
from contextlib import contextmanager

# Terminal echo control (Unix only)
try:
    import termios

    HAS_TERMIOS = True
except ImportError:
    HAS_TERMIOS = False

logger = logging.getLogger(__name__)

# Global storage for pristine terminal settings captured before any modification.
# Used by atexit/signal handlers as a last resort to restore terminal state.
_pristine_terminal_settings = None


def _disable_terminal_echo():
    """Disable terminal echo to prevent Enter key from creating newlines.

    Captures pristine settings on first call for reliable restoration later.
    """
    global _pristine_terminal_settings
    if not HAS_TERMIOS or not sys.stdin.isatty():
        return
    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        new_settings = termios.tcgetattr(fd)
        # Disable echo (ECHO) and canonical mode (ICANON)
        new_settings[3] = new_settings[3] & ~termios.ECHO & ~termios.ICANON
        termios.tcsetattr(fd, termios.TCSADRAIN, new_settings)
        # Save pristine settings on first call only
        if _pristine_terminal_settings is None:
            _pristine_terminal_settings = old_settings
    except (OSError, ValueError) as e:
        logger.debug(f"Failed to disable terminal echo: {e}")


def restore_terminal_for_input():
    """Restore terminal to a usable state.

    This is the single authoritative restore function. It:
    1. Flushes buffered stdin
    2. Shows the cursor (ANSI escape)
    3. Runs `stty sane` as a reliable nuclear reset
    4. Restores pristine termios settings if available

    Safe to call multiple times (idempotent). Safe to call when terminal
    is already in a good state.
    """
    global _pristine_terminal_settings

    if not sys.stdin.isatty():
        return

    # Flush any buffered input
    try:
        while select.select([sys.stdin], [], [], 0)[0]:
            sys.stdin.read(1)
    except (OSError, ValueError) as e:
        logger.debug(f"stdin flush failed: {e}")

    # Show cursor (ANSI escape) — Rich Live may hide it
    try:
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()
    except (OSError, ValueError) as e:
        logger.debug(f"cursor show failed: {e}")

    # Use stty sane as the primary reset — most reliable for fixing terminal state
    try:
        subprocess.run(["stty", "sane"], check=False, capture_output=True)
    except (OSError, FileNotFoundError) as e:
        logger.debug(f"stty sane failed: {e}")

    # Also restore pristine termios settings if we captured them
    if HAS_TERMIOS and _pristine_terminal_settings is not None:
        try:
            fd = sys.stdin.fileno()
            termios.tcsetattr(fd, termios.TCSANOW, _pristine_terminal_settings)
            _pristine_terminal_settings = None
        except (OSError, ValueError) as e:
            logger.debug(f"termios restore failed: {e}")


# Register atexit handler
atexit.register(restore_terminal_for_input)


def _signal_restore_terminal(signum, frame):
    """Restore terminal on SIGTERM/SIGHUP before process dies."""
    restore_terminal_for_input()
    # Re-raise with default handler to allow normal termination
    signal.signal(signum, signal.SIG_DFL)
    os.kill(os.getpid(), signum)


# Register signal handlers for terminal restoration on kill/hangup
try:
    signal.signal(signal.SIGTERM, _signal_restore_terminal)
    signal.signal(signal.SIGHUP, _signal_restore_terminal)
except (OSError, ValueError, AttributeError):
    # ValueError if not main thread, OSError if signal not available,
    # AttributeError if SIGHUP not defined (Windows)
    pass


@contextmanager
def terminal_guard():
    """Context manager that guarantees terminal restoration on exit.

    Wraps any block that may manipulate terminal state (echo, cursor, raw mode).
    On exit — normal, exception, or interrupt — restores the terminal.
    """
    try:
        yield
    finally:
        restore_terminal_for_input()
