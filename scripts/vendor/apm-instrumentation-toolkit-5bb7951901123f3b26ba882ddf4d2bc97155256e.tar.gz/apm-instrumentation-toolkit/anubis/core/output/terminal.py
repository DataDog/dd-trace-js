"""Terminal output listener using Rich.

Handles events from EventEmitter and displays them beautifully in the terminal.
"""

import json
import logging
import os
import sys
from typing import IO, Any, Dict, List, Optional, cast

from pydantic import BaseModel
from rich.box import ROUNDED
from rich.columns import Columns
from rich.console import Console, Group
from rich.live import Live
from rich.markup import escape
from rich.panel import Panel
from rich.progress import Progress, TaskID
from rich.prompt import Prompt
from rich.spinner import Spinner
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from .terminal_state import _disable_terminal_echo, restore_terminal_for_input

logger = logging.getLogger(__name__)


class _CRLFFile:
    """Translate ``\\n`` → ``\\r\\n`` for output through ssh -tt + tmux.

    tmux disables output processing (opost) on the outer PTY, so ``\\n``
    from incremental screen updates passes through without a carriage
    return, causing rightward drift.  This wrapper ensures every ``\\n``
    in Rich Console output becomes ``\\r\\n``.
    """

    def __init__(self, file: IO[str]):
        self._file = file

    def write(self, s: str) -> int:
        s = s.replace("\r\n", "\n").replace("\n", "\r\n")
        return self._file.write(s)

    def flush(self) -> None:
        return self._file.flush()

    def fileno(self) -> int:
        return self._file.fileno()

    def isatty(self) -> bool:
        return True


class TerminalListener:
    """Rich terminal output for workflow events.

    Usage:
        from anubis.core.output import EventEmitter, TerminalListener

        class MyWorkflow(EventEmitter):
            def run(self):
                self.emit('workflow_start', name='kafkajs')
                ...

        workflow = MyWorkflow()
        workflow.add_listener(TerminalListener())
        workflow.run()
    """

    def __init__(self, console: Optional[Console] = None):
        if console:
            self.console = console
        elif os.environ.get("DD_APM_REMOTE"):
            self.console = Console(file=cast(IO[str], _CRLFFile(sys.stdout)), force_terminal=True)
        else:
            self.console = Console()
        self._progress: Optional[Progress] = None
        self._progress_tasks: Dict[str, TaskID] = {}
        # Agent live display state (multi-line panel showing current activity)
        self._agent_live: Optional[Live] = None
        self._agent_status: Optional[bool] = None  # Flag for suppressing other output
        self._agent_task: Optional[str] = None
        self._agent_metadata: Dict[str, Any] = {}  # Agent info (model, cwd, prompt, log)
        self._agent_output_history: List[str] = []  # Recent outputs for scrolling display
        self._agent_max_lines: int = 12  # Max lines to show (not items)
        # Batch display state (multi-item parallel execution)
        self._batch_live: Optional[Live] = None
        self._in_batch: bool = False  # True while a batch/seq-batch is actively running
        # Sequential batch state (initialized in on_seq_batch_start)
        self._seq_live: Optional[Live] = None
        self._seq_current: Optional[str] = None
        self._batch_items: Dict[str, dict] = {}  # item_id -> {status, message, duration}
        self._batch_order: List[str] = []  # Preserve original order
        self._saved_stderr_fd: Optional[int] = None  # Saved stderr fd during Live panels
        # Last "Step data: <path>/" info message — consumed by on_phase_complete to show output link
        self._last_step_data_path: Optional[str] = None

    def _suppress_stderr(self) -> None:
        """Redirect stderr to /dev/null while Live panels are active.

        Background threads (e.g. ddtrace LLMObs writer) can write to stderr,
        injecting lines that break Rich Live's cursor tracking and cause
        stacking panel borders.
        """
        if self._saved_stderr_fd is None:
            try:
                self._saved_stderr_fd = os.dup(2)
                devnull = os.open(os.devnull, os.O_WRONLY)
                os.dup2(devnull, 2)
                os.close(devnull)
            except OSError:
                self._saved_stderr_fd = None

    def _restore_stderr(self) -> None:
        """Restore stderr after Live panels stop."""
        saved = getattr(self, "_saved_stderr_fd", None)
        if saved is not None:
            try:
                os.dup2(saved, 2)
                os.close(saved)
            except OSError as e:
                logger.debug("Failed to restore stderr: %s", e)
            self._saved_stderr_fd = None

    def _print(self, *args, **kwargs) -> bool:
        """Print to console, suppressing output during live displays.

        Returns True if printed, False if suppressed.
        """
        if self._agent_status or getattr(self, "_seq_live", None):
            return False
        self.console.print(*args, **kwargs)
        return True

    # ============================================================
    # Flow Events
    # ============================================================

    def on_workflow_start(self, name: str):
        """Display workflow header."""
        self.console.print()
        self.console.rule(f"[bold blue]{name}[/]", style="blue")
        self.console.print()

    def on_workflow_complete(self, success: bool, message: Optional[str] = None):
        """Display workflow completion."""
        # Clean up any active panels first
        self.cleanup()

        self.console.print()
        if success:
            label = message or "Complete"
            self.console.rule(f"[bold green]{label}[/]", style="green")
        else:
            label = message or "Failed"
            self.console.rule(f"[bold red]{label}[/]", style="red")
        self.console.print()

    def on_phase_start(self, phase: str, number: Optional[int] = None, total: Optional[int] = None):
        """Display phase header."""
        if number and total:
            label = f"[bold cyan]{number}/{total}. {phase}[/]"
        elif number:
            label = f"[bold cyan]{number}. {phase}[/]"
        else:
            label = f"[bold cyan]{phase}[/]"

        self.console.print()
        self.console.print(f"[cyan]▶[/] {label}")
        self.console.print()  # Space after phase header before sections

    def on_phase_complete(self, phase: str, success: bool = True, output: Any = None):
        """Display phase completion with a visual separator."""
        if success:
            self.console.rule(f"[bold green]✓ {phase} complete[/]", style="green")
        else:
            self.console.rule(f"[bold red]✗ {phase} failed[/]", style="red")
        if output is not None:
            output_path = self._last_step_data_path
            self._last_step_data_path = None
            self._print_output_summary(output, output_path=output_path)

    def _print_output_summary(self, output: Any, output_path: Optional[str] = None) -> None:
        """Print a compact summary of step output with a file link."""
        try:
            if isinstance(output, BaseModel):
                fields = output.model_dump(exclude_none=True)
                skip = {"success", "error"}
                lines = []
                for key, value in fields.items():
                    if key.startswith("_") or key in skip:
                        continue
                    if isinstance(value, list):
                        lines.append(f"  [dim]{key}:[/] [cyan]{len(value)} items[/]")
                    elif isinstance(value, dict):
                        lines.append(f"  [dim]{key}:[/] [cyan]{len(value)} keys[/]")
                    elif isinstance(value, str) and len(value) > 80:
                        lines.append(f"  [dim]{key}:[/] {escape(value[:77])}[dim]...[/]")
                    else:
                        lines.append(f"  [dim]{key}:[/] {escape(str(value))}")
                    if len(lines) >= 8:
                        lines.append("  [dim]...[/]")
                        break

                if lines:
                    self.console.print("  [bold dim]── Output ──[/]")
                    for line in lines:
                        self.console.print(line)

                if output_path:
                    # Strip trailing slash so we can append /output.json cleanly
                    base = output_path.rstrip("/")
                    self.console.print(f"  [dim]→[/] [dim]{base}/output.json[/]")
        except Exception:
            logger.debug("Failed to render output summary", exc_info=True)

    def on_phase_skip(
        self,
        phase: str,
        number: Optional[int] = None,
        total: Optional[int] = None,
        reason: Optional[str] = None,
    ):
        """Display skipped phase."""
        if number and total:
            label = f"[dim]{number}/{total}. {phase}[/]"
        elif number:
            label = f"[dim]{number}. {phase}[/]"
        else:
            label = f"[dim]{phase}[/]"

        reason_text = f" ({reason})" if reason else ""
        self.console.print(f"[dim]⏭[/] {label} [dim]skipped{reason_text}[/]")

    def on_step_start(self, step: str):
        """Display step start."""
        self._print(f"  [dim]•[/] {step}")

    def on_stage_start(self, stage: str):
        """Display stage start within a composite step."""
        display_name = stage.replace("_", " ").title()
        self._print()
        self._print(f"  [magenta]▸[/] [bold magenta]Stage: {display_name}[/]")

    def on_stage_complete(self, stage: str, success: bool = True):
        """Display stage completion."""
        display_name = stage.replace("_", " ").title()
        if success:
            self._print(f"  [green]✓[/] [dim]Stage: {display_name} complete[/]")
        else:
            self._print(f"  [red]✗[/] [dim]Stage: {display_name} failed[/]")

    def on_section(self, name: str):
        """Display a section header within a phase."""
        # No blank line before "completed" sections - keep them connected to output
        if not name.endswith("complete") and not name.endswith("completed"):
            self._print()
        self._print(f"  [bold dim]── {name} ──[/]")
        if not name.endswith("complete") and not name.endswith("completed"):
            self._print()

    def on_blank(self):
        """Display a blank line for spacing."""
        self._print()

    # ============================================================
    # Message Events
    # ============================================================

    def on_info(self, message: str):
        """Display info message."""
        if message.startswith("Step data: "):
            self._last_step_data_path = message[len("Step data: ") :]
        self._print(f"  [blue]ℹ[/] {escape(message)}")

    def on_success(self, message: str):
        """Display success message."""
        self._print(f"  [green]✓[/] {escape(message)}")

    def on_warn(self, message: str):
        """Display warning message."""
        self._print(f"  [yellow]⚠[/] {escape(message)}")

    def on_error(self, message: str, exception: Optional[Exception] = None):
        """Display error message."""
        self.console.print(f"  [red]✗[/] {escape(message)}")
        if exception:
            self.console.print(f"    [dim red]{type(exception).__name__}: {exception}[/]")

    # ============================================================
    # Data Events
    # ============================================================

    def on_detail(self, label: str, value: str):
        """Display a key/value detail."""
        self.console.print(f"  [bold]{label}:[/] {value}")

    def on_steps(self, title: str, items: List[str]):
        """Display numbered steps."""
        self.console.print()
        self.console.print(f"[dim]{title}:[/]")
        for i, item in enumerate(items, 1):
            self.console.print(f"  {i}. {item}")

    def on_prompt(self, message: str):
        """Display prompt text."""
        self.console.print(Text(message, style="dim"))

    def on_scrollable(self, content: Any, max_lines: int = 100, title: Optional[str] = None):
        """Display content with truncated preview and optional full pager.

        Args:
            content: Content to display (str, dict, or Pydantic model)
            max_lines: Lines to show before prompting (default: 100)
            title: Optional title to show before content
        """

        if title:
            self._print(f"  [dim]{title}:[/]")

        # Convert to string if needed
        if hasattr(content, "model_dump"):
            text = json.dumps(content.model_dump(), indent=2, default=str)
        elif isinstance(content, dict):
            text = json.dumps(content, indent=2, default=str)
        else:
            text = str(content)

        lines = text.split("\n")
        if len(lines) <= max_lines:
            # Content fits, show directly
            self.console.print(Syntax(text, "json", theme="monokai"))
        else:
            # Show truncated preview
            preview = "\n".join(lines[:max_lines])
            self.console.print(Syntax(preview, "json", theme="monokai"))
            remaining = len(lines) - max_lines
            self.console.print(f"  [dim]... ({remaining} more lines)[/]")
            self.console.print()

            # Prompt to show full output
            show_full = Prompt.ask(
                "  Show full output?", choices=["y", "n"], default="n", console=self.console
            )
            if show_full == "y":
                with self.console.pager(styles=True):
                    self.console.print(Syntax(text, "json", theme="monokai"))

    # ============================================================
    # Cost Events
    # ============================================================

    def on_cost_summary(
        self,
        total_cost: float,
        total_duration: float,
        total_turns: int,
        agent_runs: Optional[List[Dict[str, Any]]] = None,
        show_breakdown: bool = False,
    ):
        """Display cost summary at end of workflow.

        Args:
            total_cost: Total cost in USD
            total_duration: Total duration in seconds
            total_turns: Total number of agent turns
            agent_runs: Optional list of per-agent run data
            show_breakdown: If True, show per-agent breakdown
        """
        self.console.print()
        self.console.print("  [bold dim]── Cost Summary ──[/]")

        if show_breakdown and agent_runs:
            for run in agent_runs:
                task = run.get("task", "Unknown")
                cost = run.get("cost_usd", 0)
                duration = run.get("duration_seconds", 0)
                turns = run.get("num_turns", 0)
                self.console.print(
                    f"    [dim]{task}:[/] ${cost:.4f} | {duration:.1f}s | {turns} turns"
                )
            self.console.print()

        # Total line
        self.console.print(
            f"  [bold]Total:[/] {len(agent_runs or [])} agent runs | "
            f"[green]${total_cost:.4f}[/] | "
            f"{total_duration:.1f}s | "
            f"{total_turns} turns"
        )

    # ============================================================
    # Review Events
    # ============================================================

    def on_review_summary(
        self,
        tests_passing: bool,
        fixed: int,
        failed: int,
        skipped: int,
        changes_made: Optional[List[str]] = None,
        todos_fixed: Optional[List[str]] = None,
        todos_failed: Optional[List[str]] = None,
    ):
        """Display review summary before approval prompt."""
        self.console.print()
        self.console.print("  [bold dim]── Review Summary ──[/]")
        self.console.print()

        if tests_passing:
            self.console.print("  [green]✓[/] Tests passing")
        else:
            self.console.print("  [red]✗[/] Tests failing")

        if changes_made:
            self.console.print()
            self.console.print("  [dim]Changes made:[/]")
            for change in changes_made:
                self.console.print(f"    [green]•[/] {change}")

        if todos_failed:
            self.console.print()
            self.console.print("  [dim]Failed to fix:[/]")
            for todo_id in todos_failed:
                self.console.print(f"    [red]✗[/] {todo_id}")

        self.console.print()
        parts = []
        if fixed:
            parts.append(f"[green]{fixed} fixed[/]")
        if failed:
            parts.append(f"[red]{failed} failed[/]")
        if skipped:
            parts.append(f"[yellow]{skipped} skipped[/]")

        if parts:
            self.console.print(f"  [dim]Todos:[/] {', '.join(parts)}")
        else:
            self.console.print("  [dim]Todos:[/] none")

        self.console.print()

    # ============================================================
    # Agent Live Display Events (multi-line panel)
    # ============================================================

    def on_agent_start(
        self,
        task: str,
        log_path: Optional[str] = None,
        prompt_path: Optional[str] = None,
        cwd: Optional[str] = None,
        model: Optional[str] = None,
        max_turns: Optional[int] = None,
        schema: Optional[str] = None,
    ):
        """Start agent live display with multi-line panel."""
        # During an active batch/seq-batch, the batch panel handles display;
        # individual agent starts should not create their own panel.
        if self._in_batch:
            return

        # If a batch or sequential-batch display is still active but _in_batch
        # is False, the display is stale (e.g. left over from a prior step that
        # errored before emitting batch_complete). Stop it now rather than
        # silently suppressing the agent output entirely.
        seq_live = getattr(self, "_seq_live", None)
        if self._batch_live or seq_live:
            if self._batch_live:
                self._batch_live.stop()
                self._batch_live = None
            if seq_live:
                seq_live.stop()
                self._seq_live = None
            self._restore_stderr()
            restore_terminal_for_input()

        self._agent_task = task
        self._agent_metadata = {
            "log_path": log_path,
            "prompt_path": prompt_path,
            "cwd": cwd,
            "model": model,
            "max_turns": max_turns,
            "schema": schema,
        }
        self._agent_output_history = ["[dim]Starting...[/]"]

        _disable_terminal_echo()
        self._agent_status = True
        self._suppress_stderr()

        self._agent_live = Live(
            self._build_agent_panel(),
            console=self.console,
            refresh_per_second=4,
            transient=False,
            vertical_overflow="crop",
        )
        self._agent_live.start()

    def _build_agent_panel(self) -> Panel:
        """Build the agent activity panel with spinner and scrolling history."""
        spinner = Spinner("dots", style="cyan")
        header = Text(f"Agent: {self._agent_task}", style="bold cyan")
        header_row = Columns([spinner, header], expand=False)

        meta = getattr(self, "_agent_metadata", {})
        meta_parts = []
        if meta.get("model"):
            meta_parts.append(f"[dim]model:[/] {meta['model']}")
        if meta.get("cwd"):
            meta_parts.append(f"[dim]cwd:[/] {meta['cwd']}")
        if meta.get("prompt_path"):
            meta_parts.append(f"[dim]prompt:[/] {meta['prompt_path']}")
        if meta.get("log_path"):
            meta_parts.append(f"[dim]log:[/] {meta['log_path']}")
        if meta_parts:
            meta_line = Text.from_markup(" | ".join(meta_parts), overflow="ellipsis")
            meta_line.no_wrap = True
        else:
            meta_line = Text("")

        history_table = Table(show_header=False, box=None, padding=(0, 0), expand=True)
        history_table.add_column("Output", no_wrap=True, overflow="ellipsis")

        history_len = len(self._agent_output_history)
        for i, item in enumerate(self._agent_output_history):
            if i < history_len - 1:
                history_table.add_row(f"[dim]{item}[/]")
            else:
                history_table.add_row(item)

        content_group = Group(header_row, meta_line, Text(""), history_table)

        return Panel(content_group, border_style="cyan", padding=(0, 1))

    def _count_lines(self, items: List[str]) -> int:
        """Count total lines across all items."""
        return sum(item.count("\n") + 1 for item in items)

    # ============================================================
    # Batch Display Events (parallel item execution)
    # ============================================================

    def on_batch_start(self, items: List[str]):
        """Start batch display."""
        self._in_batch = True
        self._batch_order = items
        self._batch_items = {
            item_id: {"status": "running", "message": "Starting..."} for item_id in items
        }
        _disable_terminal_echo()
        self._suppress_stderr()
        self._batch_live = Live(
            self._build_batch_panel(), console=self.console, refresh_per_second=4, transient=True
        )
        self._batch_live.start()

    def _build_batch_panel(self) -> Panel:
        """Build batch display with border and consistent spacing."""
        table = Table(show_header=False, box=None, padding=(0, 1), expand=True)
        table.add_column("Item", no_wrap=True, overflow="ellipsis", ratio=1)
        table.add_column("Status", no_wrap=True, overflow="ellipsis", ratio=4)

        for item_id in self._batch_order:
            item = self._batch_items.get(item_id, {})
            status = item.get("status", "running")
            msg = item.get("message", "")
            icon = {"complete": "[green]✓[/]", "failed": "[red]✗[/]", "running": "[cyan]●[/]"}.get(
                status, "[dim]○[/]"
            )
            status_text = f"[dim]{msg}[/]" if status == "running" else ""
            table.add_row(f"{icon} {item_id}", status_text)

        return Panel(table, box=ROUNDED, border_style="cyan", padding=(0, 1))

    def on_batch_item_update(
        self, item_id: str, status: Optional[str] = None, message: Optional[str] = None, **_: Any
    ):
        """Update batch item."""
        if item_id in self._batch_items:
            if status:
                self._batch_items[item_id]["status"] = status
            if message:
                self._batch_items[item_id]["message"] = message
            if self._batch_live:
                self._batch_live.update(self._build_batch_panel())

    def on_batch_item_complete(self, item_id: str, success: bool, **_: Any):
        """Mark batch item complete."""
        self.on_batch_item_update(item_id, status="complete" if success else "failed")

    def on_batch_complete(self):
        """Stop batch display."""
        self._in_batch = False
        if self._batch_live:
            self._batch_live.stop()
            self._batch_live = None
        self._restore_stderr()
        restore_terminal_for_input()
        sys.stdout.write("\r")
        sys.stdout.flush()
        self._batch_items, self._batch_order = {}, []

    # ============================================================
    # Sequential Batch Display (3-panel: info, history, current)
    # ============================================================

    def on_seq_batch_start(self, step: str, total: int, model: str = "unknown"):
        """Start sequential batch with 3-panel display."""
        self._in_batch = True
        self._seq_step = step
        self._seq_total = total
        self._seq_model = model
        self._seq_completed: List[tuple] = []
        self._seq_current = None
        self._seq_index = 0
        self._seq_cost = 0.0
        self._seq_output: List[str] = []
        _disable_terminal_echo()
        self._suppress_stderr()
        self._seq_live = Live(
            self._build_seq_panels(),
            console=self.console,
            refresh_per_second=4,
            transient=True,
            vertical_overflow="crop",
        )
        self._seq_live.start()

    def _build_seq_panels(self) -> Group:
        """Build 2-panel display for sequential batch (compact)."""
        panels = []
        term_width = self.console.width - 6

        progress = (
            f"[{self._seq_index + 1}/{self._seq_total}]"
            if self._seq_current
            else f"[0/{self._seq_total}]"
        )
        header = Text.from_markup(
            f"[bold cyan]{self._seq_step}[/] {progress} | {self._seq_model} | [green]${self._seq_cost:.2f}[/]"
        )
        panels.append(Panel(header, box=ROUNDED, border_style="cyan", padding=(0, 1)))

        if self._seq_current or self._seq_completed:
            content_lines = []

            for item_id, success in self._seq_completed[-3:]:
                icon = "[green]✓[/]" if success else "[red]✗[/]"
                content_lines.append(f"{icon} {item_id}")

            if self._seq_current:
                content_lines.append(f"[cyan]●[/] [bold]{self._seq_current}[/]")
                for line in self._seq_output[-4:]:
                    truncated = line[:term_width] if len(line) > term_width else line
                    content_lines.append(f"  [dim]{truncated}[/]")

            content_table = Table(show_header=False, box=None, padding=(0, 0), expand=True)
            content_table.add_column(
                "Content", no_wrap=True, overflow="ellipsis", max_width=term_width
            )
            for line in content_lines:
                content_table.add_row(line)
            panels.append(Panel(content_table, box=ROUNDED, border_style="cyan", padding=(0, 1)))

        return Group(*panels)

    def on_seq_batch_item_start(self, item_id: str, index: int, total: int):
        """Start a new item in sequential batch."""
        self._seq_current = item_id
        self._seq_index = index
        self._seq_output = []
        if self._seq_live:
            self._seq_live.update(self._build_seq_panels())

    def on_seq_batch_item_complete(self, item_id: str, success: bool):
        """Complete an item in sequential batch."""
        self._seq_completed.append((item_id, success))
        self._seq_current = None
        self._seq_output = []
        if self._seq_live:
            self._seq_live.update(self._build_seq_panels())

    def on_seq_batch_complete(self):
        """Stop sequential batch display."""
        self._in_batch = False
        if self._seq_live:
            self._seq_live.stop()
            self._seq_live = None
        self._restore_stderr()
        restore_terminal_for_input()
        sys.stdout.write("\r")
        sys.stdout.flush()
        succeeded = sum(1 for _, s in self._seq_completed if s)
        failed = len(self._seq_completed) - succeeded
        if failed:
            self.console.print(
                f"  [yellow]⚠[/] {self._seq_step}: [green]{succeeded}[/]/{self._seq_total} succeeded, [red]{failed}[/] failed | ${self._seq_cost:.2f}"
            )
        else:
            self.console.print(
                f"  [green]✓[/] {self._seq_step}: {self._seq_total}/{self._seq_total} succeeded | ${self._seq_cost:.2f}"
            )

    def on_agent_output(self, line: str, batch_item_id: Optional[str] = None):
        """Update live panel with latest agent activity."""
        if batch_item_id and self._batch_live:
            self.on_batch_item_update(batch_item_id, message=line)
            return

        if hasattr(self, "_seq_live") and self._seq_live and self._seq_current:
            self._seq_output.append(line)
            if len(self._seq_output) > 4:
                self._seq_output.pop(0)
            self._seq_live.update(self._build_seq_panels())
            return

        if not self._agent_live:
            return
        self._agent_output_history.append(line)
        while (
            len(self._agent_output_history) > 1
            and self._count_lines(self._agent_output_history) > self._agent_max_lines
        ):
            self._agent_output_history.pop(0)
        self._agent_live.update(self._build_agent_panel())

    def on_agent_complete(self, task: str, success: bool, cost: float = 0, **_: Any):
        """Stop live display and show completion summary."""
        if self._batch_live:
            return
        if hasattr(self, "_seq_live") and self._seq_live:
            self._seq_cost += cost
            return

        if self._agent_live:
            self._agent_live.stop()
            self._agent_live = None
        self._agent_status = None
        self._restore_stderr()
        restore_terminal_for_input()
        sys.stdout.write("\r")
        sys.stdout.flush()
        self._agent_task = None
        self._agent_metadata = {}
        self._agent_output_history = []
        status = "[green]✓[/]" if success else "[red]✗[/]"
        self.console.print(f"  {status} Agent complete (${cost:.4f})")

    def on_pause_live(self):
        """Pause all live displays for interactive prompts."""
        self._paused_seq_live = getattr(self, "_seq_live", None)
        self._paused_batch_live = self._batch_live
        self._paused_agent_live = self._agent_live

        if self._paused_seq_live:
            self._paused_seq_live.stop()
            self._seq_live = None
        if self._paused_batch_live:
            self._paused_batch_live.stop()
            self._batch_live = None
        if self._paused_agent_live:
            self._paused_agent_live.stop()
            self._agent_live = None

        restore_terminal_for_input()
        self._agent_status = None

    def on_resume_live(self):
        """Resume live displays after interactive prompts."""
        any_paused = (
            getattr(self, "_paused_seq_live", None)
            or getattr(self, "_paused_batch_live", None)
            or getattr(self, "_paused_agent_live", None)
        )
        if any_paused:
            _disable_terminal_echo()

        paused_seq = getattr(self, "_paused_seq_live", None)
        if paused_seq:
            self._seq_live = paused_seq
            paused_seq.start()
        paused_batch = getattr(self, "_paused_batch_live", None)
        if paused_batch:
            self._batch_live = paused_batch
            paused_batch.start()
        paused_agent = getattr(self, "_paused_agent_live", None)
        if paused_agent:
            self._agent_live = paused_agent
            paused_agent.start()
            self._agent_status = True

        self._paused_seq_live = None
        self._paused_batch_live = None
        self._paused_agent_live = None

    def on_stop_live(self):
        """Stop all live displays and restore terminal (for abort scenarios)."""
        self._in_batch = False
        for attr in ["_paused_seq_live", "_paused_batch_live", "_paused_agent_live"]:
            panel = getattr(self, attr, None)
            if panel:
                try:
                    panel.stop()
                except (OSError, RuntimeError):
                    pass
                setattr(self, attr, None)

        for panel in [self._agent_live, self._batch_live, getattr(self, "_seq_live", None)]:
            if panel:
                try:
                    panel.stop()
                except (OSError, RuntimeError):
                    pass
        self._agent_live = self._batch_live = self._agent_status = None
        if hasattr(self, "_seq_live"):
            self._seq_live = None

        self._restore_stderr()
        restore_terminal_for_input()
        sys.stdout.write("\r")
        sys.stdout.flush()

    def cleanup(self):
        """Clean up any active state."""
        self._in_batch = False
        seq_live = getattr(self, "_seq_live", None)
        for live in [self._agent_live, self._batch_live, seq_live]:
            if live:
                try:
                    live.stop()
                except (OSError, RuntimeError) as e:
                    logger.debug(f"Failed to stop live display during cleanup: {e}")
        self._agent_live = self._batch_live = self._agent_status = None
        self._restore_stderr()
        if seq_live:
            self._seq_live = None
        self._batch_items, self._batch_order = {}, []
        restore_terminal_for_input()
        self._agent_task, self._agent_metadata, self._agent_output_history = None, {}, []
        if self._progress:
            try:
                self._progress.stop()
            except (OSError, RuntimeError) as e:
                logger.debug(f"Failed to stop progress during cleanup: {e}")
            self._progress, self._progress_tasks = None, {}
