"""Toolkit version utilities."""

import importlib.metadata

_PACKAGE_NAME = "dd-apm-integration-ai-toolkit"


def get_toolkit_version() -> str:
    """Return the installed toolkit version, or 'unknown' if not installed."""
    try:
        return importlib.metadata.version(_PACKAGE_NAME)
    except importlib.metadata.PackageNotFoundError:
        return "unknown"
