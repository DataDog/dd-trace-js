"""Toolkit deployment to a remote workspace via SSH."""

from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path

from .models import REMOTE_TOOLKIT_DIR, WorkspaceConfig, WorkspaceInfo

logger = logging.getLogger(__name__)

_REMOTE_REPOS_DIR = "~/repos"


def _ssh(host: str, command: str, *, timeout: int = 300) -> subprocess.CompletedProcess:
    """Run a command on the workspace via SSH."""
    return subprocess.run(
        ["ssh", "-o", "StrictHostKeyChecking=no", host, command],
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _is_toolkit_deployed(workspace: WorkspaceInfo) -> bool:
    """Check if the toolkit is already deployed in the workspace."""
    result = _ssh(
        workspace.ssh_host,
        f"test -f {REMOTE_TOOLKIT_DIR}/.venv/bin/dd-apm && echo yes || echo no",
        timeout=15,
    )
    return result.returncode == 0 and "yes" in result.stdout


def deploy_to_workspace(
    workspace: WorkspaceInfo,
    config: WorkspaceConfig,
    toolkit_root: Path | None = None,
) -> None:
    """Deploy the toolkit into the workspace.

    If toolkit_root is provided, deploys from local source via tar-over-SSH.
    Otherwise, clones from GitHub.
    """
    if _is_toolkit_deployed(workspace):
        logger.info("Toolkit already deployed in workspace %s, updating...", workspace.name)
        _update_deployed_toolkit(workspace, config, toolkit_root)
        return

    if toolkit_root and toolkit_root.exists():
        _deploy_from_source(workspace, toolkit_root)
    else:
        _deploy_from_github(workspace, config)

    _install_toolkit(workspace)


def _deploy_from_source(workspace: WorkspaceInfo, toolkit_root: Path) -> None:
    """Deploy toolkit from local source via tar-over-SSH."""
    logger.info("Deploying toolkit from local source to %s...", workspace.name)

    _ssh(workspace.ssh_host, f"mkdir -p {REMOTE_TOOLKIT_DIR}", timeout=15)

    excludes = [
        "--exclude=.git",
        "--exclude=.venv",
        "--exclude=__pycache__",
        "--exclude=.mypy_cache",
        "--exclude=.pytest_cache",
        "--exclude=repos",
        "--exclude=.analysis",
        "--exclude=node_modules",
        "--exclude=test-results",
        "--exclude=.anubis/config.yaml",
    ]
    # COPYFILE_DISABLE prevents macOS tar from including ._* resource fork files
    tar_env = {**os.environ, "COPYFILE_DISABLE": "1"}
    tar_cmd = ["tar", "-C", str(toolkit_root), *excludes, "-cf", "-", "."]
    untar_cmd = [
        "ssh",
        "-o",
        "StrictHostKeyChecking=no",
        workspace.ssh_host,
        f"tar -C {REMOTE_TOOLKIT_DIR} -xf -",
    ]

    tar_proc = subprocess.Popen(tar_cmd, stdout=subprocess.PIPE, env=tar_env)
    untar_proc = subprocess.run(
        untar_cmd, stdin=tar_proc.stdout, capture_output=True, text=True, timeout=300
    )
    tar_proc.wait()

    if untar_proc.returncode != 0:
        raise RuntimeError(f"Failed to deploy toolkit via tar: {untar_proc.stderr}")

    logger.info("Source deployed to %s:%s", workspace.name, REMOTE_TOOLKIT_DIR)


def _deploy_from_github(workspace: WorkspaceInfo, config: WorkspaceConfig) -> None:
    """Clone the toolkit from GitHub into the workspace."""
    logger.info("Cloning toolkit from GitHub into %s...", workspace.name)

    branch_flag = f"--branch {config.toolkit_branch}" if config.toolkit_branch else ""
    clone_cmd = (
        f"if [ -d {REMOTE_TOOLKIT_DIR}/.git ]; then "
        f"  cd {REMOTE_TOOLKIT_DIR} && git pull; "
        f"else "
        f"  git clone {branch_flag} https://github.com/{config.toolkit_repo}.git {REMOTE_TOOLKIT_DIR}; "
        f"fi"
    )
    result = _ssh(workspace.ssh_host, clone_cmd, timeout=300)
    if result.returncode != 0:
        raise RuntimeError(f"Failed to clone toolkit: {result.stderr}")

    logger.info("Toolkit cloned to %s:%s", workspace.name, REMOTE_TOOLKIT_DIR)


def _update_deployed_toolkit(
    workspace: WorkspaceInfo,
    config: WorkspaceConfig,
    toolkit_root: Path | None = None,
) -> None:
    """Update an already-deployed toolkit."""
    if toolkit_root and toolkit_root.exists():
        _deploy_from_source(workspace, toolkit_root)
    else:
        result = _ssh(
            workspace.ssh_host,
            f"cd {REMOTE_TOOLKIT_DIR} && git pull",
            timeout=60,
        )
        if result.returncode != 0:
            logger.warning("git pull failed, re-deploying: %s", result.stderr)
            _deploy_from_github(workspace, config)
    _install_toolkit(workspace)


def _ensure_workspace_prerequisites(workspace: WorkspaceInfo) -> None:
    """Install required system dependencies in the workspace.

    Workspaces are Ubuntu-based and may not have Node.js or yarn
    pre-installed. The local prereqs system (prereqs.py) uses brew and
    targets macOS; this function handles the workspace equivalent.
    """
    node_ok = _ssh(workspace.ssh_host, "command -v node", timeout=15)
    if node_ok.returncode != 0:
        logger.info("Installing Node.js in workspace %s...", workspace.name)
        install_cmd = (
            "curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - "
            "&& sudo apt-get install -y nodejs"
        )
        result = _ssh(workspace.ssh_host, install_cmd, timeout=120)
        if result.returncode != 0:
            raise RuntimeError(
                f"Failed to install Node.js in workspace {workspace.name}:\n"
                f"stderr: {result.stderr[-500:]}"
            )
        logger.info("Node.js installed in workspace %s", workspace.name)

    yarn_ok = _ssh(workspace.ssh_host, "command -v yarn", timeout=15)
    if yarn_ok.returncode != 0:
        logger.info("Installing yarn in workspace %s...", workspace.name)
        result = _ssh(workspace.ssh_host, "sudo npm install -g yarn", timeout=60)
        if result.returncode != 0:
            logger.warning("Failed to install yarn: %s", result.stderr[-300:])


def _install_toolkit(workspace: WorkspaceInfo) -> None:
    """Ensure prerequisites and run make install in the workspace."""
    logger.info("Installing toolkit in workspace %s...", workspace.name)

    _ensure_workspace_prerequisites(workspace)

    install_cmd = f"cd {REMOTE_TOOLKIT_DIR} && make install"
    result = _ssh(workspace.ssh_host, install_cmd, timeout=600)
    if result.returncode != 0:
        raise RuntimeError(
            f"Toolkit installation failed in workspace {workspace.name}:\n"
            f"stdout: {result.stdout[-500:]}\n"
            f"stderr: {result.stderr[-500:]}"
        )

    logger.info("Toolkit installed successfully in workspace %s", workspace.name)


def write_workspace_config(
    workspace: WorkspaceInfo,
    repository: str,
    remote_repo_path: str,
    language: str = "node",
) -> None:
    """Write a workspace-specific .anubis/config.yaml.

    The local config.yaml contains Mac-local absolute paths that don't exist
    in the workspace. This writes a minimal config with just the target repo.
    """
    config_yaml = (
        f"default_repository: {repository}\n"
        f"repositories:\n"
        f"  {repository}:\n"
        f"    path: {remote_repo_path}\n"
        f"    language: {language}\n"
    )
    write_cmd = (
        f"mkdir -p {REMOTE_TOOLKIT_DIR}/.anubis && "
        f"cat > {REMOTE_TOOLKIT_DIR}/.anubis/config.yaml << 'CONFIGEOF'\n"
        f"{config_yaml}CONFIGEOF"
    )
    result = _ssh(workspace.ssh_host, write_cmd, timeout=15)
    if result.returncode != 0:
        logger.warning("Failed to write workspace config: %s", result.stderr)
    else:
        logger.info("Wrote workspace config for %s -> %s", repository, remote_repo_path)


def clone_repo_in_workspace(
    workspace: WorkspaceInfo,
    repo_url: str,
    branch: str | None = None,
) -> str:
    """Clone or update a target repository in the workspace.

    Returns the remote path to the repo.
    """
    repo_name = repo_url.rstrip("/").rsplit("/", 1)[-1].replace(".git", "")
    remote_path = f"{_REMOTE_REPOS_DIR}/{repo_name}"

    # If the repo already exists, leave it as-is — a previous workflow run
    # may have uncommitted changes we don't want to clobber.
    check = _ssh(workspace.ssh_host, f"test -d {remote_path}/.git && echo exists", timeout=15)
    if check.stdout and "exists" in check.stdout:
        logger.info("Repo already cloned at %s:%s, skipping update", workspace.name, remote_path)
    else:
        branch_flag = f"--branch {branch}" if branch else ""
        clone_cmd = (
            f"mkdir -p {_REMOTE_REPOS_DIR} && git clone {branch_flag} {repo_url} {remote_path}"
        )
        result = _ssh(workspace.ssh_host, clone_cmd, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to clone {repo_url} in workspace: {result.stderr}")

    logger.info("Repo %s available at %s:%s", repo_name, workspace.name, remote_path)
    return remote_path
