"""Data models for workspace management."""

from __future__ import annotations

import getpass
from dataclasses import dataclass

REMOTE_TOOLKIT_DIR = "~/apm-instrumentation-toolkit"


@dataclass
class WorkspaceConfig:
    """Configuration for workspace creation and deployment."""

    name: str | None = None
    region: str = "us-east-1"
    toolkit_branch: str | None = None
    toolkit_repo: str = "DataDog/apm-instrumentation-toolkit"

    @property
    def resolved_name(self) -> str:
        if self.name:
            return self.name
        user = getpass.getuser().replace(".", "-").replace("_", "-")[:20]
        return f"apm-toolkit-{user}"


@dataclass
class WorkspaceInfo:
    """Information about an active workspace."""

    name: str
    ssh_host: str


@dataclass
class TmuxSession:
    """Metadata for a tmux session running on a workspace."""

    name: str
    workspace: WorkspaceInfo
    exit_file: str
    script_file: str
