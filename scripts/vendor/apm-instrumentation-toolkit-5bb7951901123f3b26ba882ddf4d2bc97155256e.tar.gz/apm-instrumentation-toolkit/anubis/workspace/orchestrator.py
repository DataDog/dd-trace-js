"""High-level orchestration for remote workspace execution.

Ties together WorkspaceManager, deploy, and WorkspaceExecutor into a single
flow: ensure workspace exists -> deploy toolkit -> configure secrets ->
clone target repo -> run workflow -> pull results.
"""

from __future__ import annotations

import getpass
import logging
import os
from pathlib import Path
from typing import Callable

from .deploy import clone_repo_in_workspace, write_workspace_config
from .executor import RemoteResult, WorkspaceExecutor
from .manager import WorkspaceManager
from .models import WorkspaceConfig, WorkspaceInfo

logger = logging.getLogger(__name__)

_REQUIRED_SECRETS = (
    "ANTHROPIC_API_KEY",
    "DD_API_KEY",
    "DD_APP_KEY",
    "GH_TOKEN",
)

StatusCallback = Callable[[str], None]


def _default_status(msg: str) -> None:
    logger.info(msg)


def run_in_workspace(
    command: str,
    command_args: list[str],
    *,
    workspace_name: str | None = None,
    repository: str | None = None,
    repo_clone_url: str | None = None,
    repo_branch: str | None = None,
    repo_language: str = "node",
    toolkit_root: Path | None = None,
    toolkit_branch: str | None = None,
    env_vars: dict[str, str] | None = None,
    stream: bool = True,
    timeout: int = 3600,
    on_status: StatusCallback = _default_status,
) -> RemoteResult:
    """Run a dd-apm command in a remote workspace.

    This is the main entry point for workspace execution. It handles the full
    lifecycle: create/reuse workspace, deploy toolkit, configure secrets,
    clone target repo, execute, and optionally pull results.

    Args:
        command: The dd-apm subcommand (e.g., "create", "analyze")
        command_args: Arguments for the command (e.g., ["kafkajs", "--mode=agent"])
        workspace_name: Optional workspace name (auto-generated if None)
        repository: Repository identifier (e.g., "dd_trace_js")
        repo_clone_url: Git clone URL for the target repo
        repo_branch: Branch to clone in the target repo
        toolkit_root: Local toolkit root (for source deployment)
        toolkit_branch: Toolkit branch to clone from GitHub
        env_vars: Additional environment variables to set remotely
        stream: Stream output to local terminal
        timeout: Command timeout in seconds
        on_status: Callback for user-visible progress messages
    """
    config = WorkspaceConfig(
        name=workspace_name,
        toolkit_branch=toolkit_branch,
    )
    manager = WorkspaceManager(config)

    # Step 1: Create or reuse workspace
    on_status(
        "Creating workspace..."
        if not workspace_name
        else f"Connecting to workspace '{workspace_name}'..."
    )
    workspace = manager.create()
    on_status(f"Workspace ready: {workspace.name} (ssh: {workspace.ssh_host})")

    # Step 2: Check for an existing running session to reconnect to
    probe = WorkspaceExecutor(workspace=workspace)
    existing = probe.find_running_session()
    if existing:
        existing_cmd = probe.get_session_command(existing)
        if existing_cmd == command:
            on_status(
                f"Found running '{command}' workflow — reconnecting to tmux session '{existing.name}'..."
            )
            result = probe.attach_to_session(existing, timeout=timeout)
            return _handle_post_run(result, workspace, on_status)
        else:
            on_status(
                f"Found stale session '{existing.name}' (was running '{existing_cmd or 'unknown'}') "
                f"— killing it to run '{command}'..."
            )
            probe.run_raw(f"tmux kill-session -t {existing.name} 2>/dev/null", timeout=10)

    # Step 3: Deploy toolkit
    on_status("Deploying toolkit to workspace...")
    manager.deploy_toolkit(workspace, toolkit_root)
    on_status("Toolkit deployed.")

    # Step 4: Configure secrets
    secrets = _collect_secrets()
    if secrets:
        on_status(f"Configuring {len(secrets)} secret(s)...")
        manager.configure_secrets(secrets)

    # Step 5: Clone target repo (if a clone URL is available)
    remote_repo_path: str | None = None
    if repo_clone_url:
        on_status("Cloning target repo into workspace...")
        remote_repo_path = clone_repo_in_workspace(workspace, repo_clone_url, repo_branch)
        on_status(f"Repo available at {remote_repo_path}")

        # Write workspace-specific config pointing to the cloned repo
        if repository:
            write_workspace_config(workspace, repository, remote_repo_path, repo_language)

        # Configure the toolkit to use this repo
        repo_config_args = []
        if repository:
            repo_config_args = [
                "--repository",
                repository,
            ]
        command_args = repo_config_args + command_args

    # Step 6: Execute workflow
    # Secrets are already in the workspace env via `workspaces secrets set --export` (step 4).
    # Do not re-inject them here — that would write plaintext API keys into the tmux script file.
    remote_env = dict(env_vars or {})
    remote_env.setdefault("DD_TRACE_AGENT_URL", "http://localhost:18127")
    remote_env.setdefault("DD_TRACE_AGENT_PORT", "18127")
    remote_env.setdefault("DD_APM_USER", os.environ.get("DD_APM_USER") or getpass.getuser())
    if repository:
        remote_env["DD_TRACER_REPO"] = remote_repo_path or f"~/repos/{repository.replace('_', '-')}"

    executor = WorkspaceExecutor(
        workspace=workspace,
        env_vars=remote_env,
    )

    on_status(f"Running: dd-apm {command} {' '.join(command_args)}")
    on_status(f"Connect manually: ssh {workspace.ssh_host}")
    result = executor.run_workflow(
        command,
        command_args,
        stream=stream,
        timeout=timeout,
    )

    # Step 7: Handle results
    return _handle_post_run(result, workspace, on_status)


def _handle_post_run(
    result: RemoteResult,
    workspace: WorkspaceInfo,
    on_status: StatusCallback,
) -> RemoteResult:
    """Shared post-run handling for both fresh runs and reconnections."""
    if result.still_running:
        session = result.tmux_session
        on_status("SSH disconnected but workflow is still running in the workspace.")
        if session:
            on_status(
                f"Reconnect: run the same dd-apm command with --workspace again, "
                f"or ssh {workspace.ssh_host} -t 'tmux attach -t {session.name}'"
            )
        return result

    on_status(f"Workspace available — ssh {workspace.ssh_host}")
    return result


def _collect_secrets() -> dict[str, str]:
    """Collect API keys from the local environment."""
    return {k: v for k in _REQUIRED_SECRETS if (v := os.environ.get(k, ""))}
