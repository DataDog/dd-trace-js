"""Remote command execution on a workspace with output streaming."""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field

from .models import REMOTE_TOOLKIT_DIR, TmuxSession, WorkspaceInfo

logger = logging.getLogger(__name__)

_SSH_OPTS = ["-o", "StrictHostKeyChecking=no"]


@dataclass
class RemoteResult:
    """Result of a remote command execution."""

    exit_code: int
    stdout: str = ""
    stderr: str = ""
    branch_pushed: str | None = None
    still_running: bool = False
    tmux_session: TmuxSession | None = None


@dataclass
class WorkspaceExecutor:
    """Execute commands on a remote workspace via SSH."""

    workspace: WorkspaceInfo
    toolkit_dir: str = REMOTE_TOOLKIT_DIR
    env_vars: dict[str, str] = field(default_factory=dict)

    def run_workflow(
        self,
        command: str,
        args: list[str],
        *,
        stream: bool = True,
        timeout: int = 3600,
    ) -> RemoteResult:
        """Run a dd-apm workflow command remotely.

        Args:
            command: The workflow command (e.g., "create", "analyze")
            args: Additional arguments (e.g., ["kafkajs", "--mode=agent"])
            stream: Stream output to local terminal in real-time
            timeout: SSH command timeout in seconds
        """
        cmd_parts = [
            f"cd {self.toolkit_dir}",
            "source .venv/bin/activate",
        ]

        for key, value in self.env_vars.items():
            cmd_parts.append(f"export {key}={_shell_quote(value)}")

        dd_apm_args = [command, *args]

        cmd_parts.append(f"dd-apm {' '.join(dd_apm_args)}")
        remote_cmd = " && ".join(cmd_parts)

        logger.info("Executing on %s: dd-apm %s", self.workspace.name, " ".join(dd_apm_args))

        if stream:
            return self._run_streaming(remote_cmd, timeout)
        return self._run_captured(remote_cmd, timeout)

    def find_running_session(self) -> TmuxSession | None:
        """Check for an existing dd-apm tmux session whose workflow is still running.

        Sessions whose workflow has completed (exit file exists) are cleaned up
        automatically — they're just leftover bash shells from ``exec bash -l``.
        """
        result = self._run_captured(
            "tmux list-sessions -F '#{session_name}' 2>/dev/null | grep '^dd-apm-'",
            timeout=10,
        )
        if result.exit_code != 0 or not result.stdout.strip():
            return None

        for session_name in result.stdout.strip().splitlines():
            session_name = session_name.strip()
            if not session_name:
                continue
            exit_file = f"/tmp/{session_name}.exit"

            exit_check = self._run_captured(f"cat {exit_file} 2>/dev/null", timeout=10)
            if exit_check.exit_code == 0 and exit_check.stdout.strip():
                logger.debug("Cleaning up completed session %s", session_name)
                self._run_captured(
                    f"tmux kill-session -t {session_name} 2>/dev/null && "
                    f"rm -f {exit_file} /tmp/{session_name}.sh",
                    timeout=10,
                )
                continue

            return TmuxSession(
                name=session_name,
                workspace=self.workspace,
                exit_file=exit_file,
                script_file=f"/tmp/{session_name}.sh",
            )

        return None

    def get_session_command(self, session: TmuxSession) -> str | None:
        """Read the dd-apm command from a session's script file.

        Returns the command string (e.g. "create") or None if unreadable.
        """
        result = self._run_captured(
            f"grep -oP 'dd-apm \\K\\S+' {session.script_file} 2>/dev/null",
            timeout=10,
        )
        if result.exit_code == 0 and result.stdout.strip():
            return result.stdout.strip().splitlines()[0]
        return None

    def attach_to_session(self, session: TmuxSession, *, timeout: int = 3600) -> RemoteResult:
        """Reconnect to an existing tmux session."""
        return self._attach_tmux(session, timeout)

    def run_raw(
        self,
        command: str,
        *,
        stream: bool = False,
        timeout: int = 120,
    ) -> RemoteResult:
        """Run an arbitrary command on the workspace."""
        if stream:
            return self._run_streaming(command, timeout)
        return self._run_captured(command, timeout)

    def pull_results(
        self,
        remote_repo_path: str,
        local_repo_path: str,
        branch_name: str | None = None,
    ) -> RemoteResult:
        """Pull workflow results from the workspace via git.

        Commits changes in the workspace, pushes to a branch, and fetches locally.
        """
        if not branch_name:
            branch_name = f"workspace/{self.workspace.name}/{int(time.time())}"

        commit_and_push = (
            f"cd {remote_repo_path} && "
            f"git checkout -b {branch_name} && "
            f"git add -A && "
            f"git diff --cached --quiet || "
            f"git -c commit.gpgSign=false commit -m 'workspace: automated changes from {self.workspace.name}' && "
            f"git push origin {branch_name}"
        )
        result = self._run_captured(commit_and_push, timeout=120)

        if result.exit_code != 0:
            logger.warning(
                "Git push from workspace failed: %s%s",
                result.stdout,
                result.stderr,
            )
            return result

        fetch_result = subprocess.run(
            ["git", "fetch", "origin", branch_name],
            capture_output=True,
            text=True,
            cwd=local_repo_path,
            timeout=60,
        )
        if fetch_result.returncode != 0:
            logger.warning("Local git fetch failed: %s", fetch_result.stderr)

        result.branch_pushed = branch_name
        return result

    def _run_streaming(self, remote_cmd: str, timeout: int) -> RemoteResult:
        """Run a command in a tmux session with live output streaming.

        The workflow runs inside tmux so it survives SSH disconnection (e.g.
        laptop close). We write a script then create the session and attach
        in a single SSH call (no ``-d``) to avoid a race between session
        start and attach. When SSH drops, tmux detaches and the command
        continues running.
        """
        session = self._prepare_tmux_session(remote_cmd)
        return self._attach_tmux(session, timeout, create=True)

    def _prepare_tmux_session(self, remote_cmd: str) -> TmuxSession:
        """Write a wrapper script to the workspace (does not start tmux yet)."""
        cols, lines = shutil.get_terminal_size()
        session_name = f"dd-apm-{int(time.time())}"
        script_file = f"/tmp/{session_name}.sh"
        exit_file = f"/tmp/{session_name}.exit"

        script_content = (
            "#!/bin/bash\n"
            f"export FORCE_COLOR=1 PYTHONUNBUFFERED=1 DD_APM_REMOTE=1"
            f" COLUMNS={cols} LINES={lines}"
            f" TERM=xterm-256color LANG=en_US.UTF-8\n"
            f"{remote_cmd}\n"
            f"echo $? > {exit_file}\n"
            f"exec bash -l\n"
        )

        write_result = subprocess.run(
            [
                "ssh",
                *_SSH_OPTS,
                self.workspace.ssh_host,
                f"cat > {script_file} && chmod +x {script_file}",
            ],
            input=script_content,
            capture_output=True,
            text=True,
            timeout=15,
        )
        if write_result.returncode != 0:
            raise RuntimeError(f"Failed to write script to workspace: {write_result.stderr}")

        return TmuxSession(
            name=session_name,
            workspace=self.workspace,
            exit_file=exit_file,
            script_file=script_file,
        )

    def _attach_tmux(
        self, session: TmuxSession, timeout: int, *, create: bool = False
    ) -> RemoteResult:
        """Attach to a tmux session via SSH with a PTY.

        When *create* is True, creates the session and attaches in one call
        (``tmux new-session`` without ``-d``), eliminating the race between
        a detached start and a subsequent attach.  When False, attaches to
        an already-running session (reconnect path).

        If the SSH connection drops (e.g. laptop close), tmux detaches and
        the workflow keeps running.  A later invocation finds the session
        via ``find_running_session`` and reattaches.
        """
        if create:
            tmux_cmd = f"tmux -u new-session -s {session.name} 'bash {session.script_file}'"
        else:
            tmux_cmd = f"tmux -u attach -t {session.name}"

        proc = subprocess.Popen(
            ["ssh", "-tt", *_SSH_OPTS, self.workspace.ssh_host, tmux_cmd],
            stdin=sys.stdin,
            stdout=sys.stdout,
            stderr=subprocess.DEVNULL,
        )

        try:
            proc.wait(timeout=timeout)
        except KeyboardInterrupt:
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.terminate()
        except subprocess.TimeoutExpired:
            proc.terminate()
            return RemoteResult(exit_code=124, stderr="SSH session timed out")

        return self._collect_tmux_result(session)

    def _collect_tmux_result(self, session: TmuxSession) -> RemoteResult:
        """Check whether the workflow finished and collect exit code.

        The tmux session stays alive after the workflow (``exec bash -l``
        keeps a shell open), so we check the exit-code file to determine
        whether the *workflow* completed — not just the session.
        """
        exit_result = self._run_captured(
            f"cat {session.exit_file} 2>/dev/null",
            timeout=10,
        )

        if exit_result.exit_code == 0 and exit_result.stdout.strip().isdigit():
            exit_code = int(exit_result.stdout.strip())
            self._run_captured(f"rm -f {session.script_file} {session.exit_file}", timeout=5)
            self._run_captured(f"tmux kill-session -t {session.name} 2>/dev/null", timeout=5)
            return RemoteResult(exit_code=exit_code)

        check = self._run_captured(
            f"tmux has-session -t {session.name} 2>/dev/null && echo running || echo done",
            timeout=10,
        )

        if "running" in check.stdout:
            return RemoteResult(
                exit_code=0,
                still_running=True,
                tmux_session=session,
            )

        return RemoteResult(exit_code=1)

    def _run_captured(self, remote_cmd: str, timeout: int) -> RemoteResult:
        """Run a command and capture all output."""
        try:
            result = subprocess.run(
                ["ssh", *_SSH_OPTS, self.workspace.ssh_host, remote_cmd],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            return RemoteResult(
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
            )
        except subprocess.TimeoutExpired:
            return RemoteResult(exit_code=124, stderr="Command timed out")


def _shell_quote(value: str) -> str:
    """Quote a value for safe shell interpolation."""
    return "'" + value.replace("'", "'\\''") + "'"
