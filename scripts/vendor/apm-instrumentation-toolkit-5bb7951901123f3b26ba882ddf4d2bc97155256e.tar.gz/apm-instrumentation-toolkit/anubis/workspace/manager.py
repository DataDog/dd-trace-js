"""Workspace lifecycle management via the `workspaces` CLI."""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

from .deploy import deploy_to_workspace
from .models import WorkspaceConfig, WorkspaceInfo

logger = logging.getLogger(__name__)

_WORKSPACES_BIN = "workspaces"


def _run_workspaces(args: list[str], *, timeout: int = 30) -> subprocess.CompletedProcess:
    """Run a `workspaces` CLI command."""
    bin_path = shutil.which(_WORKSPACES_BIN)
    if not bin_path:
        raise RuntimeError(
            f"'{_WORKSPACES_BIN}' CLI not found. "
            "Install it: brew install --cask datadog/tap/datadog-workspaces"
        )
    cmd = [bin_path, *args]
    logger.debug("Running: %s", " ".join(cmd))
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"'{_WORKSPACES_BIN} {' '.join(args)}' timed out after {timeout}s. "
            "Check your VPN connection and workspace auth."
        ) from exc


class WorkspaceManager:
    """Manages Datadog workspace lifecycle."""

    def __init__(self, config: WorkspaceConfig | None = None) -> None:
        self.config = config or WorkspaceConfig()

    def list_workspaces(self) -> list[dict]:
        """List active workspaces."""
        result = _run_workspaces(["list"])
        if result.returncode != 0:
            raise RuntimeError(f"Failed to list workspaces: {result.stderr}")
        workspaces = []
        for line in result.stdout.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("NAME") or line.startswith("-"):
                continue
            parts = line.split()
            if parts:
                workspaces.append({"name": parts[0]})
        return workspaces

    def workspace_exists(self, name: str) -> bool:
        """Check if a workspace with the given name exists."""
        try:
            workspaces = self.list_workspaces()
            return any(ws.get("name") == name for ws in workspaces)
        except RuntimeError:
            return False

    def create(self) -> WorkspaceInfo:
        """Create a new workspace or reuse an existing one."""
        name = self.config.resolved_name

        if self.workspace_exists(name):
            logger.info("Reusing existing workspace: %s", name)
            self._update_ssh_config(name)
            return WorkspaceInfo(name=name, ssh_host=f"workspace-{name}")

        logger.info("Creating workspace: %s (region=%s)", name, self.config.region)
        result = _run_workspaces(
            ["create", name, "--region", self.config.region, "--yes"],
            timeout=300,
        )
        if result.returncode != 0:
            raise RuntimeError(f"Failed to create workspace '{name}': {result.stderr}")

        self._update_ssh_config(name)
        return WorkspaceInfo(name=name, ssh_host=f"workspace-{name}")

    def delete(self, name: str) -> None:
        """Delete a workspace."""
        result = _run_workspaces(["delete", name, "--yes"], timeout=120)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to delete workspace '{name}': {result.stderr}")
        logger.info("Deleted workspace: %s", name)

    def _update_ssh_config(self, name: str) -> None:
        """Update local SSH config for workspace access."""
        result = _run_workspaces(["ssh-config", name], timeout=30)
        if result.returncode != 0:
            logger.warning("Failed to update SSH config for %s: %s", name, result.stderr)

    def configure_secrets(self, secrets: dict[str, str]) -> None:
        """Push secrets to the workspace via `workspaces secrets set`."""
        for key, value in secrets.items():
            if not value:
                continue
            result = _run_workspaces(
                ["secrets", "set", f"{key}={value}", "--export"],
                timeout=30,
            )
            if result.returncode != 0:
                logger.warning("Failed to set secret %s: %s", key, result.stderr)
            else:
                logger.debug("Set workspace secret: %s", key)

    def deploy_toolkit(
        self,
        workspace: WorkspaceInfo,
        toolkit_root: Path | None = None,
    ) -> None:
        """Deploy the toolkit into the workspace."""
        deploy_to_workspace(workspace, self.config, toolkit_root)
